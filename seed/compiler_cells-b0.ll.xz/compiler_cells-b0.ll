; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64 }
%"compiler/cells:Worker" = type { i1, i32, i32, i32, i32, i32, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cells:Outcome" = type { i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cells:Plan" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
define dso_local i32 @compiler_2fcells_2eBuild(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, ptr %v8, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, ptr %a6, { i64, ptr } %a7, ptr %a8) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %lp9 = alloca ptr
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca %"compiler/build:Program"
  %l40 = alloca %"compiler/build:Config"
  %l42 = alloca %"compiler/build:Config"
  %l54 = alloca i32
  %l57 = alloca i64
  %l61 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i64
  %l88 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca i64
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l112 = alloca i32
  %l114 = alloca i1
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l123 = alloca i32
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l132 = alloca i64
  %l134 = alloca i64
  %l139 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i32
  %l151 = alloca i1
  %l154 = alloca i64
  %l177 = alloca i64
  %l179 = alloca i64
  %l184 = alloca { i64, ptr }
  %l191 = alloca i64
  %l193 = alloca i64
  %l198 = alloca { i64, ptr }
  %l221 = alloca i1
  %l227 = alloca i32
  %s0 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  %t6 = alloca %"compiler/build:Config", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a7, ptr %l7
  store ptr %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %v8)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t1, i64 280, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v8, i64 280, i64 8)
  store ptr %t2, ptr %lp9
  %t3 = load ptr, ptr %lp9
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l38, i64 280, i1 false)
  %t4 = load ptr, ptr %l0, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t4, i64 720, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbuild_3aConfig(ptr %t6, ptr %v0, ptr %l40)
  call void @llvm.memmove.p0.p0.i64(ptr %l42, ptr %t6, i64 720, i1 false)
  br label %bb2
bb2:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 720, i64 8)
  store ptr %t8, ptr %lp10
  %t9 = load ptr, ptr %lp10
  call void @llvm.memmove.p0.p0.i64(ptr %t9, ptr %l42, i64 720, i1 false)
  %t10 = load { ptr, ptr }, ptr @G_2ecompiler_2fcells_2eBuilder
  %t12 = extractvalue { ptr, ptr } %t10, 0
  %t13 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t14 = icmp eq ptr %t12, %t13
  %t15 = extractvalue { ptr, ptr } %t10, 1
  %t16 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t17 = icmp eq ptr %t15, %t16
  %t18 = and i1 %t14, %t17
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_982e698976ed59f7_448003811d791d9b)
  unreachable
bb4:
  br label %bb5
bb5:
  %t20 = load { ptr, ptr }, ptr @G_2ecompiler_2fcells_2eBuilder
  %t26 = load ptr, ptr %lp10
  %t27 = load ptr, ptr %lp9
  %t28 = load ptr, ptr %l8, !tbaa !29
  %t30 = extractvalue { ptr, ptr } %t20, 0
  %t31 = extractvalue { ptr, ptr } %t20, 1
  %t40 = call i32 %t30(ptr %t31, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v0, ptr %v8, ptr %v8, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, ptr %t26, ptr %t27, ptr %t28)
  store i32 %t40, ptr %l54
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb7, label %ok.42, !prof !99
ok.42:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t43 = load i32, ptr %l54, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 1, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  call void @__olang_scope_close(ptr %s0)
  store i32 %t51, ptr %rv
  br label %ret
bb8:
  %t53 = load ptr, ptr %l8, !tbaa !29
  %t55 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v8, ptr %t53)
  store i64 %t55, ptr %l57
  br label %bb9
bb9:
  %t56 = load i64, ptr %l57, !tbaa !24
  %t57 = icmp sgt i64 %t56, 0
  br i1 %t57, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  store i64 0, ptr %l11, !tbaa !24
  %t60 = load ptr, ptr %lp9
  %t61 = getelementptr %"compiler/build:Program", ptr %t60, i32 0, i32 0
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v8, ptr %t61)
  store i64 %t63, ptr %l61
  br label %bb13
bb13:
  %t64 = load i64, ptr %l61, !tbaa !24
  store i64 %t64, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t65 = load i64, ptr %l12, !tbaa !24
  %t66 = load i64, ptr %l11, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t71 = load i64, ptr %l13, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb19
bb16:
  %t75 = load i64, ptr %l12, !tbaa !24
  %t76 = load i64, ptr %l11, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l13, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l13, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l68, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb18
bb18:
  %t91 = load i64, ptr %l68, !tbaa !24
  store i64 %t91, ptr %l65, !tbaa !24
  br label %bb19
bb19:
  %t92 = load i64, ptr %l65, !tbaa !24
  store i64 %t92, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb20
bb20:
  %t93 = load i64, ptr %l15, !tbaa !24
  %t94 = load i64, ptr %l14, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb21, label %bb22
bb21:
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t101 = load i64, ptr %l11, !tbaa !24
  %t102 = load i64, ptr %l15, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  %t111 = load ptr, ptr %lp9
  %t112 = getelementptr %"compiler/build:Program", ptr %t111, i32 0, i32 0
  %t116 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eRefMut_3ccompiler_2fbuild_3aUnit_3e(ptr %v8, ptr %v8, ptr %t112, i64 %t109)
  store ptr %t116, ptr %l88
  br label %bb24
bb24:
  %t117 = load ptr, ptr %l88, !tbaa !29
  store ptr %t117, ptr %l17, !tbaa !29
  %t118 = load ptr, ptr %l17, !tbaa !29
  %t120 = getelementptr %"compiler/build:Unit", ptr %t118, i32 0, i32 1
  %t121 = load i32, ptr %t120, !range !{i32 0, i32 5}
  %t123 = trunc i64 0 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb25, label %bb26
bb25:
  br label %bb35
bb26:
  br label %bb27
bb27:
  %t126 = load ptr, ptr %l17, !tbaa !29
  store ptr %t126, ptr %l92, !tbaa !29
  %t127 = call ptr @__olang_scope_hold(ptr %v8)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l93, !tbaa !24
  %t129 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aUnit_2e2
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t131 = call ptr @__olang_region_make(ptr %v8)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l93, !tbaa !24
  br label %bb29
bb29:
  %t133 = load ptr, ptr %l17, !tbaa !29
  %t135 = getelementptr %"compiler/build:Unit", ptr %t133, i32 0, i32 2
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t138 = load i64, ptr %l93
  %t139 = inttoptr i64 %t138 to ptr
  %t142 = call { i64, ptr } @compiler_2fcells_2erewrite(ptr %v8, ptr %v6, ptr %t139, { i64, ptr } %t136, ptr %a6)
  store { i64, ptr } %t142, ptr %l98
  br label %bb30
bb30:
  %t143 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t144 = load ptr, ptr %l92, !tbaa !29
  %t145 = getelementptr %"compiler/build:Unit", ptr %t144, i32 0, i32 2
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l100, !tbaa !27
  %t148 = load ptr, ptr %l92, !tbaa !29
  %t149 = getelementptr %"compiler/build:Unit", ptr %t148, i32 0, i32 2
  store { i64, ptr } %t143, ptr %t149, !tbaa !27
  %t150 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aUnit_2e2
  br i1 %t150, label %bb31, label %bb32
bb31:
  %t152 = load { i64, ptr }, ptr %l100
  %t153 = extractvalue { i64, ptr } %t152, 1
  call void @__olang_region_release(ptr %t153)
  store { i64, ptr } zeroinitializer, ptr %l100
  br label %bb32
bb32:
  %t154 = load ptr, ptr %l17, !tbaa !29
  store ptr %t154, ptr %l102, !tbaa !29
  %t155 = load ptr, ptr %l102, !tbaa !29
  %t156 = getelementptr %"compiler/build:Unit", ptr %t155, i32 0, i32 3
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l103, !tbaa !27
  %t158 = load ptr, ptr %l102, !tbaa !29
  %t159 = getelementptr %"compiler/build:Unit", ptr %t158, i32 0, i32 3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %t159, !tbaa !27
  %t160 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aUnit_2e3
  br i1 %t160, label %bb33, label %bb34
bb33:
  %t162 = load { i64, ptr }, ptr %l103
  %t163 = extractvalue { i64, ptr } %t162, 1
  call void @__olang_region_release(ptr %t163)
  store { i64, ptr } zeroinitializer, ptr %l103
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t164 = load i64, ptr %l15, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l15, !tbaa !24
  br label %bb20
bb36:
  %t169 = load ptr, ptr %lp9
  %t170 = getelementptr %"compiler/build:Program", ptr %t169, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  store { i64, ptr } %t171, ptr %l108, !tbaa !27
  %t172 = load ptr, ptr %lp9
  %t173 = getelementptr %"compiler/build:Program", ptr %t172, i32 0, i32 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %t173, !tbaa !27
  %t174 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e1
  br i1 %t174, label %bb37, label %bb38
bb37:
  %t176 = load { i64, ptr }, ptr %l108
  %t177 = extractvalue { i64, ptr } %t176, 1
  call void @__olang_region_release(ptr %t177)
  store { i64, ptr } zeroinitializer, ptr %l108
  br label %bb38
bb38:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/build:Config", ptr %t178, i32 0, i32 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t183 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t181)
  store i32 %t183, ptr %l112
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb40, label %ok.185, !prof !99
ok.185:
  br label %bb39
bb39:
  br label %bb44
bb40:
  %t186 = load i32, ptr %l112, !tbaa !23
  %t187 = ashr i32 %t186, 16
  %t189 = icmp eq i32 %t187, 1
  store i1 %t189, ptr %l114, !tbaa !21
  %t190 = load i32, ptr %l112, !tbaa !23
  %t191 = ashr i32 %t190, 16
  %t193 = icmp eq i32 %t191, 1
  br i1 %t193, label %bb41, label %bb42
bb41:
  call void @__olang_errpay_pop()
  br label %bb42
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb44:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %lp9
  %t198 = load ptr, ptr %l8, !tbaa !29
  %t202 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v8, ptr %v8, ptr %v8, ptr %t196, ptr %t197, ptr %t198)
  %t203 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t202, 1
  %t204 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t202, 0
  store i32 %t204, ptr %l123
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb46, label %ok.206, !prof !99
ok.206:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t203, ptr %l122
  br label %bb45
bb45:
  %t207 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t207, ptr %l118
  br label %bb47
bb46:
  %t208 = load i32, ptr %l123, !tbaa !23
  %t209 = lshr i32 %t208, 16
  %t210 = and i32 %t208, 65535
  %t211 = icmp eq i32 %t209, 1
  %t212 = select i1 %t211, i32 1, i32 0
  %t213 = icmp eq i32 %t208, 0
  %t214 = shl i32 %t212, 16
  %t215 = or i32 %t214, %t210
  %t216 = select i1 %t213, i32 0, i32 %t215
  call void @__olang_scope_close(ptr %s0)
  store i32 %t216, ptr %rv
  br label %ret
bb47:
  %t218 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %l18
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb48
bb48:
  %t219 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t219, ptr %l125
  br label %bb49
bb49:
  %t220 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t220, ptr %l19
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/build:Config", ptr %t221, i32 0, i32 1
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l19, { i64, ptr } %t224)
  br label %bb50
bb50:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s0, ptr %t227)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %l130
  br label %bb51
bb51:
  %t230 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l130
  %t231 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %t231
  store ptr %t231, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb52
bb52:
  %t233 = load i64, ptr %l21, !tbaa !24
  store i64 %t233, ptr %l132, !tbaa !24
  %t234 = load ptr, ptr %l20, !tbaa !29
  %t236 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t234)
  store i64 %t236, ptr %l134
  br label %bb53
bb53:
  %t237 = load i64, ptr %l132, !tbaa !24
  %t238 = load i64, ptr %l134, !tbaa !24
  %t239 = icmp slt i64 %t237, %t238
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb54, label %bb55
bb54:
  br label %bb60
bb55:
  br label %bb56
bb56:
  %t243 = load ptr, ptr %l20, !tbaa !29
  %t244 = load i64, ptr %l21, !tbaa !24
  %t247 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t243, i64 %t244)
  store { i64, ptr } %t247, ptr %l139
  br label %bb57
bb57:
  %t248 = load { i64, ptr }, ptr %l139, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t248)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t252 = load i64, ptr %l21, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l21, !tbaa !24
  br label %bb52
bb60:
  %t257 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t257, 1
  %t260 = extractvalue { i64, ptr } %t257, 0
  %t261 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t259, i64 %t260)
  %t265 = getelementptr i8, ptr %t264, i64 %t260
  call void @olang_textcopy(ptr %t265, ptr %t261, i64 %t262)
  %t266 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t264, 1
  store { i64, ptr } %t267, ptr %l23, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l148, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t272 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t269, { i64, ptr } %t271)
  store i32 %t272, ptr %l149
  %t273 = icmp ne i32 %t272, 0
  br i1 %t273, label %bb62, label %ok.274, !prof !99
ok.274:
  br label %bb61
bb61:
  br label %bb66
bb62:
  %t275 = load i32, ptr %l149, !tbaa !23
  %t276 = ashr i32 %t275, 16
  %t278 = icmp eq i32 %t276, 1
  store i1 %t278, ptr %l151, !tbaa !21
  %t279 = load i32, ptr %l149, !tbaa !23
  %t280 = ashr i32 %t279, 16
  %t282 = icmp eq i32 %t280, 1
  br i1 %t282, label %bb63, label %bb64
bb63:
  call void @__olang_errpay_pop()
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t284 = call ptr @__olang_scope_hold(ptr %s0)
  %t285 = ptrtoint ptr %t284 to i64
  store i64 %t285, ptr %l154, !tbaa !24
  %t286 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_205_3e_2e_2d1
  br i1 %t286, label %bb67, label %bb68
bb67:
  %t288 = call ptr @__olang_region_make(ptr %s0)
  %t289 = ptrtoint ptr %t288 to i64
  store i64 %t289, ptr %l154, !tbaa !24
  br label %bb68
bb68:
  %t290 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t291 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t294 = extractvalue { i64, ptr } %t290, 1
  %t295 = extractvalue { i64, ptr } %t290, 0
  %t296 = add i64 %t292, %t295
  %t297 = load i64, ptr %l154
  %t298 = inttoptr i64 %t297 to ptr
  %t299 = call ptr @__olang_held_alloc(ptr %t298, i64 %t296)
  call void @olang_textcopy(ptr %t299, ptr %t291, i64 %t292)
  %t300 = getelementptr i8, ptr %t299, i64 %t292
  call void @olang_textcopy(ptr %t300, ptr %t294, i64 %t295)
  %t301 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t299, 1
  %t304 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t305 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t306 = insertvalue [5 x { i64, ptr }] %t305, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t308 = insertvalue [5 x { i64, ptr }] %t306, { i64, ptr } %t302, 2
  %t309 = insertvalue [5 x { i64, ptr }] %t308, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 3
  %t311 = insertvalue [5 x { i64, ptr }] %t309, { i64, ptr } %t304, 4
  %t313 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 80, i64 8)
  store [5 x { i64, ptr }] %t311, ptr %t313
  store ptr %t313, ptr %l24
  store i64 0, ptr %l25, !tbaa !24
  %t315 = load ptr, ptr %l24
  store i64 5, ptr %l26, !tbaa !24
  br label %bb69
bb69:
  %t318 = load i64, ptr %l25, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  %t322 = icmp slt i64 %t318, %t319
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb70, label %bb71
bb70:
  br label %bb75
bb71:
  br label %bb72
bb72:
  %t326 = load ptr, ptr %l24
  %t327 = load i64, ptr %l25, !tbaa !24
  %t330 = getelementptr [5 x { i64, ptr }], ptr %t326, i64 0, i64 %t327
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t331)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t336 = load i64, ptr %l25, !tbaa !24
  %t339 = add i64 %t336, 1
  store i64 %t339, ptr %l25, !tbaa !24
  br label %bb69
bb75:
  store ptr %l18, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb76
bb76:
  %t342 = load i64, ptr %l29, !tbaa !24
  store i64 %t342, ptr %l177, !tbaa !24
  %t343 = load ptr, ptr %l28, !tbaa !29
  %t345 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v8, ptr %t343)
  store i64 %t345, ptr %l179
  br label %bb77
bb77:
  %t346 = load i64, ptr %l177, !tbaa !24
  %t347 = load i64, ptr %l179, !tbaa !24
  %t348 = icmp slt i64 %t346, %t347
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb78, label %bb79
bb78:
  br label %bb84
bb79:
  br label %bb80
bb80:
  %t352 = load ptr, ptr %l28, !tbaa !29
  %t353 = load i64, ptr %l29, !tbaa !24
  %t356 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v8, ptr %v8, ptr %t352, i64 %t353)
  store { i64, ptr } %t356, ptr %l184
  br label %bb81
bb81:
  %t357 = load { i64, ptr }, ptr %l184, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v8, ptr %l19, { i64, ptr } %t357)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t361 = load i64, ptr %l29, !tbaa !24
  %t364 = add i64 %t361, 1
  store i64 %t364, ptr %l29, !tbaa !24
  br label %bb76
bb84:
  %t366 = load ptr, ptr %lp9
  %t367 = getelementptr %"compiler/build:Program", ptr %t366, i32 0, i32 3
  store ptr %t367, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb85
bb85:
  %t369 = load i64, ptr %l32, !tbaa !24
  store i64 %t369, ptr %l191, !tbaa !24
  %t370 = load ptr, ptr %l31, !tbaa !29
  %t372 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v8, ptr %t370)
  store i64 %t372, ptr %l193
  br label %bb86
bb86:
  %t373 = load i64, ptr %l191, !tbaa !24
  %t374 = load i64, ptr %l193, !tbaa !24
  %t375 = icmp slt i64 %t373, %t374
  %t377 = xor i1 %t375, true
  br i1 %t377, label %bb87, label %bb88
bb87:
  br label %bb93
bb88:
  br label %bb89
bb89:
  %t379 = load ptr, ptr %l31, !tbaa !29
  %t380 = load i64, ptr %l32, !tbaa !24
  %t383 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v8, ptr %v8, ptr %t379, i64 %t380)
  store { i64, ptr } %t383, ptr %l198
  br label %bb90
bb90:
  %t384 = load { i64, ptr }, ptr %l198, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v8, ptr %l19, { i64, ptr } %t384)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t388 = load i64, ptr %l32, !tbaa !24
  %t391 = add i64 %t388, 1
  store i64 %t391, ptr %l32, !tbaa !24
  br label %bb85
bb93:
  store %olang.scope zeroinitializer, ptr %s22
  %t393 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t394 = insertvalue [3 x { i64, ptr }] %t393, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t395 = insertvalue [3 x { i64, ptr }] %t394, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, 2
  %t397 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 48, i64 8)
  store [3 x { i64, ptr }] %t395, ptr %t397
  store ptr %t397, ptr %l34
  store i64 0, ptr %l35, !tbaa !24
  %t399 = load ptr, ptr %l34
  store i64 3, ptr %l36, !tbaa !24
  br label %bb94
bb94:
  %t402 = load i64, ptr %l35, !tbaa !24
  %t403 = load i64, ptr %l36, !tbaa !24
  %t406 = icmp slt i64 %t402, %t403
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb95, label %bb96
bb95:
  br label %bb100
bb96:
  br label %bb97
bb97:
  %t410 = load ptr, ptr %l34
  %t411 = load i64, ptr %l35, !tbaa !24
  %t414 = getelementptr [3 x { i64, ptr }], ptr %t410, i64 0, i64 %t411
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !37
  %t418 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %t418, ptr %l19, { i64, ptr } %t415)
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t421 = load i64, ptr %l35, !tbaa !24
  %t424 = add i64 %t421, 1
  store i64 %t424, ptr %l35, !tbaa !24
  br label %bb94
bb100:
  call void @__olang_scope_close(ptr %s22)
  %t426 = load ptr, ptr %lp9
  %t427 = getelementptr %"compiler/build:Program", ptr %t426, i32 0, i32 2
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t430 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v8, ptr %s0, { i64, ptr } %t428, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t430, ptr %l221
  br label %bb101
bb101:
  %t431 = load i1, ptr %l221, !tbaa !21
  %t432 = xor i1 %t431, true
  br i1 %t432, label %bb102, label %bb103
bb102:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  %t435 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t436 = load ptr, ptr %l8, !tbaa !29
  %t440 = call i32 @compiler_2fcells_2elink(ptr %s0, ptr %v7, ptr %v8, ptr %l19, { i64, ptr } %t435, ptr %t436)
  store i32 %t440, ptr %l227
  %t441 = icmp ne i32 %t440, 0
  br i1 %t441, label %bb107, label %ok.442, !prof !99
ok.442:
  br label %bb106
bb106:
  br label %bb108
bb107:
  %t443 = load i32, ptr %l227, !tbaa !23
  %t444 = lshr i32 %t443, 16
  %t445 = and i32 %t443, 65535
  %t446 = icmp eq i32 %t444, 1
  %t447 = select i1 %t446, i32 1, i32 0
  %t448 = icmp eq i32 %t443, 0
  %t449 = shl i32 %t447, 16
  %t450 = or i32 %t449, %t445
  %t451 = select i1 %t448, i32 0, i32 %t450
  call void @__olang_scope_close(ptr %s0)
  store i32 %t451, ptr %rv
  br label %ret
bb108:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcells_2eCacheDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %s0, ptr %v0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store { i64, ptr } %t1, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcells_2eConfig(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/build:Config"
  %l2 = alloca %"compiler/build:Config"
  %l5 = alloca { i64, ptr }
  %l8 = alloca %"compiler/target:Target"
  %l9 = alloca %"compiler/target:Target"
  %l19 = alloca %"compiler/cond:Consts"
  %l21 = alloca %"compiler/cond:Consts"
  %l22 = alloca %"compiler/cond:Consts"
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca %"compiler/build:Config"
  %t1 = alloca %"compiler/build:Config", align 8
  %t62 = alloca %"compiler/cond:Consts", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t1, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %t1, i64 720, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %l2, i64 720, i1 false)
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 1
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t6 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t9 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t5, ptr %t9, !tbaa !27
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e1
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load { i64, ptr }, ptr %l5
  %t13 = extractvalue { i64, ptr } %t12, 1
  call void @__olang_region_release(ptr %t13)
  store { i64, ptr } zeroinitializer, ptr %l5
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/build:Config", ptr %t14, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t16, i64 152, i1 false)
  %t17 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %t17, i64 152, i1 false)
  %t18 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %l8, i64 152, i1 false)
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e0
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = getelementptr %"compiler/target:Target", ptr %l9, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  call void @__olang_region_release(ptr %t23)
  store { i64, ptr } zeroinitializer, ptr %t21
  br label %bb5
bb5:
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = getelementptr %"compiler/target:Target", ptr %l9, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26
  %t28 = extractvalue { i64, ptr } %t27, 1
  call void @__olang_region_release(ptr %t28)
  store { i64, ptr } zeroinitializer, ptr %t26
  br label %bb7
bb7:
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e2
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = getelementptr %"compiler/target:Target", ptr %l9, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31
  %t33 = extractvalue { i64, ptr } %t32, 1
  call void @__olang_region_release(ptr %t33)
  store { i64, ptr } zeroinitializer, ptr %t31
  br label %bb9
bb9:
  %t34 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e3
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = getelementptr %"compiler/target:Target", ptr %l9, i32 0, i32 3
  %t37 = load { i64, ptr }, ptr %t36
  %t38 = extractvalue { i64, ptr } %t37, 1
  call void @__olang_region_release(ptr %t38)
  store { i64, ptr } zeroinitializer, ptr %t36
  br label %bb11
bb11:
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e4
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = getelementptr %"compiler/target:Target", ptr %l9, i32 0, i32 4
  %t42 = load { i64, ptr }, ptr %t41
  %t43 = extractvalue { i64, ptr } %t42, 1
  call void @__olang_region_release(ptr %t43)
  store { i64, ptr } zeroinitializer, ptr %t41
  br label %bb13
bb13:
  %t44 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e5
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = getelementptr %"compiler/target:Target", ptr %l9, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46
  %t48 = extractvalue { i64, ptr } %t47, 1
  call void @__olang_region_release(ptr %t48)
  store { i64, ptr } zeroinitializer, ptr %t46
  br label %bb15
bb15:
  %t49 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e6
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t51 = getelementptr %"compiler/target:Target", ptr %l9, i32 0, i32 6
  %t52 = load { i64, ptr }, ptr %t51
  %t53 = extractvalue { i64, ptr } %t52, 1
  call void @__olang_region_release(ptr %t53)
  store { i64, ptr } zeroinitializer, ptr %t51
  br label %bb17
bb17:
  %t54 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e13
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = getelementptr %"compiler/target:Target", ptr %l9, i32 0, i32 13
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  call void @__olang_region_release(ptr %t58)
  store { i64, ptr } zeroinitializer, ptr %t56
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/build:Config", ptr %t59, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t61, i64 256, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcond_3aConsts(ptr %t62, ptr %v1, ptr %l19)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t62, i64 256, i1 false)
  br label %bb20
bb20:
  %t64 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t64, i64 256, i1 false)
  %t65 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %l21, i64 256, i1 false)
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e0
  br i1 %t66, label %bb21, label %bb22
bb21:
  %t68 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 0
  %t69 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t68, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = call ptr @__olang_region_or(ptr %t71, ptr null)
  %t73 = call ptr @__olang_region_home(ptr %t72)
  %t74 = icmp ne ptr %t73, null
  %t75 = select i1 %t74, ptr %t73, ptr null
  call void @__olang_region_drop(ptr %t75)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t68
  br label %bb22
bb22:
  %t76 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t76, label %bb23, label %bb24
bb23:
  %t78 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 0
  %t79 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t78, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  call void @__olang_region_release_part(ptr %t82, i64 %t81)
  store { i64, ptr } zeroinitializer, ptr %t79
  br label %bb24
bb24:
  %t83 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e2
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t85 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 2
  %t86 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t85, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = call ptr @__olang_region_or(ptr %t88, ptr null)
  %t90 = call ptr @__olang_region_home(ptr %t89)
  %t91 = icmp ne ptr %t90, null
  %t92 = select i1 %t91, ptr %t90, ptr null
  call void @__olang_region_drop(ptr %t92)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t85
  br label %bb26
bb26:
  %t93 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t93, label %bb27, label %bb28
bb27:
  %t95 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 2
  %t96 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t95, i32 0, i32 0
  %t97 = load { i64, ptr }, ptr %t96
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = extractvalue { i64, ptr } %t97, 1
  call void @__olang_region_release_part(ptr %t99, i64 %t98)
  store { i64, ptr } zeroinitializer, ptr %t96
  br label %bb28
bb28:
  %t100 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e3
  br i1 %t100, label %bb29, label %bb30
bb29:
  %t102 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 3
  %t103 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t102, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = call ptr @__olang_region_or(ptr %t105, ptr null)
  %t107 = call ptr @__olang_region_home(ptr %t106)
  %t108 = icmp ne ptr %t107, null
  %t109 = select i1 %t108, ptr %t107, ptr null
  call void @__olang_region_drop(ptr %t109)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t102
  br label %bb30
bb30:
  %t110 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 3
  %t113 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t112, i32 0, i32 0
  %t114 = load { i64, ptr }, ptr %t113
  %t115 = extractvalue { i64, ptr } %t114, 0
  %t116 = extractvalue { i64, ptr } %t114, 1
  call void @__olang_region_release_part(ptr %t116, i64 %t115)
  store { i64, ptr } zeroinitializer, ptr %t113
  br label %bb32
bb32:
  %t117 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e4
  br i1 %t117, label %bb33, label %bb34
bb33:
  %t119 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 4
  %t120 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t119, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = call ptr @__olang_region_or(ptr %t122, ptr null)
  %t124 = call ptr @__olang_region_home(ptr %t123)
  %t125 = icmp ne ptr %t124, null
  %t126 = select i1 %t125, ptr %t124, ptr null
  call void @__olang_region_drop(ptr %t126)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t119
  br label %bb34
bb34:
  %t127 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t127, label %bb35, label %bb36
bb35:
  %t129 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 4
  %t130 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t129, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  call void @__olang_region_release_part(ptr %t133, i64 %t132)
  store { i64, ptr } zeroinitializer, ptr %t130
  br label %bb36
bb36:
  %t134 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e5
  br i1 %t134, label %bb37, label %bb38
bb37:
  %t136 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 5
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t136, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = call ptr @__olang_region_or(ptr %t139, ptr null)
  %t141 = call ptr @__olang_region_home(ptr %t140)
  %t142 = icmp ne ptr %t141, null
  %t143 = select i1 %t142, ptr %t141, ptr null
  call void @__olang_region_drop(ptr %t143)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t136
  br label %bb38
bb38:
  %t144 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t144, label %bb39, label %bb40
bb39:
  %t146 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 5
  %t147 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t146, i32 0, i32 0
  %t148 = load { i64, ptr }, ptr %t147
  %t149 = extractvalue { i64, ptr } %t148, 0
  %t150 = extractvalue { i64, ptr } %t148, 1
  call void @__olang_region_release_part(ptr %t150, i64 %t149)
  store { i64, ptr } zeroinitializer, ptr %t147
  br label %bb40
bb40:
  %t151 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e6
  br i1 %t151, label %bb41, label %bb42
bb41:
  %t153 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 6
  %t154 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t153, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = call ptr @__olang_region_or(ptr %t156, ptr null)
  %t158 = call ptr @__olang_region_home(ptr %t157)
  %t159 = icmp ne ptr %t158, null
  %t160 = select i1 %t159, ptr %t158, ptr null
  call void @__olang_region_drop(ptr %t160)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t153
  br label %bb42
bb42:
  %t161 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t161, label %bb43, label %bb44
bb43:
  %t163 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 6
  %t164 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t163, i32 0, i32 0
  %t165 = load { i64, ptr }, ptr %t164
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = extractvalue { i64, ptr } %t165, 1
  call void @__olang_region_release_part(ptr %t167, i64 %t166)
  store { i64, ptr } zeroinitializer, ptr %t164
  br label %bb44
bb44:
  %t168 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e7
  br i1 %t168, label %bb45, label %bb46
bb45:
  %t170 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 7
  %t171 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t170, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = call ptr @__olang_region_or(ptr %t173, ptr null)
  %t175 = call ptr @__olang_region_home(ptr %t174)
  %t176 = icmp ne ptr %t175, null
  %t177 = select i1 %t176, ptr %t175, ptr null
  call void @__olang_region_drop(ptr %t177)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t170
  br label %bb46
bb46:
  %t178 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t178, label %bb47, label %bb48
bb47:
  %t180 = getelementptr %"compiler/cond:Consts", ptr %l22, i32 0, i32 7
  %t181 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t180, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  call void @__olang_region_release_part(ptr %t184, i64 %t183)
  store { i64, ptr } zeroinitializer, ptr %t181
  br label %bb48
bb48:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/build:Config", ptr %t185, i32 0, i32 24
  %t188 = load i1, ptr %t187, !tbaa !21
  %t190 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 24
  store i1 %t188, ptr %t190, !tbaa !21
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/build:Config", ptr %t191, i32 0, i32 31
  %t194 = load i64, ptr %t193, !tbaa !24
  %t196 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 31
  store i64 %t194, ptr %t196, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/build:Config", ptr %t197, i32 0, i32 5
  %t200 = load i1, ptr %t199, !tbaa !21
  %t202 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 5
  store i1 %t200, ptr %t202, !tbaa !21
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/build:Config", ptr %t203, i32 0, i32 26
  %t206 = load i1, ptr %t205, !tbaa !21
  %t208 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 26
  store i1 %t206, ptr %t208, !tbaa !21
  %t209 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 14
  store i1 true, ptr %t209, !tbaa !21
  %t210 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 33
  store i1 true, ptr %t210, !tbaa !21
  %t211 = call ptr @__olang_scope_hold(ptr %v1)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l45, !tbaa !24
  %t213 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e0
  br i1 %t213, label %bb49, label %bb50
bb49:
  %t215 = call ptr @__olang_region_make(ptr %v1)
  %t216 = ptrtoint ptr %t215 to i64
  store i64 %t216, ptr %l45, !tbaa !24
  br label %bb50
bb50:
  %t217 = load i64, ptr %l45
  %t218 = inttoptr i64 %t217 to ptr
  %t219 = call { i64, ptr } @compiler_2fcells_2eCacheDir(ptr %t218)
  store { i64, ptr } %t219, ptr %l47
  br label %bb51
bb51:
  %t220 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t221 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 0
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l49, !tbaa !27
  %t224 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t220, ptr %t224, !tbaa !27
  %t225 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e0
  br i1 %t225, label %bb52, label %bb53
bb52:
  %t227 = load { i64, ptr }, ptr %l49
  %t228 = extractvalue { i64, ptr } %t227, 1
  call void @__olang_region_release(ptr %t228)
  store { i64, ptr } zeroinitializer, ptr %l49
  br label %bb53
bb53:
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr %l1, i64 720, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l51, i64 720, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca [4096 x i8]
  %l4 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l31 = alloca i1
  %l34 = alloca i1
  %l37 = alloca [4096 x i8]
  %l41 = alloca [4096 x i8]
  %l44 = alloca i64
  %l52 = alloca i1
  %l54 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l69 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eRunning(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/cells:Worker", ptr %t7, i32 0, i32 3
  %t10 = load i32, ptr %t9, !tbaa !23
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t10, { i64, ptr } %t12)
  store i32 %t13, ptr %l9
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb6, label %ok.15, !prof !99
ok.15:
  br label %bb5
bb5:
  br label %bb10
bb6:
  %t16 = load i32, ptr %l9, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  store i1 %t19, ptr %l11, !tbaa !21
  %t20 = load i32, ptr %l9, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/cells:Worker", ptr %t25, i32 0, i32 3
  %t28 = load i32, ptr %t27, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t28)
  br label %bb11
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/cells:Worker", ptr %t30, i32 0, i32 3
  store i32 -1, ptr %t32, !tbaa !23
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/cells:Worker", ptr %t33, i32 0, i32 4
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp sge i32 %t36, 0
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb14:
  br label %bb15
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/cells:Worker", ptr %t42, i32 0, i32 4
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/cells:Worker", ptr %t46, i32 0, i32 5
  %t49 = load i32, ptr %t48, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/cells:Worker", ptr %t50, i32 0, i32 6
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = mul i64 3, 4
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 3, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l27, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 0
  store i32 %t45, ptr %t61, !tbaa !33
  %t63 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 1
  store i32 %t49, ptr %t65, !tbaa !33
  %t67 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i32, ptr %t68, i64 2
  store i32 %t53, ptr %t69, !tbaa !33
  %t70 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t71 = call { i64, ptr } @compiler_2fsession_2eReadable(ptr %s3, ptr %s3, { i64, ptr } %t70, i32 -1)
  store { i64, ptr } %t71, ptr %l28
  br label %bb16
bb16:
  %t72 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t72, ptr %l1, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i1, ptr %t74, i64 1
  %t76 = load i1, ptr %t75, !tbaa !31
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %t78, i64 1)
  store i1 %t80, ptr %l31
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t81 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i1, ptr %t82, i64 2
  %t84 = load i1, ptr %t83, !tbaa !31
  br i1 %t84, label %bb21, label %bb22
bb21:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %t86, i64 2)
  store i1 %t88, ptr %l34
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t89 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i1, ptr %t90, i64 0
  %t92 = load i1, ptr %t91, !tbaa !31
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb26:
  br label %bb27
bb27:
  br label %fill.99
fill.99:
  br label %fill.96
fill.96:
  %t100 = phi i64 [ 0, %fill.99 ], [ %t101, %fill.97 ]
  %t102 = icmp slt i64 %t100, 4096
  br i1 %t102, label %fill.97, label %fill.98
fill.97:
  %t103 = getelementptr [4096 x i8], ptr %l37, i64 0, i64 %t100
  store i8 0, ptr %t103
  %t101 = add i64 %t100, 1
  br label %fill.96
fill.98:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l37, i64 4096, i1 false)
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/cells:Worker", ptr %t104, i32 0, i32 4
  %t107 = load i32, ptr %t106, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %l41, ptr %l2, i64 4096, i1 false)
  %t108 = load [4096 x i8], ptr %l41
  %t113 = call i64 @read(i32 %t107, ptr %l2, i64 4096)
  store i64 %t113, ptr %l44
  br label %bb28
bb28:
  %t114 = load i64, ptr %l44, !tbaa !24
  %t115 = icmp sle i64 %t114, 0
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/cells:Worker", ptr %t117, i32 0, i32 4
  %t120 = load i32, ptr %t119, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t120)
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/cells:Worker", ptr %t122, i32 0, i32 4
  store i32 -1, ptr %t124, !tbaa !23
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb33:
  br label %bb12
bb34:
  br label %bb35
bb35:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/cells:Worker", ptr %t125, i32 0, i32 5
  %t128 = load i32, ptr %t127, !tbaa !23
  %t130 = icmp sge i32 %t128, 0
  br i1 %t130, label %bb36, label %bb37
bb36:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %t132, i64 1)
  store i1 %t134, ptr %l54
  br label %bb38
bb37:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb39
bb38:
  %t135 = load i1, ptr %l54, !tbaa !21
  store i1 %t135, ptr %l52, !tbaa !21
  br label %bb39
bb39:
  %t136 = load i1, ptr %l52, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb35
bb44:
  br label %bb45
bb45:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/cells:Worker", ptr %t139, i32 0, i32 6
  %t142 = load i32, ptr %t141, !tbaa !23
  %t144 = icmp sge i32 %t142, 0
  br i1 %t144, label %bb46, label %bb47
bb46:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %t146, i64 2)
  store i1 %t148, ptr %l61
  br label %bb48
bb47:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb49
bb48:
  %t149 = load i1, ptr %l61, !tbaa !21
  store i1 %t149, ptr %l59, !tbaa !21
  br label %bb49
bb49:
  %t150 = load i1, ptr %l59, !tbaa !21
  %t151 = xor i1 %t150, true
  br i1 %t151, label %bb50, label %bb51
bb50:
  br label %bb54
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb45
bb54:
  %t153 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eclose(ptr %v0, ptr %t153)
  br label %bb55
bb55:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/cells:Worker", ptr %t155, i32 0, i32 1
  %t158 = load i32, ptr %t157, !tbaa !23
  %t160 = icmp sgt i32 %t158, 0
  br i1 %t160, label %bb56, label %bb57
bb56:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/cells:Worker", ptr %t162, i32 0, i32 1
  %t165 = load i32, ptr %t164, !tbaa !23
  %t167 = call i32 @compiler_2fsession_2eReap(i32 %t165)
  store i32 %t167, ptr %l69
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/cells:Worker", ptr %t168, i32 0, i32 1
  store i32 -1, ptr %t170, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/cells:Outcome" @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eRun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2c, ptr %a2e) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { ptr, ptr }
  %l3 = alloca %"compiler/cells:Outcome"
  %l4 = alloca i1
  %l5 = alloca [3 x i32]
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/cells:Outcome"
  %l14 = alloca i32
  %l16 = alloca i1
  %l22 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i32
  %l65 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca i1
  %l73 = alloca i1
  %l78 = alloca i1
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca i1
  %l86 = alloca i1
  %l91 = alloca i1
  %l93 = alloca i32
  %l97 = alloca i32
  %l102 = alloca %"compiler/cells:Outcome"
  %l103 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca %"compiler/cells:Outcome"
  store ptr %a0, ptr %l0
  %pf2 = insertvalue { ptr, ptr } undef, ptr %a2c, 0
  %pg2 = insertvalue { ptr, ptr } %pf2, ptr %a2e, 1
  store { ptr, ptr } %pg2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/cells:Outcome" @compiler_2fcells_3aOutcome_2ector(ptr %v3)
  store %"compiler/cells:Outcome" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"compiler/cells:Outcome", ptr %l7
  store %"compiler/cells:Outcome" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/cells:Worker", ptr %t3, i32 0, i32 3
  %t6 = load i32, ptr %t5, !tbaa !23
  %t8 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t8, i64 %t9)
  %t18 = getelementptr i8, ptr %t17, i64 %t9
  call void @olang_textcopy(ptr %t18, ptr %t11, i64 %t12)
  %t19 = getelementptr i8, ptr %t18, i64 %t12
  call void @olang_textcopy(ptr %t19, ptr %t14, i64 %t15)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = extractvalue { i64, ptr } %t21, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t32 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t6, { i64, ptr } %t29)
  store i32 %t32, ptr %l14
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb3, label %ok.34, !prof !99
ok.34:
  br label %bb2
bb2:
  br label %bb8
bb3:
  %t35 = load i32, ptr %l14, !tbaa !23
  %t36 = ashr i32 %t35, 16
  %t38 = icmp eq i32 %t36, 1
  store i1 %t38, ptr %l16, !tbaa !21
  %t39 = load i32, ptr %l14, !tbaa !23
  %t40 = ashr i32 %t39, 16
  %t42 = icmp eq i32 %t40, 1
  br i1 %t42, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2elost(ptr %v0, ptr %v3, ptr %t44, ptr %l3)
  br label %bb7
bb7:
  %t47 = load %"compiler/cells:Outcome", ptr %l3
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cells:Outcome" %t47, ptr %rv
  br label %ret
bb8:
  %t49 = call i64 @signal(i32 2, i64 1)
  store i64 %t49, ptr %l22
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/cells:Worker", ptr %t50, i32 0, i32 2
  store i32 -1, ptr %t52, !tbaa !23
  store i1 false, ptr %l4, !tbaa !21
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/cells:Worker", ptr %t53, i32 0, i32 4
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/cells:Worker", ptr %t57, i32 0, i32 5
  %t60 = load i32, ptr %t59, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/cells:Worker", ptr %t61, i32 0, i32 6
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = insertvalue [3 x i32] undef, i32 %t56, 0
  %t68 = insertvalue [3 x i32] %t66, i32 %t60, 1
  %t70 = insertvalue [3 x i32] %t68, i32 %t64, 2
  store [3 x i32] %t70, ptr %l5
  %t73 = insertvalue { i64, ptr } undef, i64 3, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %l5, 1
  store { i64, ptr } %t74, ptr %l32, !tbaa !27
  %t75 = load { ptr, ptr }, ptr %l2
  %t77 = extractvalue { ptr, ptr } %t75, 0
  %t78 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t79 = icmp eq ptr %t77, %t78
  %t80 = extractvalue { ptr, ptr } %t75, 1
  %t81 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t82 = icmp eq ptr %t80, %t81
  %t83 = and i1 %t79, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb11, label %bb12
bb11:
  store i32 50, ptr %l36, !tbaa !23
  br label %bb13
bb12:
  store i32 -1, ptr %l36, !tbaa !23
  br label %bb13
bb13:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load i32, ptr %l36, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fsession_2eReadable(ptr %s3, ptr %s3, { i64, ptr } %t87, i32 %t88)
  store { i64, ptr } %t89, ptr %l37
  br label %bb14
bb14:
  %t90 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t90, ptr %l6, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i1, ptr %t92, i64 1
  %t94 = load i1, ptr %t93, !tbaa !31
  br i1 %t94, label %bb15, label %bb16
bb15:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %t96, i64 1)
  store i1 %t98, ptr %l40
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t99 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i1, ptr %t100, i64 2
  %t102 = load i1, ptr %t101, !tbaa !31
  br i1 %t102, label %bb19, label %bb20
bb19:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %t104, i64 2)
  store i1 %t106, ptr %l43
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t107 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i1, ptr %t108, i64 0
  %t110 = load i1, ptr %t109, !tbaa !31
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t112 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2etake(ptr %v0, ptr %v3, ptr %t112, ptr %l3)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t115 = getelementptr %"compiler/cells:Outcome", ptr %l3, i32 0, i32 7
  %t116 = load i1, ptr %t115, !tbaa !21
  br i1 %t116, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb28:
  br label %bb29
bb29:
  %t118 = load { ptr, ptr }, ptr %l2
  %t120 = extractvalue { ptr, ptr } %t118, 0
  %t121 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t122 = icmp eq ptr %t120, %t121
  %t123 = extractvalue { ptr, ptr } %t118, 1
  %t124 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t125 = icmp eq ptr %t123, %t124
  %t126 = and i1 %t122, %t125
  br i1 %t126, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb32
bb31:
  %t128 = load i1, ptr %l4, !tbaa !21
  store i1 %t128, ptr %l50, !tbaa !21
  br label %bb32
bb32:
  %t130 = load i1, ptr %l50, !tbaa !21
  br i1 %t130, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb35
bb34:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/cells:Worker", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %t133, !tbaa !23
  %t136 = icmp sle i32 %t134, 0
  store i1 %t136, ptr %l52, !tbaa !21
  br label %bb35
bb35:
  %t138 = load i1, ptr %l52, !tbaa !21
  br i1 %t138, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t139 = load { ptr, ptr }, ptr %l2
  %t141 = extractvalue { ptr, ptr } %t139, 0
  %t142 = extractvalue { ptr, ptr } %t139, 1
  %t143 = call i1 %t141(ptr %t142)
  store i1 %t143, ptr %l57
  br label %bb39
bb39:
  %t144 = load i1, ptr %l57, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/cells:Worker", ptr %t145, i32 0, i32 2
  %t148 = load i32, ptr %t147, !tbaa !23
  %t150 = call i32 @kill(i32 %t148, i32 9)
  store i32 %t150, ptr %l60
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb44:
  br label %bb10
bb45:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/cells:Worker", ptr %t151, i32 0, i32 2
  store i32 -1, ptr %t153, !tbaa !23
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/cells:Worker", ptr %t154, i32 0, i32 5
  %t157 = load i32, ptr %t156, !tbaa !23
  %t159 = icmp sge i32 %t157, 0
  br i1 %t159, label %bb47, label %bb48
bb47:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/cells:Worker", ptr %t161, i32 0, i32 5
  %t164 = load i32, ptr %t163, !tbaa !23
  %t165 = mul i64 1, 4
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %s10, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 1, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l68, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i32, ptr %t171, i64 0
  store i32 %t164, ptr %t172, !tbaa !33
  %t173 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t174 = call { i64, ptr } @compiler_2fsession_2eReadable(ptr %s10, ptr %s10, { i64, ptr } %t173, i32 0)
  store { i64, ptr } %t174, ptr %l69
  br label %bb49
bb48:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb50
bb49:
  %t175 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i1, ptr %t176, i64 0
  %t178 = load i1, ptr %t177, !tbaa !31
  store i1 %t178, ptr %l65, !tbaa !21
  br label %bb50
bb50:
  %t180 = load i1, ptr %l65, !tbaa !21
  br i1 %t180, label %bb51, label %bb52
bb51:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %t181, i64 1)
  store i1 %t183, ptr %l73
  br label %bb53
bb52:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb54
bb53:
  %t184 = load i1, ptr %l73, !tbaa !21
  store i1 %t184, ptr %l71, !tbaa !21
  br label %bb54
bb54:
  %t185 = load i1, ptr %l71, !tbaa !21
  %t186 = xor i1 %t185, true
  br i1 %t186, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb58:
  br label %bb46
bb59:
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/cells:Worker", ptr %t188, i32 0, i32 6
  %t191 = load i32, ptr %t190, !tbaa !23
  %t193 = icmp sge i32 %t191, 0
  br i1 %t193, label %bb61, label %bb62
bb61:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/cells:Worker", ptr %t195, i32 0, i32 6
  %t198 = load i32, ptr %t197, !tbaa !23
  %t199 = mul i64 1, 4
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %s11, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 1, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l81, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 0
  store i32 %t198, ptr %t206, !tbaa !33
  %t207 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t208 = call { i64, ptr } @compiler_2fsession_2eReadable(ptr %s11, ptr %s11, { i64, ptr } %t207, i32 0)
  store { i64, ptr } %t208, ptr %l82
  br label %bb63
bb62:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb64
bb63:
  %t209 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr i1, ptr %t210, i64 0
  %t212 = load i1, ptr %t211, !tbaa !31
  store i1 %t212, ptr %l78, !tbaa !21
  br label %bb64
bb64:
  %t214 = load i1, ptr %l78, !tbaa !21
  br i1 %t214, label %bb65, label %bb66
bb65:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %t215, i64 2)
  store i1 %t217, ptr %l86
  br label %bb67
bb66:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb68
bb67:
  %t218 = load i1, ptr %l86, !tbaa !21
  store i1 %t218, ptr %l84, !tbaa !21
  br label %bb68
bb68:
  %t219 = load i1, ptr %l84, !tbaa !21
  %t220 = xor i1 %t219, true
  br i1 %t220, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  br label %bb60
bb73:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/cells:Worker", ptr %t222, i32 0, i32 1
  %t225 = load i32, ptr %t224, !tbaa !23
  %t227 = icmp sgt i32 %t225, 0
  br i1 %t227, label %bb74, label %bb75
bb74:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/cells:Worker", ptr %t229, i32 0, i32 1
  %t232 = load i32, ptr %t231, !tbaa !23
  store i32 %t232, ptr %l93, !tbaa !23
  %t233 = icmp sge i64 1, 0
  br i1 %t233, label %bb76, label %bb77
bb75:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb81
bb76:
  %t235 = icmp sle i64 1, 2305843009213693951
  br i1 %t235, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_bd7f84bf0a6a1790_6aecdefa88c1aedc)
  unreachable
bb78:
  %t237 = mul i64 1, 4
  %t238 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t237)
  %t239 = insertvalue { i64, ptr } undef, i64 1, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t241 = load i32, ptr %l93, !tbaa !23
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = extractvalue { i64, ptr } %t240, 0
  %t245 = call i32 @waitpid(i32 %t241, ptr %t243, i32 1)
  store i32 %t245, ptr %l97
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_bd7f84bf0a6a1790_6aecdefa88c1aedc)
  unreachable
bb80:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/cells:Worker", ptr %t246, i32 0, i32 1
  %t249 = load i32, ptr %t248, !tbaa !23
  %t250 = load i32, ptr %l97, !tbaa !23
  %t252 = icmp eq i32 %t250, %t249
  store i1 %t252, ptr %l91, !tbaa !21
  br label %bb81
bb81:
  %t254 = load i1, ptr %l91, !tbaa !21
  br i1 %t254, label %bb82, label %bb83
bb82:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/cells:Worker", ptr %t255, i32 0, i32 1
  store i32 0, ptr %t257, !tbaa !23
  br label %bb84
bb83:
  br label %bb84
bb84:
  %t258 = load %"compiler/cells:Outcome", ptr %l3
  store %"compiler/cells:Outcome" %t258, ptr %l102
  %t259 = call i64 @signal(i32 2, i64 0)
  store i64 %t259, ptr %l103
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t260 = load %"compiler/cells:Outcome", ptr %l102
  store %"compiler/cells:Outcome" %t260, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cells:Outcome", ptr %rv
  ret %"compiler/cells:Outcome" %rr
}

define dso_local { i64, ptr } @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eStart(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i32, i32 }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i32, i32 }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i32, i32 }
  %l16 = alloca { i32, i32 }
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l25 = alloca [1 x { i64, ptr }]
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca %"compiler/diag:Diagnostics"
  %l32 = alloca %"compiler/build:Config"
  %l34 = alloca %"compiler/build:Config"
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l41 = alloca i1
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i32, i32 }
  %l50 = alloca { i32, i32 }
  %l55 = alloca { i32, i32 }
  %l58 = alloca { i32, i32 }
  %l61 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca i64
  %l102 = alloca i32
  %l111 = alloca i32
  %l113 = alloca i1
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t1 = alloca %"compiler/diag:Diagnostics", align 8
  %t6 = alloca %"compiler/build:Config", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t1, ptr %v1, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t1, i64 704, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 704, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l30, i64 704, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %a1, i64 720, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbuild_3aConfig(ptr %t6, ptr %v1, ptr %l32)
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t6, i64 720, i1 false)
  br label %bb2
bb2:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 720, i64 8)
  store ptr %t8, ptr %lp3
  %t9 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t9, ptr %l34, i64 720, i1 false)
  %t10 = load ptr, ptr %lp3
  %t11 = getelementptr %"compiler/build:Config", ptr %t10, i32 0, i32 14
  store i1 false, ptr %t11, !tbaa !21
  %t12 = load ptr, ptr %lp3
  %t13 = load ptr, ptr %lp2
  %t16 = call { i32, { i64, ptr } } @compiler_2fcells_2eworkerExe(ptr %v1, ptr %v1, ptr %s0, ptr %t12, ptr %t13)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l39
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20, !prof !99
ok.20:
  store { i64, ptr } %t17, ptr %l38
  br label %bb3
bb3:
  %t21 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t21, ptr %l35, !tbaa !27
  br label %bb8
bb4:
  %t22 = load i32, ptr %l39, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  store i1 %t25, ptr %l41, !tbaa !21
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %lp2
  %t28 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v1, ptr %s1, ptr %t26)
  store { i64, ptr } %t28, ptr %l43
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t31 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s1, ptr %s1, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l45
  br label %bb7
bb7:
  %t32 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t34 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t32, i64 %t33)
  %t39 = getelementptr i8, ptr %t38, i64 %t33
  call void @olang_textcopy(ptr %t39, ptr %t35, i64 %t36)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb8:
  %t43 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t43, ptr %l4, !tbaa !27
  call void @compiler_2fsession_2eIgnoreBrokenPipes()
  br label %bb9
bb9:
  %t44 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t44, ptr %l47
  br label %bb10
bb10:
  %t45 = load { i32, i32 }, ptr %l47
  store { i32, i32 } %t45, ptr %l5
  %t46 = getelementptr { i32, i32 }, ptr %l5, i32 0, i32 0
  %t47 = load i32, ptr %t46, !tbaa !23
  store i32 %t47, ptr %l6, !tbaa !23
  %t49 = getelementptr { i32, i32 }, ptr %l5, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  store i32 %t50, ptr %l7, !tbaa !23
  %t52 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t52, ptr %l50
  br label %bb11
bb11:
  %t53 = load { i32, i32 }, ptr %l50
  store { i32, i32 } %t53, ptr %l8
  %t54 = getelementptr { i32, i32 }, ptr %l8, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  %t57 = getelementptr { i32, i32 }, ptr %l8, i32 0, i32 1
  %t58 = load i32, ptr %t57, !tbaa !23
  store i32 %t58, ptr %l10, !tbaa !23
  store i32 -1, ptr %l11, !tbaa !23
  store i32 -1, ptr %l12, !tbaa !23
  store i32 -1, ptr %l13, !tbaa !23
  store i32 -1, ptr %l14, !tbaa !23
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/cells:Worker", ptr %t60, i32 0, i32 0
  %t63 = load i1, ptr %t62, !tbaa !21
  br i1 %t63, label %bb12, label %bb13
bb12:
  %t65 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t65, ptr %l55
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t66 = load { i32, i32 }, ptr %l55
  store { i32, i32 } %t66, ptr %l15
  %t67 = getelementptr { i32, i32 }, ptr %l15, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  store i32 %t68, ptr %l11, !tbaa !23
  %t70 = getelementptr { i32, i32 }, ptr %l15, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  store i32 %t71, ptr %l12, !tbaa !23
  %t73 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t73, ptr %l58
  br label %bb15
bb15:
  %t74 = load { i32, i32 }, ptr %l58
  store { i32, i32 } %t74, ptr %l16
  %t75 = getelementptr { i32, i32 }, ptr %l16, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  store i32 %t76, ptr %l13, !tbaa !23
  %t78 = getelementptr { i32, i32 }, ptr %l16, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  store i32 %t79, ptr %l14, !tbaa !23
  br label %bb16
bb16:
  %t81 = call i32 @compiler_2fsession_2eFork()
  store i32 %t81, ptr %l61
  br label %bb17
bb17:
  %t82 = load i32, ptr %l61, !tbaa !23
  store i32 %t82, ptr %l17, !tbaa !23
  %t83 = load i32, ptr %l17, !tbaa !23
  %t85 = icmp slt i32 %t83, 0
  br i1 %t85, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t87, ptr %l65, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l66, !tbaa !24
  %t90 = load i64, ptr %l66, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l67, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l66, !tbaa !24
  %t100 = mul i64 %t99, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %t98, i64 %t100, i1 false)
  %t101 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t101, ptr %l65, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t102 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t102, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t103 = load i32, ptr %l17, !tbaa !23
  %t105 = icmp eq i32 %t103, 0
  br i1 %t105, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fsession_2eDup2(i32 %t107, i32 100)
  br label %bb23
bb22:
  br label %bb52
bb23:
  %t109 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fsession_2eDup2(i32 %t109, i32 101)
  br label %bb24
bb24:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/cells:Worker", ptr %t111, i32 0, i32 0
  %t114 = load i1, ptr %t113, !tbaa !21
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t116 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2fsession_2eDup2(i32 %t116, i32 1)
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t118 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fsession_2eDup2(i32 %t118, i32 2)
  br label %bb28
bb28:
  br label %bb29
bb29:
  call void @compiler_2fsession_2eDup2(i32 100, i32 3)
  br label %bb30
bb30:
  call void @compiler_2fsession_2eDup2(i32 101, i32 4)
  br label %bb31
bb31:
  store i64 5, ptr %l18, !tbaa !24
  store i64 1024, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t120 = load i64, ptr %l19, !tbaa !24
  %t121 = load i64, ptr %l18, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb32, label %bb33
bb32:
  %t126 = load i64, ptr %l20, !tbaa !24
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb37
bb34:
  %t130 = load i64, ptr %l19, !tbaa !24
  %t131 = load i64, ptr %l18, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i64, ptr %l20, !tbaa !24
  %t138 = add i64 %t134, %t135
  %t140 = sub i64 %t138, 1
  %t141 = load i64, ptr %l20, !tbaa !24
  %t144 = sdiv i64 %t140, %t141
  store i64 %t144, ptr %l82, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb36
bb36:
  %t146 = load i64, ptr %l82, !tbaa !24
  store i64 %t146, ptr %l79, !tbaa !24
  br label %bb37
bb37:
  %t147 = load i64, ptr %l79, !tbaa !24
  store i64 %t147, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb38
bb38:
  %t148 = load i64, ptr %l22, !tbaa !24
  %t149 = load i64, ptr %l21, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t156 = load i64, ptr %l18, !tbaa !24
  %t157 = load i64, ptr %l22, !tbaa !24
  %t158 = load i64, ptr %l20, !tbaa !24
  %t161 = mul i64 %t157, %t158
  %t164 = add i64 %t156, %t161
  %t168 = trunc i64 %t164 to i32
  %t170 = call i32 @close(i32 %t168)
  store i32 %t170, ptr %l102
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t171 = load i64, ptr %l22, !tbaa !24
  %t174 = add i64 %t171, 1
  store i64 %t174, ptr %l22, !tbaa !24
  br label %bb38
bb44:
  %t176 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t178 = insertvalue [1 x { i64, ptr }] undef, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  store [1 x { i64, ptr }] %t178, ptr %l25
  %t182 = insertvalue { i64, ptr } undef, i64 1, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %l25, 1
  %t186 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s5, { i64, ptr } %t176, { i64, ptr } %t183)
  store i32 %t186, ptr %l111
  %t187 = icmp ne i32 %t186, 0
  br i1 %t187, label %bb46, label %ok.188, !prof !99
ok.188:
  br label %bb45
bb45:
  br label %bb50
bb46:
  %t189 = load i32, ptr %l111, !tbaa !23
  %t190 = ashr i32 %t189, 16
  %t192 = icmp eq i32 %t190, 1
  store i1 %t192, ptr %l113, !tbaa !21
  %t193 = load i32, ptr %l111, !tbaa !23
  %t194 = ashr i32 %t193, 16
  %t196 = icmp eq i32 %t194, 1
  br i1 %t196, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  call void @compiler_2fsession_2eExit(i32 127)
  unreachable
bb51:
  call void @__olang_check_failed(ptr @olang_loc_9bfba30e0b79067c_c7b40212ef9fcad0)
  unreachable
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t198 = load i32, ptr %l6, !tbaa !23
  %t199 = load i32, ptr %l10, !tbaa !23
  %t200 = load i32, ptr %l12, !tbaa !23
  %t201 = load i32, ptr %l14, !tbaa !23
  %t203 = insertvalue [4 x i32] undef, i32 %t198, 0
  %t205 = insertvalue [4 x i32] %t203, i32 %t199, 1
  %t207 = insertvalue [4 x i32] %t205, i32 %t200, 2
  %t209 = insertvalue [4 x i32] %t207, i32 %t201, 3
  %t211 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 16, i64 8)
  store [4 x i32] %t209, ptr %t211
  store ptr %t211, ptr %l26
  store i64 0, ptr %l27, !tbaa !24
  %t213 = load ptr, ptr %l26
  store i64 4, ptr %l28, !tbaa !24
  br label %bb53
bb53:
  %t216 = load i64, ptr %l27, !tbaa !24
  %t217 = load i64, ptr %l28, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb54, label %bb55
bb54:
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t224 = load ptr, ptr %l26
  %t225 = load i64, ptr %l27, !tbaa !24
  %t228 = getelementptr [4 x i32], ptr %t224, i64 0, i64 %t225
  %t229 = load i32, ptr %t228, !tbaa !33
  call void @compiler_2fsession_2eCloseFd(i32 %t229)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t233 = load i64, ptr %l27, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l27, !tbaa !24
  br label %bb53
bb59:
  call void @__olang_scope_close(ptr %s11)
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i32, ptr %l17, !tbaa !23
  %t242 = getelementptr %"compiler/cells:Worker", ptr %t238, i32 0, i32 1
  store i32 %t239, ptr %t242, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l7, !tbaa !23
  %t247 = getelementptr %"compiler/cells:Worker", ptr %t243, i32 0, i32 3
  store i32 %t244, ptr %t247, !tbaa !23
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l9, !tbaa !23
  %t252 = getelementptr %"compiler/cells:Worker", ptr %t248, i32 0, i32 4
  store i32 %t249, ptr %t252, !tbaa !23
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load i32, ptr %l11, !tbaa !23
  %t257 = getelementptr %"compiler/cells:Worker", ptr %t253, i32 0, i32 5
  store i32 %t254, ptr %t257, !tbaa !23
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l13, !tbaa !23
  %t262 = getelementptr %"compiler/cells:Worker", ptr %t258, i32 0, i32 6
  store i32 %t259, ptr %t262, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l145, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t263, ptr %l146, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  store i64 %t265, ptr %l147, !tbaa !24
  %t266 = load i64, ptr %l147, !tbaa !24
  %t267 = mul i64 %t266, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t267)
  %t269 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  store { i64, ptr } %t270, ptr %l148, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = load i64, ptr %l147, !tbaa !24
  %t276 = mul i64 %t275, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t272, ptr %t274, i64 %t276, i1 false)
  %t277 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t277, ptr %l146, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t278 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t278, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2edrop(ptr %v0, ptr noalias dereferenceable(64) align 8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l39 = alloca ptr
  %l42 = alloca i64
  %l46 = alloca i8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cells:Worker", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l20, !tbaa !24
  store i64 %t37, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l17, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/cells:Worker", ptr %t57, i32 0, i32 8
  store ptr %t59, ptr %l39, !tbaa !29
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = sub i64 %t60, %t61
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/cells:Worker", ptr %t65, i32 0, i32 8
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t67, i64 %t68)
  store i8 %t71, ptr %l46
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i8, ptr %l46, !tbaa !22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %t72, i64 %t73, i8 %t74)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l7, !tbaa !24
  br label %bb8
bb15:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/cells:Worker", ptr %t80, i32 0, i32 8
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = sub i64 %t83, %t84
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eTruncate_3cU8_3e(ptr %v0, ptr %t82, i64 %t87)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2etake(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca [65536 x i8]
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca [65536 x i8]
  %l12 = alloca [65536 x i8]
  %l15 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l34 = alloca { i64, ptr }
  %l39 = alloca i64
  %l41 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 65536
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [65536 x i8], ptr %l8, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l8, i64 65536, i1 false)
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/cells:Worker", ptr %t9, i32 0, i32 4
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l2, i64 65536, i1 false)
  %t13 = load [65536 x i8], ptr %l12
  %t18 = call i64 @read(i32 %t12, ptr %l2, i64 65536)
  store i64 %t18, ptr %l15
  br label %bb1
bb1:
  %t19 = load i64, ptr %l15, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sle i64 %t20, 0
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2elost(ptr %v0, ptr %v1, ptr %t24, ptr %t25)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/cells:Worker", ptr %t28, i32 0, i32 8
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l22, !tbaa !24
  %t32 = load [65536 x i8], ptr %l2
  store i64 65536, ptr %l23, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c055f97e3313c422_daca2fce6a780a3e)
  unreachable
bb8:
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = load i64, ptr %l23, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c055f97e3313c422_daca2fce6a780a3e)
  unreachable
bb10:
  %t42 = load i64, ptr %l22, !tbaa !24
  %t43 = getelementptr i8, ptr %l2, i64 0
  %t44 = sub i64 %t42, 0
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePushAll_3cU8_3e(ptr %v0, ptr %s0, ptr %t47, { i64, ptr } %t46)
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c055f97e3313c422_daca2fce6a780a3e)
  unreachable
bb12:
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/cells:Outcome", ptr %t49, i32 0, i32 7
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = xor i1 %t52, true
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb15:
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/cells:Worker", ptr %t58, i32 0, i32 8
  %t62 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v0, ptr %t60)
  store { i64, ptr } %t62, ptr %l34
  br label %bb17
bb17:
  %t63 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t63, ptr %l4, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp slt i64 %t66, 16
  br i1 %t68, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t72 = call i64 @compiler_2fcells_2eword(ptr %v0, { i64, ptr } %t70, i64 0)
  store i64 %t72, ptr %l39
  br label %bb21
bb21:
  %t73 = load i64, ptr %l39, !tbaa !24
  store i64 %t73, ptr %l5, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t76 = call i64 @compiler_2fcells_2eword(ptr %v0, { i64, ptr } %t74, i64 8)
  store i64 %t76, ptr %l41
  br label %bb22
bb22:
  %t77 = load i64, ptr %l41, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 16, %t81
  %t86 = icmp slt i64 %t80, %t83
  br i1 %t86, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  br label %bb25
bb25:
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t88, ptr %l47, !tbaa !27
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = add i64 16, %t89
  store i64 %t91, ptr %l49, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l50, !tbaa !24
  %t94 = icmp sge i64 16, 0
  br i1 %t94, label %bb26, label %bb27
bb26:
  %t96 = load i64, ptr %l49, !tbaa !24
  %t97 = icmp sle i64 16, %t96
  br i1 %t97, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_dcdbbf63e25e519f_c5c2eacce8fd1bbb)
  unreachable
bb28:
  %t99 = load i64, ptr %l49, !tbaa !24
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_dcdbbf63e25e519f_c5c2eacce8fd1bbb)
  unreachable
bb30:
  %t103 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = getelementptr i8, ptr %t104, i64 16
  %t107 = sub i64 %t105, 16
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  store { i64, ptr } %t109, ptr %l55, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l56, !tbaa !24
  %t113 = load i64, ptr %l56, !tbaa !24
  %t114 = mul i64 %t113, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l57, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l56, !tbaa !24
  %t123 = mul i64 %t122, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %t121, i64 %t123, i1 false)
  %t124 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = extractvalue { i64, ptr } %t124, 0
  %t128 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t127)
  call void @olang_textcopy(ptr %t128, ptr %t126, i64 %t127)
  %t129 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t131, ptr %lp7
  %t133 = load ptr, ptr %lp7
  store { i64, ptr } %t130, ptr %t133, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 16, %t135
  call void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2edrop(ptr %v0, ptr %t134, i64 %t137)
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_dcdbbf63e25e519f_c5c2eacce8fd1bbb)
  unreachable
bb32:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t141 = load i64, ptr %l5, !tbaa !24
  %t142 = load ptr, ptr %lp7
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t144 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcells_2eframe(ptr %v1, ptr %v1, ptr %v0, ptr %t140, i64 %t141, { i64, ptr } %t143, ptr %t144)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  br label %bb13
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcells_2edropped(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t7, ptr %l7
  br label %bb4
bb4:
  %t8 = load i1, ptr %l7, !tbaa !21
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t13, ptr %l10
  br label %bb9
bb9:
  %t14 = load i1, ptr %l10, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb13
bb11:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb12
bb12:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb13
bb13:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = sub i64 %t28, 2
  store i64 %t30, ptr %l20, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = icmp sge i64 13, 0
  br i1 %t33, label %bb17, label %bb18
bb17:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = icmp sle i64 13, %t35
  br i1 %t36, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_616551f0a3546013_1249d7bcaf39212f)
  unreachable
bb19:
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_616551f0a3546013_1249d7bcaf39212f)
  unreachable
bb21:
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = getelementptr i8, ptr %t43, i64 13
  %t46 = sub i64 %t44, 13
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  %t52 = getelementptr %"compiler/cells:Plan", ptr %a1, i32 0, i32 2
  %t56 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v1, ptr %v0, ptr %t52, { i64, ptr } %t48)
  store i1 %t56, ptr %l29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_616551f0a3546013_1249d7bcaf39212f)
  unreachable
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i1, ptr %l29, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcells_2eframe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i32
  %l19 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i64
  %l48 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l61 = alloca i1
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2fcells_2eFramePid, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %a3, ptr %l7, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l9, !tbaa !27
  %t9 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 10)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l10
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v1, { i64, ptr } %t14, i64 %t15)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l13
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb7, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l12
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb8
bb6:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb8
bb7:
  br label %bb5
bb8:
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = trunc i64 %t22 to i32
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = getelementptr %"compiler/cells:Worker", ptr %t25, i32 0, i32 2
  store i32 %t23, ptr %t26, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t27 = load i64, ptr %l1, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2fcells_2eFrameShown, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/cells:Outcome", ptr %t33, i32 0, i32 0
  store i1 true, ptr %t35, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l19, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = getelementptr %"compiler/cells:Outcome", ptr %t38, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l21, !tbaa !27
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = getelementptr %"compiler/cells:Outcome", ptr %t42, i32 0, i32 1
  store { i64, ptr } %t37, ptr %t43, !tbaa !27
  %t44 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aOutcome_2e1
  br i1 %t44, label %bb12, label %bb13
bb11:
  br label %bb14
bb12:
  %t46 = load { i64, ptr }, ptr %l21
  %t47 = extractvalue { i64, ptr } %t46, 1
  call void @__olang_region_release(ptr %t47)
  store { i64, ptr } zeroinitializer, ptr %l21
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t48 = load i64, ptr %l1, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2fcells_2eFrameMime, !tbaa !24
  %t52 = icmp eq i64 %t48, %t49
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l26, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = getelementptr %"compiler/cells:Outcome", ptr %t56, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l28, !tbaa !27
  %t60 = load ptr, ptr %l26, !tbaa !29
  %t61 = getelementptr %"compiler/cells:Outcome", ptr %t60, i32 0, i32 2
  store { i64, ptr } %t55, ptr %t61, !tbaa !27
  %t62 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aOutcome_2e2
  br i1 %t62, label %bb17, label %bb18
bb16:
  br label %bb19
bb17:
  %t64 = load { i64, ptr }, ptr %l28
  %t65 = extractvalue { i64, ptr } %t64, 1
  call void @__olang_region_release(ptr %t65)
  store { i64, ptr } zeroinitializer, ptr %l28
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t66 = load i64, ptr %l1, !tbaa !24
  %t67 = load i64, ptr @G_2ecompiler_2fcells_2eFrameData, !tbaa !24
  %t70 = icmp eq i64 %t66, %t67
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l33, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t74 = load ptr, ptr %l33, !tbaa !29
  %t75 = getelementptr %"compiler/cells:Outcome", ptr %t74, i32 0, i32 3
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l35, !tbaa !27
  %t78 = load ptr, ptr %l33, !tbaa !29
  %t79 = getelementptr %"compiler/cells:Outcome", ptr %t78, i32 0, i32 3
  store { i64, ptr } %t73, ptr %t79, !tbaa !27
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aOutcome_2e3
  br i1 %t80, label %bb22, label %bb23
bb21:
  br label %bb24
bb22:
  %t82 = load { i64, ptr }, ptr %l35
  %t83 = extractvalue { i64, ptr } %t82, 1
  call void @__olang_region_release(ptr %t83)
  store { i64, ptr } zeroinitializer, ptr %l35
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load i64, ptr @G_2ecompiler_2fcells_2eFrameFailure, !tbaa !24
  %t88 = icmp eq i64 %t84, %t85
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l40, !tbaa !29
  %t91 = call ptr @__olang_scope_hold(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l41, !tbaa !24
  %t93 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aOutcome_2e4
  br i1 %t93, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  %t95 = call ptr @__olang_region_make(ptr %v0)
  %t96 = ptrtoint ptr %t95 to i64
  store i64 %t96, ptr %l41, !tbaa !24
  br label %bb28
bb28:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/cells:Outcome", ptr %t97, i32 0, i32 4
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = extractvalue { i64, ptr } %t100, 0
  %t106 = extractvalue { i64, ptr } %t101, 1
  %t107 = extractvalue { i64, ptr } %t101, 0
  %t108 = add i64 %t104, %t107
  %t109 = load i64, ptr %l41
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = call ptr @__olang_held_alloc(ptr %t110, i64 %t108)
  call void @olang_textcopy(ptr %t111, ptr %t103, i64 %t104)
  %t112 = getelementptr i8, ptr %t111, i64 %t104
  call void @olang_textcopy(ptr %t112, ptr %t106, i64 %t107)
  %t113 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = load ptr, ptr %l40, !tbaa !29
  %t117 = getelementptr %"compiler/cells:Outcome", ptr %t116, i32 0, i32 4
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l48, !tbaa !27
  %t120 = load ptr, ptr %l40, !tbaa !29
  %t121 = getelementptr %"compiler/cells:Outcome", ptr %t120, i32 0, i32 4
  store { i64, ptr } %t114, ptr %t121, !tbaa !27
  %t122 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aOutcome_2e4
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t124 = load { i64, ptr }, ptr %l48
  %t125 = extractvalue { i64, ptr } %t124, 1
  call void @__olang_region_release(ptr %t125)
  store { i64, ptr } zeroinitializer, ptr %l48
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t126 = load i64, ptr %l1, !tbaa !24
  %t127 = load i64, ptr @G_2ecompiler_2fcells_2eFrameStopped, !tbaa !24
  %t130 = icmp eq i64 %t126, %t127
  br i1 %t130, label %bb32, label %bb33
bb32:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l53, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t134 = load ptr, ptr %l53, !tbaa !29
  %t135 = getelementptr %"compiler/cells:Outcome", ptr %t134, i32 0, i32 5
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l55, !tbaa !27
  %t138 = load ptr, ptr %l53, !tbaa !29
  %t139 = getelementptr %"compiler/cells:Outcome", ptr %t138, i32 0, i32 5
  store { i64, ptr } %t133, ptr %t139, !tbaa !27
  %t140 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aOutcome_2e5
  br i1 %t140, label %bb34, label %bb35
bb33:
  br label %bb36
bb34:
  %t142 = load { i64, ptr }, ptr %l55
  %t143 = extractvalue { i64, ptr } %t142, 1
  call void @__olang_region_release(ptr %t143)
  store { i64, ptr } zeroinitializer, ptr %l55
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l57, !tbaa !29
  %t145 = load i64, ptr %l1, !tbaa !24
  %t146 = load i64, ptr @G_2ecompiler_2fcells_2eFrameDone, !tbaa !24
  %t149 = icmp eq i64 %t145, %t146
  br i1 %t149, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb39
bb38:
  %t151 = load i64, ptr %l1, !tbaa !24
  %t152 = load i64, ptr @G_2ecompiler_2fcells_2eFrameStopped, !tbaa !24
  %t155 = icmp eq i64 %t151, %t152
  store i1 %t155, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t157 = load i1, ptr %l61, !tbaa !21
  %t158 = load ptr, ptr %l57, !tbaa !29
  %t159 = getelementptr %"compiler/cells:Outcome", ptr %t158, i32 0, i32 7
  store i1 %t157, ptr %t159, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcells_2erenamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l22 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H17e0a6412004f84451bdf7ff6c816e10(ptr %v2, ptr %t1)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t11 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t7, { i64, ptr } %t10)
  store i1 %t11, ptr %l13
  br label %bb4
bb4:
  %t12 = load i1, ptr %l13, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t16, { i64, ptr } %t17)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t26 = icmp slt i64 %t20, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t30, ptr %l22, !tbaa !27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i8, ptr %t34, i64 %t31
  %t36 = load i8, ptr %t35, !tbaa !32
  store i8 %t36, ptr %l4, !tbaa !22
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i8, ptr %l4, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t38, i8 %t39)
  br label %bb14
bb14:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l3, !tbaa !24
  %t47 = load i8, ptr %l4, !tbaa !22
  %t49 = icmp ne i8 %t47, 64
  br i1 %t49, label %bb15, label %bb16
bb15:
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = call { i64, ptr } @compiler_2fcells_2esymbolAt(ptr %v1, ptr %v1, { i64, ptr } %t51, i64 %t52)
  store { i64, ptr } %t55, ptr %l34
  br label %bb18
bb18:
  %t56 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t56, ptr %l5, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l35, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v2, ptr %v1, ptr %v2, ptr %t58, { i64, ptr } %t59)
  %t63 = extractvalue { i32, { i64, ptr } } %t62, 1
  %t64 = extractvalue { i32, { i64, ptr } } %t62, 0
  store i32 %t64, ptr %l40
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb20, label %ok.66, !prof !99
ok.66:
  store { i64, ptr } %t63, ptr %l39
  br label %bb19
bb19:
  %t67 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t67, ptr %l36, !tbaa !27
  br label %bb22
bb20:
  br label %bb21
bb21:
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l36, !tbaa !27
  br label %bb22
bb22:
  %t70 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = call ptr @__olang_scope_of(ptr %t71, ptr null)
  %t73 = call ptr @__olang_scope_hold(ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l35, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %t76, ptr %t77, { i64, ptr } %t78)
  br label %bb23
bb23:
  %t79 = load i64, ptr %l3, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t85 = add i64 %t79, %t82
  store i64 %t85, ptr %l3, !tbaa !24
  br label %bb24
bb24:
  br label %bb10
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcells_2erewrite(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca %"std/prelude/text:LineIter"
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l16 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l10
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l10
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l4)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l14
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l13
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l14, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb7:
  %t18 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t21, ptr %l18
  br label %bb8
bb8:
  %t22 = load i1, ptr %l18, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb10:
  br label %bb11
bb11:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t23, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t25, ptr %l20
  br label %bb12
bb12:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb16:
  %t28 = load i1, ptr %l3, !tbaa !21
  br i1 %t28, label %bb17, label %bb18
bb17:
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t30, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t32, ptr %l25
  br label %bb19
bb18:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb20
bb19:
  %t33 = load i1, ptr %l25, !tbaa !21
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb20
bb20:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb21, label %bb22
bb21:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t35 = load i1, ptr %l3, !tbaa !21
  br i1 %t35, label %bb24, label %bb25
bb24:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t41 = call i1 @compiler_2fcells_2edropped(ptr %v0, ptr %v1, { i64, ptr } %t37, ptr %t38)
  store i1 %t41, ptr %l30
  br label %bb26
bb25:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb27
bb26:
  %t42 = load i1, ptr %l30, !tbaa !21
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb27
bb27:
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb29:
  br label %bb30
bb30:
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t44, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t46, ptr %l32
  br label %bb31
bb31:
  %t47 = load i1, ptr %l32, !tbaa !21
  br i1 %t47, label %bb32, label %bb33
bb32:
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = call { i64, ptr } @compiler_2fcells_2esymbolAt(ptr %v0, ptr %v0, { i64, ptr } %t48, i64 1)
  store { i64, ptr } %t50, ptr %l34
  br label %bb34
bb33:
  br label %bb45
bb34:
  %t51 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t51, ptr %l6, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/cells:Plan", ptr %t54, i32 0, i32 1
  %t60 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v1, ptr %v0, ptr %t56, { i64, ptr } %t52)
  store i1 %t60, ptr %l39
  br label %bb35
bb35:
  %t61 = load i1, ptr %l39, !tbaa !21
  br i1 %t61, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l2, ptr %l40, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/cells:Plan", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v1, ptr %v0, ptr %s8, ptr %t64, { i64, ptr } %t65)
  %t69 = extractvalue { i32, { i64, ptr } } %t68, 1
  %t70 = extractvalue { i32, { i64, ptr } } %t68, 0
  store i32 %t70, ptr %l46
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb39, label %ok.72, !prof !99
ok.72:
  store { i64, ptr } %t69, ptr %l45
  br label %bb38
bb37:
  br label %bb44
bb38:
  %t73 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t73, ptr %l41, !tbaa !27
  br label %bb42
bb39:
  %t74 = load i32, ptr %l46, !tbaa !23
  %t75 = icmp eq i32 %t74, 65536
  br i1 %t75, label %bb40, label %bb41
bb40:
  call void @__olang_bang_failed_plain(ptr @olang_loc_20926c2b81d0e00c_7d8ac19a57247f8)
  unreachable
bb41:
  call void @__olang_bang_failed_plain(ptr @olang_loc_948f6b52a35541f0_f4572f553ac6bc74)
  unreachable
bb42:
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t79 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t77, i64 %t78)
  %t87 = getelementptr i8, ptr %t86, i64 %t78
  call void @olang_textcopy(ptr %t87, ptr %t80, i64 %t81)
  %t88 = getelementptr i8, ptr %t87, i64 %t81
  call void @olang_textcopy(ptr %t88, ptr %t83, i64 %t84)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  %t92 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t92, { i64, ptr } %t90)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/cells:Plan", ptr %t95, i32 0, i32 0
  call void @compiler_2fcells_2erenamed(ptr %s0, ptr %v0, ptr %v1, ptr %l2, { i64, ptr } %t94, ptr %t97)
  br label %bb46
bb46:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  br label %bb3
bb49:
  %t103 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t103, ptr %l56
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t104 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcells_2eword(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i1
  %l39 = alloca { i64, ptr }
  %l46 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t1 = load i64, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l15, !tbaa !24
  store i64 %t27, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l12, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = sub i64 %t29, 1
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t31, 2147483648
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  %t37 = and i1 %t32, %t34
  store i1 %t37, ptr %l27, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l2, !tbaa !24
  store { i64, ptr } %a0, ptr %l39, !tbaa !27
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %a1, %t60
  %t65 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i8, ptr %t66, i64 %t63
  %t68 = load i8, ptr %t67, !tbaa !32
  %t70 = zext i8 %t68 to i64
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = mul i64 8, %t71
  store i64 %t73, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l46, !tbaa !24
  %t76 = load i64, ptr %l46, !tbaa !24
  %t77 = shl i64 %t70, %t76
  %t80 = or i64 %t56, %t77
  store i64 %t80, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb7
bb12:
  %t87 = load i64, ptr %l2, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcells_2eworkerExe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca i32
  %l36 = alloca i1
  %l40 = alloca %"compiler/build:Program"
  %l47 = alloca %"compiler/build:Config"
  %l49 = alloca %"compiler/build:Config"
  %l64 = alloca i32
  %l67 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i64
  %l79 = alloca %"compiler/build:Unit"
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca i32
  %l87 = alloca %"std/prelude/text:StringBuilder"
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l117 = alloca i64
  %l119 = alloca i64
  %l124 = alloca { i64, ptr }
  %l130 = alloca i1
  %l139 = alloca { i64, ptr }
  %l140 = alloca i32
  %l142 = alloca i1
  %l146 = alloca { i64, ptr }
  %l147 = alloca i32
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l154 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l156 = alloca i64
  %l158 = alloca i64
  %l163 = alloca { i64, ptr }
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca { i64, ptr }
  %l187 = alloca i64
  %l189 = alloca i64
  %l194 = alloca { i64, ptr }
  %l200 = alloca i64
  %l222 = alloca i1
  %l228 = alloca i32
  %l232 = alloca i32
  %l234 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t20 = alloca %"compiler/build:Program", align 8
  %t48 = alloca %"compiler/build:Config", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t4)
  store i32 %t6, ptr %l34
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t9 = load i32, ptr %l34, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l36, !tbaa !21
  %t13 = load i32, ptr %l34, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
bb6:
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t20, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t20, i64 280, i1 false)
  br label %bb7
bb7:
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 280, i64 8)
  store ptr %t21, ptr %lp2
  %t22 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %l40, i64 280, i1 false)
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/build:Config", ptr %t23, i32 0, i32 0
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 1
  %t29 = extractvalue { i64, ptr } %t26, 0
  %t30 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t28, i64 %t29)
  %t34 = getelementptr i8, ptr %t33, i64 %t29
  call void @olang_textcopy(ptr %t34, ptr %t30, i64 %t31)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t37, ptr %lp3
  %t39 = load ptr, ptr %lp3
  store { i64, ptr } %t36, ptr %t39, !tbaa !27
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 0, i64 8)
  store ptr %t40, ptr %lp4
  %t42 = load ptr, ptr %lp4
  store [0 x { i64, ptr }] zeroinitializer, ptr %t42
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 0, i64 8)
  store ptr %t43, ptr %lp5
  %t45 = load ptr, ptr %lp5
  store [0 x i64] zeroinitializer, ptr %t45
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t46, i64 720, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbuild_3aConfig(ptr %t48, ptr %v0, ptr %l47)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t48, i64 720, i1 false)
  br label %bb8
bb8:
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 720, i64 8)
  store ptr %t50, ptr %lp6
  %t51 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %l49, i64 720, i1 false)
  %t52 = load { ptr, ptr }, ptr @G_2ecompiler_2fcells_2eBuilder
  %t54 = extractvalue { ptr, ptr } %t52, 0
  %t55 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t56 = icmp eq ptr %t54, %t55
  %t57 = extractvalue { ptr, ptr } %t52, 1
  %t58 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t59 = icmp eq ptr %t57, %t58
  %t60 = and i1 %t56, %t59
  br i1 %t60, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f955eaf1a3bf6405_1ec27af45d1f4ca9)
  unreachable
bb10:
  br label %bb11
bb11:
  %t62 = load { ptr, ptr }, ptr @G_2ecompiler_2fcells_2eBuilder
  %t63 = load ptr, ptr %lp3
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t65 = load { i64, ptr }, ptr @G_2ecompiler_2fcells_2eWorkerSource, !tbaa !27
  %t66 = load ptr, ptr %lp4
  %t68 = insertvalue { i64, ptr } undef, i64 0, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t66, 1
  %t70 = load ptr, ptr %lp4
  %t72 = insertvalue { i64, ptr } undef, i64 0, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  %t74 = load ptr, ptr %lp5
  %t76 = insertvalue { i64, ptr } undef, i64 0, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t74, 1
  %t78 = load ptr, ptr %lp6
  %t79 = load ptr, ptr %lp2
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = extractvalue { ptr, ptr } %t62, 0
  %t83 = extractvalue { ptr, ptr } %t62, 1
  %t84 = load ptr, ptr @__olang_prog_scope
  %t93 = call i32 %t82(ptr %t83, ptr %v0, ptr %t84, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %t64, { i64, ptr } %t65, { i64, ptr } %t69, { i64, ptr } %t73, { i64, ptr } %t77, ptr %t78, ptr %t79, ptr %t80)
  store i32 %t93, ptr %l64
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb13, label %ok.95, !prof !99
ok.95:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t96 = load i32, ptr %l64, !tbaa !23
  %t97 = lshr i32 %t96, 16
  %t98 = and i32 %t96, 65535
  %t99 = icmp eq i32 %t97, 1
  %t100 = select i1 %t99, i32 1, i32 0
  %t101 = icmp eq i32 %t96, 0
  %t102 = shl i32 %t100, 16
  %t103 = or i32 %t102, %t98
  %t104 = select i1 %t101, i32 0, i32 %t103
  call void @__olang_scope_close(ptr %s0)
  %t106 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t104, 0
  store { i32, { i64, ptr } } %t106, ptr %rv
  br label %ret
bb14:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t107)
  store i64 %t109, ptr %l67
  br label %bb15
bb15:
  %t110 = load i64, ptr %l67, !tbaa !24
  %t111 = icmp sgt i64 %t110, 0
  br i1 %t111, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t114 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t114, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t115 = load ptr, ptr %lp2
  %t116 = getelementptr %"compiler/build:Program", ptr %t115, i32 0, i32 0
  store ptr %t116, ptr %l70, !tbaa !29
  store i32 0, ptr %l71
  %t117 = call ptr @__olang_scope_hold(ptr %v1)
  %t118 = ptrtoint ptr %t117 to i64
  store i64 %t118, ptr %l72, !tbaa !24
  %t119 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aUnit_2e2
  br i1 %t119, label %bb19, label %bb20
bb19:
  %t121 = call ptr @__olang_region_make(ptr %v1)
  %t122 = ptrtoint ptr %t121 to i64
  store i64 %t122, ptr %l72, !tbaa !24
  br label %bb20
bb20:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/build:Config", ptr %t123, i32 0, i32 2
  %t126 = getelementptr %"compiler/target:Target", ptr %t125, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t128 = load { i64, ptr }, ptr @G_2ecompiler_2fcells_2eHelperIr, !tbaa !27
  %t129 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t132 = extractvalue { i64, ptr } %t127, 1
  %t133 = extractvalue { i64, ptr } %t127, 0
  %t134 = add i64 %t130, %t133
  %t135 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t139 = extractvalue { i64, ptr } %t128, 1
  %t140 = extractvalue { i64, ptr } %t128, 0
  %t141 = add i64 %t137, %t140
  %t142 = load i64, ptr %l72
  %t143 = inttoptr i64 %t142 to ptr
  %t144 = call ptr @__olang_held_alloc(ptr %t143, i64 %t141)
  call void @olang_textcopy(ptr %t144, ptr %t129, i64 %t130)
  %t145 = getelementptr i8, ptr %t144, i64 %t130
  call void @olang_textcopy(ptr %t145, ptr %t132, i64 %t133)
  %t146 = getelementptr i8, ptr %t145, i64 %t133
  call void @olang_textcopy(ptr %t146, ptr %t135, i64 %t136)
  %t147 = getelementptr i8, ptr %t146, i64 %t136
  call void @olang_textcopy(ptr %t147, ptr %t139, i64 %t140)
  %t148 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t144, 1
  %t151 = load i32, ptr %l71, !range !{i32 0, i32 5}
  %t153 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d38, i32 0, i32 1) }, i32 %t151, { i64, ptr } %t149)
  store %"compiler/build:Unit" %t153, ptr %l79
  br label %bb21
bb21:
  %t154 = load ptr, ptr %l70, !tbaa !29
  %t155 = load %"compiler/build:Unit", ptr %l79
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t154, %"compiler/build:Unit" %t155)
  br label %bb22
bb22:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %lp2
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t162 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t156, ptr %t157, ptr %t158)
  %t163 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t162, 1
  %t164 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t162, 0
  store i32 %t164, ptr %l85
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb24, label %ok.166, !prof !99
ok.166:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l84
  br label %bb23
bb23:
  %t167 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %l80
  br label %bb25
bb24:
  %t168 = load i32, ptr %l85, !tbaa !23
  %t169 = lshr i32 %t168, 16
  %t170 = and i32 %t168, 65535
  %t171 = icmp eq i32 %t169, 1
  %t172 = select i1 %t171, i32 1, i32 0
  %t173 = icmp eq i32 %t168, 0
  %t174 = shl i32 %t172, 16
  %t175 = or i32 %t174, %t170
  %t176 = select i1 %t173, i32 0, i32 %t175
  call void @__olang_scope_close(ptr %s0)
  %t178 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t176, 0
  store { i32, { i64, ptr } } %t178, ptr %rv
  br label %ret
bb25:
  %t179 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %l7
  %t180 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t180, ptr %l87
  br label %bb26
bb26:
  %t181 = load %"std/prelude/text:StringBuilder", ptr %l87
  store %"std/prelude/text:StringBuilder" %t181, ptr %l8
  store ptr %l7, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t183 = load i64, ptr %l10, !tbaa !24
  store i64 %t183, ptr %l89, !tbaa !24
  %t184 = load ptr, ptr %l9, !tbaa !29
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t184)
  store i64 %t186, ptr %l91
  br label %bb28
bb28:
  %t187 = load i64, ptr %l89, !tbaa !24
  %t188 = load i64, ptr %l91, !tbaa !24
  %t189 = icmp slt i64 %t187, %t188
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb30:
  br label %bb31
bb31:
  %t193 = load ptr, ptr %l9, !tbaa !29
  %t194 = load i64, ptr %l10, !tbaa !24
  %t197 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t193, i64 %t194)
  store { i64, ptr } %t197, ptr %l96
  br label %bb32
bb32:
  %t198 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t198, 1
  %t202 = extractvalue { i64, ptr } %t198, 0
  %t203 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t205 = add i64 %t202, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t201, i64 %t202)
  %t207 = getelementptr i8, ptr %t206, i64 %t202
  call void @olang_textcopy(ptr %t207, ptr %t203, i64 %t204)
  %t208 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l8, { i64, ptr } %t209)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t213 = load i64, ptr %l10, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l10, !tbaa !24
  br label %bb27
bb35:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/build:Config", ptr %t218, i32 0, i32 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l105, !tbaa !27
  %t223 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t223, ptr %l107
  br label %bb36
bb36:
  %t224 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t226 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %s0, ptr %s0, { i64, ptr } %t224)
  store { i64, ptr } %t226, ptr %l109
  br label %bb37
bb37:
  %t227 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  store i64 %t228, ptr %l110, !tbaa !24
  %t229 = icmp sge i64 0, 0
  br i1 %t229, label %bb38, label %bb39
bb38:
  %t231 = icmp sle i64 0, 16
  br i1 %t231, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_848145de22f96d6_67a3d2054bf098fa)
  unreachable
bb40:
  %t233 = load i64, ptr %l110, !tbaa !24
  %t234 = icmp sle i64 16, %t233
  br i1 %t234, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_848145de22f96d6_67a3d2054bf098fa)
  unreachable
bb42:
  %t236 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i8, ptr %t237, i64 0
  %t239 = sub i64 16, 0
  %t240 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t242 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t247 = add i64 %t244, %t246
  %t249 = extractvalue { i64, ptr } %t241, 1
  %t250 = extractvalue { i64, ptr } %t241, 0
  %t251 = add i64 %t247, %t250
  %t252 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t243, i64 %t244)
  %t253 = getelementptr i8, ptr %t252, i64 %t244
  call void @olang_textcopy(ptr %t253, ptr %t245, i64 %t246)
  %t254 = getelementptr i8, ptr %t253, i64 %t246
  call void @olang_textcopy(ptr %t254, ptr %t249, i64 %t250)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t252, 1
  %t257 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t257, ptr %lp12
  %t259 = load ptr, ptr %lp12
  store { i64, ptr } %t256, ptr %t259, !tbaa !27
  store ptr %l7, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_848145de22f96d6_67a3d2054bf098fa)
  unreachable
bb44:
  %t261 = load i64, ptr %l14, !tbaa !24
  store i64 %t261, ptr %l117, !tbaa !24
  %t262 = load ptr, ptr %l13, !tbaa !29
  %t264 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t262)
  store i64 %t264, ptr %l119
  br label %bb45
bb45:
  %t265 = load i64, ptr %l117, !tbaa !24
  %t266 = load i64, ptr %l119, !tbaa !24
  %t267 = icmp slt i64 %t265, %t266
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  br label %bb48
bb48:
  %t271 = load ptr, ptr %l13, !tbaa !29
  %t272 = load i64, ptr %l14, !tbaa !24
  %t275 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t271, i64 %t272)
  store { i64, ptr } %t275, ptr %l124
  br label %bb49
bb49:
  %t276 = load { i64, ptr }, ptr %l124, !tbaa !27
  call void @compiler_2fbuild_2eTouch(ptr %v1, { i64, ptr } %t276)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t279 = load i64, ptr %l14, !tbaa !24
  %t282 = add i64 %t279, 1
  store i64 %t282, ptr %l14, !tbaa !24
  br label %bb44
bb52:
  %t284 = load ptr, ptr %lp12
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t287 = call i1 @std_2fos_2eExists(ptr %v2, { i64, ptr } %t285)
  store i1 %t287, ptr %l130
  br label %bb53
bb53:
  %t288 = load i1, ptr %l130, !tbaa !21
  br i1 %t288, label %bb54, label %bb55
bb54:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/build:Config", ptr %t289, i32 0, i32 0
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  %t293 = load ptr, ptr %lp12
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  %t295 = load i64, ptr @G_2ecompiler_2fcells_2eCellsCacheCap, !tbaa !24
  call void @compiler_2fbuild_2ePrune(ptr %v0, ptr %v2, { i64, ptr } %t292, { i64, ptr } %t294, i64 %t295)
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t299 = load ptr, ptr %lp12
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t302 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t300, 1
  store { i32, { i64, ptr } } %t302, ptr %rv
  br label %ret
bb57:
  %t303 = load ptr, ptr %lp12
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 1
  %t307 = extractvalue { i64, ptr } %t304, 0
  %t308 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t311 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t310)
  call void @olang_textcopy(ptr %t311, ptr %t306, i64 %t307)
  %t312 = getelementptr i8, ptr %t311, i64 %t307
  call void @olang_textcopy(ptr %t312, ptr %t308, i64 %t309)
  %t313 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t311, 1
  store { i64, ptr } %t314, ptr %l16, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l139, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t319 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t316, { i64, ptr } %t318)
  store i32 %t319, ptr %l140
  %t320 = icmp ne i32 %t319, 0
  br i1 %t320, label %bb59, label %ok.321, !prof !99
ok.321:
  br label %bb58
bb58:
  br label %bb63
bb59:
  %t322 = load i32, ptr %l140, !tbaa !23
  %t323 = ashr i32 %t322, 16
  %t325 = icmp eq i32 %t323, 1
  store i1 %t325, ptr %l142, !tbaa !21
  %t326 = load i32, ptr %l140, !tbaa !23
  %t327 = ashr i32 %t326, 16
  %t329 = icmp eq i32 %t327, 1
  br i1 %t329, label %bb60, label %bb61
bb60:
  call void @__olang_errpay_pop()
  br label %bb61
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  %t332 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t332, ptr %rv
  br label %ret
bb63:
  %t333 = load ptr, ptr %lp12
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  store { i64, ptr } %t334, ptr %l146, !tbaa !27
  %t335 = call i32 @getpid()
  store i32 %t335, ptr %l147
  br label %bb64
bb64:
  %t336 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t342 = load i32, ptr %l147, !tbaa !23
  %t343 = sext i32 %t342 to i64
  %t344 = call i64 @__olang_fmt_i64(ptr null, i64 %t343)
  %t345 = add i64 %t341, %t344
  %t346 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t345)
  call void @olang_textcopy(ptr %t346, ptr %t337, i64 %t338)
  %t347 = getelementptr i8, ptr %t346, i64 %t338
  call void @olang_textcopy(ptr %t347, ptr %t339, i64 %t340)
  %t348 = getelementptr i8, ptr %t347, i64 %t340
  %t349 = call i64 @__olang_fmt_i64(ptr %t348, i64 %t343)
  %t350 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t346, 1
  store { i64, ptr } %t351, ptr %l17, !tbaa !27
  %t353 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t353, ptr %l149
  br label %bb65
bb65:
  %t354 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t354, ptr %l18
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/build:Config", ptr %t355, i32 0, i32 1
  %t358 = load { i64, ptr }, ptr %t357, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l18, { i64, ptr } %t358)
  br label %bb66
bb66:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s0, ptr %t361)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t363, ptr %l154
  br label %bb67
bb67:
  %t364 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l154
  %t365 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t364, ptr %t365
  store ptr %t365, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb68
bb68:
  %t367 = load i64, ptr %l20, !tbaa !24
  store i64 %t367, ptr %l156, !tbaa !24
  %t368 = load ptr, ptr %l19, !tbaa !29
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t368)
  store i64 %t370, ptr %l158
  br label %bb69
bb69:
  %t371 = load i64, ptr %l156, !tbaa !24
  %t372 = load i64, ptr %l158, !tbaa !24
  %t373 = icmp slt i64 %t371, %t372
  %t375 = xor i1 %t373, true
  br i1 %t375, label %bb70, label %bb71
bb70:
  br label %bb76
bb71:
  br label %bb72
bb72:
  %t377 = load ptr, ptr %l19, !tbaa !29
  %t378 = load i64, ptr %l20, !tbaa !24
  %t381 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t377, i64 %t378)
  store { i64, ptr } %t381, ptr %l163
  br label %bb73
bb73:
  %t382 = load { i64, ptr }, ptr %l163, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } %t382)
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t386 = load i64, ptr %l20, !tbaa !24
  %t389 = add i64 %t386, 1
  store i64 %t389, ptr %l20, !tbaa !24
  br label %bb68
bb76:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb77
bb77:
  %t392 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } %t392)
  br label %bb78
bb78:
  store ptr %l7, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb79
bb79:
  %t396 = load i64, ptr %l23, !tbaa !24
  store i64 %t396, ptr %l173, !tbaa !24
  %t397 = load ptr, ptr %l22, !tbaa !29
  %t399 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t397)
  store i64 %t399, ptr %l175
  br label %bb80
bb80:
  %t400 = load i64, ptr %l173, !tbaa !24
  %t401 = load i64, ptr %l175, !tbaa !24
  %t402 = icmp slt i64 %t400, %t401
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb81, label %bb82
bb81:
  br label %bb87
bb82:
  br label %bb83
bb83:
  %t406 = load ptr, ptr %l22, !tbaa !29
  %t407 = load i64, ptr %l23, !tbaa !24
  %t410 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t406, i64 %t407)
  store { i64, ptr } %t410, ptr %l180
  br label %bb84
bb84:
  %t411 = load { i64, ptr }, ptr %l180, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l18, { i64, ptr } %t411)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t415 = load i64, ptr %l23, !tbaa !24
  %t418 = add i64 %t415, 1
  store i64 %t418, ptr %l23, !tbaa !24
  br label %bb79
bb87:
  %t420 = load ptr, ptr %lp2
  %t421 = getelementptr %"compiler/build:Program", ptr %t420, i32 0, i32 3
  store ptr %t421, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb88
bb88:
  %t423 = load i64, ptr %l26, !tbaa !24
  store i64 %t423, ptr %l187, !tbaa !24
  %t424 = load ptr, ptr %l25, !tbaa !29
  %t426 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t424)
  store i64 %t426, ptr %l189
  br label %bb89
bb89:
  %t427 = load i64, ptr %l187, !tbaa !24
  %t428 = load i64, ptr %l189, !tbaa !24
  %t429 = icmp slt i64 %t427, %t428
  %t431 = xor i1 %t429, true
  br i1 %t431, label %bb90, label %bb91
bb90:
  br label %bb96
bb91:
  br label %bb92
bb92:
  %t433 = load ptr, ptr %l25, !tbaa !29
  %t434 = load i64, ptr %l26, !tbaa !24
  %t437 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t433, i64 %t434)
  store { i64, ptr } %t437, ptr %l194
  br label %bb93
bb93:
  %t438 = load { i64, ptr }, ptr %l194, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l18, { i64, ptr } %t438)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t442 = load i64, ptr %l26, !tbaa !24
  %t445 = add i64 %t442, 1
  store i64 %t445, ptr %l26, !tbaa !24
  br label %bb88
bb96:
  %t447 = call ptr @__olang_scope_hold(ptr %s0)
  %t448 = ptrtoint ptr %t447 to i64
  store i64 %t448, ptr %l200, !tbaa !24
  %t449 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_204_3e_2e_2d1
  br i1 %t449, label %bb97, label %bb98
bb97:
  %t451 = call ptr @__olang_region_make(ptr %s0)
  %t452 = ptrtoint ptr %t451 to i64
  store i64 %t452, ptr %l200, !tbaa !24
  br label %bb98
bb98:
  %t453 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t454 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t455 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t457 = extractvalue { i64, ptr } %t453, 1
  %t458 = extractvalue { i64, ptr } %t453, 0
  %t459 = add i64 %t455, %t458
  %t460 = load i64, ptr %l200
  %t461 = inttoptr i64 %t460 to ptr
  %t462 = call ptr @__olang_held_alloc(ptr %t461, i64 %t459)
  call void @olang_textcopy(ptr %t462, ptr %t454, i64 %t455)
  %t463 = getelementptr i8, ptr %t462, i64 %t455
  call void @olang_textcopy(ptr %t463, ptr %t457, i64 %t458)
  %t464 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t462, 1
  %t468 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } %t465, 0
  %t469 = insertvalue [4 x { i64, ptr }] %t468, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t470 = insertvalue [4 x { i64, ptr }] %t469, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d47, i32 0, i32 1) }, 2
  %t471 = insertvalue [4 x { i64, ptr }] %t470, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, 3
  %t473 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 64, i64 8)
  store [4 x { i64, ptr }] %t471, ptr %t473
  store ptr %t473, ptr %l28
  store i64 0, ptr %l29, !tbaa !24
  %t475 = load ptr, ptr %l28
  store i64 4, ptr %l30, !tbaa !24
  br label %bb99
bb99:
  %t478 = load i64, ptr %l29, !tbaa !24
  %t479 = load i64, ptr %l30, !tbaa !24
  %t482 = icmp slt i64 %t478, %t479
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb100, label %bb101
bb100:
  br label %bb105
bb101:
  br label %bb102
bb102:
  %t486 = load ptr, ptr %l28
  %t487 = load i64, ptr %l29, !tbaa !24
  %t490 = getelementptr [4 x { i64, ptr }], ptr %t486, i64 0, i64 %t487
  %t491 = load { i64, ptr }, ptr %t490, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } %t491)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t496 = load i64, ptr %l29, !tbaa !24
  %t499 = add i64 %t496, 1
  store i64 %t499, ptr %l29, !tbaa !24
  br label %bb99
bb105:
  %t501 = load ptr, ptr %lp2
  %t502 = getelementptr %"compiler/build:Program", ptr %t501, i32 0, i32 2
  %t503 = load { i64, ptr }, ptr %t502, !tbaa !27
  %t505 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t503, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t505, ptr %l222
  br label %bb106
bb106:
  %t506 = load i1, ptr %l222, !tbaa !21
  %t507 = xor i1 %t506, true
  br i1 %t507, label %bb107, label %bb108
bb107:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb110
bb110:
  %t510 = load ptr, ptr %lp12
  %t511 = load { i64, ptr }, ptr %t510, !tbaa !27
  %t512 = load ptr, ptr %l1, !tbaa !29
  %t516 = call i32 @compiler_2fcells_2elink(ptr %s0, ptr %v2, ptr %v1, ptr %l18, { i64, ptr } %t511, ptr %t512)
  store i32 %t516, ptr %l228
  %t517 = icmp ne i32 %t516, 0
  br i1 %t517, label %bb112, label %ok.518, !prof !99
ok.518:
  br label %bb111
bb111:
  br label %bb113
bb112:
  %t519 = load i32, ptr %l228, !tbaa !23
  %t520 = lshr i32 %t519, 16
  %t521 = and i32 %t519, 65535
  %t522 = icmp eq i32 %t520, 1
  %t523 = select i1 %t522, i32 1, i32 0
  %t524 = icmp eq i32 %t519, 0
  %t525 = shl i32 %t523, 16
  %t526 = or i32 %t525, %t521
  %t527 = select i1 %t524, i32 0, i32 %t526
  call void @__olang_scope_close(ptr %s0)
  %t529 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t527, 0
  store { i32, { i64, ptr } } %t529, ptr %rv
  br label %ret
bb113:
  %t530 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t531 = load ptr, ptr %lp12
  %t532 = load { i64, ptr }, ptr %t531, !tbaa !27
  %t535 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v2, { i64, ptr } %t530, { i64, ptr } %t532)
  store i32 %t535, ptr %l232
  %t536 = icmp ne i32 %t535, 0
  br i1 %t536, label %bb115, label %ok.537, !prof !99
ok.537:
  br label %bb114
bb114:
  br label %bb119
bb115:
  %t538 = load i32, ptr %l232, !tbaa !23
  %t539 = ashr i32 %t538, 16
  %t541 = icmp eq i32 %t539, 1
  store i1 %t541, ptr %l234, !tbaa !21
  %t542 = load i32, ptr %l232, !tbaa !23
  %t543 = ashr i32 %t542, 16
  %t545 = icmp eq i32 %t543, 1
  br i1 %t545, label %bb116, label %bb117
bb116:
  call void @__olang_errpay_pop()
  br label %bb117
bb117:
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s0)
  %t548 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t548, ptr %rv
  br label %ret
bb119:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/build:Config", ptr %t549, i32 0, i32 0
  %t552 = load { i64, ptr }, ptr %t551, !tbaa !27
  %t553 = load ptr, ptr %lp12
  %t554 = load { i64, ptr }, ptr %t553, !tbaa !27
  %t555 = load i64, ptr @G_2ecompiler_2fcells_2eCellsCacheCap, !tbaa !24
  call void @compiler_2fbuild_2ePrune(ptr %v0, ptr %v2, { i64, ptr } %t552, { i64, ptr } %t554, i64 %t555)
  br label %bb120
bb120:
  %t559 = load ptr, ptr %lp12
  %t560 = load { i64, ptr }, ptr %t559, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t562 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t560, 1
  store { i32, { i64, ptr } } %t562, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"compiler/cells:Outcome" @compiler_2fcells_3aOutcome_2ector(ptr %v0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca %"compiler/cells:Outcome"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t2 = insertvalue %"compiler/cells:Outcome" undef, i1 false, 0
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = insertvalue %"compiler/cells:Outcome" %t2, { i64, ptr } %t3, 1
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = insertvalue %"compiler/cells:Outcome" %t4, { i64, ptr } %t5, 2
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = insertvalue %"compiler/cells:Outcome" %t6, { i64, ptr } %t7, 3
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = insertvalue %"compiler/cells:Outcome" %t8, { i64, ptr } %t9, 4
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = insertvalue %"compiler/cells:Outcome" %t10, { i64, ptr } %t11, 5
  %t14 = insertvalue %"compiler/cells:Outcome" %t12, i1 false, 6
  %t16 = insertvalue %"compiler/cells:Outcome" %t14, i1 false, 7
  store %"compiler/cells:Outcome" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cells:Outcome", ptr %rv
  ret %"compiler/cells:Outcome" %rr
}

define dso_local void @compiler_2fcells_3aPlan_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"compiler/cells:Plan"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aPlan_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %t8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aPlan_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l3
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 2
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  %t21 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = call ptr @__olang_region_home(ptr %t24)
  %t26 = icmp ne ptr %t25, null
  %t27 = select i1 %t26, ptr %t25, ptr %t20
  %t28 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = call ptr @__olang_region_or(ptr %t30, ptr null)
  %t32 = call ptr @__olang_region_home(ptr %t31)
  %t33 = icmp ne ptr %t32, null
  %t34 = select i1 %t33, ptr %t32, ptr %t27
  call void @__olang_region_settle_in(ptr %t13, ptr %t34)
  br label %bb5
bb5:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l0
  %t36 = call ptr @__olang_scope_hold(ptr %v0)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l7, !tbaa !24
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aPlan_2e1
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t40 = call ptr @__olang_region_make(ptr %v0)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l7
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t43)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t44, ptr %l9
  br label %bb8
bb8:
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aPlan_2e1
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l7
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = call ptr @__olang_region_or(ptr %t51, ptr null)
  %t53 = call ptr @__olang_region_home(ptr %t52)
  %t54 = icmp ne ptr %t53, null
  %t55 = select i1 %t54, ptr %t53, ptr null
  %t56 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr %t55
  %t63 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr %t62
  call void @__olang_region_settle_in(ptr %t48, ptr %t69)
  br label %bb10
bb10:
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %l1
  %t71 = call ptr @__olang_scope_hold(ptr %v0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l11, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aPlan_2e2
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t75 = call ptr @__olang_region_make(ptr %v0)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t77 = load i64, ptr %l11
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t78)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t79, ptr %l13
  br label %bb13
bb13:
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aPlan_2e2
  br i1 %t80, label %bb14, label %bb15
bb14:
  %t82 = load i64, ptr %l11
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 2
  %t85 = load { i64, ptr }, ptr %t84
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = call ptr @__olang_region_or(ptr %t86, ptr null)
  %t88 = call ptr @__olang_region_home(ptr %t87)
  %t89 = icmp ne ptr %t88, null
  %t90 = select i1 %t89, ptr %t88, ptr null
  %t91 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr %t90
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr %t97
  call void @__olang_region_settle_in(ptr %t83, ptr %t104)
  br label %bb15
bb15:
  %t105 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  %t106 = getelementptr %"compiler/cells:Plan", ptr %l15, i32 0, i32 0
  %t107 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t107, ptr %t106
  %t108 = getelementptr %"compiler/cells:Plan", ptr %l15, i32 0, i32 1
  %t109 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t109, ptr %t108
  %t110 = getelementptr %"compiler/cells:Plan", ptr %l15, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t105, ptr %t110
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l15, i64 216, i1 false)
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbuild_3aConfig(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Config"
  %l3 = alloca %"compiler/cond:Consts"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t3 = alloca %"compiler/cond:Consts", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 720, i1 false)
  %t2 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 3
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcond_3aConsts(ptr %t3, ptr %v0, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %t3, i64 256, i1 false)
  br label %bb1
bb1:
  %t5 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l3, i64 256, i1 false)
  %t6 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 28
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  br label %bb2
bb2:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t10 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %t10
  %t11 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 30
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t11)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l7
  br label %bb3
bb3:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t15 = getelementptr %"compiler/build:Config", ptr %l1, i32 0, i32 30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t15
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 720, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fbuild_3aUnit_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @__olang_region_release(ptr) noinline
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aUnit_2e3 = weak hidden constant i1 false
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aProgram_2e1 = weak hidden constant i1 false
declare void @__olang_errpay_pop()
@.d2 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"cell compile" }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".map" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"{\0A  global: olang_cell_init; olang_cell_run; *.cell[0-9]*;\0A  local: *;\0A};\0A" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_205_3e_2e_2d1 = weak hidden constant i1 false
@.d5 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"-Wl,--version-script=" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d6 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-shared" }>, align 8
@.d7 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"-Wl,-Bsymbolic" }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-lm" }>, align 8
@.d10 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-lpthread" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-ldl" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-lffi" }>, align 8
@.d14 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"cell link" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"cells" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e13 = weak hidden constant i1 false
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcond_3aConsts(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/cond:Consts"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 256, i1 false)
  %t2 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 0
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 1
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 2
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 3
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 4
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 5
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 6
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 7
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

@olang_2esole_2ecompiler_2fcond_3aConsts_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2ecompiler_2fcond_3aConsts_2e2 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e0 = weak hidden constant i1 false
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"end\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare i64 @read(i32, ptr, i64)
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"cell " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare i64 @signal(i32, i64)
declare i32 @kill(i32, i32)
declare i32 @waitpid(i32, ptr, i32)
@.d19 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"its worker cannot be built: " }>, align 8
@.d20 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"its worker cannot be started" }>, align 8
declare i32 @close(i32)
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"olang" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"  call void @__olang_thread_init()" }>, align 8
@.d24 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"  call void @__olang_san_init()" }>, align 8
@.d25 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"()" }>, align 8
@olang_2esole_2ecompiler_2fcells_3aOutcome_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcells_3aOutcome_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcells_3aOutcome_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcells_3aOutcome_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcells_3aOutcome_2e5 = weak hidden constant i1 false
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d28 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"@llvm.global_ctors = " }>, align 8
@.d29 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"define internal void @__olang_lib_init()" }>, align 8
@.d30 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"define void @olang_cell_init() #0 {\0A" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d34 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" = external global i8\0A" }>, align 8
@.d35 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"/olang-cellworker.olang" }>, align 8
@.d36 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d38 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang_cellhelp" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d40 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"/olang-cellworker." }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".list" }>, align 8
@.d42 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"{ __olang_*; __muloti4; olang_cell_*; };\0A" }>, align 8
declare i32 @getpid()
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_204_3e_2e_2d1 = weak hidden constant i1 false
@.d45 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"-Wl,--dynamic-list=" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-lm" }>, align 8
@.d47 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-lpthread" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-ldl" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-lffi" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcells_3aPlan_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2fcells_3aPlan_2e1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fcells_3aPlan_2e2 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 48
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 48
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare void @compiler_2fbuild_3aProgram_2ector(ptr %out, ptr %v0)
@G_2ecompiler_2fcells_2eBuilder = external global { ptr, ptr }
@olang_loc_982e698976ed59f7_448003811d791d9b = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eRefMut_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcells_2elink(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eRunning(ptr %v0, ptr %a0)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fsession_2eCloseFd(i32 %a0)
declare { i64, ptr } @compiler_2fsession_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eclose(ptr %v0, ptr %a0)
declare i32 @compiler_2fsession_2eReap(i32 %a0)
declare void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2elost(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_bd7f84bf0a6a1790_6aecdefa88c1aedc = external constant [0 x i8]
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fsession_2eIgnoreBrokenPipes()
declare { i32, i32 } @compiler_2fsession_2ePipe()
declare i32 @compiler_2fsession_2eFork()
declare void @compiler_2fsession_2eDup2(i32 %a0, i32 %a1)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fsession_2eExit(i32 %a0)
@olang_loc_9bfba30e0b79067c_c7b40212ef9fcad0 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eTruncate_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c055f97e3313c422_daca2fce6a780a3e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePushAll_3cU8_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_dcdbbf63e25e519f_c5c2eacce8fd1bbb = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_616551f0a3546013_1249d7bcaf39212f = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fcells_2eFramePid = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@G_2ecompiler_2fcells_2eFrameShown = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameMime = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameData = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameFailure = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameStopped = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameDone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H17e0a6412004f84451bdf7ff6c816e10(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2fcells_2esymbolAt(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_20926c2b81d0e00c_7d8ac19a57247f8 = external constant [0 x i8]
@olang_loc_948f6b52a35541f0_f4572f553ac6bc74 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_f955eaf1a3bf6405_1ec27af45d1f4ca9 = external constant [0 x i8]
@G_2ecompiler_2fcells_2eWorkerSource = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fcells_2eHelperIr = external constant <{ [8 x i8], ptr }>
declare %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
declare { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_848145de22f96d6_67a3d2054bf098fa = external constant [0 x i8]
declare void @compiler_2fbuild_2eTouch(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fcells_2eCellsCacheCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\20\00\00\00\00" }>, align 8
declare void @compiler_2fbuild_2ePrune(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
