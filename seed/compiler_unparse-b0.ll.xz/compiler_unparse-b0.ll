; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/unparse:writer" = type { ptr, { i64, ptr }, ptr, %"std/prelude/text:StringBuilder", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/ast:MemberDecl" = type { ptr, i32, { i64, ptr }, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
define dso_local i1 @compiler_2funparse_2ebareSpread(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %v1, ptr %a1, i32 %t17)
  store { i64, ptr } %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t22, ptr %l12
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_97fb03c83c422508_396f69b1ea6ff204)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/unparse:writer", ptr %t10, i32 0, i32 2
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Branch", ptr %t14, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t13, i64 %t17)
  store i1 %t20, ptr %l11
  br label %bb3
bb3:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l6, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/unparse:writer", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Branch", ptr %t27, i32 0, i32 0
  %t30 = getelementptr %"compiler/source:Span", ptr %t29, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = icmp ne i8 %t38, 58
  br i1 %t40, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t42, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Branch", ptr %t45, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t44, %"compiler/source:Span" %t48)
  br label %bb11
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/unparse:writer", ptr %t51, i32 0, i32 5
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Branch", ptr %t54, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t53, %"compiler/source:Span" %t57)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Branch", ptr %t61, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t60, { i64, ptr } %t64)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l157 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l174 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t2 = load ptr, ptr %l29, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l29, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 12}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l30, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l30, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [8 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb128
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t21 = load ptr, ptr %l37, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l37, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 12}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l38, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l38, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [8 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { ptr }, ptr %t31, i32 0, i32 0
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t35, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexternFn(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb128
bb15:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t42 = load ptr, ptr %l46, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l46, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 12}
  %t48 = icmp eq i64 %t46, 11
  store i1 %t48, ptr %l47, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l47, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [8 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t52, i32 0, i32 1
  %t54 = load %"compiler/source:Span", ptr %t53
  store %"compiler/source:Span" %t54, ptr %l4
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [8 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t58, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59
  store { i64, ptr } %t60, ptr %l5, !tbaa !27
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l4
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexternBlock(ptr %v0, ptr %v1, ptr %t62, %"compiler/source:Span" %t63, { i64, ptr } %t64)
  br label %bb21
bb21:
  br label %bb128
bb22:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t69 = load ptr, ptr %l57, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l57, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 12}
  %t75 = icmp eq i64 %t73, 2
  store i1 %t75, ptr %l58, !tbaa !21
  br label %bb24
bb24:
  %t76 = load i1, ptr %l58, !tbaa !21
  br i1 %t76, label %bb25, label %bb26
bb25:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [8 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l6, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb28
bb28:
  br label %bb128
bb29:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t88 = load ptr, ptr %l65, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb30, label %bb31
bb30:
  %t91 = load ptr, ptr %l65, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 12}
  %t94 = icmp eq i64 %t92, 3
  store i1 %t94, ptr %l66, !tbaa !21
  br label %bb31
bb31:
  %t95 = load i1, ptr %l66, !tbaa !21
  br i1 %t95, label %bb32, label %bb33
bb32:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [8 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb42
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t102 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t102, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb35
bb35:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l7, !tbaa !29
  %t107 = getelementptr %"compiler/ast:MemberDecl", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  br label %bb36
bb36:
  %t111 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t111, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb37
bb37:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l7, !tbaa !29
  %t116 = getelementptr %"compiler/ast:MemberDecl", ptr %t114, i32 0, i32 1
  %t117 = load i32, ptr %t116, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t113, i32 %t117)
  br label %bb38
bb38:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l7, !tbaa !29
  %t123 = getelementptr %"compiler/ast:MemberDecl", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t120, { i64, ptr } %t124)
  br label %bb39
bb39:
  %t127 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t127, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb40
bb40:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l7, !tbaa !29
  %t132 = getelementptr %"compiler/ast:MemberDecl", ptr %t130, i32 0, i32 3
  %t133 = load ptr, ptr %t132, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t129, ptr %t133)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb128
bb42:
  %t136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t136, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t137 = load ptr, ptr %l86, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb43, label %bb44
bb43:
  %t140 = load ptr, ptr %l86, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 12}
  %t143 = icmp eq i64 %t141, 4
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb44
bb44:
  %t144 = load i1, ptr %l87, !tbaa !21
  br i1 %t144, label %bb45, label %bb46
bb45:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [8 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr }, ptr %t147, i32 0, i32 1
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l8, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t151, ptr %t152)
  br label %bb48
bb48:
  br label %bb128
bb49:
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t156 = load ptr, ptr %l94, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb50, label %bb51
bb50:
  %t159 = load ptr, ptr %l94, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 12}
  %t162 = icmp eq i64 %t160, 5
  store i1 %t162, ptr %l95, !tbaa !21
  br label %bb51
bb51:
  %t163 = load i1, ptr %l95, !tbaa !21
  br i1 %t163, label %bb52, label %bb53
bb52:
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [8 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l9, !tbaa !23
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [8 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t172, i32 0, i32 2
  %t174 = load %"compiler/source:Span", ptr %t173
  store %"compiler/source:Span" %t174, ptr %l10
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [8 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t178, i32 0, i32 3
  %t180 = load %"compiler/source:Span", ptr %t179
  store %"compiler/source:Span" %t180, ptr %l11
  br label %bb54
bb53:
  br label %bb67
bb54:
  store %olang.scope zeroinitializer, ptr %s7
  %t182 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t182, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb55
bb55:
  %t184 = load i32, ptr %l9, !tbaa !23
  %t186 = icmp ne i32 %t184, 0
  br i1 %t186, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s8
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t188, i32 %t189)
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t192 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t192, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb60:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l10
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t194, %"compiler/source:Span" %t195)
  br label %bb61
bb61:
  %t198 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = icmp sgt i32 %t199, 0
  br i1 %t201, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t203 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t203, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l11
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t205, %"compiler/source:Span" %t206)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s7)
  br label %bb128
bb67:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t210 = load ptr, ptr %l117, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb68, label %bb69
bb68:
  %t213 = load ptr, ptr %l117, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 12}
  %t216 = icmp eq i64 %t214, 6
  store i1 %t216, ptr %l118, !tbaa !21
  br label %bb69
bb69:
  %t217 = load i1, ptr %l118, !tbaa !21
  br i1 %t217, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [8 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t220, i32 0, i32 1
  %t222 = load i32, ptr %t221
  store i32 %t222, ptr %l12, !tbaa !23
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [8 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t226, i32 0, i32 2
  %t228 = load { i64, ptr }, ptr %t227
  store { i64, ptr } %t228, ptr %l13, !tbaa !27
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [8 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t232, i32 0, i32 3
  %t234 = load { i64, ptr }, ptr %t233
  store { i64, ptr } %t234, ptr %l14, !tbaa !27
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [8 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t238, i32 0, i32 4
  %t240 = load { i64, ptr }, ptr %t239
  store { i64, ptr } %t240, ptr %l15, !tbaa !27
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l12, !tbaa !23
  %t244 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrorDecl(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t242, i32 %t243, { i64, ptr } %t244, { i64, ptr } %t245, { i64, ptr } %t246)
  br label %bb73
bb73:
  br label %bb128
bb74:
  %t252 = load ptr, ptr %l1, !tbaa !29
  store ptr %t252, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t253 = load ptr, ptr %l134, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb75, label %bb76
bb75:
  %t256 = load ptr, ptr %l134, !tbaa !29
  %t257 = load i64, ptr %t256, !range !{i64 0, i64 12}
  %t259 = icmp eq i64 %t257, 7
  store i1 %t259, ptr %l135, !tbaa !21
  br label %bb76
bb76:
  %t260 = load i1, ptr %l135, !tbaa !21
  br i1 %t260, label %bb77, label %bb78
bb77:
  %t261 = load ptr, ptr %l1, !tbaa !29
  %t263 = getelementptr { i64, [8 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t263, i32 0, i32 1
  %t265 = load %"compiler/source:Span", ptr %t264
  store %"compiler/source:Span" %t265, ptr %l16
  %t267 = load ptr, ptr %l1, !tbaa !29
  %t269 = getelementptr { i64, [8 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t269, i32 0, i32 2
  %t271 = load { i64, ptr }, ptr %t270
  store { i64, ptr } %t271, ptr %l17, !tbaa !27
  %t273 = load ptr, ptr %l1, !tbaa !29
  %t275 = getelementptr { i64, [8 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t275, i32 0, i32 3
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l18, !tbaa !29
  br label %bb79
bb78:
  br label %bb98
bb79:
  store %olang.scope zeroinitializer, ptr %s11
  %t279 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t279, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb80
bb80:
  %t281 = load ptr, ptr %l18, !tbaa !29
  %t283 = icmp eq ptr %t281, null
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s12
  %t287 = load ptr, ptr %l18, !tbaa !29
  %t289 = getelementptr %"compiler/ast:Path", ptr %t287, i32 0, i32 1
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, ptr } %t290, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t292 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t292, 0
  store i64 %t294, ptr %l21, !tbaa !24
  br label %bb83
bb82:
  br label %bb95
bb83:
  %t296 = load i64, ptr %l20, !tbaa !24
  %t297 = load i64, ptr %l21, !tbaa !24
  %t300 = icmp slt i64 %t296, %t297
  %t302 = xor i1 %t300, true
  br i1 %t302, label %bb84, label %bb85
bb84:
  br label %bb93
bb85:
  br label %bb86
bb86:
  %t304 = load i64, ptr %l20, !tbaa !24
  %t306 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t306, ptr %l157, !tbaa !27
  %t307 = load i64, ptr %l20, !tbaa !24
  %t309 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr i32, ptr %t310, i64 %t307
  %t312 = load i32, ptr %t311, !tbaa !33
  store i32 %t312, ptr %l23, !tbaa !23
  %t316 = icmp sgt i64 %t304, 0
  br i1 %t316, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s15
  %t318 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t318, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) })
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_scope_close(ptr %s15)
  br label %bb90
bb90:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t320, i32 %t321)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t324 = load i64, ptr %l20, !tbaa !24
  %t327 = add i64 %t324, 1
  store i64 %t327, ptr %l20, !tbaa !24
  br label %bb83
bb93:
  %t329 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t329, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb95:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l16
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t331, %"compiler/source:Span" %t332)
  br label %bb96
bb96:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t335, { i64, ptr } %t336)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  br label %bb128
bb98:
  %t339 = load ptr, ptr %l1, !tbaa !29
  store ptr %t339, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t340 = load ptr, ptr %l173, !tbaa !29
  %t341 = icmp ne ptr %t340, null
  br i1 %t341, label %bb99, label %bb100
bb99:
  %t343 = load ptr, ptr %l173, !tbaa !29
  %t344 = load i64, ptr %t343, !range !{i64 0, i64 12}
  %t346 = icmp eq i64 %t344, 8
  store i1 %t346, ptr %l174, !tbaa !21
  br label %bb100
bb100:
  %t347 = load i1, ptr %l174, !tbaa !21
  br i1 %t347, label %bb101, label %bb102
bb101:
  %t348 = load ptr, ptr %l1, !tbaa !29
  %t350 = getelementptr { i64, [8 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr }, ptr %t350, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l24, !tbaa !29
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t354, ptr %t355)
  br label %bb104
bb104:
  br label %bb128
bb105:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t359 = load ptr, ptr %l181, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb106, label %bb107
bb106:
  %t362 = load ptr, ptr %l181, !tbaa !29
  %t363 = load i64, ptr %t362, !range !{i64 0, i64 12}
  %t365 = icmp eq i64 %t363, 9
  store i1 %t365, ptr %l182, !tbaa !21
  br label %bb107
bb107:
  %t366 = load i1, ptr %l182, !tbaa !21
  br i1 %t366, label %bb108, label %bb109
bb108:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [8 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t369, i32 0, i32 1
  %t371 = load ptr, ptr %t370
  store ptr %t371, ptr %l25, !tbaa !29
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [8 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t375, i32 0, i32 2
  %t377 = load ptr, ptr %t376
  store ptr %t377, ptr %l26, !tbaa !29
  br label %bb110
bb109:
  br label %bb114
bb110:
  store %olang.scope zeroinitializer, ptr %s18
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t379, ptr %t380)
  br label %bb111
bb111:
  %t383 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t383, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb112
bb112:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t385, ptr %t386)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s18)
  br label %bb128
bb114:
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t390 = load ptr, ptr %l194, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  br i1 %t391, label %bb115, label %bb116
bb115:
  %t393 = load ptr, ptr %l194, !tbaa !29
  %t394 = load i64, ptr %t393, !range !{i64 0, i64 12}
  %t396 = icmp eq i64 %t394, 10
  store i1 %t396, ptr %l195, !tbaa !21
  br label %bb116
bb116:
  %t397 = load i1, ptr %l195, !tbaa !21
  br i1 %t397, label %bb117, label %bb118
bb117:
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [8 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l27, !tbaa !29
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [8 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t406, i32 0, i32 2
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l28, !tbaa !29
  br label %bb119
bb118:
  br label %bb127
bb119:
  store %olang.scope zeroinitializer, ptr %s19
  %t410 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t410, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb120
bb120:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t412, ptr %t413)
  br label %bb121
bb121:
  %t416 = load ptr, ptr %l28, !tbaa !29
  %t418 = icmp eq ptr %t416, null
  %t420 = xor i1 %t418, true
  br i1 %t420, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s20
  %t422 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t422, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb124
bb123:
  br label %bb126
bb124:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t424, ptr %t425)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s20)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s19)
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_7f8607ca82c86e8f_41d7f7ff4057cd03)
  unreachable
bb128:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:StructBody", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 1
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:StructBody", ptr %t11, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l9, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr ptr, ptr %t16, i64 0
  %t18 = load ptr, ptr %t17, !tbaa !39
  %t21 = call i1 @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecolonBefore(ptr %v0, ptr %v1, ptr %t10, ptr %t18)
  store i1 %t21, ptr %l11
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t22 = load i1, ptr %l11, !tbaa !21
  store i1 %t22, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l6, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t24)
  br label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t26, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t28, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:StructBody", ptr %t31, i32 0, i32 4
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t30, { i64, ptr } %t34)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrorDecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l27 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i64
  %l46 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l85 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t3, i32 %a1)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb3
bb3:
  store { i64, ptr } %a3, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t25, ptr %l27, !tbaa !27
  %t26 = load i64, ptr %l6, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l9, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l30, !tbaa !29
  %t36 = icmp sgt i64 %t23, 0
  br i1 %t36, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l30, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t38, { i64, ptr } %t39)
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l9, !tbaa !29
  store ptr %t40, ptr %l34, !tbaa !29
  %t41 = call ptr @__olang_scope_hold(ptr %v2)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l35, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l34, !tbaa !29
  %t46 = call ptr @__olang_region_or(ptr %t45, ptr %v2)
  %t47 = call ptr @__olang_scope_hold(ptr %t46)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l35, !tbaa !24
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l9, !tbaa !29
  %t51 = load i64, ptr %l35
  %t52 = inttoptr i64 %t51 to ptr
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %t52, ptr %t49, ptr %t50)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb4
bb16:
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp eq i64 %t62, 0
  br i1 %t64, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t66, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l46, !tbaa !29
  %t69 = load ptr, ptr %l46, !tbaa !29
  %t70 = getelementptr %"compiler/unparse:writer", ptr %t69, i32 0, i32 4
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = add i64 %t71, 1
  %t76 = load ptr, ptr %l46, !tbaa !29
  %t77 = getelementptr %"compiler/unparse:writer", ptr %t76, i32 0, i32 4
  store i64 %t74, ptr %t77, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l12, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t84 = load i64, ptr %l11, !tbaa !24
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb23:
  br label %bb24
bb24:
  %t92 = load i64, ptr %l11, !tbaa !24
  store i64 %t92, ptr %l13, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t94, ptr %l58, !tbaa !27
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  store i32 %t100, ptr %l14, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t102)
  br label %bb25
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t104, i32 %t105)
  br label %bb26
bb26:
  %t108 = load i64, ptr %l13, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t114 = icmp sge i64 %t108, %t111
  br i1 %t114, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb29
bb28:
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t116, ptr %l69, !tbaa !27
  %t117 = load i64, ptr %l13, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr ptr, ptr %t120, i64 %t117
  %t122 = load ptr, ptr %t121, !tbaa !39
  %t124 = getelementptr %"compiler/ast:CaseDecl", ptr %t122, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t129 = icmp eq i64 %t127, 0
  store i1 %t129, ptr %l68, !tbaa !21
  br label %bb29
bb29:
  %t131 = load i1, ptr %l68, !tbaa !21
  br i1 %t131, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb31:
  br label %bb32
bb32:
  %t132 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t132, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb33
bb33:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t135, ptr %l77, !tbaa !27
  %t136 = load i64, ptr %l13, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr ptr, ptr %t139, i64 %t136
  %t141 = load ptr, ptr %t140, !tbaa !39
  %t143 = getelementptr %"compiler/ast:CaseDecl", ptr %t141, i32 0, i32 2
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v3, ptr %t134, { i64, ptr } %t144)
  br label %bb34
bb34:
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t147, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = add i64 %t149, 1
  store i64 %t152, ptr %l11, !tbaa !24
  br label %bb21
bb37:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l85, !tbaa !29
  %t155 = load ptr, ptr %l85, !tbaa !29
  %t156 = getelementptr %"compiler/unparse:writer", ptr %t155, i32 0, i32 4
  %t157 = load i64, ptr %t156, !tbaa !24
  %t160 = sub i64 %t157, 1
  %t162 = load ptr, ptr %l85, !tbaa !29
  %t163 = getelementptr %"compiler/unparse:writer", ptr %t162, i32 0, i32 4
  store i64 %t160, ptr %t163, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t164)
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t166, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l98 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l103 = alloca i1
  %l106 = alloca i1
  %l109 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l120 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l134 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i1
  %l153 = alloca ptr
  %l158 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i1
  %l191 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l199 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l210 = alloca ptr
  %l211 = alloca i1
  %l228 = alloca ptr
  %l229 = alloca i1
  %l241 = alloca ptr
  %l242 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i1
  %l282 = alloca ptr
  %l283 = alloca i1
  %l296 = alloca ptr
  %l297 = alloca i1
  %l321 = alloca ptr
  %l322 = alloca i1
  %l340 = alloca ptr
  %l341 = alloca i1
  %l348 = alloca ptr
  %l356 = alloca ptr
  %l357 = alloca i1
  %l366 = alloca ptr
  %l367 = alloca i1
  %l379 = alloca ptr
  %l409 = alloca ptr
  %l419 = alloca ptr
  %l420 = alloca i1
  %l432 = alloca ptr
  %l433 = alloca i1
  %l450 = alloca ptr
  %l451 = alloca i1
  %l458 = alloca ptr
  %l459 = alloca i1
  %l467 = alloca ptr
  %l468 = alloca i1
  %l472 = alloca ptr
  %l473 = alloca i1
  %l485 = alloca ptr
  %l486 = alloca i1
  %l498 = alloca ptr
  %l499 = alloca i1
  %l508 = alloca i1
  %l512 = alloca ptr
  %l513 = alloca i1
  %l526 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s50 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t2 = load ptr, ptr %l59, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l59, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l60, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l60, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb353
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t21 = load ptr, ptr %l67, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l67, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 28}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l68, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l68, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/source:Span", ptr %t32
  store %"compiler/source:Span" %t33, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t35, %"compiler/source:Span" %t36)
  br label %bb13
bb13:
  br label %bb353
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t40 = load ptr, ptr %l75, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l75, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 28}
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l76, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l76, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb23
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t54, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/unparse:writer", ptr %t56, i32 0, i32 6
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l5, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/unparse:writer", ptr %t61, i32 0, i32 6
  store i1 false, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i1, ptr %l5, !tbaa !21
  %t72 = getelementptr %"compiler/unparse:writer", ptr %t68, i32 0, i32 6
  store i1 %t69, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb353
bb23:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t76 = load ptr, ptr %l90, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l90, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 28}
  %t82 = icmp eq i64 %t80, 3
  store i1 %t82, ptr %l91, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l91, !tbaa !21
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87, !range !{i32 0, i32 116}
  store i32 %t88, ptr %l6
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb56
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l98, !tbaa !29
  %t97 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t99 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t97)
  store { i64, ptr } %t99, ptr %l100
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l98, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t100, { i64, ptr } %t101)
  br label %bb30
bb30:
  %t102 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t104 = trunc i64 48 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb33
bb32:
  %t107 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t109 = trunc i64 13 to i32
  %t110 = icmp eq i32 %t107, %t109
  store i1 %t110, ptr %l103, !tbaa !21
  br label %bb33
bb33:
  %t112 = load i1, ptr %l103, !tbaa !21
  br i1 %t112, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb36
bb35:
  %t113 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t115 = trunc i64 18 to i32
  %t116 = icmp eq i32 %t113, %t115
  store i1 %t116, ptr %l106, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l106, !tbaa !21
  br i1 %t118, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb39
bb38:
  %t119 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t121 = trunc i64 51 to i32
  %t122 = icmp eq i32 %t119, %t121
  store i1 %t122, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t124 = load i1, ptr %l109, !tbaa !21
  br i1 %t124, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s5
  %t125 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t125, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb42
bb41:
  %t127 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t129 = trunc i64 69 to i32
  %t130 = icmp eq i32 %t127, %t129
  br i1 %t130, label %bb43, label %bb44
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb43:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb45
bb44:
  %t132 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t134 = trunc i64 94 to i32
  %t135 = icmp eq i32 %t132, %t134
  store i1 %t135, ptr %l115, !tbaa !21
  br label %bb45
bb45:
  %t137 = load i1, ptr %l115, !tbaa !21
  br i1 %t137, label %bb46, label %bb47
bb46:
  %t138 = load ptr, ptr %l7, !tbaa !29
  %t140 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v1, ptr %t138)
  store i1 %t140, ptr %l120
  br label %bb48
bb47:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb49
bb48:
  %t141 = load i1, ptr %l120, !tbaa !21
  store i1 %t141, ptr %l118, !tbaa !21
  br label %bb49
bb49:
  %t142 = load i1, ptr %l118, !tbaa !21
  br i1 %t142, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t143 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t143, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb353
bb56:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t150 = load ptr, ptr %l124, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb57, label %bb58
bb57:
  %t153 = load ptr, ptr %l124, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 28}
  %t156 = icmp eq i64 %t154, 4
  store i1 %t156, ptr %l125, !tbaa !21
  br label %bb58
bb58:
  %t157 = load i1, ptr %l125, !tbaa !21
  br i1 %t157, label %bb59, label %bb60
bb59:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t160, i32 0, i32 1
  %t162 = load i32, ptr %t161, !range !{i32 0, i32 116}
  store i32 %t162, ptr %l8
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 2
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l9, !tbaa !29
  br label %bb61
bb60:
  br label %bb65
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t170, ptr %t171)
  br label %bb62
bb62:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l134, !tbaa !29
  %t175 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t177 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t175)
  store { i64, ptr } %t177, ptr %l136
  br label %bb63
bb63:
  %t178 = load ptr, ptr %l134, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l136, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t178, { i64, ptr } %t179)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  br label %bb353
bb65:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t181 = load ptr, ptr %l137, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb66, label %bb67
bb66:
  %t184 = load ptr, ptr %l137, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 28}
  %t187 = icmp eq i64 %t185, 5
  store i1 %t187, ptr %l138, !tbaa !21
  br label %bb67
bb67:
  %t188 = load i1, ptr %l138, !tbaa !21
  br i1 %t188, label %bb68, label %bb69
bb68:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t191, i32 0, i32 1
  %t193 = load i32, ptr %t192, !range !{i32 0, i32 116}
  store i32 %t193, ptr %l10
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t197, i32 0, i32 2
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l11, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t203, i32 0, i32 3
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l12, !tbaa !29
  br label %bb70
bb69:
  br label %bb80
bb70:
  store %olang.scope zeroinitializer, ptr %s9
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t207, ptr %t208)
  br label %bb71
bb71:
  %t211 = load i32, ptr %l10, !range !{i32 0, i32 116}
  %t213 = trunc i64 79 to i32
  %t214 = icmp eq i32 %t211, %t213
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s10
  %t218 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t218, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb75
bb75:
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l153, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l10, !range !{i32 0, i32 116}
  %t223 = load ptr, ptr %l11, !tbaa !29
  %t224 = load ptr, ptr %l12, !tbaa !29
  %t229 = call { i64, ptr } @compiler_2funparse_2ecompiler_2funparse_3awriter_2eopWritten(ptr %v0, ptr %v1, ptr %v1, ptr %s9, ptr %t221, i32 %t222, ptr %t223, ptr %t224)
  store { i64, ptr } %t229, ptr %l158
  br label %bb76
bb76:
  %t230 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t231 = load ptr, ptr %l153, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t231, { i64, ptr } %t230)
  br label %bb77
bb77:
  %t233 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t233, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb78
bb78:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t235, ptr %t236)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s9)
  br label %bb353
bb80:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t240 = load ptr, ptr %l163, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb81, label %bb82
bb81:
  %t243 = load ptr, ptr %l163, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 28}
  %t246 = icmp eq i64 %t244, 6
  store i1 %t246, ptr %l164, !tbaa !21
  br label %bb82
bb82:
  %t247 = load i1, ptr %l164, !tbaa !21
  br i1 %t247, label %bb83, label %bb84
bb83:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t250, i32 0, i32 1
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l13, !tbaa !29
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t256, i32 0, i32 2
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l14, !tbaa !29
  br label %bb85
bb84:
  br label %bb89
bb85:
  store %olang.scope zeroinitializer, ptr %s11
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t260, ptr %t261)
  br label %bb86
bb86:
  %t264 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t264, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb87
bb87:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t266, ptr %t267)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s11)
  br label %bb353
bb89:
  %t270 = load ptr, ptr %l1, !tbaa !29
  store ptr %t270, ptr %l176, !tbaa !29
  store i1 false, ptr %l177, !tbaa !21
  %t271 = load ptr, ptr %l176, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb90, label %bb91
bb90:
  %t274 = load ptr, ptr %l176, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 28}
  %t277 = icmp eq i64 %t275, 7
  store i1 %t277, ptr %l177, !tbaa !21
  br label %bb91
bb91:
  %t278 = load i1, ptr %l177, !tbaa !21
  br i1 %t278, label %bb92, label %bb93
bb92:
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", ptr }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l15, !tbaa !29
  br label %bb94
bb93:
  br label %bb109
bb94:
  %t285 = load ptr, ptr %l15, !tbaa !29
  %t287 = getelementptr %"compiler/ast:Chain", ptr %t285, i32 0, i32 1
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  store i64 %t292, ptr %l18, !tbaa !24
  br label %bb95
bb95:
  %t294 = load i64, ptr %l17, !tbaa !24
  %t295 = load i64, ptr %l18, !tbaa !24
  %t298 = icmp slt i64 %t294, %t295
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb96, label %bb97
bb96:
  br label %bb108
bb97:
  br label %bb98
bb98:
  %t302 = load i64, ptr %l17, !tbaa !24
  store i64 %t302, ptr %l19, !tbaa !24
  %t304 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t304, ptr %l191, !tbaa !27
  %t305 = load i64, ptr %l17, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr ptr, ptr %t308, i64 %t305
  %t310 = load ptr, ptr %t309, !tbaa !39
  store ptr %t310, ptr %l20, !tbaa !29
  %t312 = load i64, ptr %l19, !tbaa !24
  %t314 = icmp sgt i64 %t312, 0
  br i1 %t314, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s15
  %t316 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t316, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb101
bb100:
  br label %bb105
bb101:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l197, !tbaa !29
  %t319 = load ptr, ptr %l15, !tbaa !29
  %t321 = getelementptr %"compiler/ast:Chain", ptr %t319, i32 0, i32 0
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l199, !tbaa !27
  %t323 = load i64, ptr %l19, !tbaa !24
  %t325 = sub i64 %t323, 1
  %t327 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr i32, ptr %t328, i64 %t325
  %t330 = load i32, ptr %t329, !range !{i32 0, i32 116}
  %t332 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s15, i32 %t330)
  store { i64, ptr } %t332, ptr %l203
  br label %bb102
bb102:
  %t333 = load ptr, ptr %l197, !tbaa !29
  %t334 = load { i64, ptr }, ptr %l203, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t333, { i64, ptr } %t334)
  br label %bb103
bb103:
  %t335 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t335, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s15)
  br label %bb105
bb105:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t337, ptr %t338)
  br label %bb106
bb106:
  br label %bb107
bb107:
  %t341 = load i64, ptr %l17, !tbaa !24
  %t344 = add i64 %t341, 1
  store i64 %t344, ptr %l17, !tbaa !24
  br label %bb95
bb108:
  br label %bb353
bb109:
  %t346 = load ptr, ptr %l1, !tbaa !29
  store ptr %t346, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t347 = load ptr, ptr %l210, !tbaa !29
  %t348 = icmp ne ptr %t347, null
  br i1 %t348, label %bb110, label %bb111
bb110:
  %t350 = load ptr, ptr %l210, !tbaa !29
  %t351 = load i64, ptr %t350, !range !{i64 0, i64 28}
  %t353 = icmp eq i64 %t351, 8
  store i1 %t353, ptr %l211, !tbaa !21
  br label %bb111
bb111:
  %t354 = load i1, ptr %l211, !tbaa !21
  br i1 %t354, label %bb112, label %bb113
bb112:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t357, i32 0, i32 1
  %t359 = load ptr, ptr %t358
  store ptr %t359, ptr %l21, !tbaa !29
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t363, i32 0, i32 2
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l22, !tbaa !29
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t369, i32 0, i32 3
  %t371 = load ptr, ptr %t370
  store ptr %t371, ptr %l23, !tbaa !29
  br label %bb114
bb113:
  br label %bb120
bb114:
  store %olang.scope zeroinitializer, ptr %s17
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t373, ptr %t374)
  br label %bb115
bb115:
  %t377 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t377, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb116
bb116:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t379, ptr %t380)
  br label %bb117
bb117:
  %t383 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t383, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb118
bb118:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t385, ptr %t386)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s17)
  br label %bb353
bb120:
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l228, !tbaa !29
  store i1 false, ptr %l229, !tbaa !21
  %t390 = load ptr, ptr %l228, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  br i1 %t391, label %bb121, label %bb122
bb121:
  %t393 = load ptr, ptr %l228, !tbaa !29
  %t394 = load i64, ptr %t393, !range !{i64 0, i64 28}
  %t396 = icmp eq i64 %t394, 9
  store i1 %t396, ptr %l229, !tbaa !21
  br label %bb122
bb122:
  %t397 = load i1, ptr %l229, !tbaa !21
  br i1 %t397, label %bb123, label %bb124
bb123:
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [4 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l24, !tbaa !29
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t406, i32 0, i32 2
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l25, !tbaa !29
  br label %bb125
bb124:
  br label %bb129
bb125:
  store %olang.scope zeroinitializer, ptr %s18
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t410, ptr %t411)
  br label %bb126
bb126:
  %t414 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t414, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb127
bb127:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t416, ptr %t417)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s18)
  br label %bb353
bb129:
  %t420 = load ptr, ptr %l1, !tbaa !29
  store ptr %t420, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t421 = load ptr, ptr %l241, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb130, label %bb131
bb130:
  %t424 = load ptr, ptr %l241, !tbaa !29
  %t425 = load i64, ptr %t424, !range !{i64 0, i64 28}
  %t427 = icmp eq i64 %t425, 10
  store i1 %t427, ptr %l242, !tbaa !21
  br label %bb131
bb131:
  %t428 = load i1, ptr %l242, !tbaa !21
  br i1 %t428, label %bb132, label %bb133
bb132:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t431, i32 0, i32 1
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l26, !tbaa !29
  %t435 = load ptr, ptr %l1, !tbaa !29
  %t437 = getelementptr { i64, [4 x i64] }, ptr %t435, i32 0, i32 1
  %t438 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t437, i32 0, i32 2
  %t439 = load { i64, ptr }, ptr %t438
  store { i64, ptr } %t439, ptr %l27, !tbaa !27
  br label %bb134
bb133:
  br label %bb139
bb134:
  store %olang.scope zeroinitializer, ptr %s19
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t441, ptr %t442)
  br label %bb135
bb135:
  %t445 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t445, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb136
bb136:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t447, { i64, ptr } %t448)
  br label %bb137
bb137:
  %t451 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t451, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s19)
  br label %bb353
bb139:
  %t453 = load ptr, ptr %l1, !tbaa !29
  store ptr %t453, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t454 = load ptr, ptr %l255, !tbaa !29
  %t455 = icmp ne ptr %t454, null
  br i1 %t455, label %bb140, label %bb141
bb140:
  %t457 = load ptr, ptr %l255, !tbaa !29
  %t458 = load i64, ptr %t457, !range !{i64 0, i64 28}
  %t460 = icmp eq i64 %t458, 11
  store i1 %t460, ptr %l256, !tbaa !21
  br label %bb141
bb141:
  %t461 = load i1, ptr %l256, !tbaa !21
  br i1 %t461, label %bb142, label %bb143
bb142:
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t464 = getelementptr { i64, [4 x i64] }, ptr %t462, i32 0, i32 1
  %t465 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t464, i32 0, i32 1
  %t466 = load ptr, ptr %t465
  store ptr %t466, ptr %l28, !tbaa !29
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [4 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t470, i32 0, i32 2
  %t472 = load { i64, ptr }, ptr %t471
  store { i64, ptr } %t472, ptr %l29, !tbaa !27
  br label %bb144
bb143:
  br label %bb149
bb144:
  store %olang.scope zeroinitializer, ptr %s20
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t474, ptr %t475)
  br label %bb145
bb145:
  %t478 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t478, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb146
bb146:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t480, { i64, ptr } %t481)
  br label %bb147
bb147:
  %t484 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t484, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s20)
  br label %bb353
bb149:
  %t486 = load ptr, ptr %l1, !tbaa !29
  store ptr %t486, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t487 = load ptr, ptr %l269, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb150, label %bb151
bb150:
  %t490 = load ptr, ptr %l269, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 28}
  %t493 = icmp eq i64 %t491, 12
  store i1 %t493, ptr %l270, !tbaa !21
  br label %bb151
bb151:
  %t494 = load i1, ptr %l270, !tbaa !21
  br i1 %t494, label %bb152, label %bb153
bb152:
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr { i64, [4 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t497, i32 0, i32 1
  %t499 = load ptr, ptr %t498
  store ptr %t499, ptr %l30, !tbaa !29
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t503 = getelementptr { i64, [4 x i64] }, ptr %t501, i32 0, i32 1
  %t504 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t503, i32 0, i32 2
  %t505 = load i32, ptr %t504
  store i32 %t505, ptr %l31, !tbaa !23
  br label %bb154
bb153:
  br label %bb158
bb154:
  store %olang.scope zeroinitializer, ptr %s21
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t507, ptr %t508)
  br label %bb155
bb155:
  %t511 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t511, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb156
bb156:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load i32, ptr %l31, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t513, i32 %t514)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s21)
  br label %bb353
bb158:
  %t517 = load ptr, ptr %l1, !tbaa !29
  store ptr %t517, ptr %l282, !tbaa !29
  store i1 false, ptr %l283, !tbaa !21
  %t518 = load ptr, ptr %l282, !tbaa !29
  %t519 = icmp ne ptr %t518, null
  br i1 %t519, label %bb159, label %bb160
bb159:
  %t521 = load ptr, ptr %l282, !tbaa !29
  %t522 = load i64, ptr %t521, !range !{i64 0, i64 28}
  %t524 = icmp eq i64 %t522, 13
  store i1 %t524, ptr %l283, !tbaa !21
  br label %bb160
bb160:
  %t525 = load i1, ptr %l283, !tbaa !21
  br i1 %t525, label %bb161, label %bb162
bb161:
  %t526 = load ptr, ptr %l1, !tbaa !29
  %t528 = getelementptr { i64, [4 x i64] }, ptr %t526, i32 0, i32 1
  %t529 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t528, i32 0, i32 1
  %t530 = load ptr, ptr %t529
  store ptr %t530, ptr %l32, !tbaa !29
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [4 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t534, i32 0, i32 2
  %t536 = load { i64, ptr }, ptr %t535
  store { i64, ptr } %t536, ptr %l33, !tbaa !27
  br label %bb163
bb162:
  br label %bb168
bb163:
  store %olang.scope zeroinitializer, ptr %s22
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t538, ptr %t539)
  br label %bb164
bb164:
  %t542 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t542, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb165
bb165:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t544, { i64, ptr } %t545)
  br label %bb166
bb166:
  %t548 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t548, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s22)
  br label %bb353
bb168:
  %t550 = load ptr, ptr %l1, !tbaa !29
  store ptr %t550, ptr %l296, !tbaa !29
  store i1 false, ptr %l297, !tbaa !21
  %t551 = load ptr, ptr %l296, !tbaa !29
  %t552 = icmp ne ptr %t551, null
  br i1 %t552, label %bb169, label %bb170
bb169:
  %t554 = load ptr, ptr %l296, !tbaa !29
  %t555 = load i64, ptr %t554, !range !{i64 0, i64 28}
  %t557 = icmp eq i64 %t555, 14
  store i1 %t557, ptr %l297, !tbaa !21
  br label %bb170
bb170:
  %t558 = load i1, ptr %l297, !tbaa !21
  br i1 %t558, label %bb171, label %bb172
bb171:
  %t559 = load ptr, ptr %l1, !tbaa !29
  %t561 = getelementptr { i64, [4 x i64] }, ptr %t559, i32 0, i32 1
  %t562 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t561, i32 0, i32 1
  %t563 = load ptr, ptr %t562
  store ptr %t563, ptr %l34, !tbaa !29
  %t565 = load ptr, ptr %l1, !tbaa !29
  %t567 = getelementptr { i64, [4 x i64] }, ptr %t565, i32 0, i32 1
  %t568 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t567, i32 0, i32 2
  %t569 = load ptr, ptr %t568
  store ptr %t569, ptr %l35, !tbaa !29
  %t571 = load ptr, ptr %l1, !tbaa !29
  %t573 = getelementptr { i64, [4 x i64] }, ptr %t571, i32 0, i32 1
  %t574 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t573, i32 0, i32 3
  %t575 = load ptr, ptr %t574
  store ptr %t575, ptr %l36, !tbaa !29
  br label %bb173
bb172:
  br label %bb186
bb173:
  store %olang.scope zeroinitializer, ptr %s23
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t577, ptr %t578)
  br label %bb174
bb174:
  %t581 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t581, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb175
bb175:
  %t583 = load ptr, ptr %l35, !tbaa !29
  %t585 = icmp eq ptr %t583, null
  %t587 = xor i1 %t585, true
  br i1 %t587, label %bb176, label %bb177
bb176:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t589, ptr %t590)
  br label %bb178
bb177:
  br label %bb179
bb178:
  br label %bb179
bb179:
  %t593 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t593, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb180
bb180:
  %t595 = load ptr, ptr %l36, !tbaa !29
  %t597 = icmp eq ptr %t595, null
  %t599 = xor i1 %t597, true
  br i1 %t599, label %bb181, label %bb182
bb181:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t601, ptr %t602)
  br label %bb183
bb182:
  br label %bb184
bb183:
  br label %bb184
bb184:
  %t605 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t605, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s23)
  br label %bb353
bb186:
  %t607 = load ptr, ptr %l1, !tbaa !29
  store ptr %t607, ptr %l321, !tbaa !29
  store i1 false, ptr %l322, !tbaa !21
  %t608 = load ptr, ptr %l321, !tbaa !29
  %t609 = icmp ne ptr %t608, null
  br i1 %t609, label %bb187, label %bb188
bb187:
  %t611 = load ptr, ptr %l321, !tbaa !29
  %t612 = load i64, ptr %t611, !range !{i64 0, i64 28}
  %t614 = icmp eq i64 %t612, 15
  store i1 %t614, ptr %l322, !tbaa !21
  br label %bb188
bb188:
  %t615 = load i1, ptr %l322, !tbaa !21
  br i1 %t615, label %bb189, label %bb190
bb189:
  %t616 = load ptr, ptr %l1, !tbaa !29
  %t618 = getelementptr { i64, [4 x i64] }, ptr %t616, i32 0, i32 1
  %t619 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t618, i32 0, i32 1
  %t620 = load ptr, ptr %t619
  store ptr %t620, ptr %l37, !tbaa !29
  %t622 = load ptr, ptr %l1, !tbaa !29
  %t624 = getelementptr { i64, [4 x i64] }, ptr %t622, i32 0, i32 1
  %t625 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t624, i32 0, i32 2
  %t626 = load ptr, ptr %t625
  store ptr %t626, ptr %l38, !tbaa !29
  br label %bb191
bb190:
  br label %bb201
bb191:
  store %olang.scope zeroinitializer, ptr %s26
  %t628 = load ptr, ptr %l37, !tbaa !29
  %t630 = icmp eq ptr %t628, null
  %t632 = xor i1 %t630, true
  br i1 %t632, label %bb192, label %bb193
bb192:
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t635 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t634, ptr %t635)
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb195
bb195:
  %t638 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t638, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb196
bb196:
  %t640 = load ptr, ptr %l38, !tbaa !29
  %t642 = icmp eq ptr %t640, null
  %t644 = xor i1 %t642, true
  br i1 %t644, label %bb197, label %bb198
bb197:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t646, ptr %t647)
  br label %bb199
bb198:
  br label %bb200
bb199:
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s26)
  br label %bb353
bb201:
  %t650 = load ptr, ptr %l1, !tbaa !29
  store ptr %t650, ptr %l340, !tbaa !29
  store i1 false, ptr %l341, !tbaa !21
  %t651 = load ptr, ptr %l340, !tbaa !29
  %t652 = icmp ne ptr %t651, null
  br i1 %t652, label %bb202, label %bb203
bb202:
  %t654 = load ptr, ptr %l340, !tbaa !29
  %t655 = load i64, ptr %t654, !range !{i64 0, i64 28}
  %t657 = icmp eq i64 %t655, 16
  store i1 %t657, ptr %l341, !tbaa !21
  br label %bb203
bb203:
  %t658 = load i1, ptr %l341, !tbaa !21
  br i1 %t658, label %bb204, label %bb205
bb204:
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t661 = getelementptr { i64, [4 x i64] }, ptr %t659, i32 0, i32 1
  %t662 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t661, i32 0, i32 1
  %t663 = load ptr, ptr %t662
  store ptr %t663, ptr %l39, !tbaa !29
  %t665 = load ptr, ptr %l1, !tbaa !29
  %t667 = getelementptr { i64, [4 x i64] }, ptr %t665, i32 0, i32 1
  %t668 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t667, i32 0, i32 2
  %t669 = load { i64, ptr }, ptr %t668
  store { i64, ptr } %t669, ptr %l40, !tbaa !27
  br label %bb206
bb205:
  br label %bb214
bb206:
  store %olang.scope zeroinitializer, ptr %s29
  %t671 = load ptr, ptr %l0, !tbaa !29
  store ptr %t671, ptr %l348, !tbaa !29
  %t672 = load ptr, ptr %l39, !tbaa !29
  %t674 = icmp eq ptr %t672, null
  br i1 %t674, label %bb207, label %bb208
bb207:
  call void @__olang_check_failed(ptr @olang_loc_577bb2401887ee03_bd83bee27b444ed7)
  unreachable
bb208:
  br label %bb209
bb209:
  %t676 = load ptr, ptr %l39, !tbaa !29
  %t677 = load ptr, ptr %l348, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t677, ptr %t676)
  br label %bb210
bb210:
  %t679 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t679, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb211
bb211:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load { i64, ptr }, ptr %l40, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t681, { i64, ptr } %t682)
  br label %bb212
bb212:
  %t685 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t685, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s29)
  br label %bb353
bb214:
  %t687 = load ptr, ptr %l1, !tbaa !29
  store ptr %t687, ptr %l356, !tbaa !29
  store i1 false, ptr %l357, !tbaa !21
  %t688 = load ptr, ptr %l356, !tbaa !29
  %t689 = icmp ne ptr %t688, null
  br i1 %t689, label %bb215, label %bb216
bb215:
  %t691 = load ptr, ptr %l356, !tbaa !29
  %t692 = load i64, ptr %t691, !range !{i64 0, i64 28}
  %t694 = icmp eq i64 %t692, 17
  store i1 %t694, ptr %l357, !tbaa !21
  br label %bb216
bb216:
  %t695 = load i1, ptr %l357, !tbaa !21
  br i1 %t695, label %bb217, label %bb218
bb217:
  %t696 = load ptr, ptr %l1, !tbaa !29
  %t698 = getelementptr { i64, [4 x i64] }, ptr %t696, i32 0, i32 1
  %t699 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t698, i32 0, i32 1
  %t700 = load { i64, ptr }, ptr %t699
  store { i64, ptr } %t700, ptr %l41, !tbaa !27
  br label %bb219
bb218:
  br label %bb223
bb219:
  store %olang.scope zeroinitializer, ptr %s30
  %t702 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t702, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb220
bb220:
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t705 = load { i64, ptr }, ptr %l41, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t704, { i64, ptr } %t705)
  br label %bb221
bb221:
  %t708 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t708, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s30)
  br label %bb353
bb223:
  %t710 = load ptr, ptr %l1, !tbaa !29
  store ptr %t710, ptr %l366, !tbaa !29
  store i1 false, ptr %l367, !tbaa !21
  %t711 = load ptr, ptr %l366, !tbaa !29
  %t712 = icmp ne ptr %t711, null
  br i1 %t712, label %bb224, label %bb225
bb224:
  %t714 = load ptr, ptr %l366, !tbaa !29
  %t715 = load i64, ptr %t714, !range !{i64 0, i64 28}
  %t717 = icmp eq i64 %t715, 18
  store i1 %t717, ptr %l367, !tbaa !21
  br label %bb225
bb225:
  %t718 = load i1, ptr %l367, !tbaa !21
  br i1 %t718, label %bb226, label %bb227
bb226:
  %t719 = load ptr, ptr %l1, !tbaa !29
  %t721 = getelementptr { i64, [4 x i64] }, ptr %t719, i32 0, i32 1
  %t722 = getelementptr { %"compiler/source:Span", ptr }, ptr %t721, i32 0, i32 1
  %t723 = load ptr, ptr %t722
  store ptr %t723, ptr %l42, !tbaa !29
  br label %bb228
bb227:
  br label %bb262
bb228:
  store %olang.scope zeroinitializer, ptr %s31
  %t725 = load ptr, ptr %l42, !tbaa !29
  %t727 = getelementptr %"compiler/ast:Compr", ptr %t725, i32 0, i32 6
  %t728 = load i1, ptr %t727, !tbaa !21
  %t730 = xor i1 %t728, true
  br i1 %t730, label %bb229, label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s32
  %t732 = load ptr, ptr %l42, !tbaa !29
  %t734 = getelementptr %"compiler/ast:Compr", ptr %t732, i32 0, i32 0
  %t735 = load ptr, ptr %t734, !tbaa !29
  %t737 = icmp eq ptr %t735, null
  %t739 = xor i1 %t737, true
  br i1 %t739, label %bb231, label %bb232
bb230:
  br label %bb239
bb231:
  %t741 = load ptr, ptr %l0, !tbaa !29
  store ptr %t741, ptr %l379, !tbaa !29
  %t742 = load ptr, ptr %l42, !tbaa !29
  %t744 = getelementptr %"compiler/ast:Compr", ptr %t742, i32 0, i32 0
  %t745 = load ptr, ptr %t744, !tbaa !29
  %t747 = icmp eq ptr %t745, null
  br i1 %t747, label %bb233, label %bb234
bb232:
  br label %bb237
bb233:
  call void @__olang_check_failed(ptr @olang_loc_47b511f5ef6d9e74_baf04e552c3da2b8)
  unreachable
bb234:
  br label %bb235
bb235:
  %t749 = load ptr, ptr %l42, !tbaa !29
  %t751 = getelementptr %"compiler/ast:Compr", ptr %t749, i32 0, i32 0
  %t752 = load ptr, ptr %t751, !tbaa !29
  %t753 = load ptr, ptr %l379, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t753, ptr %t752)
  br label %bb236
bb236:
  br label %bb237
bb237:
  %t755 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s32, ptr %t755, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s32)
  br label %bb239
bb239:
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t758 = load ptr, ptr %l42, !tbaa !29
  %t760 = getelementptr %"compiler/ast:Compr", ptr %t758, i32 0, i32 1
  %t761 = load ptr, ptr %t760, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t757, ptr %t761)
  br label %bb240
bb240:
  %t764 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t764, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb241
bb241:
  %t766 = load ptr, ptr %l42, !tbaa !29
  %t768 = getelementptr %"compiler/ast:Compr", ptr %t766, i32 0, i32 2
  %t769 = load i32, ptr %t768, !tbaa !23
  %t771 = icmp ne i32 %t769, 0
  br i1 %t771, label %bb242, label %bb243
bb242:
  store %olang.scope zeroinitializer, ptr %s34
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = load ptr, ptr %l42, !tbaa !29
  %t776 = getelementptr %"compiler/ast:Compr", ptr %t774, i32 0, i32 2
  %t777 = load i32, ptr %t776, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t773, i32 %t777)
  br label %bb244
bb243:
  br label %bb246
bb244:
  %t780 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s34, ptr %t780, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s34)
  br label %bb246
bb246:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t783 = load ptr, ptr %l42, !tbaa !29
  %t785 = getelementptr %"compiler/ast:Compr", ptr %t783, i32 0, i32 3
  %t786 = load i32, ptr %t785, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t782, i32 %t786)
  br label %bb247
bb247:
  %t789 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t789, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) })
  br label %bb248
bb248:
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t792 = load ptr, ptr %l42, !tbaa !29
  %t794 = getelementptr %"compiler/ast:Compr", ptr %t792, i32 0, i32 4
  %t795 = load ptr, ptr %t794, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t791, ptr %t795)
  br label %bb249
bb249:
  %t798 = load ptr, ptr %l42, !tbaa !29
  %t800 = getelementptr %"compiler/ast:Compr", ptr %t798, i32 0, i32 5
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = icmp eq ptr %t801, null
  %t805 = xor i1 %t803, true
  br i1 %t805, label %bb250, label %bb251
bb250:
  store %olang.scope zeroinitializer, ptr %s35
  %t807 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s35, ptr %t807, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb252
bb251:
  br label %bb257
bb252:
  %t809 = load ptr, ptr %l0, !tbaa !29
  store ptr %t809, ptr %l409, !tbaa !29
  %t810 = load ptr, ptr %l42, !tbaa !29
  %t812 = getelementptr %"compiler/ast:Compr", ptr %t810, i32 0, i32 5
  %t813 = load ptr, ptr %t812, !tbaa !29
  %t815 = icmp eq ptr %t813, null
  br i1 %t815, label %bb253, label %bb254
bb253:
  call void @__olang_check_failed(ptr @olang_loc_e6dde321a76d1169_ef8c066898e78ecd)
  unreachable
bb254:
  br label %bb255
bb255:
  %t817 = load ptr, ptr %l42, !tbaa !29
  %t819 = getelementptr %"compiler/ast:Compr", ptr %t817, i32 0, i32 5
  %t820 = load ptr, ptr %t819, !tbaa !29
  %t821 = load ptr, ptr %l409, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t821, ptr %t820)
  br label %bb256
bb256:
  call void @__olang_scope_close(ptr %s35)
  br label %bb257
bb257:
  %t823 = load ptr, ptr %l42, !tbaa !29
  %t825 = getelementptr %"compiler/ast:Compr", ptr %t823, i32 0, i32 6
  %t826 = load i1, ptr %t825, !tbaa !21
  %t828 = xor i1 %t826, true
  br i1 %t828, label %bb258, label %bb259
bb258:
  store %olang.scope zeroinitializer, ptr %s36
  %t830 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s36, ptr %t830, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb260
bb259:
  br label %bb261
bb260:
  call void @__olang_scope_close(ptr %s36)
  br label %bb261
bb261:
  call void @__olang_scope_close(ptr %s31)
  br label %bb353
bb262:
  %t832 = load ptr, ptr %l1, !tbaa !29
  store ptr %t832, ptr %l419, !tbaa !29
  store i1 false, ptr %l420, !tbaa !21
  %t833 = load ptr, ptr %l419, !tbaa !29
  %t834 = icmp ne ptr %t833, null
  br i1 %t834, label %bb263, label %bb264
bb263:
  %t836 = load ptr, ptr %l419, !tbaa !29
  %t837 = load i64, ptr %t836, !range !{i64 0, i64 28}
  %t839 = icmp eq i64 %t837, 19
  store i1 %t839, ptr %l420, !tbaa !21
  br label %bb264
bb264:
  %t840 = load i1, ptr %l420, !tbaa !21
  br i1 %t840, label %bb265, label %bb266
bb265:
  %t841 = load ptr, ptr %l1, !tbaa !29
  %t843 = getelementptr { i64, [4 x i64] }, ptr %t841, i32 0, i32 1
  %t844 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t843, i32 0, i32 1
  %t845 = load ptr, ptr %t844
  store ptr %t845, ptr %l43, !tbaa !29
  %t847 = load ptr, ptr %l1, !tbaa !29
  %t849 = getelementptr { i64, [4 x i64] }, ptr %t847, i32 0, i32 1
  %t850 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t849, i32 0, i32 2
  %t851 = load { i64, ptr }, ptr %t850
  store { i64, ptr } %t851, ptr %l44, !tbaa !27
  br label %bb267
bb266:
  br label %bb271
bb267:
  store %olang.scope zeroinitializer, ptr %s37
  %t853 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s37, ptr %t853, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb268
bb268:
  %t855 = load ptr, ptr %l0, !tbaa !29
  %t856 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t855, ptr %t856)
  br label %bb269
bb269:
  %t859 = load ptr, ptr %l0, !tbaa !29
  %t860 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t859, { i64, ptr } %t860)
  br label %bb270
bb270:
  call void @__olang_scope_close(ptr %s37)
  br label %bb353
bb271:
  %t863 = load ptr, ptr %l1, !tbaa !29
  store ptr %t863, ptr %l432, !tbaa !29
  store i1 false, ptr %l433, !tbaa !21
  %t864 = load ptr, ptr %l432, !tbaa !29
  %t865 = icmp ne ptr %t864, null
  br i1 %t865, label %bb272, label %bb273
bb272:
  %t867 = load ptr, ptr %l432, !tbaa !29
  %t868 = load i64, ptr %t867, !range !{i64 0, i64 28}
  %t870 = icmp eq i64 %t868, 20
  store i1 %t870, ptr %l433, !tbaa !21
  br label %bb273
bb273:
  %t871 = load i1, ptr %l433, !tbaa !21
  br i1 %t871, label %bb274, label %bb275
bb274:
  %t872 = load ptr, ptr %l1, !tbaa !29
  %t874 = getelementptr { i64, [4 x i64] }, ptr %t872, i32 0, i32 1
  %t875 = getelementptr { %"compiler/source:Span", ptr }, ptr %t874, i32 0, i32 1
  %t876 = load ptr, ptr %t875
  store ptr %t876, ptr %l45, !tbaa !29
  br label %bb276
bb275:
  br label %bb280
bb276:
  store %olang.scope zeroinitializer, ptr %s38
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t880 = getelementptr %"compiler/unparse:writer", ptr %t878, i32 0, i32 6
  %t881 = load i1, ptr %t880, !tbaa !21
  store i1 %t881, ptr %l46, !tbaa !21
  %t883 = load ptr, ptr %l0, !tbaa !29
  %t885 = getelementptr %"compiler/unparse:writer", ptr %t883, i32 0, i32 6
  store i1 false, ptr %t885, !tbaa !21
  %t886 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s38, ptr %t886, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb277
bb277:
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t889 = load ptr, ptr %l45, !tbaa !29
  %t891 = getelementptr %"compiler/ast:Func", ptr %t889, i32 0, i32 3
  %t892 = load ptr, ptr %t891, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t888, ptr %t892)
  br label %bb278
bb278:
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t896 = load i1, ptr %l46, !tbaa !21
  %t899 = getelementptr %"compiler/unparse:writer", ptr %t895, i32 0, i32 6
  store i1 %t896, ptr %t899, !tbaa !21
  %t900 = load ptr, ptr %l0, !tbaa !29
  %t901 = load ptr, ptr %l45, !tbaa !29
  %t903 = getelementptr %"compiler/ast:Func", ptr %t901, i32 0, i32 4
  %t904 = load { i64, ptr }, ptr %t903, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t900, { i64, ptr } %t904)
  br label %bb279
bb279:
  call void @__olang_scope_close(ptr %s38)
  br label %bb353
bb280:
  %t907 = load ptr, ptr %l1, !tbaa !29
  store ptr %t907, ptr %l450, !tbaa !29
  store i1 false, ptr %l451, !tbaa !21
  %t908 = load ptr, ptr %l450, !tbaa !29
  %t909 = icmp ne ptr %t908, null
  br i1 %t909, label %bb281, label %bb282
bb281:
  %t911 = load ptr, ptr %l450, !tbaa !29
  %t912 = load i64, ptr %t911, !range !{i64 0, i64 28}
  %t914 = icmp eq i64 %t912, 21
  store i1 %t914, ptr %l451, !tbaa !21
  br label %bb282
bb282:
  %t915 = load i1, ptr %l451, !tbaa !21
  br i1 %t915, label %bb283, label %bb284
bb283:
  %t916 = load ptr, ptr %l1, !tbaa !29
  %t918 = getelementptr { i64, [4 x i64] }, ptr %t916, i32 0, i32 1
  %t919 = getelementptr { %"compiler/source:Span", ptr }, ptr %t918, i32 0, i32 1
  %t920 = load ptr, ptr %t919
  store ptr %t920, ptr %l47, !tbaa !29
  br label %bb285
bb284:
  br label %bb287
bb285:
  %t922 = load ptr, ptr %l0, !tbaa !29
  %t923 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t922, ptr %t923)
  br label %bb286
bb286:
  br label %bb353
bb287:
  %t926 = load ptr, ptr %l1, !tbaa !29
  store ptr %t926, ptr %l458, !tbaa !29
  store i1 false, ptr %l459, !tbaa !21
  %t927 = load ptr, ptr %l458, !tbaa !29
  %t928 = icmp ne ptr %t927, null
  br i1 %t928, label %bb288, label %bb289
bb288:
  %t930 = load ptr, ptr %l458, !tbaa !29
  %t931 = load i64, ptr %t930, !range !{i64 0, i64 28}
  %t933 = icmp eq i64 %t931, 22
  store i1 %t933, ptr %l459, !tbaa !21
  br label %bb289
bb289:
  %t934 = load i1, ptr %l459, !tbaa !21
  br i1 %t934, label %bb290, label %bb291
bb290:
  %t935 = load ptr, ptr %l1, !tbaa !29
  %t937 = getelementptr { i64, [4 x i64] }, ptr %t935, i32 0, i32 1
  %t938 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t937, i32 0, i32 1
  %t939 = load { i64, ptr }, ptr %t938
  store { i64, ptr } %t939, ptr %l48, !tbaa !27
  br label %bb292
bb291:
  br label %bb295
bb292:
  store %olang.scope zeroinitializer, ptr %s40
  %t941 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s40, ptr %t941, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb293
bb293:
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t944 = load { i64, ptr }, ptr %l48, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t943, { i64, ptr } %t944)
  br label %bb294
bb294:
  call void @__olang_scope_close(ptr %s40)
  br label %bb353
bb295:
  %t947 = load ptr, ptr %l1, !tbaa !29
  store ptr %t947, ptr %l467, !tbaa !29
  store i1 false, ptr %l468, !tbaa !21
  %t948 = load ptr, ptr %l467, !tbaa !29
  %t949 = icmp ne ptr %t948, null
  br i1 %t949, label %bb296, label %bb297
bb296:
  %t951 = load ptr, ptr %l467, !tbaa !29
  %t952 = load i64, ptr %t951, !range !{i64 0, i64 28}
  %t954 = icmp eq i64 %t952, 23
  store i1 %t954, ptr %l468, !tbaa !21
  br label %bb297
bb297:
  %t955 = load i1, ptr %l468, !tbaa !21
  br i1 %t955, label %bb298, label %bb299
bb298:
  br label %bb300
bb299:
  br label %bb302
bb300:
  store %olang.scope zeroinitializer, ptr %s41
  %t956 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s41, ptr %t956, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb301
bb301:
  call void @__olang_scope_close(ptr %s41)
  br label %bb353
bb302:
  %t958 = load ptr, ptr %l1, !tbaa !29
  store ptr %t958, ptr %l472, !tbaa !29
  store i1 false, ptr %l473, !tbaa !21
  %t959 = load ptr, ptr %l472, !tbaa !29
  %t960 = icmp ne ptr %t959, null
  br i1 %t960, label %bb303, label %bb304
bb303:
  %t962 = load ptr, ptr %l472, !tbaa !29
  %t963 = load i64, ptr %t962, !range !{i64 0, i64 28}
  %t965 = icmp eq i64 %t963, 25
  store i1 %t965, ptr %l473, !tbaa !21
  br label %bb304
bb304:
  %t966 = load i1, ptr %l473, !tbaa !21
  br i1 %t966, label %bb305, label %bb306
bb305:
  %t967 = load ptr, ptr %l1, !tbaa !29
  %t969 = getelementptr { i64, [4 x i64] }, ptr %t967, i32 0, i32 1
  %t970 = getelementptr { %"compiler/source:Span", ptr }, ptr %t969, i32 0, i32 1
  %t971 = load ptr, ptr %t970
  store ptr %t971, ptr %l49, !tbaa !29
  br label %bb307
bb306:
  br label %bb314
bb307:
  store %olang.scope zeroinitializer, ptr %s42
  %t973 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s42, ptr %t973, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb308
bb308:
  %t975 = load ptr, ptr %l49, !tbaa !29
  %t977 = icmp eq ptr %t975, null
  %t979 = xor i1 %t977, true
  br i1 %t979, label %bb309, label %bb310
bb309:
  store %olang.scope zeroinitializer, ptr %s43
  %t981 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s43, ptr %t981, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb311
bb310:
  br label %bb313
bb311:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t984 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t983, ptr %t984)
  br label %bb312
bb312:
  call void @__olang_scope_close(ptr %s43)
  br label %bb313
bb313:
  call void @__olang_scope_close(ptr %s42)
  br label %bb353
bb314:
  %t987 = load ptr, ptr %l1, !tbaa !29
  store ptr %t987, ptr %l485, !tbaa !29
  store i1 false, ptr %l486, !tbaa !21
  %t988 = load ptr, ptr %l485, !tbaa !29
  %t989 = icmp ne ptr %t988, null
  br i1 %t989, label %bb315, label %bb316
bb315:
  %t991 = load ptr, ptr %l485, !tbaa !29
  %t992 = load i64, ptr %t991, !range !{i64 0, i64 28}
  %t994 = icmp eq i64 %t992, 24
  store i1 %t994, ptr %l486, !tbaa !21
  br label %bb316
bb316:
  %t995 = load i1, ptr %l486, !tbaa !21
  br i1 %t995, label %bb317, label %bb318
bb317:
  %t996 = load ptr, ptr %l1, !tbaa !29
  %t998 = getelementptr { i64, [4 x i64] }, ptr %t996, i32 0, i32 1
  %t999 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t998, i32 0, i32 1
  %t1000 = load i32, ptr %t999
  store i32 %t1000, ptr %l50, !tbaa !23
  %t1002 = load ptr, ptr %l1, !tbaa !29
  %t1004 = getelementptr { i64, [4 x i64] }, ptr %t1002, i32 0, i32 1
  %t1005 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1004, i32 0, i32 2
  %t1006 = load ptr, ptr %t1005
  store ptr %t1006, ptr %l51, !tbaa !29
  br label %bb319
bb318:
  br label %bb323
bb319:
  store %olang.scope zeroinitializer, ptr %s44
  %t1008 = load ptr, ptr %l0, !tbaa !29
  %t1009 = load i32, ptr %l50, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t1008, i32 %t1009)
  br label %bb320
bb320:
  %t1012 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s44, ptr %t1012, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb321
bb321:
  %t1014 = load ptr, ptr %l0, !tbaa !29
  %t1015 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t1014, ptr %t1015)
  br label %bb322
bb322:
  call void @__olang_scope_close(ptr %s44)
  br label %bb353
bb323:
  %t1018 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1018, ptr %l498, !tbaa !29
  store i1 false, ptr %l499, !tbaa !21
  %t1019 = load ptr, ptr %l498, !tbaa !29
  %t1020 = icmp ne ptr %t1019, null
  br i1 %t1020, label %bb324, label %bb325
bb324:
  %t1022 = load ptr, ptr %l498, !tbaa !29
  %t1023 = load i64, ptr %t1022, !range !{i64 0, i64 28}
  %t1025 = icmp eq i64 %t1023, 26
  store i1 %t1025, ptr %l499, !tbaa !21
  br label %bb325
bb325:
  %t1026 = load i1, ptr %l499, !tbaa !21
  br i1 %t1026, label %bb326, label %bb327
bb326:
  %t1027 = load ptr, ptr %l1, !tbaa !29
  %t1029 = getelementptr { i64, [4 x i64] }, ptr %t1027, i32 0, i32 1
  %t1030 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1029, i32 0, i32 1
  %t1031 = load ptr, ptr %t1030
  store ptr %t1031, ptr %l52, !tbaa !29
  br label %bb328
bb327:
  br label %bb335
bb328:
  store %olang.scope zeroinitializer, ptr %s45
  %t1033 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s45, ptr %t1033, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb329
bb329:
  %t1035 = load ptr, ptr %l52, !tbaa !29
  %t1036 = load ptr, ptr %l0, !tbaa !29
  %t1038 = getelementptr %"compiler/unparse:writer", ptr %t1036, i32 0, i32 0
  %t1039 = load ptr, ptr %t1038, !tbaa !29
  %t1042 = call i1 @compiler_2funparse_2ebareSpread(ptr %v1, ptr %v0, ptr %t1035, ptr %t1039)
  store i1 %t1042, ptr %l508
  br label %bb330
bb330:
  %t1043 = load i1, ptr %l508, !tbaa !21
  %t1044 = xor i1 %t1043, true
  br i1 %t1044, label %bb331, label %bb332
bb331:
  %t1046 = load ptr, ptr %l0, !tbaa !29
  %t1047 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t1046, ptr %t1047)
  br label %bb333
bb332:
  br label %bb334
bb333:
  br label %bb334
bb334:
  call void @__olang_scope_close(ptr %s45)
  br label %bb353
bb335:
  %t1050 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1050, ptr %l512, !tbaa !29
  store i1 false, ptr %l513, !tbaa !21
  %t1051 = load ptr, ptr %l512, !tbaa !29
  %t1052 = icmp ne ptr %t1051, null
  br i1 %t1052, label %bb336, label %bb337
bb336:
  %t1054 = load ptr, ptr %l512, !tbaa !29
  %t1055 = load i64, ptr %t1054, !range !{i64 0, i64 28}
  %t1057 = icmp eq i64 %t1055, 27
  store i1 %t1057, ptr %l513, !tbaa !21
  br label %bb337
bb337:
  %t1058 = load i1, ptr %l513, !tbaa !21
  br i1 %t1058, label %bb338, label %bb339
bb338:
  %t1059 = load ptr, ptr %l1, !tbaa !29
  %t1061 = getelementptr { i64, [4 x i64] }, ptr %t1059, i32 0, i32 1
  %t1062 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1061, i32 0, i32 1
  %t1063 = load { i64, ptr }, ptr %t1062
  store { i64, ptr } %t1063, ptr %l53, !tbaa !27
  br label %bb340
bb339:
  br label %bb352
bb340:
  %t1065 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t1065, ptr %l54, !tbaa !27
  store i64 0, ptr %l55, !tbaa !24
  %t1067 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t1069 = extractvalue { i64, ptr } %t1067, 0
  store i64 %t1069, ptr %l56, !tbaa !24
  br label %bb341
bb341:
  %t1071 = load i64, ptr %l55, !tbaa !24
  %t1072 = load i64, ptr %l56, !tbaa !24
  %t1075 = icmp slt i64 %t1071, %t1072
  %t1077 = xor i1 %t1075, true
  br i1 %t1077, label %bb342, label %bb343
bb342:
  br label %bb351
bb343:
  br label %bb344
bb344:
  %t1079 = load i64, ptr %l55, !tbaa !24
  %t1081 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t1081, ptr %l526, !tbaa !27
  %t1082 = load i64, ptr %l55, !tbaa !24
  %t1084 = getelementptr { i64, ptr }, ptr %l526, i32 0, i32 1
  %t1085 = load ptr, ptr %t1084, !tbaa !27
  %t1086 = getelementptr ptr, ptr %t1085, i64 %t1082
  %t1087 = load ptr, ptr %t1086, !tbaa !39
  store ptr %t1087, ptr %l58, !tbaa !29
  %t1091 = icmp sgt i64 %t1079, 0
  br i1 %t1091, label %bb345, label %bb346
bb345:
  store %olang.scope zeroinitializer, ptr %s50
  %t1093 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s50, ptr %t1093, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb347
bb346:
  br label %bb348
bb347:
  call void @__olang_scope_close(ptr %s50)
  br label %bb348
bb348:
  %t1095 = load ptr, ptr %l0, !tbaa !29
  %t1096 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t1095, ptr %t1096)
  br label %bb349
bb349:
  br label %bb350
bb350:
  %t1099 = load i64, ptr %l55, !tbaa !24
  %t1102 = add i64 %t1099, 1
  store i64 %t1102, ptr %l55, !tbaa !24
  br label %bb341
bb351:
  br label %bb353
bb352:
  call void @__olang_check_failed(ptr @olang_loc_af8532b2afdd02b1_ed9973e7a2ad66a5)
  unreachable
bb353:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexternBlock(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l17 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l53 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp sgt i32 %t4, 0
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t8, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t10, %"compiler/source:Span" %t11)
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t14, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t16, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb8
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l17, !tbaa !29
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 4
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = add i64 %t21, 1
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t26, i32 0, i32 4
  store i64 %t24, ptr %t27, !tbaa !24
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb10, label %bb11
bb10:
  br label %bb35
bb11:
  br label %bb12
bb12:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l28, !tbaa !27
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l6, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t50)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l6, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t53 = load ptr, ptr %l32, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 12}
  %t59 = icmp eq i64 %t57, 1
  store i1 %t59, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t61 = load ptr, ptr %l6, !tbaa !29
  %t63 = getelementptr { i64, [8 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { ptr }, ptr %t63, i32 0, i32 0
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexternFn(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb19
bb19:
  br label %bb33
bb20:
  %t71 = load ptr, ptr %l6, !tbaa !29
  store ptr %t71, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t72 = load ptr, ptr %l40, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 12}
  %t78 = icmp eq i64 %t76, 2
  store i1 %t78, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t80 = load ptr, ptr %l6, !tbaa !29
  %t82 = getelementptr { i64, [8 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr }, ptr %t82, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l8, !tbaa !29
  br label %bb25
bb24:
  br label %bb28
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t86, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb26
bb26:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/ast:TypeDecl", ptr %t89, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t88, i32 %t92)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c8c27977e1720628_5d646bf05a6faac)
  unreachable
bb33:
  br label %bb34
bb34:
  %t95 = load i64, ptr %l4, !tbaa !24
  %t98 = add i64 %t95, 1
  store i64 %t98, ptr %l4, !tbaa !24
  br label %bb9
bb35:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l53, !tbaa !29
  %t101 = load ptr, ptr %l53, !tbaa !29
  %t102 = getelementptr %"compiler/unparse:writer", ptr %t101, i32 0, i32 4
  %t103 = load i64, ptr %t102, !tbaa !24
  %t106 = sub i64 %t103, 1
  %t108 = load ptr, ptr %l53, !tbaa !29
  %t109 = getelementptr %"compiler/unparse:writer", ptr %t108, i32 0, i32 4
  store i64 %t106, ptr %t109, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t110)
  br label %bb36
bb36:
  %t112 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t112, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d74, i32 0, i32 1) })
  br label %bb5
bb5:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Func", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t19, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l11, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_240300a98391f326_30555605a48ff2da)
  unreachable
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t33, ptr %t32)
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t35, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v1, ptr %t37)
  store i1 %t39, ptr %l19
  br label %bb15
bb15:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l20, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Func", ptr %t42, i32 0, i32 8
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb18, label %bb19
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Func", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %t52, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t49, i32 %t53)
  br label %bb24
bb18:
  call void @__olang_check_failed(ptr @olang_loc_62b5cb0662a9bd0d_8638c84775e31461)
  unreachable
bb19:
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 8
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t60, ptr %t59)
  br label %bb21
bb21:
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t62, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb22
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 9
  %t68 = load i32, ptr %t67, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t64, i32 %t68)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 5
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t71, { i64, ptr } %t75)
  br label %bb26
bb26:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 3
  %t82 = load ptr, ptr %t81, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t78, ptr %t82)
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Func", ptr %t86, i32 0, i32 4
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t85, { i64, ptr } %t89)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efuncType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb9
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Sig", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp sgt i64 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Sig", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t27 = icmp sgt i64 %t25, 1
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l10, !tbaa !21
  store i1 %t30, ptr %l7, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l7, !tbaa !21
  store i1 %t31, ptr %l3, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/unparse:writer", ptr %t32, i32 0, i32 7
  store i1 false, ptr %t34, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load i1, ptr %l3, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t38, { i64, ptr } %t39)
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Sig", ptr %t40, i32 0, i32 8
  %t43 = load i1, ptr %t42, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s1
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t45, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t47, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb18
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v2, ptr %t49, { i64, ptr } %a2)
  br label %bb19
bb19:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/unparse:writer", ptr %t53, i32 0, i32 6
  %t56 = load i1, ptr %t55, !tbaa !21
  store i1 %t56, ptr %l4, !tbaa !21
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/unparse:writer", ptr %t58, i32 0, i32 6
  store i1 false, ptr %t60, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t61, ptr %t62)
  br label %bb20
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i1, ptr %l4, !tbaa !21
  %t69 = getelementptr %"compiler/unparse:writer", ptr %t65, i32 0, i32 6
  store i1 %t66, ptr %t69, !tbaa !21
  %t70 = load i1, ptr %l3, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca ptr
  %l20 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l42 = alloca ptr
  %l49 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:If", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_450b6e4c0e54f911_1dcad8b8a27ff01d)
  unreachable
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:If", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t20, ptr %t19)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t22, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:If", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_375b6e3c7dc4e00a_588d095da59240b6)
  unreachable
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/ast:If", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t36, ptr %t35)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l20, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:If", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_e1b6c554c381b10b_f727e5cc4e37ef67)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:If", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:If", ptr %t52, i32 0, i32 2
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t61, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb43
bb19:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:If", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l2, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  store ptr %t68, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t69 = load ptr, ptr %l33, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l33, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 22}
  %t75 = icmp eq i64 %t73, 5
  store i1 %t75, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/ast:If", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = icmp eq ptr %t86, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l42, !tbaa !29
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/ast:If", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ba8e182b2fbe7a1c_99d493faf8d7cb48)
  unreachable
bb28:
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/ast:If", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t102, ptr %t101)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a676b6f90e9ab794_adfa384105d75b88)
  unreachable
bb37:
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t104, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb38
bb38:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l49, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/ast:If", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8218e8270bec8206_ca247080b262927a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/ast:If", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t118, ptr %t117)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2einPlaceName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l8 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %t1, i32 0, i32 6
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:TypeDecl", ptr %t9, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t8, i32 %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:TypeDecl", ptr %t16, i32 0, i32 6
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_888c02f4e7827027_c6893dabd191b6cb)
  unreachable
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TypeDecl", ptr %t23, i32 0, i32 6
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t27, ptr %t26)
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/ast:TypeDecl", ptr %t32, i32 0, i32 7
  %t35 = load i32, ptr %t34, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t31, i32 %t35)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2funparse_2ecompiler_2funparse_3awriter_2eopWritten(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/source:Span"
  %l26 = alloca i1
  %l32 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t3 = trunc i64 95 to i32
  %t4 = icmp eq i32 %t1, %t3
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t10 = trunc i64 96 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t16)
  store { i64, ptr } %t18, ptr %l14
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t20, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb7:
  %t28 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %a2)
  store %"compiler/source:Span" %t28, ptr %l17
  br label %bb8
bb8:
  %t29 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t30 = load i32, ptr %t29, !tbaa !23
  %t32 = sext i32 %t30 to i64
  store i64 %t32, ptr %l4, !tbaa !24
  %t36 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %a3)
  store %"compiler/source:Span" %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t40 = sext i32 %t38 to i64
  store i64 %t40, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb12
bb11:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/unparse:writer", ptr %t47, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t55 = icmp sgt i64 %t46, %t52
  store i1 %t55, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l26, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb15
bb14:
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp sge i64 %t58, %t59
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t64 = load i1, ptr %l32, !tbaa !21
  br i1 %t64, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t67 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s3, i32 %t65)
  store { i64, ptr } %t67, ptr %l37
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t69, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/unparse:writer", ptr %t75, i32 0, i32 1
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l40, !tbaa !27
  %t79 = load i64, ptr %l4, !tbaa !24
  store i64 %t79, ptr %l41, !tbaa !24
  %t80 = load i64, ptr %l5, !tbaa !24
  store i64 %t80, ptr %l42, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l43, !tbaa !24
  %t83 = load i64, ptr %l41, !tbaa !24
  %t84 = icmp sge i64 %t83, 0
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_592dd44f1f3b971c_93db6877d1071d30)
  unreachable
bb22:
  %t90 = load i64, ptr %l42, !tbaa !24
  %t91 = load i64, ptr %l43, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_592dd44f1f3b971c_93db6877d1071d30)
  unreachable
bb24:
  %t94 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l41, !tbaa !24
  %t97 = load i64, ptr %l42, !tbaa !24
  %t98 = getelementptr i8, ptr %t95, i64 %t96
  %t99 = sub i64 %t97, %t96
  %t100 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t98, 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t105 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t101, { i64, ptr } %t104)
  store i1 %t105, ptr %l50
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_592dd44f1f3b971c_93db6877d1071d30)
  unreachable
bb26:
  %t106 = load i1, ptr %l50, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t111 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t109)
  store { i64, ptr } %t111, ptr %l53
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t112 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t113, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb30:
  %t119 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t121 = trunc i64 95 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t124, ptr %l57, !tbaa !27
  br label %bb33
bb32:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t126, ptr %l57, !tbaa !27
  br label %bb33
bb33:
  %t128 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  store i64 %t129, ptr %l62, !tbaa !24
  %t130 = load i64, ptr %l62, !tbaa !24
  %t131 = mul i64 %t130, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t131)
  %t133 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  store { i64, ptr } %t134, ptr %l63, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = load i64, ptr %l62, !tbaa !24
  %t140 = mul i64 %t139, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t136, ptr %t138, i64 %t140, i1 false)
  %t141 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t141, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t142 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t142, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l50 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l109 = alloca { i64, ptr }
  %l110 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l18, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l19, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l19, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb87
bb7:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t13 = load ptr, ptr %l23, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb8, label %bb9
bb8:
  %t16 = load ptr, ptr %l23, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 9}
  %t19 = icmp eq i64 %t17, 1
  store i1 %t19, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l24, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", ptr }, ptr %t23, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb13
bb13:
  br label %bb87
bb14:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t35 = load ptr, ptr %l31, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 9}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l32, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t48, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  br label %bb19
bb18:
  br label %bb34
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb21
bb21:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb23, label %bb24
bb23:
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l50, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l9, !tbaa !29
  %t84 = icmp sgt i64 %t72, 0
  br i1 %t84, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t86, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t92, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb22
bb32:
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t97, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb87
bb34:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t100 = load ptr, ptr %l62, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb35, label %bb36
bb35:
  %t103 = load ptr, ptr %l62, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 9}
  %t106 = icmp eq i64 %t104, 3
  store i1 %t106, ptr %l63, !tbaa !21
  br label %bb36
bb36:
  %t107 = load i1, ptr %l63, !tbaa !21
  br i1 %t107, label %bb37, label %bb38
bb37:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32 }, ptr %t110, i32 0, i32 1
  %t112 = load i32, ptr %t111
  store i32 %t112, ptr %l10, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t114, i32 %t115)
  br label %bb40
bb40:
  br label %bb87
bb41:
  %t118 = load ptr, ptr %l1, !tbaa !29
  store ptr %t118, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t119 = load ptr, ptr %l70, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb42, label %bb43
bb42:
  %t122 = load ptr, ptr %l70, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 9}
  %t125 = icmp eq i64 %t123, 4
  store i1 %t125, ptr %l71, !tbaa !21
  br label %bb43
bb43:
  %t126 = load i1, ptr %l71, !tbaa !21
  br i1 %t126, label %bb44, label %bb45
bb44:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", ptr }, ptr %t129, i32 0, i32 1
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l11, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t133, ptr %t134)
  br label %bb47
bb47:
  br label %bb87
bb48:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t138 = load ptr, ptr %l78, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb49, label %bb50
bb49:
  %t141 = load ptr, ptr %l78, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 9}
  %t144 = icmp eq i64 %t142, 5
  store i1 %t144, ptr %l79, !tbaa !21
  br label %bb50
bb50:
  %t145 = load i1, ptr %l79, !tbaa !21
  br i1 %t145, label %bb51, label %bb52
bb51:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t148, i32 0, i32 1
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l12, !tbaa !29
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t154, i32 0, i32 2
  %t156 = load i32, ptr %t155
  store i32 %t156, ptr %l13, !tbaa !23
  br label %bb53
bb52:
  br label %bb57
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  br label %bb54
bb54:
  %t162 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t162, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) })
  br label %bb55
bb55:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t164, i32 %t165)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb87
bb57:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t169 = load ptr, ptr %l91, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb58, label %bb59
bb58:
  %t172 = load ptr, ptr %l91, !tbaa !29
  %t173 = load i64, ptr %t172, !range !{i64 0, i64 9}
  %t175 = icmp eq i64 %t173, 6
  store i1 %t175, ptr %l92, !tbaa !21
  br label %bb59
bb59:
  %t176 = load i1, ptr %l92, !tbaa !21
  br i1 %t176, label %bb60, label %bb61
bb60:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l14, !tbaa !29
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t183, ptr %t184)
  br label %bb63
bb63:
  br label %bb87
bb64:
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t188 = load ptr, ptr %l99, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb65, label %bb66
bb65:
  %t191 = load ptr, ptr %l99, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 9}
  %t194 = icmp eq i64 %t192, 7
  store i1 %t194, ptr %l100, !tbaa !21
  br label %bb66
bb66:
  %t195 = load i1, ptr %l100, !tbaa !21
  br i1 %t195, label %bb67, label %bb68
bb67:
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32 }, ptr %t198, i32 0, i32 1
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l15, !tbaa !23
  br label %bb69
bb68:
  br label %bb77
bb69:
  store %olang.scope zeroinitializer, ptr %s12
  %t202 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t202, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d95, i32 0, i32 1) })
  br label %bb70
bb70:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/unparse:writer", ptr %t204, i32 0, i32 0
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t208 = load i32, ptr %l15, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t207, i32 %t208)
  store { i64, ptr } %t211, ptr %l109
  br label %bb71
bb71:
  %t212 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t213 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t212, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t213, ptr %l110
  br label %bb72
bb72:
  %t214 = load i1, ptr %l110, !tbaa !21
  %t215 = xor i1 %t214, true
  br i1 %t215, label %bb73, label %bb74
bb73:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t217, i32 %t218)
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s12)
  br label %bb87
bb77:
  %t221 = load ptr, ptr %l1, !tbaa !29
  store ptr %t221, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t222 = load ptr, ptr %l114, !tbaa !29
  %t223 = icmp ne ptr %t222, null
  br i1 %t223, label %bb78, label %bb79
bb78:
  %t225 = load ptr, ptr %l114, !tbaa !29
  %t226 = load i64, ptr %t225, !range !{i64 0, i64 9}
  %t228 = icmp eq i64 %t226, 8
  store i1 %t228, ptr %l115, !tbaa !21
  br label %bb79
bb79:
  %t229 = load i1, ptr %l115, !tbaa !21
  br i1 %t229, label %bb80, label %bb81
bb80:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t232, i32 0, i32 1
  %t234 = load i32, ptr %t233
  store i32 %t234, ptr %l16, !tbaa !23
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t238, i32 0, i32 2
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l17, !tbaa !29
  br label %bb82
bb81:
  br label %bb86
bb82:
  store %olang.scope zeroinitializer, ptr %s14
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t242, i32 %t243)
  br label %bb83
bb83:
  %t246 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t246, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb84
bb84:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t248, ptr %t249)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s14)
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_19d95224243c5dd3_a108b37826b1917)
  unreachable
bb87:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l82 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l89 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l142 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca i1
  %l188 = alloca ptr
  %l189 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i1
  %l241 = alloca ptr
  %l242 = alloca i1
  %l249 = alloca ptr
  %l251 = alloca { i64, ptr }
  %l258 = alloca ptr
  %l259 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i1
  %l297 = alloca ptr
  %l298 = alloca i1
  %l314 = alloca ptr
  %l315 = alloca i1
  %l330 = alloca ptr
  %l331 = alloca i1
  %l338 = alloca ptr
  %l340 = alloca { i64, ptr }
  %l341 = alloca ptr
  %l344 = alloca i1
  %l345 = alloca { i64, ptr }
  %l349 = alloca ptr
  %l350 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t2 = load ptr, ptr %l34, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l34, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l35, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l35, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb255
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t21 = load ptr, ptr %l42, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l42, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 22}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l43, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l43, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb255
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t40 = load ptr, ptr %l50, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l50, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 22}
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l51, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb29
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Multi", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t54, { i64, ptr } %t58)
  br label %bb20
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l59, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb26
bb22:
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Multi", ptr %t67, i32 0, i32 3
  %t70 = load i1, ptr %t69, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb25
bb24:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l65, !tbaa !27
  br label %bb25
bb25:
  %t72 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t72, ptr %l62, !tbaa !27
  br label %bb26
bb26:
  %t73 = load ptr, ptr %l59, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t73, { i64, ptr } %t74)
  br label %bb27
bb27:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Multi", ptr %t76, i32 0, i32 2
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t75, { i64, ptr } %t79)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb255
bb29:
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t83 = load ptr, ptr %l69, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t86 = load ptr, ptr %l69, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 22}
  %t89 = icmp eq i64 %t87, 3
  store i1 %t89, ptr %l70, !tbaa !21
  br label %bb31
bb31:
  %t90 = load i1, ptr %l70, !tbaa !21
  br i1 %t90, label %bb32, label %bb33
bb32:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t93, i32 0, i32 1
  %t95 = load i32, ptr %t94, !range !{i32 0, i32 116}
  store i32 %t95, ptr %l5
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l6, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t105, i32 0, i32 3
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb41
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  br label %bb35
bb35:
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t113, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb36
bb36:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l82, !tbaa !29
  %t116 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t118 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t116)
  store { i64, ptr } %t118, ptr %l84
  br label %bb37
bb37:
  %t119 = load ptr, ptr %l82, !tbaa !29
  %t120 = load { i64, ptr }, ptr %l84, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t119, { i64, ptr } %t120)
  br label %bb38
bb38:
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t121, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) })
  br label %bb39
bb39:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb255
bb41:
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t128 = load ptr, ptr %l88, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb42, label %bb43
bb42:
  %t131 = load ptr, ptr %l88, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 22}
  %t134 = icmp eq i64 %t132, 4
  store i1 %t134, ptr %l89, !tbaa !21
  br label %bb43
bb43:
  %t135 = load i1, ptr %l89, !tbaa !21
  br i1 %t135, label %bb44, label %bb45
bb44:
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t138, i32 0, i32 1
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l8, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t144, i32 0, i32 2
  %t146 = load { i64, ptr }, ptr %t145
  store { i64, ptr } %t146, ptr %l9, !tbaa !27
  br label %bb46
bb45:
  br label %bb50
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t148, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb47
bb47:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t150, ptr %t151)
  br label %bb48
bb48:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t154, { i64, ptr } %t155)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb255
bb50:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t159 = load ptr, ptr %l101, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb51, label %bb52
bb51:
  %t162 = load ptr, ptr %l101, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 22}
  %t165 = icmp eq i64 %t163, 5
  store i1 %t165, ptr %l102, !tbaa !21
  br label %bb52
bb52:
  %t166 = load i1, ptr %l102, !tbaa !21
  br i1 %t166, label %bb53, label %bb54
bb53:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr }, ptr %t169, i32 0, i32 1
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l10, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %t173, ptr %t174)
  br label %bb56
bb56:
  br label %bb255
bb57:
  %t177 = load ptr, ptr %l1, !tbaa !29
  store ptr %t177, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t178 = load ptr, ptr %l109, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb58, label %bb59
bb58:
  %t181 = load ptr, ptr %l109, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 22}
  %t184 = icmp eq i64 %t182, 6
  store i1 %t184, ptr %l110, !tbaa !21
  br label %bb59
bb59:
  %t185 = load i1, ptr %l110, !tbaa !21
  br i1 %t185, label %bb60, label %bb61
bb60:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t188, i32 0, i32 1
  %t190 = load { i64, ptr }, ptr %t189
  store { i64, ptr } %t190, ptr %l11, !tbaa !27
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s7
  %t192 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t192, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb63
bb63:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t194, { i64, ptr } %t195)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb255
bb65:
  %t198 = load ptr, ptr %l1, !tbaa !29
  store ptr %t198, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t199 = load ptr, ptr %l118, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb66, label %bb67
bb66:
  %t202 = load ptr, ptr %l118, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 22}
  %t205 = icmp eq i64 %t203, 7
  store i1 %t205, ptr %l119, !tbaa !21
  br label %bb67
bb67:
  %t206 = load i1, ptr %l119, !tbaa !21
  br i1 %t206, label %bb68, label %bb69
bb68:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t209, i32 0, i32 1
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l12, !tbaa !29
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t215, i32 0, i32 2
  %t217 = load { i64, ptr }, ptr %t216
  store { i64, ptr } %t217, ptr %l13, !tbaa !27
  br label %bb70
bb69:
  br label %bb74
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t219 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t219, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb71
bb71:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t221, ptr %t222)
  br label %bb72
bb72:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t225, { i64, ptr } %t226)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb255
bb74:
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t230 = load ptr, ptr %l131, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb75, label %bb76
bb75:
  %t233 = load ptr, ptr %l131, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 22}
  %t236 = icmp eq i64 %t234, 8
  store i1 %t236, ptr %l132, !tbaa !21
  br label %bb76
bb76:
  %t237 = load i1, ptr %l132, !tbaa !21
  br i1 %t237, label %bb77, label %bb78
bb77:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", ptr }, ptr %t240, i32 0, i32 1
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l14, !tbaa !29
  br label %bb79
bb78:
  br label %bb90
bb79:
  store %olang.scope zeroinitializer, ptr %s9
  %t244 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t244, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d106, i32 0, i32 1) })
  br label %bb80
bb80:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l14, !tbaa !29
  %t249 = getelementptr %"compiler/ast:For3", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t246, ptr %t250)
  br label %bb81
bb81:
  %t253 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t253, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb82
bb82:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l142, !tbaa !29
  %t256 = load ptr, ptr %l14, !tbaa !29
  %t258 = getelementptr %"compiler/ast:For3", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  br i1 %t261, label %bb83, label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_b263a57856eac862_46b7b1031f9001a6)
  unreachable
bb84:
  br label %bb85
bb85:
  %t263 = load ptr, ptr %l14, !tbaa !29
  %t265 = getelementptr %"compiler/ast:For3", ptr %t263, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t267 = load ptr, ptr %l142, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t267, ptr %t266)
  br label %bb86
bb86:
  %t269 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t269, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb87
bb87:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l14, !tbaa !29
  %t274 = getelementptr %"compiler/ast:For3", ptr %t272, i32 0, i32 2
  %t275 = load ptr, ptr %t274, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t271, ptr %t275)
  br label %bb88
bb88:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l14, !tbaa !29
  %t281 = getelementptr %"compiler/ast:For3", ptr %t279, i32 0, i32 3
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t278, { i64, ptr } %t282)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s9)
  br label %bb255
bb90:
  %t285 = load ptr, ptr %l1, !tbaa !29
  store ptr %t285, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t286 = load ptr, ptr %l155, !tbaa !29
  %t287 = icmp ne ptr %t286, null
  br i1 %t287, label %bb91, label %bb92
bb91:
  %t289 = load ptr, ptr %l155, !tbaa !29
  %t290 = load i64, ptr %t289, !range !{i64 0, i64 22}
  %t292 = icmp eq i64 %t290, 9
  store i1 %t292, ptr %l156, !tbaa !21
  br label %bb92
bb92:
  %t293 = load i1, ptr %l156, !tbaa !21
  br i1 %t293, label %bb93, label %bb94
bb93:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = getelementptr { i64, [4 x i64] }, ptr %t294, i32 0, i32 1
  %t297 = getelementptr { %"compiler/source:Span", ptr }, ptr %t296, i32 0, i32 1
  %t298 = load ptr, ptr %t297
  store ptr %t298, ptr %l15, !tbaa !29
  br label %bb95
bb94:
  br label %bb115
bb95:
  store %olang.scope zeroinitializer, ptr %s10
  %t300 = load ptr, ptr %l15, !tbaa !29
  %t302 = getelementptr %"compiler/ast:ForIn", ptr %t300, i32 0, i32 6
  %t303 = load i1, ptr %t302, !tbaa !21
  br i1 %t303, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s11
  %t305 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t305, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s11)
  br label %bb99
bb99:
  %t307 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t307, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb100
bb100:
  %t309 = load ptr, ptr %l15, !tbaa !29
  %t311 = getelementptr %"compiler/ast:ForIn", ptr %t309, i32 0, i32 0
  %t312 = load i32, ptr %t311, !tbaa !23
  %t314 = icmp ne i32 %t312, 0
  br i1 %t314, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s12
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l15, !tbaa !29
  %t319 = getelementptr %"compiler/ast:ForIn", ptr %t317, i32 0, i32 0
  %t320 = load i32, ptr %t319, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t316, i32 %t320)
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t323 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t323, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s12)
  br label %bb105
bb105:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load ptr, ptr %l15, !tbaa !29
  %t328 = getelementptr %"compiler/ast:ForIn", ptr %t326, i32 0, i32 1
  %t329 = load i32, ptr %t328, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t325, i32 %t329)
  br label %bb106
bb106:
  %t332 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t332, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb107
bb107:
  %t334 = load ptr, ptr %l15, !tbaa !29
  %t336 = getelementptr %"compiler/ast:ForIn", ptr %t334, i32 0, i32 3
  %t337 = load i1, ptr %t336, !tbaa !21
  br i1 %t337, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s13
  %t339 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t339, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s13)
  br label %bb111
bb111:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l15, !tbaa !29
  %t344 = getelementptr %"compiler/ast:ForIn", ptr %t342, i32 0, i32 2
  %t345 = load ptr, ptr %t344, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t341, ptr %t345)
  br label %bb112
bb112:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l15, !tbaa !29
  %t351 = getelementptr %"compiler/ast:ForIn", ptr %t349, i32 0, i32 4
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t348, { i64, ptr } %t352)
  br label %bb113
bb113:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l15, !tbaa !29
  %t358 = getelementptr %"compiler/ast:ForIn", ptr %t356, i32 0, i32 5
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t355, { i64, ptr } %t359)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s10)
  br label %bb255
bb115:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t363 = load ptr, ptr %l188, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb116, label %bb117
bb116:
  %t366 = load ptr, ptr %l188, !tbaa !29
  %t367 = load i64, ptr %t366, !range !{i64 0, i64 22}
  %t369 = icmp eq i64 %t367, 10
  store i1 %t369, ptr %l189, !tbaa !21
  br label %bb117
bb117:
  %t370 = load i1, ptr %l189, !tbaa !21
  br i1 %t370, label %bb118, label %bb119
bb118:
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t373, i32 0, i32 1
  %t375 = load { i64, ptr }, ptr %t374
  store { i64, ptr } %t375, ptr %l16, !tbaa !27
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [4 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t379, i32 0, i32 2
  %t381 = load ptr, ptr %t380
  store ptr %t381, ptr %l17, !tbaa !29
  br label %bb120
bb119:
  br label %bb125
bb120:
  store %olang.scope zeroinitializer, ptr %s14
  %t383 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t383, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb121
bb121:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t385, { i64, ptr } %t386)
  br label %bb122
bb122:
  %t389 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t389, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d115, i32 0, i32 1) })
  br label %bb123
bb123:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t391, ptr %t392)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s14)
  br label %bb255
bb125:
  %t395 = load ptr, ptr %l1, !tbaa !29
  store ptr %t395, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t396 = load ptr, ptr %l202, !tbaa !29
  %t397 = icmp ne ptr %t396, null
  br i1 %t397, label %bb126, label %bb127
bb126:
  %t399 = load ptr, ptr %l202, !tbaa !29
  %t400 = load i64, ptr %t399, !range !{i64 0, i64 22}
  %t402 = icmp eq i64 %t400, 11
  store i1 %t402, ptr %l203, !tbaa !21
  br label %bb127
bb127:
  %t403 = load i1, ptr %l203, !tbaa !21
  br i1 %t403, label %bb128, label %bb129
bb128:
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr }, ptr %t406, i32 0, i32 1
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l18, !tbaa !29
  br label %bb130
bb129:
  br label %bb132
bb130:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t410, ptr %t411)
  br label %bb131
bb131:
  br label %bb255
bb132:
  %t414 = load ptr, ptr %l1, !tbaa !29
  store ptr %t414, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t415 = load ptr, ptr %l210, !tbaa !29
  %t416 = icmp ne ptr %t415, null
  br i1 %t416, label %bb133, label %bb134
bb133:
  %t418 = load ptr, ptr %l210, !tbaa !29
  %t419 = load i64, ptr %t418, !range !{i64 0, i64 22}
  %t421 = icmp eq i64 %t419, 12
  store i1 %t421, ptr %l211, !tbaa !21
  br label %bb134
bb134:
  %t422 = load i1, ptr %l211, !tbaa !21
  br i1 %t422, label %bb135, label %bb136
bb135:
  %t423 = load ptr, ptr %l1, !tbaa !29
  %t425 = getelementptr { i64, [4 x i64] }, ptr %t423, i32 0, i32 1
  %t426 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t425, i32 0, i32 1
  %t427 = load { i64, ptr }, ptr %t426
  store { i64, ptr } %t427, ptr %l19, !tbaa !27
  br label %bb137
bb136:
  br label %bb144
bb137:
  store %olang.scope zeroinitializer, ptr %s16
  %t429 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t429, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb138
bb138:
  %t431 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 0
  %t435 = icmp sgt i64 %t433, 0
  br i1 %t435, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s17
  %t437 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t437, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) })
  br label %bb141
bb140:
  br label %bb143
bb141:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t439, { i64, ptr } %t440)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s17)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s16)
  br label %bb255
bb144:
  %t443 = load ptr, ptr %l1, !tbaa !29
  store ptr %t443, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t444 = load ptr, ptr %l223, !tbaa !29
  %t445 = icmp ne ptr %t444, null
  br i1 %t445, label %bb145, label %bb146
bb145:
  %t447 = load ptr, ptr %l223, !tbaa !29
  %t448 = load i64, ptr %t447, !range !{i64 0, i64 22}
  %t450 = icmp eq i64 %t448, 21
  store i1 %t450, ptr %l224, !tbaa !21
  br label %bb146
bb146:
  %t451 = load i1, ptr %l224, !tbaa !21
  br i1 %t451, label %bb147, label %bb148
bb147:
  %t452 = load ptr, ptr %l1, !tbaa !29
  %t454 = getelementptr { i64, [4 x i64] }, ptr %t452, i32 0, i32 1
  %t455 = getelementptr { %"compiler/source:Span", ptr }, ptr %t454, i32 0, i32 1
  %t456 = load ptr, ptr %t455
  store ptr %t456, ptr %l20, !tbaa !29
  br label %bb149
bb148:
  br label %bb152
bb149:
  store %olang.scope zeroinitializer, ptr %s18
  %t458 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t458, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb150
bb150:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t460, ptr %t461)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s18)
  br label %bb255
bb152:
  %t464 = load ptr, ptr %l1, !tbaa !29
  store ptr %t464, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t465 = load ptr, ptr %l232, !tbaa !29
  %t466 = icmp ne ptr %t465, null
  br i1 %t466, label %bb153, label %bb154
bb153:
  %t468 = load ptr, ptr %l232, !tbaa !29
  %t469 = load i64, ptr %t468, !range !{i64 0, i64 22}
  %t471 = icmp eq i64 %t469, 15
  store i1 %t471, ptr %l233, !tbaa !21
  br label %bb154
bb154:
  %t472 = load i1, ptr %l233, !tbaa !21
  br i1 %t472, label %bb155, label %bb156
bb155:
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr { i64, [4 x i64] }, ptr %t473, i32 0, i32 1
  %t476 = getelementptr { %"compiler/source:Span", ptr }, ptr %t475, i32 0, i32 1
  %t477 = load ptr, ptr %t476
  store ptr %t477, ptr %l21, !tbaa !29
  br label %bb157
bb156:
  br label %bb160
bb157:
  store %olang.scope zeroinitializer, ptr %s19
  %t479 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t479, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb158
bb158:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t481, ptr %t482)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s19)
  br label %bb255
bb160:
  %t485 = load ptr, ptr %l1, !tbaa !29
  store ptr %t485, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t486 = load ptr, ptr %l241, !tbaa !29
  %t487 = icmp ne ptr %t486, null
  br i1 %t487, label %bb161, label %bb162
bb161:
  %t489 = load ptr, ptr %l241, !tbaa !29
  %t490 = load i64, ptr %t489, !range !{i64 0, i64 22}
  %t492 = icmp eq i64 %t490, 13
  store i1 %t492, ptr %l242, !tbaa !21
  br label %bb162
bb162:
  %t493 = load i1, ptr %l242, !tbaa !21
  br i1 %t493, label %bb163, label %bb164
bb163:
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 1
  %t497 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t496, i32 0, i32 1
  %t498 = load i32, ptr %t497, !range !{i32 0, i32 116}
  store i32 %t498, ptr %l22
  %t500 = load ptr, ptr %l1, !tbaa !29
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t502, i32 0, i32 2
  %t504 = load ptr, ptr %t503
  store ptr %t504, ptr %l23, !tbaa !29
  br label %bb165
bb164:
  br label %bb173
bb165:
  store %olang.scope zeroinitializer, ptr %s20
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l249, !tbaa !29
  %t507 = load i32, ptr %l22, !range !{i32 0, i32 116}
  %t509 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s20, i32 %t507)
  store { i64, ptr } %t509, ptr %l251
  br label %bb166
bb166:
  %t510 = load ptr, ptr %l249, !tbaa !29
  %t511 = load { i64, ptr }, ptr %l251, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t510, { i64, ptr } %t511)
  br label %bb167
bb167:
  %t512 = load ptr, ptr %l23, !tbaa !29
  %t514 = icmp eq ptr %t512, null
  %t516 = xor i1 %t514, true
  br i1 %t516, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s21
  %t518 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t518, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) })
  br label %bb170
bb169:
  br label %bb172
bb170:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t520, ptr %t521)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s21)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s20)
  br label %bb255
bb173:
  %t524 = load ptr, ptr %l1, !tbaa !29
  store ptr %t524, ptr %l258, !tbaa !29
  store i1 false, ptr %l259, !tbaa !21
  %t525 = load ptr, ptr %l258, !tbaa !29
  %t526 = icmp ne ptr %t525, null
  br i1 %t526, label %bb174, label %bb175
bb174:
  %t528 = load ptr, ptr %l258, !tbaa !29
  %t529 = load i64, ptr %t528, !range !{i64 0, i64 22}
  %t531 = icmp eq i64 %t529, 14
  store i1 %t531, ptr %l259, !tbaa !21
  br label %bb175
bb175:
  %t532 = load i1, ptr %l259, !tbaa !21
  br i1 %t532, label %bb176, label %bb177
bb176:
  %t533 = load ptr, ptr %l1, !tbaa !29
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t533, i32 0, i32 1
  %t536 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t535, i32 0, i32 1
  %t537 = load ptr, ptr %t536
  store ptr %t537, ptr %l24, !tbaa !29
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr { i64, [4 x i64] }, ptr %t539, i32 0, i32 1
  %t542 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t541, i32 0, i32 2
  %t543 = load ptr, ptr %t542
  store ptr %t543, ptr %l25, !tbaa !29
  br label %bb178
bb177:
  br label %bb186
bb178:
  store %olang.scope zeroinitializer, ptr %s22
  %t545 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t545, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d121, i32 0, i32 1) })
  br label %bb179
bb179:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t547, ptr %t548)
  br label %bb180
bb180:
  %t551 = load ptr, ptr %l25, !tbaa !29
  %t553 = icmp eq ptr %t551, null
  %t555 = xor i1 %t553, true
  br i1 %t555, label %bb181, label %bb182
bb181:
  store %olang.scope zeroinitializer, ptr %s23
  %t557 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t557, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d122, i32 0, i32 1) })
  br label %bb183
bb182:
  br label %bb185
bb183:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t559, ptr %t560)
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s23)
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s22)
  br label %bb255
bb186:
  %t563 = load ptr, ptr %l1, !tbaa !29
  store ptr %t563, ptr %l275, !tbaa !29
  store i1 false, ptr %l276, !tbaa !21
  %t564 = load ptr, ptr %l275, !tbaa !29
  %t565 = icmp ne ptr %t564, null
  br i1 %t565, label %bb187, label %bb188
bb187:
  %t567 = load ptr, ptr %l275, !tbaa !29
  %t568 = load i64, ptr %t567, !range !{i64 0, i64 22}
  %t570 = icmp eq i64 %t568, 16
  store i1 %t570, ptr %l276, !tbaa !21
  br label %bb188
bb188:
  %t571 = load i1, ptr %l276, !tbaa !21
  br i1 %t571, label %bb189, label %bb190
bb189:
  %t572 = load ptr, ptr %l1, !tbaa !29
  %t574 = getelementptr { i64, [4 x i64] }, ptr %t572, i32 0, i32 1
  %t575 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t574, i32 0, i32 1
  %t576 = load ptr, ptr %t575
  store ptr %t576, ptr %l26, !tbaa !29
  %t578 = load ptr, ptr %l1, !tbaa !29
  %t580 = getelementptr { i64, [4 x i64] }, ptr %t578, i32 0, i32 1
  %t581 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t580, i32 0, i32 2
  %t582 = load { i64, ptr }, ptr %t581
  store { i64, ptr } %t582, ptr %l27, !tbaa !27
  br label %bb191
bb190:
  br label %bb204
bb191:
  store %olang.scope zeroinitializer, ptr %s24
  %t584 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t584, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d123, i32 0, i32 1) })
  br label %bb192
bb192:
  %t586 = load ptr, ptr %l26, !tbaa !29
  %t588 = icmp eq ptr %t586, null
  %t590 = xor i1 %t588, true
  br i1 %t590, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s25
  %t592 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t592, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) })
  br label %bb195
bb194:
  br label %bb197
bb195:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t594, ptr %t595)
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s25)
  br label %bb197
bb197:
  %t598 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t602 = icmp eq i64 %t600, %t601
  %t603 = extractvalue { i64, ptr } %t598, 1
  %t604 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t605 = icmp eq ptr %t603, %t604
  %t606 = and i1 %t602, %t605
  %t608 = xor i1 %t606, true
  br i1 %t608, label %bb198, label %bb199
bb198:
  store %olang.scope zeroinitializer, ptr %s26
  %t610 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t610, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) })
  br label %bb200
bb199:
  br label %bb203
bb200:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t612, { i64, ptr } %t613)
  br label %bb201
bb201:
  %t616 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t616, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) })
  br label %bb202
bb202:
  call void @__olang_scope_close(ptr %s26)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s24)
  br label %bb255
bb204:
  %t618 = load ptr, ptr %l1, !tbaa !29
  store ptr %t618, ptr %l297, !tbaa !29
  store i1 false, ptr %l298, !tbaa !21
  %t619 = load ptr, ptr %l297, !tbaa !29
  %t620 = icmp ne ptr %t619, null
  br i1 %t620, label %bb205, label %bb206
bb205:
  %t622 = load ptr, ptr %l297, !tbaa !29
  %t623 = load i64, ptr %t622, !range !{i64 0, i64 22}
  %t625 = icmp eq i64 %t623, 17
  store i1 %t625, ptr %l298, !tbaa !21
  br label %bb206
bb206:
  %t626 = load i1, ptr %l298, !tbaa !21
  br i1 %t626, label %bb207, label %bb208
bb207:
  %t627 = load ptr, ptr %l1, !tbaa !29
  %t629 = getelementptr { i64, [4 x i64] }, ptr %t627, i32 0, i32 1
  %t630 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t629, i32 0, i32 1
  %t631 = load { i64, ptr }, ptr %t630
  store { i64, ptr } %t631, ptr %l28, !tbaa !27
  %t633 = load ptr, ptr %l1, !tbaa !29
  %t635 = getelementptr { i64, [4 x i64] }, ptr %t633, i32 0, i32 1
  %t636 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t635, i32 0, i32 2
  %t637 = load ptr, ptr %t636
  store ptr %t637, ptr %l29, !tbaa !29
  br label %bb209
bb208:
  br label %bb217
bb209:
  store %olang.scope zeroinitializer, ptr %s27
  %t639 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s27, ptr %t639, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d127, i32 0, i32 1) })
  br label %bb210
bb210:
  %t641 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t643 = extractvalue { i64, ptr } %t641, 0
  %t645 = icmp sgt i64 %t643, 0
  br i1 %t645, label %bb211, label %bb212
bb211:
  store %olang.scope zeroinitializer, ptr %s28
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t647, { i64, ptr } %t648)
  br label %bb213
bb212:
  br label %bb215
bb213:
  %t651 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t651, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d128, i32 0, i32 1) })
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s28)
  br label %bb215
bb215:
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t653, ptr %t654)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s27)
  br label %bb255
bb217:
  %t657 = load ptr, ptr %l1, !tbaa !29
  store ptr %t657, ptr %l314, !tbaa !29
  store i1 false, ptr %l315, !tbaa !21
  %t658 = load ptr, ptr %l314, !tbaa !29
  %t659 = icmp ne ptr %t658, null
  br i1 %t659, label %bb218, label %bb219
bb218:
  %t661 = load ptr, ptr %l314, !tbaa !29
  %t662 = load i64, ptr %t661, !range !{i64 0, i64 22}
  %t664 = icmp eq i64 %t662, 18
  store i1 %t664, ptr %l315, !tbaa !21
  br label %bb219
bb219:
  %t665 = load i1, ptr %l315, !tbaa !21
  br i1 %t665, label %bb220, label %bb221
bb220:
  %t666 = load ptr, ptr %l1, !tbaa !29
  %t668 = getelementptr { i64, [4 x i64] }, ptr %t666, i32 0, i32 1
  %t669 = getelementptr { %"compiler/source:Span", ptr }, ptr %t668, i32 0, i32 1
  %t670 = load ptr, ptr %t669
  store ptr %t670, ptr %l30, !tbaa !29
  br label %bb222
bb221:
  br label %bb230
bb222:
  store %olang.scope zeroinitializer, ptr %s29
  %t672 = load ptr, ptr %l30, !tbaa !29
  %t674 = getelementptr %"compiler/ast:JoinS", ptr %t672, i32 0, i32 0
  %t675 = load i1, ptr %t674, !tbaa !21
  br i1 %t675, label %bb223, label %bb224
bb223:
  store %olang.scope zeroinitializer, ptr %s30
  %t677 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t677, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) })
  br label %bb225
bb224:
  br label %bb226
bb225:
  call void @__olang_scope_close(ptr %s30)
  br label %bb226
bb226:
  %t679 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t679, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb227
bb227:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load ptr, ptr %l30, !tbaa !29
  %t684 = getelementptr %"compiler/ast:JoinS", ptr %t682, i32 0, i32 1
  %t685 = load { i64, ptr }, ptr %t684, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t681, { i64, ptr } %t685)
  br label %bb228
bb228:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t689 = load ptr, ptr %l30, !tbaa !29
  %t691 = getelementptr %"compiler/ast:JoinS", ptr %t689, i32 0, i32 2
  %t692 = load { i64, ptr }, ptr %t691, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t688, { i64, ptr } %t692)
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s29)
  br label %bb255
bb230:
  %t695 = load ptr, ptr %l1, !tbaa !29
  store ptr %t695, ptr %l330, !tbaa !29
  store i1 false, ptr %l331, !tbaa !21
  %t696 = load ptr, ptr %l330, !tbaa !29
  %t697 = icmp ne ptr %t696, null
  br i1 %t697, label %bb231, label %bb232
bb231:
  %t699 = load ptr, ptr %l330, !tbaa !29
  %t700 = load i64, ptr %t699, !range !{i64 0, i64 22}
  %t702 = icmp eq i64 %t700, 19
  store i1 %t702, ptr %l331, !tbaa !21
  br label %bb232
bb232:
  %t703 = load i1, ptr %l331, !tbaa !21
  br i1 %t703, label %bb233, label %bb234
bb233:
  %t704 = load ptr, ptr %l1, !tbaa !29
  %t706 = getelementptr { i64, [4 x i64] }, ptr %t704, i32 0, i32 1
  %t707 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t706, i32 0, i32 1
  %t708 = load ptr, ptr %t707
  store ptr %t708, ptr %l31, !tbaa !29
  %t710 = load ptr, ptr %l1, !tbaa !29
  %t712 = getelementptr { i64, [4 x i64] }, ptr %t710, i32 0, i32 1
  %t713 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t712, i32 0, i32 2
  %t714 = load i1, ptr %t713
  store i1 %t714, ptr %l32, !tbaa !21
  br label %bb235
bb234:
  br label %bb247
bb235:
  store %olang.scope zeroinitializer, ptr %s31
  %t716 = load ptr, ptr %l0, !tbaa !29
  store ptr %t716, ptr %l338, !tbaa !29
  %t717 = load i1, ptr %l32, !tbaa !21
  br i1 %t717, label %bb236, label %bb237
bb236:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d131, i32 0, i32 1) }, ptr %l340, !tbaa !27
  br label %bb238
bb237:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l340, !tbaa !27
  br label %bb238
bb238:
  %t719 = load ptr, ptr %l338, !tbaa !29
  %t720 = load { i64, ptr }, ptr %l340, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t719, { i64, ptr } %t720)
  br label %bb239
bb239:
  %t721 = load ptr, ptr %l0, !tbaa !29
  store ptr %t721, ptr %l341, !tbaa !29
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load ptr, ptr %l31, !tbaa !29
  %t726 = call i1 @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecolonBefore(ptr %v0, ptr %v1, ptr %t722, ptr %t723)
  store i1 %t726, ptr %l344
  br label %bb240
bb240:
  %t727 = load i1, ptr %l344, !tbaa !21
  br i1 %t727, label %bb241, label %bb242
bb241:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, ptr %l345, !tbaa !27
  br label %bb243
bb242:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d134, i32 0, i32 1) }, ptr %l345, !tbaa !27
  br label %bb243
bb243:
  %t728 = load ptr, ptr %l341, !tbaa !29
  %t729 = load { i64, ptr }, ptr %l345, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t728, { i64, ptr } %t729)
  br label %bb244
bb244:
  %t730 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t730, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) })
  br label %bb245
bb245:
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t733 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t732, ptr %t733)
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s31)
  br label %bb255
bb247:
  %t736 = load ptr, ptr %l1, !tbaa !29
  store ptr %t736, ptr %l349, !tbaa !29
  store i1 false, ptr %l350, !tbaa !21
  %t737 = load ptr, ptr %l349, !tbaa !29
  %t738 = icmp ne ptr %t737, null
  br i1 %t738, label %bb248, label %bb249
bb248:
  %t740 = load ptr, ptr %l349, !tbaa !29
  %t741 = load i64, ptr %t740, !range !{i64 0, i64 22}
  %t743 = icmp eq i64 %t741, 20
  store i1 %t743, ptr %l350, !tbaa !21
  br label %bb249
bb249:
  %t744 = load i1, ptr %l350, !tbaa !21
  br i1 %t744, label %bb250, label %bb251
bb250:
  %t745 = load ptr, ptr %l1, !tbaa !29
  %t747 = getelementptr { i64, [4 x i64] }, ptr %t745, i32 0, i32 1
  %t748 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t747, i32 0, i32 1
  %t749 = load { i64, ptr }, ptr %t748
  store { i64, ptr } %t749, ptr %l33, !tbaa !27
  br label %bb252
bb251:
  br label %bb254
bb252:
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t752 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t751, { i64, ptr } %t752)
  br label %bb253
bb253:
  br label %bb255
bb254:
  call void @__olang_check_failed(ptr @olang_loc_9166140a1ac8280_ddd22134593fa34)
  unreachable
bb255:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l18 = alloca i1
  %l30 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l62 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopBranch", ptr %t5, i32 0, i32 0
  %t8 = getelementptr %"compiler/source:Span", ptr %t7, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t13 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i8, ptr %t14, i64 %t11
  %t16 = load i8, ptr %t15, !tbaa !32
  %t18 = icmp eq i8 %t16, 58
  store i1 %t18, ptr %l2, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TopBranch", ptr %t24, i32 0, i32 2
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t23, i64 %t27)
  store i1 %t30, ptr %l18
  br label %bb1
bb1:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb2, label %bb3
bb2:
  %t32 = load i1, ptr %l2, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb4, label %bb5
bb3:
  br label %bb10
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t36, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TopBranch", ptr %t39, i32 0, i32 0
  %t42 = load %"compiler/source:Span", ptr %t41
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t38, %"compiler/source:Span" %t42)
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/unparse:writer", ptr %t45, i32 0, i32 5
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopBranch", ptr %t48, i32 0, i32 0
  %t51 = load %"compiler/source:Span", ptr %t50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t47, %"compiler/source:Span" %t51)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t54 = load i1, ptr %l2, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/ast:TopBranch", ptr %t56, i32 0, i32 1
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t63 = icmp eq i64 %t61, 1
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t66, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/ast:TopBranch", ptr %t69, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l38, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 0
  %t76 = load ptr, ptr %t75, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %t68, ptr %t76)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  %t79 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t79, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d138, i32 0, i32 1) })
  br label %bb19
bb19:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l41, !tbaa !29
  %t82 = load ptr, ptr %l41, !tbaa !29
  %t83 = getelementptr %"compiler/unparse:writer", ptr %t82, i32 0, i32 4
  %t84 = load i64, ptr %t83, !tbaa !24
  %t87 = add i64 %t84, 1
  %t89 = load ptr, ptr %l41, !tbaa !29
  %t90 = getelementptr %"compiler/unparse:writer", ptr %t89, i32 0, i32 4
  store i64 %t87, ptr %t90, !tbaa !24
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/ast:TopBranch", ptr %t91, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l5, !tbaa !24
  br label %bb20
bb20:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t101 = load i64, ptr %l5, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb21, label %bb22
bb21:
  br label %bb27
bb22:
  br label %bb23
bb23:
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t108, ptr %l53, !tbaa !27
  %t109 = load i64, ptr %l4, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr ptr, ptr %t112, i64 %t109
  %t114 = load ptr, ptr %t113, !tbaa !39
  store ptr %t114, ptr %l6, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t116)
  br label %bb24
bb24:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %t118, ptr %t119)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l4, !tbaa !24
  %t125 = add i64 %t122, 1
  store i64 %t125, ptr %l4, !tbaa !24
  br label %bb20
bb27:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l62, !tbaa !29
  %t128 = load ptr, ptr %l62, !tbaa !29
  %t129 = getelementptr %"compiler/unparse:writer", ptr %t128, i32 0, i32 4
  %t130 = load i64, ptr %t129, !tbaa !24
  %t133 = sub i64 %t130, 1
  %t135 = load ptr, ptr %l62, !tbaa !29
  %t136 = getelementptr %"compiler/unparse:writer", ptr %t135, i32 0, i32 4
  store i64 %t133, ptr %t136, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t137)
  br label %bb28
bb28:
  %t139 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t139, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l9 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l48 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d140, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TopIf", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_69b21e264e8a714a_b3e97d9d77526506)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TopIf", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t15, ptr %t14)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopIf", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8585d6fe8f316a51_b60a12ce50df87ed)
  unreachable
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TopIf", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t29, ptr %t28)
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:TopIf", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:TopIf", ptr %t38, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  store i1 %t43, ptr %l18, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l18, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/unparse:writer", ptr %t46, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l23, !tbaa !27
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TopIf", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_eabe3ddcfaef285c_106dba970e52f8d8)
  unreachable
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TopIf", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = getelementptr %"compiler/ast:TopBranch", ptr %t60, i32 0, i32 0
  %t64 = getelementptr %"compiler/source:Span", ptr %t63, i32 0, i32 0
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = sext i32 %t65 to i64
  %t69 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 58
  br i1 %t74, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t76)
  br label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t78, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d141, i32 0, i32 1) })
  br label %bb23
bb21:
  %t80 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t80, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d142, i32 0, i32 1) })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/ast:TopIf", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t91 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t91, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) })
  br label %bb27
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l48, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/ast:TopIf", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  br i1 %t99, label %bb32, label %bb33
bb27:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l42, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/ast:TopIf", ptr %t102, i32 0, i32 2
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  br i1 %t107, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_14b8182deed7e34b_cfe8cf3ea4c448f7)
  unreachable
bb29:
  br label %bb30
bb30:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/ast:TopIf", ptr %t109, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t113, ptr %t112)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_1f325493bec1d846_692c03b2e92ac30a)
  unreachable
bb33:
  br label %bb34
bb34:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/ast:TopIf", ptr %t115, i32 0, i32 3
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t119, ptr %t118)
  br label %bb35
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l41 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l88 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l102 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l134 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l146 = alloca i1
  %l156 = alloca i1
  %l158 = alloca i1
  %l159 = alloca ptr
  %l161 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l164 = alloca ptr
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t2 = load ptr, ptr %l25, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l41, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t39
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l8, !tbaa !23
  %t48 = icmp sgt i64 %t36, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t50, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) })
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t52, i32 %t53)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t56, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb6
bb16:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t67, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t69, { i64, ptr } %t70)
  br label %bb20
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  br label %bb123
bb23:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t76 = load ptr, ptr %l59, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l59, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 8}
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l60, !tbaa !21
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", ptr }, ptr %t86, i32 0, i32 1
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efuncType(ptr %v0, ptr %v1, ptr %s7, ptr %t90, ptr %t91, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d147, i32 0, i32 1) })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb123
bb30:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t95 = load ptr, ptr %l67, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t98 = load ptr, ptr %l67, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 8}
  %t101 = icmp eq i64 %t99, 2
  store i1 %t101, ptr %l68, !tbaa !21
  br label %bb32
bb32:
  %t102 = load i1, ptr %l68, !tbaa !21
  br i1 %t102, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  br label %bb36
bb36:
  br label %bb123
bb37:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t114 = load ptr, ptr %l75, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb38, label %bb39
bb38:
  %t117 = load ptr, ptr %l75, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 8}
  %t120 = icmp eq i64 %t118, 3
  store i1 %t120, ptr %l76, !tbaa !21
  br label %bb39
bb39:
  %t121 = load i1, ptr %l76, !tbaa !21
  br i1 %t121, label %bb40, label %bb41
bb40:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t124, i32 0, i32 1
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l11, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t130, i32 0, i32 2
  %t132 = load i1, ptr %t131
  store i1 %t132, ptr %l12, !tbaa !21
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t136, i32 0, i32 3
  %t138 = load i1, ptr %t137
  store i1 %t138, ptr %l13, !tbaa !21
  br label %bb42
bb41:
  br label %bb60
bb42:
  %t140 = load i1, ptr %l13, !tbaa !21
  br i1 %t140, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t142 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t142, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d148, i32 0, i32 1) })
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb46
bb46:
  %t144 = load ptr, ptr %l11, !tbaa !29
  %t146 = call ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eFuncSig(ptr %v1, ptr %v1, ptr %t144)
  store ptr %t146, ptr %l88
  br label %bb47
bb47:
  %t147 = load ptr, ptr %l88, !tbaa !29
  store ptr %t147, ptr %l14, !tbaa !29
  %t148 = load ptr, ptr %l14, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s11
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l92, !tbaa !29
  %t155 = load ptr, ptr %l14, !tbaa !29
  store ptr %t155, ptr %l93, !tbaa !29
  %t156 = load i1, ptr %l12, !tbaa !21
  br i1 %t156, label %bb50, label %bb51
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  br label %bb54
bb50:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l95, !tbaa !27
  br label %bb52
bb51:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l95, !tbaa !27
  br label %bb52
bb52:
  %t162 = load ptr, ptr %l92, !tbaa !29
  %t163 = load ptr, ptr %l93, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l95, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efuncType(ptr %v0, ptr %v1, ptr %s11, ptr %t162, ptr %t163, { i64, ptr } %t164)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb59
bb54:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l98, !tbaa !29
  %t166 = load i1, ptr %l12, !tbaa !21
  br i1 %t166, label %bb55, label %bb56
bb55:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d151, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb57
bb56:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb57
bb57:
  %t168 = load ptr, ptr %l98, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t168, { i64, ptr } %t169)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb59:
  br label %bb123
bb60:
  %t170 = load ptr, ptr %l1, !tbaa !29
  store ptr %t170, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t171 = load ptr, ptr %l101, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb61, label %bb62
bb61:
  %t174 = load ptr, ptr %l101, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 8}
  %t177 = icmp eq i64 %t175, 5
  store i1 %t177, ptr %l102, !tbaa !21
  br label %bb62
bb62:
  %t178 = load i1, ptr %l102, !tbaa !21
  br i1 %t178, label %bb63, label %bb64
bb63:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 1
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l15, !tbaa !29
  br label %bb65
bb64:
  br label %bb68
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t185 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t185, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) })
  br label %bb66
bb66:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t187, ptr %t188)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb123
bb68:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t192 = load ptr, ptr %l110, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb69, label %bb70
bb69:
  %t195 = load ptr, ptr %l110, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 8}
  %t198 = icmp eq i64 %t196, 7
  store i1 %t198, ptr %l111, !tbaa !21
  br label %bb70
bb70:
  %t199 = load i1, ptr %l111, !tbaa !21
  br i1 %t199, label %bb71, label %bb72
bb71:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", ptr }, ptr %t202, i32 0, i32 1
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l16, !tbaa !29
  br label %bb73
bb72:
  br label %bb76
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t206, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d154, i32 0, i32 1) })
  br label %bb74
bb74:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t208, ptr %t209)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb123
bb76:
  %t212 = load ptr, ptr %l1, !tbaa !29
  store ptr %t212, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t213 = load ptr, ptr %l119, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb77, label %bb78
bb77:
  %t216 = load ptr, ptr %l119, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 8}
  %t219 = icmp eq i64 %t217, 6
  store i1 %t219, ptr %l120, !tbaa !21
  br label %bb78
bb78:
  %t220 = load i1, ptr %l120, !tbaa !21
  br i1 %t220, label %bb79, label %bb80
bb79:
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t223, i32 0, i32 1
  %t225 = load { i64, ptr }, ptr %t224
  store { i64, ptr } %t225, ptr %l17, !tbaa !27
  br label %bb81
bb80:
  br label %bb94
bb81:
  store %olang.scope zeroinitializer, ptr %s15
  %t227 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t227, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d155, i32 0, i32 1) })
  br label %bb82
bb82:
  %t229 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t229, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  store i64 %t233, ptr %l20, !tbaa !24
  br label %bb83
bb83:
  %t235 = load i64, ptr %l19, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb84, label %bb85
bb84:
  br label %bb93
bb85:
  br label %bb86
bb86:
  %t243 = load i64, ptr %l19, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t245, ptr %l134, !tbaa !27
  %t246 = load i64, ptr %l19, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr ptr, ptr %t249, i64 %t246
  %t251 = load ptr, ptr %t250, !tbaa !39
  store ptr %t251, ptr %l22, !tbaa !29
  %t255 = icmp sgt i64 %t243, 0
  br i1 %t255, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s18
  %t257 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t257, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d156, i32 0, i32 1) })
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_scope_close(ptr %s18)
  br label %bb90
bb90:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t259, ptr %t260)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t263 = load i64, ptr %l19, !tbaa !24
  %t266 = add i64 %t263, 1
  store i64 %t266, ptr %l19, !tbaa !24
  br label %bb83
bb93:
  call void @__olang_scope_close(ptr %s15)
  br label %bb123
bb94:
  %t268 = load ptr, ptr %l1, !tbaa !29
  store ptr %t268, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t269 = load ptr, ptr %l145, !tbaa !29
  %t270 = icmp ne ptr %t269, null
  br i1 %t270, label %bb95, label %bb96
bb95:
  %t272 = load ptr, ptr %l145, !tbaa !29
  %t273 = load i64, ptr %t272, !range !{i64 0, i64 8}
  %t275 = icmp eq i64 %t273, 4
  store i1 %t275, ptr %l146, !tbaa !21
  br label %bb96
bb96:
  %t276 = load i1, ptr %l146, !tbaa !21
  br i1 %t276, label %bb97, label %bb98
bb97:
  %t277 = load ptr, ptr %l1, !tbaa !29
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t277, i32 0, i32 1
  %t280 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t279, i32 0, i32 1
  %t281 = load ptr, ptr %t280
  store ptr %t281, ptr %l23, !tbaa !29
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t285, i32 0, i32 2
  %t287 = load i1, ptr %t286
  store i1 %t287, ptr %l24, !tbaa !21
  br label %bb99
bb98:
  br label %bb122
bb99:
  %t289 = load ptr, ptr %l23, !tbaa !29
  %t291 = icmp eq ptr %t289, null
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb100, label %bb101
bb100:
  %t295 = load ptr, ptr %l23, !tbaa !29
  %t297 = call i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsWeak(ptr %v1, ptr %t295)
  store i1 %t297, ptr %l158
  br label %bb102
bb101:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb103
bb102:
  %t298 = load i1, ptr %l158, !tbaa !21
  store i1 %t298, ptr %l156, !tbaa !21
  br label %bb103
bb103:
  %t299 = load i1, ptr %l156, !tbaa !21
  br i1 %t299, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s21
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l159, !tbaa !29
  %t301 = load i1, ptr %l24, !tbaa !21
  br i1 %t301, label %bb106, label %bb107
bb105:
  br label %bb112
bb106:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d157, i32 0, i32 1) }, ptr %l161, !tbaa !27
  br label %bb108
bb107:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d158, i32 0, i32 1) }, ptr %l161, !tbaa !27
  br label %bb108
bb108:
  %t303 = load ptr, ptr %l159, !tbaa !29
  %t304 = load { i64, ptr }, ptr %l161, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t303, { i64, ptr } %t304)
  br label %bb109
bb109:
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l162, !tbaa !29
  %t306 = load ptr, ptr %l23, !tbaa !29
  %t308 = call ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eUnweak(ptr %v1, ptr %v1, ptr %t306)
  store ptr %t308, ptr %l164
  br label %bb110
bb110:
  %t309 = load ptr, ptr %l162, !tbaa !29
  %t310 = load ptr, ptr %l164, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t309, ptr %t310)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s21)
  br label %ret
bb112:
  %t311 = load i1, ptr %l24, !tbaa !21
  br i1 %t311, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s22
  %t313 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t313, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d159, i32 0, i32 1) })
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s22)
  br label %bb116
bb116:
  %t315 = load ptr, ptr %l23, !tbaa !29
  %t317 = icmp eq ptr %t315, null
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb117, label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s23
  %t321 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t321, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) })
  br label %bb119
bb118:
  br label %bb121
bb119:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t323, ptr %t324)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s23)
  br label %bb121
bb121:
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_9034b6aed20fb51a_d179ca40c5e654ce)
  unreachable
bb123:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l48 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i1
  %l78 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l130 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca i1
  %l159 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t2 = load ptr, ptr %l29, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l29, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l30, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l30, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb142
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t11 = load ptr, ptr %l33, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l33, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 5}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l34, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [6 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { ptr }, ptr %t21, i32 0, i32 0
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb26
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t25, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d161, i32 0, i32 1) })
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:StructBody", ptr %t28, i32 0, i32 5
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t27, { i64, ptr } %t31)
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t34, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) })
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:StructBody", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t40)
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t43, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) })
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l48, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:StructBody", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8cd05a7785ffddf0_abfc69165374635c)
  unreachable
bb18:
  br label %bb19
bb19:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:StructBody", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t57, ptr %t56)
  br label %bb20
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:StructBody", ptr %t60, i32 0, i32 2
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %t63)
  br label %bb21
bb21:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:StructBody", ptr %t66, i32 0, i32 3
  %t69 = getelementptr %"compiler/source:Span", ptr %t68, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = icmp sgt i32 %t70, 0
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edtor(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb142
bb26:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t79 = load ptr, ptr %l62, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb27, label %bb28
bb27:
  %t82 = load ptr, ptr %l62, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 5}
  %t85 = icmp eq i64 %t83, 1
  store i1 %t85, ptr %l63, !tbaa !21
  br label %bb28
bb28:
  %t86 = load i1, ptr %l63, !tbaa !21
  br i1 %t86, label %bb29, label %bb30
bb29:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [6 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { { i64, ptr }, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90
  store { i64, ptr } %t91, ptr %l3, !tbaa !27
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [6 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { { i64, ptr }, ptr }, ptr %t95, i32 0, i32 1
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb71
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t99 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t99, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d164, i32 0, i32 1) })
  br label %bb32
bb32:
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t111 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t111, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) })
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb37:
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t113, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) })
  br label %bb38
bb38:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l78, !tbaa !29
  %t116 = load ptr, ptr %l78, !tbaa !29
  %t117 = getelementptr %"compiler/unparse:writer", ptr %t116, i32 0, i32 4
  %t118 = load i64, ptr %t117, !tbaa !24
  %t121 = add i64 %t118, 1
  %t123 = load ptr, ptr %l78, !tbaa !29
  %t124 = getelementptr %"compiler/unparse:writer", ptr %t123, i32 0, i32 4
  store i64 %t121, ptr %t124, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t125, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  store i64 %t129, ptr %l7, !tbaa !24
  br label %bb39
bb39:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l7, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb40, label %bb41
bb40:
  br label %bb68
bb41:
  br label %bb42
bb42:
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t139, ptr %l89, !tbaa !27
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 %t140
  %t145 = load ptr, ptr %t144, !tbaa !39
  store ptr %t145, ptr %l8, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t147)
  br label %bb43
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l8, !tbaa !29
  %t152 = getelementptr %"compiler/ast:CaseDecl", ptr %t150, i32 0, i32 1
  %t153 = load i32, ptr %t152, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t149, i32 %t153)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l8, !tbaa !29
  %t158 = getelementptr %"compiler/ast:CaseDecl", ptr %t156, i32 0, i32 3
  %t159 = load i1, ptr %t158, !tbaa !21
  br i1 %t159, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t161 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t161, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) })
  br label %bb47
bb46:
  %t163 = load ptr, ptr %l8, !tbaa !29
  %t165 = getelementptr %"compiler/ast:CaseDecl", ptr %t163, i32 0, i32 2
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = icmp sgt i64 %t168, 0
  br i1 %t170, label %bb52, label %bb53
bb47:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l99, !tbaa !29
  %t173 = load ptr, ptr %l8, !tbaa !29
  %t175 = getelementptr %"compiler/ast:CaseDecl", ptr %t173, i32 0, i32 2
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  store { i64, ptr } %t176, ptr %l101, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 0
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t182 = getelementptr %"compiler/ast:Param", ptr %t180, i32 0, i32 2
  %t183 = load ptr, ptr %t182, !tbaa !29
  store ptr %t183, ptr %l9, !tbaa !29
  %t185 = load ptr, ptr %l9, !tbaa !29
  %t187 = icmp eq ptr %t185, null
  br i1 %t187, label %bb48, label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_c53cd7dd70350acf_d5f64367475d1e4b)
  unreachable
bb49:
  br label %bb50
bb50:
  %t189 = load ptr, ptr %l9, !tbaa !29
  %t190 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t190, ptr %t189)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t192 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t192, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) })
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l8, !tbaa !29
  %t197 = getelementptr %"compiler/ast:CaseDecl", ptr %t195, i32 0, i32 2
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t194, { i64, ptr } %t198)
  br label %bb55
bb55:
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t201, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) })
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t205 = getelementptr %"compiler/ast:CaseDecl", ptr %t203, i32 0, i32 4
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = icmp eq ptr %t206, null
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t212 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t212, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d170, i32 0, i32 1) })
  br label %bb61
bb60:
  br label %bb66
bb61:
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l121, !tbaa !29
  %t215 = load ptr, ptr %l8, !tbaa !29
  %t217 = getelementptr %"compiler/ast:CaseDecl", ptr %t215, i32 0, i32 4
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = icmp eq ptr %t218, null
  br i1 %t220, label %bb62, label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_565cf8a51c2b309e_2af0495fa70fac4a)
  unreachable
bb63:
  br label %bb64
bb64:
  %t222 = load ptr, ptr %l8, !tbaa !29
  %t224 = getelementptr %"compiler/ast:CaseDecl", ptr %t222, i32 0, i32 4
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t226 = load ptr, ptr %l121, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t226, ptr %t225)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t228 = load i64, ptr %l6, !tbaa !24
  %t231 = add i64 %t228, 1
  store i64 %t231, ptr %l6, !tbaa !24
  br label %bb39
bb68:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l130, !tbaa !29
  %t234 = load ptr, ptr %l130, !tbaa !29
  %t235 = getelementptr %"compiler/unparse:writer", ptr %t234, i32 0, i32 4
  %t236 = load i64, ptr %t235, !tbaa !24
  %t239 = sub i64 %t236, 1
  %t241 = load ptr, ptr %l130, !tbaa !29
  %t242 = getelementptr %"compiler/unparse:writer", ptr %t241, i32 0, i32 4
  store i64 %t239, ptr %t242, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t243)
  br label %bb69
bb69:
  %t245 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t245, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) })
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s4)
  br label %bb142
bb71:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t248 = load ptr, ptr %l136, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb72, label %bb73
bb72:
  %t251 = load ptr, ptr %l136, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 5}
  %t254 = icmp eq i64 %t252, 2
  store i1 %t254, ptr %l137, !tbaa !21
  br label %bb73
bb73:
  %t255 = load i1, ptr %l137, !tbaa !21
  br i1 %t255, label %bb74, label %bb75
bb74:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [6 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t258, i32 0, i32 0
  %t260 = load { i64, ptr }, ptr %t259
  store { i64, ptr } %t260, ptr %l10, !tbaa !27
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [6 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t264, i32 0, i32 1
  %t266 = load { i64, ptr }, ptr %t265
  store { i64, ptr } %t266, ptr %l11, !tbaa !27
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [6 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t270, i32 0, i32 2
  %t272 = load { i64, ptr }, ptr %t271
  store { i64, ptr } %t272, ptr %l12, !tbaa !27
  br label %bb76
bb75:
  br label %bb126
bb76:
  store %olang.scope zeroinitializer, ptr %s13
  %t274 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t274, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) })
  br label %bb77
bb77:
  %t276 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t280 = icmp sgt i64 %t278, 0
  br i1 %t280, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s14
  %t282 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t282, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb80
bb79:
  br label %bb93
bb80:
  %t284 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t284, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t286 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t286, 0
  store i64 %t288, ptr %l15, !tbaa !24
  br label %bb81
bb81:
  %t290 = load i64, ptr %l14, !tbaa !24
  %t291 = load i64, ptr %l15, !tbaa !24
  %t294 = icmp slt i64 %t290, %t291
  %t296 = xor i1 %t294, true
  br i1 %t296, label %bb82, label %bb83
bb82:
  br label %bb91
bb83:
  br label %bb84
bb84:
  %t298 = load i64, ptr %l14, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t300, ptr %l159, !tbaa !27
  %t301 = load i64, ptr %l14, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 %t301
  %t306 = load ptr, ptr %t305, !tbaa !39
  store ptr %t306, ptr %l17, !tbaa !29
  %t310 = icmp sgt i64 %t298, 0
  br i1 %t310, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s17
  %t312 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t312, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d174, i32 0, i32 1) })
  br label %bb87
bb86:
  br label %bb88
bb87:
  call void @__olang_scope_close(ptr %s17)
  br label %bb88
bb88:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t314, ptr %t315)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t318 = load i64, ptr %l14, !tbaa !24
  %t321 = add i64 %t318, 1
  store i64 %t321, ptr %l14, !tbaa !24
  br label %bb81
bb91:
  %t323 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t323, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) })
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s14)
  br label %bb93
bb93:
  %t325 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t329 = icmp sgt i64 %t327, 0
  br i1 %t329, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s19
  %t331 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t331, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d176, i32 0, i32 1) })
  br label %bb96
bb95:
  br label %bb109
bb96:
  %t333 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t333, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l20, !tbaa !24
  br label %bb97
bb97:
  %t339 = load i64, ptr %l19, !tbaa !24
  %t340 = load i64, ptr %l20, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb98, label %bb99
bb98:
  br label %bb107
bb99:
  br label %bb100
bb100:
  %t347 = load i64, ptr %l19, !tbaa !24
  %t349 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t349, ptr %l183, !tbaa !27
  %t350 = load i64, ptr %l19, !tbaa !24
  %t352 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = getelementptr ptr, ptr %t353, i64 %t350
  %t355 = load ptr, ptr %t354, !tbaa !39
  store ptr %t355, ptr %l22, !tbaa !29
  %t359 = icmp sgt i64 %t347, 0
  br i1 %t359, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s22
  %t361 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t361, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d177, i32 0, i32 1) })
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_scope_close(ptr %s22)
  br label %bb104
bb104:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t363, ptr %t364)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t367 = load i64, ptr %l19, !tbaa !24
  %t370 = add i64 %t367, 1
  store i64 %t370, ptr %l19, !tbaa !24
  br label %bb97
bb107:
  %t372 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t372, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d178, i32 0, i32 1) })
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s19)
  br label %bb109
bb109:
  %t374 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t374, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) })
  br label %bb110
bb110:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l196, !tbaa !29
  %t377 = load ptr, ptr %l196, !tbaa !29
  %t378 = getelementptr %"compiler/unparse:writer", ptr %t377, i32 0, i32 4
  %t379 = load i64, ptr %t378, !tbaa !24
  %t382 = add i64 %t379, 1
  %t384 = load ptr, ptr %l196, !tbaa !29
  %t385 = getelementptr %"compiler/unparse:writer", ptr %t384, i32 0, i32 4
  store i64 %t382, ptr %t385, !tbaa !24
  %t386 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t386, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t388, 0
  store i64 %t390, ptr %l25, !tbaa !24
  br label %bb111
bb111:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t393 = load i64, ptr %l25, !tbaa !24
  %t396 = icmp slt i64 %t392, %t393
  %t398 = xor i1 %t396, true
  br i1 %t398, label %bb112, label %bb113
bb112:
  br label %bb123
bb113:
  br label %bb114
bb114:
  %t400 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t400, ptr %l207, !tbaa !27
  %t401 = load i64, ptr %l24, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr ptr, ptr %t404, i64 %t401
  %t406 = load ptr, ptr %t405, !tbaa !39
  store ptr %t406, ptr %l26, !tbaa !29
  %t408 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t408)
  br label %bb115
bb115:
  %t410 = load ptr, ptr %l26, !tbaa !29
  %t412 = getelementptr %"compiler/ast:Func", ptr %t410, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  %t417 = xor i1 %t415, true
  br i1 %t417, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s26
  %t419 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t419, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d180, i32 0, i32 1) })
  br label %bb118
bb117:
  br label %bb119
bb118:
  call void @__olang_scope_close(ptr %s26)
  br label %bb119
bb119:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load ptr, ptr %l26, !tbaa !29
  %t424 = getelementptr %"compiler/ast:Func", ptr %t422, i32 0, i32 2
  %t425 = load i32, ptr %t424, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t421, i32 %t425)
  br label %bb120
bb120:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load ptr, ptr %l26, !tbaa !29
  %t431 = getelementptr %"compiler/ast:Func", ptr %t429, i32 0, i32 3
  %t432 = load ptr, ptr %t431, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t428, ptr %t432)
  br label %bb121
bb121:
  br label %bb122
bb122:
  %t435 = load i64, ptr %l24, !tbaa !24
  %t438 = add i64 %t435, 1
  store i64 %t438, ptr %l24, !tbaa !24
  br label %bb111
bb123:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l225, !tbaa !29
  %t441 = load ptr, ptr %l225, !tbaa !29
  %t442 = getelementptr %"compiler/unparse:writer", ptr %t441, i32 0, i32 4
  %t443 = load i64, ptr %t442, !tbaa !24
  %t446 = sub i64 %t443, 1
  %t448 = load ptr, ptr %l225, !tbaa !29
  %t449 = getelementptr %"compiler/unparse:writer", ptr %t448, i32 0, i32 4
  store i64 %t446, ptr %t449, !tbaa !24
  %t450 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t450)
  br label %bb124
bb124:
  %t452 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t452, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d181, i32 0, i32 1) })
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s13)
  br label %bb142
bb126:
  %t454 = load ptr, ptr %l1, !tbaa !29
  store ptr %t454, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t455 = load ptr, ptr %l231, !tbaa !29
  %t456 = icmp ne ptr %t455, null
  br i1 %t456, label %bb127, label %bb128
bb127:
  %t458 = load ptr, ptr %l231, !tbaa !29
  %t459 = load i64, ptr %t458, !range !{i64 0, i64 5}
  %t461 = icmp eq i64 %t459, 3
  store i1 %t461, ptr %l232, !tbaa !21
  br label %bb128
bb128:
  %t462 = load i1, ptr %l232, !tbaa !21
  br i1 %t462, label %bb129, label %bb130
bb129:
  %t463 = load ptr, ptr %l1, !tbaa !29
  %t465 = getelementptr { i64, [6 x i64] }, ptr %t463, i32 0, i32 1
  %t466 = getelementptr { ptr, ptr }, ptr %t465, i32 0, i32 0
  %t467 = load ptr, ptr %t466
  store ptr %t467, ptr %l27, !tbaa !29
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr { i64, [6 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { ptr, ptr }, ptr %t471, i32 0, i32 1
  %t473 = load ptr, ptr %t472
  store ptr %t473, ptr %l28, !tbaa !29
  br label %bb131
bb130:
  br label %bb141
bb131:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t475, ptr %t476)
  br label %bb132
bb132:
  %t479 = load ptr, ptr %l28, !tbaa !29
  %t481 = icmp eq ptr %t479, null
  %t483 = xor i1 %t481, true
  br i1 %t483, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s29
  %t485 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t485, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d182, i32 0, i32 1) })
  br label %bb135
bb134:
  br label %bb140
bb135:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load ptr, ptr %l28, !tbaa !29
  %t490 = getelementptr %"compiler/ast:Func", ptr %t488, i32 0, i32 3
  %t491 = load ptr, ptr %t490, !tbaa !29
  %t493 = getelementptr %"compiler/ast:Sig", ptr %t491, i32 0, i32 0
  %t494 = load { i64, ptr }, ptr %t493, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t487, { i64, ptr } %t494)
  br label %bb136
bb136:
  %t497 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t497, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) })
  br label %bb137
bb137:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load ptr, ptr %l28, !tbaa !29
  %t502 = getelementptr %"compiler/ast:Func", ptr %t500, i32 0, i32 3
  %t503 = load ptr, ptr %t502, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t499, ptr %t503)
  br label %bb138
bb138:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load ptr, ptr %l28, !tbaa !29
  %t509 = getelementptr %"compiler/ast:Func", ptr %t507, i32 0, i32 4
  %t510 = load { i64, ptr }, ptr %t509, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t506, { i64, ptr } %t510)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s29)
  br label %bb140
bb140:
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_8ed9030be27b37c_c547c050429384d8)
  unreachable
bb142:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l34 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t15, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TypeDecl", ptr %t18, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t17, i32 %t21)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ebbf44be12946e17_d86a8718ca658f6b)
  unreachable
bb13:
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d185, i32 0, i32 1) })
  br label %bb14
bb14:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2einPlaceName(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb15
bb15:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:TypeDecl", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t30, { i64, ptr } %t34)
  br label %bb16
bb16:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TypeDecl", ptr %t37, i32 0, i32 4
  %t40 = load i32, ptr %t39, !range !{i32 0, i32 3}
  %t42 = trunc i64 1 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t45, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:TypeDecl", ptr %t47, i32 0, i32 4
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 3}
  %t52 = trunc i64 2 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t55 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t55, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d187, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeDecl", ptr %t57, i32 0, i32 5
  %t60 = load i1, ptr %t59, !tbaa !21
  br i1 %t60, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t62, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d188, i32 0, i32 1) })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/ast:TypeDecl", ptr %t64, i32 0, i32 2
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t69 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t69, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d189, i32 0, i32 1) })
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t71 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t71, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d190, i32 0, i32 1) })
  br label %bb33
bb33:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l34, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/ast:TypeDecl", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_2cc3368697e3422f_b87e422715826713)
  unreachable
bb35:
  br label %bb36
bb36:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/ast:TypeDecl", ptr %t81, i32 0, i32 3
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t85, ptr %t84)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 116}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 69 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t23 = trunc i64 94 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l7, !tbaa !21
  br label %bb55
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 28}
  %t34 = icmp eq i64 %t32, 1
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb55
bb15:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 28}
  %t43 = icmp eq i64 %t41, 5
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb18, label %bb19
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l30
  br label %bb21
bb21:
  %t54 = load i1, ptr %l30, !tbaa !21
  store i1 %t54, ptr %l7, !tbaa !21
  br label %bb55
bb22:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb23, label %bb24
bb23:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 28}
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t63 = load i1, ptr %l32, !tbaa !21
  br i1 %t63, label %bb25, label %bb26
bb25:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t70)
  store i1 %t72, ptr %l38
  br label %bb28
bb28:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  br label %bb55
bb29:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb30, label %bb31
bb30:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 28}
  %t81 = icmp eq i64 %t79, 10
  store i1 %t81, ptr %l40, !tbaa !21
  br label %bb31
bb31:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l46
  br label %bb35
bb35:
  %t92 = load i1, ptr %l46, !tbaa !21
  store i1 %t92, ptr %l7, !tbaa !21
  br label %bb55
bb36:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb37, label %bb38
bb37:
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 28}
  %t100 = icmp eq i64 %t98, 12
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb38
bb38:
  %t101 = load i1, ptr %l48, !tbaa !21
  br i1 %t101, label %bb39, label %bb40
bb39:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t108)
  store i1 %t110, ptr %l54
  br label %bb42
bb42:
  %t111 = load i1, ptr %l54, !tbaa !21
  store i1 %t111, ptr %l7, !tbaa !21
  br label %bb55
bb43:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t113 = load ptr, ptr %l55, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb44, label %bb45
bb44:
  %t116 = load ptr, ptr %l55, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 28}
  %t119 = icmp eq i64 %t117, 13
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb45
bb45:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb46, label %bb47
bb46:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l6, !tbaa !29
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t129 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t127)
  store i1 %t129, ptr %l62
  br label %bb49
bb49:
  %t130 = load i1, ptr %l62, !tbaa !21
  store i1 %t130, ptr %l7, !tbaa !21
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_d36f35e5fb1d5e1e_8f0854d909464512)
  unreachable
bb55:
  %t131 = load i1, ptr %l7, !tbaa !21
  store i1 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d2 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d6 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" link " }>, align 8
@.d9 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d13 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d15 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" destruct" }>, align 8
@.d16 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"destruct" }>, align 8
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" error" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d31 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" not in " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"range " }>, align 8
@.d61 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"default" }>, align 8
@.d62 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d64 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d65 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d67 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d68 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"link " }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d71 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d73 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"export " }>, align 8
@.d74 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d81 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d83 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d84 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" else" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"is" }>, align 8
@.d88 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"is" }>, align 8
@.d89 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"is not" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d95 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d97 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d98 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d99 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ~ " }>, align 8
@.d100 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d103 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d104 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"for" }>, align 8
@.d105 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d106 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d107 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d108 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d109 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"comptime " }>, align 8
@.d110 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d111 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d113 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d114 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"do" }>, align 8
@.d115 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d118 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"yield " }>, align 8
@.d119 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"become " }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d121 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d122 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d123 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d126 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d127 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"spawn " }>, align 8
@.d128 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d129 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d130 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"join" }>, align 8
@.d131 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"errdefer" }>, align 8
@.d132 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"defer" }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d134 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d136 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d137 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d138 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d139 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d140 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d141 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" else" }>, align 8
@.d142 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"else" }>, align 8
@.d143 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d145 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d146 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d147 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d148 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"weak " }>, align 8
@.d149 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d151 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d152 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d153 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"any " }>, align 8
@.d154 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d155 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d156 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d157 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"weak mut " }>, align 8
@.d158 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"weak " }>, align 8
@.d159 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"mut" }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d161 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"struct" }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d164 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"enum " }>, align 8
@.d165 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d166 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d167 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d168 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d169 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d170 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d171 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d172 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trait " }>, align 8
@.d173 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"extends " }>, align 8
@.d174 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d176 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d177 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d178 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d179 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d180 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d181 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d182 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d183 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d184 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"extern type " }>, align 8
@.d185 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d186 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" immut" }>, align 8
@.d187 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" unique" }>, align 8
@.d188 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" packed" }>, align 8
@.d189 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" extends" }>, align 8
@.d190 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_97fb03c83c422508_396f69b1ea6ff204 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexternFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7f8607ca82c86e8f_41d7f7ff4057cd03 = external constant [0 x i8]
declare i1 @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecolonBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %a0)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_577bb2401887ee03_bd83bee27b444ed7 = external constant [0 x i8]
@olang_loc_47b511f5ef6d9e74_baf04e552c3da2b8 = external constant [0 x i8]
@olang_loc_e6dde321a76d1169_ef8c066898e78ecd = external constant [0 x i8]
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_af8532b2afdd02b1_ed9973e7a2ad66a5 = external constant [0 x i8]
@olang_loc_c8c27977e1720628_5d646bf05a6faac = external constant [0 x i8]
@olang_loc_240300a98391f326_30555605a48ff2da = external constant [0 x i8]
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
@olang_loc_62b5cb0662a9bd0d_8638c84775e31461 = external constant [0 x i8]
@olang_loc_450b6e4c0e54f911_1dcad8b8a27ff01d = external constant [0 x i8]
@olang_loc_375b6e3c7dc4e00a_588d095da59240b6 = external constant [0 x i8]
@olang_loc_e1b6c554c381b10b_f727e5cc4e37ef67 = external constant [0 x i8]
@olang_loc_ba8e182b2fbe7a1c_99d493faf8d7cb48 = external constant [0 x i8]
@olang_loc_a676b6f90e9ab794_adfa384105d75b88 = external constant [0 x i8]
@olang_loc_8218e8270bec8206_ca247080b262927a = external constant [0 x i8]
@olang_loc_888c02f4e7827027_c6893dabd191b6cb = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_592dd44f1f3b971c_93db6877d1071d30 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_19d95224243c5dd3_a108b37826b1917 = external constant [0 x i8]
@olang_loc_b263a57856eac862_46b7b1031f9001a6 = external constant [0 x i8]
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_9166140a1ac8280_ddd22134593fa34 = external constant [0 x i8]
@olang_loc_69b21e264e8a714a_b3e97d9d77526506 = external constant [0 x i8]
@olang_loc_8585d6fe8f316a51_b60a12ce50df87ed = external constant [0 x i8]
@olang_loc_eabe3ddcfaef285c_106dba970e52f8d8 = external constant [0 x i8]
@olang_loc_14b8182deed7e34b_cfe8cf3ea4c448f7 = external constant [0 x i8]
@olang_loc_1f325493bec1d846_692c03b2e92ac30a = external constant [0 x i8]
declare ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eFuncSig(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsWeak(ptr %v0, ptr %a0)
declare ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eUnweak(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_9034b6aed20fb51a_d179ca40c5e654ce = external constant [0 x i8]
@olang_loc_8cd05a7785ffddf0_abfc69165374635c = external constant [0 x i8]
declare void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c53cd7dd70350acf_d5f64367475d1e4b = external constant [0 x i8]
@olang_loc_565cf8a51c2b309e_2af0495fa70fac4a = external constant [0 x i8]
@olang_loc_8ed9030be27b37c_c547c050429384d8 = external constant [0 x i8]
@olang_loc_ebbf44be12946e17_d86a8718ca658f6b = external constant [0 x i8]
@olang_loc_2cc3368697e3422f_b87e422715826713 = external constant [0 x i8]
@olang_loc_d36f35e5fb1d5e1e_8f0854d909464512 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
