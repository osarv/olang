; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1dcc5c98f6ba0c1a_a73fbcdffad54c26 = weak_odr constant [48 x i8] c"std/prelude/vec.olang:266: unreachable reached\0A\00"
@olang_loc_2cd882cac0fbadc5_c03728255a828271 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_584a5b309f9617c3_19cebfea604189a7 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_7ca9792b6e18dccf_4b735a4e3fd9b403 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_8d86fc6ce468287_b2554197f581caab = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_925fabed9d43dece_1577de7e619da4d2 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:231: slice bounds out of range\0A\00"
@olang_loc_93075c37432f356c_6dec0e1ba68e8fc0 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_9fbcac4ab390f5ba_a9c421edcc4f6186 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:267: slice bounds out of range\0A\00"
@olang_loc_be4f7056fe2b22a1_b4ec2f4dce2fd965 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_f9a298574f6fcd2c_98d69e8b2d03d648 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:265: slice bounds out of range\0A\00"
@olang_loc_fdd2b0eaf959dd0f_4d6539d3cd8946c3 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
