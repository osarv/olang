; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1e2a74573405b32f_8b849e969b747243 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_3b80568893693b06_6721000e43a4efa2 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:238: array length out of range\0A\00"
@olang_loc_6235c2ec36083217_44642b1077aad9eb = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_85c4fcee59add7bb_821fa9b129c7abe7 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:237: array length out of range\0A\00"
@olang_loc_87b05058a9e8049b_867a45e0d7857c57 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:237: array length out of range\0A\00"
@olang_loc_887360f38b90b426_2a33a0f3f44377f2 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:238: array length out of range\0A\00"
