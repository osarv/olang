; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/parse:NameList" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/parse:stackMarks" = type { i64, i64, i64, i64, i64, i64, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
define dso_local ptr @compiler_2fparse_2eGenericFnNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/scan:Tokens", ptr %a1, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 2
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l23, !tbaa !24
  store i64 %t42, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l20, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l41, !tbaa !27
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr %"compiler/token:Token", ptr %t66, i64 %t63
  %t68 = getelementptr %"compiler/token:Token", ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68
  %t71 = trunc i64 38 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb12, label %bb13
bb12:
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t74, ptr %l46, !tbaa !27
  %t75 = load i64, ptr %l9, !tbaa !24
  %t77 = add i64 %t75, 1
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"compiler/token:Token", ptr %t80, i64 %t77
  %t82 = getelementptr %"compiler/token:Token", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82
  %t85 = trunc i64 1 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l45, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb14
bb14:
  %t88 = load i1, ptr %l45, !tbaa !21
  br i1 %t88, label %bb15, label %bb16
bb15:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l52, !tbaa !27
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t90, 2
  %t94 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %t95, i64 %t92
  %t97 = getelementptr %"compiler/token:Token", ptr %t96, i32 0, i32 0
  %t98 = load i32, ptr %t97
  %t100 = trunc i64 79 to i32
  %t101 = icmp eq i32 %t98, %t100
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb17
bb17:
  %t103 = load i1, ptr %l51, !tbaa !21
  br i1 %t103, label %bb18, label %bb19
bb18:
  %t104 = load ptr, ptr %l2, !tbaa !29
  store ptr %t104, ptr %l57, !tbaa !29
  store { i64, ptr } %a0, ptr %l58, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l59, !tbaa !27
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = add i64 %t107, 1
  %t111 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr %"compiler/token:Token", ptr %t112, i64 %t109
  %t114 = getelementptr %"compiler/token:Token", ptr %t113, i32 0, i32 2
  %t115 = load i32, ptr %t114, !tbaa !23
  %t117 = sext i32 %t115 to i64
  store i64 %t117, ptr %l63, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t118, ptr %l64, !tbaa !27
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = add i64 %t119, 1
  %t123 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/token:Token", ptr %t124, i64 %t121
  %t126 = getelementptr %"compiler/token:Token", ptr %t125, i32 0, i32 3
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = sext i32 %t127 to i64
  store i64 %t129, ptr %l68, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l69, !tbaa !24
  %t132 = load i64, ptr %l63, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  br i1 %t133, label %bb20, label %bb21
bb19:
  br label %bb27
bb20:
  %t135 = load i64, ptr %l63, !tbaa !24
  %t136 = load i64, ptr %l68, !tbaa !24
  %t137 = icmp sle i64 %t135, %t136
  br i1 %t137, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d732b4b75ca0d086_f16e80b591ad44e2)
  unreachable
bb22:
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = load i64, ptr %l69, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  br i1 %t141, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_d732b4b75ca0d086_f16e80b591ad44e2)
  unreachable
bb24:
  %t143 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = load i64, ptr %l63, !tbaa !24
  %t146 = load i64, ptr %l68, !tbaa !24
  %t147 = getelementptr i8, ptr %t144, i64 %t145
  %t148 = sub i64 %t146, %t145
  %t149 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  %t151 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t151, { i64, ptr } %t150)
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d732b4b75ca0d086_f16e80b591ad44e2)
  unreachable
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t153 = load i64, ptr %l8, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l8, !tbaa !24
  br label %bb8
bb29:
  %t157 = load ptr, ptr %l2, !tbaa !29
  store ptr %t157, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fparse_2ebuiltinType(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb21
bb19:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t27, ptr %l17
  br label %bb20
bb20:
  %t28 = load i1, ptr %l17, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb21
bb21:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb25
bb23:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t32, ptr %l20
  br label %bb24
bb24:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb25
bb25:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb29
bb27:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t37, ptr %l23
  br label %bb28
bb28:
  %t38 = load i1, ptr %l23, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb29
bb29:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb33
bb31:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t42, ptr %l26
  br label %bb32
bb32:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb33
bb33:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb37
bb35:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t47, ptr %l29
  br label %bb36
bb36:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb37
bb37:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb41
bb39:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t52, ptr %l32
  br label %bb40
bb40:
  %t53 = load i1, ptr %l32, !tbaa !21
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb41
bb41:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb45
bb43:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t57, ptr %l35
  br label %bb44
bb44:
  %t58 = load i1, ptr %l35, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb45
bb45:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb49
bb47:
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t62, ptr %l38
  br label %bb48
bb48:
  %t63 = load i1, ptr %l38, !tbaa !21
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb49
bb49:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb53
bb51:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t67, ptr %l41
  br label %bb52
bb52:
  %t68 = load i1, ptr %l41, !tbaa !21
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i1, ptr %l39, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecomparison(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 75 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 77 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb12
bb10:
  %t27 = load i32, ptr %l1
  %t29 = call i1 @compiler_2fparse_2eisOrdering(i32 %t27)
  store i1 %t29, ptr %l15
  br label %bb11
bb11:
  %t30 = load i1, ptr %l15, !tbaa !21
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t31 = load i1, ptr %l13, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb15
bb14:
  %t32 = load i32, ptr %l1
  %t34 = trunc i64 27 to i32
  %t35 = icmp eq i32 %t32, %t34
  store i1 %t35, ptr %l16, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l16, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t39 = load ptr, ptr %l19, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 7
  store i1 %t45, ptr %l20, !tbaa !21
  br label %bb18
bb18:
  %t46 = load i1, ptr %l20, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  br label %bb33
bb20:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb21, label %bb22
bb21:
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 6
  store i1 %t54, ptr %l24, !tbaa !21
  br label %bb22
bb22:
  %t55 = load i1, ptr %l24, !tbaa !21
  br i1 %t55, label %bb23, label %bb24
bb23:
  br label %bb33
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t60 = load ptr, ptr %l27, !tbaa !29
  %t61 = load i64, ptr %t60
  %t63 = icmp eq i64 %t61, 10
  store i1 %t63, ptr %l28, !tbaa !21
  br label %bb26
bb26:
  %t64 = load i1, ptr %l28, !tbaa !21
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb29, label %bb30
bb29:
  %t69 = load ptr, ptr %l31, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 9
  store i1 %t72, ptr %l32, !tbaa !21
  br label %bb30
bb30:
  %t73 = load i1, ptr %l32, !tbaa !21
  br i1 %t73, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Oracle", ptr %t5, i32 0, i32 0
  store ptr %t7, ptr %l7, !tbaa !29
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v3, ptr %a1, { i64, ptr } %t9)
  store i32 %t12, ptr %l10
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Oracle", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = extractvalue { i64, ptr } %t16, 0
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t25 = extractvalue { i64, ptr } %t17, 1
  %t26 = extractvalue { i64, ptr } %t17, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t19, i64 %t20)
  %t29 = getelementptr i8, ptr %t28, i64 %t20
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = getelementptr i8, ptr %t29, i64 %t22
  call void @olang_textcopy(ptr %t30, ptr %t25, i64 %t26)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } %t39, i1 true)
  br label %bb6
bb4:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t43 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t42, i32 %t43, i1 true)
  br label %bb5
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Oracle", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l7, !tbaa !29
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v3, ptr %a1, { i64, ptr } %t9)
  store i32 %t12, ptr %l10
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Oracle", ptr %t13, i32 0, i32 3
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = extractvalue { i64, ptr } %t16, 0
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t25 = extractvalue { i64, ptr } %t17, 1
  %t26 = extractvalue { i64, ptr } %t17, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t19, i64 %t20)
  %t29 = getelementptr i8, ptr %t28, i64 %t20
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = getelementptr i8, ptr %t29, i64 %t22
  call void @olang_textcopy(ptr %t30, ptr %t25, i64 %t26)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } %t39, i1 true)
  br label %bb6
bb4:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t43 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t42, i32 %t43, i1 true)
  br label %bb5
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 7
  store i32 0, ptr %t9
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 11
  store i1 false, ptr %t12, !tbaa !21
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t13, i32 0, i32 12
  store i1 false, ptr %t15, !tbaa !21
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 17
  store i64 0, ptr %t18, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/parse:Parser", ptr %t19, i32 0, i32 18
  store i1 false, ptr %t21, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 20
  store i64 0, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 21
  store i1 false, ptr %t27, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t30, i64 0)
  br label %bb1
bb1:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t32)
  %t35 = extractvalue { i32, ptr } %t34, 1
  %t36 = extractvalue { i32, ptr } %t34, 0
  store i32 %t36, ptr %l17
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb3, label %ok.38
ok.38:
  store ptr %t35, ptr %l16
  br label %bb2
bb2:
  %t39 = load ptr, ptr %l16, !tbaa !29
  store ptr %t39, ptr %l14, !tbaa !29
  br label %bb4
bb3:
  %t40 = load i32, ptr %l17, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  %t50 = insertvalue { i32, ptr } zeroinitializer, i32 %t48, 0
  store { i32, ptr } %t50, ptr %rv
  br label %ret
bb4:
  %t51 = load ptr, ptr %l14, !tbaa !29
  %t52 = insertvalue { i32, ptr } zeroinitializer, ptr %t51, 1
  store { i32, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i32
  %l15 = alloca i32
  %l20 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t7)
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t9, i32 0)
  store i1 %t12, ptr %l8
  br label %bb4
bb4:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %bb19
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t14, i32 95)
  store i1 %t17, ptr %l11
  br label %bb8
bb8:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s3, ptr %t19, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i32 %t21, ptr %l13
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb12, label %ok.23
ok.23:
  br label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  br label %bb14
bb14:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l15
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb16:
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %t27)
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb2
bb19:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 37
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t31, i64 %t32)
  store { i64, ptr } %t35, ptr %l20
  br label %bb20
bb20:
  %t36 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i1
  %l11 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  store i32 %a1, ptr %l5
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l3, ptr %l5)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t12)
  store i32 %t14, ptr %l11
  br label %bb6
bb6:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l14 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l25 = alloca i64
  %l28 = alloca { i64, ptr }
  %l35 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 7
  %t15 = load i32, ptr %t14
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 9
  store i32 %t15, ptr %t18
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t19, i32 0, i32 7
  store i32 0, ptr %t22
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/scan:Tokens", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l14, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 6
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = sub i64 %t34, 1
  %t38 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr %"compiler/token:Token", ptr %t39, i64 %t36
  %t41 = getelementptr %"compiler/token:Token", ptr %t40, i32 0, i32 3
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 10
  store i32 %t42, ptr %t45, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 8
  %t49 = load i32, ptr %t48, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l21, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 6
  %t56 = load i64, ptr %t55, !tbaa !24
  %t59 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t52, i64 %t56)
  store i64 %t59, ptr %l25
  br label %bb4
bb4:
  %t60 = load i64, ptr %l25, !tbaa !24
  %t61 = load ptr, ptr %l21, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t61, i32 0, i32 6
  store i64 %t60, ptr %t62, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/scan:Tokens", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l28, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 6
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"compiler/token:Token", ptr %t76, i64 %t73
  %t78 = load %"compiler/token:Token", ptr %t77
  store %"compiler/token:Token" %t78, ptr %l1
  %t80 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t81 = load i32, ptr %t80
  %t83 = trunc i64 0 to i32
  %t84 = icmp eq i32 %t81, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb5, label %bb6
bb5:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l35, !tbaa !29
  %t89 = load ptr, ptr %l35, !tbaa !29
  %t90 = getelementptr %"compiler/parse:Parser", ptr %t89, i32 0, i32 6
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = add i64 %t91, 1
  %t95 = load ptr, ptr %l35, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t95, i32 0, i32 6
  store i64 %t93, ptr %t96, !tbaa !24
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t97 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t98 = load i32, ptr %t97
  %t100 = trunc i64 8 to i32
  %t101 = icmp eq i32 %t98, %t100
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb8, label %bb9
bb8:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t107 = load i32, ptr %t106
  %t110 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 9
  store i32 %t107, ptr %t110
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t113 = load i32, ptr %t112, !tbaa !23
  %t116 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 10
  store i32 %t113, ptr %t116, !tbaa !23
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t117 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t118 = load i32, ptr %t117, !tbaa !23
  store i32 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i1
  %l28 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/parse:Parser", ptr %t2, i32 0, i32 6
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t1, i64 %t5)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l8, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 7
  %t14 = load i32, ptr %t13
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  store i64 1, ptr %l13, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = load i64, ptr %l13, !tbaa !24
  %t23 = sub i64 %t21, %t22
  store i64 %t23, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/scan:Tokens", ptr %t33, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t41 = icmp slt i64 %t29, %t38
  store i1 %t41, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t43 = load i1, ptr %l17, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t47, 1
  %t52 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t46, i64 %t49)
  store i64 %t52, ptr %l28
  br label %bb12
bb12:
  %t53 = load i64, ptr %l28, !tbaa !24
  store i64 %t53, ptr %l2, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = sub i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  br label %bb13
bb13:
  br label %bb5
bb14:
  %t58 = load i64, ptr %l2, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eanyHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l6 = alloca i1
  %l8 = alloca i32
  %l12 = alloca i1
  %l14 = alloca %"compiler/token:Token"
  %l16 = alloca i1
  %l19 = alloca %"compiler/token:Token"
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t11, i64 1)
  store i32 %t13, ptr %l8
  br label %bb3
bb3:
  %t14 = load i32, ptr %l8
  %t16 = trunc i64 1 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l6, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb9
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t22, i64 1)
  store %"compiler/token:Token" %t24, ptr %l14
  br label %bb7
bb7:
  %t25 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t26 = load %"compiler/token:Token", ptr %l14
  %t28 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t26, i8 %t25)
  store i1 %t28, ptr %l16
  br label %bb8
bb8:
  %t29 = load i1, ptr %l16, !tbaa !21
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l12, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t32)
  store %"compiler/token:Token" %t34, ptr %l19
  br label %bb13
bb13:
  %t35 = load %"compiler/token:Token", ptr %l19
  store %"compiler/token:Token" %t35, ptr %l1
  %t36 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t42 = sub i32 %t37, %t39
  %t44 = icmp eq i32 %t42, 3
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/source:Source", ptr %t49, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l27, !tbaa !27
  %t53 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  store i64 %t56, ptr %l29, !tbaa !24
  %t57 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = sext i32 %t58 to i64
  store i64 %t60, ptr %l31, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l32, !tbaa !24
  %t63 = load i64, ptr %l29, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb16, label %bb17
bb15:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb23
bb16:
  %t66 = load i64, ptr %l29, !tbaa !24
  %t67 = load i64, ptr %l31, !tbaa !24
  %t68 = icmp sle i64 %t66, %t67
  br i1 %t68, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bb3818bbd2107504_76faa65ecf814280)
  unreachable
bb18:
  %t70 = load i64, ptr %l31, !tbaa !24
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bb3818bbd2107504_76faa65ecf814280)
  unreachable
bb20:
  %t74 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l29, !tbaa !24
  %t77 = load i64, ptr %l31, !tbaa !24
  %t78 = getelementptr i8, ptr %t75, i64 %t76
  %t79 = sub i64 %t77, %t76
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t81, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t83, ptr %l37
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bb3818bbd2107504_76faa65ecf814280)
  unreachable
bb22:
  %t84 = load i1, ptr %l37, !tbaa !21
  store i1 %t84, ptr %l24, !tbaa !21
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t85 = load i1, ptr %l24, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l17 = alloca ptr
  %l28 = alloca i64
  %l31 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca ptr
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i32
  %l60 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca i32
  %l81 = alloca ptr
  %l90 = alloca ptr
  %l102 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i32
  %l108 = alloca ptr
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i32
  %l125 = alloca ptr
  %l136 = alloca i1
  %l141 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l145 = alloca i32
  %l147 = alloca ptr
  %l157 = alloca i32
  %l160 = alloca %"compiler/source:Span"
  %l162 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l169 = alloca ptr
  %s2 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t434 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 92)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l12
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t9 = load i32, ptr %l11, !tbaa !23
  store i32 %t9, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l12, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l3, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 11
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 17
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 17
  store i64 %t34, ptr %t37, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 18
  %t41 = load i1, ptr %t40, !tbaa !21
  store i1 %t41, ptr %l4, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 19
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l5, !tbaa !21
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 18
  store i1 false, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 19
  store i1 true, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/parse:Parser", ptr %t54, i32 0, i32 30
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l28
  br label %bb4
bb4:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l6, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t60, i32 93)
  store i1 %t63, ptr %l31
  br label %bb5
bb5:
  %t64 = load i1, ptr %l31, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb6, label %bb7
bb6:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t67, i32 91)
  store i1 %t70, ptr %l35
  br label %bb8
bb7:
  br label %bb44
bb8:
  %t71 = load i1, ptr %l35, !tbaa !21
  br i1 %t71, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb12
bb10:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t72, i32 95)
  store i1 %t75, ptr %l39
  br label %bb11
bb11:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb12
bb12:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  %t80 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 93)
  store { i64, ptr } %t80, ptr %l42
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t81 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  %t83 = extractvalue { i64, ptr } %t81, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t90 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t88, { i64, ptr } %t87)
  store i32 %t90, ptr %l44
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb17, label %ok.92
ok.92:
  br label %bb16
bb16:
  br label %bb18
bb17:
  %t93 = load i32, ptr %l44, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  call void @__olang_scope_close(ptr %s2)
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l46, !tbaa !29
  %t103 = load ptr, ptr %l46, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t103, i32 0, i32 17
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = sub i64 %t105, 1
  %t109 = load ptr, ptr %l46, !tbaa !29
  %t110 = getelementptr %"compiler/parse:Parser", ptr %t109, i32 0, i32 17
  store i64 %t107, ptr %t110, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i1, ptr %l3, !tbaa !21
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 11
  store i1 %t112, ptr %t115, !tbaa !21
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i1, ptr %l4, !tbaa !21
  %t120 = getelementptr %"compiler/parse:Parser", ptr %t116, i32 0, i32 18
  store i1 %t117, ptr %t120, !tbaa !21
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i1, ptr %l5, !tbaa !21
  %t125 = getelementptr %"compiler/parse:Parser", ptr %t121, i32 0, i32 19
  store i1 %t122, ptr %t125, !tbaa !21
  %t127 = insertvalue { i32, ptr } zeroinitializer, i32 %t101, 0
  store { i32, ptr } %t127, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t128)
  %t131 = extractvalue { i32, ptr } %t130, 1
  %t132 = extractvalue { i32, ptr } %t130, 0
  store i32 %t132, ptr %l58
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb21, label %ok.134
ok.134:
  store ptr %t131, ptr %l57
  br label %bb20
bb20:
  %t135 = load ptr, ptr %l57, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  br label %bb22
bb21:
  %t136 = load i32, ptr %l58, !tbaa !23
  %t137 = lshr i32 %t136, 16
  %t138 = and i32 %t136, 65535
  %t139 = icmp eq i32 %t137, 1
  %t140 = select i1 %t139, i32 1, i32 0
  %t141 = icmp eq i32 %t136, 0
  %t142 = shl i32 %t140, 16
  %t143 = or i32 %t142, %t138
  %t144 = select i1 %t141, i32 0, i32 %t143
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l60, !tbaa !29
  %t146 = load ptr, ptr %l60, !tbaa !29
  %t147 = getelementptr %"compiler/parse:Parser", ptr %t146, i32 0, i32 17
  %t148 = load i64, ptr %t147, !tbaa !24
  %t150 = sub i64 %t148, 1
  %t152 = load ptr, ptr %l60, !tbaa !29
  %t153 = getelementptr %"compiler/parse:Parser", ptr %t152, i32 0, i32 17
  store i64 %t150, ptr %t153, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i1, ptr %l3, !tbaa !21
  %t158 = getelementptr %"compiler/parse:Parser", ptr %t154, i32 0, i32 11
  store i1 %t155, ptr %t158, !tbaa !21
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i1, ptr %l4, !tbaa !21
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 18
  store i1 %t160, ptr %t163, !tbaa !21
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i1, ptr %l5, !tbaa !21
  %t168 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 19
  store i1 %t165, ptr %t168, !tbaa !21
  %t170 = insertvalue { i32, ptr } zeroinitializer, i32 %t144, 0
  store { i32, ptr } %t170, ptr %rv
  br label %ret
bb22:
  %t171 = load ptr, ptr %l55, !tbaa !29
  store ptr %t171, ptr %l7, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t172)
  store i1 %t174, ptr %l70
  br label %bb23
bb23:
  %t175 = load i1, ptr %l70, !tbaa !21
  br i1 %t175, label %bb24, label %bb25
bb24:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l1, !tbaa !23
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = load ptr, ptr %l7, !tbaa !29
  %t186 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %t176, i32 %t177, ptr %t178, ptr %t180, i32 93)
  %t187 = extractvalue { i32, ptr } %t186, 1
  %t188 = extractvalue { i32, ptr } %t186, 0
  store i32 %t188, ptr %l79
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb27, label %ok.190
ok.190:
  store ptr %t187, ptr %l78
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t191 = load ptr, ptr %l78, !tbaa !29
  store ptr %t191, ptr %l71, !tbaa !29
  br label %bb28
bb27:
  %t192 = load i32, ptr %l79, !tbaa !23
  %t193 = lshr i32 %t192, 16
  %t194 = and i32 %t192, 65535
  %t195 = icmp eq i32 %t193, 1
  %t196 = select i1 %t195, i32 1, i32 0
  %t197 = icmp eq i32 %t192, 0
  %t198 = shl i32 %t196, 16
  %t199 = or i32 %t198, %t194
  %t200 = select i1 %t197, i32 0, i32 %t199
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l81, !tbaa !29
  %t202 = load ptr, ptr %l81, !tbaa !29
  %t203 = getelementptr %"compiler/parse:Parser", ptr %t202, i32 0, i32 17
  %t204 = load i64, ptr %t203, !tbaa !24
  %t206 = sub i64 %t204, 1
  %t208 = load ptr, ptr %l81, !tbaa !29
  %t209 = getelementptr %"compiler/parse:Parser", ptr %t208, i32 0, i32 17
  store i64 %t206, ptr %t209, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i1, ptr %l3, !tbaa !21
  %t214 = getelementptr %"compiler/parse:Parser", ptr %t210, i32 0, i32 11
  store i1 %t211, ptr %t214, !tbaa !21
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i1, ptr %l4, !tbaa !21
  %t219 = getelementptr %"compiler/parse:Parser", ptr %t215, i32 0, i32 18
  store i1 %t216, ptr %t219, !tbaa !21
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i1, ptr %l5, !tbaa !21
  %t224 = getelementptr %"compiler/parse:Parser", ptr %t220, i32 0, i32 19
  store i1 %t221, ptr %t224, !tbaa !21
  %t226 = insertvalue { i32, ptr } zeroinitializer, i32 %t200, 0
  store { i32, ptr } %t226, ptr %rv
  br label %ret
bb28:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l90, !tbaa !29
  %t228 = load ptr, ptr %l90, !tbaa !29
  %t229 = getelementptr %"compiler/parse:Parser", ptr %t228, i32 0, i32 17
  %t230 = load i64, ptr %t229, !tbaa !24
  %t232 = sub i64 %t230, 1
  %t234 = load ptr, ptr %l90, !tbaa !29
  %t235 = getelementptr %"compiler/parse:Parser", ptr %t234, i32 0, i32 17
  store i64 %t232, ptr %t235, !tbaa !24
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i1, ptr %l3, !tbaa !21
  %t240 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 11
  store i1 %t237, ptr %t240, !tbaa !21
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i1, ptr %l4, !tbaa !21
  %t245 = getelementptr %"compiler/parse:Parser", ptr %t241, i32 0, i32 18
  store i1 %t242, ptr %t245, !tbaa !21
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i1, ptr %l5, !tbaa !21
  %t250 = getelementptr %"compiler/parse:Parser", ptr %t246, i32 0, i32 19
  store i1 %t247, ptr %t250, !tbaa !21
  %t251 = load ptr, ptr %l71, !tbaa !29
  %t252 = insertvalue { i32, ptr } zeroinitializer, ptr %t251, 1
  store { i32, ptr } %t252, ptr %rv
  br label %ret
bb29:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/parse:Parser", ptr %t253, i32 0, i32 30
  %t256 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t255, ptr %t256)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t262 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t259, i32 93)
  %t263 = extractvalue { i32, i1 } %t262, 1
  %t264 = extractvalue { i32, i1 } %t262, 0
  store i32 %t264, ptr %l106
  %t265 = icmp ne i32 %t264, 0
  br i1 %t265, label %bb33, label %ok.266
ok.266:
  store i1 %t263, ptr %l105
  br label %bb32
bb32:
  %t267 = load i1, ptr %l105, !tbaa !21
  store i1 %t267, ptr %l102, !tbaa !21
  br label %bb34
bb33:
  %t268 = load i32, ptr %l106, !tbaa !23
  %t269 = lshr i32 %t268, 16
  %t270 = and i32 %t268, 65535
  %t271 = icmp eq i32 %t269, 1
  %t272 = select i1 %t271, i32 1, i32 0
  %t273 = icmp eq i32 %t268, 0
  %t274 = shl i32 %t272, 16
  %t275 = or i32 %t274, %t270
  %t276 = select i1 %t273, i32 0, i32 %t275
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l108, !tbaa !29
  %t278 = load ptr, ptr %l108, !tbaa !29
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t278, i32 0, i32 17
  %t280 = load i64, ptr %t279, !tbaa !24
  %t282 = sub i64 %t280, 1
  %t284 = load ptr, ptr %l108, !tbaa !29
  %t285 = getelementptr %"compiler/parse:Parser", ptr %t284, i32 0, i32 17
  store i64 %t282, ptr %t285, !tbaa !24
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load i1, ptr %l3, !tbaa !21
  %t290 = getelementptr %"compiler/parse:Parser", ptr %t286, i32 0, i32 11
  store i1 %t287, ptr %t290, !tbaa !21
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i1, ptr %l4, !tbaa !21
  %t295 = getelementptr %"compiler/parse:Parser", ptr %t291, i32 0, i32 18
  store i1 %t292, ptr %t295, !tbaa !21
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load i1, ptr %l5, !tbaa !21
  %t300 = getelementptr %"compiler/parse:Parser", ptr %t296, i32 0, i32 19
  store i1 %t297, ptr %t300, !tbaa !21
  %t302 = insertvalue { i32, ptr } zeroinitializer, i32 %t276, 0
  store { i32, ptr } %t302, ptr %rv
  br label %ret
bb34:
  %t303 = load i1, ptr %l102, !tbaa !21
  %t304 = xor i1 %t303, true
  br i1 %t304, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/parse:Parser", ptr %t306, i32 0, i32 30
  store ptr %t308, ptr %l119, !tbaa !29
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t309)
  %t312 = extractvalue { i32, ptr } %t311, 1
  %t313 = extractvalue { i32, ptr } %t311, 0
  store i32 %t313, ptr %l123
  %t314 = icmp ne i32 %t313, 0
  br i1 %t314, label %bb39, label %ok.315
ok.315:
  store ptr %t312, ptr %l122
  br label %bb38
bb38:
  %t316 = load ptr, ptr %l122, !tbaa !29
  store ptr %t316, ptr %l120, !tbaa !29
  br label %bb40
bb39:
  %t317 = load i32, ptr %l123, !tbaa !23
  %t318 = lshr i32 %t317, 16
  %t319 = and i32 %t317, 65535
  %t320 = icmp eq i32 %t318, 1
  %t321 = select i1 %t320, i32 1, i32 0
  %t322 = icmp eq i32 %t317, 0
  %t323 = shl i32 %t321, 16
  %t324 = or i32 %t323, %t319
  %t325 = select i1 %t322, i32 0, i32 %t324
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l125, !tbaa !29
  %t327 = load ptr, ptr %l125, !tbaa !29
  %t328 = getelementptr %"compiler/parse:Parser", ptr %t327, i32 0, i32 17
  %t329 = load i64, ptr %t328, !tbaa !24
  %t331 = sub i64 %t329, 1
  %t333 = load ptr, ptr %l125, !tbaa !29
  %t334 = getelementptr %"compiler/parse:Parser", ptr %t333, i32 0, i32 17
  store i64 %t331, ptr %t334, !tbaa !24
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i1, ptr %l3, !tbaa !21
  %t339 = getelementptr %"compiler/parse:Parser", ptr %t335, i32 0, i32 11
  store i1 %t336, ptr %t339, !tbaa !21
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load i1, ptr %l4, !tbaa !21
  %t344 = getelementptr %"compiler/parse:Parser", ptr %t340, i32 0, i32 18
  store i1 %t341, ptr %t344, !tbaa !21
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i1, ptr %l5, !tbaa !21
  %t349 = getelementptr %"compiler/parse:Parser", ptr %t345, i32 0, i32 19
  store i1 %t346, ptr %t349, !tbaa !21
  %t351 = insertvalue { i32, ptr } zeroinitializer, i32 %t325, 0
  store { i32, ptr } %t351, ptr %rv
  br label %ret
bb40:
  %t352 = load ptr, ptr %l119, !tbaa !29
  %t353 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t352, ptr %t353)
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb31
bb43:
  br label %bb44
bb44:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t357 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t354, i32 93)
  store i1 %t357, ptr %l136
  br label %bb45
bb45:
  %t358 = load i1, ptr %l136, !tbaa !21
  %t359 = xor i1 %t358, true
  br i1 %t359, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s17
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/parse:Parser", ptr %t361, i32 0, i32 30
  %t364 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t363, i64 %t364)
  br label %bb48
bb47:
  br label %bb53
bb48:
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l141, !tbaa !29
  %t369 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s17, i32 93)
  store { i64, ptr } %t369, ptr %l143
  br label %bb49
bb49:
  %t370 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 0
  %t372 = extractvalue { i64, ptr } %t370, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t377 = load ptr, ptr %l141, !tbaa !29
  %t379 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s17, ptr %t377, { i64, ptr } %t376)
  store i32 %t379, ptr %l145
  %t380 = icmp ne i32 %t379, 0
  br i1 %t380, label %bb51, label %ok.381
ok.381:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t382 = load i32, ptr %l145, !tbaa !23
  %t383 = lshr i32 %t382, 16
  %t384 = and i32 %t382, 65535
  %t385 = icmp eq i32 %t383, 1
  %t386 = select i1 %t385, i32 1, i32 0
  %t387 = icmp eq i32 %t382, 0
  %t388 = shl i32 %t386, 16
  %t389 = or i32 %t388, %t384
  %t390 = select i1 %t387, i32 0, i32 %t389
  call void @__olang_scope_close(ptr %s17)
  %t391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t391, ptr %l147, !tbaa !29
  %t392 = load ptr, ptr %l147, !tbaa !29
  %t393 = getelementptr %"compiler/parse:Parser", ptr %t392, i32 0, i32 17
  %t394 = load i64, ptr %t393, !tbaa !24
  %t396 = sub i64 %t394, 1
  %t398 = load ptr, ptr %l147, !tbaa !29
  %t399 = getelementptr %"compiler/parse:Parser", ptr %t398, i32 0, i32 17
  store i64 %t396, ptr %t399, !tbaa !24
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i1, ptr %l3, !tbaa !21
  %t404 = getelementptr %"compiler/parse:Parser", ptr %t400, i32 0, i32 11
  store i1 %t401, ptr %t404, !tbaa !21
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i1, ptr %l4, !tbaa !21
  %t409 = getelementptr %"compiler/parse:Parser", ptr %t405, i32 0, i32 18
  store i1 %t406, ptr %t409, !tbaa !21
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load i1, ptr %l5, !tbaa !21
  %t414 = getelementptr %"compiler/parse:Parser", ptr %t410, i32 0, i32 19
  store i1 %t411, ptr %t414, !tbaa !21
  %t416 = insertvalue { i32, ptr } zeroinitializer, i32 %t390, 0
  store { i32, ptr } %t416, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s17)
  br label %bb53
bb53:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t417)
  store i32 %t419, ptr %l157
  br label %bb54
bb54:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i32, ptr %l1, !tbaa !23
  %t424 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t420, i32 %t421)
  store %"compiler/source:Span" %t424, ptr %l160
  br label %bb55
bb55:
  %t425 = load ptr, ptr %l2, !tbaa !29
  store ptr %t425, ptr %l162, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/parse:Parser", ptr %t427, i32 0, i32 30
  %t430 = load i64, ptr %l6, !tbaa !24
  %t433 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t429, i64 %t430)
  store { i64, ptr } %t433, ptr %l166
  br label %bb56
bb56:
  store { i64, [5 x i64] } zeroinitializer, ptr %t434
  %t435 = getelementptr { i64, [5 x i64] }, ptr %t434, i32 0, i32 0
  store i64 18, ptr %t435
  %t436 = load %"compiler/source:Span", ptr %l160
  %t437 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t436, 0
  %t438 = load ptr, ptr %l162, !tbaa !29
  %t439 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t437, ptr %t438, 1
  %t440 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t441 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t439, { i64, ptr } %t440, 2
  %t442 = getelementptr { i64, [5 x i64] }, ptr %t434, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t441, ptr %t442
  %t443 = load { i64, [5 x i64] }, ptr %t434
  %t445 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t443, ptr %t445
  %t446 = load ptr, ptr %l0, !tbaa !29
  store ptr %t446, ptr %l169, !tbaa !29
  %t447 = load ptr, ptr %l169, !tbaa !29
  %t448 = getelementptr %"compiler/parse:Parser", ptr %t447, i32 0, i32 17
  %t449 = load i64, ptr %t448, !tbaa !24
  %t451 = sub i64 %t449, 1
  %t453 = load ptr, ptr %l169, !tbaa !29
  %t454 = getelementptr %"compiler/parse:Parser", ptr %t453, i32 0, i32 17
  store i64 %t451, ptr %t454, !tbaa !24
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i1, ptr %l3, !tbaa !21
  %t459 = getelementptr %"compiler/parse:Parser", ptr %t455, i32 0, i32 11
  store i1 %t456, ptr %t459, !tbaa !21
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i1, ptr %l4, !tbaa !21
  %t464 = getelementptr %"compiler/parse:Parser", ptr %t460, i32 0, i32 18
  store i1 %t461, ptr %t464, !tbaa !21
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load i1, ptr %l5, !tbaa !21
  %t469 = getelementptr %"compiler/parse:Parser", ptr %t465, i32 0, i32 19
  store i1 %t466, ptr %t469, !tbaa !21
  %t471 = insertvalue { i32, ptr } zeroinitializer, ptr %t445, 1
  store { i32, ptr } %t471, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 8 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 95 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 0 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 15
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load i32, ptr %l1
  %t30 = trunc i64 91 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb13, label %bb14
bb12:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb19
bb13:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t33 = load i32, ptr %l1
  %t35 = trunc i64 93 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb18
bb17:
  %t39 = load i32, ptr %l1
  %t41 = trunc i64 57 to i32
  %t42 = icmp eq i32 %t39, %t41
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb18
bb18:
  %t44 = load i1, ptr %l21, !tbaa !21
  store i1 %t44, ptr %l15, !tbaa !21
  br label %bb19
bb19:
  %t45 = load i1, ptr %l15, !tbaa !21
  br i1 %t45, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 13
  %t50 = load i1, ptr %t49, !tbaa !21
  br i1 %t50, label %bb23, label %bb24
bb23:
  %t52 = load i32, ptr %l1
  %t54 = trunc i64 10 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb28
bb25:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb27
bb26:
  %t57 = load i32, ptr %l1
  %t59 = trunc i64 12 to i32
  %t60 = icmp eq i32 %t57, %t59
  store i1 %t60, ptr %l30, !tbaa !21
  br label %bb27
bb27:
  %t62 = load i1, ptr %l30, !tbaa !21
  store i1 %t62, ptr %l27, !tbaa !21
  br label %bb28
bb28:
  %t63 = load i1, ptr %l27, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 61)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %t6)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l7
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l6
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  br label %bb6
bb5:
  %t14 = load i32, ptr %l7, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t22, 0
  store { i32, { i64, ptr } } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t25, 1
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l12
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l11
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  br label %bb10
bb9:
  %t35 = load i32, ptr %l12, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t43, 0
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t47 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t46, 1
  store { i32, { i64, ptr } } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l24 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/ast:Branch"
  %l42 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/ast:Branch"
  %l49 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l70 = alloca i1
  %l78 = alloca i32
  %l88 = alloca i32
  %l91 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/ast:Branch"
  %l102 = alloca %"compiler/source:Span"
  %l105 = alloca %"compiler/ast:Branch"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i32, ptr %l9, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 61)
  store i1 %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 4
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l15
  br label %bb5
bb4:
  br label %bb27
bb5:
  %t16 = load i64, ptr %l15, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %t17)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l19
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb7, label %ok.23
ok.23:
  store { i64, ptr } %t20, ptr %l18
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t24, ptr %l16, !tbaa !27
  br label %bb23
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t28)
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 21
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 23
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t42, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t43)
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t45, i32 %t46)
  store %"compiler/source:Span" %t49, ptr %l31
  br label %bb17
bb17:
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb18, label %bb19
bb18:
  %t52 = icmp sle i64 0, 1152921504606846975
  br i1 %t52, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3a014922d706f8ae_e8b2af70e71e377a)
  unreachable
bb20:
  %t54 = mul i64 0, 8
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 0, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load %"compiler/source:Span", ptr %l31
  %t62 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t59, { i64, ptr } %t57, i64 %t58)
  store %"compiler/ast:Branch" %t62, ptr %l36
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3a014922d706f8ae_e8b2af70e71e377a)
  unreachable
bb22:
  %t63 = load %"compiler/ast:Branch", ptr %l36
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t63, ptr %t64
  %t66 = insertvalue { i32, ptr } zeroinitializer, ptr %t64, 1
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb23:
  %t67 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t67, ptr %l3, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 4
  %t71 = load ptr, ptr %t70, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t71)
  br label %bb24
bb24:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t73, i32 %t74)
  store %"compiler/source:Span" %t77, ptr %l42
  br label %bb25
bb25:
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load %"compiler/source:Span", ptr %l42
  %t83 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t80, { i64, ptr } %t78, i64 %t79)
  store %"compiler/ast:Branch" %t83, ptr %l45
  br label %bb26
bb26:
  %t84 = load %"compiler/ast:Branch", ptr %l45
  %t85 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t84, ptr %t85
  %t87 = insertvalue { i32, ptr } zeroinitializer, ptr %t85, 1
  store { i32, ptr } %t87, ptr %rv
  br label %ret
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t88, i32 94)
  store i1 %t91, ptr %l49
  br label %bb28
bb28:
  %t92 = load i1, ptr %l49, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l51, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 94)
  store { i64, ptr } %t97, ptr %l53
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t98 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t107 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t105, { i64, ptr } %t104)
  store i32 %t107, ptr %l55
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb33, label %ok.109
ok.109:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t110 = load i32, ptr %l55, !tbaa !23
  %t111 = lshr i32 %t110, 16
  %t112 = and i32 %t110, 65535
  %t113 = icmp eq i32 %t111, 1
  %t114 = select i1 %t113, i32 1, i32 0
  %t115 = icmp eq i32 %t110, 0
  %t116 = shl i32 %t114, 16
  %t117 = or i32 %t116, %t112
  %t118 = select i1 %t115, i32 0, i32 %t117
  call void @__olang_scope_close(ptr %s4)
  %t120 = insertvalue { i32, ptr } zeroinitializer, i32 %t118, 0
  store { i32, ptr } %t120, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/parse:Parser", ptr %t121, i32 0, i32 4
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t124)
  store i64 %t126, ptr %l59
  br label %bb36
bb36:
  %t127 = load i64, ptr %l59, !tbaa !24
  store i64 %t127, ptr %l4, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/parse:Parser", ptr %t128, i32 0, i32 6
  %t131 = load i64, ptr %t130, !tbaa !24
  store i64 %t131, ptr %l5, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t133)
  %t136 = extractvalue { i32, { i64, ptr } } %t135, 1
  %t137 = extractvalue { i32, { i64, ptr } } %t135, 0
  store i32 %t137, ptr %l65
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb38, label %ok.139
ok.139:
  store { i64, ptr } %t136, ptr %l64
  br label %bb37
bb37:
  %t140 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t140, ptr %l62, !tbaa !27
  br label %bb58
bb38:
  br label %bb39
bb39:
  call void @__olang_ert_req_clear()
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/parse:Parser", ptr %t141, i32 0, i32 4
  %t144 = load ptr, ptr %t143, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t144)
  br label %bb40
bb40:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/parse:Parser", ptr %t146, i32 0, i32 21
  %t149 = load i1, ptr %t148, !tbaa !21
  br i1 %t149, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb43
bb42:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/parse:Parser", ptr %t151, i32 0, i32 23
  %t154 = load i1, ptr %t153, !tbaa !21
  store i1 %t154, ptr %l70, !tbaa !21
  br label %bb43
bb43:
  %t156 = load i1, ptr %l70, !tbaa !21
  br i1 %t156, label %bb44, label %bb45
bb44:
  %t158 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t158, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = trunc i64 %t163 to i32
  %t168 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %t162, i32 %t165)
  store i32 %t168, ptr %l78
  br label %bb47
bb47:
  %t169 = load i32, ptr %l78, !tbaa !23
  store i32 %t169, ptr %l6, !tbaa !23
  %t170 = load i32, ptr %l6, !tbaa !23
  %t172 = icmp slt i32 %t170, 0
  br i1 %t172, label %bb48, label %bb49
bb48:
  %t175 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l6, !tbaa !23
  %t179 = sext i32 %t177 to i64
  %t182 = getelementptr %"compiler/parse:Parser", ptr %t176, i32 0, i32 6
  store i64 %t179, ptr %t182, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 7
  store i32 0, ptr %t186
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t187)
  store i32 %t189, ptr %l88
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l1, !tbaa !23
  %t194 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t190, i32 %t191)
  store %"compiler/source:Span" %t194, ptr %l91
  br label %bb52
bb52:
  %t195 = icmp sge i64 0, 0
  br i1 %t195, label %bb53, label %bb54
bb53:
  %t197 = icmp sle i64 0, 1152921504606846975
  br i1 %t197, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_e5b5865feda95523_92aca47b2e780ecf)
  unreachable
bb55:
  %t199 = mul i64 0, 8
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 0, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  %t203 = load i64, ptr %l4, !tbaa !24
  %t204 = load %"compiler/source:Span", ptr %l91
  %t207 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t204, { i64, ptr } %t202, i64 %t203)
  store %"compiler/ast:Branch" %t207, ptr %l96
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_e5b5865feda95523_92aca47b2e780ecf)
  unreachable
bb57:
  %t208 = load %"compiler/ast:Branch", ptr %l96
  %t209 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t208, ptr %t209
  %t211 = insertvalue { i32, ptr } zeroinitializer, ptr %t209, 1
  store { i32, ptr } %t211, ptr %rv
  br label %ret
bb58:
  %t212 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t212, ptr %l7, !tbaa !27
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 4
  %t216 = load ptr, ptr %t215, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t216)
  br label %bb59
bb59:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l1, !tbaa !23
  %t222 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t218, i32 %t219)
  store %"compiler/source:Span" %t222, ptr %l102
  br label %bb60
bb60:
  %t223 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t224 = load i64, ptr %l4, !tbaa !24
  %t225 = load %"compiler/source:Span", ptr %l102
  %t228 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t225, { i64, ptr } %t223, i64 %t224)
  store %"compiler/ast:Branch" %t228, ptr %l105
  br label %bb61
bb61:
  %t229 = load %"compiler/ast:Branch", ptr %l105
  %t230 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t229, ptr %t230
  %t232 = insertvalue { i32, ptr } zeroinitializer, ptr %t230, 1
  store { i32, ptr } %t232, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca %"compiler/token:Token"
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t12)
  store %"compiler/token:Token" %t14, ptr %l7
  br label %bb4
bb4:
  %t15 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t16 = load %"compiler/token:Token", ptr %l7
  %t18 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t16, i8 %t15)
  store i1 %t18, ptr %l9
  br label %bb5
bb5:
  %t19 = load i1, ptr %l9, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %rv = alloca { i32, { { i64, ptr }, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 76)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t6)
  %t9 = extractvalue { i32, ptr } %t8, 1
  %t10 = extractvalue { i32, ptr } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store ptr %t9, ptr %l8
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t13 = load ptr, ptr %l8, !tbaa !29
  store ptr %t13, ptr %l6, !tbaa !29
  br label %bb6
bb5:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 %t22, 0
  store { i32, { { i64, ptr }, ptr } } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load ptr, ptr %l6, !tbaa !29
  store ptr %t25, ptr %l1, !tbaa !29
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = icmp sle i64 0, 1152921504606846975
  br i1 %t28, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_1409caed80efd5ca_aa5da404b7edad6)
  unreachable
bb9:
  %t30 = mul i64 0, 8
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 0, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t37 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t33, 0
  %t39 = insertvalue { { i64, ptr }, ptr } %t37, ptr %t34, 1
  %t41 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, { { i64, ptr }, ptr } %t39, 1
  store { i32, { { i64, ptr }, ptr } } %t41, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_1409caed80efd5ca_aa5da404b7edad6)
  unreachable
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t42)
  %t45 = extractvalue { i32, { i64, ptr } } %t44, 1
  %t46 = extractvalue { i32, { i64, ptr } } %t44, 0
  store i32 %t46, ptr %l20
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb13, label %ok.48
ok.48:
  store { i64, ptr } %t45, ptr %l19
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t49, ptr %l17, !tbaa !27
  br label %bb14
bb13:
  %t50 = load i32, ptr %l20, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  %t60 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 %t58, 0
  store { i32, { { i64, ptr }, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t64 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t61, 0
  %t65 = insertvalue { { i64, ptr }, ptr } %t64, ptr null, 1
  %t67 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, { { i64, ptr }, ptr } %t65, 1
  store { i32, { { i64, ptr }, ptr } } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { { i64, ptr }, ptr } }, ptr %rv
  ret { i32, { { i64, ptr }, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %rv = alloca { i32, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l1, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = insertvalue { i32, ptr } zeroinitializer, ptr %t20, 1
  store { i32, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i32
  %l15 = alloca i64
  %l20 = alloca i1
  %l23 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8
  %t8 = trunc i64 57 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t14, i64 %t15)
  store i64 %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load i64, ptr %l15, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t20, 1
  store i64 %t22, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sge i64 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t28, i64 %t29)
  store i64 %t32, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp eq i64 %t34, %t33
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l20, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb11, label %bb12
bb11:
  br label %bb43
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t41, i64 %t42)
  store i32 %t45, ptr %l29
  br label %bb14
bb14:
  %t46 = load i32, ptr %l29
  store i32 %t46, ptr %l5
  %t47 = load i32, ptr %l5
  %t49 = trunc i64 91 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb17
bb16:
  %t52 = load i32, ptr %l5
  %t54 = trunc i64 93 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb20
bb19:
  %t58 = load i32, ptr %l5
  %t60 = trunc i64 95 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb41
bb22:
  %t68 = load i32, ptr %l5
  %t70 = trunc i64 90 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb25
bb24:
  %t73 = load i32, ptr %l5
  %t75 = trunc i64 92 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l42, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb28
bb27:
  %t79 = load i32, ptr %l5
  %t81 = trunc i64 94 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb31, label %bb32
bb30:
  %t89 = load i32, ptr %l5
  %t91 = trunc i64 76 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb34, label %bb35
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = sub i64 %t95, 1
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb40
bb34:
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = icmp eq i64 %t99, 0
  store i1 %t101, ptr %l55, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb36
bb36:
  %t103 = load i1, ptr %l55, !tbaa !21
  br i1 %t103, label %bb37, label %bb38
bb37:
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t107 = sub i64 %t105, 1
  store i64 %t107, ptr %l4, !tbaa !24
  br label %bb42
bb42:
  br label %bb6
bb43:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/token:Token"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i1
  %l19 = alloca i32
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l36 = alloca i1
  %l38 = alloca %"compiler/source:Span"
  %l40 = alloca i64
  %l42 = alloca i1
  %l45 = alloca i1
  %l47 = alloca %"compiler/token:Token"
  %l48 = alloca i32
  %l50 = alloca i32
  %l51 = alloca i32
  %l55 = alloca %"compiler/source:Span"
  %l61 = alloca i1
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i32
  %l70 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i32
  %l80 = alloca i1
  %l83 = alloca i1
  %l87 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l91 = alloca i32
  %l96 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l102 = alloca { i64, ptr }
  %l108 = alloca %"compiler/ast:Catch"
  %l111 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 12)
  store i1 %t8, ptr %l16
  br label %bb3
bb3:
  %t9 = load i1, ptr %l16, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb81
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t12)
  store i32 %t14, ptr %l19
  br label %bb7
bb7:
  %t15 = load i32, ptr %l19, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 30
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l22
  br label %bb8
bb8:
  %t21 = load i64, ptr %l22, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l23
  br label %bb9
bb9:
  %t23 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %t24
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t26, i32 1)
  store i1 %t29, ptr %l27
  br label %bb10
bb10:
  %t30 = load i1, ptr %l27, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t31 = load ptr, ptr %l5, !tbaa !29
  store ptr %t31, ptr %l28, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t32)
  %t35 = extractvalue { i32, ptr } %t34, 1
  %t36 = extractvalue { i32, ptr } %t34, 0
  store i32 %t36, ptr %l32
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb15, label %ok.38
ok.38:
  store ptr %t35, ptr %l31
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l31, !tbaa !29
  store ptr %t39, ptr %l29, !tbaa !29
  br label %bb16
bb15:
  %t40 = load i32, ptr %l32, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  call void @__olang_scope_close(ptr %s1)
  %t50 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t48, 0
  store { i32, { i64, ptr } } %t50, ptr %rv
  br label %ret
bb16:
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t51, ptr %t52)
  br label %bb17
bb17:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t53, i32 57)
  store i1 %t56, ptr %l36
  br label %bb18
bb18:
  %t57 = load i1, ptr %l36, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb13
bb23:
  br label %bb24
bb24:
  store i32 0, ptr %l6, !tbaa !23
  %t60 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t60, ptr %l38
  br label %bb25
bb25:
  %t61 = load %"compiler/source:Span", ptr %l38
  store %"compiler/source:Span" %t61, ptr %l7
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eLen_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l40
  br label %bb26
bb26:
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = icmp sgt i64 %t65, 0
  br i1 %t66, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t68, i32 1)
  store i1 %t71, ptr %l45
  br label %bb29
bb28:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb30
bb29:
  %t72 = load i1, ptr %l45, !tbaa !21
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb30
bb30:
  %t73 = load i1, ptr %l42, !tbaa !21
  br i1 %t73, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t74)
  store %"compiler/token:Token" %t76, ptr %l47
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t77 = load %"compiler/token:Token", ptr %l47
  store %"compiler/token:Token" %t77, ptr %l8
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t78)
  %t81 = extractvalue { i32, i32 } %t80, 1
  %t82 = extractvalue { i32, i32 } %t80, 0
  store i32 %t82, ptr %l51
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb35, label %ok.84
ok.84:
  store i32 %t81, ptr %l50
  br label %bb34
bb34:
  %t85 = load i32, ptr %l50, !tbaa !23
  store i32 %t85, ptr %l48, !tbaa !23
  br label %bb36
bb35:
  %t86 = load i32, ptr %l51, !tbaa !23
  %t87 = lshr i32 %t86, 16
  %t88 = and i32 %t86, 65535
  %t89 = icmp eq i32 %t87, 1
  %t90 = select i1 %t89, i32 1, i32 0
  %t91 = icmp eq i32 %t86, 0
  %t92 = shl i32 %t90, 16
  %t93 = or i32 %t92, %t88
  %t94 = select i1 %t91, i32 0, i32 %t93
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  %t96 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t94, 0
  store { i32, { i64, ptr } } %t96, ptr %rv
  br label %ret
bb36:
  %t97 = load i32, ptr %l48, !tbaa !23
  store i32 %t97, ptr %l6, !tbaa !23
  %t98 = getelementptr %"compiler/token:Token", ptr %l8, i32 0, i32 2
  %t99 = load i32, ptr %t98, !tbaa !23
  %t100 = getelementptr %"compiler/token:Token", ptr %l8, i32 0, i32 3
  %t101 = load i32, ptr %t100, !tbaa !23
  %t104 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t99, i32 %t101)
  store %"compiler/source:Span" %t104, ptr %l55
  br label %bb37
bb37:
  %t105 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t105, ptr %l7
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t106 = icmp sge i64 0, 0
  br i1 %t106, label %bb39, label %bb40
bb39:
  %t108 = icmp sle i64 0, 1152921504606846975
  br i1 %t108, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746)
  unreachable
bb41:
  %t110 = mul i64 0, 8
  %t111 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 0, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l9, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t118 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t115, i32 94)
  store i1 %t118, ptr %l61
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746)
  unreachable
bb43:
  %t119 = load i1, ptr %l61, !tbaa !21
  store i1 %t119, ptr %l10, !tbaa !21
  %t120 = load i1, ptr %l10, !tbaa !21
  br i1 %t120, label %bb44, label %bb45
bb44:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t122)
  %t125 = extractvalue { i32, { i64, ptr } } %t124, 1
  %t126 = extractvalue { i32, { i64, ptr } } %t124, 0
  store i32 %t126, ptr %l66
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb47, label %ok.128
ok.128:
  store { i64, ptr } %t125, ptr %l65
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t129 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t129, ptr %l63, !tbaa !27
  br label %bb48
bb47:
  %t130 = load i32, ptr %l66, !tbaa !23
  %t131 = lshr i32 %t130, 16
  %t132 = and i32 %t130, 65535
  %t133 = icmp eq i32 %t131, 1
  %t134 = select i1 %t133, i32 1, i32 0
  %t135 = icmp eq i32 %t130, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t132
  %t138 = select i1 %t135, i32 0, i32 %t137
  call void @__olang_scope_close(ptr %s1)
  %t140 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t138, 0
  store { i32, { i64, ptr } } %t140, ptr %rv
  br label %ret
bb48:
  %t141 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t141, ptr %l9, !tbaa !27
  br label %bb49
bb49:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t142, i32 45)
  store i1 %t145, ptr %l70
  br label %bb50
bb50:
  %t146 = load i1, ptr %l70, !tbaa !21
  br i1 %t146, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  %t147 = load i1, ptr %l10, !tbaa !21
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb67, label %bb68
bb53:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/parse:Parser", ptr %t151, i32 0, i32 30
  store ptr %t153, ptr %l72, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t154)
  %t157 = extractvalue { i32, ptr } %t156, 1
  %t158 = extractvalue { i32, ptr } %t156, 0
  store i32 %t158, ptr %l76
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb55, label %ok.160
ok.160:
  store ptr %t157, ptr %l75
  br label %bb54
bb54:
  %t161 = load ptr, ptr %l75, !tbaa !29
  store ptr %t161, ptr %l73, !tbaa !29
  br label %bb56
bb55:
  %t162 = load i32, ptr %l76, !tbaa !23
  %t163 = lshr i32 %t162, 16
  %t164 = and i32 %t162, 65535
  %t165 = icmp eq i32 %t163, 1
  %t166 = select i1 %t165, i32 1, i32 0
  %t167 = icmp eq i32 %t162, 0
  %t168 = shl i32 %t166, 16
  %t169 = or i32 %t168, %t164
  %t170 = select i1 %t167, i32 0, i32 %t169
  call void @__olang_scope_close(ptr %s1)
  %t172 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t170, 0
  store { i32, { i64, ptr } } %t172, ptr %rv
  br label %ret
bb56:
  %t173 = load ptr, ptr %l72, !tbaa !29
  %t174 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t173, ptr %t174)
  br label %bb57
bb57:
  %t177 = xor i1 %a1, true
  br i1 %t177, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb61
bb59:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t182 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t179, i32 57)
  store i1 %t182, ptr %l83
  br label %bb60
bb60:
  %t183 = load i1, ptr %l83, !tbaa !21
  %t184 = xor i1 %t183, true
  store i1 %t184, ptr %l80, !tbaa !21
  br label %bb61
bb61:
  %t186 = load i1, ptr %l80, !tbaa !21
  br i1 %t186, label %bb62, label %bb63
bb62:
  br label %bb66
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb53
bb66:
  br label %bb74
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l87, !tbaa !29
  %t189 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s11, i32 94)
  store { i64, ptr } %t189, ptr %l89
  br label %bb69
bb68:
  br label %bb73
bb69:
  %t190 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t197 = load ptr, ptr %l87, !tbaa !29
  %t199 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s11, ptr %t197, { i64, ptr } %t196)
  store i32 %t199, ptr %l91
  %t200 = icmp ne i32 %t199, 0
  br i1 %t200, label %bb71, label %ok.201
ok.201:
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t202 = load i32, ptr %l91, !tbaa !23
  %t203 = lshr i32 %t202, 16
  %t204 = and i32 %t202, 65535
  %t205 = icmp eq i32 %t203, 1
  %t206 = select i1 %t205, i32 1, i32 0
  %t207 = icmp eq i32 %t202, 0
  %t208 = shl i32 %t206, 16
  %t209 = or i32 %t208, %t204
  %t210 = select i1 %t207, i32 0, i32 %t209
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s1)
  %t212 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t210, 0
  store { i32, { i64, ptr } } %t212, ptr %rv
  br label %ret
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 30
  %t216 = load i64, ptr %l4, !tbaa !24
  %t219 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t215, i64 %t216)
  store { i64, ptr } %t219, ptr %l96
  br label %bb75
bb75:
  %t220 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t220, ptr %l11, !tbaa !27
  %t221 = load ptr, ptr %l2, !tbaa !29
  store ptr %t221, ptr %l97, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l3, !tbaa !23
  %t226 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t222, i32 %t223)
  store %"compiler/source:Span" %t226, ptr %l100
  br label %bb76
bb76:
  %t227 = load ptr, ptr %l5, !tbaa !29
  %t229 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t227)
  store { i64, ptr } %t229, ptr %l102
  br label %bb77
bb77:
  %t230 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t232 = load i1, ptr %l10, !tbaa !21
  %t233 = load i32, ptr %l6, !tbaa !23
  %t234 = load %"compiler/source:Span", ptr %l7
  %t235 = load %"compiler/source:Span", ptr %l100
  %t236 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t242 = call %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t235, { i64, ptr } %t236, { i64, ptr } %t230, { i64, ptr } %t231, i1 %t232, i32 %t233, %"compiler/source:Span" %t234)
  store %"compiler/ast:Catch" %t242, ptr %l108
  br label %bb78
bb78:
  %t243 = load %"compiler/ast:Catch", ptr %l108
  %t244 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Catch" %t243, ptr %t244
  %t245 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ePush_3ccompiler_2fast_3aCatch_26_3e(ptr %v0, ptr %v0, ptr %t245, ptr %t244)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s1)
  br label %bb80
bb80:
  br label %bb2
bb81:
  %t247 = load ptr, ptr %l2, !tbaa !29
  %t249 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2eToArray_3ccompiler_2fast_3aCatch_26_3e(ptr %v0, ptr %v0, ptr %t247)
  store { i64, ptr } %t249, ptr %l111
  br label %bb82
bb82:
  %t250 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t251 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t250, 1
  store { i32, { i64, ptr } } %t251, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 81 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 89 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 82 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb9:
  %t22 = load i32, ptr %l1
  %t24 = trunc i64 69 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l12, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l25 = alloca i1
  %l28 = alloca { i64, ptr }
  %l37 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/scan:Tokens", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr %"compiler/token:Token", ptr %t16, i64 %t13
  %t18 = getelementptr %"compiler/token:Token", ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  %t21 = trunc i64 8 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/scan:Tokens", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = sub i64 %t33, 1
  %t38 = icmp slt i64 %t24, %t35
  store i1 %t38, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t40 = load i1, ptr %l10, !tbaa !21
  %t41 = xor i1 %t40, true
  br i1 %t41, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l1, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 7
  %t50 = load i32, ptr %t49
  %t52 = trunc i64 0 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb12
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/scan:Tokens", ptr %t60, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l28, !tbaa !27
  %t64 = load i64, ptr %l1, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr %"compiler/token:Token", ptr %t67, i64 %t64
  %t69 = getelementptr %"compiler/token:Token", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69
  %t72 = trunc i64 25 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t75 = xor i1 %t73, true
  store i1 %t75, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t77 = load i1, ptr %l25, !tbaa !21
  br i1 %t77, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l1, !tbaa !24
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t79, i32 0, i32 6
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t84)
  store i32 %t86, ptr %l37
  br label %bb16
bb16:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %a0, i32 %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l24 = alloca i1
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i32
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i32
  %l60 = alloca i1
  %l64 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i32
  %l81 = alloca i1
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i32
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca i32
  %l102 = alloca %"compiler/ast:Compr"
  %l108 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i32
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca i32
  %l127 = alloca %"compiler/ast:Compr"
  %rv = alloca { i32, ptr }
  %t161 = alloca { i64, [5 x i64] }, align 8
  %t249 = alloca { i64, [5 x i64] }, align 8
  %t315 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 18
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l5, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 18
  store i1 true, ptr %t8, !tbaa !21
  store i32 0, ptr %l6, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t9)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l18
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15
ok.15:
  store i32 %t12, ptr %l17
  br label %bb1
bb1:
  %t16 = load i32, ptr %l17, !tbaa !23
  store i32 %t16, ptr %l15, !tbaa !23
  br label %bb3
bb2:
  %t17 = load i32, ptr %l18, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i1, ptr %l5, !tbaa !21
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 18
  store i1 %t27, ptr %t30, !tbaa !21
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t25, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb3:
  %t33 = load i32, ptr %l15, !tbaa !23
  store i32 %t33, ptr %l7, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t37 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t34, i32 57)
  store i1 %t37, ptr %l24
  br label %bb4
bb4:
  %t38 = load i1, ptr %l24, !tbaa !21
  br i1 %t38, label %bb5, label %bb6
bb5:
  %t39 = load i32, ptr %l7, !tbaa !23
  store i32 %t39, ptr %l6, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t41)
  %t44 = extractvalue { i32, i32 } %t43, 1
  %t45 = extractvalue { i32, i32 } %t43, 0
  store i32 %t45, ptr %l29
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47
ok.47:
  store i32 %t44, ptr %l28
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t48 = load i32, ptr %l28, !tbaa !23
  store i32 %t48, ptr %l26, !tbaa !23
  br label %bb9
bb8:
  %t49 = load i32, ptr %l29, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i1, ptr %l5, !tbaa !21
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 18
  store i1 %t59, ptr %t62, !tbaa !21
  %t64 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t64, ptr %rv
  br label %ret
bb9:
  %t65 = load i32, ptr %l26, !tbaa !23
  store i32 %t65, ptr %l7, !tbaa !23
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t66, i32 27)
  %t70 = extractvalue { i32, i32 } %t69, 1
  %t71 = extractvalue { i32, i32 } %t69, 0
  store i32 %t71, ptr %l37
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb12, label %ok.73
ok.73:
  store i32 %t70, ptr %l36
  br label %bb11
bb11:
  %t74 = load i32, ptr %l36, !tbaa !23
  store i32 %t74, ptr %l33, !tbaa !23
  br label %bb13
bb12:
  %t75 = load i32, ptr %l37, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i1, ptr %l5, !tbaa !21
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 18
  store i1 %t85, ptr %t88, !tbaa !21
  %t90 = insertvalue { i32, ptr } zeroinitializer, i32 %t83, 0
  store { i32, ptr } %t90, ptr %rv
  br label %ret
bb13:
  store ptr null, ptr %l8, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t91, i32 30)
  store i1 %t94, ptr %l43
  br label %bb14
bb14:
  %t95 = load i1, ptr %l43, !tbaa !21
  br i1 %t95, label %bb15, label %bb16
bb15:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t96)
  store i32 %t98, ptr %l45
  br label %bb17
bb16:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t99, i64 1)
  %t102 = extractvalue { i32, ptr } %t101, 1
  %t103 = extractvalue { i32, ptr } %t101, 0
  store i32 %t103, ptr %l74
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb33, label %ok.105
ok.105:
  store ptr %t102, ptr %l73
  br label %bb32
bb17:
  %t106 = load i32, ptr %l45, !tbaa !23
  store i32 %t106, ptr %l9, !tbaa !23
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/parse:Parser", ptr %t107, i32 0, i32 30
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l48
  br label %bb18
bb18:
  %t112 = load i64, ptr %l48, !tbaa !24
  store i64 %t112, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t113, i32 0, i32 30
  store ptr %t115, ptr %l50, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t116, i64 1)
  %t119 = extractvalue { i32, ptr } %t118, 1
  %t120 = extractvalue { i32, ptr } %t118, 0
  store i32 %t120, ptr %l54
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb21, label %ok.122
ok.122:
  store ptr %t119, ptr %l53
  br label %bb20
bb20:
  %t123 = load ptr, ptr %l53, !tbaa !29
  store ptr %t123, ptr %l51, !tbaa !29
  br label %bb22
bb21:
  %t124 = load i32, ptr %l54, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i1, ptr %l5, !tbaa !21
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 18
  store i1 %t134, ptr %t137, !tbaa !21
  %t139 = insertvalue { i32, ptr } zeroinitializer, i32 %t132, 0
  store { i32, ptr } %t139, ptr %rv
  br label %ret
bb22:
  %t140 = load ptr, ptr %l50, !tbaa !29
  %t141 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t140, ptr %t141)
  br label %bb23
bb23:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t142, i32 57)
  store i1 %t145, ptr %l60
  br label %bb24
bb24:
  %t146 = load i1, ptr %l60, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb19
bb29:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l9, !tbaa !23
  %t153 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t149, i32 %t150)
  store %"compiler/source:Span" %t153, ptr %l64
  br label %bb30
bb30:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/parse:Parser", ptr %t154, i32 0, i32 30
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t156, i64 %t157)
  store { i64, ptr } %t160, ptr %l68
  br label %bb31
bb31:
  store { i64, [5 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 0
  store i64 25, ptr %t162
  %t163 = load %"compiler/source:Span", ptr %l64
  %t164 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t163, 0
  %t165 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t166 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t164, { i64, ptr } %t165, 1
  %t167 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t166, ptr %t167
  %t168 = load { i64, [5 x i64] }, ptr %t161
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t168, ptr %t170
  store ptr %t170, ptr %l8, !tbaa !29
  br label %bb35
bb32:
  %t172 = load ptr, ptr %l73, !tbaa !29
  store ptr %t172, ptr %l71, !tbaa !29
  br label %bb34
bb33:
  %t173 = load i32, ptr %l74, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 1, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l5, !tbaa !21
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t182, i32 0, i32 18
  store i1 %t183, ptr %t186, !tbaa !21
  %t188 = insertvalue { i32, ptr } zeroinitializer, i32 %t181, 0
  store { i32, ptr } %t188, ptr %rv
  br label %ret
bb34:
  %t189 = load ptr, ptr %l71, !tbaa !29
  store ptr %t189, ptr %l8, !tbaa !29
  br label %bb35
bb35:
  store ptr null, ptr %l11, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t194 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t191, i32 9)
  store i1 %t194, ptr %l81
  br label %bb36
bb36:
  %t195 = load i1, ptr %l81, !tbaa !21
  br i1 %t195, label %bb37, label %bb38
bb37:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t196, i64 1)
  %t199 = extractvalue { i32, ptr } %t198, 1
  %t200 = extractvalue { i32, ptr } %t198, 0
  store i32 %t200, ptr %l85
  %t201 = icmp ne i32 %t200, 0
  br i1 %t201, label %bb40, label %ok.202
ok.202:
  store ptr %t199, ptr %l84
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t203 = load ptr, ptr %l84, !tbaa !29
  store ptr %t203, ptr %l82, !tbaa !29
  br label %bb41
bb40:
  %t204 = load i32, ptr %l85, !tbaa !23
  %t205 = lshr i32 %t204, 16
  %t206 = and i32 %t204, 65535
  %t207 = icmp eq i32 %t205, 1
  %t208 = select i1 %t207, i32 1, i32 0
  %t209 = icmp eq i32 %t204, 0
  %t210 = shl i32 %t208, 16
  %t211 = or i32 %t210, %t206
  %t212 = select i1 %t209, i32 0, i32 %t211
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i1, ptr %l5, !tbaa !21
  %t217 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 18
  store i1 %t214, ptr %t217, !tbaa !21
  %t219 = insertvalue { i32, ptr } zeroinitializer, i32 %t212, 0
  store { i32, ptr } %t219, ptr %rv
  br label %ret
bb41:
  %t220 = load ptr, ptr %l82, !tbaa !29
  store ptr %t220, ptr %l11, !tbaa !29
  br label %bb42
bb42:
  %t224 = trunc i64 91 to i32
  %t225 = icmp eq i32 %a4, %t224
  br i1 %t225, label %bb43, label %bb44
bb43:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l1, !tbaa !23
  %t231 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t227, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l94
  br label %bb45
bb44:
  br label %bb50
bb45:
  %t232 = load ptr, ptr %l3, !tbaa !29
  store ptr %t232, ptr %l95, !tbaa !29
  %t233 = load i32, ptr %l6, !tbaa !23
  store i32 %t233, ptr %l96, !tbaa !23
  %t234 = load i32, ptr %l7, !tbaa !23
  store i32 %t234, ptr %l97, !tbaa !23
  %t235 = load ptr, ptr %l8, !tbaa !29
  %t237 = icmp eq ptr %t235, null
  br i1 %t237, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_562ee49de0d7f4dc_ca929e902ecee878)
  unreachable
bb47:
  br label %bb48
bb48:
  %t239 = load ptr, ptr %l8, !tbaa !29
  %t240 = load ptr, ptr %l11, !tbaa !29
  %t241 = load ptr, ptr %l95, !tbaa !29
  %t242 = load i32, ptr %l96, !tbaa !23
  %t243 = load i32, ptr %l97, !tbaa !23
  %t246 = call %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr null, ptr %t241, i32 %t242, i32 %t243, ptr %t239, ptr %t240, i1 true, i64 -1)
  store %"compiler/ast:Compr" %t246, ptr %l102
  br label %bb49
bb49:
  %t247 = load %"compiler/ast:Compr", ptr %l102
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/ast:Compr" %t247, ptr %t248
  store { i64, [5 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 0
  store i64 20, ptr %t250
  %t251 = load %"compiler/source:Span", ptr %l94
  %t252 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t251, 0
  %t254 = insertvalue { %"compiler/source:Span", ptr } %t252, ptr %t248, 1
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t254, ptr %t255
  %t256 = load { i64, [5 x i64] }, ptr %t249
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t256, ptr %t258
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i1, ptr %l5, !tbaa !21
  %t263 = getelementptr %"compiler/parse:Parser", ptr %t259, i32 0, i32 18
  store i1 %t260, ptr %t263, !tbaa !21
  %t265 = insertvalue { i32, ptr } zeroinitializer, ptr %t258, 1
  store { i32, ptr } %t265, ptr %rv
  br label %ret
bb50:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t269 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t266, i32 93)
  %t270 = extractvalue { i32, i32 } %t269, 1
  %t271 = extractvalue { i32, i32 } %t269, 0
  store i32 %t271, ptr %l112
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb52, label %ok.273
ok.273:
  store i32 %t270, ptr %l111
  br label %bb51
bb51:
  %t274 = load i32, ptr %l111, !tbaa !23
  store i32 %t274, ptr %l108, !tbaa !23
  br label %bb53
bb52:
  %t275 = load i32, ptr %l112, !tbaa !23
  %t276 = lshr i32 %t275, 16
  %t277 = and i32 %t275, 65535
  %t278 = icmp eq i32 %t276, 1
  %t279 = select i1 %t278, i32 1, i32 0
  %t280 = icmp eq i32 %t275, 0
  %t281 = shl i32 %t279, 16
  %t282 = or i32 %t281, %t277
  %t283 = select i1 %t280, i32 0, i32 %t282
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i1, ptr %l5, !tbaa !21
  %t288 = getelementptr %"compiler/parse:Parser", ptr %t284, i32 0, i32 18
  store i1 %t285, ptr %t288, !tbaa !21
  %t290 = insertvalue { i32, ptr } zeroinitializer, i32 %t283, 0
  store { i32, ptr } %t290, ptr %rv
  br label %ret
bb53:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l1, !tbaa !23
  %t295 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t291, i32 %t292)
  store %"compiler/source:Span" %t295, ptr %l118
  br label %bb54
bb54:
  store ptr %a2, ptr %l119, !tbaa !29
  %t297 = load ptr, ptr %l3, !tbaa !29
  store ptr %t297, ptr %l120, !tbaa !29
  %t298 = load i32, ptr %l6, !tbaa !23
  store i32 %t298, ptr %l121, !tbaa !23
  %t299 = load i32, ptr %l7, !tbaa !23
  store i32 %t299, ptr %l122, !tbaa !23
  %t300 = load ptr, ptr %l8, !tbaa !29
  %t302 = icmp eq ptr %t300, null
  br i1 %t302, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_8028beeed4c0afcb_93e9486db4deb497)
  unreachable
bb56:
  br label %bb57
bb57:
  %t304 = load ptr, ptr %l8, !tbaa !29
  %t305 = load ptr, ptr %l11, !tbaa !29
  %t306 = load ptr, ptr %l119, !tbaa !29
  %t307 = load ptr, ptr %l120, !tbaa !29
  %t308 = load i32, ptr %l121, !tbaa !23
  %t309 = load i32, ptr %l122, !tbaa !23
  %t312 = call %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t306, ptr %t307, i32 %t308, i32 %t309, ptr %t304, ptr %t305, i1 false, i64 -1)
  store %"compiler/ast:Compr" %t312, ptr %l127
  br label %bb58
bb58:
  %t313 = load %"compiler/ast:Compr", ptr %l127
  %t314 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/ast:Compr" %t313, ptr %t314
  store { i64, [5 x i64] } zeroinitializer, ptr %t315
  %t316 = getelementptr { i64, [5 x i64] }, ptr %t315, i32 0, i32 0
  store i64 20, ptr %t316
  %t317 = load %"compiler/source:Span", ptr %l118
  %t318 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t317, 0
  %t320 = insertvalue { %"compiler/source:Span", ptr } %t318, ptr %t314, 1
  %t321 = getelementptr { i64, [5 x i64] }, ptr %t315, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t320, ptr %t321
  %t322 = load { i64, [5 x i64] }, ptr %t315
  %t324 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t322, ptr %t324
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i1, ptr %l5, !tbaa !21
  %t329 = getelementptr %"compiler/parse:Parser", ptr %t325, i32 0, i32 18
  store i1 %t326, ptr %t329, !tbaa !21
  %t331 = insertvalue { i32, ptr } zeroinitializer, ptr %t324, 1
  store { i32, ptr } %t331, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t102 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 9)
  store i1 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i1, ptr %l6, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb8
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 17
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t15)
  store i1 %t17, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i1, ptr %l14, !tbaa !21
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l12, !tbaa !21
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = insertvalue { i32, ptr } zeroinitializer, ptr %t21, 1
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l17
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t27, i64 1)
  %t30 = extractvalue { i32, ptr } %t29, 1
  %t31 = extractvalue { i32, ptr } %t29, 0
  store i32 %t31, ptr %l21
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb14, label %ok.33
ok.33:
  store ptr %t30, ptr %l20
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l20, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  br label %bb15
bb14:
  %t35 = load i32, ptr %l21, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load ptr, ptr %l18, !tbaa !29
  store ptr %t46, ptr %l2, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t47, i32 10)
  %t51 = extractvalue { i32, i32 } %t50, 1
  %t52 = extractvalue { i32, i32 } %t50, 0
  store i32 %t52, ptr %l27
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb17, label %ok.54
ok.54:
  store i32 %t51, ptr %l26
  br label %bb16
bb16:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l23, !tbaa !23
  br label %bb18
bb17:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t67)
  %t70 = extractvalue { i32, ptr } %t69, 1
  %t71 = extractvalue { i32, ptr } %t69, 0
  store i32 %t71, ptr %l32
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb20, label %ok.73
ok.73:
  store ptr %t70, ptr %l31
  br label %bb19
bb19:
  %t74 = load ptr, ptr %l31, !tbaa !29
  store ptr %t74, ptr %l29, !tbaa !29
  br label %bb21
bb20:
  %t75 = load i32, ptr %l32, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t85 = insertvalue { i32, ptr } zeroinitializer, i32 %t83, 0
  store { i32, ptr } %t85, ptr %rv
  br label %ret
bb21:
  %t86 = load ptr, ptr %l29, !tbaa !29
  store ptr %t86, ptr %l3, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t87)
  store %"compiler/source:Span" %t89, ptr %l35
  br label %bb22
bb22:
  %t90 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 0
  %t91 = load i32, ptr %t90, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 10
  %t95 = load i32, ptr %t94, !tbaa !23
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t91, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l39
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 0
  store i64 8, ptr %t103
  %t104 = load %"compiler/source:Span", ptr %l39
  %t105 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } undef, %"compiler/source:Span" %t104, 0
  %t107 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t105, ptr %t99, 1
  %t109 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t107, ptr %t100, 2
  %t111 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t109, ptr %t101, 3
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, ptr } %t111, ptr %t112
  %t113 = load { i64, [5 x i64] }, ptr %t102
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t113, ptr %t115
  %t117 = insertvalue { i32, ptr } zeroinitializer, ptr %t115, 1
  store { i32, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtract(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l27 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i32
  %l53 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i32
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i32
  %l88 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l100 = alloca i32
  %l101 = alloca i32
  %l107 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca %"compiler/ast:ContractBlock"
  %l122 = alloca ptr
  %rv = alloca { i32, ptr }
  %t178 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 42
  store ptr %t3, ptr %l10, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 6
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t4, i64 %t8)
  store i64 %t11, ptr %l14
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t12, i64 %t13)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t14, i32 92)
  %t18 = extractvalue { i32, i32 } %t17, 1
  %t19 = extractvalue { i32, i32 } %t17, 0
  store i32 %t19, ptr %l19
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb4, label %ok.21
ok.21:
  store i32 %t18, ptr %l18
  br label %bb3
bb3:
  %t22 = load i32, ptr %l18, !tbaa !23
  store i32 %t22, ptr %l15, !tbaa !23
  br label %bb5
bb4:
  %t23 = load i32, ptr %l19, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  %t33 = insertvalue { i32, ptr } zeroinitializer, i32 %t31, 0
  store { i32, ptr } %t33, ptr %rv
  br label %ret
bb5:
  %t34 = load i32, ptr %l15, !tbaa !23
  store i32 %t34, ptr %l1, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 19
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l2, !tbaa !21
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 18
  %t43 = load i1, ptr %t42, !tbaa !21
  store i1 %t43, ptr %l3, !tbaa !21
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/parse:Parser", ptr %t45, i32 0, i32 19
  store i1 false, ptr %t47, !tbaa !21
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 18
  store i1 false, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 17
  %t54 = load i64, ptr %t53, !tbaa !24
  %t56 = add i64 %t54, 1
  %t58 = load ptr, ptr %l27, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 17
  store i64 %t56, ptr %t59, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 31
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l32
  br label %bb6
bb6:
  %t65 = load i64, ptr %l32, !tbaa !24
  store i64 %t65, ptr %l4, !tbaa !24
  %t66 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aOutlives_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l33
  br label %bb7
bb7:
  %t67 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %t68
  store ptr %t68, ptr %l5, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t70)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t72, i32 93)
  store i1 %t75, ptr %l38
  br label %bb10
bb10:
  %t76 = load i1, ptr %l38, !tbaa !21
  %t77 = xor i1 %t76, true
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb11, label %bb12
bb11:
  br label %bb35
bb12:
  br label %bb13
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlivesHere(ptr %v0, ptr %t81)
  store i1 %t83, ptr %l42
  br label %bb14
bb14:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb15, label %bb16
bb15:
  %t85 = load ptr, ptr %l5, !tbaa !29
  store ptr %t85, ptr %l43, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlives(ptr %v0, ptr %t86)
  %t89 = extractvalue { i32, ptr } %t88, 1
  %t90 = extractvalue { i32, ptr } %t88, 0
  store i32 %t90, ptr %l47
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb18, label %ok.92
ok.92:
  store ptr %t89, ptr %l46
  br label %bb17
bb16:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t93)
  store i32 %t95, ptr %l57
  br label %bb21
bb17:
  %t96 = load ptr, ptr %l46, !tbaa !29
  store ptr %t96, ptr %l44, !tbaa !29
  br label %bb19
bb18:
  %t97 = load i32, ptr %l47, !tbaa !23
  %t98 = lshr i32 %t97, 16
  %t99 = and i32 %t97, 65535
  %t100 = icmp eq i32 %t98, 1
  %t101 = select i1 %t100, i32 1, i32 0
  %t102 = icmp eq i32 %t97, 0
  %t103 = shl i32 %t101, 16
  %t104 = or i32 %t103, %t99
  %t105 = select i1 %t102, i32 0, i32 %t104
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i1, ptr %l2, !tbaa !21
  %t110 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 19
  store i1 %t107, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i1, ptr %l3, !tbaa !21
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 18
  store i1 %t112, ptr %t115, !tbaa !21
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l53, !tbaa !29
  %t117 = load ptr, ptr %l53, !tbaa !29
  %t118 = getelementptr %"compiler/parse:Parser", ptr %t117, i32 0, i32 17
  %t119 = load i64, ptr %t118, !tbaa !24
  %t121 = sub i64 %t119, 1
  %t123 = load ptr, ptr %l53, !tbaa !29
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t123, i32 0, i32 17
  store i64 %t121, ptr %t124, !tbaa !24
  %t126 = insertvalue { i32, ptr } zeroinitializer, i32 %t105, 0
  store { i32, ptr } %t126, ptr %rv
  br label %ret
bb19:
  %t127 = load ptr, ptr %l43, !tbaa !29
  %t128 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aOutlives_26_3e_2ePush_H1795edae43e3fb2f1ebc9cb1197392ef(ptr %v0, ptr %v0, ptr %t127, ptr %t128)
  br label %bb20
bb20:
  br label %bb27
bb21:
  %t129 = load i32, ptr %l57, !tbaa !23
  store i32 %t129, ptr %l6, !tbaa !23
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t130)
  %t133 = extractvalue { i32, ptr } %t132, 1
  %t134 = extractvalue { i32, ptr } %t132, 0
  store i32 %t134, ptr %l61
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb23, label %ok.136
ok.136:
  store ptr %t133, ptr %l60
  br label %bb22
bb22:
  %t137 = load ptr, ptr %l60, !tbaa !29
  store ptr %t137, ptr %l58, !tbaa !29
  br label %bb24
bb23:
  %t138 = load i32, ptr %l61, !tbaa !23
  %t139 = lshr i32 %t138, 16
  %t140 = and i32 %t138, 65535
  %t141 = icmp eq i32 %t139, 1
  %t142 = select i1 %t141, i32 1, i32 0
  %t143 = icmp eq i32 %t138, 0
  %t144 = shl i32 %t142, 16
  %t145 = or i32 %t144, %t140
  %t146 = select i1 %t143, i32 0, i32 %t145
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i1, ptr %l2, !tbaa !21
  %t151 = getelementptr %"compiler/parse:Parser", ptr %t147, i32 0, i32 19
  store i1 %t148, ptr %t151, !tbaa !21
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i1, ptr %l3, !tbaa !21
  %t156 = getelementptr %"compiler/parse:Parser", ptr %t152, i32 0, i32 18
  store i1 %t153, ptr %t156, !tbaa !21
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l67, !tbaa !29
  %t158 = load ptr, ptr %l67, !tbaa !29
  %t159 = getelementptr %"compiler/parse:Parser", ptr %t158, i32 0, i32 17
  %t160 = load i64, ptr %t159, !tbaa !24
  %t162 = sub i64 %t160, 1
  %t164 = load ptr, ptr %l67, !tbaa !29
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 17
  store i64 %t162, ptr %t165, !tbaa !24
  %t167 = insertvalue { i32, ptr } zeroinitializer, i32 %t146, 0
  store { i32, ptr } %t167, ptr %rv
  br label %ret
bb24:
  %t168 = load ptr, ptr %l58, !tbaa !29
  store ptr %t168, ptr %l7, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/parse:Parser", ptr %t169, i32 0, i32 31
  store ptr %t171, ptr %l71, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l6, !tbaa !23
  %t176 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t172, i32 %t173)
  store %"compiler/source:Span" %t176, ptr %l74
  br label %bb25
bb25:
  %t177 = load ptr, ptr %l7, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 0
  store i64 14, ptr %t179
  %t180 = load %"compiler/source:Span", ptr %l74
  %t181 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t180, 0
  %t183 = insertvalue { %"compiler/source:Span", ptr, ptr } %t181, ptr %t177, 1
  %t184 = insertvalue { %"compiler/source:Span", ptr, ptr } %t183, ptr null, 2
  %t185 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t184, ptr %t185
  %t186 = load { i64, [4 x i64] }, ptr %t178
  %t188 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t186, ptr %t188
  %t189 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t189, ptr %t188)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t194 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t191, i32 93)
  %t195 = extractvalue { i32, i1 } %t194, 1
  %t196 = extractvalue { i32, i1 } %t194, 0
  store i32 %t196, ptr %l82
  %t197 = icmp ne i32 %t196, 0
  br i1 %t197, label %bb29, label %ok.198
ok.198:
  store i1 %t195, ptr %l81
  br label %bb28
bb28:
  %t199 = load i1, ptr %l81, !tbaa !21
  store i1 %t199, ptr %l78, !tbaa !21
  br label %bb30
bb29:
  %t200 = load i32, ptr %l82, !tbaa !23
  %t201 = lshr i32 %t200, 16
  %t202 = and i32 %t200, 65535
  %t203 = icmp eq i32 %t201, 1
  %t204 = select i1 %t203, i32 1, i32 0
  %t205 = icmp eq i32 %t200, 0
  %t206 = shl i32 %t204, 16
  %t207 = or i32 %t206, %t202
  %t208 = select i1 %t205, i32 0, i32 %t207
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i1, ptr %l2, !tbaa !21
  %t213 = getelementptr %"compiler/parse:Parser", ptr %t209, i32 0, i32 19
  store i1 %t210, ptr %t213, !tbaa !21
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i1, ptr %l3, !tbaa !21
  %t218 = getelementptr %"compiler/parse:Parser", ptr %t214, i32 0, i32 18
  store i1 %t215, ptr %t218, !tbaa !21
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l88, !tbaa !29
  %t220 = load ptr, ptr %l88, !tbaa !29
  %t221 = getelementptr %"compiler/parse:Parser", ptr %t220, i32 0, i32 17
  %t222 = load i64, ptr %t221, !tbaa !24
  %t224 = sub i64 %t222, 1
  %t226 = load ptr, ptr %l88, !tbaa !29
  %t227 = getelementptr %"compiler/parse:Parser", ptr %t226, i32 0, i32 17
  store i64 %t224, ptr %t227, !tbaa !24
  %t229 = insertvalue { i32, ptr } zeroinitializer, i32 %t208, 0
  store { i32, ptr } %t229, ptr %rv
  br label %ret
bb30:
  %t230 = load i1, ptr %l78, !tbaa !21
  %t231 = xor i1 %t230, true
  br i1 %t231, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb9
bb35:
  %t233 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t233)
  br label %bb36
bb36:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/parse:Parser", ptr %t235, i32 0, i32 31
  %t238 = load i64, ptr %l4, !tbaa !24
  %t241 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t237, i64 %t238)
  store { i64, ptr } %t241, ptr %l96
  br label %bb37
bb37:
  %t242 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t242, ptr %l8, !tbaa !27
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t246 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t243, i32 93)
  %t247 = extractvalue { i32, i32 } %t246, 1
  %t248 = extractvalue { i32, i32 } %t246, 0
  store i32 %t248, ptr %l101
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb39, label %ok.250
ok.250:
  store i32 %t247, ptr %l100
  br label %bb38
bb38:
  %t251 = load i32, ptr %l100, !tbaa !23
  store i32 %t251, ptr %l97, !tbaa !23
  br label %bb40
bb39:
  %t252 = load i32, ptr %l101, !tbaa !23
  %t253 = lshr i32 %t252, 16
  %t254 = and i32 %t252, 65535
  %t255 = icmp eq i32 %t253, 1
  %t256 = select i1 %t255, i32 1, i32 0
  %t257 = icmp eq i32 %t252, 0
  %t258 = shl i32 %t256, 16
  %t259 = or i32 %t258, %t254
  %t260 = select i1 %t257, i32 0, i32 %t259
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i1, ptr %l2, !tbaa !21
  %t265 = getelementptr %"compiler/parse:Parser", ptr %t261, i32 0, i32 19
  store i1 %t262, ptr %t265, !tbaa !21
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i1, ptr %l3, !tbaa !21
  %t270 = getelementptr %"compiler/parse:Parser", ptr %t266, i32 0, i32 18
  store i1 %t267, ptr %t270, !tbaa !21
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l107, !tbaa !29
  %t272 = load ptr, ptr %l107, !tbaa !29
  %t273 = getelementptr %"compiler/parse:Parser", ptr %t272, i32 0, i32 17
  %t274 = load i64, ptr %t273, !tbaa !24
  %t276 = sub i64 %t274, 1
  %t278 = load ptr, ptr %l107, !tbaa !29
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t278, i32 0, i32 17
  store i64 %t276, ptr %t279, !tbaa !24
  %t281 = insertvalue { i32, ptr } zeroinitializer, i32 %t260, 0
  store { i32, ptr } %t281, ptr %rv
  br label %ret
bb40:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l1, !tbaa !23
  %t286 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t282, i32 %t283)
  store %"compiler/source:Span" %t286, ptr %l112
  br label %bb41
bb41:
  %t287 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t287, ptr %l113, !tbaa !27
  %t288 = load ptr, ptr %l5, !tbaa !29
  %t290 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aOutlives_26_3e_2eToAr_H5eeb6199570724b12f836c014634c4fb(ptr %v0, ptr %v0, ptr %t288)
  store { i64, ptr } %t290, ptr %l115
  br label %bb42
bb42:
  %t291 = load %"compiler/source:Span", ptr %l112
  %t292 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t294 = call %"compiler/ast:ContractBlock" @compiler_2fast_3aContractBlock_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t291, { i64, ptr } %t292, { i64, ptr } %t293)
  store %"compiler/ast:ContractBlock" %t294, ptr %l116
  br label %bb43
bb43:
  %t295 = load %"compiler/ast:ContractBlock", ptr %l116
  %t296 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:ContractBlock" %t295, ptr %t296
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i1, ptr %l2, !tbaa !21
  %t301 = getelementptr %"compiler/parse:Parser", ptr %t297, i32 0, i32 19
  store i1 %t298, ptr %t301, !tbaa !21
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i1, ptr %l3, !tbaa !21
  %t306 = getelementptr %"compiler/parse:Parser", ptr %t302, i32 0, i32 18
  store i1 %t303, ptr %t306, !tbaa !21
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l122, !tbaa !29
  %t308 = load ptr, ptr %l122, !tbaa !29
  %t309 = getelementptr %"compiler/parse:Parser", ptr %t308, i32 0, i32 17
  %t310 = load i64, ptr %t309, !tbaa !24
  %t312 = sub i64 %t310, 1
  %t314 = load ptr, ptr %l122, !tbaa !29
  %t315 = getelementptr %"compiler/parse:Parser", ptr %t314, i32 0, i32 17
  store i64 %t312, ptr %t315, !tbaa !24
  %t317 = insertvalue { i32, ptr } zeroinitializer, ptr %t296, 1
  store { i32, ptr } %t317, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 92)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t9 = insertvalue { i32, ptr } zeroinitializer, ptr null, 1
  store { i32, ptr } %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtract(ptr %v0, ptr %t10)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l9
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16
ok.16:
  store ptr %t13, ptr %l8
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l8, !tbaa !29
  store ptr %t17, ptr %l6, !tbaa !29
  br label %bb7
bb6:
  %t18 = load i32, ptr %l9, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t31 = insertvalue { i32, ptr } zeroinitializer, ptr %t29, 1
  store { i32, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/parse:NameList", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/source:Span", ptr %t6, i64 0
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l3
  store ptr %a0, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l8, !tbaa !23
  %t13 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %l9, !tbaa !23
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/parse:NameList", ptr %t15, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarListCount(ptr %s0, i64 %t20, i64 %a2)
  store %"compiler/msgs:Msg" %t24, ptr %l14
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i32, ptr %l8, !tbaa !23
  %t27 = load i32, ptr %l9, !tbaa !23
  %t28 = load %"compiler/msgs:Msg", ptr %l14
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s0, ptr %t25, i32 %t26, i32 %t27, %"compiler/msgs:Msg" %t28)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %lp12 = alloca ptr
  %l13 = alloca %"compiler/token:Token"
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca %"compiler/token:Token"
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l25 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i1
  %l42 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l46 = alloca i32
  %l49 = alloca %"compiler/token:Token"
  %l51 = alloca i32
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca i32
  %l59 = alloca %"compiler/source:Span"
  %l61 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca i32
  %l67 = alloca %"compiler/source:Span"
  %l73 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i32
  %l81 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i32
  %l92 = alloca i32
  %l95 = alloca i1
  %l97 = alloca i32
  %l98 = alloca i32
  %l100 = alloca i32
  %l101 = alloca i32
  %l105 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca i32
  %l116 = alloca %"compiler/ast:TypeDecl"
  %l120 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca i32
  %l127 = alloca i1
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca i32
  %l138 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l142 = alloca i32
  %l144 = alloca ptr
  %l147 = alloca ptr
  %l148 = alloca i32
  %l151 = alloca i32
  %l159 = alloca i32
  %l162 = alloca i1
  %l163 = alloca ptr
  %l165 = alloca ptr
  %l166 = alloca i32
  %l171 = alloca i1
  %l173 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l177 = alloca i32
  %l180 = alloca %"compiler/token:Token"
  %l182 = alloca i32
  %l183 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l186 = alloca i32
  %l190 = alloca %"compiler/source:Span"
  %l193 = alloca %"compiler/source:Span"
  %l200 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca i32
  %l208 = alloca ptr
  %l210 = alloca %"compiler/token:Token"
  %l211 = alloca { i64, ptr }
  %l212 = alloca i1
  %l213 = alloca i1
  %l215 = alloca i32
  %l219 = alloca i32
  %l220 = alloca ptr
  %l222 = alloca ptr
  %l223 = alloca i32
  %l227 = alloca %"compiler/source:Span"
  %l240 = alloca %"compiler/ast:Func"
  %l245 = alloca i32
  %l249 = alloca %"compiler/token:Token"
  %l250 = alloca i32
  %l252 = alloca i32
  %l253 = alloca i32
  %l256 = alloca i32
  %l257 = alloca ptr
  %l259 = alloca ptr
  %l260 = alloca i32
  %l264 = alloca %"compiler/source:Span"
  %l266 = alloca i32
  %l268 = alloca %"compiler/source:Span"
  %l271 = alloca %"compiler/source:Span"
  %l278 = alloca ptr
  %l280 = alloca ptr
  %l281 = alloca i32
  %l285 = alloca %"compiler/source:Span"
  %l287 = alloca i32
  %l294 = alloca i32
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t134 = alloca { i64, [6 x i64] }, align 8
  %t203 = alloca { i64, [6 x i64] }, align 8
  %t281 = alloca { i64, [6 x i64] }, align 8
  %t292 = alloca { i64, [6 x i64] }, align 8
  %t425 = alloca { i64, [6 x i64] }, align 8
  %t547 = alloca { i64, [6 x i64] }, align 8
  %t676 = alloca { i64, [6 x i64] }, align 8
  %t772 = alloca { i64, [5 x i64] }, align 8
  %t783 = alloca { i64, [6 x i64] }, align 8
  %t841 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i32, ptr %l23, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l25
  br label %bb2
bb2:
  %t8 = load i32, ptr %l25
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2
  %t11 = trunc i64 41 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l29
  br label %bb6
bb6:
  store i32 0, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t17, i32 1)
  store i1 %t20, ptr %l32
  br label %bb7
bb7:
  %t21 = load i1, ptr %l32, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t22)
  %t25 = extractvalue { i32, i32 } %t24, 1
  %t26 = extractvalue { i32, i32 } %t24, 0
  store i32 %t26, ptr %l36
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb11, label %ok.28
ok.28:
  store i32 %t25, ptr %l35
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t29 = load i32, ptr %l35, !tbaa !23
  store i32 %t29, ptr %l33, !tbaa !23
  br label %bb12
bb11:
  %t30 = load i32, ptr %l36, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb12:
  %t41 = load i32, ptr %l33, !tbaa !23
  store i32 %t41, ptr %l3, !tbaa !23
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t42, i32 5)
  store i1 %t45, ptr %l40
  br label %bb14
bb14:
  %t46 = load i1, ptr %l40, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l42, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s3, i32 5)
  store { i64, ptr } %t51, ptr %l44
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t52 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l42, !tbaa !29
  %t61 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s3, ptr %t59, { i64, ptr } %t58)
  store i32 %t61, ptr %l46
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb19, label %ok.63
ok.63:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t64 = load i32, ptr %l46, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  call void @__olang_scope_close(ptr %s3)
  %t74 = insertvalue { i32, ptr } zeroinitializer, i32 %t72, 0
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t75)
  store %"compiler/token:Token" %t77, ptr %l49
  br label %bb22
bb22:
  %t78 = load %"compiler/token:Token", ptr %l49
  store %"compiler/token:Token" %t78, ptr %l4
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l51
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call { i32, %"compiler/source:Span" } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elinkClause(ptr %v0, ptr %t82)
  %t85 = extractvalue { i32, %"compiler/source:Span" } %t84, 1
  %t86 = extractvalue { i32, %"compiler/source:Span" } %t84, 0
  store i32 %t86, ptr %l55
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb25, label %ok.88
ok.88:
  store %"compiler/source:Span" %t85, ptr %l54
  br label %bb24
bb24:
  %t89 = load %"compiler/source:Span", ptr %l54
  store %"compiler/source:Span" %t89, ptr %l52
  br label %bb26
bb25:
  %t90 = load i32, ptr %l55, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  %t100 = insertvalue { i32, ptr } zeroinitializer, i32 %t98, 0
  store { i32, ptr } %t100, ptr %rv
  br label %ret
bb26:
  %t101 = load %"compiler/source:Span", ptr %l52
  store %"compiler/source:Span" %t101, ptr %l5
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l1, !tbaa !23
  %t106 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t102, i32 %t103)
  store %"compiler/source:Span" %t106, ptr %l59
  br label %bb27
bb27:
  %t107 = load %"compiler/source:Span", ptr %l59
  store %"compiler/source:Span" %t107, ptr %l6
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t108)
  store i32 %t110, ptr %l61
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb29, label %ok.112
ok.112:
  br label %bb28
bb28:
  br label %bb30
bb29:
  %t113 = load i32, ptr %l61, !tbaa !23
  %t114 = lshr i32 %t113, 16
  %t115 = and i32 %t113, 65535
  %t116 = icmp eq i32 %t114, 1
  %t117 = select i1 %t116, i32 1, i32 0
  %t118 = icmp eq i32 %t113, 0
  %t119 = shl i32 %t117, 16
  %t120 = or i32 %t119, %t115
  %t121 = select i1 %t118, i32 0, i32 %t120
  %t123 = insertvalue { i32, ptr } zeroinitializer, i32 %t121, 0
  store { i32, ptr } %t123, ptr %rv
  br label %ret
bb30:
  %t124 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t124, ptr %l63
  %t125 = load i32, ptr %l3, !tbaa !23
  store i32 %t125, ptr %l64, !tbaa !23
  %t126 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 2
  %t127 = load i32, ptr %t126, !tbaa !23
  %t128 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t127, i32 %t129)
  store %"compiler/source:Span" %t132, ptr %l67
  br label %bb31
bb31:
  %t133 = load %"compiler/source:Span", ptr %l5
  store { i64, [6 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [6 x i64] }, ptr %t134, i32 0, i32 0
  store i64 4, ptr %t135
  %t136 = load %"compiler/source:Span", ptr %l63
  %t137 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } undef, %"compiler/source:Span" %t136, 0
  %t138 = load i32, ptr %l64, !tbaa !23
  %t139 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } %t137, i32 %t138, 1
  %t140 = load %"compiler/source:Span", ptr %l67
  %t141 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } %t139, %"compiler/source:Span" %t140, 2
  %t143 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } %t141, %"compiler/source:Span" %t133, 3
  %t144 = getelementptr { i64, [6 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" } %t143, ptr %t144
  %t145 = load { i64, [6 x i64] }, ptr %t134
  %t147 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t145, ptr %t147
  %t149 = insertvalue { i32, ptr } zeroinitializer, ptr %t147, 1
  store { i32, ptr } %t149, ptr %rv
  br label %ret
bb32:
  %t150 = load i32, ptr %l2
  %t152 = trunc i64 34 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDecl(ptr %v0, ptr %t155)
  %t158 = extractvalue { i32, ptr } %t157, 1
  %t159 = extractvalue { i32, ptr } %t157, 0
  store i32 %t159, ptr %l76
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb37, label %ok.161
ok.161:
  store ptr %t158, ptr %l75
  br label %bb36
bb36:
  %t162 = load ptr, ptr %l75, !tbaa !29
  store ptr %t162, ptr %l73, !tbaa !29
  br label %bb38
bb37:
  %t163 = load i32, ptr %l76, !tbaa !23
  %t164 = lshr i32 %t163, 16
  %t165 = and i32 %t163, 65535
  %t166 = icmp eq i32 %t164, 1
  %t167 = select i1 %t166, i32 1, i32 0
  %t168 = icmp eq i32 %t163, 0
  %t169 = shl i32 %t167, 16
  %t170 = or i32 %t169, %t165
  %t171 = select i1 %t168, i32 0, i32 %t170
  %t173 = insertvalue { i32, ptr } zeroinitializer, i32 %t171, 0
  store { i32, ptr } %t173, ptr %rv
  br label %ret
bb38:
  %t174 = load ptr, ptr %l73, !tbaa !29
  %t176 = insertvalue { i32, ptr } zeroinitializer, ptr %t174, 1
  store { i32, ptr } %t176, ptr %rv
  br label %ret
bb39:
  %t177 = load i32, ptr %l2
  %t179 = trunc i64 38 to i32
  %t180 = icmp eq i32 %t177, %t179
  br i1 %t180, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efunction(ptr %v0, ptr %t182)
  %t185 = extractvalue { i32, ptr } %t184, 1
  %t186 = extractvalue { i32, ptr } %t184, 0
  store i32 %t186, ptr %l84
  %t187 = icmp ne i32 %t186, 0
  br i1 %t187, label %bb44, label %ok.188
ok.188:
  store ptr %t185, ptr %l83
  br label %bb43
bb43:
  %t189 = load ptr, ptr %l83, !tbaa !29
  store ptr %t189, ptr %l81, !tbaa !29
  br label %bb45
bb44:
  %t190 = load i32, ptr %l84, !tbaa !23
  %t191 = lshr i32 %t190, 16
  %t192 = and i32 %t190, 65535
  %t193 = icmp eq i32 %t191, 1
  %t194 = select i1 %t193, i32 1, i32 0
  %t195 = icmp eq i32 %t190, 0
  %t196 = shl i32 %t194, 16
  %t197 = or i32 %t196, %t192
  %t198 = select i1 %t195, i32 0, i32 %t197
  %t200 = insertvalue { i32, ptr } zeroinitializer, i32 %t198, 0
  store { i32, ptr } %t200, ptr %rv
  br label %ret
bb45:
  %t201 = load ptr, ptr %l81, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t203
  %t204 = getelementptr { i64, [6 x i64] }, ptr %t203, i32 0, i32 0
  store i64 0, ptr %t204
  %t206 = insertvalue { ptr } undef, ptr %t201, 0
  %t207 = getelementptr { i64, [6 x i64] }, ptr %t203, i32 0, i32 1
  store { ptr } %t206, ptr %t207
  %t208 = load { i64, [6 x i64] }, ptr %t203
  %t210 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t208, ptr %t210
  %t212 = insertvalue { i32, ptr } zeroinitializer, ptr %t210, 1
  store { i32, ptr } %t212, ptr %rv
  br label %ret
bb46:
  %t213 = load i32, ptr %l2
  %t215 = trunc i64 44 to i32
  %t216 = icmp eq i32 %t213, %t215
  br i1 %t216, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb91
bb49:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t218)
  store i32 %t220, ptr %l92
  br label %bb50
bb50:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t224 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t221, i32 34)
  store i1 %t224, ptr %l95
  br label %bb51
bb51:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb52, label %bb53
bb52:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t226)
  store i32 %t228, ptr %l97
  br label %bb54
bb53:
  br label %bb67
bb54:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t229)
  %t232 = extractvalue { i32, i32 } %t231, 1
  %t233 = extractvalue { i32, i32 } %t231, 0
  store i32 %t233, ptr %l101
  %t234 = icmp ne i32 %t233, 0
  br i1 %t234, label %bb56, label %ok.235
ok.235:
  store i32 %t232, ptr %l100
  br label %bb55
bb55:
  %t236 = load i32, ptr %l100, !tbaa !23
  store i32 %t236, ptr %l98, !tbaa !23
  br label %bb57
bb56:
  %t237 = load i32, ptr %l101, !tbaa !23
  %t238 = lshr i32 %t237, 16
  %t239 = and i32 %t237, 65535
  %t240 = icmp eq i32 %t238, 1
  %t241 = select i1 %t240, i32 1, i32 0
  %t242 = icmp eq i32 %t237, 0
  %t243 = shl i32 %t241, 16
  %t244 = or i32 %t243, %t239
  %t245 = select i1 %t242, i32 0, i32 %t244
  %t247 = insertvalue { i32, ptr } zeroinitializer, i32 %t245, 0
  store { i32, ptr } %t247, ptr %rv
  br label %ret
bb57:
  %t248 = load i32, ptr %l98, !tbaa !23
  store i32 %t248, ptr %l8, !tbaa !23
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i32, ptr %l1, !tbaa !23
  %t253 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t249, i32 %t250)
  store %"compiler/source:Span" %t253, ptr %l105
  br label %bb58
bb58:
  %t254 = load %"compiler/source:Span", ptr %l105
  store %"compiler/source:Span" %t254, ptr %l9
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t255)
  store i32 %t257, ptr %l107
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb60, label %ok.259
ok.259:
  br label %bb59
bb59:
  br label %bb61
bb60:
  %t260 = load i32, ptr %l107, !tbaa !23
  %t261 = lshr i32 %t260, 16
  %t262 = and i32 %t260, 65535
  %t263 = icmp eq i32 %t261, 1
  %t264 = select i1 %t263, i32 1, i32 0
  %t265 = icmp eq i32 %t260, 0
  %t266 = shl i32 %t264, 16
  %t267 = or i32 %t266, %t262
  %t268 = select i1 %t265, i32 0, i32 %t267
  %t270 = insertvalue { i32, ptr } zeroinitializer, i32 %t268, 0
  store { i32, ptr } %t270, ptr %rv
  br label %ret
bb61:
  %t271 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t271, ptr %l109
  %t272 = load i32, ptr %l8, !tbaa !23
  store i32 %t272, ptr %l110, !tbaa !23
  %t273 = icmp sge i64 0, 0
  br i1 %t273, label %bb62, label %bb63
bb62:
  %t275 = icmp sle i64 0, 1152921504606846975
  br i1 %t275, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe)
  unreachable
bb64:
  %t277 = mul i64 0, 8
  %t278 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t277)
  %t279 = insertvalue { i64, ptr } undef, i64 0, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t281
  %t282 = getelementptr { i64, [6 x i64] }, ptr %t281, i32 0, i32 0
  store i64 4, ptr %t282
  %t283 = load { i64, [6 x i64] }, ptr %t281
  %t285 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t283, ptr %t285
  %t286 = load i32, ptr %l110, !tbaa !23
  %t289 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t286, { i64, ptr } %t280, i1 false, ptr %t285)
  store %"compiler/ast:TypeDecl" %t289, ptr %l116
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe)
  unreachable
bb66:
  %t290 = load %"compiler/ast:TypeDecl", ptr %l116
  %t291 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:TypeDecl" %t290, ptr %t291
  store { i64, [6 x i64] } zeroinitializer, ptr %t292
  %t293 = getelementptr { i64, [6 x i64] }, ptr %t292, i32 0, i32 0
  store i64 2, ptr %t293
  %t294 = load %"compiler/source:Span", ptr %l109
  %t295 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t294, 0
  %t297 = insertvalue { %"compiler/source:Span", ptr } %t295, ptr %t291, 1
  %t298 = getelementptr { i64, [6 x i64] }, ptr %t292, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t297, ptr %t298
  %t299 = load { i64, [6 x i64] }, ptr %t292
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t299, ptr %t301
  %t303 = insertvalue { i32, ptr } zeroinitializer, ptr %t301, 1
  store { i32, ptr } %t303, ptr %rv
  br label %ret
bb67:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = call { i32, %"compiler/source:Span" } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elinkClause(ptr %v0, ptr %t304)
  %t307 = extractvalue { i32, %"compiler/source:Span" } %t306, 1
  %t308 = extractvalue { i32, %"compiler/source:Span" } %t306, 0
  store i32 %t308, ptr %l123
  %t309 = icmp ne i32 %t308, 0
  br i1 %t309, label %bb69, label %ok.310
ok.310:
  store %"compiler/source:Span" %t307, ptr %l122
  br label %bb68
bb68:
  %t311 = load %"compiler/source:Span", ptr %l122
  store %"compiler/source:Span" %t311, ptr %l120
  br label %bb70
bb69:
  %t312 = load i32, ptr %l123, !tbaa !23
  %t313 = lshr i32 %t312, 16
  %t314 = and i32 %t312, 65535
  %t315 = icmp eq i32 %t313, 1
  %t316 = select i1 %t315, i32 1, i32 0
  %t317 = icmp eq i32 %t312, 0
  %t318 = shl i32 %t316, 16
  %t319 = or i32 %t318, %t314
  %t320 = select i1 %t317, i32 0, i32 %t319
  %t322 = insertvalue { i32, ptr } zeroinitializer, i32 %t320, 0
  store { i32, ptr } %t322, ptr %rv
  br label %ret
bb70:
  %t323 = load %"compiler/source:Span", ptr %l120
  store %"compiler/source:Span" %t323, ptr %l10
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t327 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t324, i32 94)
  store i1 %t327, ptr %l127
  br label %bb71
bb71:
  %t328 = load i1, ptr %l127, !tbaa !21
  br i1 %t328, label %bb72, label %bb73
bb72:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l1, !tbaa !23
  %t331 = load %"compiler/source:Span", ptr %l10
  %t335 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternBlock(ptr %v0, ptr %t329, i32 %t330, %"compiler/source:Span" %t331)
  %t336 = extractvalue { i32, ptr } %t335, 1
  %t337 = extractvalue { i32, ptr } %t335, 0
  store i32 %t337, ptr %l133
  %t338 = icmp ne i32 %t337, 0
  br i1 %t338, label %bb75, label %ok.339
ok.339:
  store ptr %t336, ptr %l132
  br label %bb74
bb73:
  br label %bb77
bb74:
  %t340 = load ptr, ptr %l132, !tbaa !29
  store ptr %t340, ptr %l128, !tbaa !29
  br label %bb76
bb75:
  %t341 = load i32, ptr %l133, !tbaa !23
  %t342 = lshr i32 %t341, 16
  %t343 = and i32 %t341, 65535
  %t344 = icmp eq i32 %t342, 1
  %t345 = select i1 %t344, i32 1, i32 0
  %t346 = icmp eq i32 %t341, 0
  %t347 = shl i32 %t345, 16
  %t348 = or i32 %t347, %t343
  %t349 = select i1 %t346, i32 0, i32 %t348
  %t351 = insertvalue { i32, ptr } zeroinitializer, i32 %t349, 0
  store { i32, ptr } %t351, ptr %rv
  br label %ret
bb76:
  %t352 = load ptr, ptr %l128, !tbaa !29
  %t354 = insertvalue { i32, ptr } zeroinitializer, ptr %t352, 1
  store { i32, ptr } %t354, ptr %rv
  br label %ret
bb77:
  %t355 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t356 = load i32, ptr %t355, !tbaa !23
  %t358 = icmp sgt i32 %t356, 0
  br i1 %t358, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s9
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l138, !tbaa !29
  %t362 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s9, i32 94)
  store { i64, ptr } %t362, ptr %l140
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t363 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t363, 0
  %t365 = extractvalue { i64, ptr } %t363, 1
  %t366 = mul i64 %t364, 1
  %t367 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t366)
  call void @llvm.memcpy.p0.p0.i64(ptr %t367, ptr %t365, i64 %t366, i1 false)
  %t368 = insertvalue { i64, ptr } undef, i64 %t364, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t367, 1
  %t370 = load ptr, ptr %l138, !tbaa !29
  %t372 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s9, ptr %t370, { i64, ptr } %t369)
  store i32 %t372, ptr %l142
  %t373 = icmp ne i32 %t372, 0
  br i1 %t373, label %bb82, label %ok.374
ok.374:
  br label %bb81
bb81:
  br label %bb83
bb82:
  %t375 = load i32, ptr %l142, !tbaa !23
  %t376 = lshr i32 %t375, 16
  %t377 = and i32 %t375, 65535
  %t378 = icmp eq i32 %t376, 1
  %t379 = select i1 %t378, i32 1, i32 0
  %t380 = icmp eq i32 %t375, 0
  %t381 = shl i32 %t379, 16
  %t382 = or i32 %t381, %t377
  %t383 = select i1 %t380, i32 0, i32 %t382
  call void @__olang_scope_close(ptr %s9)
  %t385 = insertvalue { i32, ptr } zeroinitializer, i32 %t383, 0
  store { i32, ptr } %t385, ptr %rv
  br label %ret
bb83:
  call void @__olang_scope_close(ptr %s9)
  br label %bb84
bb84:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load i32, ptr %l1, !tbaa !23
  %t390 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %t386, i32 %t387)
  %t391 = extractvalue { i32, ptr } %t390, 1
  %t392 = extractvalue { i32, ptr } %t390, 0
  store i32 %t392, ptr %l148
  %t393 = icmp ne i32 %t392, 0
  br i1 %t393, label %bb86, label %ok.394
ok.394:
  store ptr %t391, ptr %l147
  br label %bb85
bb85:
  %t395 = load ptr, ptr %l147, !tbaa !29
  store ptr %t395, ptr %l144, !tbaa !29
  br label %bb87
bb86:
  %t396 = load i32, ptr %l148, !tbaa !23
  %t397 = lshr i32 %t396, 16
  %t398 = and i32 %t396, 65535
  %t399 = icmp eq i32 %t397, 1
  %t400 = select i1 %t399, i32 1, i32 0
  %t401 = icmp eq i32 %t396, 0
  %t402 = shl i32 %t400, 16
  %t403 = or i32 %t402, %t398
  %t404 = select i1 %t401, i32 0, i32 %t403
  %t406 = insertvalue { i32, ptr } zeroinitializer, i32 %t404, 0
  store { i32, ptr } %t406, ptr %rv
  br label %ret
bb87:
  %t407 = load ptr, ptr %l144, !tbaa !29
  store ptr %t407, ptr %l11, !tbaa !29
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t408)
  store i32 %t410, ptr %l151
  %t411 = icmp ne i32 %t410, 0
  br i1 %t411, label %bb89, label %ok.412
ok.412:
  br label %bb88
bb88:
  br label %bb90
bb89:
  %t413 = load i32, ptr %l151, !tbaa !23
  %t414 = lshr i32 %t413, 16
  %t415 = and i32 %t413, 65535
  %t416 = icmp eq i32 %t414, 1
  %t417 = select i1 %t416, i32 1, i32 0
  %t418 = icmp eq i32 %t413, 0
  %t419 = shl i32 %t417, 16
  %t420 = or i32 %t419, %t415
  %t421 = select i1 %t418, i32 0, i32 %t420
  %t423 = insertvalue { i32, ptr } zeroinitializer, i32 %t421, 0
  store { i32, ptr } %t423, ptr %rv
  br label %ret
bb90:
  %t424 = load ptr, ptr %l11, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t425
  %t426 = getelementptr { i64, [6 x i64] }, ptr %t425, i32 0, i32 0
  store i64 1, ptr %t426
  %t428 = insertvalue { ptr } undef, ptr %t424, 0
  %t429 = getelementptr { i64, [6 x i64] }, ptr %t425, i32 0, i32 1
  store { ptr } %t428, ptr %t429
  %t430 = load { i64, [6 x i64] }, ptr %t425
  %t432 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t430, ptr %t432
  %t434 = insertvalue { i32, ptr } zeroinitializer, ptr %t432, 1
  store { i32, ptr } %t434, ptr %rv
  br label %ret
bb91:
  %t435 = load i32, ptr %l2
  %t437 = trunc i64 42 to i32
  %t438 = icmp eq i32 %t435, %t437
  br i1 %t438, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb118
bb94:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t440)
  store i32 %t442, ptr %l159
  br label %bb95
bb95:
  %t443 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t443, ptr %lp12
  %t444 = load ptr, ptr %lp12
  store ptr null, ptr %t444, !tbaa !29
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t448 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t445, i32 1)
  store i1 %t448, ptr %l162
  br label %bb96
bb96:
  %t449 = load i1, ptr %l162, !tbaa !21
  br i1 %t449, label %bb97, label %bb98
bb97:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t450)
  %t453 = extractvalue { i32, ptr } %t452, 1
  %t454 = extractvalue { i32, ptr } %t452, 0
  store i32 %t454, ptr %l166
  %t455 = icmp ne i32 %t454, 0
  br i1 %t455, label %bb100, label %ok.456
ok.456:
  store ptr %t453, ptr %l165
  br label %bb99
bb98:
  br label %bb102
bb99:
  %t457 = load ptr, ptr %l165, !tbaa !29
  store ptr %t457, ptr %l163, !tbaa !29
  br label %bb101
bb100:
  %t458 = load i32, ptr %l166, !tbaa !23
  %t459 = lshr i32 %t458, 16
  %t460 = and i32 %t458, 65535
  %t461 = icmp eq i32 %t459, 1
  %t462 = select i1 %t461, i32 1, i32 0
  %t463 = icmp eq i32 %t458, 0
  %t464 = shl i32 %t462, 16
  %t465 = or i32 %t464, %t460
  %t466 = select i1 %t463, i32 0, i32 %t465
  %t468 = insertvalue { i32, ptr } zeroinitializer, i32 %t466, 0
  store { i32, ptr } %t468, ptr %rv
  br label %ret
bb101:
  %t469 = load ptr, ptr %l163, !tbaa !29
  %t471 = load ptr, ptr %lp12
  store ptr %t469, ptr %t471, !tbaa !29
  br label %bb102
bb102:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t475 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t472, i32 5)
  store i1 %t475, ptr %l171
  br label %bb103
bb103:
  %t476 = load i1, ptr %l171, !tbaa !21
  %t477 = xor i1 %t476, true
  br i1 %t477, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s12
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l173, !tbaa !29
  %t481 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s12, i32 5)
  store { i64, ptr } %t481, ptr %l175
  br label %bb106
bb105:
  br label %bb110
bb106:
  %t482 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t482, 0
  %t484 = extractvalue { i64, ptr } %t482, 1
  %t485 = mul i64 %t483, 1
  %t486 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t486, ptr %t484, i64 %t485, i1 false)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  %t489 = load ptr, ptr %l173, !tbaa !29
  %t491 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s12, ptr %t489, { i64, ptr } %t488)
  store i32 %t491, ptr %l177
  %t492 = icmp ne i32 %t491, 0
  br i1 %t492, label %bb108, label %ok.493
ok.493:
  br label %bb107
bb107:
  br label %bb109
bb108:
  %t494 = load i32, ptr %l177, !tbaa !23
  %t495 = lshr i32 %t494, 16
  %t496 = and i32 %t494, 65535
  %t497 = icmp eq i32 %t495, 1
  %t498 = select i1 %t497, i32 1, i32 0
  %t499 = icmp eq i32 %t494, 0
  %t500 = shl i32 %t498, 16
  %t501 = or i32 %t500, %t496
  %t502 = select i1 %t499, i32 0, i32 %t501
  call void @__olang_scope_close(ptr %s12)
  %t504 = insertvalue { i32, ptr } zeroinitializer, i32 %t502, 0
  store { i32, ptr } %t504, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s12)
  br label %bb110
bb110:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t505)
  store %"compiler/token:Token" %t507, ptr %l180
  br label %bb111
bb111:
  %t508 = load %"compiler/token:Token", ptr %l180
  store %"compiler/token:Token" %t508, ptr %l13
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t509)
  store i32 %t511, ptr %l182
  br label %bb112
bb112:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t512)
  %t515 = extractvalue { i32, { i64, ptr } } %t514, 1
  %t516 = extractvalue { i32, { i64, ptr } } %t514, 0
  store i32 %t516, ptr %l186
  %t517 = icmp ne i32 %t516, 0
  br i1 %t517, label %bb114, label %ok.518
ok.518:
  store { i64, ptr } %t515, ptr %l185
  br label %bb113
bb113:
  %t519 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t519, ptr %l183, !tbaa !27
  br label %bb115
bb114:
  %t520 = load i32, ptr %l186, !tbaa !23
  %t521 = lshr i32 %t520, 16
  %t522 = and i32 %t520, 65535
  %t523 = icmp eq i32 %t521, 1
  %t524 = select i1 %t523, i32 1, i32 0
  %t525 = icmp eq i32 %t520, 0
  %t526 = shl i32 %t524, 16
  %t527 = or i32 %t526, %t522
  %t528 = select i1 %t525, i32 0, i32 %t527
  %t530 = insertvalue { i32, ptr } zeroinitializer, i32 %t528, 0
  store { i32, ptr } %t530, ptr %rv
  br label %ret
bb115:
  %t531 = load { i64, ptr }, ptr %l183, !tbaa !27
  store { i64, ptr } %t531, ptr %l14, !tbaa !27
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load i32, ptr %l1, !tbaa !23
  %t536 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t532, i32 %t533)
  store %"compiler/source:Span" %t536, ptr %l190
  br label %bb116
bb116:
  %t537 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 2
  %t538 = load i32, ptr %t537, !tbaa !23
  %t539 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 3
  %t540 = load i32, ptr %t539, !tbaa !23
  %t543 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t538, i32 %t540)
  store %"compiler/source:Span" %t543, ptr %l193
  br label %bb117
bb117:
  %t544 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t545 = load ptr, ptr %lp12
  %t546 = load ptr, ptr %t545, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t547
  %t548 = getelementptr { i64, [6 x i64] }, ptr %t547, i32 0, i32 0
  store i64 6, ptr %t548
  %t549 = load %"compiler/source:Span", ptr %l190
  %t550 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t549, 0
  %t551 = load %"compiler/source:Span", ptr %l193
  %t552 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } %t550, %"compiler/source:Span" %t551, 1
  %t554 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } %t552, { i64, ptr } %t544, 2
  %t556 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } %t554, ptr %t546, 3
  %t557 = getelementptr { i64, [6 x i64] }, ptr %t547, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr } %t556, ptr %t557
  %t558 = load { i64, [6 x i64] }, ptr %t547
  %t560 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t558, ptr %t560
  %t562 = insertvalue { i32, ptr } zeroinitializer, ptr %t560, 1
  store { i32, ptr } %t562, ptr %rv
  br label %ret
bb118:
  %t563 = load i32, ptr %l2
  %t565 = trunc i64 9 to i32
  %t566 = icmp eq i32 %t563, %t565
  br i1 %t566, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb125
bb121:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIf(ptr %v0, ptr %t568)
  %t571 = extractvalue { i32, ptr } %t570, 1
  %t572 = extractvalue { i32, ptr } %t570, 0
  store i32 %t572, ptr %l203
  %t573 = icmp ne i32 %t572, 0
  br i1 %t573, label %bb123, label %ok.574
ok.574:
  store ptr %t571, ptr %l202
  br label %bb122
bb122:
  %t575 = load ptr, ptr %l202, !tbaa !29
  store ptr %t575, ptr %l200, !tbaa !29
  br label %bb124
bb123:
  %t576 = load i32, ptr %l203, !tbaa !23
  %t577 = lshr i32 %t576, 16
  %t578 = and i32 %t576, 65535
  %t579 = icmp eq i32 %t577, 1
  %t580 = select i1 %t579, i32 1, i32 0
  %t581 = icmp eq i32 %t576, 0
  %t582 = shl i32 %t580, 16
  %t583 = or i32 %t582, %t578
  %t584 = select i1 %t581, i32 0, i32 %t583
  %t586 = insertvalue { i32, ptr } zeroinitializer, i32 %t584, 0
  store { i32, ptr } %t586, ptr %rv
  br label %ret
bb124:
  %t587 = load ptr, ptr %l200, !tbaa !29
  %t589 = insertvalue { i32, ptr } zeroinitializer, ptr %t587, 1
  store { i32, ptr } %t589, ptr %rv
  br label %ret
bb125:
  %t590 = load i32, ptr %l2
  %t592 = trunc i64 1 to i32
  %t593 = icmp eq i32 %t590, %t592
  br i1 %t593, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb169
bb128:
  store %olang.scope zeroinitializer, ptr %s14
  %t595 = load ptr, ptr %l0, !tbaa !29
  store ptr %t595, ptr %l208, !tbaa !29
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t596)
  store %"compiler/token:Token" %t598, ptr %l210
  br label %bb129
bb129:
  %t599 = load ptr, ptr %l208, !tbaa !29
  %t600 = load %"compiler/token:Token", ptr %l210
  %t601 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t599, %"compiler/token:Token" %t600)
  store { i64, ptr } %t601, ptr %l211
  br label %bb130
bb130:
  %t602 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t603 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s14, { i64, ptr } %t602, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t603, ptr %l212
  br label %bb131
bb131:
  %t604 = load i1, ptr %l212, !tbaa !21
  br i1 %t604, label %bb132, label %bb133
bb132:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t605, i64 1)
  store i32 %t607, ptr %l215
  br label %bb134
bb133:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb135
bb134:
  %t608 = load i32, ptr %l215
  %t610 = trunc i64 38 to i32
  %t611 = icmp eq i32 %t608, %t610
  store i1 %t611, ptr %l213, !tbaa !21
  br label %bb135
bb135:
  %t613 = load i1, ptr %l213, !tbaa !21
  br i1 %t613, label %bb136, label %bb137
bb136:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t614)
  store i32 %t616, ptr %l219
  br label %bb138
bb137:
  br label %bb144
bb138:
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t619 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efunction(ptr %v0, ptr %t617)
  %t620 = extractvalue { i32, ptr } %t619, 1
  %t621 = extractvalue { i32, ptr } %t619, 0
  store i32 %t621, ptr %l223
  %t622 = icmp ne i32 %t621, 0
  br i1 %t622, label %bb140, label %ok.623
ok.623:
  store ptr %t620, ptr %l222
  br label %bb139
bb139:
  %t624 = load ptr, ptr %l222, !tbaa !29
  store ptr %t624, ptr %l220, !tbaa !29
  br label %bb141
bb140:
  %t625 = load i32, ptr %l223, !tbaa !23
  %t626 = lshr i32 %t625, 16
  %t627 = and i32 %t625, 65535
  %t628 = icmp eq i32 %t626, 1
  %t629 = select i1 %t628, i32 1, i32 0
  %t630 = icmp eq i32 %t625, 0
  %t631 = shl i32 %t629, 16
  %t632 = or i32 %t631, %t627
  %t633 = select i1 %t630, i32 0, i32 %t632
  call void @__olang_scope_close(ptr %s14)
  %t635 = insertvalue { i32, ptr } zeroinitializer, i32 %t633, 0
  store { i32, ptr } %t635, ptr %rv
  br label %ret
bb141:
  %t636 = load ptr, ptr %l220, !tbaa !29
  store ptr %t636, ptr %l15, !tbaa !29
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load i32, ptr %l1, !tbaa !23
  %t641 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t637, i32 %t638)
  store %"compiler/source:Span" %t641, ptr %l227
  br label %bb142
bb142:
  %t642 = load ptr, ptr %l15, !tbaa !29
  %t644 = getelementptr %"compiler/ast:Func", ptr %t642, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !29
  %t646 = load ptr, ptr %l15, !tbaa !29
  %t648 = getelementptr %"compiler/ast:Func", ptr %t646, i32 0, i32 2
  %t649 = load i32, ptr %t648, !tbaa !23
  %t650 = load ptr, ptr %l15, !tbaa !29
  %t652 = getelementptr %"compiler/ast:Func", ptr %t650, i32 0, i32 3
  %t653 = load ptr, ptr %t652, !tbaa !29
  %t654 = load ptr, ptr %l15, !tbaa !29
  %t656 = getelementptr %"compiler/ast:Func", ptr %t654, i32 0, i32 4
  %t657 = load { i64, ptr }, ptr %t656, !tbaa !27
  %t658 = load ptr, ptr %l15, !tbaa !29
  %t660 = getelementptr %"compiler/ast:Func", ptr %t658, i32 0, i32 5
  %t661 = load { i64, ptr }, ptr %t660, !tbaa !27
  %t662 = load ptr, ptr %l15, !tbaa !29
  %t664 = getelementptr %"compiler/ast:Func", ptr %t662, i32 0, i32 6
  %t665 = load i1, ptr %t664, !tbaa !21
  %t666 = load %"compiler/source:Span", ptr %l227
  %t673 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t666, ptr %t645, i32 %t649, ptr %t653, { i64, ptr } %t657, { i64, ptr } %t661, i1 %t665, i1 true)
  store %"compiler/ast:Func" %t673, ptr %l240
  br label %bb143
bb143:
  %t674 = load %"compiler/ast:Func", ptr %l240
  %t675 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t674, ptr %t675
  store { i64, [6 x i64] } zeroinitializer, ptr %t676
  %t677 = getelementptr { i64, [6 x i64] }, ptr %t676, i32 0, i32 0
  store i64 0, ptr %t677
  %t679 = insertvalue { ptr } undef, ptr %t675, 0
  %t680 = getelementptr { i64, [6 x i64] }, ptr %t676, i32 0, i32 1
  store { ptr } %t679, ptr %t680
  %t681 = load { i64, [6 x i64] }, ptr %t676
  %t683 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t681, ptr %t683
  call void @__olang_scope_close(ptr %s14)
  %t685 = insertvalue { i32, ptr } zeroinitializer, ptr %t683, 1
  store { i32, ptr } %t685, ptr %rv
  br label %ret
bb144:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t686, i64 1)
  store i32 %t688, ptr %l245
  br label %bb145
bb145:
  %t689 = load i32, ptr %l245
  %t691 = trunc i64 60 to i32
  %t692 = icmp eq i32 %t689, %t691
  br i1 %t692, label %bb146, label %bb147
bb146:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t694)
  store %"compiler/token:Token" %t696, ptr %l249
  br label %bb148
bb147:
  br label %bb161
bb148:
  %t697 = load %"compiler/token:Token", ptr %l249
  store %"compiler/token:Token" %t697, ptr %l16
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t700 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t698)
  %t701 = extractvalue { i32, i32 } %t700, 1
  %t702 = extractvalue { i32, i32 } %t700, 0
  store i32 %t702, ptr %l253
  %t703 = icmp ne i32 %t702, 0
  br i1 %t703, label %bb150, label %ok.704
ok.704:
  store i32 %t701, ptr %l252
  br label %bb149
bb149:
  %t705 = load i32, ptr %l252, !tbaa !23
  store i32 %t705, ptr %l250, !tbaa !23
  br label %bb151
bb150:
  %t706 = load i32, ptr %l253, !tbaa !23
  %t707 = lshr i32 %t706, 16
  %t708 = and i32 %t706, 65535
  %t709 = icmp eq i32 %t707, 1
  %t710 = select i1 %t709, i32 1, i32 0
  %t711 = icmp eq i32 %t706, 0
  %t712 = shl i32 %t710, 16
  %t713 = or i32 %t712, %t708
  %t714 = select i1 %t711, i32 0, i32 %t713
  call void @__olang_scope_close(ptr %s14)
  %t716 = insertvalue { i32, ptr } zeroinitializer, i32 %t714, 0
  store { i32, ptr } %t716, ptr %rv
  br label %ret
bb151:
  %t717 = load i32, ptr %l250, !tbaa !23
  store i32 %t717, ptr %l17, !tbaa !23
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t720 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t718)
  store i32 %t720, ptr %l256
  br label %bb152
bb152:
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t723 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t721)
  %t724 = extractvalue { i32, ptr } %t723, 1
  %t725 = extractvalue { i32, ptr } %t723, 0
  store i32 %t725, ptr %l260
  %t726 = icmp ne i32 %t725, 0
  br i1 %t726, label %bb154, label %ok.727
ok.727:
  store ptr %t724, ptr %l259
  br label %bb153
bb153:
  %t728 = load ptr, ptr %l259, !tbaa !29
  store ptr %t728, ptr %l257, !tbaa !29
  br label %bb155
bb154:
  %t729 = load i32, ptr %l260, !tbaa !23
  %t730 = lshr i32 %t729, 16
  %t731 = and i32 %t729, 65535
  %t732 = icmp eq i32 %t730, 1
  %t733 = select i1 %t732, i32 1, i32 0
  %t734 = icmp eq i32 %t729, 0
  %t735 = shl i32 %t733, 16
  %t736 = or i32 %t735, %t731
  %t737 = select i1 %t734, i32 0, i32 %t736
  call void @__olang_scope_close(ptr %s14)
  %t739 = insertvalue { i32, ptr } zeroinitializer, i32 %t737, 0
  store { i32, ptr } %t739, ptr %rv
  br label %ret
bb155:
  %t740 = load ptr, ptr %l257, !tbaa !29
  store ptr %t740, ptr %l18, !tbaa !29
  %t741 = load ptr, ptr %l0, !tbaa !29
  %t742 = load i32, ptr %l1, !tbaa !23
  %t745 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t741, i32 %t742)
  store %"compiler/source:Span" %t745, ptr %l264
  br label %bb156
bb156:
  %t746 = load %"compiler/source:Span", ptr %l264
  store %"compiler/source:Span" %t746, ptr %l19
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t747)
  store i32 %t749, ptr %l266
  %t750 = icmp ne i32 %t749, 0
  br i1 %t750, label %bb158, label %ok.751
ok.751:
  br label %bb157
bb157:
  br label %bb159
bb158:
  %t752 = load i32, ptr %l266, !tbaa !23
  %t753 = lshr i32 %t752, 16
  %t754 = and i32 %t752, 65535
  %t755 = icmp eq i32 %t753, 1
  %t756 = select i1 %t755, i32 1, i32 0
  %t757 = icmp eq i32 %t752, 0
  %t758 = shl i32 %t756, 16
  %t759 = or i32 %t758, %t754
  %t760 = select i1 %t757, i32 0, i32 %t759
  call void @__olang_scope_close(ptr %s14)
  %t762 = insertvalue { i32, ptr } zeroinitializer, i32 %t760, 0
  store { i32, ptr } %t762, ptr %rv
  br label %ret
bb159:
  %t763 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t763, ptr %l268
  %t764 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t765 = load i32, ptr %t764, !tbaa !23
  %t766 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t767 = load i32, ptr %t766, !tbaa !23
  %t770 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t765, i32 %t767)
  store %"compiler/source:Span" %t770, ptr %l271
  br label %bb160
bb160:
  %t771 = load i32, ptr %l17, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t772
  %t773 = getelementptr { i64, [5 x i64] }, ptr %t772, i32 0, i32 0
  store i64 0, ptr %t773
  %t774 = load %"compiler/source:Span", ptr %l271
  %t775 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t774, 0
  %t777 = insertvalue { %"compiler/source:Span", i32 } %t775, i32 %t771, 1
  %t778 = getelementptr { i64, [5 x i64] }, ptr %t772, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t777, ptr %t778
  %t779 = load { i64, [5 x i64] }, ptr %t772
  %t781 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t779, ptr %t781
  %t782 = load ptr, ptr %l18, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t783
  %t784 = getelementptr { i64, [6 x i64] }, ptr %t783, i32 0, i32 0
  store i64 8, ptr %t784
  %t785 = load %"compiler/source:Span", ptr %l268
  %t786 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t785, 0
  %t788 = insertvalue { %"compiler/source:Span", ptr, ptr } %t786, ptr %t781, 1
  %t790 = insertvalue { %"compiler/source:Span", ptr, ptr } %t788, ptr %t782, 2
  %t791 = getelementptr { i64, [6 x i64] }, ptr %t783, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t790, ptr %t791
  %t792 = load { i64, [6 x i64] }, ptr %t783
  %t794 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t792, ptr %t794
  call void @__olang_scope_close(ptr %s14)
  %t796 = insertvalue { i32, ptr } zeroinitializer, ptr %t794, 1
  store { i32, ptr } %t796, ptr %rv
  br label %ret
bb161:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclNames(ptr %v0, ptr %t797, i1 false)
  %t800 = extractvalue { i32, ptr } %t799, 1
  %t801 = extractvalue { i32, ptr } %t799, 0
  store i32 %t801, ptr %l281
  %t802 = icmp ne i32 %t801, 0
  br i1 %t802, label %bb163, label %ok.803
ok.803:
  store ptr %t800, ptr %l280
  br label %bb162
bb162:
  %t804 = load ptr, ptr %l280, !tbaa !29
  store ptr %t804, ptr %l278, !tbaa !29
  br label %bb164
bb163:
  %t805 = load i32, ptr %l281, !tbaa !23
  %t806 = lshr i32 %t805, 16
  %t807 = and i32 %t805, 65535
  %t808 = icmp eq i32 %t806, 1
  %t809 = select i1 %t808, i32 1, i32 0
  %t810 = icmp eq i32 %t805, 0
  %t811 = shl i32 %t809, 16
  %t812 = or i32 %t811, %t807
  %t813 = select i1 %t810, i32 0, i32 %t812
  call void @__olang_scope_close(ptr %s14)
  %t815 = insertvalue { i32, ptr } zeroinitializer, i32 %t813, 0
  store { i32, ptr } %t815, ptr %rv
  br label %ret
bb164:
  %t816 = load ptr, ptr %l278, !tbaa !29
  store ptr %t816, ptr %l20, !tbaa !29
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load i32, ptr %l1, !tbaa !23
  %t821 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t817, i32 %t818)
  store %"compiler/source:Span" %t821, ptr %l285
  br label %bb165
bb165:
  %t822 = load %"compiler/source:Span", ptr %l285
  store %"compiler/source:Span" %t822, ptr %l21
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t825 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t823)
  store i32 %t825, ptr %l287
  %t826 = icmp ne i32 %t825, 0
  br i1 %t826, label %bb167, label %ok.827
ok.827:
  br label %bb166
bb166:
  br label %bb168
bb167:
  %t828 = load i32, ptr %l287, !tbaa !23
  %t829 = lshr i32 %t828, 16
  %t830 = and i32 %t828, 65535
  %t831 = icmp eq i32 %t829, 1
  %t832 = select i1 %t831, i32 1, i32 0
  %t833 = icmp eq i32 %t828, 0
  %t834 = shl i32 %t832, 16
  %t835 = or i32 %t834, %t830
  %t836 = select i1 %t833, i32 0, i32 %t835
  call void @__olang_scope_close(ptr %s14)
  %t838 = insertvalue { i32, ptr } zeroinitializer, i32 %t836, 0
  store { i32, ptr } %t838, ptr %rv
  br label %ret
bb168:
  %t839 = load %"compiler/source:Span", ptr %l21
  %t840 = load ptr, ptr %l20, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t841
  %t842 = getelementptr { i64, [6 x i64] }, ptr %t841, i32 0, i32 0
  store i64 3, ptr %t842
  %t844 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t839, 0
  %t846 = insertvalue { %"compiler/source:Span", ptr } %t844, ptr %t840, 1
  %t847 = getelementptr { i64, [6 x i64] }, ptr %t841, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t846, ptr %t847
  %t848 = load { i64, [6 x i64] }, ptr %t841
  %t850 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t848, ptr %t850
  call void @__olang_scope_close(ptr %s14)
  %t852 = insertvalue { i32, ptr } zeroinitializer, ptr %t850, 1
  store { i32, ptr } %t852, ptr %rv
  br label %ret
bb169:
  store %olang.scope zeroinitializer, ptr %s17
  %t853 = load ptr, ptr %l0, !tbaa !29
  %t855 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s17, ptr %t853, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t855, ptr %l294
  %t856 = icmp ne i32 %t855, 0
  br i1 %t856, label %bb171, label %ok.857
ok.857:
  br label %bb170
bb170:
  br label %bb172
bb171:
  %t858 = load i32, ptr %l294, !tbaa !23
  %t859 = lshr i32 %t858, 16
  %t860 = and i32 %t858, 65535
  %t861 = icmp eq i32 %t859, 1
  %t862 = select i1 %t861, i32 1, i32 0
  %t863 = icmp eq i32 %t858, 0
  %t864 = shl i32 %t862, 16
  %t865 = or i32 %t864, %t860
  %t866 = select i1 %t863, i32 0, i32 %t865
  call void @__olang_scope_close(ptr %s17)
  %t868 = insertvalue { i32, ptr } zeroinitializer, i32 %t866, 0
  store { i32, ptr } %t868, ptr %rv
  br label %ret
bb172:
  call void @__olang_scope_close(ptr %s17)
  br label %bb173
bb173:
  call void @__olang_check_failed(ptr @olang_loc_2df52f758a425120_e9eb2ffac7d00514)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  store i32 %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 12
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %t10)
  store i1 %t12, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 38 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb11
bb10:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 34 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t26 = load i1, ptr %l12, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t27, i64 1)
  store i32 %t29, ptr %l16
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t30 = load i32, ptr %l16
  %t32 = trunc i64 1 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %rv
  br label %ret
bb15:
  %t35 = load i32, ptr %l1
  %t37 = trunc i64 42 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb18
bb17:
  %t40 = load i32, ptr %l1
  %t42 = trunc i64 41 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb18
bb18:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb21
bb20:
  %t46 = load i32, ptr %l1
  %t48 = trunc i64 44 to i32
  %t49 = icmp eq i32 %t46, %t48
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb21
bb21:
  %t51 = load i1, ptr %l24, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclNames(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/token:Token"
  %lp5 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"compiler/token:Token"
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca %"compiler/parse:NameList"
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 35
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t7, i32 0, i32 36
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t13)
  store %"compiler/token:Token" %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load %"compiler/token:Token", ptr %l13
  store %"compiler/token:Token" %t16, ptr %l4
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 35
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t20)
  %t23 = extractvalue { i32, i32 } %t22, 1
  %t24 = extractvalue { i32, i32 } %t22, 0
  store i32 %t24, ptr %l19
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb6, label %ok.26
ok.26:
  store i32 %t23, ptr %l18
  br label %bb5
bb5:
  %t27 = load i32, ptr %l18, !tbaa !23
  store i32 %t27, ptr %l16, !tbaa !23
  br label %bb7
bb6:
  %t28 = load i32, ptr %l19, !tbaa !23
  %t29 = lshr i32 %t28, 16
  %t30 = and i32 %t28, 65535
  %t31 = icmp eq i32 %t29, 1
  %t32 = select i1 %t31, i32 1, i32 0
  %t33 = icmp eq i32 %t28, 0
  %t34 = shl i32 %t32, 16
  %t35 = or i32 %t34, %t30
  %t36 = select i1 %t33, i32 0, i32 %t35
  call void @__olang_scope_close(ptr %s1)
  %t38 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t38, ptr %rv
  br label %ret
bb7:
  %t39 = load ptr, ptr %l15, !tbaa !29
  %t40 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t39, i32 %t40)
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 36
  store ptr %t43, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 2
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t45, i32 %t47)
  store %"compiler/source:Span" %t50, ptr %l25
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t53, i32 57)
  store i1 %t56, ptr %l28
  br label %bb11
bb11:
  %t57 = load i1, ptr %l28, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb15:
  br label %bb3
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 35
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t62, i64 %t63)
  store { i64, ptr } %t66, ptr %l33
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t67, i32 0, i32 36
  %t70 = load i64, ptr %l3, !tbaa !24
  %t73 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l37
  br label %bb18
bb18:
  %t74 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t76 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t74, { i64, ptr } %t75)
  store %"compiler/parse:NameList" %t76, ptr %l38
  br label %bb19
bb19:
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t77, ptr %lp5
  %t78 = load %"compiler/parse:NameList", ptr %l38
  %t79 = load ptr, ptr %lp5
  store %"compiler/parse:NameList" %t78, ptr %t79
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %lp5
  %t86 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v0, ptr %t80, ptr %t81, i1 %a1)
  %t87 = extractvalue { i32, ptr } %t86, 1
  %t88 = extractvalue { i32, ptr } %t86, 0
  store i32 %t88, ptr %l44
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb21, label %ok.90
ok.90:
  store ptr %t87, ptr %l43
  br label %bb20
bb20:
  %t91 = load ptr, ptr %l43, !tbaa !29
  store ptr %t91, ptr %l39, !tbaa !29
  br label %bb22
bb21:
  %t92 = load i32, ptr %l44, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  %t102 = insertvalue { i32, ptr } zeroinitializer, i32 %t100, 0
  store { i32, ptr } %t102, ptr %rv
  br label %ret
bb22:
  %t103 = load ptr, ptr %l39, !tbaa !29
  %t104 = insertvalue { i32, ptr } zeroinitializer, ptr %t103, 1
  store { i32, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %lp4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i32
  %l18 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l40 = alloca %"compiler/ast:VarDecl"
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l56 = alloca i1
  %l73 = alloca %"compiler/ast:VarDecl"
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i32
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l99 = alloca i1
  %l116 = alloca %"compiler/ast:VarDecl"
  %rv = alloca { i32, ptr }
  %t27 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 40)
  store i1 %t4, ptr %l11
  br label %bb1
bb1:
  %t5 = load i1, ptr %l11, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t6, i64 1)
  store i32 %t8, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t9 = load i32, ptr %l14
  %t11 = trunc i64 62 to i32
  %t12 = icmp eq i32 %t9, %t11
  store i1 %t12, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l18
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t18 = load i32, ptr %l18, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 10
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t18, i32 %t23)
  store %"compiler/source:Span" %t26, ptr %l22
  br label %bb9
bb9:
  store { i64, [5 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 0
  store i64 4, ptr %t28
  %t29 = load %"compiler/source:Span", ptr %l22
  %t30 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t29, 0
  %t31 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t30, ptr null, 1
  %t32 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t31, i1 true, 2
  %t33 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t32, i1 false, 3
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t33, ptr %t34
  %t35 = load { i64, [5 x i64] }, ptr %t27
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t36, ptr %lp4
  %t38 = load ptr, ptr %lp4
  store { i64, [5 x i64] } %t35, ptr %t38
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load i1, ptr %l2, !tbaa !21
  %t48 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %t42, ptr %t43, i1 %t44)
  %t49 = extractvalue { i32, { i64, ptr } } %t48, 1
  %t50 = extractvalue { i32, { i64, ptr } } %t48, 0
  store i32 %t50, ptr %l31
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb12, label %ok.52
ok.52:
  store { i64, ptr } %t49, ptr %l30
  br label %bb11
bb11:
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %l26, !tbaa !27
  br label %bb13
bb12:
  %t54 = load i32, ptr %l31, !tbaa !23
  %t55 = lshr i32 %t54, 16
  %t56 = and i32 %t54, 65535
  %t57 = icmp eq i32 %t55, 1
  %t58 = select i1 %t57, i32 1, i32 0
  %t59 = icmp eq i32 %t54, 0
  %t60 = shl i32 %t58, 16
  %t61 = or i32 %t60, %t56
  %t62 = select i1 %t59, i32 0, i32 %t61
  %t64 = insertvalue { i32, ptr } zeroinitializer, i32 %t62, 0
  store { i32, ptr } %t64, ptr %rv
  br label %ret
bb13:
  %t65 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/parse:NameList", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/parse:NameList", ptr %t70, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t74 = load ptr, ptr %lp4
  %t76 = load i1, ptr %l2, !tbaa !21
  %t82 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t69, { i64, ptr } %t73, ptr %t74, { i64, ptr } %t65, i1 true, i1 %t76)
  store %"compiler/ast:VarDecl" %t82, ptr %l40
  br label %bb14
bb14:
  %t83 = load %"compiler/ast:VarDecl", ptr %l40
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t83, ptr %t84
  %t86 = insertvalue { i32, ptr } zeroinitializer, ptr %t84, 1
  store { i32, ptr } %t86, ptr %rv
  br label %ret
bb15:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t90 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t87, i32 62)
  store i1 %t90, ptr %l44
  br label %bb16
bb16:
  %t91 = load i1, ptr %l44, !tbaa !21
  br i1 %t91, label %bb17, label %bb18
bb17:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t94 = load i1, ptr %l2, !tbaa !21
  %t98 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %t92, ptr %t93, i1 %t94)
  %t99 = extractvalue { i32, { i64, ptr } } %t98, 1
  %t100 = extractvalue { i32, { i64, ptr } } %t98, 0
  store i32 %t100, ptr %l50
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb20, label %ok.102
ok.102:
  store { i64, ptr } %t99, ptr %l49
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t103 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t103, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t104 = load i32, ptr %l50, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  %t114 = insertvalue { i32, ptr } zeroinitializer, i32 %t112, 0
  store { i32, ptr } %t114, ptr %rv
  br label %ret
bb21:
  %t115 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t115, ptr %l6, !tbaa !27
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/parse:NameList", ptr %t116, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t123 = icmp sgt i64 %t121, 1
  br i1 %t123, label %bb22, label %bb23
bb22:
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr %"compiler/parse:NameList", ptr %t128, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t136 = icmp ne i64 %t127, %t133
  store i1 %t136, ptr %l56, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t138 = load i1, ptr %l56, !tbaa !21
  br i1 %t138, label %bb25, label %bb26
bb25:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %t139, ptr %t140, i64 %t143)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/parse:NameList", ptr %t147, i32 0, i32 0
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr %"compiler/parse:NameList", ptr %t151, i32 0, i32 1
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t156 = load i1, ptr %l2, !tbaa !21
  %t161 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t150, { i64, ptr } %t154, ptr null, { i64, ptr } %t155, i1 true, i1 %t156)
  store %"compiler/ast:VarDecl" %t161, ptr %l73
  br label %bb29
bb29:
  %t162 = load %"compiler/ast:VarDecl", ptr %l73
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t162, ptr %t163
  %t165 = insertvalue { i32, ptr } zeroinitializer, ptr %t163, 1
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb30:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t166)
  %t169 = extractvalue { i32, ptr } %t168, 1
  %t170 = extractvalue { i32, ptr } %t168, 0
  store i32 %t170, ptr %l78
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb32, label %ok.172
ok.172:
  store ptr %t169, ptr %l77
  br label %bb31
bb31:
  %t173 = load ptr, ptr %l77, !tbaa !29
  store ptr %t173, ptr %l75, !tbaa !29
  br label %bb33
bb32:
  %t174 = load i32, ptr %l78, !tbaa !23
  %t175 = lshr i32 %t174, 16
  %t176 = and i32 %t174, 65535
  %t177 = icmp eq i32 %t175, 1
  %t178 = select i1 %t177, i32 1, i32 0
  %t179 = icmp eq i32 %t174, 0
  %t180 = shl i32 %t178, 16
  %t181 = or i32 %t180, %t176
  %t182 = select i1 %t179, i32 0, i32 %t181
  %t184 = insertvalue { i32, ptr } zeroinitializer, i32 %t182, 0
  store { i32, ptr } %t184, ptr %rv
  br label %ret
bb33:
  %t185 = load ptr, ptr %l75, !tbaa !29
  store ptr %t185, ptr %l7, !tbaa !29
  %t186 = icmp sge i64 0, 0
  br i1 %t186, label %bb34, label %bb35
bb34:
  %t188 = icmp sle i64 0, 1152921504606846975
  br i1 %t188, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_88b4df24f395cba0_7a8585039ef7582c)
  unreachable
bb36:
  %t190 = mul i64 0, 8
  %t191 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 0, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l8, !tbaa !27
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t198 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t195, i32 60)
  store i1 %t198, ptr %l85
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_88b4df24f395cba0_7a8585039ef7582c)
  unreachable
bb38:
  %t199 = load i1, ptr %l85, !tbaa !21
  br i1 %t199, label %bb39, label %bb40
bb39:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t202 = load i1, ptr %l2, !tbaa !21
  %t206 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %t200, ptr %t201, i1 %t202)
  %t207 = extractvalue { i32, { i64, ptr } } %t206, 1
  %t208 = extractvalue { i32, { i64, ptr } } %t206, 0
  store i32 %t208, ptr %l91
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb42, label %ok.210
ok.210:
  store { i64, ptr } %t207, ptr %l90
  br label %bb41
bb40:
  br label %bb51
bb41:
  %t211 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t211, ptr %l86, !tbaa !27
  br label %bb43
bb42:
  %t212 = load i32, ptr %l91, !tbaa !23
  %t213 = lshr i32 %t212, 16
  %t214 = and i32 %t212, 65535
  %t215 = icmp eq i32 %t213, 1
  %t216 = select i1 %t215, i32 1, i32 0
  %t217 = icmp eq i32 %t212, 0
  %t218 = shl i32 %t216, 16
  %t219 = or i32 %t218, %t214
  %t220 = select i1 %t217, i32 0, i32 %t219
  %t222 = insertvalue { i32, ptr } zeroinitializer, i32 %t220, 0
  store { i32, ptr } %t222, ptr %rv
  br label %ret
bb43:
  %t223 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t223, ptr %l8, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr %"compiler/parse:NameList", ptr %t227, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t235 = icmp ne i64 %t226, %t232
  br i1 %t235, label %bb44, label %bb45
bb44:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/parse:NameList", ptr %t237, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t244 = icmp sgt i64 %t242, 1
  store i1 %t244, ptr %l99, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t246 = load i1, ptr %l99, !tbaa !21
  br i1 %t246, label %bb47, label %bb48
bb47:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t249, 0
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %t247, ptr %t248, i64 %t251)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr %"compiler/parse:NameList", ptr %t255, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr %"compiler/parse:NameList", ptr %t259, i32 0, i32 1
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t263 = load ptr, ptr %l7, !tbaa !29
  %t265 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t266 = load i1, ptr %l2, !tbaa !21
  %t272 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t258, { i64, ptr } %t262, ptr %t263, { i64, ptr } %t265, i1 false, i1 %t266)
  store %"compiler/ast:VarDecl" %t272, ptr %l116
  br label %bb52
bb52:
  %t273 = load %"compiler/ast:VarDecl", ptr %l116
  %t274 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t273, ptr %t274
  %t276 = insertvalue { i32, ptr } zeroinitializer, ptr %t274, 1
  store { i32, ptr } %t276, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendsRendering(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca i32
  %l47 = alloca i1
  %l52 = alloca i64
  %l60 = alloca i32
  %l66 = alloca i64
  %l69 = alloca i64
  %l71 = alloca i1
  %l74 = alloca i32
  %l75 = alloca i1
  %l82 = alloca i32
  %l88 = alloca i32
  %l91 = alloca i1
  %l95 = alloca i32
  %l96 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i1, ptr %l14, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 256, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t38 = load i64, ptr %l24, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb54
bb13:
  br label %bb14
bb14:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l8, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l2, !tbaa !24
  %t62 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t58, i64 %t59)
  store i32 %t62, ptr %l44
  br label %bb15
bb15:
  %t63 = load i32, ptr %l44
  store i32 %t63, ptr %l9
  %t64 = load i32, ptr %l9
  %t66 = trunc i64 91 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb18
bb17:
  %t69 = load i32, ptr %l9
  %t71 = trunc i64 93 to i32
  %t72 = icmp eq i32 %t69, %t71
  store i1 %t72, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t74 = load i1, ptr %l47, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l2, !tbaa !24
  %t79 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenerOf(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l52
  br label %bb21
bb20:
  br label %bb39
bb21:
  %t80 = load i64, ptr %l52, !tbaa !24
  store i64 %t80, ptr %l2, !tbaa !24
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = icmp slt i64 %t81, 0
  br i1 %t83, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t88 = sub i64 %t86, 1
  store i64 %t88, ptr %l10, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t90, i64 %t91)
  store i32 %t94, ptr %l60
  br label %bb25
bb25:
  %t95 = load i32, ptr %l60
  %t97 = trunc i64 87 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t101, i64 %t102)
  store i64 %t105, ptr %l66
  br label %bb29
bb29:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l2, !tbaa !24
  %t110 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t106, i64 %t107)
  store i64 %t110, ptr %l69
  br label %bb30
bb30:
  %t111 = load i64, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l69, !tbaa !24
  %t113 = icmp eq i64 %t111, %t112
  br i1 %t113, label %bb31, label %bb32
bb31:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l10, !tbaa !24
  %t119 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t115, i64 %t116)
  store i32 %t119, ptr %l74
  br label %bb33
bb32:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb35
bb33:
  %t120 = load i32, ptr %l74
  %t121 = call i1 @compiler_2fparse_2eisOperandTail(i32 %t120)
  store i1 %t121, ptr %l75
  br label %bb34
bb34:
  %t122 = load i1, ptr %l75, !tbaa !21
  store i1 %t122, ptr %l71, !tbaa !21
  br label %bb35
bb35:
  %t123 = load i1, ptr %l71, !tbaa !21
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t124 = load i64, ptr %l10, !tbaa !24
  store i64 %t124, ptr %l2, !tbaa !24
  br label %bb53
bb37:
  br label %bb38
bb38:
  store i1 false, ptr %rv
  br label %ret
bb39:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t129 = sub i64 %t127, 1
  store i64 %t129, ptr %l11, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t131, i64 %t132)
  store i32 %t135, ptr %l82
  br label %bb40
bb40:
  %t136 = load i32, ptr %l82
  %t138 = trunc i64 87 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb41, label %bb42
bb41:
  store i1 true, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t142, i64 %t143)
  store i32 %t146, ptr %l88
  br label %bb44
bb44:
  %t147 = load i32, ptr %l88
  %t149 = trunc i64 58 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb45, label %bb46
bb45:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l2, !tbaa !24
  %t155 = sub i64 %t153, 2
  %t158 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t152, i64 %t155)
  store i32 %t158, ptr %l95
  br label %bb47
bb46:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb49
bb47:
  %t159 = load i32, ptr %l95
  %t160 = call i1 @compiler_2fparse_2eisOperandTail(i32 %t159)
  store i1 %t160, ptr %l96
  br label %bb48
bb48:
  %t161 = load i1, ptr %l96, !tbaa !21
  store i1 %t161, ptr %l91, !tbaa !21
  br label %bb49
bb49:
  %t162 = load i1, ptr %l91, !tbaa !21
  br i1 %t162, label %bb50, label %bb51
bb50:
  %t163 = load i64, ptr %l2, !tbaa !24
  %t165 = sub i64 %t163, 2
  store i64 %t165, ptr %l2, !tbaa !24
  br label %bb53
bb51:
  br label %bb52
bb52:
  store i1 false, ptr %rv
  br label %ret
bb53:
  %t168 = load i64, ptr %l7, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l7, !tbaa !24
  br label %bb11
bb54:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l11 = alloca %"compiler/token:Token"
  %l13 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca i32
  %l21 = alloca { i64, [3 x i64] }
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l31 = alloca i1
  %l38 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i32
  %t41 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t8 = icmp sge i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 21
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb10
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 21
  store i1 true, ptr %t19, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t20)
  store %"compiler/token:Token" %t22, ptr %l11
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t23 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t23, ptr %l1
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 4
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 5
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t32)
  store i32 %t34, ptr %l17
  br label %bb6
bb6:
  %t35 = load i32, ptr %l17, !tbaa !23
  %t36 = sext i32 %t35 to i64
  %t37 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t38 = load i32, ptr %t37, !tbaa !23
  %t40 = sext i32 %t38 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t43 = load i64, ptr %l15, !tbaa !24
  %t44 = insertvalue { i64, i64, i64 } undef, i64 %t43, 0
  %t46 = insertvalue { i64, i64, i64 } %t44, i64 %t36, 1
  %t48 = insertvalue { i64, i64, i64 } %t46, i64 %t40, 2
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 1
  store { i64, i64, i64 } %t48, ptr %t49
  %t50 = load { i64, [3 x i64] }, ptr %t41
  store { i64, [3 x i64] } %t50, ptr %l21
  %t51 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %s2, i64 %t51)
  store %"compiler/msgs:Msg" %t53, ptr %l23
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l13, !tbaa !29
  %t55 = load { i64, [3 x i64] }, ptr %l21
  %t56 = load %"compiler/msgs:Msg", ptr %l23
  %t57 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %s2, ptr %t54, { i64, [3 x i64] } %t55, %"compiler/msgs:Msg" %t56)
  store i64 %t57, ptr %l24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  store i32 65536, ptr %rv
  br label %ret
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 20
  %t62 = load i64, ptr %t61, !tbaa !24
  %t64 = add i64 %t62, 1
  %t65 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t68 = icmp eq i64 %t64, %t65
  br i1 %t68, label %bb11, label %bb12
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 22
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  store i1 %t75, ptr %l31, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t77 = load i1, ptr %l31, !tbaa !21
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/parse:Parser", ptr %t79, i32 0, i32 6
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t78, i32 0, i32 22
  store i64 %t82, ptr %t85, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l38, !tbaa !29
  %t87 = load ptr, ptr %l38, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 20
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = add i64 %t89, 1
  %t93 = load ptr, ptr %l38, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t93, i32 0, i32 20
  store i64 %t91, ptr %t94, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorDecl(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l35 = alloca i64
  %l38 = alloca i32
  %l42 = alloca %"compiler/source:Span"
  %l45 = alloca i1
  %l47 = alloca i32
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t118 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l8
  br label %bb2
bb2:
  %t5 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %t6
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t8, i32 1)
  store i1 %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load i1, ptr %l12, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb17
bb6:
  %t13 = load ptr, ptr %l3, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t14)
  %t17 = extractvalue { i32, ptr } %t16, 1
  %t18 = extractvalue { i32, ptr } %t16, 0
  store i32 %t18, ptr %l17
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb8, label %ok.20
ok.20:
  store ptr %t17, ptr %l16
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l16, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  br label %bb9
bb8:
  %t22 = load i32, ptr %l17, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 1, i32 0
  %t27 = icmp eq i32 %t22, 0
  %t28 = shl i32 %t26, 16
  %t29 = or i32 %t28, %t24
  %t30 = select i1 %t27, i32 0, i32 %t29
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t30, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l13, !tbaa !29
  %t34 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t33, ptr %t34)
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t35, i32 57)
  store i1 %t38, ptr %l21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l21, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb6
bb16:
  br label %bb17
bb17:
  %t42 = icmp sge i64 0, 0
  br i1 %t42, label %bb18, label %bb19
bb18:
  %t44 = icmp sle i64 0, 2305843009213693951
  br i1 %t44, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_789713e4eee702da_477f9e47229ca02e)
  unreachable
bb20:
  %t46 = mul i64 0, 4
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 0, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t51, i32 94)
  store i1 %t54, ptr %l28
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_789713e4eee702da_477f9e47229ca02e)
  unreachable
bb22:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb23, label %bb24
bb23:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorWords(ptr %v0, ptr %t56)
  %t59 = extractvalue { i32, { i64, ptr } } %t58, 1
  %t60 = extractvalue { i32, { i64, ptr } } %t58, 0
  store i32 %t60, ptr %l32
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb26, label %ok.62
ok.62:
  store { i64, ptr } %t59, ptr %l31
  br label %bb25
bb24:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eLen_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l35
  br label %bb28
bb25:
  %t66 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t66, ptr %l29, !tbaa !27
  br label %bb27
bb26:
  %t67 = load i32, ptr %l32, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, ptr } zeroinitializer, i32 %t75, 0
  store { i32, ptr } %t77, ptr %rv
  br label %ret
bb27:
  %t78 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t78, ptr %l4, !tbaa !27
  br label %bb35
bb28:
  %t79 = load i64, ptr %l35, !tbaa !24
  %t80 = icmp eq i64 %t79, 0
  br i1 %t80, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s6, ptr %t82, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i32 %t84, ptr %l38
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb32, label %ok.86
ok.86:
  br label %bb31
bb30:
  br label %bb34
bb31:
  br label %bb33
bb32:
  %t87 = load i32, ptr %l38, !tbaa !23
  %t88 = lshr i32 %t87, 16
  %t89 = and i32 %t87, 65535
  %t90 = icmp eq i32 %t88, 1
  %t91 = select i1 %t90, i32 1, i32 0
  %t92 = icmp eq i32 %t87, 0
  %t93 = shl i32 %t91, 16
  %t94 = or i32 %t93, %t89
  %t95 = select i1 %t92, i32 0, i32 %t94
  call void @__olang_scope_close(ptr %s6)
  %t97 = insertvalue { i32, ptr } zeroinitializer, i32 %t95, 0
  store { i32, ptr } %t97, ptr %rv
  br label %ret
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t102 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t98, i32 %a1)
  store %"compiler/source:Span" %t102, ptr %l42
  br label %bb36
bb36:
  %t103 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t103, ptr %l5
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t107 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t104, i32 8)
  store i1 %t107, ptr %l45
  br label %bb37
bb37:
  %t108 = load i1, ptr %l45, !tbaa !21
  br i1 %t108, label %bb38, label %bb39
bb38:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t109)
  store i32 %t111, ptr %l47
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  %t112 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t112, ptr %l48
  store i32 %a2, ptr %l49, !tbaa !23
  %t114 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t114, ptr %l50, !tbaa !27
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t117 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t115)
  store { i64, ptr } %t117, ptr %l52
  br label %bb42
bb42:
  store { i64, [6 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [6 x i64] }, ptr %t118, i32 0, i32 0
  store i64 5, ptr %t119
  %t120 = load %"compiler/source:Span", ptr %l48
  %t121 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t120, 0
  %t122 = load i32, ptr %l49, !tbaa !23
  %t123 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } %t121, i32 %t122, 1
  %t124 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t125 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } %t123, { i64, ptr } %t124, 2
  %t126 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t127 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } %t125, { i64, ptr } %t126, 3
  %t128 = getelementptr { i64, [6 x i64] }, ptr %t118, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } } %t127, ptr %t128
  %t129 = load { i64, [6 x i64] }, ptr %t118
  %t131 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t129, ptr %t131
  %t133 = insertvalue { i32, ptr } zeroinitializer, ptr %t131, 1
  store { i32, ptr } %t133, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca %"compiler/ast:Sig"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"compiler/ast:Sig"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 59)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb4, label %bb5
bb3:
  br label %bb17
bb4:
  %t10 = icmp sle i64 0, 1152921504606846975
  br i1 %t10, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb6:
  %t12 = mul i64 0, 8
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = icmp sge i64 0, 0
  br i1 %t16, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb8:
  %t18 = icmp sle i64 0, 1152921504606846975
  br i1 %t18, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb10:
  %t20 = mul i64 0, 8
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 0, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l12, !tbaa !27
  %t24 = icmp sge i64 0, 0
  br i1 %t24, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb12:
  %t26 = icmp sle i64 0, 1152921504606846975
  br i1 %t26, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb14:
  %t28 = mul i64 0, 8
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 0, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t32 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t35 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t32, { i64, ptr } %t33, i1 false, { i64, ptr } %t31, i1 false, ptr null, i1 false, i1 false)
  store %"compiler/ast:Sig" %t35, ptr %l16
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb16:
  %t36 = load %"compiler/ast:Sig", ptr %l16
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store %"compiler/ast:Sig" %t36, ptr %t37
  %t39 = insertvalue { i32, ptr } zeroinitializer, ptr %t37, 1
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb17:
  %t40 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l18
  br label %bb18
bb18:
  %t41 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %t42
  store ptr %t42, ptr %l2, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t44, i32 1)
  store i1 %t47, ptr %l22
  br label %bb19
bb19:
  %t48 = load i1, ptr %l22, !tbaa !21
  br i1 %t48, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb36
bb22:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l23, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t50)
  %t53 = extractvalue { i32, ptr } %t52, 1
  %t54 = extractvalue { i32, ptr } %t52, 0
  store i32 %t54, ptr %l27
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb24, label %ok.56
ok.56:
  store ptr %t53, ptr %l26
  br label %bb23
bb23:
  %t57 = load ptr, ptr %l26, !tbaa !29
  store ptr %t57, ptr %l24, !tbaa !29
  br label %bb25
bb24:
  %t58 = load i32, ptr %l27, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  %t68 = insertvalue { i32, ptr } zeroinitializer, i32 %t66, 0
  store { i32, ptr } %t68, ptr %rv
  br label %ret
bb25:
  %t69 = load ptr, ptr %l23, !tbaa !29
  %t70 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t69, ptr %t70)
  br label %bb26
bb26:
  br i1 %a1, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb30
bb28:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t73, i32 57)
  store i1 %t76, ptr %l33
  br label %bb29
bb29:
  %t77 = load i1, ptr %l33, !tbaa !21
  %t78 = xor i1 %t77, true
  store i1 %t78, ptr %l30, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l30, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb22
bb35:
  br label %bb36
bb36:
  %t81 = icmp sge i64 0, 0
  br i1 %t81, label %bb37, label %bb38
bb37:
  %t83 = icmp sle i64 0, 1152921504606846975
  br i1 %t83, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb39:
  %t85 = mul i64 0, 8
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 0, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l37, !tbaa !27
  %t89 = icmp sge i64 0, 0
  br i1 %t89, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb41:
  %t91 = icmp sle i64 0, 1152921504606846975
  br i1 %t91, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb43:
  %t93 = mul i64 0, 8
  %t94 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 0, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l40, !tbaa !27
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t97)
  store { i64, ptr } %t99, ptr %l42
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb45:
  %t100 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t103 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t100, { i64, ptr } %t101, i1 true, { i64, ptr } %t102, i1 false, ptr null, i1 false, i1 false)
  store %"compiler/ast:Sig" %t103, ptr %l43
  br label %bb46
bb46:
  %t104 = load %"compiler/ast:Sig", ptr %l43
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store %"compiler/ast:Sig" %t104, ptr %t105
  %t107 = insertvalue { i32, ptr } zeroinitializer, ptr %t105, 1
  store { i32, ptr } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrsArg(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca i1
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca { i64, ptr }
  %rv = alloca { i32, ptr }
  %t66 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t5, i32 59)
  %t9 = extractvalue { i32, i32 } %t8, 1
  %t10 = extractvalue { i32, i32 } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb3, label %ok.12
ok.12:
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t13 = load i32, ptr %l8, !tbaa !23
  store i32 %t13, ptr %l5, !tbaa !23
  br label %bb4
bb3:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, ptr } zeroinitializer, i32 %t22, 0
  store { i32, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l11
  br label %bb5
bb5:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %t27
  store ptr %t27, ptr %l2, !tbaa !29
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l13, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t30)
  %t33 = extractvalue { i32, ptr } %t32, 1
  %t34 = extractvalue { i32, ptr } %t32, 0
  store i32 %t34, ptr %l17
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb8, label %ok.36
ok.36:
  store ptr %t33, ptr %l16
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l16, !tbaa !29
  store ptr %t37, ptr %l14, !tbaa !29
  br label %bb9
bb8:
  %t38 = load i32, ptr %l17, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  %t48 = insertvalue { i32, ptr } zeroinitializer, i32 %t46, 0
  store { i32, ptr } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load ptr, ptr %l13, !tbaa !29
  %t50 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t49, ptr %t50)
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t51, i32 57)
  store i1 %t54, ptr %l21
  br label %bb11
bb11:
  %t55 = load i1, ptr %l21, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb6
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t58, i32 %t59)
  store %"compiler/source:Span" %t62, ptr %l25
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t63)
  store { i64, ptr } %t65, ptr %l27
  br label %bb18
bb18:
  store { i64, [5 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 0
  store i64 6, ptr %t67
  %t68 = load %"compiler/source:Span", ptr %l25
  %t69 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t68, 0
  %t70 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t71 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t69, { i64, ptr } %t70, 1
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t71, ptr %t72
  %t73 = load { i64, [5 x i64] }, ptr %t66
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t73, ptr %t75
  %t77 = insertvalue { i32, ptr } zeroinitializer, ptr %t75, 1
  store { i32, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l34 = alloca %"compiler/ast:Func"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 38)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l8
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t21)
  %t24 = extractvalue { i32, i32 } %t23, 1
  %t25 = extractvalue { i32, i32 } %t23, 0
  store i32 %t25, ptr %l13
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27
ok.27:
  store i32 %t24, ptr %l12
  br label %bb4
bb4:
  %t28 = load i32, ptr %l12, !tbaa !23
  store i32 %t28, ptr %l10, !tbaa !23
  br label %bb6
bb5:
  %t29 = load i32, ptr %l13, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 %t37, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load i32, ptr %l10, !tbaa !23
  store i32 %t40, ptr %l2, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 48
  store i1 true, ptr %t43, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t44, i1 false, i1 false, i1 false)
  %t47 = extractvalue { i32, ptr } %t46, 1
  %t48 = extractvalue { i32, ptr } %t46, 0
  store i32 %t48, ptr %l19
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb8, label %ok.50
ok.50:
  store ptr %t47, ptr %l18
  br label %bb7
bb7:
  %t51 = load ptr, ptr %l18, !tbaa !29
  store ptr %t51, ptr %l16, !tbaa !29
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 48
  store i1 false, ptr %t54, !tbaa !21
  %t56 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t56, ptr %rv
  br label %ret
bb10:
  %t57 = load ptr, ptr %l16, !tbaa !29
  store ptr %t57, ptr %l3, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 48
  store i1 false, ptr %t60, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t61, i32 %a1)
  store %"compiler/source:Span" %t65, ptr %l25
  br label %bb11
bb11:
  %t66 = load i32, ptr %l2, !tbaa !23
  store i32 %t66, ptr %l26, !tbaa !23
  %t67 = load ptr, ptr %l3, !tbaa !29
  store ptr %t67, ptr %l27, !tbaa !29
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = icmp sle i64 0, 1152921504606846975
  br i1 %t70, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_30a3a318854048f4_b503dd06e25e7b98)
  unreachable
bb14:
  %t72 = mul i64 0, 8
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 0, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l30, !tbaa !27
  %t76 = icmp sge i64 0, 0
  br i1 %t76, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_30a3a318854048f4_b503dd06e25e7b98)
  unreachable
bb16:
  %t78 = icmp sle i64 0, 1152921504606846975
  br i1 %t78, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_30a3a318854048f4_b503dd06e25e7b98)
  unreachable
bb18:
  %t80 = mul i64 0, 8
  %t81 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 0, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  %t84 = load %"compiler/source:Span", ptr %l25
  %t85 = load i32, ptr %l26, !tbaa !23
  %t86 = load ptr, ptr %l27, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t89 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t84, ptr null, i32 %t85, ptr %t86, { i64, ptr } %t87, { i64, ptr } %t83, i1 false, i1 false)
  store %"compiler/ast:Func" %t89, ptr %l34
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_30a3a318854048f4_b503dd06e25e7b98)
  unreachable
bb20:
  %t90 = load %"compiler/ast:Func", ptr %l34
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t90, ptr %t91
  %t93 = insertvalue { i32, ptr } zeroinitializer, ptr %t91, 1
  store { i32, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/token:Token"
  %l5 = alloca i1
  %l11 = alloca i1
  %l14 = alloca %"compiler/token:Token"
  %l15 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca %"compiler/msgs:Msg"
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 21
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 23
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i32 65536, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehint(ptr %v0, ptr %v1, ptr %t13, { i64, ptr } %t14)
  store i1 %t17, ptr %l11
  br label %bb7
bb7:
  %t18 = load i1, ptr %l11, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t21)
  store %"compiler/token:Token" %t23, ptr %l14
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t24 = load %"compiler/token:Token", ptr %l14
  store %"compiler/token:Token" %t24, ptr %l2
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t26)
  store i32 %t28, ptr %l17
  br label %bb11
bb11:
  %t29 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l18, !tbaa !23
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %s2, ptr %t32)
  store { i64, ptr } %t34, ptr %l21
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t44 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExpected(ptr %v1, ptr %s2, ptr %s2, { i64, ptr } %t42, { i64, ptr } %t41)
  store %"compiler/msgs:Msg" %t44, ptr %l23
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l15, !tbaa !29
  %t46 = load i32, ptr %l17, !tbaa !23
  %t47 = load i32, ptr %l18, !tbaa !23
  %t48 = load %"compiler/msgs:Msg", ptr %l23
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s2, ptr %t45, i32 %t46, i32 %t47, %"compiler/msgs:Msg" %t48)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efieldDecl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/token:Token"
  %l5 = alloca i32
  %l7 = alloca %"compiler/token:Token"
  %l9 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t5)
  store %"compiler/token:Token" %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load %"compiler/token:Token", ptr %l7
  store %"compiler/token:Token" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l9
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/token:Token", ptr %l2
  %t20 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t16, %"compiler/token:Token" %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t23 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  store i32 %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  store i32 %t26, ptr %l18, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i32 %t24, ptr %l20, !tbaa !23
  %t29 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t31 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t32 = load i32, ptr %t31, !tbaa !23
  %t35 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t30, i32 %t32)
  store %"compiler/source:Span" %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i32, ptr %l20, !tbaa !23
  %t38 = load %"compiler/source:Span", ptr %l23
  %t39 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %t36, i32 %t37, %"compiler/source:Span" %t38)
  store ptr %t39, ptr %l24
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l18, !tbaa !23
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v0, ptr %t40, i32 %t41, ptr %t42)
  %t44 = extractvalue { i32, ptr } %t43, 1
  %t45 = extractvalue { i32, ptr } %t43, 0
  store i32 %t45, ptr %l26
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb9, label %ok.47
ok.47:
  store ptr %t44, ptr %l25
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l25, !tbaa !29
  store ptr %t48, ptr %l16, !tbaa !29
  br label %bb10
bb9:
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s0)
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load ptr, ptr %l16, !tbaa !29
  %t61 = insertvalue { i32, ptr } zeroinitializer, ptr %t60, 1
  store { i32, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %rv = alloca { i32, ptr }
  %t36 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 30)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t6)
  store i32 %t8, ptr %l7
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l1, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %t10)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l10
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l8, !tbaa !27
  br label %bb7
bb6:
  %t18 = load i32, ptr %l11, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t30, i32 %t31)
  store %"compiler/source:Span" %t34, ptr %l15
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 25, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l15
  %t39 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t38, 0
  %t41 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t39, { i64, ptr } %t35, 1
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t41, ptr %t42
  %t43 = load { i64, [5 x i64] }, ptr %t36
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t43, ptr %t45
  %t47 = insertvalue { i32, ptr } zeroinitializer, ptr %t45, 1
  store { i32, ptr } %t47, ptr %rv
  br label %ret
bb9:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t48)
  %t51 = extractvalue { i32, ptr } %t50, 1
  %t52 = extractvalue { i32, ptr } %t50, 0
  store i32 %t52, ptr %l22
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb11, label %ok.54
ok.54:
  store ptr %t51, ptr %l21
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l21, !tbaa !29
  store ptr %t55, ptr %l19, !tbaa !29
  br label %bb12
bb11:
  %t56 = load i32, ptr %l22, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb12:
  %t67 = load ptr, ptr %l19, !tbaa !29
  %t68 = insertvalue { i32, ptr } zeroinitializer, ptr %t67, 1
  store { i32, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca %"compiler/token:Token"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 7
  %t14 = load i32, ptr %t13
  %t16 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v1, i32 %t14)
  store { i64, ptr } %t16, ptr %l8
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t18 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v1, ptr %v1, { i64, ptr } %t17)
  store { i64, ptr } %t18, ptr %l9
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t20)
  store %"compiler/token:Token" %t22, ptr %l11
  br label %bb6
bb6:
  %t23 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t23, ptr %l1
  %t24 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t25 = load i32, ptr %t24
  %t27 = trunc i64 8 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, !tbaa !27
  store { i64, ptr } %t30, ptr %l14, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l15, !tbaa !24
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l15, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t44, ptr %l14, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t47 = load i32, ptr %t46
  %t49 = trunc i64 0 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, !tbaa !27
  store { i64, ptr } %t52, ptr %l19, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l20, !tbaa !24
  %t55 = load i64, ptr %l20, !tbaa !24
  %t56 = mul i64 %t55, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l21, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l20, !tbaa !24
  %t65 = mul i64 %t64, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t66, ptr %l19, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t67, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load %"compiler/token:Token", ptr %l1
  %t72 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t68, %"compiler/token:Token" %t69)
  store { i64, ptr } %t72, ptr %l24
  br label %bb13
bb13:
  %t73 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t74 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t73)
  store { i64, ptr } %t74, ptr %l25
  br label %bb14
bb14:
  %t75 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l5 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 10
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %a1, i32 %t5)
  store %"compiler/source:Span" %t8, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efunction(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l53 = alloca i1
  %l58 = alloca ptr
  %l65 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i32
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l79 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca ptr
  %l90 = alloca %"compiler/ast:Func"
  %l97 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/ast:Func"
  %rv = alloca { i32, ptr }
  %t238 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 38)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l12
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t9 = load i32, ptr %l11, !tbaa !23
  store i32 %t9, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l12, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l8, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  store ptr null, ptr %l2, !tbaa !29
  store i32 0, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t22, i32 90)
  store i1 %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %t27, i1 false)
  %t30 = extractvalue { i32, ptr } %t29, 1
  %t31 = extractvalue { i32, ptr } %t29, 0
  store i32 %t31, ptr %l20
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb8, label %ok.33
ok.33:
  store ptr %t30, ptr %l19
  br label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t34)
  %t37 = extractvalue { i32, i32 } %t36, 1
  %t38 = extractvalue { i32, i32 } %t36, 0
  store i32 %t38, ptr %l37
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb17, label %ok.40
ok.40:
  store i32 %t37, ptr %l36
  br label %bb16
bb7:
  %t41 = load ptr, ptr %l19, !tbaa !29
  store ptr %t41, ptr %l17, !tbaa !29
  br label %bb9
bb8:
  %t42 = load i32, ptr %l20, !tbaa !23
  %t43 = lshr i32 %t42, 16
  %t44 = and i32 %t42, 65535
  %t45 = icmp eq i32 %t43, 1
  %t46 = select i1 %t45, i32 1, i32 0
  %t47 = icmp eq i32 %t42, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t44
  %t50 = select i1 %t47, i32 0, i32 %t49
  %t52 = insertvalue { i32, ptr } zeroinitializer, i32 %t50, 0
  store { i32, ptr } %t52, ptr %rv
  br label %ret
bb9:
  %t53 = load ptr, ptr %l17, !tbaa !29
  store ptr %t53, ptr %l2, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t58 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t55, i32 91)
  %t59 = extractvalue { i32, i32 } %t58, 1
  %t60 = extractvalue { i32, i32 } %t58, 0
  store i32 %t60, ptr %l27
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb11, label %ok.62
ok.62:
  store i32 %t59, ptr %l26
  br label %bb10
bb10:
  %t63 = load i32, ptr %l26, !tbaa !23
  store i32 %t63, ptr %l23, !tbaa !23
  br label %bb12
bb11:
  %t64 = load i32, ptr %l27, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  %t74 = insertvalue { i32, ptr } zeroinitializer, i32 %t72, 0
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t75)
  %t78 = extractvalue { i32, i32 } %t77, 1
  %t79 = extractvalue { i32, i32 } %t77, 0
  store i32 %t79, ptr %l32
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb14, label %ok.81
ok.81:
  store i32 %t78, ptr %l31
  br label %bb13
bb13:
  %t82 = load i32, ptr %l31, !tbaa !23
  store i32 %t82, ptr %l29, !tbaa !23
  br label %bb15
bb14:
  %t83 = load i32, ptr %l32, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  %t93 = insertvalue { i32, ptr } zeroinitializer, i32 %t91, 0
  store { i32, ptr } %t93, ptr %rv
  br label %ret
bb15:
  %t94 = load i32, ptr %l29, !tbaa !23
  store i32 %t94, ptr %l3, !tbaa !23
  br label %bb19
bb16:
  %t95 = load i32, ptr %l36, !tbaa !23
  store i32 %t95, ptr %l34, !tbaa !23
  br label %bb18
bb17:
  %t96 = load i32, ptr %l37, !tbaa !23
  %t97 = lshr i32 %t96, 16
  %t98 = and i32 %t96, 65535
  %t99 = icmp eq i32 %t97, 1
  %t100 = select i1 %t99, i32 1, i32 0
  %t101 = icmp eq i32 %t96, 0
  %t102 = shl i32 %t100, 16
  %t103 = or i32 %t102, %t98
  %t104 = select i1 %t101, i32 0, i32 %t103
  %t106 = insertvalue { i32, ptr } zeroinitializer, i32 %t104, 0
  store { i32, ptr } %t106, ptr %rv
  br label %ret
bb18:
  %t107 = load i32, ptr %l34, !tbaa !23
  store i32 %t107, ptr %l3, !tbaa !23
  br label %bb19
bb19:
  %t108 = icmp sge i64 0, 0
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t110 = icmp sle i64 0, 1152921504606846975
  br i1 %t110, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea)
  unreachable
bb22:
  %t112 = mul i64 0, 8
  %t113 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 0, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l4, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t117, i32 79)
  store i1 %t120, ptr %l44
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea)
  unreachable
bb24:
  %t121 = load i1, ptr %l44, !tbaa !21
  br i1 %t121, label %bb25, label %bb26
bb25:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %t122)
  %t125 = extractvalue { i32, { i64, ptr } } %t124, 1
  %t126 = extractvalue { i32, { i64, ptr } } %t124, 0
  store i32 %t126, ptr %l48
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb28, label %ok.128
ok.128:
  store { i64, ptr } %t125, ptr %l47
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t129 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t129, ptr %l45, !tbaa !27
  br label %bb29
bb28:
  %t130 = load i32, ptr %l48, !tbaa !23
  %t131 = lshr i32 %t130, 16
  %t132 = and i32 %t130, 65535
  %t133 = icmp eq i32 %t131, 1
  %t134 = select i1 %t133, i32 1, i32 0
  %t135 = icmp eq i32 %t130, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t132
  %t138 = select i1 %t135, i32 0, i32 %t137
  %t140 = insertvalue { i32, ptr } zeroinitializer, i32 %t138, 0
  store { i32, ptr } %t140, ptr %rv
  br label %ret
bb29:
  %t141 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t141, ptr %l4, !tbaa !27
  br label %bb30
bb30:
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb31, label %bb32
bb31:
  %t148 = load ptr, ptr %l2, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Param", ptr %t148, i32 0, i32 2
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  store i1 %t155, ptr %l53, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb33
bb33:
  %t157 = load i1, ptr %l53, !tbaa !21
  br i1 %t157, label %bb34, label %bb35
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l58, !tbaa !29
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Param", ptr %t159, i32 0, i32 2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb36, label %bb37
bb35:
  br label %bb40
bb36:
  call void @__olang_check_failed(ptr @olang_loc_b7532cf042be3d05_817bd3bc9b025111)
  unreachable
bb37:
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr %"compiler/ast:Param", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t170 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v0, ptr %t170, ptr %t169, i1 false)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t172 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2escopeDecl(ptr %v0, ptr %t172)
  br label %bb41
bb41:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t174, i1 false, i1 false, i1 true)
  %t177 = extractvalue { i32, ptr } %t176, 1
  %t178 = extractvalue { i32, ptr } %t176, 0
  store i32 %t178, ptr %l68
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb43, label %ok.180
ok.180:
  store ptr %t177, ptr %l67
  br label %bb42
bb42:
  %t181 = load ptr, ptr %l67, !tbaa !29
  store ptr %t181, ptr %l65, !tbaa !29
  br label %bb44
bb43:
  %t182 = load i32, ptr %l68, !tbaa !23
  %t183 = lshr i32 %t182, 16
  %t184 = and i32 %t182, 65535
  %t185 = icmp eq i32 %t183, 1
  %t186 = select i1 %t185, i32 1, i32 0
  %t187 = icmp eq i32 %t182, 0
  %t188 = shl i32 %t186, 16
  %t189 = or i32 %t188, %t184
  %t190 = select i1 %t187, i32 0, i32 %t189
  %t192 = insertvalue { i32, ptr } zeroinitializer, i32 %t190, 0
  store { i32, ptr } %t192, ptr %rv
  br label %ret
bb44:
  %t193 = load ptr, ptr %l65, !tbaa !29
  store ptr %t193, ptr %l5, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t197 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t194, i32 94)
  store i1 %t197, ptr %l72
  br label %bb45
bb45:
  %t198 = load i1, ptr %l72, !tbaa !21
  store i1 %t198, ptr %l6, !tbaa !21
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t199)
  %t202 = extractvalue { i32, { i64, ptr } } %t201, 1
  %t203 = extractvalue { i32, { i64, ptr } } %t201, 0
  store i32 %t203, ptr %l76
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb47, label %ok.205
ok.205:
  store { i64, ptr } %t202, ptr %l75
  br label %bb46
bb46:
  %t206 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t206, ptr %l73, !tbaa !27
  br label %bb59
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  %t207 = load i1, ptr %l6, !tbaa !21
  br i1 %t207, label %bb49, label %bb50
bb49:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/parse:Parser", ptr %t209, i32 0, i32 38
  store ptr %t211, ptr %l79, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l1, !tbaa !23
  %t216 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t212, i32 %t213)
  store %"compiler/source:Span" %t216, ptr %l82
  br label %bb51
bb50:
  br label %bb58
bb51:
  %t217 = load ptr, ptr %l2, !tbaa !29
  store ptr %t217, ptr %l83, !tbaa !29
  %t218 = load i32, ptr %l3, !tbaa !23
  store i32 %t218, ptr %l84, !tbaa !23
  %t219 = load ptr, ptr %l5, !tbaa !29
  store ptr %t219, ptr %l85, !tbaa !29
  %t220 = icmp sge i64 0, 0
  br i1 %t220, label %bb52, label %bb53
bb52:
  %t222 = icmp sle i64 0, 1152921504606846975
  br i1 %t222, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c)
  unreachable
bb54:
  %t224 = mul i64 0, 8
  %t225 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t224)
  %t226 = insertvalue { i64, ptr } undef, i64 0, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  %t228 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t229 = load %"compiler/source:Span", ptr %l82
  %t230 = load ptr, ptr %l83, !tbaa !29
  %t231 = load i32, ptr %l84, !tbaa !23
  %t232 = load ptr, ptr %l85, !tbaa !29
  %t235 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t229, ptr %t230, i32 %t231, ptr %t232, { i64, ptr } %t227, { i64, ptr } %t228, i1 false, i1 false)
  store %"compiler/ast:Func" %t235, ptr %l90
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c)
  unreachable
bb56:
  %t236 = load %"compiler/ast:Func", ptr %l90
  %t237 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t236, ptr %t237
  store { i64, [6 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [6 x i64] }, ptr %t238, i32 0, i32 0
  store i64 0, ptr %t239
  %t241 = insertvalue { ptr } undef, ptr %t237, 0
  %t242 = getelementptr { i64, [6 x i64] }, ptr %t238, i32 0, i32 1
  store { ptr } %t241, ptr %t242
  %t243 = load { i64, [6 x i64] }, ptr %t238
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t243, ptr %t245
  %t246 = load ptr, ptr %l79, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t246, ptr %t245)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t249 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t249, ptr %rv
  br label %ret
bb59:
  %t250 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t250, ptr %l7, !tbaa !27
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load i32, ptr %l1, !tbaa !23
  %t255 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t251, i32 %t252)
  store %"compiler/source:Span" %t255, ptr %l97
  br label %bb60
bb60:
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t257 = load i32, ptr %l3, !tbaa !23
  %t258 = load ptr, ptr %l5, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t261 = load %"compiler/source:Span", ptr %l97
  %t267 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t261, ptr %t256, i32 %t257, ptr %t258, { i64, ptr } %t259, { i64, ptr } %t260, i1 true, i1 false)
  store %"compiler/ast:Func" %t267, ptr %l103
  br label %bb61
bb61:
  %t268 = load %"compiler/ast:Func", ptr %l103
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t268, ptr %t269
  %t271 = insertvalue { i32, ptr } zeroinitializer, ptr %t269, 1
  store { i32, ptr } %t271, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l13 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Sig", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 1
  br i1 %t23, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Sig", ptr %t25, i32 0, i32 3
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp sgt i64 %t30, 1
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l13, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Sig", ptr %t36, i32 0, i32 2
  %t39 = load i1, ptr %t38, !tbaa !21
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t46 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 59)
  store i1 %t46, ptr %l25
  br label %bb14
bb13:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb15
bb14:
  %t47 = load i1, ptr %l25, !tbaa !21
  store i1 %t47, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t48 = load i1, ptr %l22, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 8
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/scan:Tokens", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l9, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 6
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t23, i64 %t27)
  store i64 %t30, ptr %l13
  br label %bb4
bb4:
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i64 %t31
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  store i32 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eidenStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/token:Token"
  %l10 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l25 = alloca %"compiler/token:Token"
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l37 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l50 = alloca %"compiler/ast:VarDecl"
  %l57 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l73 = alloca %"compiler/token:Token"
  %l74 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca ptr
  %l83 = alloca i32
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t86 = alloca i64
  %t110 = alloca i64
  %t137 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t5, i64 1)
  store i32 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load i32, ptr %l12
  store i32 %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 12
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i32, ptr %l2
  %t16 = trunc i64 8 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t19 = load i32, ptr %l2
  %t21 = trunc i64 95 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb9:
  %t25 = load i32, ptr %l2
  %t27 = trunc i64 0 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l21, !tbaa !21
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t32)
  store %"compiler/token:Token" %t34, ptr %l25
  br label %bb14
bb13:
  br label %bb36
bb14:
  %t35 = load %"compiler/token:Token", ptr %l25
  store %"compiler/token:Token" %t35, ptr %l3
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t36)
  %t39 = extractvalue { i32, i32 } %t38, 1
  %t40 = extractvalue { i32, i32 } %t38, 0
  store i32 %t40, ptr %l29
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb16, label %ok.42
ok.42:
  store i32 %t39, ptr %l28
  br label %bb15
bb15:
  %t43 = load i32, ptr %l28, !tbaa !23
  store i32 %t43, ptr %l26, !tbaa !23
  br label %bb17
bb16:
  %t44 = load i32, ptr %l29, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t54 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t54, ptr %rv
  br label %ret
bb17:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l4, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t60 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t56, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l33
  br label %bb18
bb18:
  %t61 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t61, ptr %l5
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t62)
  store i32 %t64, ptr %l35
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb20, label %ok.66
ok.66:
  br label %bb19
bb19:
  br label %bb21
bb20:
  %t67 = load i32, ptr %l35, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, ptr } zeroinitializer, i32 %t75, 0
  store { i32, ptr } %t77, ptr %rv
  br label %ret
bb21:
  %t78 = load i32, ptr %l4, !tbaa !23
  store i32 %t78, ptr %l37, !tbaa !23
  %t79 = icmp sge i64 1, 0
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t81 = icmp sle i64 1, 2305843009213693951
  br i1 %t81, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb24:
  %t83 = mul i64 1, 4
  %t84 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t83)
  %t85 = load i32, ptr %l37, !tbaa !23
  store i64 0, ptr %t86
  br label %fill.87
fill.87:
  %t90 = load i64, ptr %t86
  %t91 = icmp slt i64 %t90, 1
  br i1 %t91, label %fillb.88, label %filld.89
fillb.88:
  %t92 = getelementptr i32, ptr %t84, i64 %t90
  store i32 %t85, ptr %t92
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %t86
  br label %fill.87
filld.89:
  %t94 = insertvalue { i64, ptr } undef, i64 1, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t84, 1
  store { i64, ptr } %t95, ptr %l40, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t99 = load i32, ptr %t98, !tbaa !23
  %t102 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t97, i32 %t99)
  store %"compiler/source:Span" %t102, ptr %l43
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb26:
  %t103 = icmp sge i64 1, 0
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = icmp sle i64 1, 1152921504606846975
  br i1 %t105, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb29:
  %t107 = mul i64 1, 8
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = load %"compiler/source:Span", ptr %l43
  store i64 0, ptr %t110
  br label %fill.111
fill.111:
  %t114 = load i64, ptr %t110
  %t115 = icmp slt i64 %t114, 1
  br i1 %t115, label %fillb.112, label %filld.113
fillb.112:
  %t116 = getelementptr %"compiler/source:Span", ptr %t108, i64 %t114
  store %"compiler/source:Span" %t109, ptr %t116
  %t117 = add i64 %t114, 1
  store i64 %t117, ptr %t110
  br label %fill.111
filld.113:
  %t118 = insertvalue { i64, ptr } undef, i64 1, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t108, 1
  store { i64, ptr } %t119, ptr %l46, !tbaa !27
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb31:
  %t122 = icmp sle i64 0, 1152921504606846975
  br i1 %t122, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b5d05676e64fefab_5744e152e232520f)
  unreachable
bb33:
  %t124 = mul i64 0, 8
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t128 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t131 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t128, { i64, ptr } %t129, ptr null, { i64, ptr } %t127, i1 false, i1 true)
  store %"compiler/ast:VarDecl" %t131, ptr %l50
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_b5d05676e64fefab_5744e152e232520f)
  unreachable
bb35:
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store ptr %t132, ptr %lp6
  %t133 = load %"compiler/ast:VarDecl", ptr %l50
  %t134 = load ptr, ptr %lp6
  store %"compiler/ast:VarDecl" %t133, ptr %t134
  %t135 = load %"compiler/source:Span", ptr %l5
  %t136 = load ptr, ptr %lp6
  store { i64, [4 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 0
  store i64 1, ptr %t138
  %t140 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t135, 0
  %t142 = insertvalue { %"compiler/source:Span", ptr } %t140, ptr %t136, 1
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t142, ptr %t143
  %t144 = load { i64, [4 x i64] }, ptr %t137
  %t146 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t144, ptr %t146
  %t148 = insertvalue { i32, ptr } zeroinitializer, ptr %t146, 1
  store { i32, ptr } %t148, ptr %rv
  br label %ret
bb36:
  %t149 = load i32, ptr %l2
  %t151 = trunc i64 62 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb39
bb38:
  %t154 = load i32, ptr %l2
  %t156 = trunc i64 1 to i32
  %t157 = icmp eq i32 %t154, %t156
  store i1 %t157, ptr %l57, !tbaa !21
  br label %bb39
bb39:
  %t159 = load i1, ptr %l57, !tbaa !21
  br i1 %t159, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb42
bb41:
  %t160 = load i32, ptr %l2
  %t162 = trunc i64 40 to i32
  %t163 = icmp eq i32 %t160, %t162
  store i1 %t163, ptr %l60, !tbaa !21
  br label %bb42
bb42:
  %t165 = load i1, ptr %l60, !tbaa !21
  br i1 %t165, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb45
bb44:
  %t166 = load i32, ptr %l2
  %t168 = trunc i64 38 to i32
  %t169 = icmp eq i32 %t166, %t168
  store i1 %t169, ptr %l63, !tbaa !21
  br label %bb45
bb45:
  %t171 = load i1, ptr %l63, !tbaa !21
  br i1 %t171, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb48
bb47:
  %t172 = load i32, ptr %l2
  %t174 = trunc i64 36 to i32
  %t175 = icmp eq i32 %t172, %t174
  store i1 %t175, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t177 = load i1, ptr %l66, !tbaa !21
  br i1 %t177, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb51
bb50:
  %t178 = load i32, ptr %l2
  %t180 = trunc i64 35 to i32
  %t181 = icmp eq i32 %t178, %t180
  store i1 %t181, ptr %l69, !tbaa !21
  br label %bb51
bb51:
  %t183 = load i1, ptr %l69, !tbaa !21
  br i1 %t183, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s2
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t184)
  store %"compiler/token:Token" %t186, ptr %l73
  br label %bb54
bb53:
  br label %bb63
bb54:
  %t187 = load %"compiler/token:Token", ptr %l73
  store %"compiler/token:Token" %t187, ptr %l7
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t188)
  %t191 = extractvalue { i32, i32 } %t190, 1
  %t192 = extractvalue { i32, i32 } %t190, 0
  store i32 %t192, ptr %l77
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb56, label %ok.194
ok.194:
  store i32 %t191, ptr %l76
  br label %bb55
bb55:
  %t195 = load i32, ptr %l76, !tbaa !23
  store i32 %t195, ptr %l74, !tbaa !23
  br label %bb57
bb56:
  %t196 = load i32, ptr %l77, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  call void @__olang_scope_close(ptr %s2)
  %t206 = insertvalue { i32, ptr } zeroinitializer, i32 %t204, 0
  store { i32, ptr } %t206, ptr %rv
  br label %ret
bb57:
  %t207 = load i32, ptr %l74, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l80, !tbaa !29
  %t209 = load i32, ptr %l1, !tbaa !23
  store i32 %t209, ptr %l81, !tbaa !23
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l82, !tbaa !29
  store i32 %t207, ptr %l83, !tbaa !23
  %t212 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 2
  %t213 = load i32, ptr %t212, !tbaa !23
  %t214 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 3
  %t215 = load i32, ptr %t214, !tbaa !23
  %t218 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t213, i32 %t215)
  store %"compiler/source:Span" %t218, ptr %l86
  br label %bb58
bb58:
  %t219 = load ptr, ptr %l82, !tbaa !29
  %t220 = load i32, ptr %l83, !tbaa !23
  %t221 = load %"compiler/source:Span", ptr %l86
  %t222 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %t219, i32 %t220, %"compiler/source:Span" %t221)
  store ptr %t222, ptr %l87
  br label %bb59
bb59:
  %t223 = load ptr, ptr %l80, !tbaa !29
  %t224 = load i32, ptr %l81, !tbaa !23
  %t225 = load ptr, ptr %l87, !tbaa !29
  %t226 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v0, ptr %t223, i32 %t224, ptr %t225)
  %t227 = extractvalue { i32, ptr } %t226, 1
  %t228 = extractvalue { i32, ptr } %t226, 0
  store i32 %t228, ptr %l89
  %t229 = icmp ne i32 %t228, 0
  br i1 %t229, label %bb61, label %ok.230
ok.230:
  store ptr %t227, ptr %l88
  br label %bb60
bb60:
  %t231 = load ptr, ptr %l88, !tbaa !29
  store ptr %t231, ptr %l79, !tbaa !29
  br label %bb62
bb61:
  %t232 = load i32, ptr %l89, !tbaa !23
  %t233 = lshr i32 %t232, 16
  %t234 = and i32 %t232, 65535
  %t235 = icmp eq i32 %t233, 1
  %t236 = select i1 %t235, i32 1, i32 0
  %t237 = icmp eq i32 %t232, 0
  %t238 = shl i32 %t236, 16
  %t239 = or i32 %t238, %t234
  %t240 = select i1 %t237, i32 0, i32 %t239
  call void @__olang_scope_close(ptr %s2)
  %t242 = insertvalue { i32, ptr } zeroinitializer, i32 %t240, 0
  store { i32, ptr } %t242, ptr %rv
  br label %ret
bb62:
  call void @__olang_scope_close(ptr %s2)
  %t243 = load ptr, ptr %l79, !tbaa !29
  %t244 = insertvalue { i32, ptr } zeroinitializer, ptr %t243, 1
  store { i32, ptr } %t244, ptr %rv
  br label %ret
bb63:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %t245)
  %t248 = extractvalue { i32, ptr } %t247, 1
  %t249 = extractvalue { i32, ptr } %t247, 0
  store i32 %t249, ptr %l94
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb65, label %ok.251
ok.251:
  store ptr %t248, ptr %l93
  br label %bb64
bb64:
  %t252 = load ptr, ptr %l93, !tbaa !29
  store ptr %t252, ptr %l91, !tbaa !29
  br label %bb66
bb65:
  %t253 = load i32, ptr %l94, !tbaa !23
  %t254 = lshr i32 %t253, 16
  %t255 = and i32 %t253, 65535
  %t256 = icmp eq i32 %t254, 1
  %t257 = select i1 %t256, i32 1, i32 0
  %t258 = icmp eq i32 %t253, 0
  %t259 = shl i32 %t257, 16
  %t260 = or i32 %t259, %t255
  %t261 = select i1 %t258, i32 0, i32 %t260
  %t263 = insertvalue { i32, ptr } zeroinitializer, i32 %t261, 0
  store { i32, ptr } %t263, ptr %rv
  br label %ret
bb66:
  %t264 = load ptr, ptr %l91, !tbaa !29
  %t265 = insertvalue { i32, ptr } zeroinitializer, ptr %t264, 1
  store { i32, ptr } %t265, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca ptr
  %l76 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i32
  %l86 = alloca ptr
  %l93 = alloca ptr
  %l102 = alloca i1
  %l105 = alloca i1
  %l107 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i32
  %l112 = alloca ptr
  %l120 = alloca i32
  %l123 = alloca i32
  %l124 = alloca i32
  %l126 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l141 = alloca ptr
  %l150 = alloca i64
  %l152 = alloca ptr
  %l156 = alloca i1
  %l159 = alloca i1
  %l160 = alloca i32
  %l162 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca i32
  %l177 = alloca ptr
  %l186 = alloca i1
  %l191 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l195 = alloca i32
  %l197 = alloca ptr
  %l205 = alloca i32
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l224 = alloca i32
  %l227 = alloca %"compiler/source:Span"
  %l228 = alloca ptr
  %l234 = alloca ptr
  %s1 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t343 = alloca { i64, [5 x i64] }, align 8
  %t553 = alloca { i64, [5 x i64] }, align 8
  %t603 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t7)
  store i32 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t10, i32 91)
  store i1 %t13, ptr %l16
  br label %bb3
bb3:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb7
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t15, i32 95)
  store i1 %t18, ptr %l20
  br label %bb6
bb6:
  %t19 = load i1, ptr %l20, !tbaa !21
  store i1 %t19, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l17, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  %t23 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 93)
  store { i64, ptr } %t23, ptr %l23
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t24 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t31, { i64, ptr } %t30)
  store i32 %t33, ptr %l25
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb12, label %ok.35
ok.35:
  br label %bb11
bb11:
  br label %bb13
bb12:
  %t36 = load i32, ptr %l25, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  call void @__olang_scope_close(ptr %s1)
  %t46 = insertvalue { i32, ptr } zeroinitializer, i32 %t44, 0
  store { i32, ptr } %t46, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 11
  %t50 = load i1, ptr %t49, !tbaa !21
  store i1 %t50, ptr %l3, !tbaa !21
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 19
  %t55 = load i1, ptr %t54, !tbaa !21
  store i1 %t55, ptr %l4, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 11
  store i1 false, ptr %t59, !tbaa !21
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 19
  store i1 true, ptr %t62, !tbaa !21
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t64, i32 0, i32 17
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = add i64 %t66, 1
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 17
  store i64 %t68, ptr %t71, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t72, i32 61)
  store i1 %t75, ptr %l38
  br label %bb15
bb15:
  %t76 = load i1, ptr %l38, !tbaa !21
  br i1 %t76, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb19
bb17:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t77, i32 93)
  store i1 %t80, ptr %l42
  br label %bb18
bb18:
  %t81 = load i1, ptr %l42, !tbaa !21
  %t82 = xor i1 %t81, true
  store i1 %t82, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l39, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  store ptr null, ptr %l5, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 61)
  store i1 %t88, ptr %l46
  br label %bb22
bb21:
  br label %bb84
bb22:
  %t89 = load i1, ptr %l46, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t92)
  %t95 = extractvalue { i32, ptr } %t94, 1
  %t96 = extractvalue { i32, ptr } %t94, 0
  store i32 %t96, ptr %l51
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb26, label %ok.98
ok.98:
  store ptr %t95, ptr %l50
  br label %bb25
bb24:
  br label %bb38
bb25:
  %t99 = load ptr, ptr %l50, !tbaa !29
  store ptr %t99, ptr %l48, !tbaa !29
  br label %bb27
bb26:
  %t100 = load i32, ptr %l51, !tbaa !23
  %t101 = lshr i32 %t100, 16
  %t102 = and i32 %t100, 65535
  %t103 = icmp eq i32 %t101, 1
  %t104 = select i1 %t103, i32 1, i32 0
  %t105 = icmp eq i32 %t100, 0
  %t106 = shl i32 %t104, 16
  %t107 = or i32 %t106, %t102
  %t108 = select i1 %t105, i32 0, i32 %t107
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l53, !tbaa !29
  %t110 = load ptr, ptr %l53, !tbaa !29
  %t111 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 17
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = sub i64 %t112, 1
  %t116 = load ptr, ptr %l53, !tbaa !29
  %t117 = getelementptr %"compiler/parse:Parser", ptr %t116, i32 0, i32 17
  store i64 %t114, ptr %t117, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i1, ptr %l3, !tbaa !21
  %t122 = getelementptr %"compiler/parse:Parser", ptr %t118, i32 0, i32 11
  store i1 %t119, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i1, ptr %l4, !tbaa !21
  %t127 = getelementptr %"compiler/parse:Parser", ptr %t123, i32 0, i32 19
  store i1 %t124, ptr %t127, !tbaa !21
  %t129 = insertvalue { i32, ptr } zeroinitializer, i32 %t108, 0
  store { i32, ptr } %t129, ptr %rv
  br label %ret
bb27:
  %t130 = load ptr, ptr %l48, !tbaa !29
  store ptr %t130, ptr %l5, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t132)
  store i1 %t134, ptr %l62
  br label %bb28
bb28:
  %t135 = load i1, ptr %l62, !tbaa !21
  br i1 %t135, label %bb29, label %bb30
bb29:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t140 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %t136, ptr %t137)
  %t141 = extractvalue { i32, ptr } %t140, 1
  %t142 = extractvalue { i32, ptr } %t140, 0
  store i32 %t142, ptr %l67
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb32, label %ok.144
ok.144:
  store ptr %t141, ptr %l66
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t145 = load ptr, ptr %l66, !tbaa !29
  store ptr %t145, ptr %l63, !tbaa !29
  br label %bb33
bb32:
  %t146 = load i32, ptr %l67, !tbaa !23
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t146, 0
  %t152 = shl i32 %t150, 16
  %t153 = or i32 %t152, %t148
  %t154 = select i1 %t151, i32 0, i32 %t153
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = getelementptr %"compiler/parse:Parser", ptr %t156, i32 0, i32 17
  %t158 = load i64, ptr %t157, !tbaa !24
  %t160 = sub i64 %t158, 1
  %t162 = load ptr, ptr %l69, !tbaa !29
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t162, i32 0, i32 17
  store i64 %t160, ptr %t163, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i1, ptr %l3, !tbaa !21
  %t168 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 11
  store i1 %t165, ptr %t168, !tbaa !21
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i1, ptr %l4, !tbaa !21
  %t173 = getelementptr %"compiler/parse:Parser", ptr %t169, i32 0, i32 19
  store i1 %t170, ptr %t173, !tbaa !21
  %t175 = insertvalue { i32, ptr } zeroinitializer, i32 %t154, 0
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb33:
  %t176 = load ptr, ptr %l63, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l2, !tbaa !23
  %t181 = load ptr, ptr %l5, !tbaa !29
  %t187 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %t177, i32 %t178, ptr %t176, ptr %t181, i32 93)
  %t188 = extractvalue { i32, ptr } %t187, 1
  %t189 = extractvalue { i32, ptr } %t187, 0
  store i32 %t189, ptr %l84
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb35, label %ok.191
ok.191:
  store ptr %t188, ptr %l83
  br label %bb34
bb34:
  %t192 = load ptr, ptr %l83, !tbaa !29
  store ptr %t192, ptr %l76, !tbaa !29
  br label %bb36
bb35:
  %t193 = load i32, ptr %l84, !tbaa !23
  %t194 = lshr i32 %t193, 16
  %t195 = and i32 %t193, 65535
  %t196 = icmp eq i32 %t194, 1
  %t197 = select i1 %t196, i32 1, i32 0
  %t198 = icmp eq i32 %t193, 0
  %t199 = shl i32 %t197, 16
  %t200 = or i32 %t199, %t195
  %t201 = select i1 %t198, i32 0, i32 %t200
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l86, !tbaa !29
  %t203 = load ptr, ptr %l86, !tbaa !29
  %t204 = getelementptr %"compiler/parse:Parser", ptr %t203, i32 0, i32 17
  %t205 = load i64, ptr %t204, !tbaa !24
  %t207 = sub i64 %t205, 1
  %t209 = load ptr, ptr %l86, !tbaa !29
  %t210 = getelementptr %"compiler/parse:Parser", ptr %t209, i32 0, i32 17
  store i64 %t207, ptr %t210, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i1, ptr %l3, !tbaa !21
  %t215 = getelementptr %"compiler/parse:Parser", ptr %t211, i32 0, i32 11
  store i1 %t212, ptr %t215, !tbaa !21
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load i1, ptr %l4, !tbaa !21
  %t220 = getelementptr %"compiler/parse:Parser", ptr %t216, i32 0, i32 19
  store i1 %t217, ptr %t220, !tbaa !21
  %t222 = insertvalue { i32, ptr } zeroinitializer, i32 %t201, 0
  store { i32, ptr } %t222, ptr %rv
  br label %ret
bb36:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l93, !tbaa !29
  %t224 = load ptr, ptr %l93, !tbaa !29
  %t225 = getelementptr %"compiler/parse:Parser", ptr %t224, i32 0, i32 17
  %t226 = load i64, ptr %t225, !tbaa !24
  %t228 = sub i64 %t226, 1
  %t230 = load ptr, ptr %l93, !tbaa !29
  %t231 = getelementptr %"compiler/parse:Parser", ptr %t230, i32 0, i32 17
  store i64 %t228, ptr %t231, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i1, ptr %l3, !tbaa !21
  %t236 = getelementptr %"compiler/parse:Parser", ptr %t232, i32 0, i32 11
  store i1 %t233, ptr %t236, !tbaa !21
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i1, ptr %l4, !tbaa !21
  %t241 = getelementptr %"compiler/parse:Parser", ptr %t237, i32 0, i32 19
  store i1 %t238, ptr %t241, !tbaa !21
  %t242 = load ptr, ptr %l76, !tbaa !29
  %t243 = insertvalue { i32, ptr } zeroinitializer, ptr %t242, 1
  store { i32, ptr } %t243, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t247 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t244, i32 61)
  store i1 %t247, ptr %l102
  br label %bb39
bb39:
  %t248 = load i1, ptr %l102, !tbaa !21
  br i1 %t248, label %bb40, label %bb41
bb40:
  store ptr null, ptr %l7, !tbaa !29
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t252 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t249, i32 93)
  store i1 %t252, ptr %l105
  br label %bb42
bb41:
  br label %bb53
bb42:
  %t253 = load i1, ptr %l105, !tbaa !21
  %t254 = xor i1 %t253, true
  br i1 %t254, label %bb43, label %bb44
bb43:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t256)
  %t259 = extractvalue { i32, ptr } %t258, 1
  %t260 = extractvalue { i32, ptr } %t258, 0
  store i32 %t260, ptr %l110
  %t261 = icmp ne i32 %t260, 0
  br i1 %t261, label %bb46, label %ok.262
ok.262:
  store ptr %t259, ptr %l109
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t263 = load ptr, ptr %l109, !tbaa !29
  store ptr %t263, ptr %l107, !tbaa !29
  br label %bb47
bb46:
  %t264 = load i32, ptr %l110, !tbaa !23
  %t265 = lshr i32 %t264, 16
  %t266 = and i32 %t264, 65535
  %t267 = icmp eq i32 %t265, 1
  %t268 = select i1 %t267, i32 1, i32 0
  %t269 = icmp eq i32 %t264, 0
  %t270 = shl i32 %t268, 16
  %t271 = or i32 %t270, %t266
  %t272 = select i1 %t269, i32 0, i32 %t271
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l112, !tbaa !29
  %t274 = load ptr, ptr %l112, !tbaa !29
  %t275 = getelementptr %"compiler/parse:Parser", ptr %t274, i32 0, i32 17
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = sub i64 %t276, 1
  %t280 = load ptr, ptr %l112, !tbaa !29
  %t281 = getelementptr %"compiler/parse:Parser", ptr %t280, i32 0, i32 17
  store i64 %t278, ptr %t281, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i1, ptr %l3, !tbaa !21
  %t286 = getelementptr %"compiler/parse:Parser", ptr %t282, i32 0, i32 11
  store i1 %t283, ptr %t286, !tbaa !21
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i1, ptr %l4, !tbaa !21
  %t291 = getelementptr %"compiler/parse:Parser", ptr %t287, i32 0, i32 19
  store i1 %t288, ptr %t291, !tbaa !21
  %t293 = insertvalue { i32, ptr } zeroinitializer, i32 %t272, 0
  store { i32, ptr } %t293, ptr %rv
  br label %ret
bb47:
  %t294 = load ptr, ptr %l107, !tbaa !29
  store ptr %t294, ptr %l7, !tbaa !29
  br label %bb48
bb48:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t299 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t296, i32 93)
  %t300 = extractvalue { i32, i32 } %t299, 1
  %t301 = extractvalue { i32, i32 } %t299, 0
  store i32 %t301, ptr %l124
  %t302 = icmp ne i32 %t301, 0
  br i1 %t302, label %bb50, label %ok.303
ok.303:
  store i32 %t300, ptr %l123
  br label %bb49
bb49:
  %t304 = load i32, ptr %l123, !tbaa !23
  store i32 %t304, ptr %l120, !tbaa !23
  br label %bb51
bb50:
  %t305 = load i32, ptr %l124, !tbaa !23
  %t306 = lshr i32 %t305, 16
  %t307 = and i32 %t305, 65535
  %t308 = icmp eq i32 %t306, 1
  %t309 = select i1 %t308, i32 1, i32 0
  %t310 = icmp eq i32 %t305, 0
  %t311 = shl i32 %t309, 16
  %t312 = or i32 %t311, %t307
  %t313 = select i1 %t310, i32 0, i32 %t312
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l126, !tbaa !29
  %t315 = load ptr, ptr %l126, !tbaa !29
  %t316 = getelementptr %"compiler/parse:Parser", ptr %t315, i32 0, i32 17
  %t317 = load i64, ptr %t316, !tbaa !24
  %t319 = sub i64 %t317, 1
  %t321 = load ptr, ptr %l126, !tbaa !29
  %t322 = getelementptr %"compiler/parse:Parser", ptr %t321, i32 0, i32 17
  store i64 %t319, ptr %t322, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i1, ptr %l3, !tbaa !21
  %t327 = getelementptr %"compiler/parse:Parser", ptr %t323, i32 0, i32 11
  store i1 %t324, ptr %t327, !tbaa !21
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i1, ptr %l4, !tbaa !21
  %t332 = getelementptr %"compiler/parse:Parser", ptr %t328, i32 0, i32 19
  store i1 %t329, ptr %t332, !tbaa !21
  %t334 = insertvalue { i32, ptr } zeroinitializer, i32 %t313, 0
  store { i32, ptr } %t334, ptr %rv
  br label %ret
bb51:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l2, !tbaa !23
  %t339 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t335, i32 %t336)
  store %"compiler/source:Span" %t339, ptr %l135
  br label %bb52
bb52:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t341 = load ptr, ptr %l5, !tbaa !29
  %t342 = load ptr, ptr %l7, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t343
  %t344 = getelementptr { i64, [5 x i64] }, ptr %t343, i32 0, i32 0
  store i64 17, ptr %t344
  %t345 = load %"compiler/source:Span", ptr %l135
  %t346 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } undef, %"compiler/source:Span" %t345, 0
  %t348 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t346, ptr %t340, 1
  %t350 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t348, ptr %t341, 2
  %t352 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t350, ptr %t342, 3
  %t353 = getelementptr { i64, [5 x i64] }, ptr %t343, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, ptr } %t352, ptr %t353
  %t354 = load { i64, [5 x i64] }, ptr %t343
  %t356 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t354, ptr %t356
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l141, !tbaa !29
  %t358 = load ptr, ptr %l141, !tbaa !29
  %t359 = getelementptr %"compiler/parse:Parser", ptr %t358, i32 0, i32 17
  %t360 = load i64, ptr %t359, !tbaa !24
  %t362 = sub i64 %t360, 1
  %t364 = load ptr, ptr %l141, !tbaa !29
  %t365 = getelementptr %"compiler/parse:Parser", ptr %t364, i32 0, i32 17
  store i64 %t362, ptr %t365, !tbaa !24
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i1, ptr %l3, !tbaa !21
  %t370 = getelementptr %"compiler/parse:Parser", ptr %t366, i32 0, i32 11
  store i1 %t367, ptr %t370, !tbaa !21
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i1, ptr %l4, !tbaa !21
  %t375 = getelementptr %"compiler/parse:Parser", ptr %t371, i32 0, i32 19
  store i1 %t372, ptr %t375, !tbaa !21
  %t377 = insertvalue { i32, ptr } zeroinitializer, ptr %t356, 1
  store { i32, ptr } %t377, ptr %rv
  br label %ret
bb53:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/parse:Parser", ptr %t378, i32 0, i32 30
  %t382 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t380)
  store i64 %t382, ptr %l150
  br label %bb54
bb54:
  %t383 = load i64, ptr %l150, !tbaa !24
  store i64 %t383, ptr %l8, !tbaa !24
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/parse:Parser", ptr %t384, i32 0, i32 30
  store ptr %t386, ptr %l152, !tbaa !29
  %t387 = load ptr, ptr %l5, !tbaa !29
  %t389 = icmp eq ptr %t387, null
  br i1 %t389, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f067807cf96ff280_872aeb81d2c2c23c)
  unreachable
bb56:
  br label %bb57
bb57:
  %t391 = load ptr, ptr %l5, !tbaa !29
  %t392 = load ptr, ptr %l152, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t392, ptr %t391)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t397 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t394, i32 93)
  %t398 = extractvalue { i32, i1 } %t397, 1
  %t399 = extractvalue { i32, i1 } %t397, 0
  store i32 %t399, ptr %l160
  %t400 = icmp ne i32 %t399, 0
  br i1 %t400, label %bb61, label %ok.401
ok.401:
  store i1 %t398, ptr %l159
  br label %bb60
bb60:
  %t402 = load i1, ptr %l159, !tbaa !21
  store i1 %t402, ptr %l156, !tbaa !21
  br label %bb62
bb61:
  %t403 = load i32, ptr %l160, !tbaa !23
  %t404 = lshr i32 %t403, 16
  %t405 = and i32 %t403, 65535
  %t406 = icmp eq i32 %t404, 1
  %t407 = select i1 %t406, i32 1, i32 0
  %t408 = icmp eq i32 %t403, 0
  %t409 = shl i32 %t407, 16
  %t410 = or i32 %t409, %t405
  %t411 = select i1 %t408, i32 0, i32 %t410
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l162, !tbaa !29
  %t413 = load ptr, ptr %l162, !tbaa !29
  %t414 = getelementptr %"compiler/parse:Parser", ptr %t413, i32 0, i32 17
  %t415 = load i64, ptr %t414, !tbaa !24
  %t417 = sub i64 %t415, 1
  %t419 = load ptr, ptr %l162, !tbaa !29
  %t420 = getelementptr %"compiler/parse:Parser", ptr %t419, i32 0, i32 17
  store i64 %t417, ptr %t420, !tbaa !24
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i1, ptr %l3, !tbaa !21
  %t425 = getelementptr %"compiler/parse:Parser", ptr %t421, i32 0, i32 11
  store i1 %t422, ptr %t425, !tbaa !21
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load i1, ptr %l4, !tbaa !21
  %t430 = getelementptr %"compiler/parse:Parser", ptr %t426, i32 0, i32 19
  store i1 %t427, ptr %t430, !tbaa !21
  %t432 = insertvalue { i32, ptr } zeroinitializer, i32 %t411, 0
  store { i32, ptr } %t432, ptr %rv
  br label %ret
bb62:
  %t433 = load i1, ptr %l156, !tbaa !21
  %t434 = xor i1 %t433, true
  br i1 %t434, label %bb63, label %bb64
bb63:
  br label %bb71
bb64:
  br label %bb65
bb65:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/parse:Parser", ptr %t436, i32 0, i32 30
  store ptr %t438, ptr %l171, !tbaa !29
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t439)
  %t442 = extractvalue { i32, ptr } %t441, 1
  %t443 = extractvalue { i32, ptr } %t441, 0
  store i32 %t443, ptr %l175
  %t444 = icmp ne i32 %t443, 0
  br i1 %t444, label %bb67, label %ok.445
ok.445:
  store ptr %t442, ptr %l174
  br label %bb66
bb66:
  %t446 = load ptr, ptr %l174, !tbaa !29
  store ptr %t446, ptr %l172, !tbaa !29
  br label %bb68
bb67:
  %t447 = load i32, ptr %l175, !tbaa !23
  %t448 = lshr i32 %t447, 16
  %t449 = and i32 %t447, 65535
  %t450 = icmp eq i32 %t448, 1
  %t451 = select i1 %t450, i32 1, i32 0
  %t452 = icmp eq i32 %t447, 0
  %t453 = shl i32 %t451, 16
  %t454 = or i32 %t453, %t449
  %t455 = select i1 %t452, i32 0, i32 %t454
  %t456 = load ptr, ptr %l0, !tbaa !29
  store ptr %t456, ptr %l177, !tbaa !29
  %t457 = load ptr, ptr %l177, !tbaa !29
  %t458 = getelementptr %"compiler/parse:Parser", ptr %t457, i32 0, i32 17
  %t459 = load i64, ptr %t458, !tbaa !24
  %t461 = sub i64 %t459, 1
  %t463 = load ptr, ptr %l177, !tbaa !29
  %t464 = getelementptr %"compiler/parse:Parser", ptr %t463, i32 0, i32 17
  store i64 %t461, ptr %t464, !tbaa !24
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load i1, ptr %l3, !tbaa !21
  %t469 = getelementptr %"compiler/parse:Parser", ptr %t465, i32 0, i32 11
  store i1 %t466, ptr %t469, !tbaa !21
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i1, ptr %l4, !tbaa !21
  %t474 = getelementptr %"compiler/parse:Parser", ptr %t470, i32 0, i32 19
  store i1 %t471, ptr %t474, !tbaa !21
  %t476 = insertvalue { i32, ptr } zeroinitializer, i32 %t455, 0
  store { i32, ptr } %t476, ptr %rv
  br label %ret
bb68:
  %t477 = load ptr, ptr %l171, !tbaa !29
  %t478 = load ptr, ptr %l172, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t477, ptr %t478)
  br label %bb69
bb69:
  br label %bb70
bb70:
  br label %bb59
bb71:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t482 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t479, i32 93)
  store i1 %t482, ptr %l186
  br label %bb72
bb72:
  %t483 = load i1, ptr %l186, !tbaa !21
  %t484 = xor i1 %t483, true
  br i1 %t484, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s26
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/parse:Parser", ptr %t486, i32 0, i32 30
  %t489 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t488, i64 %t489)
  br label %bb75
bb74:
  br label %bb80
bb75:
  %t492 = load ptr, ptr %l0, !tbaa !29
  store ptr %t492, ptr %l191, !tbaa !29
  %t494 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s26, i32 93)
  store { i64, ptr } %t494, ptr %l193
  br label %bb76
bb76:
  %t495 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t496 = extractvalue { i64, ptr } %t495, 0
  %t497 = extractvalue { i64, ptr } %t495, 1
  %t498 = mul i64 %t496, 1
  %t499 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t498)
  call void @llvm.memcpy.p0.p0.i64(ptr %t499, ptr %t497, i64 %t498, i1 false)
  %t500 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t499, 1
  %t502 = load ptr, ptr %l191, !tbaa !29
  %t504 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s26, ptr %t502, { i64, ptr } %t501)
  store i32 %t504, ptr %l195
  %t505 = icmp ne i32 %t504, 0
  br i1 %t505, label %bb78, label %ok.506
ok.506:
  br label %bb77
bb77:
  br label %bb79
bb78:
  %t507 = load i32, ptr %l195, !tbaa !23
  %t508 = lshr i32 %t507, 16
  %t509 = and i32 %t507, 65535
  %t510 = icmp eq i32 %t508, 1
  %t511 = select i1 %t510, i32 1, i32 0
  %t512 = icmp eq i32 %t507, 0
  %t513 = shl i32 %t511, 16
  %t514 = or i32 %t513, %t509
  %t515 = select i1 %t512, i32 0, i32 %t514
  call void @__olang_scope_close(ptr %s26)
  %t516 = load ptr, ptr %l0, !tbaa !29
  store ptr %t516, ptr %l197, !tbaa !29
  %t517 = load ptr, ptr %l197, !tbaa !29
  %t518 = getelementptr %"compiler/parse:Parser", ptr %t517, i32 0, i32 17
  %t519 = load i64, ptr %t518, !tbaa !24
  %t521 = sub i64 %t519, 1
  %t523 = load ptr, ptr %l197, !tbaa !29
  %t524 = getelementptr %"compiler/parse:Parser", ptr %t523, i32 0, i32 17
  store i64 %t521, ptr %t524, !tbaa !24
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load i1, ptr %l3, !tbaa !21
  %t529 = getelementptr %"compiler/parse:Parser", ptr %t525, i32 0, i32 11
  store i1 %t526, ptr %t529, !tbaa !21
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load i1, ptr %l4, !tbaa !21
  %t534 = getelementptr %"compiler/parse:Parser", ptr %t530, i32 0, i32 19
  store i1 %t531, ptr %t534, !tbaa !21
  %t536 = insertvalue { i32, ptr } zeroinitializer, i32 %t515, 0
  store { i32, ptr } %t536, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s26)
  br label %bb80
bb80:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t537)
  store i32 %t539, ptr %l205
  br label %bb81
bb81:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load i32, ptr %l2, !tbaa !23
  %t544 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t540, i32 %t541)
  store %"compiler/source:Span" %t544, ptr %l208
  br label %bb82
bb82:
  %t545 = load ptr, ptr %l1, !tbaa !29
  store ptr %t545, ptr %l209, !tbaa !29
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t548 = getelementptr %"compiler/parse:Parser", ptr %t546, i32 0, i32 30
  %t549 = load i64, ptr %l8, !tbaa !24
  %t552 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t548, i64 %t549)
  store { i64, ptr } %t552, ptr %l213
  br label %bb83
bb83:
  store { i64, [5 x i64] } zeroinitializer, ptr %t553
  %t554 = getelementptr { i64, [5 x i64] }, ptr %t553, i32 0, i32 0
  store i64 16, ptr %t554
  %t555 = load %"compiler/source:Span", ptr %l208
  %t556 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t555, 0
  %t557 = load ptr, ptr %l209, !tbaa !29
  %t558 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t556, ptr %t557, 1
  %t559 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t560 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t558, { i64, ptr } %t559, 2
  %t561 = getelementptr { i64, [5 x i64] }, ptr %t553, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t560, ptr %t561
  %t562 = load { i64, [5 x i64] }, ptr %t553
  %t564 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t562, ptr %t564
  %t565 = load ptr, ptr %l0, !tbaa !29
  store ptr %t565, ptr %l216, !tbaa !29
  %t566 = load ptr, ptr %l216, !tbaa !29
  %t567 = getelementptr %"compiler/parse:Parser", ptr %t566, i32 0, i32 17
  %t568 = load i64, ptr %t567, !tbaa !24
  %t570 = sub i64 %t568, 1
  %t572 = load ptr, ptr %l216, !tbaa !29
  %t573 = getelementptr %"compiler/parse:Parser", ptr %t572, i32 0, i32 17
  store i64 %t570, ptr %t573, !tbaa !24
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load i1, ptr %l3, !tbaa !21
  %t578 = getelementptr %"compiler/parse:Parser", ptr %t574, i32 0, i32 11
  store i1 %t575, ptr %t578, !tbaa !21
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load i1, ptr %l4, !tbaa !21
  %t583 = getelementptr %"compiler/parse:Parser", ptr %t579, i32 0, i32 19
  store i1 %t580, ptr %t583, !tbaa !21
  %t585 = insertvalue { i32, ptr } zeroinitializer, ptr %t564, 1
  store { i32, ptr } %t585, ptr %rv
  br label %ret
bb84:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t588 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t586)
  store i32 %t588, ptr %l224
  br label %bb85
bb85:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load i32, ptr %l2, !tbaa !23
  %t593 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t589, i32 %t590)
  store %"compiler/source:Span" %t593, ptr %l227
  br label %bb86
bb86:
  %t594 = load ptr, ptr %l1, !tbaa !29
  store ptr %t594, ptr %l228, !tbaa !29
  %t595 = icmp sge i64 0, 0
  br i1 %t595, label %bb87, label %bb88
bb87:
  %t597 = icmp sle i64 0, 1152921504606846975
  br i1 %t597, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_882dfc00c36114e5_890842da0dcd92c9)
  unreachable
bb89:
  %t599 = mul i64 0, 8
  %t600 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t599)
  %t601 = insertvalue { i64, ptr } undef, i64 0, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t600, 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t603
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t603, i32 0, i32 0
  store i64 16, ptr %t604
  %t605 = load %"compiler/source:Span", ptr %l227
  %t606 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t605, 0
  %t607 = load ptr, ptr %l228, !tbaa !29
  %t608 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t606, ptr %t607, 1
  %t610 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t608, { i64, ptr } %t602, 2
  %t611 = getelementptr { i64, [5 x i64] }, ptr %t603, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t610, ptr %t611
  %t612 = load { i64, [5 x i64] }, ptr %t603
  %t614 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t612, ptr %t614
  %t615 = load ptr, ptr %l0, !tbaa !29
  store ptr %t615, ptr %l234, !tbaa !29
  %t616 = load ptr, ptr %l234, !tbaa !29
  %t617 = getelementptr %"compiler/parse:Parser", ptr %t616, i32 0, i32 17
  %t618 = load i64, ptr %t617, !tbaa !24
  %t620 = sub i64 %t618, 1
  %t622 = load ptr, ptr %l234, !tbaa !29
  %t623 = getelementptr %"compiler/parse:Parser", ptr %t622, i32 0, i32 17
  store i64 %t620, ptr %t623, !tbaa !24
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = load i1, ptr %l3, !tbaa !21
  %t628 = getelementptr %"compiler/parse:Parser", ptr %t624, i32 0, i32 11
  store i1 %t625, ptr %t628, !tbaa !21
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load i1, ptr %l4, !tbaa !21
  %t633 = getelementptr %"compiler/parse:Parser", ptr %t629, i32 0, i32 19
  store i1 %t630, ptr %t633, !tbaa !21
  %t635 = insertvalue { i32, ptr } zeroinitializer, ptr %t614, 1
  store { i32, ptr } %t635, ptr %rv
  br label %ret
bb90:
  call void @__olang_check_failed(ptr @olang_loc_882dfc00c36114e5_890842da0dcd92c9)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/token:Token"
  %l6 = alloca i32
  %l9 = alloca i1
  %l12 = alloca i1
  %l18 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 1 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  %t12 = load i32, ptr %l2
  %t14 = trunc i64 0 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i32, ptr %l2
  %t20 = trunc i64 8 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/scan:Tokens", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i64 %t32
  %t37 = load %"compiler/token:Token", ptr %t36
  store %"compiler/token:Token" %t37, ptr %l3
  %t39 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = icmp sgt i32 %t40, %t42
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/source:Source", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l27, !tbaa !27
  %t54 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t58 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t57
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t61)
  store i1 %t63, ptr %l30
  br label %bb13
bb12:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb14
bb13:
  %t64 = load i1, ptr %l30, !tbaa !21
  store i1 %t64, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t65 = load i1, ptr %l24, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t7 = call i1 @compiler_2fparse_2eisOperandEndTok(i32 %t6)
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb10
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l9
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t15, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb8
bb7:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t22 = load i32, ptr %l14
  %t24 = trunc i64 58 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l10, !tbaa !21
  store i1 %t27, ptr %l6, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l6, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fparse_2eisPath(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 3
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Oracle", ptr %t11, i32 0, i32 1
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/parse:Parser", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l10, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t18)
  store %"compiler/source:Span" %t20, ptr %l12
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l10, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l12
  %t23 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %t21, %"compiler/source:Span" %t22)
  store { i64, ptr } %t23, ptr %l13
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l8, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t26 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  store i1 %t26, ptr %l14
  br label %bb7
bb7:
  %t27 = load i1, ptr %l14, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l22 = alloca i1
  %l24 = alloca i32
  %l28 = alloca %"compiler/ast:JoinS"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 14)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l8
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t21)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l13
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27
ok.27:
  store { i64, ptr } %t24, ptr %l12
  br label %bb4
bb4:
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l10, !tbaa !27
  br label %bb6
bb5:
  %t29 = load i32, ptr %l13, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 %t37, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t40, ptr %l2, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t41, i1 false)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l18
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47
ok.47:
  store { i64, ptr } %t44, ptr %l17
  br label %bb7
bb7:
  %t48 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t48, ptr %l15, !tbaa !27
  br label %bb9
bb8:
  %t49 = load i32, ptr %l18, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb9:
  %t60 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t60, ptr %l3, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t61, i32 8)
  store i1 %t64, ptr %l22
  br label %bb10
bb10:
  %t65 = load i1, ptr %l22, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t66)
  store i32 %t68, ptr %l24
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = call %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v0, ptr %v0, ptr %v0, i1 %a1, { i64, ptr } %t70, { i64, ptr } %t71)
  store %"compiler/ast:JoinS" %t75, ptr %l28
  br label %bb15
bb15:
  %t76 = load %"compiler/ast:JoinS", ptr %l28
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:JoinS" %t76, ptr %t77
  %t79 = insertvalue { i32, ptr } zeroinitializer, ptr %t77, 1
  store { i32, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l11 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l19 = alloca %"compiler/ast:VarDecl"
  %rv = alloca ptr
  %t9 = alloca i64
  %t27 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l4, !tbaa !23
  %t2 = icmp sge i64 1, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 1, 2305843009213693951
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb3:
  %t6 = mul i64 1, 4
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  %t8 = load i32, ptr %l4, !tbaa !23
  store i64 0, ptr %t9
  br label %fill.10
fill.10:
  %t13 = load i64, ptr %t9
  %t14 = icmp slt i64 %t13, 1
  br i1 %t14, label %fillb.11, label %filld.12
fillb.11:
  %t15 = getelementptr i32, ptr %t7, i64 %t13
  store i32 %t8, ptr %t15
  %t16 = add i64 %t13, 1
  store i64 %t16, ptr %t9
  br label %fill.10
filld.12:
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t7, 1
  store { i64, ptr } %t18, ptr %l7, !tbaa !27
  store %"compiler/source:Span" %a3, ptr %l8
  %t20 = icmp sge i64 1, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb5:
  %t22 = icmp sle i64 1, 1152921504606846975
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb7:
  %t24 = mul i64 1, 8
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  %t26 = load %"compiler/source:Span", ptr %l8
  store i64 0, ptr %t27
  br label %fill.28
fill.28:
  %t31 = load i64, ptr %t27
  %t32 = icmp slt i64 %t31, 1
  br i1 %t32, label %fillb.29, label %filld.30
fillb.29:
  %t33 = getelementptr %"compiler/source:Span", ptr %t25, i64 %t31
  store %"compiler/source:Span" %t26, ptr %t33
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %t27
  br label %fill.28
filld.30:
  %t35 = insertvalue { i64, ptr } undef, i64 1, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t25, 1
  store { i64, ptr } %t36, ptr %l11, !tbaa !27
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/ast:VarDecl", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l13, !tbaa !29
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb9:
  %t43 = icmp sle i64 0, 1152921504606846975
  br i1 %t43, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb11:
  %t45 = mul i64 0, 8
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 0, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/ast:VarDecl", ptr %t49, i32 0, i32 4
  %t52 = load i1, ptr %t51, !tbaa !21
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t55 = load ptr, ptr %l13, !tbaa !29
  %t58 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t53, { i64, ptr } %t54, ptr %t55, { i64, ptr } %t48, i1 %t52, i1 true)
  store %"compiler/ast:VarDecl" %t58, ptr %l19
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb13:
  %t59 = load %"compiler/ast:VarDecl", ptr %l19
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t59, ptr %t60
  store ptr %t60, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca %"compiler/token:Token"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/token:Token"
  %l12 = alloca i32
  %l14 = alloca %"compiler/token:Token"
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i32
  %l30 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l47 = alloca %"compiler/msgs:Msg"
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l79 = alloca %"compiler/msgs:Msg"
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i32
  %l94 = alloca %"compiler/msgs:Msg"
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t1)
  store %"compiler/token:Token" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l10
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t8)
  store %"compiler/token:Token" %t10, ptr %l14
  br label %bb3
bb3:
  %t11 = load %"compiler/token:Token", ptr %l14
  store %"compiler/token:Token" %t11, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t12, i32 8)
  store i1 %t15, ptr %l17
  br label %bb4
bb4:
  %t16 = load i1, ptr %l17, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t17, i32 0)
  store i1 %t20, ptr %l21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l21, !tbaa !21
  store i1 %t21, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l18, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb13
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t26, i32 %t28)
  store i32 %t31, ptr %l26
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t35, i32 %t37)
  store i32 %t40, ptr %l30
  br label %bb12
bb12:
  %t41 = load i32, ptr %l26, !tbaa !23
  %t42 = load i32, ptr %l30, !tbaa !23
  %t43 = icmp ne i32 %t41, %t42
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s1
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  %t47 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t48 = load i32, ptr %t47, !tbaa !23
  store i32 %t48, ptr %l33, !tbaa !23
  %t49 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t50 = load i32, ptr %t49, !tbaa !23
  store i32 %t50, ptr %l34, !tbaa !23
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %s1)
  store %"compiler/msgs:Msg" %t51, ptr %l35
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l32, !tbaa !29
  %t53 = load i32, ptr %l33, !tbaa !23
  %t54 = load i32, ptr %l34, !tbaa !23
  %t55 = load %"compiler/msgs:Msg", ptr %l35
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s1, ptr %t52, i32 %t53, i32 %t54, %"compiler/msgs:Msg" %t55)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb18:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l38
  br label %bb19
bb19:
  %t61 = load i32, ptr %l38
  %t62 = call { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %s0, i32 %t61)
  store { i64, ptr } %t62, ptr %l39
  br label %bb20
bb20:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t63, ptr %l3, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t64, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t66, ptr %l41
  br label %bb21
bb21:
  %t67 = load i1, ptr %l41, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s2
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l43, !tbaa !29
  %t71 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  store i32 %t72, ptr %l44, !tbaa !23
  %t73 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t74 = load i32, ptr %t73, !tbaa !23
  store i32 %t74, ptr %l45, !tbaa !23
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t77 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s0, ptr %s2, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t77, ptr %l47
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = load i32, ptr %l44, !tbaa !23
  %t80 = load i32, ptr %l45, !tbaa !23
  %t81 = load %"compiler/msgs:Msg", ptr %l47
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s2, ptr %t78, i32 %t79, i32 %t80, %"compiler/msgs:Msg" %t81)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t83, ptr %rv
  br label %ret
bb26:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 13
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l4, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t89, i32 0, i32 13
  store i1 true, ptr %t91, !tbaa !21
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 12
  %t95 = load i1, ptr %t94, !tbaa !21
  store i1 %t95, ptr %l5, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Parser", ptr %t97, i32 0, i32 12
  store i1 false, ptr %t99, !tbaa !21
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %t100)
  %t103 = extractvalue { i32, ptr } %t102, 1
  %t104 = extractvalue { i32, ptr } %t102, 0
  store i32 %t104, ptr %l58
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb28, label %ok.106
ok.106:
  store ptr %t103, ptr %l57
  br label %bb27
bb27:
  %t107 = load ptr, ptr %l57, !tbaa !29
  store ptr %t107, ptr %l55, !tbaa !29
  br label %bb29
bb28:
  %t108 = load i32, ptr %l58, !tbaa !23
  %t109 = lshr i32 %t108, 16
  %t110 = and i32 %t108, 65535
  %t111 = icmp eq i32 %t109, 1
  %t112 = select i1 %t111, i32 1, i32 0
  %t113 = icmp eq i32 %t108, 0
  %t114 = shl i32 %t112, 16
  %t115 = or i32 %t114, %t110
  %t116 = select i1 %t113, i32 0, i32 %t115
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i1, ptr %l5, !tbaa !21
  %t121 = getelementptr %"compiler/parse:Parser", ptr %t117, i32 0, i32 12
  store i1 %t118, ptr %t121, !tbaa !21
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i1, ptr %l4, !tbaa !21
  %t126 = getelementptr %"compiler/parse:Parser", ptr %t122, i32 0, i32 13
  store i1 %t123, ptr %t126, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t128 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t116, 0
  store { i32, { i64, ptr } } %t128, ptr %rv
  br label %ret
bb29:
  %t129 = load ptr, ptr %l55, !tbaa !29
  store ptr %t129, ptr %l6, !tbaa !29
  %t130 = load ptr, ptr %l6, !tbaa !29
  store ptr %t130, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t131 = load ptr, ptr %l64, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb30, label %bb31
bb30:
  %t134 = load ptr, ptr %l64, !tbaa !29
  %t135 = load i64, ptr %t134
  %t137 = icmp eq i64 %t135, 1
  store i1 %t137, ptr %l65, !tbaa !21
  br label %bb31
bb31:
  %t138 = load i1, ptr %l65, !tbaa !21
  br i1 %t138, label %bb32, label %bb33
bb32:
  %t139 = load ptr, ptr %l6, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr }, ptr %t141, i32 0, i32 0
  %t143 = load %"compiler/source:Span", ptr %t142
  store %"compiler/source:Span" %t143, ptr %l7
  br label %bb38
bb33:
  %t145 = load ptr, ptr %l6, !tbaa !29
  store ptr %t145, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t146 = load ptr, ptr %l70, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb34, label %bb35
bb34:
  %t149 = load ptr, ptr %l70, !tbaa !29
  %t150 = load i64, ptr %t149
  %t152 = icmp eq i64 %t150, 2
  store i1 %t152, ptr %l71, !tbaa !21
  br label %bb35
bb35:
  %t153 = load i1, ptr %l71, !tbaa !21
  br i1 %t153, label %bb36, label %bb37
bb36:
  %t154 = load ptr, ptr %l6, !tbaa !29
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", ptr }, ptr %t156, i32 0, i32 0
  %t158 = load %"compiler/source:Span", ptr %t157
  store %"compiler/source:Span" %t158, ptr %l7
  br label %bb38
bb37:
  br label %bb41
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l76, !tbaa !29
  %t161 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t162 = load i32, ptr %t161, !tbaa !23
  store i32 %t162, ptr %l77, !tbaa !23
  %t163 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t164 = load i32, ptr %t163, !tbaa !23
  store i32 %t164, ptr %l78, !tbaa !23
  %t165 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s7, ptr %s7, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t165, ptr %l79
  br label %bb39
bb39:
  %t166 = load ptr, ptr %l76, !tbaa !29
  %t167 = load i32, ptr %l77, !tbaa !23
  %t168 = load i32, ptr %l78, !tbaa !23
  %t169 = load %"compiler/msgs:Msg", ptr %l79
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s7, ptr %t166, i32 %t167, i32 %t168, %"compiler/msgs:Msg" %t169)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i1, ptr %l5, !tbaa !21
  %t174 = getelementptr %"compiler/parse:Parser", ptr %t170, i32 0, i32 12
  store i1 %t171, ptr %t174, !tbaa !21
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i1, ptr %l4, !tbaa !21
  %t179 = getelementptr %"compiler/parse:Parser", ptr %t175, i32 0, i32 13
  store i1 %t176, ptr %t179, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t181 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t181, ptr %rv
  br label %ret
bb41:
  %t182 = load ptr, ptr %l6, !tbaa !29
  store ptr %t182, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t183 = load ptr, ptr %l85, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb42, label %bb43
bb42:
  %t186 = load ptr, ptr %l85, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 17
  store i1 %t189, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t190 = load i1, ptr %l86, !tbaa !21
  br i1 %t190, label %bb44, label %bb45
bb44:
  %t191 = load ptr, ptr %l6, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", ptr }, ptr %t193, i32 0, i32 0
  %t195 = load %"compiler/source:Span", ptr %t194
  store %"compiler/source:Span" %t195, ptr %l8
  br label %bb46
bb45:
  br label %bb49
bb46:
  store %olang.scope zeroinitializer, ptr %s12
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l91, !tbaa !29
  %t198 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  store i32 %t199, ptr %l92, !tbaa !23
  %t200 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t201 = load i32, ptr %t200, !tbaa !23
  store i32 %t201, ptr %l93, !tbaa !23
  %t202 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s12, ptr %s12, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t202, ptr %l94
  br label %bb47
bb47:
  %t203 = load ptr, ptr %l91, !tbaa !29
  %t204 = load i32, ptr %l92, !tbaa !23
  %t205 = load i32, ptr %l93, !tbaa !23
  %t206 = load %"compiler/msgs:Msg", ptr %l94
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s12, ptr %t203, i32 %t204, i32 %t205, %"compiler/msgs:Msg" %t206)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s12)
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i1, ptr %l5, !tbaa !21
  %t211 = getelementptr %"compiler/parse:Parser", ptr %t207, i32 0, i32 12
  store i1 %t208, ptr %t211, !tbaa !21
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i1, ptr %l4, !tbaa !21
  %t216 = getelementptr %"compiler/parse:Parser", ptr %t212, i32 0, i32 13
  store i1 %t213, ptr %t216, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t218 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t218, ptr %rv
  br label %ret
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a66f16e9609fdd27_2fbef1e5bed159db)
  unreachable
bb54:
  %t219 = load ptr, ptr %l6, !tbaa !29
  %t220 = mul i64 1, 8
  %t221 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t220)
  %t222 = insertvalue { i64, ptr } undef, i64 1, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l101, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr ptr, ptr %t226, i64 0
  store ptr %t219, ptr %t227, !tbaa !39
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i1, ptr %l5, !tbaa !21
  %t232 = getelementptr %"compiler/parse:Parser", ptr %t228, i32 0, i32 12
  store i1 %t229, ptr %t232, !tbaa !21
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i1, ptr %l4, !tbaa !21
  %t237 = getelementptr %"compiler/parse:Parser", ptr %t233, i32 0, i32 13
  store i1 %t234, ptr %t237, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t238 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t239 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t238, 1
  store { i32, { i64, ptr } } %t239, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/parse:stackMarks"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/parse:stackMarks"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 30
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 31
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 32
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 33
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l12
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 34
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 35
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 36
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l21
  br label %bb7
bb7:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l9, !tbaa !24
  %t39 = load i64, ptr %l12, !tbaa !24
  %t40 = load i64, ptr %l15, !tbaa !24
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = call %"compiler/parse:stackMarks" @compiler_2fparse_3astackMarks_2ector(ptr %s0, i64 %t36, i64 %t37, i64 %t38, i64 %t39, i64 %t40, i64 %t41, i64 %t42)
  store %"compiler/parse:stackMarks" %t43, ptr %l22
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load %"compiler/parse:stackMarks", ptr %l22
  store %"compiler/parse:stackMarks" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:stackMarks", ptr %rv
  ret %"compiler/parse:stackMarks" %rr
}

define dso_local { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/token:Token"
  %l4 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i32
  %l16 = alloca %"compiler/token:Token"
  %l18 = alloca i32
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 1 to i32
  %t8 = icmp eq i32 %t5, %t7
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l1
  %t14 = call i1 @compiler_2fparse_2eisWordKeyword(i32 %t12)
  store i1 %t14, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i32 %t21, ptr %l13
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb9, label %ok.23
ok.23:
  br label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb10
bb9:
  %t24 = load i32, ptr %l13, !tbaa !23
  %t25 = lshr i32 %t24, 16
  %t26 = and i32 %t24, 65535
  %t27 = icmp eq i32 %t25, 1
  %t28 = select i1 %t27, i32 1, i32 0
  %t29 = icmp eq i32 %t24, 0
  %t30 = shl i32 %t28, 16
  %t31 = or i32 %t30, %t26
  %t32 = select i1 %t29, i32 0, i32 %t31
  call void @__olang_scope_close(ptr %s1)
  %t34 = insertvalue { i32, i32 } zeroinitializer, i32 %t32, 0
  store { i32, i32 } %t34, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t35)
  store %"compiler/token:Token" %t37, ptr %l16
  br label %bb12
bb12:
  %t38 = load %"compiler/token:Token", ptr %l16
  store %"compiler/token:Token" %t38, ptr %l2
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l18
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/parse:Parser", ptr %t42, i32 0, i32 2
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load %"compiler/token:Token", ptr %l2
  %t50 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t46, %"compiler/token:Token" %t47)
  store { i64, ptr } %t50, ptr %l23
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l20, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t53 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t51, { i64, ptr } %t52)
  store i32 %t53, ptr %l24
  br label %bb15
bb15:
  %t54 = load i32, ptr %l24, !tbaa !23
  %t55 = insertvalue { i32, i32 } zeroinitializer, i32 %t54, 1
  store { i32, i32 } %t55, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i32
  %l13 = alloca %"compiler/token:Token"
  %l14 = alloca i32
  %l16 = alloca %"compiler/token:Token"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 59)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t8, i64 1)
  store i32 %t10, ptr %l7
  br label %bb4
bb4:
  %t11 = load i32, ptr %l7
  %t13 = trunc i64 83 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  store i1 %t16, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l5, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t20, i64 0)
  store %"compiler/token:Token" %t22, ptr %l13
  br label %bb9
bb9:
  %t23 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 3
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l14, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t25, i64 1)
  store %"compiler/token:Token" %t27, ptr %l16
  br label %bb10
bb10:
  %t28 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t29 = load i32, ptr %t28, !tbaa !23
  %t30 = load i32, ptr %l14, !tbaa !23
  %t32 = icmp eq i32 %t30, %t29
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/parse:NameList"
  %rv = alloca ptr
  %t9 = alloca i64
  %t27 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l3, !tbaa !23
  %t2 = icmp sge i64 1, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 1, 2305843009213693951
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_56ae34a9066c1560_be19fd249755f1d4)
  unreachable
bb3:
  %t6 = mul i64 1, 4
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  %t8 = load i32, ptr %l3, !tbaa !23
  store i64 0, ptr %t9
  br label %fill.10
fill.10:
  %t13 = load i64, ptr %t9
  %t14 = icmp slt i64 %t13, 1
  br i1 %t14, label %fillb.11, label %filld.12
fillb.11:
  %t15 = getelementptr i32, ptr %t7, i64 %t13
  store i32 %t8, ptr %t15
  %t16 = add i64 %t13, 1
  store i64 %t16, ptr %t9
  br label %fill.10
filld.12:
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t7, 1
  store { i64, ptr } %t18, ptr %l6, !tbaa !27
  store %"compiler/source:Span" %a2, ptr %l7
  %t20 = icmp sge i64 1, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_56ae34a9066c1560_be19fd249755f1d4)
  unreachable
bb5:
  %t22 = icmp sle i64 1, 1152921504606846975
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_56ae34a9066c1560_be19fd249755f1d4)
  unreachable
bb7:
  %t24 = mul i64 1, 8
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  %t26 = load %"compiler/source:Span", ptr %l7
  store i64 0, ptr %t27
  br label %fill.28
fill.28:
  %t31 = load i64, ptr %t27
  %t32 = icmp slt i64 %t31, 1
  br i1 %t32, label %fillb.29, label %filld.30
fillb.29:
  %t33 = getelementptr %"compiler/source:Span", ptr %t25, i64 %t31
  store %"compiler/source:Span" %t26, ptr %t33
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %t27
  br label %fill.28
filld.30:
  %t35 = insertvalue { i64, ptr } undef, i64 1, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t25, 1
  %t37 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t39 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t37, { i64, ptr } %t36)
  store %"compiler/parse:NameList" %t39, ptr %l11
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_56ae34a9066c1560_be19fd249755f1d4)
  unreachable
bb9:
  %t40 = load %"compiler/parse:NameList", ptr %l11
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/parse:NameList" %t40, ptr %t41
  store ptr %t41, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenerOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i1
  %l29 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 91 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i32 90, ptr %l12
  br label %bb4
bb3:
  store i32 92, ptr %l12
  br label %bb4
bb4:
  %t14 = load i32, ptr %l12
  store i32 %t14, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb22
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t23, i64 %t24)
  store i32 %t27, ptr %l21
  br label %bb9
bb9:
  %t28 = load i32, ptr %l21
  store i32 %t28, ptr %l6
  %t29 = load i32, ptr %l6
  store i32 %t29, ptr %l22
  %t30 = load i32, ptr %l2
  store i32 %t30, ptr %l24
  %t33 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l22, ptr %l24)
  store i1 %t33, ptr %l26
  br label %bb10
bb10:
  %t34 = load i1, ptr %l26, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb20
bb12:
  %t39 = load i32, ptr %l6
  store i32 %t39, ptr %l29
  %t40 = load i32, ptr %l3
  store i32 %t40, ptr %l31
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l29, ptr %l31)
  store i1 %t43, ptr %l33
  br label %bb13
bb13:
  %t44 = load i1, ptr %l33, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb16, label %bb17
bb15:
  br label %bb19
bb16:
  %t53 = load i64, ptr %l5, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = sub i64 %t55, 1
  store i64 %t57, ptr %l5, !tbaa !24
  br label %bb21
bb21:
  br label %bb5
bb22:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandEndAfter(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i1
  %l56 = alloca i32
  %l65 = alloca i32
  %l66 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i1
  %l73 = alloca i32
  %l75 = alloca i32
  %l77 = alloca i1
  %l92 = alloca i64
  %l95 = alloca i64
  %l100 = alloca i32
  %l103 = alloca i1
  %l107 = alloca i32
  %l110 = alloca i1
  %l114 = alloca i1
  %l119 = alloca i32
  %l122 = alloca i1
  %l125 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/scan:Tokens", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 256, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb6
bb3:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l27, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb5
bb5:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  br label %bb68
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l2, !tbaa !24
  %t63 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t59, i64 %t60)
  store i32 %t63, ptr %l47
  br label %bb11
bb11:
  %t64 = load i32, ptr %l47
  store i32 %t64, ptr %l10
  %t65 = load i32, ptr %l10
  %t67 = trunc i64 90 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb14
bb13:
  %t70 = load i32, ptr %l10
  %t72 = trunc i64 92 to i32
  %t73 = icmp eq i32 %t70, %t72
  store i1 %t73, ptr %l50, !tbaa !21
  br label %bb14
bb14:
  %t75 = load i1, ptr %l50, !tbaa !21
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t76 = load i32, ptr %l10
  store i32 %t76, ptr %l11
  %t78 = load i32, ptr %l10
  %t80 = trunc i64 90 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb17, label %bb18
bb16:
  br label %bb41
bb17:
  store i32 91, ptr %l56
  br label %bb19
bb18:
  store i32 93, ptr %l56
  br label %bb19
bb19:
  %t85 = load i32, ptr %l56
  store i32 %t85, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l3, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb21, label %bb22
bb21:
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l2, !tbaa !24
  %t98 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t94, i64 %t95)
  store i32 %t98, ptr %l65
  br label %bb24
bb24:
  %t99 = load i32, ptr %l65
  store i32 %t99, ptr %l14
  %t100 = load i32, ptr %l14
  store i32 %t100, ptr %l66
  %t101 = load i32, ptr %l11
  store i32 %t101, ptr %l68
  %t104 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l66, ptr %l68)
  store i1 %t104, ptr %l70
  br label %bb25
bb25:
  %t105 = load i1, ptr %l70, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load i64, ptr %l13, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l13, !tbaa !24
  br label %bb35
bb27:
  %t110 = load i32, ptr %l14
  store i32 %t110, ptr %l73
  %t111 = load i32, ptr %l12
  store i32 %t111, ptr %l75
  %t114 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l73, ptr %l75)
  store i1 %t114, ptr %l77
  br label %bb28
bb28:
  %t115 = load i1, ptr %l77, !tbaa !21
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t118 = sub i64 %t116, 1
  store i64 %t118, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp eq i64 %t120, 0
  br i1 %t122, label %bb31, label %bb32
bb30:
  br label %bb34
bb31:
  br label %bb37
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t124 = load i64, ptr %l2, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l2, !tbaa !24
  br label %bb36
bb36:
  br label %bb20
bb37:
  %t128 = load i64, ptr %l2, !tbaa !24
  %t129 = load i64, ptr %l3, !tbaa !24
  %t132 = icmp sge i64 %t128, %t129
  br i1 %t132, label %bb38, label %bb39
bb38:
  %t134 = load i64, ptr %l1, !tbaa !24
  store i64 %t134, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t136 = load i64, ptr %l2, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l15, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l15, !tbaa !24
  %t144 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t140, i64 %t141)
  store i64 %t144, ptr %l92
  br label %bb42
bb42:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l2, !tbaa !24
  %t149 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t145, i64 %t146)
  store i64 %t149, ptr %l95
  br label %bb43
bb43:
  %t150 = load i64, ptr %l92, !tbaa !24
  %t151 = load i64, ptr %l95, !tbaa !24
  %t152 = icmp ne i64 %t150, %t151
  br i1 %t152, label %bb44, label %bb45
bb44:
  %t154 = load i64, ptr %l2, !tbaa !24
  store i64 %t154, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l15, !tbaa !24
  %t160 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t156, i64 %t157)
  store i32 %t160, ptr %l100
  br label %bb47
bb47:
  %t161 = load i32, ptr %l100
  %t163 = trunc i64 58 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb48, label %bb49
bb48:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l15, !tbaa !24
  %t169 = add i64 %t167, 1
  %t172 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t166, i64 %t169)
  store i32 %t172, ptr %l107
  br label %bb50
bb49:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb55
bb50:
  %t173 = load i32, ptr %l107
  %t175 = trunc i64 1 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb54
bb52:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i64, ptr %l15, !tbaa !24
  %t181 = add i64 %t179, 1
  %t184 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t178, i64 %t181)
  store i1 %t184, ptr %l114
  br label %bb53
bb53:
  %t185 = load i1, ptr %l114, !tbaa !21
  store i1 %t185, ptr %l110, !tbaa !21
  br label %bb54
bb54:
  %t186 = load i1, ptr %l110, !tbaa !21
  store i1 %t186, ptr %l103, !tbaa !21
  br label %bb55
bb55:
  %t187 = load i1, ptr %l103, !tbaa !21
  br i1 %t187, label %bb56, label %bb57
bb56:
  %t188 = load i64, ptr %l15, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l2, !tbaa !24
  br label %bb67
bb57:
  br label %bb58
bb58:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i64, ptr %l15, !tbaa !24
  %t196 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t192, i64 %t193)
  store i32 %t196, ptr %l119
  br label %bb59
bb59:
  %t197 = load i32, ptr %l119
  %t199 = trunc i64 90 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb63
bb61:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l15, !tbaa !24
  %t206 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t202, i64 %t203)
  store i32 %t206, ptr %l125
  br label %bb62
bb62:
  %t207 = load i32, ptr %l125
  %t209 = trunc i64 92 to i32
  %t210 = icmp eq i32 %t207, %t209
  store i1 %t210, ptr %l122, !tbaa !21
  br label %bb63
bb63:
  %t212 = load i1, ptr %l122, !tbaa !21
  br i1 %t212, label %bb64, label %bb65
bb64:
  %t213 = load i64, ptr %l15, !tbaa !24
  store i64 %t213, ptr %l2, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  %t215 = load i64, ptr %l2, !tbaa !24
  store i64 %t215, ptr %rv
  br label %ret
bb67:
  %t217 = load i64, ptr %l8, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l8, !tbaa !24
  br label %bb7
bb68:
  %t221 = load i64, ptr %l2, !tbaa !24
  store i64 %t221, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandStartBefore(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l38 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i1
  %l62 = alloca i32
  %l63 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i32
  %l74 = alloca i1
  %l78 = alloca i32
  %l79 = alloca i1
  %l86 = alloca i32
  %l89 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 256, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l18, !tbaa !24
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l15, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb50
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l2, !tbaa !24
  %t53 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t49, i64 %t50)
  store i32 %t53, ptr %l38
  br label %bb11
bb11:
  %t54 = load i32, ptr %l38
  store i32 %t54, ptr %l9
  %t55 = load i32, ptr %l9
  %t57 = trunc i64 91 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb14
bb13:
  %t60 = load i32, ptr %l9
  %t62 = trunc i64 93 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l41, !tbaa !21
  br label %bb14
bb14:
  %t65 = load i1, ptr %l41, !tbaa !21
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenerOf(ptr %v0, ptr %t66, i64 %t67)
  store i64 %t70, ptr %l46
  br label %bb17
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l67
  br label %bb31
bb17:
  %t76 = load i64, ptr %l46, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  %t77 = load i64, ptr %l2, !tbaa !24
  %t79 = icmp slt i64 %t77, 0
  br i1 %t79, label %bb18, label %bb19
bb18:
  store i64 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = sub i64 %t82, 1
  store i64 %t84, ptr %l10, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l10, !tbaa !24
  %t90 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t86, i64 %t87)
  store i64 %t90, ptr %l54
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l2, !tbaa !24
  %t95 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l57
  br label %bb22
bb22:
  %t96 = load i64, ptr %l54, !tbaa !24
  %t97 = load i64, ptr %l57, !tbaa !24
  %t98 = icmp eq i64 %t96, %t97
  br i1 %t98, label %bb23, label %bb24
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t100, i64 %t101)
  store i32 %t104, ptr %l62
  br label %bb25
bb24:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb27
bb25:
  %t105 = load i32, ptr %l62
  %t106 = call i1 @compiler_2fparse_2eisOperandTail(i32 %t105)
  store i1 %t106, ptr %l63
  br label %bb26
bb26:
  %t107 = load i1, ptr %l63, !tbaa !21
  store i1 %t107, ptr %l59, !tbaa !21
  br label %bb27
bb27:
  %t108 = load i1, ptr %l59, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t109 = load i64, ptr %l10, !tbaa !24
  store i64 %t109, ptr %l2, !tbaa !24
  br label %bb49
bb29:
  br label %bb30
bb30:
  br label %bb44
bb31:
  %t111 = load i1, ptr %l67, !tbaa !21
  br i1 %t111, label %bb32, label %bb33
bb32:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l2, !tbaa !24
  %t115 = sub i64 %t113, 1
  %t118 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t112, i64 %t115)
  store i32 %t118, ptr %l71
  br label %bb34
bb33:
  store i64 -1, ptr %rv
  br label %ret
bb34:
  %t120 = load i32, ptr %l71
  %t122 = trunc i64 58 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l2, !tbaa !24
  %t128 = sub i64 %t126, 2
  %t131 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t125, i64 %t128)
  store i32 %t131, ptr %l78
  br label %bb37
bb36:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb39
bb37:
  %t132 = load i32, ptr %l78
  %t133 = call i1 @compiler_2fparse_2eisOperandTail(i32 %t132)
  store i1 %t133, ptr %l79
  br label %bb38
bb38:
  %t134 = load i1, ptr %l79, !tbaa !21
  store i1 %t134, ptr %l74, !tbaa !21
  br label %bb39
bb39:
  %t135 = load i1, ptr %l74, !tbaa !21
  br i1 %t135, label %bb40, label %bb41
bb40:
  %t136 = load i64, ptr %l2, !tbaa !24
  %t138 = sub i64 %t136, 2
  store i64 %t138, ptr %l2, !tbaa !24
  br label %bb49
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l2, !tbaa !24
  %t143 = sub i64 %t141, 1
  %t146 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t140, i64 %t143)
  store i32 %t146, ptr %l86
  br label %bb45
bb45:
  %t147 = load i32, ptr %l86
  %t149 = trunc i64 87 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb46, label %bb47
bb46:
  store i64 -1, ptr %l89, !tbaa !24
  br label %bb48
bb47:
  %t152 = load i64, ptr %l2, !tbaa !24
  store i64 %t152, ptr %l89, !tbaa !24
  br label %bb48
bb48:
  %t154 = load i64, ptr %l89, !tbaa !24
  store i64 %t154, ptr %rv
  br label %ret
bb49:
  %t155 = load i64, ptr %l7, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l7, !tbaa !24
  br label %bb7
bb50:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l29 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i64
  %l42 = alloca i64
  %l61 = alloca i32
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l75 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i32
  %l100 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i64, ptr %l14, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l15, !tbaa !29
  %t8 = load ptr, ptr %l15, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 17
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = add i64 %t10, 1
  %t14 = load ptr, ptr %l15, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t14, i32 0, i32 17
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 18
  %t19 = load i1, ptr %t18, !tbaa !21
  store i1 %t19, ptr %l3, !tbaa !21
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 19
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l4, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 18
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 19
  store i1 true, ptr %t31, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 48
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l5, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 48
  store i1 false, ptr %t39, !tbaa !21
  br label %bb2
bb2:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t40, i32 91)
  store i1 %t43, ptr %l29
  br label %bb3
bb3:
  %t44 = load i1, ptr %l29, !tbaa !21
  %t45 = xor i1 %t44, true
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb4, label %bb5
bb4:
  br label %bb38
bb5:
  br label %bb6
bb6:
  %t49 = load i1, ptr %l5, !tbaa !21
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l35
  br label %bb9
bb8:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb10
bb9:
  %t54 = load i1, ptr %l35, !tbaa !21
  store i1 %t54, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  store i64 0, ptr %l6, !tbaa !24
  store i64 3, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp sgt i64 %t56, %t57
  br i1 %t60, label %bb13, label %bb14
bb12:
  br label %bb26
bb13:
  %t62 = load i64, ptr %l8, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb18
bb15:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = sub i64 %t74, 1
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = sdiv i64 %t76, %t77
  store i64 %t80, ptr %l42, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb17
bb17:
  %t82 = load i64, ptr %l42, !tbaa !24
  store i64 %t82, ptr %l39, !tbaa !24
  br label %bb18
bb18:
  %t83 = load i64, ptr %l39, !tbaa !24
  store i64 %t83, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  store i64 %t100, ptr %l11, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t102)
  store i32 %t104, ptr %l61
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t105 = load i64, ptr %l10, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l10, !tbaa !24
  br label %bb19
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/parse:Parser", ptr %t109, i32 0, i32 49
  store i1 true, ptr %t111, !tbaa !21
  br label %bb38
bb26:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/parse:Parser", ptr %t112, i32 0, i32 33
  store ptr %t114, ptr %l66, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t119 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %t115, i1 %a1)
  %t120 = extractvalue { i32, ptr } %t119, 1
  %t121 = extractvalue { i32, ptr } %t119, 0
  store i32 %t121, ptr %l71
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb28, label %ok.123
ok.123:
  store ptr %t120, ptr %l70
  br label %bb27
bb27:
  %t124 = load ptr, ptr %l70, !tbaa !29
  store ptr %t124, ptr %l67, !tbaa !29
  br label %bb29
bb28:
  %t125 = load i32, ptr %l71, !tbaa !23
  %t126 = lshr i32 %t125, 16
  %t127 = and i32 %t125, 65535
  %t128 = icmp eq i32 %t126, 1
  %t129 = select i1 %t128, i32 1, i32 0
  %t130 = icmp eq i32 %t125, 0
  %t131 = shl i32 %t129, 16
  %t132 = or i32 %t131, %t127
  %t133 = select i1 %t130, i32 0, i32 %t132
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i1, ptr %l4, !tbaa !21
  %t138 = getelementptr %"compiler/parse:Parser", ptr %t134, i32 0, i32 19
  store i1 %t135, ptr %t138, !tbaa !21
  %t140 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t133, 0
  store { i32, { i64, ptr } } %t140, ptr %rv
  br label %ret
bb29:
  %t141 = load ptr, ptr %l66, !tbaa !29
  %t142 = load ptr, ptr %l67, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v0, ptr %t141, ptr %t142)
  br label %bb30
bb30:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t146 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t143, i32 91)
  %t147 = extractvalue { i32, i1 } %t146, 1
  %t148 = extractvalue { i32, i1 } %t146, 0
  store i32 %t148, ptr %l79
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb32, label %ok.150
ok.150:
  store i1 %t147, ptr %l78
  br label %bb31
bb31:
  %t151 = load i1, ptr %l78, !tbaa !21
  store i1 %t151, ptr %l75, !tbaa !21
  br label %bb33
bb32:
  %t152 = load i32, ptr %l79, !tbaa !23
  %t153 = lshr i32 %t152, 16
  %t154 = and i32 %t152, 65535
  %t155 = icmp eq i32 %t153, 1
  %t156 = select i1 %t155, i32 1, i32 0
  %t157 = icmp eq i32 %t152, 0
  %t158 = shl i32 %t156, 16
  %t159 = or i32 %t158, %t154
  %t160 = select i1 %t157, i32 0, i32 %t159
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i1, ptr %l4, !tbaa !21
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t161, i32 0, i32 19
  store i1 %t162, ptr %t165, !tbaa !21
  %t167 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t160, 0
  store { i32, { i64, ptr } } %t167, ptr %rv
  br label %ret
bb33:
  %t168 = load i1, ptr %l75, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb2
bb38:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i1, ptr %l3, !tbaa !21
  %t175 = getelementptr %"compiler/parse:Parser", ptr %t171, i32 0, i32 18
  store i1 %t172, ptr %t175, !tbaa !21
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l86, !tbaa !29
  %t177 = load ptr, ptr %l86, !tbaa !29
  %t178 = getelementptr %"compiler/parse:Parser", ptr %t177, i32 0, i32 17
  %t179 = load i64, ptr %t178, !tbaa !24
  %t181 = sub i64 %t179, 1
  %t183 = load ptr, ptr %l86, !tbaa !29
  %t184 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 17
  store i64 %t181, ptr %t184, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t188 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t185, i32 91)
  %t189 = extractvalue { i32, i32 } %t188, 1
  %t190 = extractvalue { i32, i32 } %t188, 0
  store i32 %t190, ptr %l93
  %t191 = icmp ne i32 %t190, 0
  br i1 %t191, label %bb40, label %ok.192
ok.192:
  store i32 %t189, ptr %l92
  br label %bb39
bb39:
  %t193 = load i32, ptr %l92, !tbaa !23
  store i32 %t193, ptr %l89, !tbaa !23
  br label %bb41
bb40:
  %t194 = load i32, ptr %l93, !tbaa !23
  %t195 = lshr i32 %t194, 16
  %t196 = and i32 %t194, 65535
  %t197 = icmp eq i32 %t195, 1
  %t198 = select i1 %t197, i32 1, i32 0
  %t199 = icmp eq i32 %t194, 0
  %t200 = shl i32 %t198, 16
  %t201 = or i32 %t200, %t196
  %t202 = select i1 %t199, i32 0, i32 %t201
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i1, ptr %l4, !tbaa !21
  %t207 = getelementptr %"compiler/parse:Parser", ptr %t203, i32 0, i32 19
  store i1 %t204, ptr %t207, !tbaa !21
  %t209 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t202, 0
  store { i32, { i64, ptr } } %t209, ptr %rv
  br label %ret
bb41:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/parse:Parser", ptr %t210, i32 0, i32 33
  %t213 = load i64, ptr %l2, !tbaa !24
  %t216 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t212, i64 %t213)
  store { i64, ptr } %t216, ptr %l100
  br label %bb42
bb42:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i1, ptr %l4, !tbaa !21
  %t221 = getelementptr %"compiler/parse:Parser", ptr %t217, i32 0, i32 19
  store i1 %t218, ptr %t221, !tbaa !21
  %t222 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t223 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t222, 1
  store { i32, { i64, ptr } } %t223, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i64
  %l73 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i1
  %l86 = alloca i1
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l113 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t34 = alloca { i64, [4 x i64] }, align 8
  %t47 = alloca { i64, [4 x i64] }, align 8
  %t60 = alloca { i64, [4 x i64] }, align 8
  %t88 = alloca { i64, [4 x i64] }, align 8
  %t193 = alloca { i64, [4 x i64] }, align 8
  %t223 = alloca { i64, [4 x i64] }, align 8
  %t238 = alloca { i64, [4 x i64] }, align 8
  %t253 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb14
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l27
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t31, ptr %l28
  br label %bb7
bb7:
  %t32 = load i1, ptr %l28, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t33 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t33, 0
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span" } %t37, ptr %t38
  %t39 = load { i64, [4 x i64] }, ptr %t34
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t39, ptr %t41
  call void @__olang_scope_close(ptr %s1)
  store ptr %t41, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br i1 %a2, label %bb11, label %bb12
bb11:
  %t45 = load %"compiler/source:Span", ptr %l3
  %t46 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 0
  store i64 1, ptr %t48
  %t50 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t45, 0
  %t52 = insertvalue { %"compiler/source:Span", ptr } %t50, ptr %t46, 1
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t52, ptr %t53
  %t54 = load { i64, [4 x i64] }, ptr %t47
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t54, ptr %t56
  call void @__olang_scope_close(ptr %s1)
  store ptr %t56, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t58 = load %"compiler/source:Span", ptr %l3
  %t59 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t60
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 0
  store i64 3, ptr %t61
  %t63 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t58, 0
  %t65 = insertvalue { %"compiler/source:Span", i32 } %t63, i32 %t59, 1
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t65, ptr %t66
  %t67 = load { i64, [4 x i64] }, ptr %t60
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t67, ptr %t69
  call void @__olang_scope_close(ptr %s1)
  store ptr %t69, ptr %rv
  br label %ret
bb14:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load ptr, ptr %l41, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 15
  store i1 %t78, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l42, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t82, i32 0, i32 0
  %t84 = load %"compiler/source:Span", ptr %t83
  store %"compiler/source:Span" %t84, ptr %l5
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t86 = load %"compiler/source:Span", ptr %l5
  %t87 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 0
  store i64 1, ptr %t89
  %t91 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t86, 0
  %t93 = insertvalue { %"compiler/source:Span", ptr } %t91, ptr %t87, 1
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t93, ptr %t94
  %t95 = load { i64, [4 x i64] }, ptr %t88
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t95, ptr %t97
  store ptr %t97, ptr %rv
  br label %ret
bb20:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb21, label %bb22
bb21:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 12
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb23, label %bb24
bb23:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t110, i32 0, i32 0
  %t112 = load %"compiler/source:Span", ptr %t111
  store %"compiler/source:Span" %t112, ptr %l6
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t116, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l7, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t122, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123
  store { i64, ptr } %t124, ptr %l8, !tbaa !27
  br label %bb25
bb24:
  br label %bb52
bb25:
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t128 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t126)
  store i1 %t128, ptr %l62
  br label %bb26
bb26:
  %t129 = load i1, ptr %l62, !tbaa !21
  br i1 %t129, label %bb27, label %bb28
bb27:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/parse:Parser", ptr %t130, i32 0, i32 34
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t132)
  store i64 %t134, ptr %l65
  br label %bb29
bb28:
  br label %bb51
bb29:
  %t135 = load i64, ptr %l65, !tbaa !24
  store i64 %t135, ptr %l9, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t136, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l12, !tbaa !24
  br label %bb30
bb30:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb31, label %bb32
bb31:
  br label %bb49
bb32:
  br label %bb33
bb33:
  %t150 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t150, ptr %l73, !tbaa !27
  %t151 = load i64, ptr %l11, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr ptr, ptr %t154, i64 %t151
  %t156 = load ptr, ptr %t155, !tbaa !39
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t162 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %t158, ptr %t156, i1 false)
  store ptr %t162, ptr %l78
  br label %bb34
bb34:
  %t163 = load ptr, ptr %l78, !tbaa !29
  store ptr %t163, ptr %l14, !tbaa !29
  %t164 = load ptr, ptr %l14, !tbaa !29
  store ptr %t164, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t165 = load ptr, ptr %l79, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb35, label %bb36
bb35:
  %t168 = load ptr, ptr %l79, !tbaa !29
  %t169 = load i64, ptr %t168
  %t171 = icmp eq i64 %t169, 4
  store i1 %t171, ptr %l80, !tbaa !21
  br label %bb36
bb36:
  %t172 = load i1, ptr %l80, !tbaa !21
  br i1 %t172, label %bb37, label %bb38
bb37:
  %t173 = load ptr, ptr %l14, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l15, !tbaa !29
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t179 = load ptr, ptr %l15, !tbaa !29
  %t181 = call i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %t179)
  store i1 %t181, ptr %l86
  br label %bb40
bb40:
  %t182 = load i1, ptr %l86, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/parse:Parser", ptr %t185, i32 0, i32 34
  %t188 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %t187, i64 %t188)
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t191 = load %"compiler/source:Span", ptr %l6
  %t192 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 0
  store i64 4, ptr %t194
  %t196 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t191, 0
  %t198 = insertvalue { %"compiler/source:Span", ptr } %t196, ptr %t192, 1
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t198, ptr %t199
  %t200 = load { i64, [4 x i64] }, ptr %t193
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t200, ptr %t202
  store ptr %t202, ptr %rv
  br label %ret
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/parse:Parser", ptr %t204, i32 0, i32 34
  %t207 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t206, ptr %t207)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t210 = load i64, ptr %l11, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l11, !tbaa !24
  br label %bb30
bb49:
  %t214 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t214, ptr %l100
  %t215 = load ptr, ptr %l7, !tbaa !29
  store ptr %t215, ptr %l101, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/parse:Parser", ptr %t216, i32 0, i32 34
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t218, i64 %t219)
  store { i64, ptr } %t222, ptr %l105
  br label %bb50
bb50:
  store { i64, [4 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 0
  store i64 2, ptr %t224
  %t225 = load %"compiler/source:Span", ptr %l100
  %t226 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t225, 0
  %t227 = load ptr, ptr %l101, !tbaa !29
  %t228 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t226, ptr %t227, 1
  %t229 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t230 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t228, { i64, ptr } %t229, 2
  %t231 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t230, ptr %t231
  %t232 = load { i64, [4 x i64] }, ptr %t223
  %t234 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t232, ptr %t234
  store ptr %t234, ptr %rv
  br label %ret
bb51:
  %t236 = load %"compiler/source:Span", ptr %l6
  %t237 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 0
  store i64 4, ptr %t239
  %t241 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t236, 0
  %t243 = insertvalue { %"compiler/source:Span", ptr } %t241, ptr %t237, 1
  %t244 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t243, ptr %t244
  %t245 = load { i64, [4 x i64] }, ptr %t238
  %t247 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t245, ptr %t247
  store ptr %t247, ptr %rv
  br label %ret
bb52:
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t251 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t249)
  store %"compiler/source:Span" %t251, ptr %l113
  br label %bb53
bb53:
  %t252 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 0
  store i64 4, ptr %t254
  %t255 = load %"compiler/source:Span", ptr %l113
  %t256 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t255, 0
  %t258 = insertvalue { %"compiler/source:Span", ptr } %t256, ptr %t252, 1
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t258, ptr %t259
  %t260 = load { i64, [4 x i64] }, ptr %t253
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t260, ptr %t262
  store ptr %t262, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i1
  %l12 = alloca i32
  %l16 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l40 = alloca i32
  %l42 = alloca i32
  %l43 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i32
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l54 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i32
  %l68 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t36 = alloca { i64, [5 x i64] }, align 8
  %t128 = alloca { i64, [5 x i64] }, align 8
  %t140 = alloca { i64, [5 x i64] }, align 8
  %t180 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 5)
  store i1 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t10)
  store i32 %t12, ptr %l12
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb6, label %ok.14
ok.14:
  br label %bb5
bb4:
  br label %bb11
bb5:
  br label %bb7
bb6:
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, ptr } zeroinitializer, i32 %t23, 0
  store { i32, ptr } %t25, ptr %rv
  br label %ret
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t26)
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l16
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t31, i32 %t32)
  store %"compiler/source:Span" %t35, ptr %l19
  br label %bb10
bb10:
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 1, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l19
  %t39 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t38, 0
  %t41 = insertvalue { %"compiler/source:Span", i32 } %t39, i32 5, 1
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t41, ptr %t42
  %t43 = load { i64, [5 x i64] }, ptr %t36
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t43, ptr %t45
  %t47 = insertvalue { i32, ptr } zeroinitializer, ptr %t45, 1
  store { i32, ptr } %t47, ptr %rv
  br label %ret
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t48, i32 87)
  %t52 = extractvalue { i32, i32 } %t51, 1
  %t53 = extractvalue { i32, i32 } %t51, 0
  store i32 %t53, ptr %l27
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb13, label %ok.55
ok.55:
  store i32 %t52, ptr %l26
  br label %bb12
bb12:
  %t56 = load i32, ptr %l26, !tbaa !23
  store i32 %t56, ptr %l23, !tbaa !23
  br label %bb14
bb13:
  %t57 = load i32, ptr %l27, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  %t67 = insertvalue { i32, ptr } zeroinitializer, i32 %t65, 0
  store { i32, ptr } %t67, ptr %rv
  br label %ret
bb14:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t68)
  store i32 %t70, ptr %l30
  br label %bb15
bb15:
  %t71 = load i32, ptr %l30
  store i32 %t71, ptr %l2
  %t72 = load i32, ptr %l2
  %t74 = trunc i64 52 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb18
bb17:
  %t77 = load i32, ptr %l2
  %t79 = trunc i64 86 to i32
  %t80 = icmp eq i32 %t77, %t79
  store i1 %t80, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t82 = load i1, ptr %l33, !tbaa !21
  br i1 %t82, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb21
bb20:
  %t83 = load i32, ptr %l2
  %t85 = trunc i64 87 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l36, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t89)
  store i32 %t91, ptr %l40
  br label %bb24
bb23:
  br label %bb31
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t92)
  store i32 %t94, ptr %l42
  br label %bb25
bb25:
  %t95 = load i32, ptr %l42, !tbaa !23
  store i32 %t95, ptr %l3, !tbaa !23
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t96)
  %t99 = extractvalue { i32, ptr } %t98, 1
  %t100 = extractvalue { i32, ptr } %t98, 0
  store i32 %t100, ptr %l46
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb27, label %ok.102
ok.102:
  store ptr %t99, ptr %l45
  br label %bb26
bb26:
  %t103 = load ptr, ptr %l45, !tbaa !29
  store ptr %t103, ptr %l43, !tbaa !29
  br label %bb28
bb27:
  %t104 = load i32, ptr %l46, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  %t114 = insertvalue { i32, ptr } zeroinitializer, i32 %t112, 0
  store { i32, ptr } %t114, ptr %rv
  br label %ret
bb28:
  %t115 = load ptr, ptr %l43, !tbaa !29
  store ptr %t115, ptr %l4, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l1, !tbaa !23
  %t120 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t116, i32 %t117)
  store %"compiler/source:Span" %t120, ptr %l50
  br label %bb29
bb29:
  store i32 87, ptr %l51
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l3, !tbaa !23
  %t125 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t121, i32 %t122)
  store %"compiler/source:Span" %t125, ptr %l54
  br label %bb30
bb30:
  %t126 = load i32, ptr %l2
  %t127 = load ptr, ptr %l4, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 0
  store i64 3, ptr %t129
  %t130 = load %"compiler/source:Span", ptr %l54
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t130, 0
  %t133 = insertvalue { %"compiler/source:Span", i32, ptr } %t131, i32 %t126, 1
  %t135 = insertvalue { %"compiler/source:Span", i32, ptr } %t133, ptr %t127, 2
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t135, ptr %t136
  %t137 = load { i64, [5 x i64] }, ptr %t128
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t137, ptr %t139
  store { i64, [5 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 0
  store i64 3, ptr %t141
  %t142 = load %"compiler/source:Span", ptr %l50
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t142, 0
  %t144 = load i32, ptr %l51
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr } %t143, i32 %t144, 1
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } %t145, ptr %t139, 2
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t147, ptr %t148
  %t149 = load { i64, [5 x i64] }, ptr %t140
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t149, ptr %t151
  %t153 = insertvalue { i32, ptr } zeroinitializer, ptr %t151, 1
  store { i32, ptr } %t153, ptr %rv
  br label %ret
bb31:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t154)
  %t157 = extractvalue { i32, ptr } %t156, 1
  %t158 = extractvalue { i32, ptr } %t156, 0
  store i32 %t158, ptr %l64
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb33, label %ok.160
ok.160:
  store ptr %t157, ptr %l63
  br label %bb32
bb32:
  %t161 = load ptr, ptr %l63, !tbaa !29
  store ptr %t161, ptr %l61, !tbaa !29
  br label %bb34
bb33:
  %t162 = load i32, ptr %l64, !tbaa !23
  %t163 = lshr i32 %t162, 16
  %t164 = and i32 %t162, 65535
  %t165 = icmp eq i32 %t163, 1
  %t166 = select i1 %t165, i32 1, i32 0
  %t167 = icmp eq i32 %t162, 0
  %t168 = shl i32 %t166, 16
  %t169 = or i32 %t168, %t164
  %t170 = select i1 %t167, i32 0, i32 %t169
  %t172 = insertvalue { i32, ptr } zeroinitializer, i32 %t170, 0
  store { i32, ptr } %t172, ptr %rv
  br label %ret
bb34:
  %t173 = load ptr, ptr %l61, !tbaa !29
  store ptr %t173, ptr %l5, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l1, !tbaa !23
  %t178 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t174, i32 %t175)
  store %"compiler/source:Span" %t178, ptr %l68
  br label %bb35
bb35:
  %t179 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 0
  store i64 3, ptr %t181
  %t182 = load %"compiler/source:Span", ptr %l68
  %t183 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t182, 0
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } %t183, i32 87, 1
  %t187 = insertvalue { %"compiler/source:Span", i32, ptr } %t185, ptr %t179, 2
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t187, ptr %t188
  %t189 = load { i64, [5 x i64] }, ptr %t180
  %t191 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t189, ptr %t191
  %t193 = insertvalue { i32, ptr } zeroinitializer, ptr %t191, 1
  store { i32, ptr } %t193, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l30 = alloca i64
  %l39 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l60 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1
  %t3 = trunc i64 47 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb95
bb4:
  %t6 = load i32, ptr %l1
  %t8 = trunc i64 48 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 2, ptr %l2, !tbaa !24
  br label %bb95
bb8:
  %t11 = load i32, ptr %l1
  %t13 = trunc i64 46 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 3, ptr %l2, !tbaa !24
  br label %bb95
bb12:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 84 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 44
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb16, label %bb17
bb16:
  store i64 4, ptr %l13, !tbaa !24
  br label %bb18
bb17:
  store i64 6, ptr %l13, !tbaa !24
  br label %bb18
bb18:
  %t26 = load i64, ptr %l13, !tbaa !24
  store i64 %t26, ptr %l2, !tbaa !24
  br label %bb95
bb19:
  %t27 = load i32, ptr %l1
  %t29 = trunc i64 85 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 44
  %t35 = load i1, ptr %t34, !tbaa !21
  br i1 %t35, label %bb23, label %bb24
bb23:
  store i64 5, ptr %l18, !tbaa !24
  br label %bb25
bb24:
  store i64 7, ptr %l18, !tbaa !24
  br label %bb25
bb25:
  %t37 = load i64, ptr %l18, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb95
bb26:
  %t38 = load i32, ptr %l1
  %t40 = trunc i64 83 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 44
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb30, label %bb31
bb30:
  store i64 6, ptr %l23, !tbaa !24
  br label %bb32
bb31:
  store i64 8, ptr %l23, !tbaa !24
  br label %bb32
bb32:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l2, !tbaa !24
  br label %bb95
bb33:
  %t49 = load i32, ptr %l1
  %t51 = trunc i64 75 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  %t54 = load i32, ptr %l1
  %t56 = trunc i64 77 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb42
bb38:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 44
  %t62 = load i1, ptr %t61, !tbaa !21
  br i1 %t62, label %bb39, label %bb40
bb39:
  store i64 7, ptr %l30, !tbaa !24
  br label %bb41
bb40:
  store i64 4, ptr %l30, !tbaa !24
  br label %bb41
bb41:
  %t64 = load i64, ptr %l30, !tbaa !24
  store i64 %t64, ptr %l2, !tbaa !24
  br label %bb95
bb42:
  %t65 = load i32, ptr %l1
  %t67 = trunc i64 27 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb43, label %bb44
bb43:
  br label %bb49
bb44:
  %t70 = load i32, ptr %l1
  %t72 = trunc i64 28 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  %t75 = load i32, ptr %l1
  %t77 = trunc i64 49 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb53
bb49:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 44
  %t83 = load i1, ptr %t82, !tbaa !21
  br i1 %t83, label %bb50, label %bb51
bb50:
  store i64 8, ptr %l39, !tbaa !24
  br label %bb52
bb51:
  store i64 5, ptr %l39, !tbaa !24
  br label %bb52
bb52:
  %t85 = load i64, ptr %l39, !tbaa !24
  store i64 %t85, ptr %l2, !tbaa !24
  br label %bb95
bb53:
  %t86 = load i32, ptr %l1
  %t88 = trunc i64 79 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  %t91 = load i32, ptr %l1
  %t93 = trunc i64 80 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  %t96 = load i32, ptr %l1
  %t98 = trunc i64 81 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb58, label %bb59
bb58:
  br label %bb62
bb59:
  %t101 = load i32, ptr %l1
  %t103 = trunc i64 82 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb69
bb62:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 11
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb63, label %bb64
bb63:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb68
bb64:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 44
  %t114 = load i1, ptr %t113, !tbaa !21
  br i1 %t114, label %bb65, label %bb66
bb65:
  store i64 8, ptr %l53, !tbaa !24
  br label %bb67
bb66:
  store i64 5, ptr %l53, !tbaa !24
  br label %bb67
bb67:
  %t116 = load i64, ptr %l53, !tbaa !24
  store i64 %t116, ptr %l50, !tbaa !24
  br label %bb68
bb68:
  %t117 = load i64, ptr %l50, !tbaa !24
  store i64 %t117, ptr %l2, !tbaa !24
  br label %bb95
bb69:
  %t118 = load i32, ptr %l1
  %t120 = trunc i64 88 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb70, label %bb71
bb70:
  br label %bb74
bb71:
  %t123 = load i32, ptr %l1
  %t125 = trunc i64 89 to i32
  %t126 = icmp eq i32 %t123, %t125
  br i1 %t126, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/parse:Parser", ptr %t128, i32 0, i32 11
  %t131 = load i1, ptr %t130, !tbaa !21
  br i1 %t131, label %bb75, label %bb76
bb75:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb77
bb76:
  store i64 9, ptr %l60, !tbaa !24
  br label %bb77
bb77:
  %t133 = load i64, ptr %l60, !tbaa !24
  store i64 %t133, ptr %l2, !tbaa !24
  br label %bb95
bb78:
  %t134 = load i32, ptr %l1
  %t136 = trunc i64 51 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb79, label %bb80
bb79:
  br label %bb83
bb80:
  %t139 = load i32, ptr %l1
  %t141 = trunc i64 52 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store i64 10, ptr %l2, !tbaa !24
  br label %bb95
bb84:
  %t144 = load i32, ptr %l1
  %t146 = trunc i64 53 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  %t149 = load i32, ptr %l1
  %t151 = trunc i64 54 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb87, label %bb88
bb87:
  br label %bb93
bb88:
  %t154 = load i32, ptr %l1
  %t156 = trunc i64 55 to i32
  %t157 = icmp eq i32 %t154, %t156
  br i1 %t157, label %bb89, label %bb90
bb89:
  br label %bb93
bb90:
  %t159 = load i32, ptr %l1
  %t161 = trunc i64 56 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb94
bb93:
  store i64 11, ptr %l2, !tbaa !24
  br label %bb95
bb94:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb95
bb95:
  %t164 = load i64, ptr %l2, !tbaa !24
  store i64 %t164, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l15 = alloca %"compiler/token:Token"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %lp19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l26 = alloca i32
  %l28 = alloca i32
  %l42 = alloca i32
  %l45 = alloca %"compiler/source:Span"
  %l52 = alloca i32
  %l56 = alloca ptr
  %l65 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l79 = alloca ptr
  %l84 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l96 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l108 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca i32
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l121 = alloca %"compiler/source:Span"
  %l129 = alloca i32
  %l132 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca i32
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i32
  %l145 = alloca %"compiler/source:Span"
  %l148 = alloca %"compiler/source:Span"
  %l149 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l154 = alloca %"compiler/ast:Func"
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca i32
  %l167 = alloca %"compiler/source:Span"
  %l174 = alloca i1
  %l175 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca i32
  %l180 = alloca ptr
  %l184 = alloca ptr
  %l185 = alloca i32
  %l188 = alloca %"compiler/token:Token"
  %l190 = alloca i32
  %l192 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l196 = alloca i32
  %l199 = alloca i1
  %l204 = alloca i1
  %l206 = alloca i32
  %l207 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca i32
  %l214 = alloca %"compiler/source:Span"
  %l217 = alloca %"compiler/source:Span"
  %l223 = alloca ptr
  %l227 = alloca ptr
  %l228 = alloca i32
  %l232 = alloca i1
  %l237 = alloca i1
  %l238 = alloca i1
  %l240 = alloca i1
  %l241 = alloca i1
  %l243 = alloca i1
  %l248 = alloca i1
  %l250 = alloca i1
  %l252 = alloca i1
  %l253 = alloca ptr
  %l255 = alloca %"compiler/token:Token"
  %l256 = alloca i32
  %l258 = alloca %"compiler/token:Token"
  %l259 = alloca i32
  %l262 = alloca { i64, ptr }
  %l263 = alloca %"compiler/msgs:Msg"
  %l265 = alloca i32
  %l266 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca i32
  %l273 = alloca %"compiler/source:Span"
  %l276 = alloca %"compiler/source:Span"
  %l285 = alloca i1
  %l287 = alloca i32
  %l290 = alloca i1
  %l292 = alloca i32
  %l296 = alloca i32
  %l298 = alloca i1
  %l301 = alloca %"compiler/source:Span"
  %l302 = alloca i32
  %l305 = alloca { i64, ptr }
  %l311 = alloca ptr
  %l312 = alloca ptr
  %l313 = alloca i32
  %l317 = alloca ptr
  %l318 = alloca ptr
  %l319 = alloca i32
  %l323 = alloca %"compiler/source:Span"
  %l330 = alloca i32
  %l333 = alloca i1
  %l336 = alloca i1
  %l338 = alloca i32
  %l341 = alloca i1
  %l346 = alloca i1
  %l348 = alloca i32
  %l351 = alloca %"compiler/source:Span"
  %l352 = alloca i32
  %l355 = alloca { i64, ptr }
  %l364 = alloca ptr
  %l365 = alloca ptr
  %l369 = alloca ptr
  %l370 = alloca i32
  %l373 = alloca i32
  %l376 = alloca %"compiler/source:Span"
  %l383 = alloca i32
  %l386 = alloca i32
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t48 = alloca { i64, [5 x i64] }, align 8
  %t177 = alloca { i64, [5 x i64] }, align 8
  %t255 = alloca { i64, [5 x i64] }, align 8
  %t351 = alloca { i64, [5 x i64] }, align 8
  %t394 = alloca { i64, [5 x i64] }, align 8
  %t532 = alloca { i64, [5 x i64] }, align 8
  %t543 = alloca { i64, [5 x i64] }, align 8
  %t682 = alloca { i64, [5 x i64] }, align 8
  %t693 = alloca { i64, [5 x i64] }, align 8
  %t750 = alloca i64
  %t768 = alloca { i64, [5 x i64] }, align 8
  %t818 = alloca { i64, [5 x i64] }, align 8
  %t887 = alloca i64
  %t905 = alloca { i64, [5 x i64] }, align 8
  %t960 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load i32, ptr %l26, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l28
  br label %bb2
bb2:
  %t8 = load i32, ptr %l28
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2
  %t11 = trunc i64 2 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  %t14 = load i32, ptr %l2
  %t16 = trunc i64 3 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  %t19 = load i32, ptr %l2
  %t21 = trunc i64 4 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t24 = load i32, ptr %l2
  %t26 = trunc i64 6 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load i32, ptr %l2
  %t31 = trunc i64 7 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load i32, ptr %l2
  %t36 = trunc i64 5 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l42
  br label %bb16
bb16:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t42, i32 %t43)
  store %"compiler/source:Span" %t46, ptr %l45
  br label %bb17
bb17:
  %t47 = load i32, ptr %l2
  store { i64, [5 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 0
  store i64 1, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l45
  %t51 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t50, 0
  %t53 = insertvalue { %"compiler/source:Span", i32 } %t51, i32 %t47, 1
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t53, ptr %t54
  %t55 = load { i64, [5 x i64] }, ptr %t48
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t55, ptr %t57
  %t59 = insertvalue { i32, ptr } zeroinitializer, ptr %t57, 1
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb18:
  %t60 = load i32, ptr %l2
  %t62 = trunc i64 90 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t65)
  store i32 %t67, ptr %l52
  br label %bb22
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 11
  %t71 = load i1, ptr %t70, !tbaa !21
  store i1 %t71, ptr %l3, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 11
  store i1 false, ptr %t75, !tbaa !21
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l56, !tbaa !29
  %t77 = load ptr, ptr %l56, !tbaa !29
  %t78 = getelementptr %"compiler/parse:Parser", ptr %t77, i32 0, i32 17
  %t79 = load i64, ptr %t78, !tbaa !24
  %t81 = add i64 %t79, 1
  %t83 = load ptr, ptr %l56, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 17
  store i64 %t81, ptr %t84, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 18
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l4, !tbaa !21
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/parse:Parser", ptr %t90, i32 0, i32 19
  %t93 = load i1, ptr %t92, !tbaa !21
  store i1 %t93, ptr %l5, !tbaa !21
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/parse:Parser", ptr %t95, i32 0, i32 18
  store i1 true, ptr %t97, !tbaa !21
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/parse:Parser", ptr %t98, i32 0, i32 19
  store i1 false, ptr %t100, !tbaa !21
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t101)
  %t104 = extractvalue { i32, ptr } %t103, 1
  %t105 = extractvalue { i32, ptr } %t103, 0
  store i32 %t105, ptr %l68
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb24, label %ok.107
ok.107:
  store ptr %t104, ptr %l67
  br label %bb23
bb23:
  %t108 = load ptr, ptr %l67, !tbaa !29
  store ptr %t108, ptr %l65, !tbaa !29
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l69, !tbaa !29
  %t110 = load ptr, ptr %l69, !tbaa !29
  %t111 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 17
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = sub i64 %t112, 1
  %t116 = load ptr, ptr %l69, !tbaa !29
  %t117 = getelementptr %"compiler/parse:Parser", ptr %t116, i32 0, i32 17
  store i64 %t114, ptr %t117, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i1, ptr %l4, !tbaa !21
  %t122 = getelementptr %"compiler/parse:Parser", ptr %t118, i32 0, i32 18
  store i1 %t119, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i1, ptr %l5, !tbaa !21
  %t127 = getelementptr %"compiler/parse:Parser", ptr %t123, i32 0, i32 19
  store i1 %t124, ptr %t127, !tbaa !21
  %t129 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t129, ptr %rv
  br label %ret
bb26:
  %t130 = load ptr, ptr %l65, !tbaa !29
  store ptr %t130, ptr %l6, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i1, ptr %l5, !tbaa !21
  %t135 = getelementptr %"compiler/parse:Parser", ptr %t131, i32 0, i32 19
  store i1 %t132, ptr %t135, !tbaa !21
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l79, !tbaa !29
  %t137 = load ptr, ptr %l79, !tbaa !29
  %t138 = getelementptr %"compiler/parse:Parser", ptr %t137, i32 0, i32 17
  %t139 = load i64, ptr %t138, !tbaa !24
  %t141 = sub i64 %t139, 1
  %t143 = load ptr, ptr %l79, !tbaa !29
  %t144 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 17
  store i64 %t141, ptr %t144, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i1, ptr %l3, !tbaa !21
  %t149 = getelementptr %"compiler/parse:Parser", ptr %t145, i32 0, i32 11
  store i1 %t146, ptr %t149, !tbaa !21
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t153 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t150, i32 91)
  %t154 = extractvalue { i32, i32 } %t153, 1
  %t155 = extractvalue { i32, i32 } %t153, 0
  store i32 %t155, ptr %l88
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb28, label %ok.157
ok.157:
  store i32 %t154, ptr %l87
  br label %bb27
bb27:
  %t158 = load i32, ptr %l87, !tbaa !23
  store i32 %t158, ptr %l84, !tbaa !23
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i1, ptr %l4, !tbaa !21
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 18
  store i1 %t160, ptr %t163, !tbaa !21
  %t165 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb30:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i1, ptr %l4, !tbaa !21
  %t170 = getelementptr %"compiler/parse:Parser", ptr %t166, i32 0, i32 18
  store i1 %t167, ptr %t170, !tbaa !21
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l1, !tbaa !23
  %t175 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t171, i32 %t172)
  store %"compiler/source:Span" %t175, ptr %l96
  br label %bb31
bb31:
  %t176 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 0
  store i64 2, ptr %t178
  %t179 = load %"compiler/source:Span", ptr %l96
  %t180 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t179, 0
  %t182 = insertvalue { %"compiler/source:Span", ptr } %t180, ptr %t176, 1
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t182, ptr %t183
  %t184 = load { i64, [5 x i64] }, ptr %t177
  %t186 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t184, ptr %t186
  %t188 = insertvalue { i32, ptr } zeroinitializer, ptr %t186, 1
  store { i32, ptr } %t188, ptr %rv
  br label %ret
bb32:
  %t189 = load i32, ptr %l2
  %t191 = trunc i64 11 to i32
  %t192 = icmp eq i32 %t189, %t191
  br i1 %t192, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb44
bb35:
  %t194 = load i32, ptr %l1, !tbaa !23
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/parse:Parser", ptr %t195, i32 0, i32 24
  %t198 = load i32, ptr %t197, !tbaa !23
  %t201 = icmp eq i32 %t194, %t198
  store i1 %t201, ptr %l7, !tbaa !21
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t203)
  store i32 %t205, ptr %l107
  br label %bb36
bb36:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t206)
  %t209 = extractvalue { i32, ptr } %t208, 1
  %t210 = extractvalue { i32, ptr } %t208, 0
  store i32 %t210, ptr %l111
  %t211 = icmp ne i32 %t210, 0
  br i1 %t211, label %bb38, label %ok.212
ok.212:
  store ptr %t209, ptr %l110
  br label %bb37
bb37:
  %t213 = load ptr, ptr %l110, !tbaa !29
  store ptr %t213, ptr %l108, !tbaa !29
  br label %bb39
bb38:
  %t214 = load i32, ptr %l111, !tbaa !23
  %t215 = lshr i32 %t214, 16
  %t216 = and i32 %t214, 65535
  %t217 = icmp eq i32 %t215, 1
  %t218 = select i1 %t217, i32 1, i32 0
  %t219 = icmp eq i32 %t214, 0
  %t220 = shl i32 %t218, 16
  %t221 = or i32 %t220, %t216
  %t222 = select i1 %t219, i32 0, i32 %t221
  %t224 = insertvalue { i32, ptr } zeroinitializer, i32 %t222, 0
  store { i32, ptr } %t224, ptr %rv
  br label %ret
bb39:
  %t225 = load ptr, ptr %l108, !tbaa !29
  store ptr %t225, ptr %l8, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i1, ptr %l7, !tbaa !21
  %t230 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t226, i1 %t227)
  %t231 = extractvalue { i32, { i64, ptr } } %t230, 1
  %t232 = extractvalue { i32, { i64, ptr } } %t230, 0
  store i32 %t232, ptr %l117
  %t233 = icmp ne i32 %t232, 0
  br i1 %t233, label %bb41, label %ok.234
ok.234:
  store { i64, ptr } %t231, ptr %l116
  br label %bb40
bb40:
  %t235 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t235, ptr %l113, !tbaa !27
  br label %bb42
bb41:
  %t236 = load i32, ptr %l117, !tbaa !23
  %t237 = lshr i32 %t236, 16
  %t238 = and i32 %t236, 65535
  %t239 = icmp eq i32 %t237, 1
  %t240 = select i1 %t239, i32 1, i32 0
  %t241 = icmp eq i32 %t236, 0
  %t242 = shl i32 %t240, 16
  %t243 = or i32 %t242, %t238
  %t244 = select i1 %t241, i32 0, i32 %t243
  %t246 = insertvalue { i32, ptr } zeroinitializer, i32 %t244, 0
  store { i32, ptr } %t246, ptr %rv
  br label %ret
bb42:
  %t247 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t247, ptr %l9, !tbaa !27
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  %t252 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t248, i32 %t249)
  store %"compiler/source:Span" %t252, ptr %l121
  br label %bb43
bb43:
  %t253 = load ptr, ptr %l8, !tbaa !29
  %t254 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t255
  %t256 = getelementptr { i64, [5 x i64] }, ptr %t255, i32 0, i32 0
  store i64 22, ptr %t256
  %t257 = load %"compiler/source:Span", ptr %l121
  %t258 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t257, 0
  %t260 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t258, ptr %t253, 1
  %t262 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t260, { i64, ptr } %t254, 2
  %t263 = getelementptr { i64, [5 x i64] }, ptr %t255, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t262, ptr %t263
  %t264 = load { i64, [5 x i64] }, ptr %t255
  %t266 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t264, ptr %t266
  %t268 = insertvalue { i32, ptr } zeroinitializer, ptr %t266, 1
  store { i32, ptr } %t268, ptr %rv
  br label %ret
bb44:
  %t269 = load i32, ptr %l2
  %t271 = trunc i64 38 to i32
  %t272 = icmp eq i32 %t269, %t271
  br i1 %t272, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb62
bb47:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t274)
  store i32 %t276, ptr %l129
  br label %bb48
bb48:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t277, i32 0, i32 19
  %t280 = load i1, ptr %t279, !tbaa !21
  store i1 %t280, ptr %l10, !tbaa !21
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t282, i1 true, i1 true, i1 false)
  %t285 = extractvalue { i32, ptr } %t284, 1
  %t286 = extractvalue { i32, ptr } %t284, 0
  store i32 %t286, ptr %l135
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb50, label %ok.288
ok.288:
  store ptr %t285, ptr %l134
  br label %bb49
bb49:
  %t289 = load ptr, ptr %l134, !tbaa !29
  store ptr %t289, ptr %l132, !tbaa !29
  br label %bb51
bb50:
  %t290 = load i32, ptr %l135, !tbaa !23
  %t291 = lshr i32 %t290, 16
  %t292 = and i32 %t290, 65535
  %t293 = icmp eq i32 %t291, 1
  %t294 = select i1 %t293, i32 1, i32 0
  %t295 = icmp eq i32 %t290, 0
  %t296 = shl i32 %t294, 16
  %t297 = or i32 %t296, %t292
  %t298 = select i1 %t295, i32 0, i32 %t297
  %t300 = insertvalue { i32, ptr } zeroinitializer, i32 %t298, 0
  store { i32, ptr } %t300, ptr %rv
  br label %ret
bb51:
  %t301 = load ptr, ptr %l132, !tbaa !29
  store ptr %t301, ptr %l11, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i1, ptr %l10, !tbaa !21
  %t306 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elambdaBody(ptr %v0, ptr %t302, i1 %t303)
  %t307 = extractvalue { i32, { i64, ptr } } %t306, 1
  %t308 = extractvalue { i32, { i64, ptr } } %t306, 0
  store i32 %t308, ptr %l141
  %t309 = icmp ne i32 %t308, 0
  br i1 %t309, label %bb53, label %ok.310
ok.310:
  store { i64, ptr } %t307, ptr %l140
  br label %bb52
bb52:
  %t311 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t311, ptr %l137, !tbaa !27
  br label %bb54
bb53:
  %t312 = load i32, ptr %l141, !tbaa !23
  %t313 = lshr i32 %t312, 16
  %t314 = and i32 %t312, 65535
  %t315 = icmp eq i32 %t313, 1
  %t316 = select i1 %t315, i32 1, i32 0
  %t317 = icmp eq i32 %t312, 0
  %t318 = shl i32 %t316, 16
  %t319 = or i32 %t318, %t314
  %t320 = select i1 %t317, i32 0, i32 %t319
  %t322 = insertvalue { i32, ptr } zeroinitializer, i32 %t320, 0
  store { i32, ptr } %t322, ptr %rv
  br label %ret
bb54:
  %t323 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t323, ptr %l12, !tbaa !27
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l1, !tbaa !23
  %t328 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t324, i32 %t325)
  store %"compiler/source:Span" %t328, ptr %l145
  br label %bb55
bb55:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l1, !tbaa !23
  %t333 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t329, i32 %t330)
  store %"compiler/source:Span" %t333, ptr %l148
  br label %bb56
bb56:
  %t334 = load ptr, ptr %l11, !tbaa !29
  store ptr %t334, ptr %l149, !tbaa !29
  %t335 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t335, ptr %l150, !tbaa !27
  %t336 = icmp sge i64 0, 0
  br i1 %t336, label %bb57, label %bb58
bb57:
  %t338 = icmp sle i64 0, 1152921504606846975
  br i1 %t338, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a)
  unreachable
bb59:
  %t340 = mul i64 0, 8
  %t341 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t340)
  %t342 = insertvalue { i64, ptr } undef, i64 0, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  %t344 = load %"compiler/source:Span", ptr %l148
  %t345 = load ptr, ptr %l149, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t348 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t344, ptr null, i32 0, ptr %t345, { i64, ptr } %t346, { i64, ptr } %t343, i1 true, i1 false)
  store %"compiler/ast:Func" %t348, ptr %l154
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a)
  unreachable
bb61:
  %t349 = load %"compiler/ast:Func", ptr %l154
  %t350 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t349, ptr %t350
  store { i64, [5 x i64] } zeroinitializer, ptr %t351
  %t352 = getelementptr { i64, [5 x i64] }, ptr %t351, i32 0, i32 0
  store i64 23, ptr %t352
  %t353 = load %"compiler/source:Span", ptr %l145
  %t354 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t353, 0
  %t356 = insertvalue { %"compiler/source:Span", ptr } %t354, ptr %t350, 1
  %t357 = getelementptr { i64, [5 x i64] }, ptr %t351, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t356, ptr %t357
  %t358 = load { i64, [5 x i64] }, ptr %t351
  %t360 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t358, ptr %t360
  %t362 = insertvalue { i32, ptr } zeroinitializer, ptr %t360, 1
  store { i32, ptr } %t362, ptr %rv
  br label %ret
bb62:
  %t363 = load i32, ptr %l2
  %t365 = trunc i64 31 to i32
  %t366 = icmp eq i32 %t363, %t365
  br i1 %t366, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb70
bb65:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %t368)
  %t371 = extractvalue { i32, ptr } %t370, 1
  %t372 = extractvalue { i32, ptr } %t370, 0
  store i32 %t372, ptr %l163
  %t373 = icmp ne i32 %t372, 0
  br i1 %t373, label %bb67, label %ok.374
ok.374:
  store ptr %t371, ptr %l162
  br label %bb66
bb66:
  %t375 = load ptr, ptr %l162, !tbaa !29
  store ptr %t375, ptr %l160, !tbaa !29
  br label %bb68
bb67:
  %t376 = load i32, ptr %l163, !tbaa !23
  %t377 = lshr i32 %t376, 16
  %t378 = and i32 %t376, 65535
  %t379 = icmp eq i32 %t377, 1
  %t380 = select i1 %t379, i32 1, i32 0
  %t381 = icmp eq i32 %t376, 0
  %t382 = shl i32 %t380, 16
  %t383 = or i32 %t382, %t378
  %t384 = select i1 %t381, i32 0, i32 %t383
  %t386 = insertvalue { i32, ptr } zeroinitializer, i32 %t384, 0
  store { i32, ptr } %t386, ptr %rv
  br label %ret
bb68:
  %t387 = load ptr, ptr %l160, !tbaa !29
  store ptr %t387, ptr %l13, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load i32, ptr %l1, !tbaa !23
  %t392 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t388, i32 %t389)
  store %"compiler/source:Span" %t392, ptr %l167
  br label %bb69
bb69:
  %t393 = load ptr, ptr %l13, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t394
  %t395 = getelementptr { i64, [5 x i64] }, ptr %t394, i32 0, i32 0
  store i64 24, ptr %t395
  %t396 = load %"compiler/source:Span", ptr %l167
  %t397 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t396, 0
  %t399 = insertvalue { %"compiler/source:Span", ptr } %t397, ptr %t393, 1
  %t400 = getelementptr { i64, [5 x i64] }, ptr %t394, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t399, ptr %t400
  %t401 = load { i64, [5 x i64] }, ptr %t394
  %t403 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t401, ptr %t403
  %t405 = insertvalue { i32, ptr } zeroinitializer, ptr %t403, 1
  store { i32, ptr } %t405, ptr %rv
  br label %ret
bb70:
  %t406 = load i32, ptr %l2
  %t408 = trunc i64 1 to i32
  %t409 = icmp eq i32 %t406, %t408
  br i1 %t409, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb202
bb73:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eanyHere(ptr %v0, ptr %t411)
  store i1 %t413, ptr %l174
  br label %bb74
bb74:
  %t414 = load i1, ptr %l174, !tbaa !21
  br i1 %t414, label %bb75, label %bb76
bb75:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t415)
  %t418 = extractvalue { i32, ptr } %t417, 1
  %t419 = extractvalue { i32, ptr } %t417, 0
  store i32 %t419, ptr %l178
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb78, label %ok.421
ok.421:
  store ptr %t418, ptr %l177
  br label %bb77
bb76:
  br label %bb83
bb77:
  %t422 = load ptr, ptr %l177, !tbaa !29
  store ptr %t422, ptr %l175, !tbaa !29
  br label %bb79
bb78:
  %t423 = load i32, ptr %l178, !tbaa !23
  %t424 = lshr i32 %t423, 16
  %t425 = and i32 %t423, 65535
  %t426 = icmp eq i32 %t424, 1
  %t427 = select i1 %t426, i32 1, i32 0
  %t428 = icmp eq i32 %t423, 0
  %t429 = shl i32 %t427, 16
  %t430 = or i32 %t429, %t425
  %t431 = select i1 %t428, i32 0, i32 %t430
  %t433 = insertvalue { i32, ptr } zeroinitializer, i32 %t431, 0
  store { i32, ptr } %t433, ptr %rv
  br label %ret
bb79:
  %t434 = load ptr, ptr %l175, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load i32, ptr %l1, !tbaa !23
  %t441 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t435, i32 %t436, ptr %t434)
  %t442 = extractvalue { i32, ptr } %t441, 1
  %t443 = extractvalue { i32, ptr } %t441, 0
  store i32 %t443, ptr %l185
  %t444 = icmp ne i32 %t443, 0
  br i1 %t444, label %bb81, label %ok.445
ok.445:
  store ptr %t442, ptr %l184
  br label %bb80
bb80:
  %t446 = load ptr, ptr %l184, !tbaa !29
  store ptr %t446, ptr %l180, !tbaa !29
  br label %bb82
bb81:
  %t447 = load i32, ptr %l185, !tbaa !23
  %t448 = lshr i32 %t447, 16
  %t449 = and i32 %t447, 65535
  %t450 = icmp eq i32 %t448, 1
  %t451 = select i1 %t450, i32 1, i32 0
  %t452 = icmp eq i32 %t447, 0
  %t453 = shl i32 %t451, 16
  %t454 = or i32 %t453, %t449
  %t455 = select i1 %t452, i32 0, i32 %t454
  %t457 = insertvalue { i32, ptr } zeroinitializer, i32 %t455, 0
  store { i32, ptr } %t457, ptr %rv
  br label %ret
bb82:
  %t458 = load ptr, ptr %l180, !tbaa !29
  %t459 = insertvalue { i32, ptr } zeroinitializer, ptr %t458, 1
  store { i32, ptr } %t459, ptr %rv
  br label %ret
bb83:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t460)
  store %"compiler/token:Token" %t462, ptr %l188
  br label %bb84
bb84:
  %t463 = load %"compiler/token:Token", ptr %l188
  store %"compiler/token:Token" %t463, ptr %l15
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t464, i64 1)
  store i32 %t466, ptr %l190
  br label %bb85
bb85:
  %t467 = load i32, ptr %l190
  store i32 %t467, ptr %l16
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/parse:Parser", ptr %t468, i32 0, i32 2
  %t471 = load ptr, ptr %t470, !tbaa !29
  store ptr %t471, ptr %l192, !tbaa !29
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load %"compiler/token:Token", ptr %l15
  %t476 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t472, %"compiler/token:Token" %t473)
  store { i64, ptr } %t476, ptr %l195
  br label %bb86
bb86:
  %t477 = load ptr, ptr %l192, !tbaa !29
  %t478 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t479 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t477, { i64, ptr } %t478)
  store i32 %t479, ptr %l196
  br label %bb87
bb87:
  %t480 = load i32, ptr %l196, !tbaa !23
  store i32 %t480, ptr %l17, !tbaa !23
  %t481 = load i32, ptr %l16
  %t483 = trunc i64 79 to i32
  %t484 = icmp eq i32 %t481, %t483
  br i1 %t484, label %bb88, label %bb89
bb88:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/parse:Parser", ptr %t486, i32 0, i32 3
  %t489 = load ptr, ptr %t488, !tbaa !29
  %t491 = getelementptr %"compiler/parse:Oracle", ptr %t489, i32 0, i32 0
  %t492 = load i32, ptr %l17, !tbaa !23
  %t495 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t491, i32 %t492)
  store i1 %t495, ptr %l204
  br label %bb90
bb89:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb91
bb90:
  %t496 = load i1, ptr %l204, !tbaa !21
  store i1 %t496, ptr %l199, !tbaa !21
  br label %bb91
bb91:
  %t497 = load i1, ptr %l199, !tbaa !21
  br i1 %t497, label %bb92, label %bb93
bb92:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t498)
  store i32 %t500, ptr %l206
  br label %bb94
bb93:
  br label %bb103
bb94:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t501)
  %t504 = extractvalue { i32, { i64, ptr } } %t503, 1
  %t505 = extractvalue { i32, { i64, ptr } } %t503, 0
  store i32 %t505, ptr %l210
  %t506 = icmp ne i32 %t505, 0
  br i1 %t506, label %bb96, label %ok.507
ok.507:
  store { i64, ptr } %t504, ptr %l209
  br label %bb95
bb95:
  %t508 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t508, ptr %l207, !tbaa !27
  br label %bb97
bb96:
  %t509 = load i32, ptr %l210, !tbaa !23
  %t510 = lshr i32 %t509, 16
  %t511 = and i32 %t509, 65535
  %t512 = icmp eq i32 %t510, 1
  %t513 = select i1 %t512, i32 1, i32 0
  %t514 = icmp eq i32 %t509, 0
  %t515 = shl i32 %t513, 16
  %t516 = or i32 %t515, %t511
  %t517 = select i1 %t514, i32 0, i32 %t516
  %t519 = insertvalue { i32, ptr } zeroinitializer, i32 %t517, 0
  store { i32, ptr } %t519, ptr %rv
  br label %ret
bb97:
  %t520 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t520, ptr %l18, !tbaa !27
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load i32, ptr %l1, !tbaa !23
  %t525 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t521, i32 %t522)
  store %"compiler/source:Span" %t525, ptr %l214
  br label %bb98
bb98:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load i32, ptr %l1, !tbaa !23
  %t530 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t526, i32 %t527)
  store %"compiler/source:Span" %t530, ptr %l217
  br label %bb99
bb99:
  %t531 = load i32, ptr %l17, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t532
  %t533 = getelementptr { i64, [5 x i64] }, ptr %t532, i32 0, i32 0
  store i64 0, ptr %t533
  %t534 = load %"compiler/source:Span", ptr %l217
  %t535 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t534, 0
  %t537 = insertvalue { %"compiler/source:Span", i32 } %t535, i32 %t531, 1
  %t538 = getelementptr { i64, [5 x i64] }, ptr %t532, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t537, ptr %t538
  %t539 = load { i64, [5 x i64] }, ptr %t532
  %t541 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t539, ptr %t541
  %t542 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t543
  %t544 = getelementptr { i64, [5 x i64] }, ptr %t543, i32 0, i32 0
  store i64 14, ptr %t544
  %t545 = load %"compiler/source:Span", ptr %l214
  %t546 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t545, 0
  %t548 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t546, ptr %t541, 1
  %t550 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t548, { i64, ptr } %t542, 2
  %t551 = getelementptr { i64, [5 x i64] }, ptr %t543, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t550, ptr %t551
  %t552 = load { i64, [5 x i64] }, ptr %t543
  %t553 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t553, ptr %lp19
  %t555 = load ptr, ptr %lp19
  store { i64, [5 x i64] } %t552, ptr %t555
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load i32, ptr %l1, !tbaa !23
  %t558 = load ptr, ptr %lp19
  %t562 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %t556, i32 %t557, ptr %t558)
  %t563 = extractvalue { i32, ptr } %t562, 1
  %t564 = extractvalue { i32, ptr } %t562, 0
  store i32 %t564, ptr %l228
  %t565 = icmp ne i32 %t564, 0
  br i1 %t565, label %bb101, label %ok.566
ok.566:
  store ptr %t563, ptr %l227
  br label %bb100
bb100:
  %t567 = load ptr, ptr %l227, !tbaa !29
  store ptr %t567, ptr %l223, !tbaa !29
  br label %bb102
bb101:
  %t568 = load i32, ptr %l228, !tbaa !23
  %t569 = lshr i32 %t568, 16
  %t570 = and i32 %t568, 65535
  %t571 = icmp eq i32 %t569, 1
  %t572 = select i1 %t571, i32 1, i32 0
  %t573 = icmp eq i32 %t568, 0
  %t574 = shl i32 %t572, 16
  %t575 = or i32 %t574, %t570
  %t576 = select i1 %t573, i32 0, i32 %t575
  %t578 = insertvalue { i32, ptr } zeroinitializer, i32 %t576, 0
  store { i32, ptr } %t578, ptr %rv
  br label %ret
bb102:
  %t579 = load ptr, ptr %l223, !tbaa !29
  %t580 = insertvalue { i32, ptr } zeroinitializer, ptr %t579, 1
  store { i32, ptr } %t580, ptr %rv
  br label %ret
bb103:
  %t581 = load i32, ptr %l16
  %t583 = trunc i64 79 to i32
  %t584 = icmp eq i32 %t581, %t583
  br i1 %t584, label %bb104, label %bb105
bb104:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t588 = getelementptr %"compiler/parse:Parser", ptr %t586, i32 0, i32 3
  %t589 = load ptr, ptr %t588, !tbaa !29
  %t591 = getelementptr %"compiler/parse:Oracle", ptr %t589, i32 0, i32 2
  %t592 = load i32, ptr %l17, !tbaa !23
  %t595 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t591, i32 %t592)
  store i1 %t595, ptr %l237
  br label %bb106
bb105:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb115
bb106:
  %t596 = load i1, ptr %l237, !tbaa !21
  br i1 %t596, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l238, !tbaa !21
  br label %bb110
bb108:
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %t597, i64 1)
  store i1 %t599, ptr %l240
  br label %bb109
bb109:
  %t600 = load i1, ptr %l240, !tbaa !21
  store i1 %t600, ptr %l238, !tbaa !21
  br label %bb110
bb110:
  %t601 = load i1, ptr %l238, !tbaa !21
  br i1 %t601, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l241, !tbaa !21
  br label %bb114
bb112:
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t604 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t602, i64 1)
  store i1 %t604, ptr %l243
  br label %bb113
bb113:
  %t605 = load i1, ptr %l243, !tbaa !21
  store i1 %t605, ptr %l241, !tbaa !21
  br label %bb114
bb114:
  %t606 = load i1, ptr %l241, !tbaa !21
  store i1 %t606, ptr %l232, !tbaa !21
  br label %bb115
bb115:
  %t607 = load i1, ptr %l232, !tbaa !21
  br i1 %t607, label %bb116, label %bb117
bb116:
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/parse:Parser", ptr %t608, i32 0, i32 3
  %t611 = load ptr, ptr %t610, !tbaa !29
  %t613 = getelementptr %"compiler/parse:Oracle", ptr %t611, i32 0, i32 2
  %t614 = load i32, ptr %l17, !tbaa !23
  %t617 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t613, i32 %t614)
  store i1 %t617, ptr %l248
  br label %bb118
bb117:
  br label %bb137
bb118:
  %t618 = load i1, ptr %l248, !tbaa !21
  %t619 = xor i1 %t618, true
  br i1 %t619, label %bb119, label %bb120
bb119:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t621, i64 1)
  store i1 %t623, ptr %l252
  br label %bb121
bb120:
  store i1 false, ptr %l250, !tbaa !21
  br label %bb122
bb121:
  %t624 = load i1, ptr %l252, !tbaa !21
  store i1 %t624, ptr %l250, !tbaa !21
  br label %bb122
bb122:
  %t625 = load i1, ptr %l250, !tbaa !21
  br i1 %t625, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s12
  %t626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t626, ptr %l253, !tbaa !29
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t627, i64 1)
  store %"compiler/token:Token" %t629, ptr %l255
  br label %bb125
bb124:
  br label %bb130
bb125:
  %t630 = getelementptr %"compiler/token:Token", ptr %l255, i32 0, i32 2
  %t631 = load i32, ptr %t630, !tbaa !23
  store i32 %t631, ptr %l256, !tbaa !23
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t634 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t632, i64 1)
  store %"compiler/token:Token" %t634, ptr %l258
  br label %bb126
bb126:
  %t635 = getelementptr %"compiler/token:Token", ptr %l258, i32 0, i32 3
  %t636 = load i32, ptr %t635, !tbaa !23
  store i32 %t636, ptr %l259, !tbaa !23
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load %"compiler/token:Token", ptr %l15
  %t641 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t637, %"compiler/token:Token" %t638)
  store { i64, ptr } %t641, ptr %l262
  br label %bb127
bb127:
  %t642 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t643 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %s12, { i64, ptr } %t642)
  store %"compiler/msgs:Msg" %t643, ptr %l263
  br label %bb128
bb128:
  %t644 = load ptr, ptr %l253, !tbaa !29
  %t645 = load i32, ptr %l256, !tbaa !23
  %t646 = load i32, ptr %l259, !tbaa !23
  %t647 = load %"compiler/msgs:Msg", ptr %l263
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s12, ptr %t644, i32 %t645, i32 %t646, %"compiler/msgs:Msg" %t647)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s12)
  br label %bb130
bb130:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t650 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t648)
  store i32 %t650, ptr %l265
  br label %bb131
bb131:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t651)
  %t654 = extractvalue { i32, { i64, ptr } } %t653, 1
  %t655 = extractvalue { i32, { i64, ptr } } %t653, 0
  store i32 %t655, ptr %l269
  %t656 = icmp ne i32 %t655, 0
  br i1 %t656, label %bb133, label %ok.657
ok.657:
  store { i64, ptr } %t654, ptr %l268
  br label %bb132
bb132:
  %t658 = load { i64, ptr }, ptr %l268, !tbaa !27
  store { i64, ptr } %t658, ptr %l266, !tbaa !27
  br label %bb134
bb133:
  %t659 = load i32, ptr %l269, !tbaa !23
  %t660 = lshr i32 %t659, 16
  %t661 = and i32 %t659, 65535
  %t662 = icmp eq i32 %t660, 1
  %t663 = select i1 %t662, i32 1, i32 0
  %t664 = icmp eq i32 %t659, 0
  %t665 = shl i32 %t663, 16
  %t666 = or i32 %t665, %t661
  %t667 = select i1 %t664, i32 0, i32 %t666
  %t669 = insertvalue { i32, ptr } zeroinitializer, i32 %t667, 0
  store { i32, ptr } %t669, ptr %rv
  br label %ret
bb134:
  %t670 = load { i64, ptr }, ptr %l266, !tbaa !27
  store { i64, ptr } %t670, ptr %l20, !tbaa !27
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load i32, ptr %l1, !tbaa !23
  %t675 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t671, i32 %t672)
  store %"compiler/source:Span" %t675, ptr %l273
  br label %bb135
bb135:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load i32, ptr %l1, !tbaa !23
  %t680 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t676, i32 %t677)
  store %"compiler/source:Span" %t680, ptr %l276
  br label %bb136
bb136:
  %t681 = load i32, ptr %l17, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t682
  %t683 = getelementptr { i64, [5 x i64] }, ptr %t682, i32 0, i32 0
  store i64 0, ptr %t683
  %t684 = load %"compiler/source:Span", ptr %l276
  %t685 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t684, 0
  %t687 = insertvalue { %"compiler/source:Span", i32 } %t685, i32 %t681, 1
  %t688 = getelementptr { i64, [5 x i64] }, ptr %t682, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t687, ptr %t688
  %t689 = load { i64, [5 x i64] }, ptr %t682
  %t691 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t689, ptr %t691
  %t692 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t693
  %t694 = getelementptr { i64, [5 x i64] }, ptr %t693, i32 0, i32 0
  store i64 14, ptr %t694
  %t695 = load %"compiler/source:Span", ptr %l273
  %t696 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t695, 0
  %t698 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t696, ptr %t691, 1
  %t700 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t698, { i64, ptr } %t692, 2
  %t701 = getelementptr { i64, [5 x i64] }, ptr %t693, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t700, ptr %t701
  %t702 = load { i64, [5 x i64] }, ptr %t693
  %t704 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t702, ptr %t704
  %t706 = insertvalue { i32, ptr } zeroinitializer, ptr %t704, 1
  store { i32, ptr } %t706, ptr %rv
  br label %ret
bb137:
  %t707 = load i32, ptr %l16
  %t709 = trunc i64 59 to i32
  %t710 = icmp eq i32 %t707, %t709
  br i1 %t710, label %bb138, label %bb139
bb138:
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t714 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t712, i64 2)
  store i32 %t714, ptr %l287
  br label %bb140
bb139:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb141
bb140:
  %t715 = load i32, ptr %l287
  %t717 = trunc i64 83 to i32
  %t718 = icmp eq i32 %t715, %t717
  store i1 %t718, ptr %l285, !tbaa !21
  br label %bb141
bb141:
  %t720 = load i1, ptr %l285, !tbaa !21
  br i1 %t720, label %bb142, label %bb143
bb142:
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t723 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t721, i64 3)
  store i32 %t723, ptr %l292
  br label %bb144
bb143:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb145
bb144:
  %t724 = load i32, ptr %l292
  %t726 = trunc i64 92 to i32
  %t727 = icmp eq i32 %t724, %t726
  store i1 %t727, ptr %l290, !tbaa !21
  br label %bb145
bb145:
  %t729 = load i1, ptr %l290, !tbaa !21
  br i1 %t729, label %bb146, label %bb147
bb146:
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t732 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t730)
  store i32 %t732, ptr %l296
  br label %bb148
bb147:
  br label %bb167
bb148:
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t735 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t733)
  store i1 %t735, ptr %l298
  br label %bb149
bb149:
  %t736 = load i1, ptr %l298, !tbaa !21
  br i1 %t736, label %bb150, label %bb151
bb150:
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t738 = load i32, ptr %l1, !tbaa !23
  %t741 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t737, i32 %t738)
  store %"compiler/source:Span" %t741, ptr %l301
  br label %bb152
bb151:
  br label %bb165
bb152:
  %t742 = load i32, ptr %l17, !tbaa !23
  store i32 %t742, ptr %l302, !tbaa !23
  %t743 = icmp sge i64 1, 0
  br i1 %t743, label %bb153, label %bb154
bb153:
  %t745 = icmp sle i64 1, 2305843009213693951
  br i1 %t745, label %bb155, label %bb156
bb154:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb155:
  %t747 = mul i64 1, 4
  %t748 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t747)
  %t749 = load i32, ptr %l302, !tbaa !23
  store i64 0, ptr %t750
  br label %fill.751
fill.751:
  %t754 = load i64, ptr %t750
  %t755 = icmp slt i64 %t754, 1
  br i1 %t755, label %fillb.752, label %filld.753
fillb.752:
  %t756 = getelementptr i32, ptr %t748, i64 %t754
  store i32 %t749, ptr %t756
  %t757 = add i64 %t754, 1
  store i64 %t757, ptr %t750
  br label %fill.751
filld.753:
  %t758 = insertvalue { i64, ptr } undef, i64 1, 0
  %t759 = insertvalue { i64, ptr } %t758, ptr %t748, 1
  store { i64, ptr } %t759, ptr %l305, !tbaa !27
  %t760 = icmp sge i64 0, 0
  br i1 %t760, label %bb157, label %bb158
bb156:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb157:
  %t762 = icmp sle i64 0, 1152921504606846975
  br i1 %t762, label %bb159, label %bb160
bb158:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb159:
  %t764 = mul i64 0, 8
  %t765 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t764)
  %t766 = insertvalue { i64, ptr } undef, i64 0, 0
  %t767 = insertvalue { i64, ptr } %t766, ptr %t765, 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t768
  %t769 = getelementptr { i64, [5 x i64] }, ptr %t768, i32 0, i32 0
  store i64 0, ptr %t769
  %t770 = load %"compiler/source:Span", ptr %l301
  %t771 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t770, 0
  %t772 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t773 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t771, { i64, ptr } %t772, 1
  %t775 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t773, { i64, ptr } %t767, 2
  %t776 = getelementptr { i64, [5 x i64] }, ptr %t768, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t775, ptr %t776
  %t777 = load { i64, [5 x i64] }, ptr %t768
  %t779 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t777, ptr %t779
  %t781 = load ptr, ptr %l0, !tbaa !29
  store ptr %t781, ptr %l312, !tbaa !29
  %t782 = load i32, ptr %l1, !tbaa !23
  store i32 %t782, ptr %l313, !tbaa !23
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load i32, ptr %l1, !tbaa !23
  %t789 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t783, i32 %t784, ptr %t779)
  store ptr %t789, ptr %l317
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb161:
  %t790 = load ptr, ptr %l312, !tbaa !29
  %t791 = load i32, ptr %l313, !tbaa !23
  %t792 = load ptr, ptr %l317, !tbaa !29
  %t793 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t790, i32 %t791, ptr %t792)
  %t794 = extractvalue { i32, ptr } %t793, 1
  %t795 = extractvalue { i32, ptr } %t793, 0
  store i32 %t795, ptr %l319
  %t796 = icmp ne i32 %t795, 0
  br i1 %t796, label %bb163, label %ok.797
ok.797:
  store ptr %t794, ptr %l318
  br label %bb162
bb162:
  %t798 = load ptr, ptr %l318, !tbaa !29
  store ptr %t798, ptr %l311, !tbaa !29
  br label %bb164
bb163:
  %t799 = load i32, ptr %l319, !tbaa !23
  %t800 = lshr i32 %t799, 16
  %t801 = and i32 %t799, 65535
  %t802 = icmp eq i32 %t800, 1
  %t803 = select i1 %t802, i32 1, i32 0
  %t804 = icmp eq i32 %t799, 0
  %t805 = shl i32 %t803, 16
  %t806 = or i32 %t805, %t801
  %t807 = select i1 %t804, i32 0, i32 %t806
  %t809 = insertvalue { i32, ptr } zeroinitializer, i32 %t807, 0
  store { i32, ptr } %t809, ptr %rv
  br label %ret
bb164:
  %t810 = load ptr, ptr %l311, !tbaa !29
  %t811 = insertvalue { i32, ptr } zeroinitializer, ptr %t810, 1
  store { i32, ptr } %t811, ptr %rv
  br label %ret
bb165:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load i32, ptr %l1, !tbaa !23
  %t816 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t812, i32 %t813)
  store %"compiler/source:Span" %t816, ptr %l323
  br label %bb166
bb166:
  %t817 = load i32, ptr %l17, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t818
  %t819 = getelementptr { i64, [5 x i64] }, ptr %t818, i32 0, i32 0
  store i64 0, ptr %t819
  %t820 = load %"compiler/source:Span", ptr %l323
  %t821 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t820, 0
  %t823 = insertvalue { %"compiler/source:Span", i32 } %t821, i32 %t817, 1
  %t824 = getelementptr { i64, [5 x i64] }, ptr %t818, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t823, ptr %t824
  %t825 = load { i64, [5 x i64] }, ptr %t818
  %t827 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t825, ptr %t827
  %t829 = insertvalue { i32, ptr } zeroinitializer, ptr %t827, 1
  store { i32, ptr } %t829, ptr %rv
  br label %ret
bb167:
  %t830 = load i32, ptr %l16
  %t832 = trunc i64 83 to i32
  %t833 = icmp eq i32 %t830, %t832
  br i1 %t833, label %bb168, label %bb169
bb168:
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t837 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t835, i64 2)
  store i32 %t837, ptr %l330
  br label %bb170
bb169:
  br label %bb199
bb170:
  %t838 = load i32, ptr %l330
  store i32 %t838, ptr %l22
  %t839 = load i32, ptr %l22
  %t841 = trunc i64 92 to i32
  %t842 = icmp eq i32 %t839, %t841
  br i1 %t842, label %bb171, label %bb172
bb171:
  store i1 true, ptr %l333, !tbaa !21
  br label %bb181
bb172:
  %t844 = load i32, ptr %l22
  %t846 = trunc i64 1 to i32
  %t847 = icmp eq i32 %t844, %t846
  br i1 %t847, label %bb173, label %bb174
bb173:
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t851 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t849, i64 3)
  store i32 %t851, ptr %l338
  br label %bb175
bb174:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb176
bb175:
  %t852 = load i32, ptr %l338
  %t854 = trunc i64 92 to i32
  %t855 = icmp eq i32 %t852, %t854
  store i1 %t855, ptr %l336, !tbaa !21
  br label %bb176
bb176:
  %t857 = load i1, ptr %l336, !tbaa !21
  br i1 %t857, label %bb177, label %bb178
bb177:
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t860 = getelementptr %"compiler/parse:Parser", ptr %t858, i32 0, i32 3
  %t861 = load ptr, ptr %t860, !tbaa !29
  %t863 = getelementptr %"compiler/parse:Oracle", ptr %t861, i32 0, i32 0
  %t864 = load i32, ptr %l17, !tbaa !23
  %t867 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t863, i32 %t864)
  store i1 %t867, ptr %l346
  br label %bb179
bb178:
  store i1 false, ptr %l341, !tbaa !21
  br label %bb180
bb179:
  %t868 = load i1, ptr %l346, !tbaa !21
  store i1 %t868, ptr %l341, !tbaa !21
  br label %bb180
bb180:
  %t869 = load i1, ptr %l341, !tbaa !21
  store i1 %t869, ptr %l333, !tbaa !21
  br label %bb181
bb181:
  %t870 = load i1, ptr %l333, !tbaa !21
  br i1 %t870, label %bb182, label %bb183
bb182:
  %t871 = load ptr, ptr %l0, !tbaa !29
  %t873 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t871)
  store i32 %t873, ptr %l348
  br label %bb184
bb183:
  br label %bb198
bb184:
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t875 = load i32, ptr %l1, !tbaa !23
  %t878 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t874, i32 %t875)
  store %"compiler/source:Span" %t878, ptr %l351
  br label %bb185
bb185:
  %t879 = load i32, ptr %l17, !tbaa !23
  store i32 %t879, ptr %l352, !tbaa !23
  %t880 = icmp sge i64 1, 0
  br i1 %t880, label %bb186, label %bb187
bb186:
  %t882 = icmp sle i64 1, 2305843009213693951
  br i1 %t882, label %bb188, label %bb189
bb187:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb188:
  %t884 = mul i64 1, 4
  %t885 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t884)
  %t886 = load i32, ptr %l352, !tbaa !23
  store i64 0, ptr %t887
  br label %fill.888
fill.888:
  %t891 = load i64, ptr %t887
  %t892 = icmp slt i64 %t891, 1
  br i1 %t892, label %fillb.889, label %filld.890
fillb.889:
  %t893 = getelementptr i32, ptr %t885, i64 %t891
  store i32 %t886, ptr %t893
  %t894 = add i64 %t891, 1
  store i64 %t894, ptr %t887
  br label %fill.888
filld.890:
  %t895 = insertvalue { i64, ptr } undef, i64 1, 0
  %t896 = insertvalue { i64, ptr } %t895, ptr %t885, 1
  store { i64, ptr } %t896, ptr %l355, !tbaa !27
  %t897 = icmp sge i64 0, 0
  br i1 %t897, label %bb190, label %bb191
bb189:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb190:
  %t899 = icmp sle i64 0, 1152921504606846975
  br i1 %t899, label %bb192, label %bb193
bb191:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb192:
  %t901 = mul i64 0, 8
  %t902 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t901)
  %t903 = insertvalue { i64, ptr } undef, i64 0, 0
  %t904 = insertvalue { i64, ptr } %t903, ptr %t902, 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t905
  %t906 = getelementptr { i64, [5 x i64] }, ptr %t905, i32 0, i32 0
  store i64 0, ptr %t906
  %t907 = load %"compiler/source:Span", ptr %l351
  %t908 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t907, 0
  %t909 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t910 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t908, { i64, ptr } %t909, 1
  %t912 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t910, { i64, ptr } %t904, 2
  %t913 = getelementptr { i64, [5 x i64] }, ptr %t905, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t912, ptr %t913
  %t914 = load { i64, [5 x i64] }, ptr %t905
  %t916 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t914, ptr %t916
  %t918 = load ptr, ptr %l0, !tbaa !29
  %t919 = load i32, ptr %l1, !tbaa !23
  %t924 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t918, i32 %t919, ptr %t916)
  store ptr %t924, ptr %l364
  br label %bb194
bb193:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb194:
  %t925 = load ptr, ptr %l364, !tbaa !29
  %t926 = load ptr, ptr %l0, !tbaa !29
  %t927 = load i32, ptr %l1, !tbaa !23
  %t932 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t926, i32 %t927, ptr %t925)
  %t933 = extractvalue { i32, ptr } %t932, 1
  %t934 = extractvalue { i32, ptr } %t932, 0
  store i32 %t934, ptr %l370
  %t935 = icmp ne i32 %t934, 0
  br i1 %t935, label %bb196, label %ok.936
ok.936:
  store ptr %t933, ptr %l369
  br label %bb195
bb195:
  %t937 = load ptr, ptr %l369, !tbaa !29
  store ptr %t937, ptr %l365, !tbaa !29
  br label %bb197
bb196:
  %t938 = load i32, ptr %l370, !tbaa !23
  %t939 = lshr i32 %t938, 16
  %t940 = and i32 %t938, 65535
  %t941 = icmp eq i32 %t939, 1
  %t942 = select i1 %t941, i32 1, i32 0
  %t943 = icmp eq i32 %t938, 0
  %t944 = shl i32 %t942, 16
  %t945 = or i32 %t944, %t940
  %t946 = select i1 %t943, i32 0, i32 %t945
  %t948 = insertvalue { i32, ptr } zeroinitializer, i32 %t946, 0
  store { i32, ptr } %t948, ptr %rv
  br label %ret
bb197:
  %t949 = load ptr, ptr %l365, !tbaa !29
  %t950 = insertvalue { i32, ptr } zeroinitializer, ptr %t949, 1
  store { i32, ptr } %t950, ptr %rv
  br label %ret
bb198:
  br label %bb199
bb199:
  %t951 = load ptr, ptr %l0, !tbaa !29
  %t953 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t951)
  store i32 %t953, ptr %l373
  br label %bb200
bb200:
  %t954 = load ptr, ptr %l0, !tbaa !29
  %t955 = load i32, ptr %l1, !tbaa !23
  %t958 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t954, i32 %t955)
  store %"compiler/source:Span" %t958, ptr %l376
  br label %bb201
bb201:
  %t959 = load i32, ptr %l17, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t960
  %t961 = getelementptr { i64, [5 x i64] }, ptr %t960, i32 0, i32 0
  store i64 0, ptr %t961
  %t962 = load %"compiler/source:Span", ptr %l376
  %t963 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t962, 0
  %t965 = insertvalue { %"compiler/source:Span", i32 } %t963, i32 %t959, 1
  %t966 = getelementptr { i64, [5 x i64] }, ptr %t960, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t965, ptr %t966
  %t967 = load { i64, [5 x i64] }, ptr %t960
  %t969 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t967, ptr %t969
  %t971 = insertvalue { i32, ptr } zeroinitializer, ptr %t969, 1
  store { i32, ptr } %t971, ptr %rv
  br label %ret
bb202:
  %t972 = load i32, ptr %l2
  %t974 = trunc i64 92 to i32
  %t975 = icmp eq i32 %t972, %t974
  br i1 %t975, label %bb203, label %bb204
bb203:
  br label %bb205
bb204:
  br label %bb209
bb205:
  store %olang.scope zeroinitializer, ptr %s17
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t979 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s17, ptr %t977, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i32 %t979, ptr %l383
  %t980 = icmp ne i32 %t979, 0
  br i1 %t980, label %bb207, label %ok.981
ok.981:
  br label %bb206
bb206:
  br label %bb208
bb207:
  %t982 = load i32, ptr %l383, !tbaa !23
  %t983 = lshr i32 %t982, 16
  %t984 = and i32 %t982, 65535
  %t985 = icmp eq i32 %t983, 1
  %t986 = select i1 %t985, i32 1, i32 0
  %t987 = icmp eq i32 %t982, 0
  %t988 = shl i32 %t986, 16
  %t989 = or i32 %t988, %t984
  %t990 = select i1 %t987, i32 0, i32 %t989
  call void @__olang_scope_close(ptr %s17)
  %t992 = insertvalue { i32, ptr } zeroinitializer, i32 %t990, 0
  store { i32, ptr } %t992, ptr %rv
  br label %ret
bb208:
  call void @__olang_scope_close(ptr %s17)
  br label %bb213
bb209:
  store %olang.scope zeroinitializer, ptr %s18
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t995 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s18, ptr %t993, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i32 %t995, ptr %l386
  %t996 = icmp ne i32 %t995, 0
  br i1 %t996, label %bb211, label %ok.997
ok.997:
  br label %bb210
bb210:
  br label %bb212
bb211:
  %t998 = load i32, ptr %l386, !tbaa !23
  %t999 = lshr i32 %t998, 16
  %t1000 = and i32 %t998, 65535
  %t1001 = icmp eq i32 %t999, 1
  %t1002 = select i1 %t1001, i32 1, i32 0
  %t1003 = icmp eq i32 %t998, 0
  %t1004 = shl i32 %t1002, 16
  %t1005 = or i32 %t1004, %t1000
  %t1006 = select i1 %t1003, i32 0, i32 %t1005
  call void @__olang_scope_close(ptr %s18)
  %t1008 = insertvalue { i32, ptr } zeroinitializer, i32 %t1006, 0
  store { i32, ptr } %t1008, ptr %rv
  br label %ret
bb212:
  call void @__olang_scope_close(ptr %s18)
  br label %bb213
bb213:
  call void @__olang_check_failed(ptr @olang_loc_c608f7f9cf1bb136_7782a31fde86d192)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereflListPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb20
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l13
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t25, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t27, ptr %l15
  br label %bb7
bb7:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb9:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t29, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t31, ptr %l18
  br label %bb10
bb10:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb15
bb13:
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t34, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t36, ptr %l21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb15
bb15:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb19
bb17:
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t39, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t41, ptr %l24
  br label %bb18
bb18:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t43 = load i1, ptr %l22, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
bb20:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/msgs:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l14 = alloca i64
  %l18 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i64
  %t15 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 4
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 5
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i32, ptr %l1, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t14 = sext i32 %a2 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 0
  store i64 3, ptr %t16
  %t18 = insertvalue { i64, i64, i64 } undef, i64 %t8, 0
  %t20 = insertvalue { i64, i64, i64 } %t18, i64 %t11, 1
  %t22 = insertvalue { i64, i64, i64 } %t20, i64 %t14, 2
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  store { i64, i64, i64 } %t22, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t15
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t4, { i64, [3 x i64] } %t24, %"compiler/msgs:Msg" %a3)
  store i64 %t29, ptr %l14
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 27
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eHas_3cI32_2c_20I64_3e(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l18
  br label %bb2
bb2:
  %t37 = load i1, ptr %l18, !tbaa !21
  %t38 = xor i1 %t37, true
  br i1 %t38, label %bb3, label %bb4
bb3:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 27
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  store i32 %t43, ptr %l22, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 25
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l25
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = sub i64 %t49, 1
  %t51 = load ptr, ptr %l21, !tbaa !29
  %t52 = load i32, ptr %l22, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %t51, i32 %t52, i64 %t50)
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2escopeDecl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca %"compiler/token:Token"
  %l7 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l14 = alloca %"compiler/token:Token"
  %l16 = alloca i1
  %l18 = alloca %"compiler/token:Token"
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l31 = alloca %"compiler/token:Token"
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i32
  %l39 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t11, i32 83)
  store i1 %t14, ptr %l10
  br label %bb3
bb3:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb9
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t19)
  store %"compiler/token:Token" %t21, ptr %l14
  br label %bb7
bb7:
  %t22 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t23 = load %"compiler/token:Token", ptr %l14
  %t25 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t23, i8 %t22)
  store i1 %t25, ptr %l16
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t28, i64 1)
  store %"compiler/token:Token" %t30, ptr %l18
  br label %bb13
bb13:
  %t31 = load %"compiler/token:Token", ptr %l18
  store %"compiler/token:Token" %t31, ptr %l1
  %t32 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t33 = load i32, ptr %t32
  %t35 = trunc i64 1 to i32
  %t36 = icmp eq i32 %t33, %t35
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb14, label %bb15
bb14:
  %t40 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t43 = trunc i64 13 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l22, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb20
bb18:
  %t49 = load %"compiler/token:Token", ptr %l1
  %t50 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t53 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t49, i8 %t50)
  store i1 %t53, ptr %l29
  br label %bb19
bb19:
  %t54 = load i1, ptr %l29, !tbaa !21
  store i1 %t54, ptr %l26, !tbaa !21
  br label %bb20
bb20:
  %t55 = load i1, ptr %l26, !tbaa !21
  br i1 %t55, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t56)
  store %"compiler/token:Token" %t58, ptr %l31
  br label %bb24
bb24:
  %t59 = load %"compiler/token:Token", ptr %l31
  store %"compiler/token:Token" %t59, ptr %l2
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  store i32 %t62, ptr %l33, !tbaa !23
  %t63 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l34, !tbaa !23
  %t65 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeDecl(ptr %s0)
  store %"compiler/msgs:Msg" %t65, ptr %l35
  br label %bb25
bb25:
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load i32, ptr %l33, !tbaa !23
  %t68 = load i32, ptr %l34, !tbaa !23
  %t69 = load %"compiler/msgs:Msg", ptr %l35
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s0, ptr %t66, i32 %t67, i32 %t68, %"compiler/msgs:Msg" %t69)
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t70)
  store i32 %t72, ptr %l37
  br label %bb27
bb27:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l39
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  store i32 %a1, ptr %l5
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l3, ptr %l5)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i32
  %l12 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 57)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etrailing(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l8
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  br label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb6
bb5:
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, i1 } zeroinitializer, i32 %t21, 0
  store { i32, i1 } %t23, ptr %rv
  br label %ret
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l12
  br label %bb7
bb7:
  %t29 = load i1, ptr %l12, !tbaa !21
  %t30 = xor i1 %t29, true
  %t32 = insertvalue { i32, i1 } zeroinitializer, i1 %t30, 1
  store { i32, i1 } %t32, ptr %rv
  br label %ret
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t33, i32 8)
  store i1 %t36, ptr %l16
  br label %bb9
bb9:
  %t37 = load i1, ptr %l16, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t38)
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l1
  %t44 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l20
  br label %bb13
bb13:
  %t45 = load i1, ptr %l20, !tbaa !21
  %t46 = xor i1 %t45, true
  %t48 = insertvalue { i32, i1 } zeroinitializer, i1 %t46, 1
  store { i32, i1 } %t48, ptr %rv
  br label %ret
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t49, i32 0, i32 9
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l2
  %t54 = load i32, ptr %l2
  %t56 = trunc i64 95 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  %t59 = load i32, ptr %l2
  %t61 = trunc i64 81 to i32
  %t62 = icmp eq i32 %t59, %t61
  store i1 %t62, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t64 = load i1, ptr %l26, !tbaa !21
  br i1 %t64, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  %t65 = load i32, ptr %l2
  %t67 = trunc i64 83 to i32
  %t68 = icmp eq i32 %t65, %t67
  store i1 %t68, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l29, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t71)
  store i1 %t73, ptr %l34
  br label %bb23
bb22:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb24
bb23:
  %t74 = load i1, ptr %l34, !tbaa !21
  store i1 %t74, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t75 = load i1, ptr %l32, !tbaa !21
  br i1 %t75, label %bb25, label %bb26
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l1
  %t80 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l37
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t81 = load i1, ptr %l37, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t84, i32 0)
  store i1 %t87, ptr %l42
  br label %bb30
bb29:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb31
bb30:
  %t88 = load i1, ptr %l42, !tbaa !21
  %t89 = xor i1 %t88, true
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb31
bb31:
  %t91 = load i1, ptr %l39, !tbaa !21
  %t92 = insertvalue { i32, i1 } zeroinitializer, i1 %t91, 1
  store { i32, i1 } %t92, ptr %rv
  br label %ret
bb32:
  %t94 = insertvalue { i32, i1 } zeroinitializer, i1 false, 1
  store { i32, i1 } %t94, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t64 = alloca { i64, [4 x i64] }, align 8
  %t86 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store ptr %t8, ptr %l9
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l7, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t25)
  store i32 %t27, ptr %l13
  br label %bb5
bb5:
  %t28 = load i32, ptr %l13
  store i32 %t28, ptr %l3
  %t29 = load i32, ptr %l3
  %t31 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t29)
  store i1 %t31, ptr %l15
  br label %bb6
bb6:
  %t32 = load i1, ptr %l15, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t33)
  store i32 %t35, ptr %l17
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t36)
  %t39 = extractvalue { i32, ptr } %t38, 1
  %t40 = extractvalue { i32, ptr } %t38, 0
  store i32 %t40, ptr %l21
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb11, label %ok.42
ok.42:
  store ptr %t39, ptr %l20
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l20, !tbaa !29
  store ptr %t43, ptr %l18, !tbaa !29
  br label %bb12
bb11:
  %t44 = load i32, ptr %l21, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t54 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t54, ptr %rv
  br label %ret
bb12:
  %t55 = load ptr, ptr %l18, !tbaa !29
  store ptr %t55, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t60 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t56, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l25
  br label %bb13
bb13:
  %t61 = load i32, ptr %l3
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 0
  store i64 3, ptr %t65
  %t66 = load %"compiler/source:Span", ptr %l25
  %t67 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t66, 0
  %t69 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t67, i32 %t61, 1
  %t71 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t69, ptr %t62, 2
  %t73 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t71, ptr %t63, 3
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t73, ptr %t74
  %t75 = load { i64, [4 x i64] }, ptr %t64
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t75, ptr %t77
  %t79 = insertvalue { i32, ptr } zeroinitializer, ptr %t77, 1
  store { i32, ptr } %t79, ptr %rv
  br label %ret
bb14:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t80, i32 %t81)
  store %"compiler/source:Span" %t84, ptr %l33
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 0
  store i64 0, ptr %t87
  %t88 = load %"compiler/source:Span", ptr %l33
  %t89 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t88, 0
  %t91 = insertvalue { %"compiler/source:Span", ptr } %t89, ptr %t85, 1
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t91, ptr %t92
  %t93 = load { i64, [4 x i64] }, ptr %t86
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t93, ptr %t95
  %t97 = insertvalue { i32, ptr } zeroinitializer, ptr %t95, 1
  store { i32, ptr } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 1 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 40 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 38 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb9:
  %t22 = load i32, ptr %l1
  %t24 = trunc i64 90 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i32, ptr %l1
  %t30 = trunc i64 36 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i32, ptr %l1
  %t36 = trunc i64 35 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb19
bb18:
  %t40 = load i32, ptr %l1
  %t42 = trunc i64 37 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb19
bb19:
  %t45 = load i1, ptr %l21, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %lp25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i32
  %l48 = alloca i32
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l73 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i32
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i32
  %l86 = alloca %"compiler/source:Span"
  %l88 = alloca i32
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca i32
  %l104 = alloca %"compiler/source:Span"
  %l107 = alloca i1
  %l109 = alloca i32
  %l117 = alloca i32
  %l122 = alloca i1
  %l124 = alloca i1
  %l127 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca i32
  %l132 = alloca { i64, ptr }
  %l134 = alloca i1
  %l136 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i32
  %l146 = alloca %"compiler/source:Span"
  %l148 = alloca i32
  %l157 = alloca i32
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca i32
  %l165 = alloca %"compiler/source:Span"
  %l167 = alloca i32
  %l180 = alloca i32
  %l182 = alloca i32
  %l185 = alloca i1
  %l187 = alloca i1
  %l189 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca i32
  %l197 = alloca %"compiler/source:Span"
  %l199 = alloca i32
  %l209 = alloca i32
  %l210 = alloca ptr
  %l212 = alloca ptr
  %l213 = alloca i32
  %l217 = alloca i1
  %l218 = alloca ptr
  %l220 = alloca ptr
  %l221 = alloca i32
  %l226 = alloca %"compiler/source:Span"
  %l228 = alloca i32
  %l238 = alloca i32
  %l239 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca i32
  %l246 = alloca %"compiler/source:Span"
  %l248 = alloca i32
  %l258 = alloca i32
  %l261 = alloca i64
  %l263 = alloca ptr
  %l264 = alloca ptr
  %l266 = alloca ptr
  %l267 = alloca i32
  %l271 = alloca i1
  %l275 = alloca i1
  %l279 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l285 = alloca i32
  %l286 = alloca ptr
  %l288 = alloca ptr
  %l289 = alloca i32
  %l293 = alloca %"compiler/source:Span"
  %l295 = alloca i32
  %l304 = alloca i64
  %l311 = alloca ptr
  %l313 = alloca { i64, ptr }
  %l315 = alloca i32
  %l320 = alloca ptr
  %l326 = alloca %"compiler/source:Span"
  %l328 = alloca i32
  %l330 = alloca %"compiler/source:Span"
  %l339 = alloca ptr
  %l341 = alloca ptr
  %l342 = alloca i32
  %l346 = alloca %"compiler/source:Span"
  %l356 = alloca i1
  %l358 = alloca i32
  %l361 = alloca i1
  %l362 = alloca { i64, ptr }
  %l364 = alloca { i64, ptr }
  %l365 = alloca i32
  %l369 = alloca %"compiler/source:Span"
  %l372 = alloca i1
  %l374 = alloca i32
  %l383 = alloca ptr
  %l385 = alloca ptr
  %l386 = alloca i32
  %l390 = alloca %"compiler/source:Span"
  %l397 = alloca { i64, ptr }
  %l399 = alloca { i64, ptr }
  %l400 = alloca i32
  %l404 = alloca %"compiler/source:Span"
  %l407 = alloca i1
  %l409 = alloca i32
  %l416 = alloca ptr
  %l418 = alloca ptr
  %l419 = alloca i32
  %l423 = alloca ptr
  %l425 = alloca ptr
  %l426 = alloca i32
  %l428 = alloca ptr
  %l430 = alloca ptr
  %l431 = alloca i32
  %s22 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t189 = alloca { i64, [4 x i64] }, align 8
  %t244 = alloca { i64, [4 x i64] }, align 8
  %t370 = alloca { i64, [4 x i64] }, align 8
  %t434 = alloca { i64, [4 x i64] }, align 8
  %t526 = alloca { i64, [4 x i64] }, align 8
  %t619 = alloca { i64, [4 x i64] }, align 8
  %t686 = alloca { i64, [4 x i64] }, align 8
  %t814 = alloca { i64, [4 x i64] }, align 8
  %t921 = alloca { i64, [4 x i64] }, align 8
  %t966 = alloca { i64, [4 x i64] }, align 8
  %t1038 = alloca { i64, [4 x i64] }, align 8
  %t1049 = alloca { i64, [4 x i64] }, align 8
  %t1090 = alloca { i64, [4 x i64] }, align 8
  %t1145 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l35
  br label %bb1
bb1:
  %t4 = load i32, ptr %l35, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 12
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %t10)
  store i1 %t12, ptr %l40
  br label %bb4
bb3:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i1, ptr %l40, !tbaa !21
  store i1 %t13, ptr %l38, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l38, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efieldDecl(ptr %v0, ptr %t15)
  %t18 = extractvalue { i32, ptr } %t17, 1
  %t19 = extractvalue { i32, ptr } %t17, 0
  store i32 %t19, ptr %l44
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb9, label %ok.21
ok.21:
  store ptr %t18, ptr %l43
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t22 = load ptr, ptr %l43, !tbaa !29
  store ptr %t22, ptr %l41, !tbaa !29
  br label %bb10
bb9:
  %t23 = load i32, ptr %l44, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  %t33 = insertvalue { i32, ptr } zeroinitializer, i32 %t31, 0
  store { i32, ptr } %t33, ptr %rv
  br label %ret
bb10:
  %t34 = load ptr, ptr %l41, !tbaa !29
  %t35 = insertvalue { i32, ptr } zeroinitializer, ptr %t34, 1
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %t36)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l48
  br label %bb13
bb13:
  %t41 = load i32, ptr %l48
  store i32 %t41, ptr %l2
  %t42 = load i32, ptr %l2
  %t44 = trunc i64 9 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %t47)
  %t50 = extractvalue { i32, ptr } %t49, 1
  %t51 = extractvalue { i32, ptr } %t49, 0
  store i32 %t51, ptr %l54
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb18, label %ok.53
ok.53:
  store ptr %t50, ptr %l53
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l53, !tbaa !29
  store ptr %t54, ptr %l51, !tbaa !29
  br label %bb19
bb18:
  %t55 = load i32, ptr %l54, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  %t65 = insertvalue { i32, ptr } zeroinitializer, i32 %t63, 0
  store { i32, ptr } %t65, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l51, !tbaa !29
  %t69 = insertvalue { i32, ptr } zeroinitializer, ptr %t66, 1
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb20:
  %t70 = load i32, ptr %l2
  %t72 = trunc i64 25 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %t75)
  %t78 = extractvalue { i32, ptr } %t77, 1
  %t79 = extractvalue { i32, ptr } %t77, 0
  store i32 %t79, ptr %l62
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb25, label %ok.81
ok.81:
  store ptr %t78, ptr %l61
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l61, !tbaa !29
  store ptr %t82, ptr %l59, !tbaa !29
  br label %bb26
bb25:
  %t83 = load i32, ptr %l62, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  %t93 = insertvalue { i32, ptr } zeroinitializer, i32 %t91, 0
  store { i32, ptr } %t93, ptr %rv
  br label %ret
bb26:
  %t94 = load ptr, ptr %l59, !tbaa !29
  %t95 = insertvalue { i32, ptr } zeroinitializer, ptr %t94, 1
  store { i32, ptr } %t95, ptr %rv
  br label %ret
bb27:
  %t96 = load i32, ptr %l2
  %t98 = trunc i64 26 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb45
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l67
  br label %bb31
bb31:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t104)
  %t107 = extractvalue { i32, { i64, ptr } } %t106, 1
  %t108 = extractvalue { i32, { i64, ptr } } %t106, 0
  store i32 %t108, ptr %l71
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb33, label %ok.110
ok.110:
  store { i64, ptr } %t107, ptr %l70
  br label %bb32
bb32:
  %t111 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t111, ptr %l68, !tbaa !27
  br label %bb34
bb33:
  %t112 = load i32, ptr %l71, !tbaa !23
  %t113 = lshr i32 %t112, 16
  %t114 = and i32 %t112, 65535
  %t115 = icmp eq i32 %t113, 1
  %t116 = select i1 %t115, i32 1, i32 0
  %t117 = icmp eq i32 %t112, 0
  %t118 = shl i32 %t116, 16
  %t119 = or i32 %t118, %t114
  %t120 = select i1 %t117, i32 0, i32 %t119
  %t122 = insertvalue { i32, ptr } zeroinitializer, i32 %t120, 0
  store { i32, ptr } %t122, ptr %rv
  br label %ret
bb34:
  %t123 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t123, ptr %l4, !tbaa !27
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t127 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t124, i32 25)
  %t128 = extractvalue { i32, i32 } %t127, 1
  %t129 = extractvalue { i32, i32 } %t127, 0
  store i32 %t129, ptr %l77
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb36, label %ok.131
ok.131:
  store i32 %t128, ptr %l76
  br label %bb35
bb35:
  %t132 = load i32, ptr %l76, !tbaa !23
  store i32 %t132, ptr %l73, !tbaa !23
  br label %bb37
bb36:
  %t133 = load i32, ptr %l77, !tbaa !23
  %t134 = lshr i32 %t133, 16
  %t135 = and i32 %t133, 65535
  %t136 = icmp eq i32 %t134, 1
  %t137 = select i1 %t136, i32 1, i32 0
  %t138 = icmp eq i32 %t133, 0
  %t139 = shl i32 %t137, 16
  %t140 = or i32 %t139, %t135
  %t141 = select i1 %t138, i32 0, i32 %t140
  %t143 = insertvalue { i32, ptr } zeroinitializer, i32 %t141, 0
  store { i32, ptr } %t143, ptr %rv
  br label %ret
bb37:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t144)
  %t147 = extractvalue { i32, ptr } %t146, 1
  %t148 = extractvalue { i32, ptr } %t146, 0
  store i32 %t148, ptr %l82
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb39, label %ok.150
ok.150:
  store ptr %t147, ptr %l81
  br label %bb38
bb38:
  %t151 = load ptr, ptr %l81, !tbaa !29
  store ptr %t151, ptr %l79, !tbaa !29
  br label %bb40
bb39:
  %t152 = load i32, ptr %l82, !tbaa !23
  %t153 = lshr i32 %t152, 16
  %t154 = and i32 %t152, 65535
  %t155 = icmp eq i32 %t153, 1
  %t156 = select i1 %t155, i32 1, i32 0
  %t157 = icmp eq i32 %t152, 0
  %t158 = shl i32 %t156, 16
  %t159 = or i32 %t158, %t154
  %t160 = select i1 %t157, i32 0, i32 %t159
  %t162 = insertvalue { i32, ptr } zeroinitializer, i32 %t160, 0
  store { i32, ptr } %t162, ptr %rv
  br label %ret
bb40:
  %t163 = load ptr, ptr %l79, !tbaa !29
  store ptr %t163, ptr %l5, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l1, !tbaa !23
  %t168 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t164, i32 %t165)
  store %"compiler/source:Span" %t168, ptr %l86
  br label %bb41
bb41:
  %t169 = load %"compiler/source:Span", ptr %l86
  store %"compiler/source:Span" %t169, ptr %l6
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t170)
  store i32 %t172, ptr %l88
  %t173 = icmp ne i32 %t172, 0
  br i1 %t173, label %bb43, label %ok.174
ok.174:
  br label %bb42
bb42:
  br label %bb44
bb43:
  %t175 = load i32, ptr %l88, !tbaa !23
  %t176 = lshr i32 %t175, 16
  %t177 = and i32 %t175, 65535
  %t178 = icmp eq i32 %t176, 1
  %t179 = select i1 %t178, i32 1, i32 0
  %t180 = icmp eq i32 %t175, 0
  %t181 = shl i32 %t179, 16
  %t182 = or i32 %t181, %t177
  %t183 = select i1 %t180, i32 0, i32 %t182
  %t185 = insertvalue { i32, ptr } zeroinitializer, i32 %t183, 0
  store { i32, ptr } %t185, ptr %rv
  br label %ret
bb44:
  %t186 = load %"compiler/source:Span", ptr %l6
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = load ptr, ptr %l5, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 0
  store i64 10, ptr %t190
  %t192 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t186, 0
  %t194 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t192, { i64, ptr } %t187, 1
  %t196 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t194, ptr %t188, 2
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t196, ptr %t197
  %t198 = load { i64, [4 x i64] }, ptr %t189
  %t200 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t198, ptr %t200
  %t202 = insertvalue { i32, ptr } zeroinitializer, ptr %t200, 1
  store { i32, ptr } %t202, ptr %rv
  br label %ret
bb45:
  %t203 = load i32, ptr %l2
  %t205 = trunc i64 31 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb58
bb48:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %t208)
  %t211 = extractvalue { i32, ptr } %t210, 1
  %t212 = extractvalue { i32, ptr } %t210, 0
  store i32 %t212, ptr %l100
  %t213 = icmp ne i32 %t212, 0
  br i1 %t213, label %bb50, label %ok.214
ok.214:
  store ptr %t211, ptr %l99
  br label %bb49
bb49:
  %t215 = load ptr, ptr %l99, !tbaa !29
  store ptr %t215, ptr %l97, !tbaa !29
  br label %bb51
bb50:
  %t216 = load i32, ptr %l100, !tbaa !23
  %t217 = lshr i32 %t216, 16
  %t218 = and i32 %t216, 65535
  %t219 = icmp eq i32 %t217, 1
  %t220 = select i1 %t219, i32 1, i32 0
  %t221 = icmp eq i32 %t216, 0
  %t222 = shl i32 %t220, 16
  %t223 = or i32 %t222, %t218
  %t224 = select i1 %t221, i32 0, i32 %t223
  %t226 = insertvalue { i32, ptr } zeroinitializer, i32 %t224, 0
  store { i32, ptr } %t226, ptr %rv
  br label %ret
bb51:
  %t227 = load ptr, ptr %l97, !tbaa !29
  store ptr %t227, ptr %l7, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i32, ptr %l1, !tbaa !23
  %t232 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t228, i32 %t229)
  store %"compiler/source:Span" %t232, ptr %l104
  br label %bb52
bb52:
  %t233 = load %"compiler/source:Span", ptr %l104
  store %"compiler/source:Span" %t233, ptr %l8
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t237 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t234, i32 8)
  store i1 %t237, ptr %l107
  br label %bb53
bb53:
  %t238 = load i1, ptr %l107, !tbaa !21
  br i1 %t238, label %bb54, label %bb55
bb54:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t239)
  store i32 %t241, ptr %l109
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t242 = load %"compiler/source:Span", ptr %l8
  %t243 = load ptr, ptr %l7, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t244
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 0
  store i64 11, ptr %t245
  %t247 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t242, 0
  %t249 = insertvalue { %"compiler/source:Span", ptr } %t247, ptr %t243, 1
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t249, ptr %t250
  %t251 = load { i64, [4 x i64] }, ptr %t244
  %t253 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t251, ptr %t253
  %t255 = insertvalue { i32, ptr } zeroinitializer, ptr %t253, 1
  store { i32, ptr } %t255, ptr %rv
  br label %ret
bb58:
  %t256 = load i32, ptr %l2
  %t258 = trunc i64 13 to i32
  %t259 = icmp eq i32 %t256, %t258
  br i1 %t259, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb89
bb61:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t261)
  store i32 %t263, ptr %l117
  br label %bb62
bb62:
  %t264 = icmp sge i64 0, 0
  br i1 %t264, label %bb63, label %bb64
bb63:
  %t266 = icmp sle i64 0, 1152921504606846975
  br i1 %t266, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_405430454c9e5d04_720bbb7e3dc9fd0)
  unreachable
bb65:
  %t268 = mul i64 0, 8
  %t269 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t268)
  %t270 = insertvalue { i64, ptr } undef, i64 0, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l9, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %t273)
  store i1 %t275, ptr %l122
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_405430454c9e5d04_720bbb7e3dc9fd0)
  unreachable
bb67:
  %t276 = load i1, ptr %l122, !tbaa !21
  %t277 = xor i1 %t276, true
  br i1 %t277, label %bb68, label %bb69
bb68:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/parse:Parser", ptr %t279, i32 0, i32 14
  %t282 = load i1, ptr %t281, !tbaa !21
  store i1 %t282, ptr %l124, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb70
bb70:
  %t284 = load i1, ptr %l124, !tbaa !21
  br i1 %t284, label %bb71, label %bb72
bb71:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t285)
  %t288 = extractvalue { i32, ptr } %t287, 1
  %t289 = extractvalue { i32, ptr } %t287, 0
  store i32 %t289, ptr %l130
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb74, label %ok.291
ok.291:
  store ptr %t288, ptr %l129
  br label %bb73
bb72:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %t292)
  store i1 %t294, ptr %l134
  br label %bb76
bb73:
  %t295 = load ptr, ptr %l129, !tbaa !29
  store ptr %t295, ptr %l127, !tbaa !29
  br label %bb75
bb74:
  %t296 = load i32, ptr %l130, !tbaa !23
  %t297 = lshr i32 %t296, 16
  %t298 = and i32 %t296, 65535
  %t299 = icmp eq i32 %t297, 1
  %t300 = select i1 %t299, i32 1, i32 0
  %t301 = icmp eq i32 %t296, 0
  %t302 = shl i32 %t300, 16
  %t303 = or i32 %t302, %t298
  %t304 = select i1 %t301, i32 0, i32 %t303
  %t306 = insertvalue { i32, ptr } zeroinitializer, i32 %t304, 0
  store { i32, ptr } %t306, ptr %rv
  br label %ret
bb75:
  %t307 = mul i64 1, 8
  %t308 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 1, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l132, !tbaa !27
  %t311 = load ptr, ptr %l127, !tbaa !29
  %t312 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr ptr, ptr %t313, i64 0
  store ptr %t311, ptr %t314, !tbaa !39
  %t315 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t315, ptr %l9, !tbaa !27
  br label %bb84
bb76:
  %t316 = load i1, ptr %l134, !tbaa !21
  %t317 = xor i1 %t316, true
  br i1 %t317, label %bb77, label %bb78
bb77:
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l136, !tbaa !29
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t320)
  store i32 %t322, ptr %l138
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t323 = load i32, ptr %l138, !tbaa !23
  %t324 = load ptr, ptr %l136, !tbaa !29
  %t325 = getelementptr %"compiler/parse:Parser", ptr %t324, i32 0, i32 24
  store i32 %t323, ptr %t325, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %t326)
  %t329 = extractvalue { i32, { i64, ptr } } %t328, 1
  %t330 = extractvalue { i32, { i64, ptr } } %t328, 0
  store i32 %t330, ptr %l142
  %t331 = icmp ne i32 %t330, 0
  br i1 %t331, label %bb81, label %ok.332
ok.332:
  store { i64, ptr } %t329, ptr %l141
  br label %bb80
bb80:
  %t333 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t333, ptr %l139, !tbaa !27
  br label %bb82
bb81:
  %t334 = load i32, ptr %l142, !tbaa !23
  %t335 = lshr i32 %t334, 16
  %t336 = and i32 %t334, 65535
  %t337 = icmp eq i32 %t335, 1
  %t338 = select i1 %t337, i32 1, i32 0
  %t339 = icmp eq i32 %t334, 0
  %t340 = shl i32 %t338, 16
  %t341 = or i32 %t340, %t336
  %t342 = select i1 %t339, i32 0, i32 %t341
  %t344 = insertvalue { i32, ptr } zeroinitializer, i32 %t342, 0
  store { i32, ptr } %t344, ptr %rv
  br label %ret
bb82:
  %t345 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t345, ptr %l9, !tbaa !27
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i32, ptr %l1, !tbaa !23
  %t350 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t346, i32 %t347)
  store %"compiler/source:Span" %t350, ptr %l146
  br label %bb85
bb85:
  %t351 = load %"compiler/source:Span", ptr %l146
  store %"compiler/source:Span" %t351, ptr %l10
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t352)
  store i32 %t354, ptr %l148
  %t355 = icmp ne i32 %t354, 0
  br i1 %t355, label %bb87, label %ok.356
ok.356:
  br label %bb86
bb86:
  br label %bb88
bb87:
  %t357 = load i32, ptr %l148, !tbaa !23
  %t358 = lshr i32 %t357, 16
  %t359 = and i32 %t357, 65535
  %t360 = icmp eq i32 %t358, 1
  %t361 = select i1 %t360, i32 1, i32 0
  %t362 = icmp eq i32 %t357, 0
  %t363 = shl i32 %t361, 16
  %t364 = or i32 %t363, %t359
  %t365 = select i1 %t362, i32 0, i32 %t364
  %t367 = insertvalue { i32, ptr } zeroinitializer, i32 %t365, 0
  store { i32, ptr } %t367, ptr %rv
  br label %ret
bb88:
  %t368 = load %"compiler/source:Span", ptr %l10
  %t369 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t370
  %t371 = getelementptr { i64, [4 x i64] }, ptr %t370, i32 0, i32 0
  store i64 12, ptr %t371
  %t373 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t368, 0
  %t375 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t373, { i64, ptr } %t369, 1
  %t376 = getelementptr { i64, [4 x i64] }, ptr %t370, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t375, ptr %t376
  %t377 = load { i64, [4 x i64] }, ptr %t370
  %t379 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t377, ptr %t379
  %t381 = insertvalue { i32, ptr } zeroinitializer, ptr %t379, 1
  store { i32, ptr } %t381, ptr %rv
  br label %ret
bb89:
  %t382 = load i32, ptr %l2
  %t384 = trunc i64 50 to i32
  %t385 = icmp eq i32 %t382, %t384
  br i1 %t385, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb101
bb92:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t387)
  store i32 %t389, ptr %l157
  br label %bb93
bb93:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t390)
  %t393 = extractvalue { i32, ptr } %t392, 1
  %t394 = extractvalue { i32, ptr } %t392, 0
  store i32 %t394, ptr %l161
  %t395 = icmp ne i32 %t394, 0
  br i1 %t395, label %bb95, label %ok.396
ok.396:
  store ptr %t393, ptr %l160
  br label %bb94
bb94:
  %t397 = load ptr, ptr %l160, !tbaa !29
  store ptr %t397, ptr %l158, !tbaa !29
  br label %bb96
bb95:
  %t398 = load i32, ptr %l161, !tbaa !23
  %t399 = lshr i32 %t398, 16
  %t400 = and i32 %t398, 65535
  %t401 = icmp eq i32 %t399, 1
  %t402 = select i1 %t401, i32 1, i32 0
  %t403 = icmp eq i32 %t398, 0
  %t404 = shl i32 %t402, 16
  %t405 = or i32 %t404, %t400
  %t406 = select i1 %t403, i32 0, i32 %t405
  %t408 = insertvalue { i32, ptr } zeroinitializer, i32 %t406, 0
  store { i32, ptr } %t408, ptr %rv
  br label %ret
bb96:
  %t409 = load ptr, ptr %l158, !tbaa !29
  store ptr %t409, ptr %l11, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load i32, ptr %l1, !tbaa !23
  %t414 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t410, i32 %t411)
  store %"compiler/source:Span" %t414, ptr %l165
  br label %bb97
bb97:
  %t415 = load %"compiler/source:Span", ptr %l165
  store %"compiler/source:Span" %t415, ptr %l12
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t416)
  store i32 %t418, ptr %l167
  %t419 = icmp ne i32 %t418, 0
  br i1 %t419, label %bb99, label %ok.420
ok.420:
  br label %bb98
bb98:
  br label %bb100
bb99:
  %t421 = load i32, ptr %l167, !tbaa !23
  %t422 = lshr i32 %t421, 16
  %t423 = and i32 %t421, 65535
  %t424 = icmp eq i32 %t422, 1
  %t425 = select i1 %t424, i32 1, i32 0
  %t426 = icmp eq i32 %t421, 0
  %t427 = shl i32 %t425, 16
  %t428 = or i32 %t427, %t423
  %t429 = select i1 %t426, i32 0, i32 %t428
  %t431 = insertvalue { i32, ptr } zeroinitializer, i32 %t429, 0
  store { i32, ptr } %t431, ptr %rv
  br label %ret
bb100:
  %t432 = load %"compiler/source:Span", ptr %l12
  %t433 = load ptr, ptr %l11, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t434
  %t435 = getelementptr { i64, [4 x i64] }, ptr %t434, i32 0, i32 0
  store i64 20, ptr %t435
  %t437 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t432, 0
  %t439 = insertvalue { %"compiler/source:Span", ptr } %t437, ptr %t433, 1
  %t440 = getelementptr { i64, [4 x i64] }, ptr %t434, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t439, ptr %t440
  %t441 = load { i64, [4 x i64] }, ptr %t434
  %t443 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t441, ptr %t443
  %t445 = insertvalue { i32, ptr } zeroinitializer, ptr %t443, 1
  store { i32, ptr } %t445, ptr %rv
  br label %ret
bb101:
  %t446 = load i32, ptr %l2
  %t448 = trunc i64 19 to i32
  %t449 = icmp eq i32 %t446, %t448
  br i1 %t449, label %bb102, label %bb103
bb102:
  br label %bb108
bb103:
  %t451 = load i32, ptr %l2
  %t453 = trunc i64 20 to i32
  %t454 = icmp eq i32 %t451, %t453
  br i1 %t454, label %bb104, label %bb105
bb104:
  br label %bb108
bb105:
  %t456 = load i32, ptr %l2
  %t458 = trunc i64 21 to i32
  %t459 = icmp eq i32 %t456, %t458
  br i1 %t459, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb125
bb108:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t461)
  store i32 %t463, ptr %l180
  br label %bb109
bb109:
  %t464 = load i32, ptr %l180
  store i32 %t464, ptr %l13
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t465)
  store i32 %t467, ptr %l182
  br label %bb110
bb110:
  store ptr null, ptr %l14, !tbaa !29
  %t468 = load i32, ptr %l13
  %t470 = trunc i64 21 to i32
  %t471 = icmp eq i32 %t468, %t470
  br i1 %t471, label %bb111, label %bb112
bb111:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %t473)
  store i1 %t475, ptr %l187
  br label %bb113
bb112:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb114
bb113:
  %t476 = load i1, ptr %l187, !tbaa !21
  %t477 = xor i1 %t476, true
  store i1 %t477, ptr %l185, !tbaa !21
  br label %bb114
bb114:
  %t479 = load i1, ptr %l185, !tbaa !21
  br i1 %t479, label %bb115, label %bb116
bb115:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t480)
  %t483 = extractvalue { i32, ptr } %t482, 1
  %t484 = extractvalue { i32, ptr } %t482, 0
  store i32 %t484, ptr %l192
  %t485 = icmp ne i32 %t484, 0
  br i1 %t485, label %bb118, label %ok.486
ok.486:
  store ptr %t483, ptr %l191
  br label %bb117
bb116:
  br label %bb120
bb117:
  %t487 = load ptr, ptr %l191, !tbaa !29
  store ptr %t487, ptr %l189, !tbaa !29
  br label %bb119
bb118:
  %t488 = load i32, ptr %l192, !tbaa !23
  %t489 = lshr i32 %t488, 16
  %t490 = and i32 %t488, 65535
  %t491 = icmp eq i32 %t489, 1
  %t492 = select i1 %t491, i32 1, i32 0
  %t493 = icmp eq i32 %t488, 0
  %t494 = shl i32 %t492, 16
  %t495 = or i32 %t494, %t490
  %t496 = select i1 %t493, i32 0, i32 %t495
  %t498 = insertvalue { i32, ptr } zeroinitializer, i32 %t496, 0
  store { i32, ptr } %t498, ptr %rv
  br label %ret
bb119:
  %t499 = load ptr, ptr %l189, !tbaa !29
  store ptr %t499, ptr %l14, !tbaa !29
  br label %bb120
bb120:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load i32, ptr %l1, !tbaa !23
  %t505 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t501, i32 %t502)
  store %"compiler/source:Span" %t505, ptr %l197
  br label %bb121
bb121:
  %t506 = load %"compiler/source:Span", ptr %l197
  store %"compiler/source:Span" %t506, ptr %l15
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t507)
  store i32 %t509, ptr %l199
  %t510 = icmp ne i32 %t509, 0
  br i1 %t510, label %bb123, label %ok.511
ok.511:
  br label %bb122
bb122:
  br label %bb124
bb123:
  %t512 = load i32, ptr %l199, !tbaa !23
  %t513 = lshr i32 %t512, 16
  %t514 = and i32 %t512, 65535
  %t515 = icmp eq i32 %t513, 1
  %t516 = select i1 %t515, i32 1, i32 0
  %t517 = icmp eq i32 %t512, 0
  %t518 = shl i32 %t516, 16
  %t519 = or i32 %t518, %t514
  %t520 = select i1 %t517, i32 0, i32 %t519
  %t522 = insertvalue { i32, ptr } zeroinitializer, i32 %t520, 0
  store { i32, ptr } %t522, ptr %rv
  br label %ret
bb124:
  %t523 = load %"compiler/source:Span", ptr %l15
  %t524 = load i32, ptr %l13
  %t525 = load ptr, ptr %l14, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t526
  %t527 = getelementptr { i64, [4 x i64] }, ptr %t526, i32 0, i32 0
  store i64 13, ptr %t527
  %t529 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t523, 0
  %t531 = insertvalue { %"compiler/source:Span", i32, ptr } %t529, i32 %t524, 1
  %t533 = insertvalue { %"compiler/source:Span", i32, ptr } %t531, ptr %t525, 2
  %t534 = getelementptr { i64, [4 x i64] }, ptr %t526, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t533, ptr %t534
  %t535 = load { i64, [4 x i64] }, ptr %t526
  %t537 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t535, ptr %t537
  %t539 = insertvalue { i32, ptr } zeroinitializer, ptr %t537, 1
  store { i32, ptr } %t539, ptr %rv
  br label %ret
bb125:
  %t540 = load i32, ptr %l2
  %t542 = trunc i64 24 to i32
  %t543 = icmp eq i32 %t540, %t542
  br i1 %t543, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb144
bb128:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t545)
  store i32 %t547, ptr %l209
  br label %bb129
bb129:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t548)
  %t551 = extractvalue { i32, ptr } %t550, 1
  %t552 = extractvalue { i32, ptr } %t550, 0
  store i32 %t552, ptr %l213
  %t553 = icmp ne i32 %t552, 0
  br i1 %t553, label %bb131, label %ok.554
ok.554:
  store ptr %t551, ptr %l212
  br label %bb130
bb130:
  %t555 = load ptr, ptr %l212, !tbaa !29
  store ptr %t555, ptr %l210, !tbaa !29
  br label %bb132
bb131:
  %t556 = load i32, ptr %l213, !tbaa !23
  %t557 = lshr i32 %t556, 16
  %t558 = and i32 %t556, 65535
  %t559 = icmp eq i32 %t557, 1
  %t560 = select i1 %t559, i32 1, i32 0
  %t561 = icmp eq i32 %t556, 0
  %t562 = shl i32 %t560, 16
  %t563 = or i32 %t562, %t558
  %t564 = select i1 %t561, i32 0, i32 %t563
  %t566 = insertvalue { i32, ptr } zeroinitializer, i32 %t564, 0
  store { i32, ptr } %t566, ptr %rv
  br label %ret
bb132:
  %t567 = load ptr, ptr %l210, !tbaa !29
  store ptr %t567, ptr %l16, !tbaa !29
  store ptr null, ptr %l17, !tbaa !29
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t571 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t568, i32 57)
  store i1 %t571, ptr %l217
  br label %bb133
bb133:
  %t572 = load i1, ptr %l217, !tbaa !21
  br i1 %t572, label %bb134, label %bb135
bb134:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t575 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t573)
  %t576 = extractvalue { i32, ptr } %t575, 1
  %t577 = extractvalue { i32, ptr } %t575, 0
  store i32 %t577, ptr %l221
  %t578 = icmp ne i32 %t577, 0
  br i1 %t578, label %bb137, label %ok.579
ok.579:
  store ptr %t576, ptr %l220
  br label %bb136
bb135:
  br label %bb139
bb136:
  %t580 = load ptr, ptr %l220, !tbaa !29
  store ptr %t580, ptr %l218, !tbaa !29
  br label %bb138
bb137:
  %t581 = load i32, ptr %l221, !tbaa !23
  %t582 = lshr i32 %t581, 16
  %t583 = and i32 %t581, 65535
  %t584 = icmp eq i32 %t582, 1
  %t585 = select i1 %t584, i32 1, i32 0
  %t586 = icmp eq i32 %t581, 0
  %t587 = shl i32 %t585, 16
  %t588 = or i32 %t587, %t583
  %t589 = select i1 %t586, i32 0, i32 %t588
  %t591 = insertvalue { i32, ptr } zeroinitializer, i32 %t589, 0
  store { i32, ptr } %t591, ptr %rv
  br label %ret
bb138:
  %t592 = load ptr, ptr %l218, !tbaa !29
  store ptr %t592, ptr %l17, !tbaa !29
  br label %bb139
bb139:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load i32, ptr %l1, !tbaa !23
  %t598 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t594, i32 %t595)
  store %"compiler/source:Span" %t598, ptr %l226
  br label %bb140
bb140:
  %t599 = load %"compiler/source:Span", ptr %l226
  store %"compiler/source:Span" %t599, ptr %l18
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t600)
  store i32 %t602, ptr %l228
  %t603 = icmp ne i32 %t602, 0
  br i1 %t603, label %bb142, label %ok.604
ok.604:
  br label %bb141
bb141:
  br label %bb143
bb142:
  %t605 = load i32, ptr %l228, !tbaa !23
  %t606 = lshr i32 %t605, 16
  %t607 = and i32 %t605, 65535
  %t608 = icmp eq i32 %t606, 1
  %t609 = select i1 %t608, i32 1, i32 0
  %t610 = icmp eq i32 %t605, 0
  %t611 = shl i32 %t609, 16
  %t612 = or i32 %t611, %t607
  %t613 = select i1 %t610, i32 0, i32 %t612
  %t615 = insertvalue { i32, ptr } zeroinitializer, i32 %t613, 0
  store { i32, ptr } %t615, ptr %rv
  br label %ret
bb143:
  %t616 = load %"compiler/source:Span", ptr %l18
  %t617 = load ptr, ptr %l16, !tbaa !29
  %t618 = load ptr, ptr %l17, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t619
  %t620 = getelementptr { i64, [4 x i64] }, ptr %t619, i32 0, i32 0
  store i64 14, ptr %t620
  %t622 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t616, 0
  %t624 = insertvalue { %"compiler/source:Span", ptr, ptr } %t622, ptr %t617, 1
  %t626 = insertvalue { %"compiler/source:Span", ptr, ptr } %t624, ptr %t618, 2
  %t627 = getelementptr { i64, [4 x i64] }, ptr %t619, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t626, ptr %t627
  %t628 = load { i64, [4 x i64] }, ptr %t619
  %t630 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t628, ptr %t630
  %t632 = insertvalue { i32, ptr } zeroinitializer, ptr %t630, 1
  store { i32, ptr } %t632, ptr %rv
  br label %ret
bb144:
  %t633 = load i32, ptr %l2
  %t635 = trunc i64 39 to i32
  %t636 = icmp eq i32 %t633, %t635
  br i1 %t636, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb156
bb147:
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t638)
  store i32 %t640, ptr %l238
  br label %bb148
bb148:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t641)
  %t644 = extractvalue { i32, ptr } %t643, 1
  %t645 = extractvalue { i32, ptr } %t643, 0
  store i32 %t645, ptr %l242
  %t646 = icmp ne i32 %t645, 0
  br i1 %t646, label %bb150, label %ok.647
ok.647:
  store ptr %t644, ptr %l241
  br label %bb149
bb149:
  %t648 = load ptr, ptr %l241, !tbaa !29
  store ptr %t648, ptr %l239, !tbaa !29
  br label %bb151
bb150:
  %t649 = load i32, ptr %l242, !tbaa !23
  %t650 = lshr i32 %t649, 16
  %t651 = and i32 %t649, 65535
  %t652 = icmp eq i32 %t650, 1
  %t653 = select i1 %t652, i32 1, i32 0
  %t654 = icmp eq i32 %t649, 0
  %t655 = shl i32 %t653, 16
  %t656 = or i32 %t655, %t651
  %t657 = select i1 %t654, i32 0, i32 %t656
  %t659 = insertvalue { i32, ptr } zeroinitializer, i32 %t657, 0
  store { i32, ptr } %t659, ptr %rv
  br label %ret
bb151:
  %t660 = load ptr, ptr %l239, !tbaa !29
  store ptr %t660, ptr %l19, !tbaa !29
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t662 = load i32, ptr %l1, !tbaa !23
  %t665 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t661, i32 %t662)
  store %"compiler/source:Span" %t665, ptr %l246
  br label %bb152
bb152:
  %t666 = load %"compiler/source:Span", ptr %l246
  store %"compiler/source:Span" %t666, ptr %l20
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t669 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t667)
  store i32 %t669, ptr %l248
  %t670 = icmp ne i32 %t669, 0
  br i1 %t670, label %bb154, label %ok.671
ok.671:
  br label %bb153
bb153:
  br label %bb155
bb154:
  %t672 = load i32, ptr %l248, !tbaa !23
  %t673 = lshr i32 %t672, 16
  %t674 = and i32 %t672, 65535
  %t675 = icmp eq i32 %t673, 1
  %t676 = select i1 %t675, i32 1, i32 0
  %t677 = icmp eq i32 %t672, 0
  %t678 = shl i32 %t676, 16
  %t679 = or i32 %t678, %t674
  %t680 = select i1 %t677, i32 0, i32 %t679
  %t682 = insertvalue { i32, ptr } zeroinitializer, i32 %t680, 0
  store { i32, ptr } %t682, ptr %rv
  br label %ret
bb155:
  %t683 = load %"compiler/source:Span", ptr %l20
  %t684 = load ptr, ptr %l19, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t686
  %t687 = getelementptr { i64, [4 x i64] }, ptr %t686, i32 0, i32 0
  store i64 15, ptr %t687
  %t689 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t683, 0
  %t691 = insertvalue { %"compiler/source:Span", ptr } %t689, ptr %t684, 1
  %t692 = getelementptr { i64, [4 x i64] }, ptr %t686, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t691, ptr %t692
  %t693 = load { i64, [4 x i64] }, ptr %t686
  %t695 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t693, ptr %t695
  %t697 = insertvalue { i32, ptr } zeroinitializer, ptr %t695, 1
  store { i32, ptr } %t697, ptr %rv
  br label %ret
bb156:
  %t698 = load i32, ptr %l2
  %t700 = trunc i64 15 to i32
  %t701 = icmp eq i32 %t698, %t700
  br i1 %t701, label %bb157, label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb208
bb159:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t705 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t703)
  store i32 %t705, ptr %l258
  br label %bb160
bb160:
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/parse:Parser", ptr %t706, i32 0, i32 30
  %t710 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t708)
  store i64 %t710, ptr %l261
  br label %bb161
bb161:
  %t711 = load i64, ptr %l261, !tbaa !24
  store i64 %t711, ptr %l21, !tbaa !24
  br label %bb162
bb162:
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/parse:Parser", ptr %t712, i32 0, i32 30
  store ptr %t714, ptr %l263, !tbaa !29
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t717 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t715)
  %t718 = extractvalue { i32, ptr } %t717, 1
  %t719 = extractvalue { i32, ptr } %t717, 0
  store i32 %t719, ptr %l267
  %t720 = icmp ne i32 %t719, 0
  br i1 %t720, label %bb164, label %ok.721
ok.721:
  store ptr %t718, ptr %l266
  br label %bb163
bb163:
  %t722 = load ptr, ptr %l266, !tbaa !29
  store ptr %t722, ptr %l264, !tbaa !29
  br label %bb165
bb164:
  %t723 = load i32, ptr %l267, !tbaa !23
  %t724 = lshr i32 %t723, 16
  %t725 = and i32 %t723, 65535
  %t726 = icmp eq i32 %t724, 1
  %t727 = select i1 %t726, i32 1, i32 0
  %t728 = icmp eq i32 %t723, 0
  %t729 = shl i32 %t727, 16
  %t730 = or i32 %t729, %t725
  %t731 = select i1 %t728, i32 0, i32 %t730
  %t733 = insertvalue { i32, ptr } zeroinitializer, i32 %t731, 0
  store { i32, ptr } %t733, ptr %rv
  br label %ret
bb165:
  %t734 = load ptr, ptr %l263, !tbaa !29
  %t735 = load ptr, ptr %l264, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t734, ptr %t735)
  br label %bb166
bb166:
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t739 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t736, i32 57)
  store i1 %t739, ptr %l271
  br label %bb167
bb167:
  %t740 = load i1, ptr %l271, !tbaa !21
  %t741 = xor i1 %t740, true
  br i1 %t741, label %bb168, label %bb169
bb168:
  br label %bb172
bb169:
  br label %bb170
bb170:
  br label %bb171
bb171:
  br label %bb162
bb172:
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t746 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t743, i32 60)
  store i1 %t746, ptr %l275
  br label %bb173
bb173:
  %t747 = load i1, ptr %l275, !tbaa !21
  br i1 %t747, label %bb174, label %bb175
bb174:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t750 = getelementptr %"compiler/parse:Parser", ptr %t748, i32 0, i32 30
  %t751 = load i64, ptr %l21, !tbaa !24
  %t754 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t750, i64 %t751)
  store { i64, ptr } %t754, ptr %l279
  br label %bb176
bb175:
  br label %bb188
bb176:
  %t755 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t755, ptr %l22, !tbaa !27
  %t756 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t758 = extractvalue { i64, ptr } %t756, 0
  %t760 = icmp sgt i64 %t758, 1
  br i1 %t760, label %bb177, label %bb178
bb177:
  %t762 = load ptr, ptr %l0, !tbaa !29
  store ptr %t762, ptr %l283, !tbaa !29
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t763)
  store i32 %t765, ptr %l285
  br label %bb179
bb178:
  br label %bb180
bb179:
  %t766 = load i32, ptr %l285, !tbaa !23
  %t767 = load ptr, ptr %l283, !tbaa !29
  %t768 = getelementptr %"compiler/parse:Parser", ptr %t767, i32 0, i32 24
  store i32 %t766, ptr %t768, !tbaa !23
  br label %bb180
bb180:
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t771 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t769)
  %t772 = extractvalue { i32, ptr } %t771, 1
  %t773 = extractvalue { i32, ptr } %t771, 0
  store i32 %t773, ptr %l289
  %t774 = icmp ne i32 %t773, 0
  br i1 %t774, label %bb182, label %ok.775
ok.775:
  store ptr %t772, ptr %l288
  br label %bb181
bb181:
  %t776 = load ptr, ptr %l288, !tbaa !29
  store ptr %t776, ptr %l286, !tbaa !29
  br label %bb183
bb182:
  %t777 = load i32, ptr %l289, !tbaa !23
  %t778 = lshr i32 %t777, 16
  %t779 = and i32 %t777, 65535
  %t780 = icmp eq i32 %t778, 1
  %t781 = select i1 %t780, i32 1, i32 0
  %t782 = icmp eq i32 %t777, 0
  %t783 = shl i32 %t781, 16
  %t784 = or i32 %t783, %t779
  %t785 = select i1 %t782, i32 0, i32 %t784
  %t787 = insertvalue { i32, ptr } zeroinitializer, i32 %t785, 0
  store { i32, ptr } %t787, ptr %rv
  br label %ret
bb183:
  %t788 = load ptr, ptr %l286, !tbaa !29
  store ptr %t788, ptr %l23, !tbaa !29
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load i32, ptr %l1, !tbaa !23
  %t793 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t789, i32 %t790)
  store %"compiler/source:Span" %t793, ptr %l293
  br label %bb184
bb184:
  %t794 = load %"compiler/source:Span", ptr %l293
  store %"compiler/source:Span" %t794, ptr %l24
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t795)
  store i32 %t797, ptr %l295
  %t798 = icmp ne i32 %t797, 0
  br i1 %t798, label %bb186, label %ok.799
ok.799:
  br label %bb185
bb185:
  br label %bb187
bb186:
  %t800 = load i32, ptr %l295, !tbaa !23
  %t801 = lshr i32 %t800, 16
  %t802 = and i32 %t800, 65535
  %t803 = icmp eq i32 %t801, 1
  %t804 = select i1 %t803, i32 1, i32 0
  %t805 = icmp eq i32 %t800, 0
  %t806 = shl i32 %t804, 16
  %t807 = or i32 %t806, %t802
  %t808 = select i1 %t805, i32 0, i32 %t807
  %t810 = insertvalue { i32, ptr } zeroinitializer, i32 %t808, 0
  store { i32, ptr } %t810, ptr %rv
  br label %ret
bb187:
  %t811 = load %"compiler/source:Span", ptr %l24
  %t812 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t813 = load ptr, ptr %l23, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t814
  %t815 = getelementptr { i64, [4 x i64] }, ptr %t814, i32 0, i32 0
  store i64 16, ptr %t815
  %t817 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t811, 0
  %t819 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t817, { i64, ptr } %t812, 1
  %t821 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t819, ptr %t813, 2
  %t822 = getelementptr { i64, [4 x i64] }, ptr %t814, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t821, ptr %t822
  %t823 = load { i64, [4 x i64] }, ptr %t814
  %t825 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t823, ptr %t825
  %t827 = insertvalue { i32, ptr } zeroinitializer, ptr %t825, 1
  store { i32, ptr } %t827, ptr %rv
  br label %ret
bb188:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = getelementptr %"compiler/parse:Parser", ptr %t828, i32 0, i32 30
  %t832 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t830)
  store i64 %t832, ptr %l304
  br label %bb189
bb189:
  %t833 = load i64, ptr %l21, !tbaa !24
  %t834 = load i64, ptr %l304, !tbaa !24
  %t836 = sub i64 %t834, %t833
  %t838 = icmp ne i64 %t836, 1
  br i1 %t838, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s22
  %t840 = load ptr, ptr %l0, !tbaa !29
  %t842 = getelementptr %"compiler/parse:Parser", ptr %t840, i32 0, i32 30
  %t843 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t842, i64 %t843)
  br label %bb192
bb191:
  br label %bb197
bb192:
  %t846 = load ptr, ptr %l0, !tbaa !29
  store ptr %t846, ptr %l311, !tbaa !29
  %t848 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s22, i32 60)
  store { i64, ptr } %t848, ptr %l313
  br label %bb193
bb193:
  %t849 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t850 = extractvalue { i64, ptr } %t849, 0
  %t851 = extractvalue { i64, ptr } %t849, 1
  %t852 = mul i64 %t850, 1
  %t853 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t852)
  call void @llvm.memcpy.p0.p0.i64(ptr %t853, ptr %t851, i64 %t852, i1 false)
  %t854 = insertvalue { i64, ptr } undef, i64 %t850, 0
  %t855 = insertvalue { i64, ptr } %t854, ptr %t853, 1
  %t856 = load ptr, ptr %l311, !tbaa !29
  %t858 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s22, ptr %t856, { i64, ptr } %t855)
  store i32 %t858, ptr %l315
  %t859 = icmp ne i32 %t858, 0
  br i1 %t859, label %bb195, label %ok.860
ok.860:
  br label %bb194
bb194:
  br label %bb196
bb195:
  %t861 = load i32, ptr %l315, !tbaa !23
  %t862 = lshr i32 %t861, 16
  %t863 = and i32 %t861, 65535
  %t864 = icmp eq i32 %t862, 1
  %t865 = select i1 %t864, i32 1, i32 0
  %t866 = icmp eq i32 %t861, 0
  %t867 = shl i32 %t865, 16
  %t868 = or i32 %t867, %t863
  %t869 = select i1 %t866, i32 0, i32 %t868
  call void @__olang_scope_close(ptr %s22)
  %t871 = insertvalue { i32, ptr } zeroinitializer, i32 %t869, 0
  store { i32, ptr } %t871, ptr %rv
  br label %ret
bb196:
  call void @__olang_scope_close(ptr %s22)
  br label %bb197
bb197:
  %t872 = load ptr, ptr %l0, !tbaa !29
  %t874 = getelementptr %"compiler/parse:Parser", ptr %t872, i32 0, i32 30
  %t875 = load i64, ptr %l21, !tbaa !24
  %t878 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eAt_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t874, i64 %t875)
  store ptr %t878, ptr %l320
  br label %bb198
bb198:
  %t879 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t879, ptr %lp25
  %t880 = load ptr, ptr %l320, !tbaa !29
  %t881 = load ptr, ptr %lp25
  store ptr %t880, ptr %t881, !tbaa !29
  %t882 = load ptr, ptr %l0, !tbaa !29
  %t884 = getelementptr %"compiler/parse:Parser", ptr %t882, i32 0, i32 30
  %t885 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t884, i64 %t885)
  br label %bb199
bb199:
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t889 = load i32, ptr %l1, !tbaa !23
  %t892 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t888, i32 %t889)
  store %"compiler/source:Span" %t892, ptr %l326
  br label %bb200
bb200:
  %t893 = load %"compiler/source:Span", ptr %l326
  store %"compiler/source:Span" %t893, ptr %l26
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t896 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t894)
  store i32 %t896, ptr %l328
  %t897 = icmp ne i32 %t896, 0
  br i1 %t897, label %bb202, label %ok.898
ok.898:
  br label %bb201
bb201:
  br label %bb203
bb202:
  %t899 = load i32, ptr %l328, !tbaa !23
  %t900 = lshr i32 %t899, 16
  %t901 = and i32 %t899, 65535
  %t902 = icmp eq i32 %t900, 1
  %t903 = select i1 %t902, i32 1, i32 0
  %t904 = icmp eq i32 %t899, 0
  %t905 = shl i32 %t903, 16
  %t906 = or i32 %t905, %t901
  %t907 = select i1 %t904, i32 0, i32 %t906
  %t909 = insertvalue { i32, ptr } zeroinitializer, i32 %t907, 0
  store { i32, ptr } %t909, ptr %rv
  br label %ret
bb203:
  %t910 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t910, ptr %l330
  %t911 = icmp sge i64 0, 0
  br i1 %t911, label %bb204, label %bb205
bb204:
  %t913 = icmp sle i64 0, 1152921504606846975
  br i1 %t913, label %bb206, label %bb207
bb205:
  call void @__olang_check_failed(ptr @olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd)
  unreachable
bb206:
  %t915 = mul i64 0, 8
  %t916 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t915)
  %t917 = insertvalue { i64, ptr } undef, i64 0, 0
  %t918 = insertvalue { i64, ptr } %t917, ptr %t916, 1
  %t919 = load ptr, ptr %lp25
  %t920 = load ptr, ptr %t919, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t921
  %t922 = getelementptr { i64, [4 x i64] }, ptr %t921, i32 0, i32 0
  store i64 16, ptr %t922
  %t923 = load %"compiler/source:Span", ptr %l330
  %t924 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t923, 0
  %t926 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t924, { i64, ptr } %t918, 1
  %t928 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t926, ptr %t920, 2
  %t929 = getelementptr { i64, [4 x i64] }, ptr %t921, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t928, ptr %t929
  %t930 = load { i64, [4 x i64] }, ptr %t921
  %t932 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t930, ptr %t932
  %t934 = insertvalue { i32, ptr } zeroinitializer, ptr %t932, 1
  store { i32, ptr } %t934, ptr %rv
  br label %ret
bb207:
  call void @__olang_check_failed(ptr @olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd)
  unreachable
bb208:
  %t935 = load i32, ptr %l2
  %t937 = trunc i64 14 to i32
  %t938 = icmp eq i32 %t935, %t937
  br i1 %t938, label %bb209, label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb216
bb211:
  %t940 = load ptr, ptr %l0, !tbaa !29
  %t942 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %t940, i1 false)
  %t943 = extractvalue { i32, ptr } %t942, 1
  %t944 = extractvalue { i32, ptr } %t942, 0
  store i32 %t944, ptr %l342
  %t945 = icmp ne i32 %t944, 0
  br i1 %t945, label %bb213, label %ok.946
ok.946:
  store ptr %t943, ptr %l341
  br label %bb212
bb212:
  %t947 = load ptr, ptr %l341, !tbaa !29
  store ptr %t947, ptr %l339, !tbaa !29
  br label %bb214
bb213:
  %t948 = load i32, ptr %l342, !tbaa !23
  %t949 = lshr i32 %t948, 16
  %t950 = and i32 %t948, 65535
  %t951 = icmp eq i32 %t949, 1
  %t952 = select i1 %t951, i32 1, i32 0
  %t953 = icmp eq i32 %t948, 0
  %t954 = shl i32 %t952, 16
  %t955 = or i32 %t954, %t950
  %t956 = select i1 %t953, i32 0, i32 %t955
  %t958 = insertvalue { i32, ptr } zeroinitializer, i32 %t956, 0
  store { i32, ptr } %t958, ptr %rv
  br label %ret
bb214:
  %t959 = load ptr, ptr %l339, !tbaa !29
  store ptr %t959, ptr %l27, !tbaa !29
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t961 = load i32, ptr %l1, !tbaa !23
  %t964 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t960, i32 %t961)
  store %"compiler/source:Span" %t964, ptr %l346
  br label %bb215
bb215:
  %t965 = load ptr, ptr %l27, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t966
  %t967 = getelementptr { i64, [4 x i64] }, ptr %t966, i32 0, i32 0
  store i64 17, ptr %t967
  %t968 = load %"compiler/source:Span", ptr %l346
  %t969 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t968, 0
  %t971 = insertvalue { %"compiler/source:Span", ptr } %t969, ptr %t965, 1
  %t972 = getelementptr { i64, [4 x i64] }, ptr %t966, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t971, ptr %t972
  %t973 = load { i64, [4 x i64] }, ptr %t966
  %t975 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t973, ptr %t975
  %t977 = insertvalue { i32, ptr } zeroinitializer, ptr %t975, 1
  store { i32, ptr } %t977, ptr %rv
  br label %ret
bb216:
  %t978 = load i32, ptr %l2
  %t980 = trunc i64 16 to i32
  %t981 = icmp eq i32 %t978, %t980
  br i1 %t981, label %bb217, label %bb218
bb217:
  br label %bb221
bb218:
  %t983 = load i32, ptr %l2
  %t985 = trunc i64 17 to i32
  %t986 = icmp eq i32 %t983, %t985
  br i1 %t986, label %bb219, label %bb220
bb219:
  br label %bb221
bb220:
  br label %bb241
bb221:
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t991 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t988, i32 17)
  store i1 %t991, ptr %l356
  br label %bb222
bb222:
  %t992 = load i1, ptr %l356, !tbaa !21
  store i1 %t992, ptr %l28, !tbaa !21
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t995 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t993)
  store i32 %t995, ptr %l358
  br label %bb223
bb223:
  %t996 = load ptr, ptr %l0, !tbaa !29
  %t999 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t996, i32 94)
  store i1 %t999, ptr %l361
  br label %bb224
bb224:
  %t1000 = load i1, ptr %l361, !tbaa !21
  br i1 %t1000, label %bb225, label %bb226
bb225:
  %t1001 = load ptr, ptr %l0, !tbaa !29
  %t1003 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t1001)
  %t1004 = extractvalue { i32, { i64, ptr } } %t1003, 1
  %t1005 = extractvalue { i32, { i64, ptr } } %t1003, 0
  store i32 %t1005, ptr %l365
  %t1006 = icmp ne i32 %t1005, 0
  br i1 %t1006, label %bb228, label %ok.1007
ok.1007:
  store { i64, ptr } %t1004, ptr %l364
  br label %bb227
bb226:
  br label %bb236
bb227:
  %t1008 = load { i64, ptr }, ptr %l364, !tbaa !27
  store { i64, ptr } %t1008, ptr %l362, !tbaa !27
  br label %bb229
bb228:
  %t1009 = load i32, ptr %l365, !tbaa !23
  %t1010 = lshr i32 %t1009, 16
  %t1011 = and i32 %t1009, 65535
  %t1012 = icmp eq i32 %t1010, 1
  %t1013 = select i1 %t1012, i32 1, i32 0
  %t1014 = icmp eq i32 %t1009, 0
  %t1015 = shl i32 %t1013, 16
  %t1016 = or i32 %t1015, %t1011
  %t1017 = select i1 %t1014, i32 0, i32 %t1016
  %t1019 = insertvalue { i32, ptr } zeroinitializer, i32 %t1017, 0
  store { i32, ptr } %t1019, ptr %rv
  br label %ret
bb229:
  %t1020 = load { i64, ptr }, ptr %l362, !tbaa !27
  store { i64, ptr } %t1020, ptr %l29, !tbaa !27
  %t1021 = load ptr, ptr %l0, !tbaa !29
  %t1022 = load i32, ptr %l1, !tbaa !23
  %t1025 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1021, i32 %t1022)
  store %"compiler/source:Span" %t1025, ptr %l369
  br label %bb230
bb230:
  %t1026 = load %"compiler/source:Span", ptr %l369
  store %"compiler/source:Span" %t1026, ptr %l30
  %t1027 = load ptr, ptr %l0, !tbaa !29
  %t1030 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1027, i32 8)
  store i1 %t1030, ptr %l372
  br label %bb231
bb231:
  %t1031 = load i1, ptr %l372, !tbaa !21
  br i1 %t1031, label %bb232, label %bb233
bb232:
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1034 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1032)
  store i32 %t1034, ptr %l374
  br label %bb234
bb233:
  br label %bb235
bb234:
  br label %bb235
bb235:
  %t1035 = load %"compiler/source:Span", ptr %l30
  %t1036 = load %"compiler/source:Span", ptr %l30
  %t1037 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t1038
  %t1039 = getelementptr { i64, [4 x i64] }, ptr %t1038, i32 0, i32 0
  store i64 19, ptr %t1039
  %t1041 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t1036, 0
  %t1043 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t1041, { i64, ptr } %t1037, 1
  %t1044 = getelementptr { i64, [4 x i64] }, ptr %t1038, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t1043, ptr %t1044
  %t1045 = load { i64, [4 x i64] }, ptr %t1038
  %t1047 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1045, ptr %t1047
  %t1048 = load i1, ptr %l28, !tbaa !21
  store { i64, [4 x i64] } zeroinitializer, ptr %t1049
  %t1050 = getelementptr { i64, [4 x i64] }, ptr %t1049, i32 0, i32 0
  store i64 18, ptr %t1050
  %t1052 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t1035, 0
  %t1054 = insertvalue { %"compiler/source:Span", ptr, i1 } %t1052, ptr %t1047, 1
  %t1056 = insertvalue { %"compiler/source:Span", ptr, i1 } %t1054, i1 %t1048, 2
  %t1057 = getelementptr { i64, [4 x i64] }, ptr %t1049, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t1056, ptr %t1057
  %t1058 = load { i64, [4 x i64] }, ptr %t1049
  %t1060 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1058, ptr %t1060
  %t1062 = insertvalue { i32, ptr } zeroinitializer, ptr %t1060, 1
  store { i32, ptr } %t1062, ptr %rv
  br label %ret
bb236:
  %t1063 = load ptr, ptr %l0, !tbaa !29
  %t1065 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %t1063)
  %t1066 = extractvalue { i32, ptr } %t1065, 1
  %t1067 = extractvalue { i32, ptr } %t1065, 0
  store i32 %t1067, ptr %l386
  %t1068 = icmp ne i32 %t1067, 0
  br i1 %t1068, label %bb238, label %ok.1069
ok.1069:
  store ptr %t1066, ptr %l385
  br label %bb237
bb237:
  %t1070 = load ptr, ptr %l385, !tbaa !29
  store ptr %t1070, ptr %l383, !tbaa !29
  br label %bb239
bb238:
  %t1071 = load i32, ptr %l386, !tbaa !23
  %t1072 = lshr i32 %t1071, 16
  %t1073 = and i32 %t1071, 65535
  %t1074 = icmp eq i32 %t1072, 1
  %t1075 = select i1 %t1074, i32 1, i32 0
  %t1076 = icmp eq i32 %t1071, 0
  %t1077 = shl i32 %t1075, 16
  %t1078 = or i32 %t1077, %t1073
  %t1079 = select i1 %t1076, i32 0, i32 %t1078
  %t1081 = insertvalue { i32, ptr } zeroinitializer, i32 %t1079, 0
  store { i32, ptr } %t1081, ptr %rv
  br label %ret
bb239:
  %t1082 = load ptr, ptr %l383, !tbaa !29
  store ptr %t1082, ptr %l31, !tbaa !29
  %t1083 = load ptr, ptr %l0, !tbaa !29
  %t1084 = load i32, ptr %l1, !tbaa !23
  %t1087 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1083, i32 %t1084)
  store %"compiler/source:Span" %t1087, ptr %l390
  br label %bb240
bb240:
  %t1088 = load ptr, ptr %l31, !tbaa !29
  %t1089 = load i1, ptr %l28, !tbaa !21
  store { i64, [4 x i64] } zeroinitializer, ptr %t1090
  %t1091 = getelementptr { i64, [4 x i64] }, ptr %t1090, i32 0, i32 0
  store i64 18, ptr %t1091
  %t1092 = load %"compiler/source:Span", ptr %l390
  %t1093 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t1092, 0
  %t1095 = insertvalue { %"compiler/source:Span", ptr, i1 } %t1093, ptr %t1088, 1
  %t1097 = insertvalue { %"compiler/source:Span", ptr, i1 } %t1095, i1 %t1089, 2
  %t1098 = getelementptr { i64, [4 x i64] }, ptr %t1090, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t1097, ptr %t1098
  %t1099 = load { i64, [4 x i64] }, ptr %t1090
  %t1101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1099, ptr %t1101
  %t1103 = insertvalue { i32, ptr } zeroinitializer, ptr %t1101, 1
  store { i32, ptr } %t1103, ptr %rv
  br label %ret
bb241:
  %t1104 = load i32, ptr %l2
  %t1106 = trunc i64 94 to i32
  %t1107 = icmp eq i32 %t1104, %t1106
  br i1 %t1107, label %bb242, label %bb243
bb242:
  br label %bb244
bb243:
  br label %bb254
bb244:
  %t1109 = load ptr, ptr %l0, !tbaa !29
  %t1111 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t1109)
  %t1112 = extractvalue { i32, { i64, ptr } } %t1111, 1
  %t1113 = extractvalue { i32, { i64, ptr } } %t1111, 0
  store i32 %t1113, ptr %l400
  %t1114 = icmp ne i32 %t1113, 0
  br i1 %t1114, label %bb246, label %ok.1115
ok.1115:
  store { i64, ptr } %t1112, ptr %l399
  br label %bb245
bb245:
  %t1116 = load { i64, ptr }, ptr %l399, !tbaa !27
  store { i64, ptr } %t1116, ptr %l397, !tbaa !27
  br label %bb247
bb246:
  %t1117 = load i32, ptr %l400, !tbaa !23
  %t1118 = lshr i32 %t1117, 16
  %t1119 = and i32 %t1117, 65535
  %t1120 = icmp eq i32 %t1118, 1
  %t1121 = select i1 %t1120, i32 1, i32 0
  %t1122 = icmp eq i32 %t1117, 0
  %t1123 = shl i32 %t1121, 16
  %t1124 = or i32 %t1123, %t1119
  %t1125 = select i1 %t1122, i32 0, i32 %t1124
  %t1127 = insertvalue { i32, ptr } zeroinitializer, i32 %t1125, 0
  store { i32, ptr } %t1127, ptr %rv
  br label %ret
bb247:
  %t1128 = load { i64, ptr }, ptr %l397, !tbaa !27
  store { i64, ptr } %t1128, ptr %l32, !tbaa !27
  %t1129 = load ptr, ptr %l0, !tbaa !29
  %t1130 = load i32, ptr %l1, !tbaa !23
  %t1133 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1129, i32 %t1130)
  store %"compiler/source:Span" %t1133, ptr %l404
  br label %bb248
bb248:
  %t1134 = load %"compiler/source:Span", ptr %l404
  store %"compiler/source:Span" %t1134, ptr %l33
  %t1135 = load ptr, ptr %l0, !tbaa !29
  %t1138 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1135, i32 8)
  store i1 %t1138, ptr %l407
  br label %bb249
bb249:
  %t1139 = load i1, ptr %l407, !tbaa !21
  br i1 %t1139, label %bb250, label %bb251
bb250:
  %t1140 = load ptr, ptr %l0, !tbaa !29
  %t1142 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1140)
  store i32 %t1142, ptr %l409
  br label %bb252
bb251:
  br label %bb253
bb252:
  br label %bb253
bb253:
  %t1143 = load %"compiler/source:Span", ptr %l33
  %t1144 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t1145
  %t1146 = getelementptr { i64, [4 x i64] }, ptr %t1145, i32 0, i32 0
  store i64 19, ptr %t1146
  %t1148 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t1143, 0
  %t1150 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t1148, { i64, ptr } %t1144, 1
  %t1151 = getelementptr { i64, [4 x i64] }, ptr %t1145, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t1150, ptr %t1151
  %t1152 = load { i64, [4 x i64] }, ptr %t1145
  %t1154 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1152, ptr %t1154
  %t1156 = insertvalue { i32, ptr } zeroinitializer, ptr %t1154, 1
  store { i32, ptr } %t1156, ptr %rv
  br label %ret
bb254:
  %t1157 = load i32, ptr %l2
  %t1159 = trunc i64 11 to i32
  %t1160 = icmp eq i32 %t1157, %t1159
  br i1 %t1160, label %bb255, label %bb256
bb255:
  br label %bb257
bb256:
  br label %bb261
bb257:
  %t1162 = load ptr, ptr %l0, !tbaa !29
  %t1164 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %t1162)
  %t1165 = extractvalue { i32, ptr } %t1164, 1
  %t1166 = extractvalue { i32, ptr } %t1164, 0
  store i32 %t1166, ptr %l419
  %t1167 = icmp ne i32 %t1166, 0
  br i1 %t1167, label %bb259, label %ok.1168
ok.1168:
  store ptr %t1165, ptr %l418
  br label %bb258
bb258:
  %t1169 = load ptr, ptr %l418, !tbaa !29
  store ptr %t1169, ptr %l416, !tbaa !29
  br label %bb260
bb259:
  %t1170 = load i32, ptr %l419, !tbaa !23
  %t1171 = lshr i32 %t1170, 16
  %t1172 = and i32 %t1170, 65535
  %t1173 = icmp eq i32 %t1171, 1
  %t1174 = select i1 %t1173, i32 1, i32 0
  %t1175 = icmp eq i32 %t1170, 0
  %t1176 = shl i32 %t1174, 16
  %t1177 = or i32 %t1176, %t1172
  %t1178 = select i1 %t1175, i32 0, i32 %t1177
  %t1180 = insertvalue { i32, ptr } zeroinitializer, i32 %t1178, 0
  store { i32, ptr } %t1180, ptr %rv
  br label %ret
bb260:
  %t1181 = load ptr, ptr %l416, !tbaa !29
  %t1182 = insertvalue { i32, ptr } zeroinitializer, ptr %t1181, 1
  store { i32, ptr } %t1182, ptr %rv
  br label %ret
bb261:
  %t1183 = load i32, ptr %l2
  %t1185 = trunc i64 1 to i32
  %t1186 = icmp eq i32 %t1183, %t1185
  br i1 %t1186, label %bb262, label %bb263
bb262:
  br label %bb264
bb263:
  br label %bb268
bb264:
  %t1188 = load ptr, ptr %l0, !tbaa !29
  %t1190 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eidenStmt(ptr %v0, ptr %t1188)
  %t1191 = extractvalue { i32, ptr } %t1190, 1
  %t1192 = extractvalue { i32, ptr } %t1190, 0
  store i32 %t1192, ptr %l426
  %t1193 = icmp ne i32 %t1192, 0
  br i1 %t1193, label %bb266, label %ok.1194
ok.1194:
  store ptr %t1191, ptr %l425
  br label %bb265
bb265:
  %t1195 = load ptr, ptr %l425, !tbaa !29
  store ptr %t1195, ptr %l423, !tbaa !29
  br label %bb267
bb266:
  %t1196 = load i32, ptr %l426, !tbaa !23
  %t1197 = lshr i32 %t1196, 16
  %t1198 = and i32 %t1196, 65535
  %t1199 = icmp eq i32 %t1197, 1
  %t1200 = select i1 %t1199, i32 1, i32 0
  %t1201 = icmp eq i32 %t1196, 0
  %t1202 = shl i32 %t1200, 16
  %t1203 = or i32 %t1202, %t1198
  %t1204 = select i1 %t1201, i32 0, i32 %t1203
  %t1206 = insertvalue { i32, ptr } zeroinitializer, i32 %t1204, 0
  store { i32, ptr } %t1206, ptr %rv
  br label %ret
bb267:
  %t1207 = load ptr, ptr %l423, !tbaa !29
  %t1208 = insertvalue { i32, ptr } zeroinitializer, ptr %t1207, 1
  store { i32, ptr } %t1208, ptr %rv
  br label %ret
bb268:
  %t1209 = load ptr, ptr %l0, !tbaa !29
  %t1211 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %t1209)
  %t1212 = extractvalue { i32, ptr } %t1211, 1
  %t1213 = extractvalue { i32, ptr } %t1211, 0
  store i32 %t1213, ptr %l431
  %t1214 = icmp ne i32 %t1213, 0
  br i1 %t1214, label %bb270, label %ok.1215
ok.1215:
  store ptr %t1212, ptr %l430
  br label %bb269
bb269:
  %t1216 = load ptr, ptr %l430, !tbaa !29
  store ptr %t1216, ptr %l428, !tbaa !29
  br label %bb271
bb270:
  %t1217 = load i32, ptr %l431, !tbaa !23
  %t1218 = lshr i32 %t1217, 16
  %t1219 = and i32 %t1217, 65535
  %t1220 = icmp eq i32 %t1218, 1
  %t1221 = select i1 %t1220, i32 1, i32 0
  %t1222 = icmp eq i32 %t1217, 0
  %t1223 = shl i32 %t1221, 16
  %t1224 = or i32 %t1223, %t1219
  %t1225 = select i1 %t1222, i32 0, i32 %t1224
  %t1227 = insertvalue { i32, ptr } zeroinitializer, i32 %t1225, 0
  store { i32, ptr } %t1227, ptr %rv
  br label %ret
bb271:
  %t1228 = load ptr, ptr %l428, !tbaa !29
  %t1229 = insertvalue { i32, ptr } zeroinitializer, ptr %t1228, 1
  store { i32, ptr } %t1229, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncItem(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca %"compiler/token:Token"
  %l11 = alloca %"compiler/token:Token"
  %l16 = alloca i1
  %l20 = alloca i32
  %l32 = alloca %"compiler/token:Token"
  %l35 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 7
  store i32 0, ptr %t9
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 11
  store i1 false, ptr %t12, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t13)
  store %"compiler/token:Token" %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t16, ptr %l3
  %t17 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t18 = load i32, ptr %t17
  %t20 = trunc i64 0 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t23 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 95 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l20
  br label %bb12
bb12:
  %t37 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t38 = load i32, ptr %t37
  %t40 = trunc i64 94 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb38
bb14:
  %t47 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t48 = load i32, ptr %t47
  %t50 = trunc i64 95 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t55 = sub i64 %t53, 1
  store i64 %t55, ptr %l2, !tbaa !24
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = icmp eq i64 %t57, 0
  br i1 %t59, label %bb17, label %bb18
bb16:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb31, label %bb32
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t65)
  store %"compiler/token:Token" %t67, ptr %l32
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t68 = load %"compiler/token:Token", ptr %l32
  store %"compiler/token:Token" %t68, ptr %l4
  %t69 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 0
  %t70 = load i32, ptr %t69
  %t72 = trunc i64 0 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  %t75 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 0
  %t76 = load i32, ptr %t75
  %t78 = trunc i64 8 to i32
  %t79 = icmp eq i32 %t76, %t78
  store i1 %t79, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb26
bb24:
  %t82 = load %"compiler/token:Token", ptr %l4
  %t83 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t86 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t82, i8 %t83)
  store i1 %t86, ptr %l41
  br label %bb25
bb25:
  %t87 = load i1, ptr %l41, !tbaa !21
  store i1 %t87, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l38, !tbaa !21
  br i1 %t88, label %bb27, label %bb28
bb27:
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb37
bb31:
  %t89 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t90 = load i32, ptr %t89
  %t92 = trunc i64 8 to i32
  %t93 = icmp eq i32 %t90, %t92
  store i1 %t93, ptr %l44, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb33
bb33:
  %t95 = load i1, ptr %l44, !tbaa !21
  br i1 %t95, label %bb34, label %bb35
bb34:
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb1
ret:
  ret void
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etextPieceCalled(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %l16 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i64
  %l42 = alloca i32
  %l45 = alloca i1
  %l48 = alloca i32
  %l51 = alloca i1
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca %"compiler/msgs:Msg"
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t20, 1
  %t23 = load i64, ptr %l16, !tbaa !24
  %t25 = icmp sge i64 %t23, %t22
  store i1 %t25, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t30 = load i64, ptr %l4, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = sub i64 %t32, 1
  store i64 %t34, ptr %l4, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/parse:Parser", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/scan:Tokens", ptr %t42, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t50 = icmp slt i64 %t38, %t47
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l34, !tbaa !24
  %t60 = icmp sle i64 %t58, %t57
  store i1 %t60, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t62 = load i1, ptr %l31, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb17, label %bb18
bb17:
  br label %bb39
bb18:
  br label %bb19
bb19:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l5, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t69, i64 %t70)
  store i32 %t73, ptr %l42
  br label %bb20
bb20:
  %t74 = load i32, ptr %l42
  %t76 = trunc i64 5 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb21, label %bb22
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l5, !tbaa !24
  %t83 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t79, i64 %t80)
  store i32 %t83, ptr %l48
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  %t84 = load i32, ptr %l48
  %t86 = trunc i64 90 to i32
  %t87 = icmp eq i32 %t84, %t86
  store i1 %t87, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t89 = load i1, ptr %l45, !tbaa !21
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l54
  br label %bb27
bb26:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb29
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t95, i64 %t96)
  store i64 %t99, ptr %l57
  br label %bb28
bb28:
  %t100 = load i64, ptr %l54, !tbaa !24
  %t101 = load i64, ptr %l57, !tbaa !24
  %t102 = icmp eq i64 %t100, %t101
  store i1 %t102, ptr %l51, !tbaa !21
  br label %bb29
bb29:
  %t104 = load i1, ptr %l51, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load i64, ptr %l5, !tbaa !24
  store i64 %t106, ptr %l60, !tbaa !24
  %t107 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s3)
  store %"compiler/msgs:Msg" %t107, ptr %l61
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t108 = load ptr, ptr %l59, !tbaa !29
  %t109 = load i64, ptr %l60, !tbaa !24
  %t110 = load %"compiler/msgs:Msg", ptr %l61
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s3, ptr %t108, i64 %t109, %"compiler/msgs:Msg" %t110)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb34:
  %t112 = load i64, ptr %l5, !tbaa !24
  %t113 = load i64, ptr %l1, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb35, label %bb36
bb35:
  br label %bb39
bb36:
  br label %bb37
bb37:
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l4, !tbaa !24
  br label %bb38
bb38:
  br label %bb12
bb39:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t31 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store ptr %t8, ptr %l7
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l7, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l5, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t25, i32 %t26)
  store %"compiler/source:Span" %t29, ptr %l12
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l2, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [6 x i64] }, ptr %t31, i32 0, i32 0
  store i64 7, ptr %t32
  %t33 = load %"compiler/source:Span", ptr %l12
  %t34 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t33, 0
  %t36 = insertvalue { %"compiler/source:Span", ptr } %t34, ptr %t30, 1
  %t37 = getelementptr { i64, [6 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t36, ptr %t37
  %t38 = load { i64, [6 x i64] }, ptr %t31
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t38, ptr %t40
  %t42 = insertvalue { i32, ptr } zeroinitializer, ptr %t40, 1
  store { i32, ptr } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l23 = alloca i1
  %l29 = alloca %"compiler/ast:TopIf"
  %l33 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l45 = alloca %"compiler/ast:TopIf"
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i32
  %l58 = alloca %"compiler/ast:TopIf"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 9)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l9
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t21)
  %t24 = extractvalue { i32, ptr } %t23, 1
  %t25 = extractvalue { i32, ptr } %t23, 0
  store i32 %t25, ptr %l14
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27
ok.27:
  store ptr %t24, ptr %l13
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l13, !tbaa !29
  store ptr %t28, ptr %l11, !tbaa !29
  br label %bb6
bb5:
  %t29 = load i32, ptr %l14, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 %t37, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load ptr, ptr %l11, !tbaa !29
  store ptr %t40, ptr %l1, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %t41)
  %t44 = extractvalue { i32, ptr } %t43, 1
  %t45 = extractvalue { i32, ptr } %t43, 0
  store i32 %t45, ptr %l19
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47
ok.47:
  store ptr %t44, ptr %l18
  br label %bb7
bb7:
  %t48 = load ptr, ptr %l18, !tbaa !29
  store ptr %t48, ptr %l16, !tbaa !29
  br label %bb9
bb8:
  %t49 = load i32, ptr %l19, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb9:
  %t60 = load ptr, ptr %l16, !tbaa !29
  store ptr %t60, ptr %l2, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t61, i32 10)
  store i1 %t64, ptr %l23
  br label %bb10
bb10:
  %t65 = load i1, ptr %l23, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t74 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t68, ptr %t70, ptr null, ptr null)
  store %"compiler/ast:TopIf" %t74, ptr %l29
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t75 = load %"compiler/ast:TopIf", ptr %l29
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t75, ptr %t76
  %t78 = insertvalue { i32, ptr } zeroinitializer, ptr %t76, 1
  store { i32, ptr } %t78, ptr %rv
  br label %ret
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t79, i32 9)
  store i1 %t82, ptr %l33
  br label %bb15
bb15:
  %t83 = load i1, ptr %l33, !tbaa !21
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %t84)
  %t87 = extractvalue { i32, ptr } %t86, 1
  %t88 = extractvalue { i32, ptr } %t86, 0
  store i32 %t88, ptr %l37
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb19, label %ok.90
ok.90:
  store ptr %t87, ptr %l36
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t91 = load ptr, ptr %l36, !tbaa !29
  store ptr %t91, ptr %l34, !tbaa !29
  br label %bb20
bb19:
  %t92 = load i32, ptr %l37, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  %t102 = insertvalue { i32, ptr } zeroinitializer, i32 %t100, 0
  store { i32, ptr } %t102, ptr %rv
  br label %ret
bb20:
  %t103 = load ptr, ptr %l34, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t113 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t104, ptr %t106, ptr %t103, ptr null)
  store %"compiler/ast:TopIf" %t113, ptr %l45
  br label %bb21
bb21:
  %t114 = load %"compiler/ast:TopIf", ptr %l45
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t114, ptr %t115
  %t117 = insertvalue { i32, ptr } zeroinitializer, ptr %t115, 1
  store { i32, ptr } %t117, ptr %rv
  br label %ret
bb22:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %t118)
  %t121 = extractvalue { i32, ptr } %t120, 1
  %t122 = extractvalue { i32, ptr } %t120, 0
  store i32 %t122, ptr %l50
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb24, label %ok.124
ok.124:
  store ptr %t121, ptr %l49
  br label %bb23
bb23:
  %t125 = load ptr, ptr %l49, !tbaa !29
  store ptr %t125, ptr %l47, !tbaa !29
  br label %bb25
bb24:
  %t126 = load i32, ptr %l50, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  %t136 = insertvalue { i32, ptr } zeroinitializer, i32 %t134, 0
  store { i32, ptr } %t136, ptr %rv
  br label %ret
bb25:
  %t137 = load ptr, ptr %l47, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t147 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t138, ptr %t140, ptr null, ptr %t137)
  store %"compiler/ast:TopIf" %t147, ptr %l58
  br label %bb26
bb26:
  %t148 = load %"compiler/ast:TopIf", ptr %l58
  %t149 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t148, ptr %t149
  %t151 = insertvalue { i32, ptr } zeroinitializer, ptr %t149, 1
  store { i32, ptr } %t151, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etrailing(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1
  %t5 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t7)
  store i1 %t9, ptr %l7
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l9, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 10
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sub i32 %t18, 1
  store i32 %t20, ptr %l12, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 10
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l14, !tbaa !23
  %t25 = load i32, ptr %l1
  %t27 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t25)
  store { i64, ptr } %t27, ptr %l16
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s1, ptr %s1, { i64, ptr } %t28)
  store { i64, ptr } %t29, ptr %l17
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %s1, ptr %s1, { i64, ptr } %t36)
  store %"compiler/msgs:Msg" %t38, ptr %l19
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l9, !tbaa !29
  %t40 = load i32, ptr %l12, !tbaa !23
  %t41 = load i32, ptr %l14, !tbaa !23
  %t42 = load %"compiler/msgs:Msg", ptr %l19
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s1, ptr %t39, i32 %t40, i32 %t41, %"compiler/msgs:Msg" %t42)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %rv
  br label %ret
bb12:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %rv = alloca { i32, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l1, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = insertvalue { i32, ptr } zeroinitializer, ptr %t20, 1
  store { i32, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsShape(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i1
  %l22 = alloca i32
  %l28 = alloca %"compiler/token:Token"
  %l32 = alloca %"compiler/token:Token"
  %l44 = alloca i32
  %l71 = alloca i1
  %l75 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l87 = alloca i1
  %l91 = alloca i1
  %l95 = alloca i1
  %l107 = alloca i1
  %l111 = alloca i32
  %l117 = alloca i1
  %l120 = alloca %"compiler/token:Token"
  %l121 = alloca i32
  %l125 = alloca %"compiler/token:Token"
  %l132 = alloca i32
  %l135 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10
  %t8 = trunc i64 79 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t13, i32 0, i32 7
  %t16 = load i32, ptr %t15
  %t18 = trunc i64 0 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  store i1 %t21, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 10
  %t32 = load i32, ptr %t31, !tbaa !23
  store i32 %t32, ptr %l22, !tbaa !23
  br label %bb11
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = sub i64 %t35, 1
  %t40 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t34, i64 %t37)
  store %"compiler/token:Token" %t40, ptr %l28
  br label %bb10
bb10:
  %t41 = getelementptr %"compiler/token:Token", ptr %l28, i32 0, i32 3
  %t42 = load i32, ptr %t41, !tbaa !23
  store i32 %t42, ptr %l22, !tbaa !23
  br label %bb11
bb11:
  %t44 = load i32, ptr %l22, !tbaa !23
  store i32 %t44, ptr %l2, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  %t49 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t45, i64 %t46)
  store %"compiler/token:Token" %t49, ptr %l32
  br label %bb12
bb12:
  %t50 = getelementptr %"compiler/token:Token", ptr %l32, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = icmp eq i32 %t51, %t52
  store i1 %t55, ptr %l3, !tbaa !21
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l1, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = add i64 %t60, 256
  %t65 = icmp slt i64 %t59, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb14, label %bb15
bb14:
  br label %bb86
bb15:
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t69, i64 %t70)
  store i32 %t73, ptr %l44
  br label %bb17
bb17:
  %t74 = load i32, ptr %l44
  store i32 %t74, ptr %l7
  %t75 = load i32, ptr %l7
  %t77 = trunc i64 79 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb18, label %bb19
bb18:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l4, !tbaa !24
  br label %bb59
bb19:
  %t84 = load i32, ptr %l7
  %t86 = trunc i64 81 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb20, label %bb21
bb20:
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = sub i64 %t89, 1
  store i64 %t91, ptr %l4, !tbaa !24
  br label %bb58
bb21:
  %t93 = load i32, ptr %l7
  %t95 = trunc i64 89 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t100 = sub i64 %t98, 2
  store i64 %t100, ptr %l4, !tbaa !24
  br label %bb57
bb23:
  %t102 = load i32, ptr %l7
  %t104 = trunc i64 90 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb24, label %bb25
bb24:
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l5, !tbaa !24
  br label %bb56
bb25:
  %t111 = load i32, ptr %l7
  %t113 = trunc i64 91 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb26, label %bb27
bb26:
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb28, label %bb29
bb27:
  %t120 = load i32, ptr %l7
  %t122 = trunc i64 1 to i32
  %t123 = icmp eq i32 %t120, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb31, label %bb32
bb28:
  store i64 0, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t128 = load i64, ptr %l5, !tbaa !24
  %t130 = sub i64 %t128, 1
  store i64 %t130, ptr %l5, !tbaa !24
  br label %bb55
bb31:
  %t132 = load i32, ptr %l7
  %t134 = trunc i64 58 to i32
  %t135 = icmp eq i32 %t132, %t134
  %t137 = xor i1 %t135, true
  store i1 %t137, ptr %l71, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  %t139 = load i1, ptr %l71, !tbaa !21
  br i1 %t139, label %bb34, label %bb35
bb34:
  %t140 = load i32, ptr %l7
  %t142 = trunc i64 57 to i32
  %t143 = icmp eq i32 %t140, %t142
  %t145 = xor i1 %t143, true
  store i1 %t145, ptr %l75, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb36
bb36:
  %t147 = load i1, ptr %l75, !tbaa !21
  br i1 %t147, label %bb37, label %bb38
bb37:
  %t148 = load i32, ptr %l7
  %t150 = trunc i64 83 to i32
  %t151 = icmp eq i32 %t148, %t150
  %t153 = xor i1 %t151, true
  store i1 %t153, ptr %l79, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb39
bb39:
  %t155 = load i1, ptr %l79, !tbaa !21
  br i1 %t155, label %bb40, label %bb41
bb40:
  %t156 = load i32, ptr %l7
  %t158 = trunc i64 59 to i32
  %t159 = icmp eq i32 %t156, %t158
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l83, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb42
bb42:
  %t163 = load i1, ptr %l83, !tbaa !21
  br i1 %t163, label %bb43, label %bb44
bb43:
  %t164 = load i32, ptr %l7
  %t166 = trunc i64 40 to i32
  %t167 = icmp eq i32 %t164, %t166
  %t169 = xor i1 %t167, true
  store i1 %t169, ptr %l87, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb45
bb45:
  %t171 = load i1, ptr %l87, !tbaa !21
  br i1 %t171, label %bb46, label %bb47
bb46:
  %t172 = load i32, ptr %l7
  %t174 = trunc i64 38 to i32
  %t175 = icmp eq i32 %t172, %t174
  %t177 = xor i1 %t175, true
  store i1 %t177, ptr %l91, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb48
bb48:
  %t179 = load i1, ptr %l91, !tbaa !21
  br i1 %t179, label %bb49, label %bb50
bb49:
  %t180 = load i32, ptr %l7
  %t182 = trunc i64 13 to i32
  %t183 = icmp eq i32 %t180, %t182
  %t185 = xor i1 %t183, true
  store i1 %t185, ptr %l95, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb51
bb51:
  %t187 = load i1, ptr %l95, !tbaa !21
  br i1 %t187, label %bb52, label %bb53
bb52:
  store i64 0, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t189 = load i64, ptr %l4, !tbaa !24
  %t191 = icmp slt i64 %t189, 0
  br i1 %t191, label %bb60, label %bb61
bb60:
  store i64 0, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t194 = load i64, ptr %l4, !tbaa !24
  %t196 = icmp eq i64 %t194, 0
  br i1 %t196, label %bb63, label %bb64
bb63:
  %t198 = load i64, ptr %l5, !tbaa !24
  %t200 = icmp ne i64 %t198, 0
  br i1 %t200, label %bb65, label %bb66
bb64:
  br label %bb84
bb65:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb68
bb66:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l6, !tbaa !24
  %t205 = add i64 %t203, 1
  %t208 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t202, i64 %t205)
  store i32 %t208, ptr %l111
  br label %bb67
bb67:
  %t209 = load i32, ptr %l111
  %t211 = trunc i64 90 to i32
  %t212 = icmp eq i32 %t209, %t211
  %t214 = xor i1 %t212, true
  store i1 %t214, ptr %l107, !tbaa !21
  br label %bb68
bb68:
  %t216 = load i1, ptr %l107, !tbaa !21
  br i1 %t216, label %bb69, label %bb70
bb69:
  store i64 0, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  %t218 = load i1, ptr %l3, !tbaa !21
  br i1 %t218, label %bb72, label %bb73
bb72:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i64, ptr %l6, !tbaa !24
  %t224 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t220, i64 %t221)
  store %"compiler/token:Token" %t224, ptr %l120
  br label %bb74
bb73:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb76
bb74:
  %t225 = getelementptr %"compiler/token:Token", ptr %l120, i32 0, i32 3
  %t226 = load i32, ptr %t225, !tbaa !23
  store i32 %t226, ptr %l121, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i64, ptr %l6, !tbaa !24
  %t230 = add i64 %t228, 1
  %t233 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t227, i64 %t230)
  store %"compiler/token:Token" %t233, ptr %l125
  br label %bb75
bb75:
  %t234 = getelementptr %"compiler/token:Token", ptr %l125, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  %t236 = load i32, ptr %l121, !tbaa !23
  %t238 = icmp eq i32 %t236, %t235
  store i1 %t238, ptr %l117, !tbaa !21
  br label %bb76
bb76:
  %t240 = load i1, ptr %l117, !tbaa !21
  br i1 %t240, label %bb77, label %bb78
bb77:
  store i64 2, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i64, ptr %l6, !tbaa !24
  %t245 = add i64 %t243, 2
  %t248 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t242, i64 %t245)
  store i32 %t248, ptr %l132
  br label %bb80
bb80:
  %t249 = load i32, ptr %l132
  %t251 = trunc i64 91 to i32
  %t252 = icmp eq i32 %t249, %t251
  br i1 %t252, label %bb81, label %bb82
bb81:
  store i64 1, ptr %l135, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l135, !tbaa !24
  br label %bb83
bb83:
  %t254 = load i64, ptr %l135, !tbaa !24
  store i64 %t254, ptr %rv
  br label %ret
bb84:
  %t255 = load i64, ptr %l6, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l6, !tbaa !24
  br label %bb85
bb85:
  br label %bb13
bb86:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca %"compiler/token:Token"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %lp34 = alloca ptr
  %l36 = alloca i32
  %l40 = alloca i32
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l52 = alloca i32
  %l55 = alloca i32
  %l56 = alloca i32
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i32
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l82 = alloca %"compiler/source:Span"
  %l88 = alloca i1
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l98 = alloca %"compiler/source:Span"
  %l106 = alloca %"compiler/ast:StructBody"
  %l113 = alloca i32
  %l116 = alloca i1
  %l118 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i32
  %l124 = alloca i32
  %l127 = alloca i32
  %l128 = alloca i32
  %l130 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l135 = alloca i1
  %l139 = alloca i32
  %l140 = alloca i32
  %l142 = alloca i32
  %l143 = alloca i32
  %l150 = alloca i1
  %l151 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca i32
  %l158 = alloca i1
  %l160 = alloca i1
  %l163 = alloca i1
  %l165 = alloca i1
  %l168 = alloca i1
  %l170 = alloca i1
  %l173 = alloca i1
  %l175 = alloca i1
  %l178 = alloca i1
  %l181 = alloca i32
  %l182 = alloca ptr
  %l184 = alloca ptr
  %l185 = alloca i32
  %l189 = alloca %"compiler/source:Span"
  %l193 = alloca %"compiler/ast:Param"
  %l195 = alloca { i64, ptr }
  %l198 = alloca i1
  %l199 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca i32
  %l205 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l213 = alloca %"compiler/ast:CaseDecl"
  %l216 = alloca i32
  %l219 = alloca i32
  %l221 = alloca { i64, ptr }
  %l228 = alloca i32
  %l229 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l233 = alloca i32
  %l235 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l239 = alloca i32
  %l241 = alloca i32
  %l244 = alloca i32
  %l245 = alloca i32
  %l247 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l252 = alloca i1
  %l256 = alloca i32
  %l259 = alloca i1
  %l261 = alloca %"compiler/token:Token"
  %l263 = alloca i32
  %l266 = alloca %"compiler/source:Span"
  %l271 = alloca %"compiler/ast:Param"
  %l273 = alloca i32
  %l275 = alloca i32
  %l276 = alloca i32
  %l278 = alloca ptr
  %l280 = alloca ptr
  %l281 = alloca i32
  %l283 = alloca ptr
  %l286 = alloca %"compiler/source:Span"
  %l287 = alloca ptr
  %l288 = alloca i32
  %l289 = alloca ptr
  %l292 = alloca { i64, ptr }
  %l296 = alloca %"compiler/ast:Func"
  %l299 = alloca i32
  %l302 = alloca i32
  %l304 = alloca { i64, ptr }
  %l309 = alloca ptr
  %l311 = alloca ptr
  %l312 = alloca i32
  %l316 = alloca i1
  %l318 = alloca i32
  %l319 = alloca { i64, ptr }
  %l321 = alloca { i64, ptr }
  %l322 = alloca i32
  %l324 = alloca ptr
  %l326 = alloca ptr
  %l327 = alloca i32
  %l329 = alloca ptr
  %l330 = alloca ptr
  %l332 = alloca ptr
  %l333 = alloca i32
  %l336 = alloca ptr
  %l337 = alloca { i64, ptr }
  %l339 = alloca { i64, ptr }
  %l340 = alloca i32
  %l342 = alloca { i64, ptr }
  %l352 = alloca %"compiler/ast:Sig"
  %l353 = alloca ptr
  %l356 = alloca %"compiler/source:Span"
  %l357 = alloca ptr
  %l358 = alloca { i64, ptr }
  %l362 = alloca %"compiler/ast:Func"
  %s1 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t218 = alloca { i64, [6 x i64] }, align 8
  %t512 = alloca { i64, [6 x i64] }, align 8
  %t635 = alloca { i64, [5 x i64] }, align 8
  %t752 = alloca { i64, [6 x i64] }, align 8
  %t934 = alloca { i64, [6 x i64] }, align 8
  %t947 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l36
  br label %bb1
bb1:
  %t4 = load i32, ptr %l36
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 35 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb48
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t10)
  store i32 %t12, ptr %l40
  br label %bb5
bb5:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e980cdf5146ac576_c2415009b5e84a7a)
  unreachable
bb8:
  %t17 = mul i64 0, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 79)
  store i1 %t25, ptr %l46
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e980cdf5146ac576_c2415009b5e84a7a)
  unreachable
bb10:
  %t26 = load i1, ptr %l46, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l50
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb14, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l49
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t34 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t34, ptr %l47, !tbaa !27
  br label %bb15
bb14:
  %t35 = load i32, ptr %l50, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  call void @__olang_scope_close(ptr %s1)
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t46, ptr %l2, !tbaa !27
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t47, i32 90)
  %t51 = extractvalue { i32, i32 } %t50, 1
  %t52 = extractvalue { i32, i32 } %t50, 0
  store i32 %t52, ptr %l56
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb18, label %ok.54
ok.54:
  store i32 %t51, ptr %l55
  br label %bb17
bb17:
  %t55 = load i32, ptr %l55, !tbaa !23
  store i32 %t55, ptr %l52, !tbaa !23
  br label %bb19
bb18:
  %t56 = load i32, ptr %l56, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  call void @__olang_scope_close(ptr %s1)
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %t67, i1 false)
  %t70 = extractvalue { i32, { i64, ptr } } %t69, 1
  %t71 = extractvalue { i32, { i64, ptr } } %t69, 0
  store i32 %t71, ptr %l61
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb21, label %ok.73
ok.73:
  store { i64, ptr } %t70, ptr %l60
  br label %bb20
bb20:
  %t74 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t74, ptr %l58, !tbaa !27
  br label %bb22
bb21:
  %t75 = load i32, ptr %l61, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  call void @__olang_scope_close(ptr %s1)
  %t85 = insertvalue { i32, ptr } zeroinitializer, i32 %t83, 0
  store { i32, ptr } %t85, ptr %rv
  br label %ret
bb22:
  %t86 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t86, ptr %l3, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractHere(ptr %v0, ptr %t87)
  %t90 = extractvalue { i32, ptr } %t89, 1
  %t91 = extractvalue { i32, ptr } %t89, 0
  store i32 %t91, ptr %l66
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb24, label %ok.93
ok.93:
  store ptr %t90, ptr %l65
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l65, !tbaa !29
  store ptr %t94, ptr %l63, !tbaa !29
  br label %bb25
bb24:
  %t95 = load i32, ptr %l66, !tbaa !23
  %t96 = lshr i32 %t95, 16
  %t97 = and i32 %t95, 65535
  %t98 = icmp eq i32 %t96, 1
  %t99 = select i1 %t98, i32 1, i32 0
  %t100 = icmp eq i32 %t95, 0
  %t101 = shl i32 %t99, 16
  %t102 = or i32 %t101, %t97
  %t103 = select i1 %t100, i32 0, i32 %t102
  call void @__olang_scope_close(ptr %s1)
  %t105 = insertvalue { i32, ptr } zeroinitializer, i32 %t103, 0
  store { i32, ptr } %t105, ptr %rv
  br label %ret
bb25:
  %t106 = load ptr, ptr %l63, !tbaa !29
  store ptr %t106, ptr %l4, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l68, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %t108, i1 false)
  %t111 = extractvalue { i32, ptr } %t110, 1
  %t112 = extractvalue { i32, ptr } %t110, 0
  store i32 %t112, ptr %l72
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb27, label %ok.114
ok.114:
  store ptr %t111, ptr %l71
  br label %bb26
bb26:
  %t115 = load ptr, ptr %l71, !tbaa !29
  store ptr %t115, ptr %l69, !tbaa !29
  br label %bb28
bb27:
  %t116 = load i32, ptr %l72, !tbaa !23
  %t117 = lshr i32 %t116, 16
  %t118 = and i32 %t116, 65535
  %t119 = icmp eq i32 %t117, 1
  %t120 = select i1 %t119, i32 1, i32 0
  %t121 = icmp eq i32 %t116, 0
  %t122 = shl i32 %t120, 16
  %t123 = or i32 %t122, %t118
  %t124 = select i1 %t121, i32 0, i32 %t123
  call void @__olang_scope_close(ptr %s1)
  %t126 = insertvalue { i32, ptr } zeroinitializer, i32 %t124, 0
  store { i32, ptr } %t126, ptr %rv
  br label %ret
bb28:
  %t127 = load ptr, ptr %l4, !tbaa !29
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = load ptr, ptr %l69, !tbaa !29
  %t131 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewithContract(ptr %v0, ptr %t128, ptr %t129, ptr %t127)
  store ptr %t131, ptr %l75
  br label %bb29
bb29:
  %t132 = load ptr, ptr %l75, !tbaa !29
  store ptr %t132, ptr %l5, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 16
  store i1 true, ptr %t135, !tbaa !21
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t136)
  %t139 = extractvalue { i32, { i64, ptr } } %t138, 1
  %t140 = extractvalue { i32, { i64, ptr } } %t138, 0
  store i32 %t140, ptr %l80
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb31, label %ok.142
ok.142:
  store { i64, ptr } %t139, ptr %l79
  br label %bb30
bb30:
  %t143 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t143, ptr %l77, !tbaa !27
  br label %bb32
bb31:
  %t144 = load i32, ptr %l80, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  call void @__olang_scope_close(ptr %s1)
  %t154 = insertvalue { i32, ptr } zeroinitializer, i32 %t152, 0
  store { i32, ptr } %t154, ptr %rv
  br label %ret
bb32:
  %t155 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t155, ptr %l6, !tbaa !27
  %t156 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t156, ptr %l82
  br label %bb33
bb33:
  %t157 = load %"compiler/source:Span", ptr %l82
  store %"compiler/source:Span" %t157, ptr %l7
  %t158 = icmp sge i64 0, 0
  br i1 %t158, label %bb34, label %bb35
bb34:
  %t160 = icmp sle i64 0, 1152921504606846975
  br i1 %t160, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_1539ac39f97600b_6c3b4513fd4221cf)
  unreachable
bb36:
  %t162 = mul i64 0, 8
  %t163 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 0, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l8, !tbaa !27
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t167, i32 43)
  store i1 %t170, ptr %l88
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_1539ac39f97600b_6c3b4513fd4221cf)
  unreachable
bb38:
  %t171 = load i1, ptr %l88, !tbaa !21
  br i1 %t171, label %bb39, label %bb40
bb39:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t172)
  store i32 %t174, ptr %l90
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t175 = load i32, ptr %l90, !tbaa !23
  store i32 %t175, ptr %l9, !tbaa !23
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t176)
  %t179 = extractvalue { i32, { i64, ptr } } %t178, 1
  %t180 = extractvalue { i32, { i64, ptr } } %t178, 0
  store i32 %t180, ptr %l94
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb43, label %ok.182
ok.182:
  store { i64, ptr } %t179, ptr %l93
  br label %bb42
bb42:
  %t183 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t183, ptr %l91, !tbaa !27
  br label %bb44
bb43:
  %t184 = load i32, ptr %l94, !tbaa !23
  %t185 = lshr i32 %t184, 16
  %t186 = and i32 %t184, 65535
  %t187 = icmp eq i32 %t185, 1
  %t188 = select i1 %t187, i32 1, i32 0
  %t189 = icmp eq i32 %t184, 0
  %t190 = shl i32 %t188, 16
  %t191 = or i32 %t190, %t186
  %t192 = select i1 %t189, i32 0, i32 %t191
  call void @__olang_scope_close(ptr %s1)
  %t194 = insertvalue { i32, ptr } zeroinitializer, i32 %t192, 0
  store { i32, ptr } %t194, ptr %rv
  br label %ret
bb44:
  %t195 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t195, ptr %l8, !tbaa !27
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l9, !tbaa !23
  %t200 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t196, i32 %t197)
  store %"compiler/source:Span" %t200, ptr %l98
  br label %bb45
bb45:
  %t201 = load %"compiler/source:Span", ptr %l98
  store %"compiler/source:Span" %t201, ptr %l7
  br label %bb46
bb46:
  %t202 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t203 = load ptr, ptr %l5, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t206 = load %"compiler/source:Span", ptr %l7
  %t207 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t215 = call %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t202, ptr %t203, { i64, ptr } %t205, %"compiler/source:Span" %t206, { i64, ptr } %t207, { i64, ptr } %t208)
  store %"compiler/ast:StructBody" %t215, ptr %l106
  br label %bb47
bb47:
  %t216 = load %"compiler/ast:StructBody", ptr %l106
  %t217 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store %"compiler/ast:StructBody" %t216, ptr %t217
  store { i64, [6 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [6 x i64] }, ptr %t218, i32 0, i32 0
  store i64 0, ptr %t219
  %t221 = insertvalue { ptr } undef, ptr %t217, 0
  %t222 = getelementptr { i64, [6 x i64] }, ptr %t218, i32 0, i32 1
  store { ptr } %t221, ptr %t222
  %t223 = load { i64, [6 x i64] }, ptr %t218
  %t225 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t223, ptr %t225
  call void @__olang_scope_close(ptr %s1)
  %t227 = insertvalue { i32, ptr } zeroinitializer, ptr %t225, 1
  store { i32, ptr } %t227, ptr %rv
  br label %ret
bb48:
  %t228 = load i32, ptr %l1
  %t230 = trunc i64 36 to i32
  %t231 = icmp eq i32 %t228, %t230
  br i1 %t231, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb128
bb51:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t233)
  store i32 %t235, ptr %l113
  br label %bb52
bb52:
  store ptr null, ptr %l10, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t239 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t236, i32 94)
  store i1 %t239, ptr %l116
  br label %bb53
bb53:
  %t240 = load i1, ptr %l116, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb54, label %bb55
bb54:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t243)
  %t246 = extractvalue { i32, ptr } %t245, 1
  %t247 = extractvalue { i32, ptr } %t245, 0
  store i32 %t247, ptr %l121
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb57, label %ok.249
ok.249:
  store ptr %t246, ptr %l120
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t250 = load ptr, ptr %l120, !tbaa !29
  store ptr %t250, ptr %l118, !tbaa !29
  br label %bb58
bb57:
  %t251 = load i32, ptr %l121, !tbaa !23
  %t252 = lshr i32 %t251, 16
  %t253 = and i32 %t251, 65535
  %t254 = icmp eq i32 %t252, 1
  %t255 = select i1 %t254, i32 1, i32 0
  %t256 = icmp eq i32 %t251, 0
  %t257 = shl i32 %t255, 16
  %t258 = or i32 %t257, %t253
  %t259 = select i1 %t256, i32 0, i32 %t258
  %t261 = insertvalue { i32, ptr } zeroinitializer, i32 %t259, 0
  store { i32, ptr } %t261, ptr %rv
  br label %ret
bb58:
  %t262 = load ptr, ptr %l118, !tbaa !29
  store ptr %t262, ptr %l10, !tbaa !29
  br label %bb59
bb59:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t267 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t264, i32 94)
  %t268 = extractvalue { i32, i32 } %t267, 1
  %t269 = extractvalue { i32, i32 } %t267, 0
  store i32 %t269, ptr %l128
  %t270 = icmp ne i32 %t269, 0
  br i1 %t270, label %bb61, label %ok.271
ok.271:
  store i32 %t268, ptr %l127
  br label %bb60
bb60:
  %t272 = load i32, ptr %l127, !tbaa !23
  store i32 %t272, ptr %l124, !tbaa !23
  br label %bb62
bb61:
  %t273 = load i32, ptr %l128, !tbaa !23
  %t274 = lshr i32 %t273, 16
  %t275 = and i32 %t273, 65535
  %t276 = icmp eq i32 %t274, 1
  %t277 = select i1 %t276, i32 1, i32 0
  %t278 = icmp eq i32 %t273, 0
  %t279 = shl i32 %t277, 16
  %t280 = or i32 %t279, %t275
  %t281 = select i1 %t278, i32 0, i32 %t280
  %t283 = insertvalue { i32, ptr } zeroinitializer, i32 %t281, 0
  store { i32, ptr } %t283, ptr %rv
  br label %ret
bb62:
  %t284 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t284, ptr %l130
  br label %bb63
bb63:
  %t285 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l130
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t285, ptr %t286
  store ptr %t286, ptr %l11, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t288)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t293 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t290, i32 95)
  store i1 %t293, ptr %l135
  br label %bb66
bb66:
  %t294 = load i1, ptr %l135, !tbaa !21
  %t295 = xor i1 %t294, true
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb67, label %bb68
bb67:
  br label %bb125
bb68:
  br label %bb69
bb69:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t299)
  store i32 %t301, ptr %l139
  br label %bb70
bb70:
  %t302 = load i32, ptr %l139, !tbaa !23
  store i32 %t302, ptr %l12, !tbaa !23
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t303)
  %t306 = extractvalue { i32, i32 } %t305, 1
  %t307 = extractvalue { i32, i32 } %t305, 0
  store i32 %t307, ptr %l143
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb72, label %ok.309
ok.309:
  store i32 %t306, ptr %l142
  br label %bb71
bb71:
  %t310 = load i32, ptr %l142, !tbaa !23
  store i32 %t310, ptr %l140, !tbaa !23
  br label %bb73
bb72:
  %t311 = load i32, ptr %l143, !tbaa !23
  %t312 = lshr i32 %t311, 16
  %t313 = and i32 %t311, 65535
  %t314 = icmp eq i32 %t312, 1
  %t315 = select i1 %t314, i32 1, i32 0
  %t316 = icmp eq i32 %t311, 0
  %t317 = shl i32 %t315, 16
  %t318 = or i32 %t317, %t313
  %t319 = select i1 %t316, i32 0, i32 %t318
  %t321 = insertvalue { i32, ptr } zeroinitializer, i32 %t319, 0
  store { i32, ptr } %t321, ptr %rv
  br label %ret
bb73:
  %t322 = load i32, ptr %l140, !tbaa !23
  store i32 %t322, ptr %l13, !tbaa !23
  %t323 = icmp sge i64 0, 0
  br i1 %t323, label %bb74, label %bb75
bb74:
  %t325 = icmp sle i64 0, 1152921504606846975
  br i1 %t325, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_17377aefad64a2a8_5cc0f861968a066c)
  unreachable
bb76:
  %t327 = mul i64 0, 8
  %t328 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t327)
  %t329 = insertvalue { i64, ptr } undef, i64 0, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  store { i64, ptr } %t330, ptr %l14, !tbaa !27
  store i1 false, ptr %l15, !tbaa !21
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t335 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t332, i32 90)
  store i1 %t335, ptr %l150
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_17377aefad64a2a8_5cc0f861968a066c)
  unreachable
bb78:
  %t336 = load i1, ptr %l150, !tbaa !21
  br i1 %t336, label %bb79, label %bb80
bb79:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %t337, i1 false)
  %t340 = extractvalue { i32, { i64, ptr } } %t339, 1
  %t341 = extractvalue { i32, { i64, ptr } } %t339, 0
  store i32 %t341, ptr %l154
  %t342 = icmp ne i32 %t341, 0
  br i1 %t342, label %bb82, label %ok.343
ok.343:
  store { i64, ptr } %t340, ptr %l153
  br label %bb81
bb80:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t347 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t344, i32 57)
  store i1 %t347, ptr %l158
  br label %bb84
bb81:
  %t348 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t348, ptr %l151, !tbaa !27
  br label %bb83
bb82:
  %t349 = load i32, ptr %l154, !tbaa !23
  %t350 = lshr i32 %t349, 16
  %t351 = and i32 %t349, 65535
  %t352 = icmp eq i32 %t350, 1
  %t353 = select i1 %t352, i32 1, i32 0
  %t354 = icmp eq i32 %t349, 0
  %t355 = shl i32 %t353, 16
  %t356 = or i32 %t355, %t351
  %t357 = select i1 %t354, i32 0, i32 %t356
  %t359 = insertvalue { i32, ptr } zeroinitializer, i32 %t357, 0
  store { i32, ptr } %t359, ptr %rv
  br label %ret
bb83:
  %t360 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t360, ptr %l14, !tbaa !27
  br label %bb110
bb84:
  %t361 = load i1, ptr %l158, !tbaa !21
  %t362 = xor i1 %t361, true
  br i1 %t362, label %bb85, label %bb86
bb85:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t367 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t364, i32 8)
  store i1 %t367, ptr %l163
  br label %bb87
bb86:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb88
bb87:
  %t368 = load i1, ptr %l163, !tbaa !21
  %t369 = xor i1 %t368, true
  store i1 %t369, ptr %l160, !tbaa !21
  br label %bb88
bb88:
  %t371 = load i1, ptr %l160, !tbaa !21
  br i1 %t371, label %bb89, label %bb90
bb89:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t375 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t372, i32 95)
  store i1 %t375, ptr %l168
  br label %bb91
bb90:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb92
bb91:
  %t376 = load i1, ptr %l168, !tbaa !21
  %t377 = xor i1 %t376, true
  store i1 %t377, ptr %l165, !tbaa !21
  br label %bb92
bb92:
  %t379 = load i1, ptr %l165, !tbaa !21
  br i1 %t379, label %bb93, label %bb94
bb93:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t383 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t380, i32 0)
  store i1 %t383, ptr %l173
  br label %bb95
bb94:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb96
bb95:
  %t384 = load i1, ptr %l173, !tbaa !21
  %t385 = xor i1 %t384, true
  store i1 %t385, ptr %l170, !tbaa !21
  br label %bb96
bb96:
  %t387 = load i1, ptr %l170, !tbaa !21
  br i1 %t387, label %bb97, label %bb98
bb97:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t391 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t388, i32 60)
  store i1 %t391, ptr %l178
  br label %bb99
bb98:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb100
bb99:
  %t392 = load i1, ptr %l178, !tbaa !21
  %t393 = xor i1 %t392, true
  store i1 %t393, ptr %l175, !tbaa !21
  br label %bb100
bb100:
  %t395 = load i1, ptr %l175, !tbaa !21
  br i1 %t395, label %bb101, label %bb102
bb101:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t396)
  store i32 %t398, ptr %l181
  br label %bb103
bb102:
  br label %bb109
bb103:
  %t399 = load i32, ptr %l181, !tbaa !23
  store i32 %t399, ptr %l16, !tbaa !23
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t400)
  %t403 = extractvalue { i32, ptr } %t402, 1
  %t404 = extractvalue { i32, ptr } %t402, 0
  store i32 %t404, ptr %l185
  %t405 = icmp ne i32 %t404, 0
  br i1 %t405, label %bb105, label %ok.406
ok.406:
  store ptr %t403, ptr %l184
  br label %bb104
bb104:
  %t407 = load ptr, ptr %l184, !tbaa !29
  store ptr %t407, ptr %l182, !tbaa !29
  br label %bb106
bb105:
  %t408 = load i32, ptr %l185, !tbaa !23
  %t409 = lshr i32 %t408, 16
  %t410 = and i32 %t408, 65535
  %t411 = icmp eq i32 %t409, 1
  %t412 = select i1 %t411, i32 1, i32 0
  %t413 = icmp eq i32 %t408, 0
  %t414 = shl i32 %t412, 16
  %t415 = or i32 %t414, %t410
  %t416 = select i1 %t413, i32 0, i32 %t415
  %t418 = insertvalue { i32, ptr } zeroinitializer, i32 %t416, 0
  store { i32, ptr } %t418, ptr %rv
  br label %ret
bb106:
  %t419 = load ptr, ptr %l182, !tbaa !29
  store ptr %t419, ptr %l17, !tbaa !29
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i32, ptr %l16, !tbaa !23
  %t424 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t420, i32 %t421)
  store %"compiler/source:Span" %t424, ptr %l189
  br label %bb107
bb107:
  %t425 = load i32, ptr %l13, !tbaa !23
  %t426 = load ptr, ptr %l17, !tbaa !29
  %t428 = load %"compiler/source:Span", ptr %l189
  %t431 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t428, i32 %t425, ptr %t426, ptr null)
  store %"compiler/ast:Param" %t431, ptr %l193
  br label %bb108
bb108:
  %t432 = load %"compiler/ast:Param", ptr %l193
  %t433 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Param" %t432, ptr %t433
  %t434 = mul i64 1, 8
  %t435 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t434)
  %t436 = insertvalue { i64, ptr } undef, i64 1, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l195, !tbaa !27
  %t439 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr ptr, ptr %t440, i64 0
  store ptr %t433, ptr %t441, !tbaa !39
  %t442 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t442, ptr %l14, !tbaa !27
  store i1 true, ptr %l15, !tbaa !21
  br label %bb109
bb109:
  br label %bb110
bb110:
  store ptr null, ptr %l18, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t446 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t443, i32 60)
  store i1 %t446, ptr %l198
  br label %bb111
bb111:
  %t447 = load i1, ptr %l198, !tbaa !21
  br i1 %t447, label %bb112, label %bb113
bb112:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t448)
  %t451 = extractvalue { i32, ptr } %t450, 1
  %t452 = extractvalue { i32, ptr } %t450, 0
  store i32 %t452, ptr %l202
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb115, label %ok.454
ok.454:
  store ptr %t451, ptr %l201
  br label %bb114
bb113:
  br label %bb117
bb114:
  %t455 = load ptr, ptr %l201, !tbaa !29
  store ptr %t455, ptr %l199, !tbaa !29
  br label %bb116
bb115:
  %t456 = load i32, ptr %l202, !tbaa !23
  %t457 = lshr i32 %t456, 16
  %t458 = and i32 %t456, 65535
  %t459 = icmp eq i32 %t457, 1
  %t460 = select i1 %t459, i32 1, i32 0
  %t461 = icmp eq i32 %t456, 0
  %t462 = shl i32 %t460, 16
  %t463 = or i32 %t462, %t458
  %t464 = select i1 %t461, i32 0, i32 %t463
  %t466 = insertvalue { i32, ptr } zeroinitializer, i32 %t464, 0
  store { i32, ptr } %t466, ptr %rv
  br label %ret
bb116:
  %t467 = load ptr, ptr %l199, !tbaa !29
  store ptr %t467, ptr %l18, !tbaa !29
  br label %bb117
bb117:
  %t469 = load ptr, ptr %l11, !tbaa !29
  store ptr %t469, ptr %l205, !tbaa !29
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i32, ptr %l12, !tbaa !23
  %t474 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t470, i32 %t471)
  store %"compiler/source:Span" %t474, ptr %l208
  br label %bb118
bb118:
  %t475 = load i32, ptr %l13, !tbaa !23
  %t476 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t477 = load i1, ptr %l15, !tbaa !21
  %t478 = load ptr, ptr %l18, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l208
  %t484 = call %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t479, i32 %t475, { i64, ptr } %t476, i1 %t477, ptr %t478)
  store %"compiler/ast:CaseDecl" %t484, ptr %l213
  br label %bb119
bb119:
  %t485 = load %"compiler/ast:CaseDecl", ptr %l213
  %t486 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/ast:CaseDecl" %t485, ptr %t486
  %t487 = load ptr, ptr %l205, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ePush_H43bc1cace347592514b4248ffd44c907(ptr %v0, ptr %v0, ptr %t487, ptr %t486)
  br label %bb120
bb120:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t489)
  store i32 %t491, ptr %l216
  %t492 = icmp ne i32 %t491, 0
  br i1 %t492, label %bb122, label %ok.493
ok.493:
  br label %bb121
bb121:
  br label %bb123
bb122:
  %t494 = load i32, ptr %l216, !tbaa !23
  %t495 = lshr i32 %t494, 16
  %t496 = and i32 %t494, 65535
  %t497 = icmp eq i32 %t495, 1
  %t498 = select i1 %t497, i32 1, i32 0
  %t499 = icmp eq i32 %t494, 0
  %t500 = shl i32 %t498, 16
  %t501 = or i32 %t500, %t496
  %t502 = select i1 %t499, i32 0, i32 %t501
  %t504 = insertvalue { i32, ptr } zeroinitializer, i32 %t502, 0
  store { i32, ptr } %t504, ptr %rv
  br label %ret
bb123:
  br label %bb124
bb124:
  br label %bb65
bb125:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t505)
  store i32 %t507, ptr %l219
  br label %bb126
bb126:
  %t508 = load ptr, ptr %l11, !tbaa !29
  %t510 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v0, ptr %t508)
  store { i64, ptr } %t510, ptr %l221
  br label %bb127
bb127:
  %t511 = load ptr, ptr %l10, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t512
  %t513 = getelementptr { i64, [6 x i64] }, ptr %t512, i32 0, i32 0
  store i64 1, ptr %t513
  %t514 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t515 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t514, 0
  %t517 = insertvalue { { i64, ptr }, ptr } %t515, ptr %t511, 1
  %t518 = getelementptr { i64, [6 x i64] }, ptr %t512, i32 0, i32 1
  store { { i64, ptr }, ptr } %t517, ptr %t518
  %t519 = load { i64, [6 x i64] }, ptr %t512
  %t521 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t519, ptr %t521
  %t523 = insertvalue { i32, ptr } zeroinitializer, ptr %t521, 1
  store { i32, ptr } %t523, ptr %rv
  br label %ret
bb128:
  %t524 = load i32, ptr %l1
  %t526 = trunc i64 37 to i32
  %t527 = icmp eq i32 %t524, %t526
  br i1 %t527, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb182
bb131:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t529)
  store i32 %t531, ptr %l228
  br label %bb132
bb132:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t535 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %t532, i32 22)
  %t536 = extractvalue { i32, { i64, ptr } } %t535, 1
  %t537 = extractvalue { i32, { i64, ptr } } %t535, 0
  store i32 %t537, ptr %l233
  %t538 = icmp ne i32 %t537, 0
  br i1 %t538, label %bb134, label %ok.539
ok.539:
  store { i64, ptr } %t536, ptr %l232
  br label %bb133
bb133:
  %t540 = load { i64, ptr }, ptr %l232, !tbaa !27
  store { i64, ptr } %t540, ptr %l229, !tbaa !27
  br label %bb135
bb134:
  %t541 = load i32, ptr %l233, !tbaa !23
  %t542 = lshr i32 %t541, 16
  %t543 = and i32 %t541, 65535
  %t544 = icmp eq i32 %t542, 1
  %t545 = select i1 %t544, i32 1, i32 0
  %t546 = icmp eq i32 %t541, 0
  %t547 = shl i32 %t545, 16
  %t548 = or i32 %t547, %t543
  %t549 = select i1 %t546, i32 0, i32 %t548
  %t551 = insertvalue { i32, ptr } zeroinitializer, i32 %t549, 0
  store { i32, ptr } %t551, ptr %rv
  br label %ret
bb135:
  %t552 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t552, ptr %l19, !tbaa !27
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t556 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %t553, i32 25)
  %t557 = extractvalue { i32, { i64, ptr } } %t556, 1
  %t558 = extractvalue { i32, { i64, ptr } } %t556, 0
  store i32 %t558, ptr %l239
  %t559 = icmp ne i32 %t558, 0
  br i1 %t559, label %bb137, label %ok.560
ok.560:
  store { i64, ptr } %t557, ptr %l238
  br label %bb136
bb136:
  %t561 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t561, ptr %l235, !tbaa !27
  br label %bb138
bb137:
  %t562 = load i32, ptr %l239, !tbaa !23
  %t563 = lshr i32 %t562, 16
  %t564 = and i32 %t562, 65535
  %t565 = icmp eq i32 %t563, 1
  %t566 = select i1 %t565, i32 1, i32 0
  %t567 = icmp eq i32 %t562, 0
  %t568 = shl i32 %t566, 16
  %t569 = or i32 %t568, %t564
  %t570 = select i1 %t567, i32 0, i32 %t569
  %t572 = insertvalue { i32, ptr } zeroinitializer, i32 %t570, 0
  store { i32, ptr } %t572, ptr %rv
  br label %ret
bb138:
  %t573 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t573, ptr %l20, !tbaa !27
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t577 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t574, i32 94)
  %t578 = extractvalue { i32, i32 } %t577, 1
  %t579 = extractvalue { i32, i32 } %t577, 0
  store i32 %t579, ptr %l245
  %t580 = icmp ne i32 %t579, 0
  br i1 %t580, label %bb140, label %ok.581
ok.581:
  store i32 %t578, ptr %l244
  br label %bb139
bb139:
  %t582 = load i32, ptr %l244, !tbaa !23
  store i32 %t582, ptr %l241, !tbaa !23
  br label %bb141
bb140:
  %t583 = load i32, ptr %l245, !tbaa !23
  %t584 = lshr i32 %t583, 16
  %t585 = and i32 %t583, 65535
  %t586 = icmp eq i32 %t584, 1
  %t587 = select i1 %t586, i32 1, i32 0
  %t588 = icmp eq i32 %t583, 0
  %t589 = shl i32 %t587, 16
  %t590 = or i32 %t589, %t585
  %t591 = select i1 %t588, i32 0, i32 %t590
  %t593 = insertvalue { i32, ptr } zeroinitializer, i32 %t591, 0
  store { i32, ptr } %t593, ptr %rv
  br label %ret
bb141:
  %t594 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t594, ptr %l247
  br label %bb142
bb142:
  %t595 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l247
  %t596 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t595, ptr %t596
  store ptr %t596, ptr %l21, !tbaa !29
  %t598 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t598)
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t603 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t600, i32 95)
  store i1 %t603, ptr %l252
  br label %bb145
bb145:
  %t604 = load i1, ptr %l252, !tbaa !21
  %t605 = xor i1 %t604, true
  %t607 = xor i1 %t605, true
  br i1 %t607, label %bb146, label %bb147
bb146:
  br label %bb179
bb147:
  br label %bb148
bb148:
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t609)
  store i32 %t611, ptr %l256
  br label %bb149
bb149:
  %t612 = load i32, ptr %l256, !tbaa !23
  store i32 %t612, ptr %l22, !tbaa !23
  store ptr null, ptr %l23, !tbaa !29
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t616 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t613, i32 40)
  store i1 %t616, ptr %l259
  br label %bb150
bb150:
  %t617 = load i1, ptr %l259, !tbaa !21
  br i1 %t617, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s13
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t618)
  store %"compiler/token:Token" %t620, ptr %l261
  br label %bb153
bb152:
  br label %bb157
bb153:
  %t621 = load %"compiler/token:Token", ptr %l261
  store %"compiler/token:Token" %t621, ptr %l24
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t622)
  store i32 %t624, ptr %l263
  br label %bb154
bb154:
  %t625 = getelementptr %"compiler/token:Token", ptr %l24, i32 0, i32 2
  %t626 = load i32, ptr %t625, !tbaa !23
  %t627 = getelementptr %"compiler/token:Token", ptr %l24, i32 0, i32 3
  %t628 = load i32, ptr %t627, !tbaa !23
  %t631 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s13, i32 %t626, i32 %t628)
  store %"compiler/source:Span" %t631, ptr %l266
  br label %bb155
bb155:
  %t632 = load %"compiler/source:Span", ptr %l266
  store %"compiler/source:Span" %t632, ptr %l25
  %t633 = load %"compiler/source:Span", ptr %l25
  %t634 = load %"compiler/source:Span", ptr %l25
  store { i64, [5 x i64] } zeroinitializer, ptr %t635
  %t636 = getelementptr { i64, [5 x i64] }, ptr %t635, i32 0, i32 0
  store i64 4, ptr %t636
  %t638 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t634, 0
  %t639 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t638, ptr null, 1
  %t640 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t639, i1 true, 2
  %t641 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t640, i1 false, 3
  %t642 = getelementptr { i64, [5 x i64] }, ptr %t635, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t641, ptr %t642
  %t643 = load { i64, [5 x i64] }, ptr %t635
  %t645 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t643, ptr %t645
  %t648 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t633, i32 0, ptr %t645, ptr null)
  store %"compiler/ast:Param" %t648, ptr %l271
  br label %bb156
bb156:
  %t649 = load %"compiler/ast:Param", ptr %l271
  %t650 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Param" %t649, ptr %t650
  store ptr %t650, ptr %l23, !tbaa !29
  call void @__olang_scope_close(ptr %s13)
  br label %bb157
bb157:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t652)
  %t655 = extractvalue { i32, i32 } %t654, 1
  %t656 = extractvalue { i32, i32 } %t654, 0
  store i32 %t656, ptr %l276
  %t657 = icmp ne i32 %t656, 0
  br i1 %t657, label %bb159, label %ok.658
ok.658:
  store i32 %t655, ptr %l275
  br label %bb158
bb158:
  %t659 = load i32, ptr %l275, !tbaa !23
  store i32 %t659, ptr %l273, !tbaa !23
  br label %bb160
bb159:
  %t660 = load i32, ptr %l276, !tbaa !23
  %t661 = lshr i32 %t660, 16
  %t662 = and i32 %t660, 65535
  %t663 = icmp eq i32 %t661, 1
  %t664 = select i1 %t663, i32 1, i32 0
  %t665 = icmp eq i32 %t660, 0
  %t666 = shl i32 %t664, 16
  %t667 = or i32 %t666, %t662
  %t668 = select i1 %t665, i32 0, i32 %t667
  %t670 = insertvalue { i32, ptr } zeroinitializer, i32 %t668, 0
  store { i32, ptr } %t670, ptr %rv
  br label %ret
bb160:
  %t671 = load i32, ptr %l273, !tbaa !23
  store i32 %t671, ptr %l26, !tbaa !23
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t674 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t672, i1 false, i1 false, i1 true)
  %t675 = extractvalue { i32, ptr } %t674, 1
  %t676 = extractvalue { i32, ptr } %t674, 0
  store i32 %t676, ptr %l281
  %t677 = icmp ne i32 %t676, 0
  br i1 %t677, label %bb162, label %ok.678
ok.678:
  store ptr %t675, ptr %l280
  br label %bb161
bb161:
  %t679 = load ptr, ptr %l280, !tbaa !29
  store ptr %t679, ptr %l278, !tbaa !29
  br label %bb163
bb162:
  %t680 = load i32, ptr %l281, !tbaa !23
  %t681 = lshr i32 %t680, 16
  %t682 = and i32 %t680, 65535
  %t683 = icmp eq i32 %t681, 1
  %t684 = select i1 %t683, i32 1, i32 0
  %t685 = icmp eq i32 %t680, 0
  %t686 = shl i32 %t684, 16
  %t687 = or i32 %t686, %t682
  %t688 = select i1 %t685, i32 0, i32 %t687
  %t690 = insertvalue { i32, ptr } zeroinitializer, i32 %t688, 0
  store { i32, ptr } %t690, ptr %rv
  br label %ret
bb163:
  %t691 = load ptr, ptr %l278, !tbaa !29
  store ptr %t691, ptr %l27, !tbaa !29
  %t692 = load ptr, ptr %l21, !tbaa !29
  store ptr %t692, ptr %l283, !tbaa !29
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load i32, ptr %l22, !tbaa !23
  %t697 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t693, i32 %t694)
  store %"compiler/source:Span" %t697, ptr %l286
  br label %bb164
bb164:
  %t698 = load ptr, ptr %l23, !tbaa !29
  store ptr %t698, ptr %l287, !tbaa !29
  %t699 = load i32, ptr %l26, !tbaa !23
  store i32 %t699, ptr %l288, !tbaa !23
  %t700 = load ptr, ptr %l27, !tbaa !29
  store ptr %t700, ptr %l289, !tbaa !29
  %t701 = icmp sge i64 0, 0
  br i1 %t701, label %bb165, label %bb166
bb165:
  %t703 = icmp sle i64 0, 1152921504606846975
  br i1 %t703, label %bb167, label %bb168
bb166:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb167:
  %t705 = mul i64 0, 8
  %t706 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t705)
  %t707 = insertvalue { i64, ptr } undef, i64 0, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t706, 1
  store { i64, ptr } %t708, ptr %l292, !tbaa !27
  %t709 = icmp sge i64 0, 0
  br i1 %t709, label %bb169, label %bb170
bb168:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb169:
  %t711 = icmp sle i64 0, 1152921504606846975
  br i1 %t711, label %bb171, label %bb172
bb170:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb171:
  %t713 = mul i64 0, 8
  %t714 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t713)
  %t715 = insertvalue { i64, ptr } undef, i64 0, 0
  %t716 = insertvalue { i64, ptr } %t715, ptr %t714, 1
  %t717 = load %"compiler/source:Span", ptr %l286
  %t718 = load ptr, ptr %l287, !tbaa !29
  %t719 = load i32, ptr %l288, !tbaa !23
  %t720 = load ptr, ptr %l289, !tbaa !29
  %t721 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t723 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t717, ptr %t718, i32 %t719, ptr %t720, { i64, ptr } %t721, { i64, ptr } %t716, i1 false, i1 false)
  store %"compiler/ast:Func" %t723, ptr %l296
  br label %bb173
bb172:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb173:
  %t724 = load %"compiler/ast:Func", ptr %l296
  %t725 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t724, ptr %t725
  %t726 = load ptr, ptr %l283, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2ePush_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v0, ptr %t726, ptr %t725)
  br label %bb174
bb174:
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t728)
  store i32 %t730, ptr %l299
  %t731 = icmp ne i32 %t730, 0
  br i1 %t731, label %bb176, label %ok.732
ok.732:
  br label %bb175
bb175:
  br label %bb177
bb176:
  %t733 = load i32, ptr %l299, !tbaa !23
  %t734 = lshr i32 %t733, 16
  %t735 = and i32 %t733, 65535
  %t736 = icmp eq i32 %t734, 1
  %t737 = select i1 %t736, i32 1, i32 0
  %t738 = icmp eq i32 %t733, 0
  %t739 = shl i32 %t737, 16
  %t740 = or i32 %t739, %t735
  %t741 = select i1 %t738, i32 0, i32 %t740
  %t743 = insertvalue { i32, ptr } zeroinitializer, i32 %t741, 0
  store { i32, ptr } %t743, ptr %rv
  br label %ret
bb177:
  br label %bb178
bb178:
  br label %bb144
bb179:
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t746 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t744)
  store i32 %t746, ptr %l302
  br label %bb180
bb180:
  %t747 = load ptr, ptr %l21, !tbaa !29
  %t749 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2eToArray_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v0, ptr %t747)
  store { i64, ptr } %t749, ptr %l304
  br label %bb181
bb181:
  %t750 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t751 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t752
  %t753 = getelementptr { i64, [6 x i64] }, ptr %t752, i32 0, i32 0
  store i64 2, ptr %t753
  %t754 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t755 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t754, 0
  %t757 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t755, { i64, ptr } %t750, 1
  %t759 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t757, { i64, ptr } %t751, 2
  %t760 = getelementptr { i64, [6 x i64] }, ptr %t752, i32 0, i32 1
  store { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t759, ptr %t760
  %t761 = load { i64, [6 x i64] }, ptr %t752
  %t763 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t761, ptr %t763
  %t765 = insertvalue { i32, ptr } zeroinitializer, ptr %t763, 1
  store { i32, ptr } %t765, ptr %rv
  br label %ret
bb182:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t768 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t766)
  %t769 = extractvalue { i32, ptr } %t768, 1
  %t770 = extractvalue { i32, ptr } %t768, 0
  store i32 %t770, ptr %l312
  %t771 = icmp ne i32 %t770, 0
  br i1 %t771, label %bb184, label %ok.772
ok.772:
  store ptr %t769, ptr %l311
  br label %bb183
bb183:
  %t773 = load ptr, ptr %l311, !tbaa !29
  store ptr %t773, ptr %l309, !tbaa !29
  br label %bb185
bb184:
  %t774 = load i32, ptr %l312, !tbaa !23
  %t775 = lshr i32 %t774, 16
  %t776 = and i32 %t774, 65535
  %t777 = icmp eq i32 %t775, 1
  %t778 = select i1 %t777, i32 1, i32 0
  %t779 = icmp eq i32 %t774, 0
  %t780 = shl i32 %t778, 16
  %t781 = or i32 %t780, %t776
  %t782 = select i1 %t779, i32 0, i32 %t781
  %t784 = insertvalue { i32, ptr } zeroinitializer, i32 %t782, 0
  store { i32, ptr } %t784, ptr %rv
  br label %ret
bb185:
  %t785 = load ptr, ptr %l309, !tbaa !29
  store ptr %t785, ptr %l28, !tbaa !29
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t789 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t786, i32 90)
  store i1 %t789, ptr %l316
  br label %bb186
bb186:
  %t790 = load i1, ptr %l316, !tbaa !21
  br i1 %t790, label %bb187, label %bb188
bb187:
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t793 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t791)
  store i32 %t793, ptr %l318
  br label %bb189
bb188:
  br label %bb214
bb189:
  %t794 = load i32, ptr %l318, !tbaa !23
  store i32 %t794, ptr %l29, !tbaa !23
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %t795, i1 false)
  %t798 = extractvalue { i32, { i64, ptr } } %t797, 1
  %t799 = extractvalue { i32, { i64, ptr } } %t797, 0
  store i32 %t799, ptr %l322
  %t800 = icmp ne i32 %t799, 0
  br i1 %t800, label %bb191, label %ok.801
ok.801:
  store { i64, ptr } %t798, ptr %l321
  br label %bb190
bb190:
  %t802 = load { i64, ptr }, ptr %l321, !tbaa !27
  store { i64, ptr } %t802, ptr %l319, !tbaa !27
  br label %bb192
bb191:
  %t803 = load i32, ptr %l322, !tbaa !23
  %t804 = lshr i32 %t803, 16
  %t805 = and i32 %t803, 65535
  %t806 = icmp eq i32 %t804, 1
  %t807 = select i1 %t806, i32 1, i32 0
  %t808 = icmp eq i32 %t803, 0
  %t809 = shl i32 %t807, 16
  %t810 = or i32 %t809, %t805
  %t811 = select i1 %t808, i32 0, i32 %t810
  %t813 = insertvalue { i32, ptr } zeroinitializer, i32 %t811, 0
  store { i32, ptr } %t813, ptr %rv
  br label %ret
bb192:
  %t814 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t814, ptr %l30, !tbaa !27
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t817 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractHere(ptr %v0, ptr %t815)
  %t818 = extractvalue { i32, ptr } %t817, 1
  %t819 = extractvalue { i32, ptr } %t817, 0
  store i32 %t819, ptr %l327
  %t820 = icmp ne i32 %t819, 0
  br i1 %t820, label %bb194, label %ok.821
ok.821:
  store ptr %t818, ptr %l326
  br label %bb193
bb193:
  %t822 = load ptr, ptr %l326, !tbaa !29
  store ptr %t822, ptr %l324, !tbaa !29
  br label %bb195
bb194:
  %t823 = load i32, ptr %l327, !tbaa !23
  %t824 = lshr i32 %t823, 16
  %t825 = and i32 %t823, 65535
  %t826 = icmp eq i32 %t824, 1
  %t827 = select i1 %t826, i32 1, i32 0
  %t828 = icmp eq i32 %t823, 0
  %t829 = shl i32 %t827, 16
  %t830 = or i32 %t829, %t825
  %t831 = select i1 %t828, i32 0, i32 %t830
  %t833 = insertvalue { i32, ptr } zeroinitializer, i32 %t831, 0
  store { i32, ptr } %t833, ptr %rv
  br label %ret
bb195:
  %t834 = load ptr, ptr %l324, !tbaa !29
  store ptr %t834, ptr %l31, !tbaa !29
  %t835 = load ptr, ptr %l0, !tbaa !29
  store ptr %t835, ptr %l329, !tbaa !29
  %t836 = load ptr, ptr %l0, !tbaa !29
  %t838 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %t836, i1 false)
  %t839 = extractvalue { i32, ptr } %t838, 1
  %t840 = extractvalue { i32, ptr } %t838, 0
  store i32 %t840, ptr %l333
  %t841 = icmp ne i32 %t840, 0
  br i1 %t841, label %bb197, label %ok.842
ok.842:
  store ptr %t839, ptr %l332
  br label %bb196
bb196:
  %t843 = load ptr, ptr %l332, !tbaa !29
  store ptr %t843, ptr %l330, !tbaa !29
  br label %bb198
bb197:
  %t844 = load i32, ptr %l333, !tbaa !23
  %t845 = lshr i32 %t844, 16
  %t846 = and i32 %t844, 65535
  %t847 = icmp eq i32 %t845, 1
  %t848 = select i1 %t847, i32 1, i32 0
  %t849 = icmp eq i32 %t844, 0
  %t850 = shl i32 %t848, 16
  %t851 = or i32 %t850, %t846
  %t852 = select i1 %t849, i32 0, i32 %t851
  %t854 = insertvalue { i32, ptr } zeroinitializer, i32 %t852, 0
  store { i32, ptr } %t854, ptr %rv
  br label %ret
bb198:
  %t855 = load ptr, ptr %l31, !tbaa !29
  %t856 = load ptr, ptr %l329, !tbaa !29
  %t857 = load ptr, ptr %l330, !tbaa !29
  %t859 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewithContract(ptr %v0, ptr %t856, ptr %t857, ptr %t855)
  store ptr %t859, ptr %l336
  br label %bb199
bb199:
  %t860 = load ptr, ptr %l336, !tbaa !29
  store ptr %t860, ptr %l32, !tbaa !29
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t863 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t861)
  %t864 = extractvalue { i32, { i64, ptr } } %t863, 1
  %t865 = extractvalue { i32, { i64, ptr } } %t863, 0
  store i32 %t865, ptr %l340
  %t866 = icmp ne i32 %t865, 0
  br i1 %t866, label %bb201, label %ok.867
ok.867:
  store { i64, ptr } %t864, ptr %l339
  br label %bb200
bb200:
  %t868 = load { i64, ptr }, ptr %l339, !tbaa !27
  store { i64, ptr } %t868, ptr %l337, !tbaa !27
  br label %bb202
bb201:
  %t869 = load i32, ptr %l340, !tbaa !23
  %t870 = lshr i32 %t869, 16
  %t871 = and i32 %t869, 65535
  %t872 = icmp eq i32 %t870, 1
  %t873 = select i1 %t872, i32 1, i32 0
  %t874 = icmp eq i32 %t869, 0
  %t875 = shl i32 %t873, 16
  %t876 = or i32 %t875, %t871
  %t877 = select i1 %t874, i32 0, i32 %t876
  %t879 = insertvalue { i32, ptr } zeroinitializer, i32 %t877, 0
  store { i32, ptr } %t879, ptr %rv
  br label %ret
bb202:
  %t880 = load { i64, ptr }, ptr %l337, !tbaa !27
  store { i64, ptr } %t880, ptr %l33, !tbaa !27
  %t881 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t881, ptr %l342, !tbaa !27
  %t882 = icmp sge i64 0, 0
  br i1 %t882, label %bb203, label %bb204
bb203:
  %t884 = icmp sle i64 0, 1152921504606846975
  br i1 %t884, label %bb205, label %bb206
bb204:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb205:
  %t886 = mul i64 0, 8
  %t887 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t886)
  %t888 = insertvalue { i64, ptr } undef, i64 0, 0
  %t889 = insertvalue { i64, ptr } %t888, ptr %t887, 1
  %t890 = load ptr, ptr %l32, !tbaa !29
  %t892 = getelementptr %"compiler/ast:Sig", ptr %t890, i32 0, i32 2
  %t893 = load i1, ptr %t892, !tbaa !21
  %t894 = load ptr, ptr %l32, !tbaa !29
  %t896 = getelementptr %"compiler/ast:Sig", ptr %t894, i32 0, i32 3
  %t897 = load { i64, ptr }, ptr %t896, !tbaa !27
  %t898 = load ptr, ptr %l32, !tbaa !29
  %t900 = getelementptr %"compiler/ast:Sig", ptr %t898, i32 0, i32 5
  %t901 = load ptr, ptr %t900, !tbaa !29
  %t902 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t907 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t902, { i64, ptr } %t889, i1 %t893, { i64, ptr } %t897, i1 false, ptr %t901, i1 false, i1 false)
  store %"compiler/ast:Sig" %t907, ptr %l352
  br label %bb207
bb206:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb207:
  %t908 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store ptr %t908, ptr %lp34
  %t909 = load %"compiler/ast:Sig", ptr %l352
  %t910 = load ptr, ptr %lp34
  store %"compiler/ast:Sig" %t909, ptr %t910
  %t911 = load ptr, ptr %l28, !tbaa !29
  store ptr %t911, ptr %l353, !tbaa !29
  %t912 = load ptr, ptr %l0, !tbaa !29
  %t913 = load i32, ptr %l29, !tbaa !23
  %t916 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t912, i32 %t913)
  store %"compiler/source:Span" %t916, ptr %l356
  br label %bb208
bb208:
  %t917 = load ptr, ptr %lp34
  store ptr %t917, ptr %l357, !tbaa !29
  %t918 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t918, ptr %l358, !tbaa !27
  %t919 = icmp sge i64 0, 0
  br i1 %t919, label %bb209, label %bb210
bb209:
  %t921 = icmp sle i64 0, 1152921504606846975
  br i1 %t921, label %bb211, label %bb212
bb210:
  call void @__olang_check_failed(ptr @olang_loc_1c3aa98278e4117_19ec5e3b00828443)
  unreachable
bb211:
  %t923 = mul i64 0, 8
  %t924 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t923)
  %t925 = insertvalue { i64, ptr } undef, i64 0, 0
  %t926 = insertvalue { i64, ptr } %t925, ptr %t924, 1
  %t927 = load %"compiler/source:Span", ptr %l356
  %t928 = load ptr, ptr %l357, !tbaa !29
  %t929 = load { i64, ptr }, ptr %l358, !tbaa !27
  %t931 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t927, ptr null, i32 0, ptr %t928, { i64, ptr } %t929, { i64, ptr } %t926, i1 true, i1 false)
  store %"compiler/ast:Func" %t931, ptr %l362
  br label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_1c3aa98278e4117_19ec5e3b00828443)
  unreachable
bb213:
  %t932 = load %"compiler/ast:Func", ptr %l362
  %t933 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t932, ptr %t933
  store { i64, [6 x i64] } zeroinitializer, ptr %t934
  %t935 = getelementptr { i64, [6 x i64] }, ptr %t934, i32 0, i32 0
  store i64 3, ptr %t935
  %t936 = load ptr, ptr %l353, !tbaa !29
  %t937 = insertvalue { ptr, ptr } undef, ptr %t936, 0
  %t939 = insertvalue { ptr, ptr } %t937, ptr %t933, 1
  %t940 = getelementptr { i64, [6 x i64] }, ptr %t934, i32 0, i32 1
  store { ptr, ptr } %t939, ptr %t940
  %t941 = load { i64, [6 x i64] }, ptr %t934
  %t943 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t941, ptr %t943
  %t945 = insertvalue { i32, ptr } zeroinitializer, ptr %t943, 1
  store { i32, ptr } %t945, ptr %rv
  br label %ret
bb214:
  %t946 = load ptr, ptr %l28, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t947
  %t948 = getelementptr { i64, [6 x i64] }, ptr %t947, i32 0, i32 0
  store i64 3, ptr %t948
  %t950 = insertvalue { ptr, ptr } undef, ptr %t946, 0
  %t951 = insertvalue { ptr, ptr } %t950, ptr null, 1
  %t952 = getelementptr { i64, [6 x i64] }, ptr %t947, i32 0, i32 1
  store { ptr, ptr } %t951, ptr %t952
  %t953 = load { i64, [6 x i64] }, ptr %t947
  %t955 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t953, ptr %t955
  %t957 = insertvalue { i32, ptr } zeroinitializer, ptr %t955, 1
  store { i32, ptr } %t957, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDecl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/ast:TypeDecl"
  %rv = alloca { i32, ptr }
  %t102 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 34)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l7
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l3, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t22)
  %t25 = extractvalue { i32, i32 } %t24, 1
  %t26 = extractvalue { i32, i32 } %t24, 0
  store i32 %t26, ptr %l12
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb5, label %ok.28
ok.28:
  store i32 %t25, ptr %l11
  br label %bb4
bb4:
  %t29 = load i32, ptr %l11, !tbaa !23
  store i32 %t29, ptr %l9, !tbaa !23
  br label %bb6
bb5:
  %t30 = load i32, ptr %l12, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb6:
  %t41 = load i32, ptr %l9, !tbaa !23
  store i32 %t41, ptr %l2, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t42, i32 39)
  store i1 %t45, ptr %l16
  br label %bb7
bb7:
  %t46 = load i1, ptr %l16, !tbaa !21
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t49 = load i32, ptr %l2, !tbaa !23
  %t53 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorDecl(ptr %v0, ptr %t47, i32 %t48, i32 %t49)
  %t54 = extractvalue { i32, ptr } %t53, 1
  %t55 = extractvalue { i32, ptr } %t53, 0
  store i32 %t55, ptr %l22
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb11, label %ok.57
ok.57:
  store ptr %t54, ptr %l21
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t58 = load ptr, ptr %l21, !tbaa !29
  store ptr %t58, ptr %l17, !tbaa !29
  br label %bb12
bb11:
  %t59 = load i32, ptr %l22, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  %t69 = insertvalue { i32, ptr } zeroinitializer, i32 %t67, 0
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb12:
  %t70 = load ptr, ptr %l17, !tbaa !29
  %t71 = insertvalue { i32, ptr } zeroinitializer, ptr %t70, 1
  store { i32, ptr } %t71, ptr %rv
  br label %ret
bb13:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l1, !tbaa !23
  %t74 = load i32, ptr %l2, !tbaa !23
  %t78 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDeclRest(ptr %v0, ptr %t72, i32 %t73, i32 %t74)
  %t79 = extractvalue { i32, ptr } %t78, 1
  %t80 = extractvalue { i32, ptr } %t78, 0
  store i32 %t80, ptr %l29
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb15, label %ok.82
ok.82:
  store ptr %t79, ptr %l28
  br label %bb14
bb14:
  %t83 = load ptr, ptr %l28, !tbaa !29
  store ptr %t83, ptr %l24, !tbaa !29
  br label %bb20
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 38
  store ptr %t86, ptr %l31, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l1, !tbaa !23
  %t91 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t87, i32 %t88)
  store %"compiler/source:Span" %t91, ptr %l34
  br label %bb17
bb17:
  %t92 = load i32, ptr %l2, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/parse:Parser", ptr %t93, i32 0, i32 39
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t99 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t92, { i64, ptr } %t96, i1 false, ptr null)
  store %"compiler/ast:TypeDecl" %t99, ptr %l38
  br label %bb18
bb18:
  %t100 = load %"compiler/ast:TypeDecl", ptr %l38
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:TypeDecl" %t100, ptr %t101
  store { i64, [6 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [6 x i64] }, ptr %t102, i32 0, i32 0
  store i64 2, ptr %t103
  %t104 = load %"compiler/source:Span", ptr %l34
  %t105 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t104, 0
  %t107 = insertvalue { %"compiler/source:Span", ptr } %t105, ptr %t101, 1
  %t108 = getelementptr { i64, [6 x i64] }, ptr %t102, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t107, ptr %t108
  %t109 = load { i64, [6 x i64] }, ptr %t102
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t109, ptr %t111
  %t112 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t112, ptr %t111)
  br label %bb19
bb19:
  %t115 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t115, ptr %rv
  br label %ret
bb20:
  %t116 = load ptr, ptr %l24, !tbaa !29
  %t117 = insertvalue { i32, ptr } zeroinitializer, ptr %t116, 1
  store { i32, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDeclRest(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l26 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l35 = alloca %"compiler/source:Span"
  %l38 = alloca i1
  %l40 = alloca i32
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca %"compiler/ast:TypeDecl"
  %rv = alloca { i32, ptr }
  %t105 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = icmp sge i64 0, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 0, 1152921504606846975
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4)
  unreachable
bb3:
  %t6 = mul i64 0, 8
  %t7 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t6)
  %t8 = insertvalue { i64, ptr } undef, i64 0, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 39
  store { i64, ptr } %t9, ptr %t12, !tbaa !27
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4)
  unreachable
bb5:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a3bb9cce88491c55_2084ae246c483bc1)
  unreachable
bb7:
  %t17 = mul i64 0, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 79)
  store i1 %t25, ptr %l16
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a3bb9cce88491c55_2084ae246c483bc1)
  unreachable
bb9:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l20
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb13, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l19
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  br label %bb14
bb13:
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb14:
  %t46 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t46, ptr %l3, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 39
  store { i64, ptr } %t48, ptr %t51, !tbaa !27
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t52, i32 22)
  store i1 %t55, ptr %l26
  br label %bb16
bb16:
  %t56 = load i1, ptr %l26, !tbaa !21
  store i1 %t56, ptr %l4, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2escopeDecl(ptr %v0, ptr %t57)
  br label %bb17
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %t59)
  %t62 = extractvalue { i32, ptr } %t61, 1
  %t63 = extractvalue { i32, ptr } %t61, 0
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb19, label %ok.65
ok.65:
  store ptr %t62, ptr %l30
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l30, !tbaa !29
  store ptr %t66, ptr %l28, !tbaa !29
  br label %bb20
bb19:
  %t67 = load i32, ptr %l31, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, ptr } zeroinitializer, i32 %t75, 0
  store { i32, ptr } %t77, ptr %rv
  br label %ret
bb20:
  %t78 = load ptr, ptr %l28, !tbaa !29
  store ptr %t78, ptr %l5, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t83 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t79, i32 %a1)
  store %"compiler/source:Span" %t83, ptr %l35
  br label %bb21
bb21:
  %t84 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t84, ptr %l6
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 8)
  store i1 %t88, ptr %l38
  br label %bb22
bb22:
  %t89 = load i1, ptr %l38, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t90)
  store i32 %t92, ptr %l40
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t93 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t93, ptr %l41
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t96 = load i1, ptr %l4, !tbaa !21
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t102 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %a2, { i64, ptr } %t95, i1 %t96, ptr %t97)
  store %"compiler/ast:TypeDecl" %t102, ptr %l46
  br label %bb27
bb27:
  %t103 = load %"compiler/ast:TypeDecl", ptr %l46
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:TypeDecl" %t103, ptr %t104
  store { i64, [6 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [6 x i64] }, ptr %t105, i32 0, i32 0
  store i64 2, ptr %t106
  %t107 = load %"compiler/source:Span", ptr %l41
  %t108 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t107, 0
  %t110 = insertvalue { %"compiler/source:Span", ptr } %t108, ptr %t104, 1
  %t111 = getelementptr { i64, [6 x i64] }, ptr %t105, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t110, ptr %t111
  %t112 = load { i64, [6 x i64] }, ptr %t105
  %t114 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t112, ptr %t114
  %t116 = insertvalue { i32, ptr } zeroinitializer, ptr %t114, 1
  store { i32, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 %a1)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t11 = icmp sle i64 0, 1152921504606846975
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2c29cc2313aef596_a74c39ade1a5acca)
  unreachable
bb6:
  %t13 = mul i64 0, 8
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  %t18 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t16, 1
  store { i32, { i64, ptr } } %t18, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2c29cc2313aef596_a74c39ade1a5acca)
  unreachable
bb8:
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l10
  br label %bb9
bb9:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %t21
  store ptr %t21, ptr %l2, !tbaa !29
  br label %bb10
bb10:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l12, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t24)
  %t27 = extractvalue { i32, ptr } %t26, 1
  %t28 = extractvalue { i32, ptr } %t26, 0
  store i32 %t28, ptr %l16
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb12, label %ok.30
ok.30:
  store ptr %t27, ptr %l15
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l15, !tbaa !29
  store ptr %t31, ptr %l13, !tbaa !29
  br label %bb13
bb12:
  %t32 = load i32, ptr %l16, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t40, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb13:
  %t43 = load ptr, ptr %l12, !tbaa !29
  %t44 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t43, ptr %t44)
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t48 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t45, i32 94)
  %t49 = extractvalue { i32, i1 } %t48, 1
  %t50 = extractvalue { i32, i1 } %t48, 0
  store i32 %t50, ptr %l22
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb16, label %ok.52
ok.52:
  store i1 %t49, ptr %l21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l21, !tbaa !21
  store i1 %t53, ptr %l18, !tbaa !21
  br label %bb17
bb16:
  %t54 = load i32, ptr %l22, !tbaa !23
  %t55 = lshr i32 %t54, 16
  %t56 = and i32 %t54, 65535
  %t57 = icmp eq i32 %t55, 1
  %t58 = select i1 %t57, i32 1, i32 0
  %t59 = icmp eq i32 %t54, 0
  %t60 = shl i32 %t58, 16
  %t61 = or i32 %t60, %t56
  %t62 = select i1 %t59, i32 0, i32 %t61
  %t64 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t62, 0
  store { i32, { i64, ptr } } %t64, ptr %rv
  br label %ret
bb17:
  %t65 = load i1, ptr %l18, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb10
bb22:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eToArr_Ha78c9aad18467c47f48c596ab5d9c770(ptr %v0, ptr %v0, ptr %t68)
  store { i64, ptr } %t70, ptr %l26
  br label %bb23
bb23:
  %t71 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t72 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t71, 1
  store { i32, { i64, ptr } } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca i32
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l41 = alloca %"compiler/ast:TypeParam"
  %l44 = alloca i32
  %l45 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i32
  %l53 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca i32
  %l95 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca i32
  %l100 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l103 = alloca %"compiler/ast:TypeParam"
  %l107 = alloca i1
  %l108 = alloca i1
  %l111 = alloca i1
  %l112 = alloca i32
  %l118 = alloca i32
  %l121 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l13
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l13, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t14, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 18
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l1, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 18
  store i1 false, ptr %t24, !tbaa !21
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l18
  br label %bb4
bb4:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %t27
  store ptr %t27, ptr %l2, !tbaa !29
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t29, i32 59)
  store i1 %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l24
  br label %bb9
bb8:
  br label %bb21
bb9:
  %t37 = load i32, ptr %l24, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t38)
  %t41 = extractvalue { i32, i32 } %t40, 1
  %t42 = extractvalue { i32, i32 } %t40, 0
  store i32 %t42, ptr %l28
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb11, label %ok.44
ok.44:
  store i32 %t41, ptr %l27
  br label %bb10
bb10:
  %t45 = load i32, ptr %l27, !tbaa !23
  store i32 %t45, ptr %l25, !tbaa !23
  br label %bb12
bb11:
  %t46 = load i32, ptr %l28, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t54, 0
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
bb12:
  %t57 = load i32, ptr %l25, !tbaa !23
  store i32 %t57, ptr %l4, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 28
  %t61 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t60, i32 %t61)
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l33, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t65, i32 %t66)
  store %"compiler/source:Span" %t69, ptr %l36
  br label %bb14
bb14:
  %t70 = load i32, ptr %l4, !tbaa !23
  store i32 %t70, ptr %l37, !tbaa !23
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = icmp sle i64 0, 1152921504606846975
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_1d244c71d015ce10_e3593377956a04fc)
  unreachable
bb17:
  %t75 = mul i64 0, 8
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 0, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load %"compiler/source:Span", ptr %l36
  %t80 = load i32, ptr %l37, !tbaa !23
  %t82 = call %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t79, i32 %t80, ptr null, { i64, ptr } %t78, i1 true)
  store %"compiler/ast:TypeParam" %t82, ptr %l41
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1d244c71d015ce10_e3593377956a04fc)
  unreachable
bb19:
  %t83 = load %"compiler/ast:TypeParam", ptr %l41
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/ast:TypeParam" %t83, ptr %t84
  %t85 = load ptr, ptr %l33, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ePus_H37c80a976dd4e939873b1680de0974c7(ptr %v0, ptr %v0, ptr %t85, ptr %t84)
  br label %bb20
bb20:
  br label %bb69
bb21:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t87)
  store i32 %t89, ptr %l44
  br label %bb22
bb22:
  %t90 = load i32, ptr %l44, !tbaa !23
  store i32 %t90, ptr %l5, !tbaa !23
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t91)
  %t94 = extractvalue { i32, i32 } %t93, 1
  %t95 = extractvalue { i32, i32 } %t93, 0
  store i32 %t95, ptr %l48
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb24, label %ok.97
ok.97:
  store i32 %t94, ptr %l47
  br label %bb23
bb23:
  %t98 = load i32, ptr %l47, !tbaa !23
  store i32 %t98, ptr %l45, !tbaa !23
  br label %bb25
bb24:
  %t99 = load i32, ptr %l48, !tbaa !23
  %t100 = lshr i32 %t99, 16
  %t101 = and i32 %t99, 65535
  %t102 = icmp eq i32 %t100, 1
  %t103 = select i1 %t102, i32 1, i32 0
  %t104 = icmp eq i32 %t99, 0
  %t105 = shl i32 %t103, 16
  %t106 = or i32 %t105, %t101
  %t107 = select i1 %t104, i32 0, i32 %t106
  %t109 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t107, 0
  store { i32, { i64, ptr } } %t109, ptr %rv
  br label %ret
bb25:
  %t110 = load i32, ptr %l45, !tbaa !23
  store i32 %t110, ptr %l6, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 28
  %t114 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t113, i32 %t114)
  br label %bb26
bb26:
  store ptr null, ptr %l7, !tbaa !29
  %t117 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t117, ptr %l53
  br label %bb27
bb27:
  %t118 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %t119
  store ptr %t119, ptr %l8, !tbaa !29
  br label %bb28
bb28:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t124 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t121, i32 57)
  store i1 %t124, ptr %l57
  br label %bb29
bb29:
  %t125 = load i1, ptr %l57, !tbaa !21
  %t126 = xor i1 %t125, true
  br i1 %t126, label %bb30, label %bb31
bb30:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t131 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t128, i32 8)
  store i1 %t131, ptr %l62
  br label %bb32
bb31:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb33
bb32:
  %t132 = load i1, ptr %l62, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l59, !tbaa !21
  br label %bb33
bb33:
  %t135 = load i1, ptr %l59, !tbaa !21
  br i1 %t135, label %bb34, label %bb35
bb34:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %t136)
  store i1 %t138, ptr %l66
  br label %bb36
bb35:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb37
bb36:
  %t139 = load i1, ptr %l66, !tbaa !21
  %t140 = xor i1 %t139, true
  store i1 %t140, ptr %l64, !tbaa !21
  br label %bb37
bb37:
  %t142 = load i1, ptr %l64, !tbaa !21
  br i1 %t142, label %bb38, label %bb39
bb38:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t143, i32 59)
  store i1 %t146, ptr %l71
  br label %bb40
bb39:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb41
bb40:
  %t147 = load i1, ptr %l71, !tbaa !21
  %t148 = xor i1 %t147, true
  store i1 %t148, ptr %l68, !tbaa !21
  br label %bb41
bb41:
  %t150 = load i1, ptr %l68, !tbaa !21
  %t151 = xor i1 %t150, true
  br i1 %t151, label %bb42, label %bb43
bb42:
  br label %bb53
bb43:
  br label %bb44
bb44:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/parse:Parser", ptr %t153, i32 0, i32 11
  %t156 = load i1, ptr %t155, !tbaa !21
  store i1 %t156, ptr %l9, !tbaa !21
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/parse:Parser", ptr %t158, i32 0, i32 19
  %t161 = load i1, ptr %t160, !tbaa !21
  store i1 %t161, ptr %l10, !tbaa !21
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t163, i32 0, i32 11
  store i1 true, ptr %t165, !tbaa !21
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/parse:Parser", ptr %t166, i32 0, i32 19
  store i1 true, ptr %t168, !tbaa !21
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t169)
  %t172 = extractvalue { i32, ptr } %t171, 1
  %t173 = extractvalue { i32, ptr } %t171, 0
  store i32 %t173, ptr %l83
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb46, label %ok.175
ok.175:
  store ptr %t172, ptr %l82
  br label %bb45
bb45:
  %t176 = load ptr, ptr %l82, !tbaa !29
  store ptr %t176, ptr %l80, !tbaa !29
  br label %bb47
bb46:
  %t177 = load i32, ptr %l83, !tbaa !23
  %t178 = lshr i32 %t177, 16
  %t179 = and i32 %t177, 65535
  %t180 = icmp eq i32 %t178, 1
  %t181 = select i1 %t180, i32 1, i32 0
  %t182 = icmp eq i32 %t177, 0
  %t183 = shl i32 %t181, 16
  %t184 = or i32 %t183, %t179
  %t185 = select i1 %t182, i32 0, i32 %t184
  %t187 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t185, 0
  store { i32, { i64, ptr } } %t187, ptr %rv
  br label %ret
bb47:
  %t188 = load ptr, ptr %l80, !tbaa !29
  store ptr %t188, ptr %l11, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i1, ptr %l9, !tbaa !21
  %t193 = getelementptr %"compiler/parse:Parser", ptr %t189, i32 0, i32 11
  store i1 %t190, ptr %t193, !tbaa !21
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i1, ptr %l10, !tbaa !21
  %t198 = getelementptr %"compiler/parse:Parser", ptr %t194, i32 0, i32 19
  store i1 %t195, ptr %t198, !tbaa !21
  %t199 = load ptr, ptr %l7, !tbaa !29
  %t201 = icmp eq ptr %t199, null
  br i1 %t201, label %bb48, label %bb49
bb48:
  %t203 = load ptr, ptr %l11, !tbaa !29
  store ptr %t203, ptr %l7, !tbaa !29
  br label %bb51
bb49:
  %t206 = load ptr, ptr %l8, !tbaa !29
  %t207 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t206, ptr %t207)
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  br label %bb28
bb53:
  %t210 = load ptr, ptr %l2, !tbaa !29
  store ptr %t210, ptr %l95, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i32, ptr %l5, !tbaa !23
  %t215 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t211, i32 %t212)
  store %"compiler/source:Span" %t215, ptr %l98
  br label %bb54
bb54:
  %t216 = load i32, ptr %l6, !tbaa !23
  store i32 %t216, ptr %l99, !tbaa !23
  %t217 = load ptr, ptr %l7, !tbaa !29
  store ptr %t217, ptr %l100, !tbaa !29
  %t218 = load ptr, ptr %l8, !tbaa !29
  %t220 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eToArr_Ha78c9aad18467c47f48c596ab5d9c770(ptr %v0, ptr %v0, ptr %t218)
  store { i64, ptr } %t220, ptr %l102
  br label %bb55
bb55:
  %t221 = load %"compiler/source:Span", ptr %l98
  %t222 = load i32, ptr %l99, !tbaa !23
  %t223 = load ptr, ptr %l100, !tbaa !29
  %t224 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t225 = call %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t221, i32 %t222, ptr %t223, { i64, ptr } %t224, i1 false)
  store %"compiler/ast:TypeParam" %t225, ptr %l103
  br label %bb56
bb56:
  %t226 = load %"compiler/ast:TypeParam", ptr %l103
  %t227 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/ast:TypeParam" %t226, ptr %t227
  %t228 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ePus_H37c80a976dd4e939873b1680de0974c7(ptr %v0, ptr %v0, ptr %t228, ptr %t227)
  br label %bb57
bb57:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t233 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t230, i32 59)
  store i1 %t233, ptr %l107
  br label %bb58
bb58:
  %t234 = load i1, ptr %l107, !tbaa !21
  br i1 %t234, label %bb59, label %bb60
bb59:
  br label %bb68
bb60:
  br label %bb61
bb61:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t238 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t235, i32 81)
  %t239 = extractvalue { i32, i1 } %t238, 1
  %t240 = extractvalue { i32, i1 } %t238, 0
  store i32 %t240, ptr %l112
  %t241 = icmp ne i32 %t240, 0
  br i1 %t241, label %bb63, label %ok.242
ok.242:
  store i1 %t239, ptr %l111
  br label %bb62
bb62:
  %t243 = load i1, ptr %l111, !tbaa !21
  store i1 %t243, ptr %l108, !tbaa !21
  br label %bb64
bb63:
  %t244 = load i32, ptr %l112, !tbaa !23
  %t245 = lshr i32 %t244, 16
  %t246 = and i32 %t244, 65535
  %t247 = icmp eq i32 %t245, 1
  %t248 = select i1 %t247, i32 1, i32 0
  %t249 = icmp eq i32 %t244, 0
  %t250 = shl i32 %t248, 16
  %t251 = or i32 %t250, %t246
  %t252 = select i1 %t249, i32 0, i32 %t251
  %t254 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t252, 0
  store { i32, { i64, ptr } } %t254, ptr %rv
  br label %ret
bb64:
  %t255 = load i1, ptr %l108, !tbaa !21
  %t256 = xor i1 %t255, true
  br i1 %t256, label %bb65, label %bb66
bb65:
  br label %bb69
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  br label %bb5
bb69:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i1, ptr %l1, !tbaa !21
  %t262 = getelementptr %"compiler/parse:Parser", ptr %t258, i32 0, i32 18
  store i1 %t259, ptr %t262, !tbaa !21
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %t263)
  store i32 %t265, ptr %l118
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb71, label %ok.267
ok.267:
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t268 = load i32, ptr %l118, !tbaa !23
  %t269 = lshr i32 %t268, 16
  %t270 = and i32 %t268, 65535
  %t271 = icmp eq i32 %t269, 1
  %t272 = select i1 %t271, i32 1, i32 0
  %t273 = icmp eq i32 %t268, 0
  %t274 = shl i32 %t272, 16
  %t275 = or i32 %t274, %t270
  %t276 = select i1 %t273, i32 0, i32 %t275
  %t278 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t276, 0
  store { i32, { i64, ptr } } %t278, ptr %rv
  br label %ret
bb72:
  %t279 = load ptr, ptr %l2, !tbaa !29
  %t281 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2eToA_H6e630dc6e3e172d7593a8563d6f9ad2c(ptr %v0, ptr %v0, ptr %t279)
  store { i64, ptr } %t281, ptr %l121
  br label %bb73
bb73:
  %t282 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t283 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t282, 1
  store { i32, { i64, ptr } } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l23 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i1
  %l38 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = xor i1 %a2, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb4, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l8
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb5:
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t24, 1
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 30
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l13
  br label %bb7
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 30
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t35)
  %t38 = extractvalue { i32, ptr } %t37, 1
  %t39 = extractvalue { i32, ptr } %t37, 0
  store i32 %t39, ptr %l19
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb10, label %ok.41
ok.41:
  store ptr %t38, ptr %l18
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l18, !tbaa !29
  store ptr %t42, ptr %l16, !tbaa !29
  br label %bb11
bb10:
  %t43 = load i32, ptr %l19, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 1, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  %t53 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t51, 0
  store { i32, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb11:
  %t54 = load ptr, ptr %l15, !tbaa !29
  %t55 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t54, ptr %t55)
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 30
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l23
  br label %bb13
bb13:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l23, !tbaa !24
  %t64 = sub i64 %t62, %t61
  %t67 = getelementptr %"compiler/parse:NameList", ptr %a1, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t64, %t70
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t78 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t75, i32 57)
  store i1 %t78, ptr %l33
  br label %bb16
bb16:
  %t79 = load i1, ptr %l33, !tbaa !21
  %t80 = xor i1 %t79, true
  store i1 %t80, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t82 = load i1, ptr %l30, !tbaa !21
  br i1 %t82, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb8
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 30
  %t86 = load i64, ptr %l3, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l38
  br label %bb23
bb23:
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l13 = alloca i32
  %l16 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l1
  store i32 %t4, ptr %l5
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l3, ptr %l5)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = load i32, ptr %l1
  %t14 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 %t12)
  store { i64, ptr } %t14, ptr %l11
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t24 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } %t21)
  store i32 %t24, ptr %l13
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb7, label %ok.26
ok.26:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t27 = load i32, ptr %l13, !tbaa !23
  %t28 = lshr i32 %t27, 16
  %t29 = and i32 %t27, 65535
  %t30 = icmp eq i32 %t28, 1
  %t31 = select i1 %t30, i32 1, i32 0
  %t32 = icmp eq i32 %t27, 0
  %t33 = shl i32 %t31, 16
  %t34 = or i32 %t33, %t29
  %t35 = select i1 %t32, i32 0, i32 %t34
  call void @__olang_scope_close(ptr %s1)
  %t37 = insertvalue { i32, i32 } zeroinitializer, i32 %t35, 0
  store { i32, i32 } %t37, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l16
  br label %bb10
bb10:
  %t41 = load i32, ptr %l16, !tbaa !23
  %t42 = insertvalue { i32, i32 } zeroinitializer, i32 %t41, 1
  store { i32, i32 } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewithContract(ptr %v0, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l22 = alloca %"compiler/ast:Sig"
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Sig", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Sig", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Sig", ptr %t15, i32 0, i32 2
  %t18 = load i1, ptr %t17, !tbaa !21
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Sig", ptr %t19, i32 0, i32 3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Sig", ptr %t23, i32 0, i32 4
  %t26 = load i1, ptr %t25, !tbaa !21
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Sig", ptr %t29, i32 0, i32 6
  %t32 = load i1, ptr %t31, !tbaa !21
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Sig", ptr %t33, i32 0, i32 7
  %t36 = load i1, ptr %t35, !tbaa !21
  %t45 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t10, { i64, ptr } %t14, i1 %t18, { i64, ptr } %t22, i1 %t26, ptr %t27, i1 %t32, i1 %t36)
  store %"compiler/ast:Sig" %t45, ptr %l22
  br label %bb4
bb4:
  %t46 = load %"compiler/ast:Sig", ptr %l22
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store %"compiler/ast:Sig" %t46, ptr %t47
  store ptr %t47, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fparse_2eisJoiningOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 51 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb13
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 52 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 53 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 54 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 55 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 56 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb47
bb14:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 46 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb15, label %bb16
bb15:
  br label %bb29
bb16:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 47 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb17, label %bb18
bb17:
  br label %bb29
bb18:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 48 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb29
bb20:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 75 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 77 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 79 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 80 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb47
bb30:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 81 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb31, label %bb32
bb31:
  br label %bb45
bb32:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 82 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb33, label %bb34
bb33:
  br label %bb45
bb34:
  %t76 = load i32, ptr %l0
  %t78 = trunc i64 83 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb35, label %bb36
bb35:
  br label %bb45
bb36:
  %t81 = load i32, ptr %l0
  %t83 = trunc i64 84 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb37, label %bb38
bb37:
  br label %bb45
bb38:
  %t86 = load i32, ptr %l0
  %t88 = trunc i64 85 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  %t91 = load i32, ptr %l0
  %t93 = trunc i64 88 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb41, label %bb42
bb41:
  br label %bb45
bb42:
  %t96 = load i32, ptr %l0
  %t98 = trunc i64 89 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb47
bb47:
  %t101 = load i1, ptr %l1, !tbaa !21
  store i1 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb17
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t31 = load i32, ptr %l1
  %t33 = trunc i64 52 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = call i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %t36)
  store i1 %t38, ptr %l20
  br label %bb14
bb13:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t39 = load i1, ptr %l20, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t40 = load i1, ptr %l18, !tbaa !21
  store i1 %t40, ptr %l3, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l3, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisOperandTail(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 1 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 91 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 93 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb14
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 15
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l14
  br label %bb12
bb12:
  %t28 = load i1, ptr %l14, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb14
bb14:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisTypeCasePath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i1, ptr %l10, !tbaa !21
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb13
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l12
  br label %bb11
bb11:
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9ddb86cdc3200de1_dc174b333c4dad15)
  unreachable
bb13:
  %t24 = load i1, ptr %l2, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisWordKeyword(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  %t3 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 0
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t15)
  store i1 %t17, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  store i1 %t18, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l7, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load i32, ptr %l0
  %t22 = trunc i64 6 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  store i1 %t25, ptr %l11, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load i32, ptr %l0
  %t30 = trunc i64 7 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ekeywordNamesField(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 19 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb17
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 27 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 28 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 29 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 46 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 47 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb51
bb18:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 48 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb31
bb20:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 30 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 32 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 33 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 34 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 35 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb51
bb32:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 36 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb33, label %bb34
bb33:
  br label %bb43
bb34:
  %t76 = load i32, ptr %l0
  %t78 = trunc i64 37 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  %t81 = load i32, ptr %l0
  %t83 = trunc i64 22 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  %t86 = load i32, ptr %l0
  %t88 = trunc i64 41 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb39, label %bb40
bb39:
  br label %bb43
bb40:
  %t91 = load i32, ptr %l0
  %t93 = trunc i64 42 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb51
bb44:
  %t96 = load i32, ptr %l0
  %t98 = trunc i64 44 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  %t101 = load i32, ptr %l0
  %t103 = trunc i64 45 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb51
bb51:
  %t106 = load i1, ptr %l1, !tbaa !21
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2epathIds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 15
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t37, i32 0, i32 2
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l4, !tbaa !23
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fparse_2epathIds(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t45, i32 %t46)
  br label %bb14
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca i64
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i64
  %l66 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t17, { i64, ptr } %t18)
  store { i64, ptr } %t22, ptr %l18
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  br label %bb48
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t25 = load ptr, ptr %l19, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 12
  store i1 %t31, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l20, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t35, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l29, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 0
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %t49, ptr %t50, { i64, ptr } %t51)
  store { i64, ptr } %t55, ptr %l33
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb16
bb15:
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t58 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t56, i64 %t57)
  %t63 = getelementptr i8, ptr %t62, i64 %t57
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l28, !tbaa !27
  br label %bb16
bb16:
  %t74 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t76 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t74, i64 %t75)
  %t81 = getelementptr i8, ptr %t80, i64 %t75
  call void @olang_textcopy(ptr %t81, ptr %t77, i64 %t78)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  store { i64, ptr } %t83, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t86 = load ptr, ptr %l37, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load ptr, ptr %l37, !tbaa !29
  %t90 = load i64, ptr %t89
  %t92 = icmp eq i64 %t90, 1
  store i1 %t92, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t93 = load i1, ptr %l38, !tbaa !21
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", ptr }, ptr %t96, i32 0, i32 1
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb29
bb22:
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l45, !tbaa !24
  %t106 = load ptr, ptr %l5, !tbaa !29
  %t108 = getelementptr %"compiler/ast:VarDecl", ptr %t106, i32 0, i32 4
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l48, !tbaa !27
  br label %bb25
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l48, !tbaa !27
  br label %bb25
bb25:
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr %"compiler/ast:VarDecl", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l53, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l53, !tbaa !27
  br label %bb28
bb28:
  %t120 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t122 = load i64, ptr %l45, !tbaa !24
  %t123 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t124 = add i64 %t121, %t123
  %t125 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = add i64 %t124, %t127
  %t129 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  %t135 = call i64 @__olang_fmt_i64(ptr %t134, i64 %t122)
  %t136 = getelementptr i8, ptr %t134, i64 %t123
  call void @olang_textcopy(ptr %t136, ptr %t126, i64 %t127)
  %t137 = getelementptr i8, ptr %t136, i64 %t127
  call void @olang_textcopy(ptr %t137, ptr %t130, i64 %t131)
  %t138 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t133, 1
  store { i64, ptr } %t139, ptr %l8, !tbaa !27
  br label %bb48
bb29:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t142 = load ptr, ptr %l55, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb30, label %bb31
bb30:
  %t145 = load ptr, ptr %l55, !tbaa !29
  %t146 = load i64, ptr %t145
  %t148 = icmp eq i64 %t146, 2
  store i1 %t148, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t149 = load i1, ptr %l56, !tbaa !21
  br i1 %t149, label %bb32, label %bb33
bb32:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr }, ptr %t152, i32 0, i32 1
  %t154 = load ptr, ptr %t153
  store ptr %t154, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t156 = load ptr, ptr %l6, !tbaa !29
  %t158 = getelementptr %"compiler/ast:Multi", ptr %t156, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  store i64 %t161, ptr %l63, !tbaa !24
  %t162 = load ptr, ptr %l6, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Multi", ptr %t162, i32 0, i32 1
  %t165 = load i1, ptr %t164, !tbaa !21
  br i1 %t165, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb37
bb37:
  %t167 = load ptr, ptr %l6, !tbaa !29
  %t169 = getelementptr %"compiler/ast:Multi", ptr %t167, i32 0, i32 2
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t175 = load i64, ptr %l63, !tbaa !24
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t177 = add i64 %t174, %t176
  %t178 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = add i64 %t177, %t180
  %t183 = call i64 @__olang_fmt_i64(ptr null, i64 %t172)
  %t184 = add i64 %t181, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t173, i64 %t174)
  %t186 = getelementptr i8, ptr %t185, i64 %t174
  %t187 = call i64 @__olang_fmt_i64(ptr %t186, i64 %t175)
  %t188 = getelementptr i8, ptr %t186, i64 %t176
  call void @olang_textcopy(ptr %t188, ptr %t179, i64 %t180)
  %t189 = getelementptr i8, ptr %t188, i64 %t180
  %t190 = call i64 @__olang_fmt_i64(ptr %t189, i64 %t172)
  %t191 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t185, 1
  store { i64, ptr } %t192, ptr %l8, !tbaa !27
  br label %bb48
bb38:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t195 = load ptr, ptr %l71, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb39, label %bb40
bb39:
  %t198 = load ptr, ptr %l71, !tbaa !29
  %t199 = load i64, ptr %t198
  %t201 = icmp eq i64 %t199, 5
  store i1 %t201, ptr %l72, !tbaa !21
  br label %bb40
bb40:
  %t202 = load i1, ptr %l72, !tbaa !21
  br i1 %t202, label %bb41, label %bb42
bb41:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l7, !tbaa !29
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t209 = load ptr, ptr %l7, !tbaa !29
  %t211 = getelementptr %"compiler/ast:If", ptr %t209, i32 0, i32 2
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = icmp eq ptr %t212, null
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb46
bb46:
  %t218 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t220 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = add i64 %t219, %t222
  %t224 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = getelementptr i8, ptr %t224, i64 %t219
  call void @olang_textcopy(ptr %t225, ptr %t221, i64 %t222)
  %t226 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t224, 1
  store { i64, ptr } %t227, ptr %l8, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l83, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t229, ptr %l8, !tbaa !27
  br label %bb48
bb48:
  %t231 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l85, !tbaa !24
  %t233 = load i64, ptr %l85, !tbaa !24
  %t234 = mul i64 %t233, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t234)
  %t236 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  store { i64, ptr } %t237, ptr %l86, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = load i64, ptr %l85, !tbaa !24
  %t243 = mul i64 %t242, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t239, ptr %t241, i64 %t243, i1 false)
  %t244 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t244, ptr %l8, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t245, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/parse:Oracle"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  %t3 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l5
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l1
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l6
  br label %bb3
bb3:
  %t6 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l7
  br label %bb4
bb4:
  %t8 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t9 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t10 = insertvalue %"compiler/parse:Oracle" undef, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, 0
  %t11 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t12 = insertvalue %"compiler/parse:Oracle" %t10, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 1
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t14 = insertvalue %"compiler/parse:Oracle" %t12, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 2
  %t16 = insertvalue %"compiler/parse:Oracle" %t14, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 3
  store %"compiler/parse:Oracle" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:Oracle", ptr %rv
  ret %"compiler/parse:Oracle" %rr
}

define dso_local %"compiler/parse:stackMarks" @compiler_2fparse_3astackMarks_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %rv = alloca %"compiler/parse:stackMarks"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/parse:stackMarks" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/parse:stackMarks" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/parse:stackMarks" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/parse:stackMarks" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/parse:stackMarks" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/parse:stackMarks" %t24, i64 %a5, 5
  %t28 = insertvalue %"compiler/parse:stackMarks" %t26, i64 %a6, 6
  store %"compiler/parse:stackMarks" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:stackMarks", ptr %rv
  ret %"compiler/parse:stackMarks" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fparse() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fparse_2eMaxNesting_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d8 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d18 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a declaration" }>, align 8
declare void @__olang_ert_req_clear()
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"any" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"export" }>, align 8
@.d21 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a declaration" }>, align 8
@.d22 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"an error type's words or a set's members" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a declaration" }>, align 8
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a join" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d28 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"an element type before the [, as in I32[...]" }>, align 8
@.d29 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an expression" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d31 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d33 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d36 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" :=" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" typed" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"var" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":=" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d44 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"multi" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" else" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"stmt" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_d732b4b75ca0d086_f16e80b591ad44e2 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fparse_2eisOrdering(i32 %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
declare %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %a0)
@olang_loc_bb3818bbd2107504_76faa65ecf814280 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %v0, i32 %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %a0)
@olang_loc_3a014922d706f8ae_e8b2af70e71e377a = external constant [0 x i8]
declare %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e5b5865feda95523_92aca47b2e780ecf = external constant [0 x i8]
@olang_loc_1409caed80efd5ca_aa5da404b7edad6 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0, i64 %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eLen_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %a0)
@olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, i32 %a5, %"compiler/source:Span" %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2ePush_3ccompiler_2fast_3aCatch_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCatch_26_3e_2eToArray_3ccompiler_2fast_3aCatch_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_562ee49de0d7f4dc_ca929e902ecee878 = external constant [0 x i8]
declare %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5, i1 %a6, i64 %a7)
@olang_loc_8028beeed4c0afcb_93e9486db4deb497 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aOutlives_26_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlivesHere(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlives(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aOutlives_26_3e_2ePush_H1795edae43e3fb2f1ebc9cb1197392ef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aOutlives_26_3e_2eToAr_H5eeb6199570724b12f836c014634c4fb(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:ContractBlock" @compiler_2fast_3aContractBlock_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarListCount(ptr %v0, i64 %a0, i64 %a1)
declare { i32, %"compiler/source:Span" } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elinkClause(ptr %v0, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %a0)
@olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe = external constant [0 x i8]
declare %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternBlock(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %a0, %"compiler/token:Token" %a1)
declare %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, ptr %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6, i1 %a7)
@olang_loc_2df52f758a425120_e9eb2ffac7d00514 = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5)
@olang_loc_88b4df24f395cba0_7a8585039ef7582c = external constant [0 x i8]
@G_2ecompiler_2fparse_2eMaxNesting = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\4E\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %v0, i64 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_789713e4eee702da_477f9e47229ca02e = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorWords(ptr %v0, ptr %a0)
@olang_loc_1981dec301b76378_38f305e42bd9bf3c = external constant [0 x i8]
declare %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, i1 %a6, i1 %a7)
@olang_loc_cd306f178609e3e5_44435844e9b3da89 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %a0, i1 %a1, i1 %a2, i1 %a3)
@olang_loc_30a3a318854048f4_b503dd06e25e7b98 = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExpected(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2fmsgs_2eEndOfLine = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fmsgs_2eEndOfFile = external constant <{ [8 x i8], ptr }>
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea = external constant [0 x i8]
@olang_loc_b7532cf042be3d05_817bd3bc9b025111 = external constant [0 x i8]
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba = external constant [0 x i8]
@olang_loc_b5d05676e64fefab_5744e152e232520f = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %a0, ptr %a1)
@olang_loc_f067807cf96ff280_872aeb81d2c2c23c = external constant [0 x i8]
@olang_loc_882dfc00c36114e5_890842da0dcd92c9 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @compiler_2fparse_2eisOperandEndTok(i32 %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_3f19ed1436e26d3c_ab56bc721c08c978 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0)
declare { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %v0, i32 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_a66f16e9609fdd27_2fbef1e5bed159db = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0)
@olang_loc_56ae34a9066c1560_be19fd249755f1d4 = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elambdaBody(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_fd55a40e832939eb_76ee8367288fff1f = external constant [0 x i8]
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc = external constant [0 x i8]
@olang_loc_c608f7f9cf1bb136_7782a31fde86d192 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eHas_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeDecl(ptr %v0)
declare i1 @compiler_2fparse_2eisAssignOp(i32 %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %a0)
@olang_loc_405430454c9e5d04_720bbb7e3dc9fd0 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eAt_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/msgs:Msg" %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %a0)
declare %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e980cdf5146ac576_c2415009b5e84a7a = external constant [0 x i8]
@olang_loc_1539ac39f97600b_6c3b4513fd4221cf = external constant [0 x i8]
declare %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_17377aefad64a2a8_5cc0f861968a066c = external constant [0 x i8]
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
declare %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2, i1 %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ePush_H43bc1cace347592514b4248ffd44c907(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_2302adf5d350ae95_7d513dc9152d99f9 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2ePush_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aFunc_26_3e_2eToArray_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_46374d1b7bb67262_72dce1a2b91be04e = external constant [0 x i8]
@olang_loc_1c3aa98278e4117_19ec5e3b00828443 = external constant [0 x i8]
@olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4 = external constant [0 x i8]
@olang_loc_a3bb9cce88491c55_2084ae246c483bc1 = external constant [0 x i8]
@olang_loc_2c29cc2313aef596_a74c39ade1a5acca = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eToArr_Ha78c9aad18467c47f48c596ab5d9c770(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_1d244c71d015ce10_e3593377956a04fc = external constant [0 x i8]
declare %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i1 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2ePus_H37c80a976dd4e939873b1680de0974c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeParam_26_3e_2eToA_H6e630dc6e3e172d7593a8563d6f9ad2c(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_9ddb86cdc3200de1_dc174b333c4dad15 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare void @compiler_2fparse_2eMaxNesting_2einit()
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
