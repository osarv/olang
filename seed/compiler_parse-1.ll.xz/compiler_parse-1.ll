; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/parse:NameList" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/parse:stackMarks" = type { i64, i64, i64, i64, i64, i64, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
define dso_local ptr @compiler_2fparse_2eGenericFnNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/scan:Tokens", ptr %a1, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 2
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l23, !tbaa !24
  store i64 %t42, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l20, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l41, !tbaa !27
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr %"compiler/token:Token", ptr %t66, i64 %t63
  %t68 = getelementptr %"compiler/token:Token", ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68
  %t71 = trunc i64 37 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb12, label %bb13
bb12:
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t74, ptr %l46, !tbaa !27
  %t75 = load i64, ptr %l9, !tbaa !24
  %t77 = add i64 %t75, 1
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"compiler/token:Token", ptr %t80, i64 %t77
  %t82 = getelementptr %"compiler/token:Token", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82
  %t85 = trunc i64 1 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l45, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb14
bb14:
  %t88 = load i1, ptr %l45, !tbaa !21
  br i1 %t88, label %bb15, label %bb16
bb15:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l52, !tbaa !27
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t90, 2
  %t94 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %t95, i64 %t92
  %t97 = getelementptr %"compiler/token:Token", ptr %t96, i32 0, i32 0
  %t98 = load i32, ptr %t97
  %t100 = trunc i64 77 to i32
  %t101 = icmp eq i32 %t98, %t100
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb17
bb17:
  %t103 = load i1, ptr %l51, !tbaa !21
  br i1 %t103, label %bb18, label %bb19
bb18:
  %t104 = load ptr, ptr %l2, !tbaa !29
  store ptr %t104, ptr %l57, !tbaa !29
  store { i64, ptr } %a0, ptr %l58, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l59, !tbaa !27
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = add i64 %t107, 1
  %t111 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr %"compiler/token:Token", ptr %t112, i64 %t109
  %t114 = getelementptr %"compiler/token:Token", ptr %t113, i32 0, i32 2
  %t115 = load i32, ptr %t114, !tbaa !23
  %t117 = sext i32 %t115 to i64
  store i64 %t117, ptr %l63, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t118, ptr %l64, !tbaa !27
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = add i64 %t119, 1
  %t123 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/token:Token", ptr %t124, i64 %t121
  %t126 = getelementptr %"compiler/token:Token", ptr %t125, i32 0, i32 3
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = sext i32 %t127 to i64
  store i64 %t129, ptr %l68, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l69, !tbaa !24
  %t132 = load i64, ptr %l63, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  br i1 %t133, label %bb20, label %bb21
bb19:
  br label %bb27
bb20:
  %t135 = load i64, ptr %l63, !tbaa !24
  %t136 = load i64, ptr %l68, !tbaa !24
  %t137 = icmp sle i64 %t135, %t136
  br i1 %t137, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d732b4b75ca0d086_f16e80b591ad44e2)
  unreachable
bb22:
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = load i64, ptr %l69, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  br i1 %t141, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_d732b4b75ca0d086_f16e80b591ad44e2)
  unreachable
bb24:
  %t143 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = load i64, ptr %l63, !tbaa !24
  %t146 = load i64, ptr %l68, !tbaa !24
  %t147 = getelementptr i8, ptr %t144, i64 %t145
  %t148 = sub i64 %t146, %t145
  %t149 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  %t151 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t151, { i64, ptr } %t150)
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d732b4b75ca0d086_f16e80b591ad44e2)
  unreachable
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t153 = load i64, ptr %l8, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l8, !tbaa !24
  br label %bb8
bb29:
  %t157 = load ptr, ptr %l2, !tbaa !29
  store ptr %t157, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fparse_2ebuiltinType(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr @.d0 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 5, ptr @.d1 })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 2, ptr @.d2 })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 3, ptr @.d3 })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 3, ptr @.d4 })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb21
bb19:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 3, ptr @.d5 })
  store i1 %t27, ptr %l17
  br label %bb20
bb20:
  %t28 = load i1, ptr %l17, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb21
bb21:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb25
bb23:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 2, ptr @.d6 })
  store i1 %t32, ptr %l20
  br label %bb24
bb24:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb25
bb25:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb29
bb27:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 3, ptr @.d7 })
  store i1 %t37, ptr %l23
  br label %bb28
bb28:
  %t38 = load i1, ptr %l23, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb29
bb29:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb33
bb31:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 3, ptr @.d8 })
  store i1 %t42, ptr %l26
  br label %bb32
bb32:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb33
bb33:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb37
bb35:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 3, ptr @.d9 })
  store i1 %t47, ptr %l29
  br label %bb36
bb36:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb37
bb37:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb41
bb39:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 3, ptr @.d10 })
  store i1 %t52, ptr %l32
  br label %bb40
bb40:
  %t53 = load i1, ptr %l32, !tbaa !21
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb41
bb41:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb45
bb43:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t55, { i64, ptr } { i64 4, ptr @.d11 })
  store i1 %t57, ptr %l35
  br label %bb44
bb44:
  %t58 = load i1, ptr %l35, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb45
bb45:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb49
bb47:
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 3, ptr @.d12 })
  store i1 %t62, ptr %l38
  br label %bb48
bb48:
  %t63 = load i1, ptr %l38, !tbaa !21
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb49
bb49:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb53
bb51:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 3, ptr @.d13 })
  store i1 %t67, ptr %l41
  br label %bb52
bb52:
  %t68 = load i1, ptr %l41, !tbaa !21
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i1, ptr %l39, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr @.d14 })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Oracle", ptr %t5, i32 0, i32 0
  store ptr %t7, ptr %l7, !tbaa !29
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v3, ptr %a1, { i64, ptr } %t9)
  store i32 %t12, ptr %l10
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Oracle", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = extractvalue { i64, ptr } %t16, 0
  %t21 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  %t23 = add i64 %t20, %t22
  %t25 = extractvalue { i64, ptr } %t17, 1
  %t26 = extractvalue { i64, ptr } %t17, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t19, i64 %t20)
  %t29 = getelementptr i8, ptr %t28, i64 %t20
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = getelementptr i8, ptr %t29, i64 %t22
  call void @olang_textcopy(ptr %t30, ptr %t25, i64 %t26)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } %t39, i1 true)
  br label %bb6
bb4:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t43 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t42, i32 %t43, i1 true)
  br label %bb5
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr @.d16 })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Oracle", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l7, !tbaa !29
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v3, ptr %a1, { i64, ptr } %t9)
  store i32 %t12, ptr %l10
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Oracle", ptr %t13, i32 0, i32 3
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = extractvalue { i64, ptr } %t16, 0
  %t21 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t23 = add i64 %t20, %t22
  %t25 = extractvalue { i64, ptr } %t17, 1
  %t26 = extractvalue { i64, ptr } %t17, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t19, i64 %t20)
  %t29 = getelementptr i8, ptr %t28, i64 %t20
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = getelementptr i8, ptr %t29, i64 %t22
  call void @olang_textcopy(ptr %t30, ptr %t25, i64 %t26)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } %t39, i1 true)
  br label %bb6
bb4:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t43 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t42, i32 %t43, i1 true)
  br label %bb5
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 7
  store i32 0, ptr %t9
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 11
  store i1 false, ptr %t12, !tbaa !21
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t13, i32 0, i32 12
  store i1 false, ptr %t15, !tbaa !21
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 16
  store i64 0, ptr %t18, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/parse:Parser", ptr %t19, i32 0, i32 17
  store i1 false, ptr %t21, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 19
  store i64 0, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 20
  store i1 false, ptr %t27, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eTru_He4c1b4b0580574c1753e0fdf1e83e9c5(ptr %v0, ptr %t30, i64 0)
  br label %bb1
bb1:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t32)
  %t35 = extractvalue { i32, ptr } %t34, 1
  %t36 = extractvalue { i32, ptr } %t34, 0
  store i32 %t36, ptr %l17
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb3, label %ok.38
ok.38:
  store ptr %t35, ptr %l16
  br label %bb2
bb2:
  %t39 = load ptr, ptr %l16, !tbaa !29
  store ptr %t39, ptr %l14, !tbaa !29
  br label %bb4
bb3:
  %t40 = load i32, ptr %l17, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  %t50 = insertvalue { i32, ptr } zeroinitializer, i32 %t48, 0
  store { i32, ptr } %t50, ptr %rv
  br label %ret
bb4:
  %t51 = load ptr, ptr %l14, !tbaa !29
  %t52 = insertvalue { i32, ptr } zeroinitializer, ptr %t51, 1
  store { i32, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i32
  %l15 = alloca i32
  %l20 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 35
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t7)
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t9, i32 0)
  store i1 %t12, ptr %l8
  br label %bb4
bb4:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t14, i32 93)
  store i1 %t17, ptr %l11
  br label %bb8
bb8:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s3, ptr %t19, { i64, ptr } { i64 13, ptr @.d18 })
  store i32 %t21, ptr %l13
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb12, label %ok.23
ok.23:
  br label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb14
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l15
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb16:
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %t27)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb18:
  br label %bb2
bb19:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 35
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t31, i64 %t32)
  store { i64, ptr } %t35, ptr %l20
  br label %bb20
bb20:
  %t36 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i1
  %l11 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  store i32 %a1, ptr %l5
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l3, ptr %l5)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t12)
  store i32 %t14, ptr %l11
  br label %bb6
bb6:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l14 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l25 = alloca i64
  %l28 = alloca { i64, ptr }
  %l35 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 7
  %t15 = load i32, ptr %t14
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 9
  store i32 %t15, ptr %t18
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t19, i32 0, i32 7
  store i32 0, ptr %t22
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/scan:Tokens", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l14, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 6
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = sub i64 %t34, 1
  %t38 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr %"compiler/token:Token", ptr %t39, i64 %t36
  %t41 = getelementptr %"compiler/token:Token", ptr %t40, i32 0, i32 3
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 10
  store i32 %t42, ptr %t45, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 8
  %t49 = load i32, ptr %t48, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l21, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 6
  %t56 = load i64, ptr %t55, !tbaa !24
  %t59 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t52, i64 %t56)
  store i64 %t59, ptr %l25
  br label %bb4
bb4:
  %t60 = load i64, ptr %l25, !tbaa !24
  %t61 = load ptr, ptr %l21, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t61, i32 0, i32 6
  store i64 %t60, ptr %t62, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/scan:Tokens", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l28, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 6
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"compiler/token:Token", ptr %t76, i64 %t73
  %t78 = load %"compiler/token:Token", ptr %t77
  store %"compiler/token:Token" %t78, ptr %l1
  %t80 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t81 = load i32, ptr %t80
  %t83 = trunc i64 0 to i32
  %t84 = icmp eq i32 %t81, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb5, label %bb6
bb5:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l35, !tbaa !29
  %t89 = load ptr, ptr %l35, !tbaa !29
  %t90 = getelementptr %"compiler/parse:Parser", ptr %t89, i32 0, i32 6
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = add i64 %t91, 1
  %t95 = load ptr, ptr %l35, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t95, i32 0, i32 6
  store i64 %t93, ptr %t96, !tbaa !24
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t97 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t98 = load i32, ptr %t97
  %t100 = trunc i64 8 to i32
  %t101 = icmp eq i32 %t98, %t100
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb8, label %bb9
bb8:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t107 = load i32, ptr %t106
  %t110 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 9
  store i32 %t107, ptr %t110
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t113 = load i32, ptr %t112, !tbaa !23
  %t116 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 10
  store i32 %t113, ptr %t116, !tbaa !23
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t117 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t118 = load i32, ptr %t117, !tbaa !23
  store i32 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i1
  %l28 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/parse:Parser", ptr %t2, i32 0, i32 6
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t1, i64 %t5)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l8, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 7
  %t14 = load i32, ptr %t13
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  store i64 1, ptr %l13, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = load i64, ptr %l13, !tbaa !24
  %t23 = sub i64 %t21, %t22
  store i64 %t23, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/scan:Tokens", ptr %t33, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t41 = icmp slt i64 %t29, %t38
  store i1 %t41, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t43 = load i1, ptr %l17, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t47, 1
  %t52 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t46, i64 %t49)
  store i64 %t52, ptr %l28
  br label %bb12
bb12:
  %t53 = load i64, ptr %l28, !tbaa !24
  store i64 %t53, ptr %l2, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = sub i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  br label %bb5
bb14:
  %t58 = load i64, ptr %l2, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l17 = alloca ptr
  %l28 = alloca i64
  %l31 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca ptr
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i32
  %l60 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca ptr
  %l88 = alloca ptr
  %l100 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i32
  %l106 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i32
  %l123 = alloca ptr
  %l134 = alloca i1
  %l139 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l143 = alloca i32
  %l145 = alloca ptr
  %l155 = alloca i32
  %l158 = alloca %"compiler/source:Span"
  %l160 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l167 = alloca ptr
  %s2 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t432 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 90)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l12
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t9 = load i32, ptr %l11, !tbaa !23
  store i32 %t9, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l12, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l3, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 11
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 16
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 16
  store i64 %t34, ptr %t37, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 17
  %t41 = load i1, ptr %t40, !tbaa !21
  store i1 %t41, ptr %l4, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 18
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l5, !tbaa !21
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 17
  store i1 false, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 18
  store i1 true, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/parse:Parser", ptr %t54, i32 0, i32 28
  %t58 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l28
  br label %bb4
bb4:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l6, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t60, i32 91)
  store i1 %t63, ptr %l31
  br label %bb5
bb5:
  %t64 = load i1, ptr %l31, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb6, label %bb7
bb6:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t67, i32 89)
  store i1 %t70, ptr %l35
  br label %bb8
bb7:
  br label %bb44
bb8:
  %t71 = load i1, ptr %l35, !tbaa !21
  br i1 %t71, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb12
bb10:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t72, i32 93)
  store i1 %t75, ptr %l39
  br label %bb11
bb11:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb12
bb12:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  %t80 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 91)
  store { i64, ptr } %t80, ptr %l42
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t81 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  %t83 = extractvalue { i64, ptr } %t81, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t90 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t88, { i64, ptr } %t87)
  store i32 %t90, ptr %l44
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb17, label %ok.92
ok.92:
  br label %bb16
bb16:
  br label %bb18
bb17:
  %t93 = load i32, ptr %l44, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  call void @__olang_scope_close(ptr %s2)
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l46, !tbaa !29
  %t103 = load ptr, ptr %l46, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t103, i32 0, i32 16
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = sub i64 %t105, 1
  %t109 = load ptr, ptr %l46, !tbaa !29
  %t110 = getelementptr %"compiler/parse:Parser", ptr %t109, i32 0, i32 16
  store i64 %t107, ptr %t110, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i1, ptr %l3, !tbaa !21
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 11
  store i1 %t112, ptr %t115, !tbaa !21
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i1, ptr %l4, !tbaa !21
  %t120 = getelementptr %"compiler/parse:Parser", ptr %t116, i32 0, i32 17
  store i1 %t117, ptr %t120, !tbaa !21
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i1, ptr %l5, !tbaa !21
  %t125 = getelementptr %"compiler/parse:Parser", ptr %t121, i32 0, i32 18
  store i1 %t122, ptr %t125, !tbaa !21
  %t127 = insertvalue { i32, ptr } zeroinitializer, i32 %t101, 0
  store { i32, ptr } %t127, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t128)
  %t131 = extractvalue { i32, ptr } %t130, 1
  %t132 = extractvalue { i32, ptr } %t130, 0
  store i32 %t132, ptr %l58
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb21, label %ok.134
ok.134:
  store ptr %t131, ptr %l57
  br label %bb20
bb20:
  %t135 = load ptr, ptr %l57, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  br label %bb22
bb21:
  %t136 = load i32, ptr %l58, !tbaa !23
  %t137 = lshr i32 %t136, 16
  %t138 = and i32 %t136, 65535
  %t139 = icmp eq i32 %t137, 1
  %t140 = select i1 %t139, i32 1, i32 0
  %t141 = icmp eq i32 %t136, 0
  %t142 = shl i32 %t140, 16
  %t143 = or i32 %t142, %t138
  %t144 = select i1 %t141, i32 0, i32 %t143
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l60, !tbaa !29
  %t146 = load ptr, ptr %l60, !tbaa !29
  %t147 = getelementptr %"compiler/parse:Parser", ptr %t146, i32 0, i32 16
  %t148 = load i64, ptr %t147, !tbaa !24
  %t150 = sub i64 %t148, 1
  %t152 = load ptr, ptr %l60, !tbaa !29
  %t153 = getelementptr %"compiler/parse:Parser", ptr %t152, i32 0, i32 16
  store i64 %t150, ptr %t153, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i1, ptr %l3, !tbaa !21
  %t158 = getelementptr %"compiler/parse:Parser", ptr %t154, i32 0, i32 11
  store i1 %t155, ptr %t158, !tbaa !21
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i1, ptr %l4, !tbaa !21
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 17
  store i1 %t160, ptr %t163, !tbaa !21
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i1, ptr %l5, !tbaa !21
  %t168 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 18
  store i1 %t165, ptr %t168, !tbaa !21
  %t170 = insertvalue { i32, ptr } zeroinitializer, i32 %t144, 0
  store { i32, ptr } %t170, ptr %rv
  br label %ret
bb22:
  %t171 = load ptr, ptr %l55, !tbaa !29
  store ptr %t171, ptr %l7, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t172)
  store i1 %t174, ptr %l70
  br label %bb23
bb23:
  %t175 = load i1, ptr %l70, !tbaa !21
  br i1 %t175, label %bb24, label %bb25
bb24:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l1, !tbaa !23
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t179 = load ptr, ptr %l7, !tbaa !29
  %t184 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %t176, i32 %t177, ptr %t178, ptr %t179)
  %t185 = extractvalue { i32, ptr } %t184, 1
  %t186 = extractvalue { i32, ptr } %t184, 0
  store i32 %t186, ptr %l77
  %t187 = icmp ne i32 %t186, 0
  br i1 %t187, label %bb27, label %ok.188
ok.188:
  store ptr %t185, ptr %l76
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t189 = load ptr, ptr %l76, !tbaa !29
  store ptr %t189, ptr %l71, !tbaa !29
  br label %bb28
bb27:
  %t190 = load i32, ptr %l77, !tbaa !23
  %t191 = lshr i32 %t190, 16
  %t192 = and i32 %t190, 65535
  %t193 = icmp eq i32 %t191, 1
  %t194 = select i1 %t193, i32 1, i32 0
  %t195 = icmp eq i32 %t190, 0
  %t196 = shl i32 %t194, 16
  %t197 = or i32 %t196, %t192
  %t198 = select i1 %t195, i32 0, i32 %t197
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l79, !tbaa !29
  %t200 = load ptr, ptr %l79, !tbaa !29
  %t201 = getelementptr %"compiler/parse:Parser", ptr %t200, i32 0, i32 16
  %t202 = load i64, ptr %t201, !tbaa !24
  %t204 = sub i64 %t202, 1
  %t206 = load ptr, ptr %l79, !tbaa !29
  %t207 = getelementptr %"compiler/parse:Parser", ptr %t206, i32 0, i32 16
  store i64 %t204, ptr %t207, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i1, ptr %l3, !tbaa !21
  %t212 = getelementptr %"compiler/parse:Parser", ptr %t208, i32 0, i32 11
  store i1 %t209, ptr %t212, !tbaa !21
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i1, ptr %l4, !tbaa !21
  %t217 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 17
  store i1 %t214, ptr %t217, !tbaa !21
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i1, ptr %l5, !tbaa !21
  %t222 = getelementptr %"compiler/parse:Parser", ptr %t218, i32 0, i32 18
  store i1 %t219, ptr %t222, !tbaa !21
  %t224 = insertvalue { i32, ptr } zeroinitializer, i32 %t198, 0
  store { i32, ptr } %t224, ptr %rv
  br label %ret
bb28:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l88, !tbaa !29
  %t226 = load ptr, ptr %l88, !tbaa !29
  %t227 = getelementptr %"compiler/parse:Parser", ptr %t226, i32 0, i32 16
  %t228 = load i64, ptr %t227, !tbaa !24
  %t230 = sub i64 %t228, 1
  %t232 = load ptr, ptr %l88, !tbaa !29
  %t233 = getelementptr %"compiler/parse:Parser", ptr %t232, i32 0, i32 16
  store i64 %t230, ptr %t233, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i1, ptr %l3, !tbaa !21
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t234, i32 0, i32 11
  store i1 %t235, ptr %t238, !tbaa !21
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i1, ptr %l4, !tbaa !21
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t239, i32 0, i32 17
  store i1 %t240, ptr %t243, !tbaa !21
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i1, ptr %l5, !tbaa !21
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t244, i32 0, i32 18
  store i1 %t245, ptr %t248, !tbaa !21
  %t249 = load ptr, ptr %l71, !tbaa !29
  %t250 = insertvalue { i32, ptr } zeroinitializer, ptr %t249, 1
  store { i32, ptr } %t250, ptr %rv
  br label %ret
bb29:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/parse:Parser", ptr %t251, i32 0, i32 28
  %t254 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t253, ptr %t254)
  br label %bb30
bb30:
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s12
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t260 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t257, i32 91)
  %t261 = extractvalue { i32, i1 } %t260, 1
  %t262 = extractvalue { i32, i1 } %t260, 0
  store i32 %t262, ptr %l104
  %t263 = icmp ne i32 %t262, 0
  br i1 %t263, label %bb33, label %ok.264
ok.264:
  store i1 %t261, ptr %l103
  br label %bb32
bb32:
  %t265 = load i1, ptr %l103, !tbaa !21
  store i1 %t265, ptr %l100, !tbaa !21
  br label %bb34
bb33:
  %t266 = load i32, ptr %l104, !tbaa !23
  %t267 = lshr i32 %t266, 16
  %t268 = and i32 %t266, 65535
  %t269 = icmp eq i32 %t267, 1
  %t270 = select i1 %t269, i32 1, i32 0
  %t271 = icmp eq i32 %t266, 0
  %t272 = shl i32 %t270, 16
  %t273 = or i32 %t272, %t268
  %t274 = select i1 %t271, i32 0, i32 %t273
  call void @__olang_scope_close(ptr %s12)
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l106, !tbaa !29
  %t276 = load ptr, ptr %l106, !tbaa !29
  %t277 = getelementptr %"compiler/parse:Parser", ptr %t276, i32 0, i32 16
  %t278 = load i64, ptr %t277, !tbaa !24
  %t280 = sub i64 %t278, 1
  %t282 = load ptr, ptr %l106, !tbaa !29
  %t283 = getelementptr %"compiler/parse:Parser", ptr %t282, i32 0, i32 16
  store i64 %t280, ptr %t283, !tbaa !24
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i1, ptr %l3, !tbaa !21
  %t288 = getelementptr %"compiler/parse:Parser", ptr %t284, i32 0, i32 11
  store i1 %t285, ptr %t288, !tbaa !21
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i1, ptr %l4, !tbaa !21
  %t293 = getelementptr %"compiler/parse:Parser", ptr %t289, i32 0, i32 17
  store i1 %t290, ptr %t293, !tbaa !21
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i1, ptr %l5, !tbaa !21
  %t298 = getelementptr %"compiler/parse:Parser", ptr %t294, i32 0, i32 18
  store i1 %t295, ptr %t298, !tbaa !21
  %t300 = insertvalue { i32, ptr } zeroinitializer, i32 %t274, 0
  store { i32, ptr } %t300, ptr %rv
  br label %ret
bb34:
  %t301 = load i1, ptr %l100, !tbaa !21
  %t302 = xor i1 %t301, true
  br i1 %t302, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s12)
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/parse:Parser", ptr %t304, i32 0, i32 28
  store ptr %t306, ptr %l117, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t307)
  %t310 = extractvalue { i32, ptr } %t309, 1
  %t311 = extractvalue { i32, ptr } %t309, 0
  store i32 %t311, ptr %l121
  %t312 = icmp ne i32 %t311, 0
  br i1 %t312, label %bb39, label %ok.313
ok.313:
  store ptr %t310, ptr %l120
  br label %bb38
bb38:
  %t314 = load ptr, ptr %l120, !tbaa !29
  store ptr %t314, ptr %l118, !tbaa !29
  br label %bb40
bb39:
  %t315 = load i32, ptr %l121, !tbaa !23
  %t316 = lshr i32 %t315, 16
  %t317 = and i32 %t315, 65535
  %t318 = icmp eq i32 %t316, 1
  %t319 = select i1 %t318, i32 1, i32 0
  %t320 = icmp eq i32 %t315, 0
  %t321 = shl i32 %t319, 16
  %t322 = or i32 %t321, %t317
  %t323 = select i1 %t320, i32 0, i32 %t322
  call void @__olang_scope_close(ptr %s12)
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l123, !tbaa !29
  %t325 = load ptr, ptr %l123, !tbaa !29
  %t326 = getelementptr %"compiler/parse:Parser", ptr %t325, i32 0, i32 16
  %t327 = load i64, ptr %t326, !tbaa !24
  %t329 = sub i64 %t327, 1
  %t331 = load ptr, ptr %l123, !tbaa !29
  %t332 = getelementptr %"compiler/parse:Parser", ptr %t331, i32 0, i32 16
  store i64 %t329, ptr %t332, !tbaa !24
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i1, ptr %l3, !tbaa !21
  %t337 = getelementptr %"compiler/parse:Parser", ptr %t333, i32 0, i32 11
  store i1 %t334, ptr %t337, !tbaa !21
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i1, ptr %l4, !tbaa !21
  %t342 = getelementptr %"compiler/parse:Parser", ptr %t338, i32 0, i32 17
  store i1 %t339, ptr %t342, !tbaa !21
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i1, ptr %l5, !tbaa !21
  %t347 = getelementptr %"compiler/parse:Parser", ptr %t343, i32 0, i32 18
  store i1 %t344, ptr %t347, !tbaa !21
  %t349 = insertvalue { i32, ptr } zeroinitializer, i32 %t323, 0
  store { i32, ptr } %t349, ptr %rv
  br label %ret
bb40:
  %t350 = load ptr, ptr %l117, !tbaa !29
  %t351 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t350, ptr %t351)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s12)
  br label %bb42
bb42:
  br label %bb31
bb43:
  br label %bb44
bb44:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t355 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t352, i32 91)
  store i1 %t355, ptr %l134
  br label %bb45
bb45:
  %t356 = load i1, ptr %l134, !tbaa !21
  %t357 = xor i1 %t356, true
  br i1 %t357, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s17
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/parse:Parser", ptr %t359, i32 0, i32 28
  %t362 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t361, i64 %t362)
  br label %bb48
bb47:
  br label %bb53
bb48:
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l139, !tbaa !29
  %t367 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s17, i32 91)
  store { i64, ptr } %t367, ptr %l141
  br label %bb49
bb49:
  %t368 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 0
  %t370 = extractvalue { i64, ptr } %t368, 1
  %t371 = mul i64 %t369, 1
  %t372 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t371)
  call void @llvm.memcpy.p0.p0.i64(ptr %t372, ptr %t370, i64 %t371, i1 false)
  %t373 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t374 = insertvalue { i64, ptr } %t373, ptr %t372, 1
  %t375 = load ptr, ptr %l139, !tbaa !29
  %t377 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s17, ptr %t375, { i64, ptr } %t374)
  store i32 %t377, ptr %l143
  %t378 = icmp ne i32 %t377, 0
  br i1 %t378, label %bb51, label %ok.379
ok.379:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t380 = load i32, ptr %l143, !tbaa !23
  %t381 = lshr i32 %t380, 16
  %t382 = and i32 %t380, 65535
  %t383 = icmp eq i32 %t381, 1
  %t384 = select i1 %t383, i32 1, i32 0
  %t385 = icmp eq i32 %t380, 0
  %t386 = shl i32 %t384, 16
  %t387 = or i32 %t386, %t382
  %t388 = select i1 %t385, i32 0, i32 %t387
  call void @__olang_scope_close(ptr %s17)
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l145, !tbaa !29
  %t390 = load ptr, ptr %l145, !tbaa !29
  %t391 = getelementptr %"compiler/parse:Parser", ptr %t390, i32 0, i32 16
  %t392 = load i64, ptr %t391, !tbaa !24
  %t394 = sub i64 %t392, 1
  %t396 = load ptr, ptr %l145, !tbaa !29
  %t397 = getelementptr %"compiler/parse:Parser", ptr %t396, i32 0, i32 16
  store i64 %t394, ptr %t397, !tbaa !24
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load i1, ptr %l3, !tbaa !21
  %t402 = getelementptr %"compiler/parse:Parser", ptr %t398, i32 0, i32 11
  store i1 %t399, ptr %t402, !tbaa !21
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load i1, ptr %l4, !tbaa !21
  %t407 = getelementptr %"compiler/parse:Parser", ptr %t403, i32 0, i32 17
  store i1 %t404, ptr %t407, !tbaa !21
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load i1, ptr %l5, !tbaa !21
  %t412 = getelementptr %"compiler/parse:Parser", ptr %t408, i32 0, i32 18
  store i1 %t409, ptr %t412, !tbaa !21
  %t414 = insertvalue { i32, ptr } zeroinitializer, i32 %t388, 0
  store { i32, ptr } %t414, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s17)
  br label %bb53
bb53:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t415)
  store i32 %t417, ptr %l155
  br label %bb54
bb54:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load i32, ptr %l1, !tbaa !23
  %t422 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t418, i32 %t419)
  store %"compiler/source:Span" %t422, ptr %l158
  br label %bb55
bb55:
  %t423 = load ptr, ptr %l2, !tbaa !29
  store ptr %t423, ptr %l160, !tbaa !29
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/parse:Parser", ptr %t425, i32 0, i32 28
  %t428 = load i64, ptr %l6, !tbaa !24
  %t431 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t427, i64 %t428)
  store { i64, ptr } %t431, ptr %l164
  br label %bb56
bb56:
  store { i64, [5 x i64] } zeroinitializer, ptr %t432
  %t433 = getelementptr { i64, [5 x i64] }, ptr %t432, i32 0, i32 0
  store i64 18, ptr %t433
  %t434 = load %"compiler/source:Span", ptr %l158
  %t435 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t434, 0
  %t436 = load ptr, ptr %l160, !tbaa !29
  %t437 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t435, ptr %t436, 1
  %t438 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t439 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t437, { i64, ptr } %t438, 2
  %t440 = getelementptr { i64, [5 x i64] }, ptr %t432, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t439, ptr %t440
  %t441 = load { i64, [5 x i64] }, ptr %t432
  %t443 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t441, ptr %t443
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l167, !tbaa !29
  %t445 = load ptr, ptr %l167, !tbaa !29
  %t446 = getelementptr %"compiler/parse:Parser", ptr %t445, i32 0, i32 16
  %t447 = load i64, ptr %t446, !tbaa !24
  %t449 = sub i64 %t447, 1
  %t451 = load ptr, ptr %l167, !tbaa !29
  %t452 = getelementptr %"compiler/parse:Parser", ptr %t451, i32 0, i32 16
  store i64 %t449, ptr %t452, !tbaa !24
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load i1, ptr %l3, !tbaa !21
  %t457 = getelementptr %"compiler/parse:Parser", ptr %t453, i32 0, i32 11
  store i1 %t454, ptr %t457, !tbaa !21
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t459 = load i1, ptr %l4, !tbaa !21
  %t462 = getelementptr %"compiler/parse:Parser", ptr %t458, i32 0, i32 17
  store i1 %t459, ptr %t462, !tbaa !21
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load i1, ptr %l5, !tbaa !21
  %t467 = getelementptr %"compiler/parse:Parser", ptr %t463, i32 0, i32 18
  store i1 %t464, ptr %t467, !tbaa !21
  %t469 = insertvalue { i32, ptr } zeroinitializer, ptr %t443, 1
  store { i32, ptr } %t469, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 8 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 93 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 0 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 13
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load i32, ptr %l1
  %t30 = trunc i64 10 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb13, label %bb14
bb12:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb16
bb13:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t33 = load i32, ptr %l1
  %t35 = trunc i64 13 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %l15, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l15, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 59)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %t6)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l7
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l6
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  br label %bb6
bb5:
  %t14 = load i32, ptr %l7, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t22, 0
  store { i32, { i64, ptr } } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t25, 1
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l12
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l11
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  br label %bb10
bb9:
  %t35 = load i32, ptr %l12, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t43, 0
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t47 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t46, 1
  store { i32, { i64, ptr } } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l24 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/ast:Branch"
  %l42 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/ast:Branch"
  %l49 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l70 = alloca i1
  %l78 = alloca i32
  %l88 = alloca i32
  %l91 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/ast:Branch"
  %l102 = alloca %"compiler/source:Span"
  %l105 = alloca %"compiler/ast:Branch"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i32, ptr %l9, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 59)
  store i1 %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 4
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l15
  br label %bb5
bb4:
  br label %bb27
bb5:
  %t16 = load i64, ptr %l15, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %t17)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l19
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb7, label %ok.23
ok.23:
  store { i64, ptr } %t20, ptr %l18
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t24, ptr %l16, !tbaa !27
  br label %bb23
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t28)
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 20
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 22
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t42, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t43)
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t45, i32 %t46)
  store %"compiler/source:Span" %t49, ptr %l31
  br label %bb17
bb17:
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb18, label %bb19
bb18:
  %t52 = icmp sle i64 0, 1152921504606846975
  br i1 %t52, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3a014922d706f8ae_e8b2af70e71e377a)
  unreachable
bb20:
  %t54 = mul i64 0, 8
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 0, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load %"compiler/source:Span", ptr %l31
  %t62 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t59, { i64, ptr } %t57, i64 %t58)
  store %"compiler/ast:Branch" %t62, ptr %l36
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3a014922d706f8ae_e8b2af70e71e377a)
  unreachable
bb22:
  %t63 = load %"compiler/ast:Branch", ptr %l36
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t63, ptr %t64
  %t66 = insertvalue { i32, ptr } zeroinitializer, ptr %t64, 1
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb23:
  %t67 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t67, ptr %l3, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 4
  %t71 = load ptr, ptr %t70, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t71)
  br label %bb24
bb24:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t73, i32 %t74)
  store %"compiler/source:Span" %t77, ptr %l42
  br label %bb25
bb25:
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load %"compiler/source:Span", ptr %l42
  %t83 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t80, { i64, ptr } %t78, i64 %t79)
  store %"compiler/ast:Branch" %t83, ptr %l45
  br label %bb26
bb26:
  %t84 = load %"compiler/ast:Branch", ptr %l45
  %t85 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t84, ptr %t85
  %t87 = insertvalue { i32, ptr } zeroinitializer, ptr %t85, 1
  store { i32, ptr } %t87, ptr %rv
  br label %ret
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t88, i32 92)
  store i1 %t91, ptr %l49
  br label %bb28
bb28:
  %t92 = load i1, ptr %l49, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l51, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 92)
  store { i64, ptr } %t97, ptr %l53
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t98 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t107 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t105, { i64, ptr } %t104)
  store i32 %t107, ptr %l55
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb33, label %ok.109
ok.109:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t110 = load i32, ptr %l55, !tbaa !23
  %t111 = lshr i32 %t110, 16
  %t112 = and i32 %t110, 65535
  %t113 = icmp eq i32 %t111, 1
  %t114 = select i1 %t113, i32 1, i32 0
  %t115 = icmp eq i32 %t110, 0
  %t116 = shl i32 %t114, 16
  %t117 = or i32 %t116, %t112
  %t118 = select i1 %t115, i32 0, i32 %t117
  call void @__olang_scope_close(ptr %s4)
  %t120 = insertvalue { i32, ptr } zeroinitializer, i32 %t118, 0
  store { i32, ptr } %t120, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/parse:Parser", ptr %t121, i32 0, i32 4
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t124)
  store i64 %t126, ptr %l59
  br label %bb36
bb36:
  %t127 = load i64, ptr %l59, !tbaa !24
  store i64 %t127, ptr %l4, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/parse:Parser", ptr %t128, i32 0, i32 6
  %t131 = load i64, ptr %t130, !tbaa !24
  store i64 %t131, ptr %l5, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t133)
  %t136 = extractvalue { i32, { i64, ptr } } %t135, 1
  %t137 = extractvalue { i32, { i64, ptr } } %t135, 0
  store i32 %t137, ptr %l65
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb38, label %ok.139
ok.139:
  store { i64, ptr } %t136, ptr %l64
  br label %bb37
bb37:
  %t140 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t140, ptr %l62, !tbaa !27
  br label %bb58
bb38:
  br label %bb39
bb39:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/parse:Parser", ptr %t141, i32 0, i32 4
  %t144 = load ptr, ptr %t143, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t144)
  br label %bb40
bb40:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/parse:Parser", ptr %t146, i32 0, i32 20
  %t149 = load i1, ptr %t148, !tbaa !21
  br i1 %t149, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb43
bb42:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/parse:Parser", ptr %t151, i32 0, i32 22
  %t154 = load i1, ptr %t153, !tbaa !21
  store i1 %t154, ptr %l70, !tbaa !21
  br label %bb43
bb43:
  %t156 = load i1, ptr %l70, !tbaa !21
  br i1 %t156, label %bb44, label %bb45
bb44:
  %t158 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t158, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = trunc i64 %t163 to i32
  %t168 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %t162, i32 %t165)
  store i32 %t168, ptr %l78
  br label %bb47
bb47:
  %t169 = load i32, ptr %l78, !tbaa !23
  store i32 %t169, ptr %l6, !tbaa !23
  %t170 = load i32, ptr %l6, !tbaa !23
  %t172 = icmp slt i32 %t170, 0
  br i1 %t172, label %bb48, label %bb49
bb48:
  %t175 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l6, !tbaa !23
  %t179 = sext i32 %t177 to i64
  %t182 = getelementptr %"compiler/parse:Parser", ptr %t176, i32 0, i32 6
  store i64 %t179, ptr %t182, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 7
  store i32 0, ptr %t186
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t187)
  store i32 %t189, ptr %l88
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l1, !tbaa !23
  %t194 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t190, i32 %t191)
  store %"compiler/source:Span" %t194, ptr %l91
  br label %bb52
bb52:
  %t195 = icmp sge i64 0, 0
  br i1 %t195, label %bb53, label %bb54
bb53:
  %t197 = icmp sle i64 0, 1152921504606846975
  br i1 %t197, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_e5b5865feda95523_92aca47b2e780ecf)
  unreachable
bb55:
  %t199 = mul i64 0, 8
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 0, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  %t203 = load i64, ptr %l4, !tbaa !24
  %t204 = load %"compiler/source:Span", ptr %l91
  %t207 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t204, { i64, ptr } %t202, i64 %t203)
  store %"compiler/ast:Branch" %t207, ptr %l96
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_e5b5865feda95523_92aca47b2e780ecf)
  unreachable
bb57:
  %t208 = load %"compiler/ast:Branch", ptr %l96
  %t209 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t208, ptr %t209
  %t211 = insertvalue { i32, ptr } zeroinitializer, ptr %t209, 1
  store { i32, ptr } %t211, ptr %rv
  br label %ret
bb58:
  %t212 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t212, ptr %l7, !tbaa !27
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 4
  %t216 = load ptr, ptr %t215, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t216)
  br label %bb59
bb59:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l1, !tbaa !23
  %t222 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t218, i32 %t219)
  store %"compiler/source:Span" %t222, ptr %l102
  br label %bb60
bb60:
  %t223 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t224 = load i64, ptr %l4, !tbaa !24
  %t225 = load %"compiler/source:Span", ptr %l102
  %t228 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t225, { i64, ptr } %t223, i64 %t224)
  store %"compiler/ast:Branch" %t228, ptr %l105
  br label %bb61
bb61:
  %t229 = load %"compiler/ast:Branch", ptr %l105
  %t230 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t229, ptr %t230
  %t232 = insertvalue { i32, ptr } zeroinitializer, ptr %t230, 1
  store { i32, ptr } %t232, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca %"compiler/token:Token"
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t12)
  store %"compiler/token:Token" %t14, ptr %l7
  br label %bb4
bb4:
  %t15 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t16 = load %"compiler/token:Token", ptr %l7
  %t18 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t16, i8 %t15)
  store i1 %t18, ptr %l9
  br label %bb5
bb5:
  %t19 = load i1, ptr %l9, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %rv = alloca { i32, { { i64, ptr }, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 74)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t6)
  %t9 = extractvalue { i32, ptr } %t8, 1
  %t10 = extractvalue { i32, ptr } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store ptr %t9, ptr %l8
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t13 = load ptr, ptr %l8, !tbaa !29
  store ptr %t13, ptr %l6, !tbaa !29
  br label %bb6
bb5:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 %t22, 0
  store { i32, { { i64, ptr }, ptr } } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load ptr, ptr %l6, !tbaa !29
  store ptr %t25, ptr %l1, !tbaa !29
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = icmp sle i64 0, 1152921504606846975
  br i1 %t28, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_1409caed80efd5ca_aa5da404b7edad6)
  unreachable
bb9:
  %t30 = mul i64 0, 8
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 0, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t37 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t33, 0
  %t39 = insertvalue { { i64, ptr }, ptr } %t37, ptr %t34, 1
  %t41 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, { { i64, ptr }, ptr } %t39, 1
  store { i32, { { i64, ptr }, ptr } } %t41, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_1409caed80efd5ca_aa5da404b7edad6)
  unreachable
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t42)
  %t45 = extractvalue { i32, { i64, ptr } } %t44, 1
  %t46 = extractvalue { i32, { i64, ptr } } %t44, 0
  store i32 %t46, ptr %l20
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb13, label %ok.48
ok.48:
  store { i64, ptr } %t45, ptr %l19
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t49, ptr %l17, !tbaa !27
  br label %bb14
bb13:
  %t50 = load i32, ptr %l20, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  %t60 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, i32 %t58, 0
  store { i32, { { i64, ptr }, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t64 = insertvalue { { i64, ptr }, ptr } undef, { i64, ptr } %t61, 0
  %t65 = insertvalue { { i64, ptr }, ptr } %t64, ptr null, 1
  %t67 = insertvalue { i32, { { i64, ptr }, ptr } } zeroinitializer, { { i64, ptr }, ptr } %t65, 1
  store { i32, { { i64, ptr }, ptr } } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { { i64, ptr }, ptr } }, ptr %rv
  ret { i32, { { i64, ptr }, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %rv = alloca { i32, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l1, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = insertvalue { i32, ptr } zeroinitializer, ptr %t20, 1
  store { i32, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i32
  %l15 = alloca i64
  %l20 = alloca i1
  %l23 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l55 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8
  %t8 = trunc i64 55 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t14, i64 %t15)
  store i64 %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load i64, ptr %l15, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t20, 1
  store i64 %t22, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sge i64 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t28, i64 %t29)
  store i64 %t32, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp eq i64 %t34, %t33
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l20, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t41, i64 %t42)
  store i32 %t45, ptr %l29
  br label %bb14
bb14:
  %t46 = load i32, ptr %l29
  store i32 %t46, ptr %l5
  %t47 = load i32, ptr %l5
  %t49 = trunc i64 89 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb17
bb16:
  %t52 = load i32, ptr %l5
  %t54 = trunc i64 91 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb20
bb19:
  %t58 = load i32, ptr %l5
  %t60 = trunc i64 93 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb41
bb22:
  %t68 = load i32, ptr %l5
  %t70 = trunc i64 88 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb25
bb24:
  %t73 = load i32, ptr %l5
  %t75 = trunc i64 90 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l42, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb28
bb27:
  %t79 = load i32, ptr %l5
  %t81 = trunc i64 92 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb31, label %bb32
bb30:
  %t89 = load i32, ptr %l5
  %t91 = trunc i64 74 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb34, label %bb35
bb31:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = sub i64 %t95, 1
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb40
bb34:
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = icmp eq i64 %t99, 0
  store i1 %t101, ptr %l55, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb36
bb36:
  %t103 = load i1, ptr %l55, !tbaa !21
  br i1 %t103, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t107 = sub i64 %t105, 1
  store i64 %t107, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb42:
  br label %bb6
bb43:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i32
  %l33 = alloca i1
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l49 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i32
  %l59 = alloca i1
  %l62 = alloca i1
  %l66 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l70 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l81 = alloca { i64, ptr }
  %l85 = alloca %"compiler/ast:Catch"
  %l88 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aCatch_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 13)
  store i1 %t8, ptr %l13
  br label %bb3
bb3:
  %t9 = load i1, ptr %l13, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb67
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t12)
  store i32 %t14, ptr %l16
  br label %bb7
bb7:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 28
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l19
  br label %bb8
bb8:
  %t21 = load i64, ptr %l19, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l20
  br label %bb9
bb9:
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %t24
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t26, i32 1)
  store i1 %t29, ptr %l24
  br label %bb10
bb10:
  %t30 = load i1, ptr %l24, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb24
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load ptr, ptr %l5, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t32)
  %t35 = extractvalue { i32, ptr } %t34, 1
  %t36 = extractvalue { i32, ptr } %t34, 0
  store i32 %t36, ptr %l29
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb15, label %ok.38
ok.38:
  store ptr %t35, ptr %l28
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l28, !tbaa !29
  store ptr %t39, ptr %l26, !tbaa !29
  br label %bb16
bb15:
  %t40 = load i32, ptr %l29, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t50 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t48, 0
  store { i32, { i64, ptr } } %t50, ptr %rv
  br label %ret
bb16:
  %t51 = load ptr, ptr %l25, !tbaa !29
  %t52 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t51, ptr %t52)
  br label %bb17
bb17:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t53, i32 55)
  store i1 %t56, ptr %l33
  br label %bb18
bb18:
  %t57 = load i1, ptr %l33, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  br label %bb13
bb23:
  br label %bb24
bb24:
  %t60 = icmp sge i64 0, 0
  br i1 %t60, label %bb25, label %bb26
bb25:
  %t62 = icmp sle i64 0, 1152921504606846975
  br i1 %t62, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746)
  unreachable
bb27:
  %t64 = mul i64 0, 8
  %t65 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 0, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l6, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t69, i32 92)
  store i1 %t72, ptr %l40
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746)
  unreachable
bb29:
  %t73 = load i1, ptr %l40, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  %t74 = load i1, ptr %l7, !tbaa !21
  br i1 %t74, label %bb30, label %bb31
bb30:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t76)
  %t79 = extractvalue { i32, { i64, ptr } } %t78, 1
  %t80 = extractvalue { i32, { i64, ptr } } %t78, 0
  store i32 %t80, ptr %l45
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb33, label %ok.82
ok.82:
  store { i64, ptr } %t79, ptr %l44
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t83 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t83, ptr %l42, !tbaa !27
  br label %bb34
bb33:
  %t84 = load i32, ptr %l45, !tbaa !23
  %t85 = lshr i32 %t84, 16
  %t86 = and i32 %t84, 65535
  %t87 = icmp eq i32 %t85, 1
  %t88 = select i1 %t87, i32 1, i32 0
  %t89 = icmp eq i32 %t84, 0
  %t90 = shl i32 %t88, 16
  %t91 = or i32 %t90, %t86
  %t92 = select i1 %t89, i32 0, i32 %t91
  call void @__olang_scope_close(ptr %s1)
  %t94 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t92, 0
  store { i32, { i64, ptr } } %t94, ptr %rv
  br label %ret
bb34:
  %t95 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t95, ptr %l6, !tbaa !27
  br label %bb35
bb35:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t99 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t96, i32 44)
  store i1 %t99, ptr %l49
  br label %bb36
bb36:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  %t101 = load i1, ptr %l7, !tbaa !21
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb53, label %bb54
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 28
  store ptr %t107, ptr %l51, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t108)
  %t111 = extractvalue { i32, ptr } %t110, 1
  %t112 = extractvalue { i32, ptr } %t110, 0
  store i32 %t112, ptr %l55
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb41, label %ok.114
ok.114:
  store ptr %t111, ptr %l54
  br label %bb40
bb40:
  %t115 = load ptr, ptr %l54, !tbaa !29
  store ptr %t115, ptr %l52, !tbaa !29
  br label %bb42
bb41:
  %t116 = load i32, ptr %l55, !tbaa !23
  %t117 = lshr i32 %t116, 16
  %t118 = and i32 %t116, 65535
  %t119 = icmp eq i32 %t117, 1
  %t120 = select i1 %t119, i32 1, i32 0
  %t121 = icmp eq i32 %t116, 0
  %t122 = shl i32 %t120, 16
  %t123 = or i32 %t122, %t118
  %t124 = select i1 %t121, i32 0, i32 %t123
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s1)
  %t126 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t124, 0
  store { i32, { i64, ptr } } %t126, ptr %rv
  br label %ret
bb42:
  %t127 = load ptr, ptr %l51, !tbaa !29
  %t128 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t127, ptr %t128)
  br label %bb43
bb43:
  %t131 = xor i1 %a1, true
  br i1 %t131, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb47
bb45:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t136 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t133, i32 55)
  store i1 %t136, ptr %l62
  br label %bb46
bb46:
  %t137 = load i1, ptr %l62, !tbaa !21
  %t138 = xor i1 %t137, true
  store i1 %t138, ptr %l59, !tbaa !21
  br label %bb47
bb47:
  %t140 = load i1, ptr %l59, !tbaa !21
  br i1 %t140, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb51:
  br label %bb39
bb52:
  br label %bb60
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l66, !tbaa !29
  %t143 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s10, i32 92)
  store { i64, ptr } %t143, ptr %l68
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t144 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t151 = load ptr, ptr %l66, !tbaa !29
  %t153 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s10, ptr %t151, { i64, ptr } %t150)
  store i32 %t153, ptr %l70
  %t154 = icmp ne i32 %t153, 0
  br i1 %t154, label %bb57, label %ok.155
ok.155:
  br label %bb56
bb56:
  br label %bb58
bb57:
  %t156 = load i32, ptr %l70, !tbaa !23
  %t157 = lshr i32 %t156, 16
  %t158 = and i32 %t156, 65535
  %t159 = icmp eq i32 %t157, 1
  %t160 = select i1 %t159, i32 1, i32 0
  %t161 = icmp eq i32 %t156, 0
  %t162 = shl i32 %t160, 16
  %t163 = or i32 %t162, %t158
  %t164 = select i1 %t161, i32 0, i32 %t163
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s1)
  %t166 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t164, 0
  store { i32, { i64, ptr } } %t166, ptr %rv
  br label %ret
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/parse:Parser", ptr %t167, i32 0, i32 28
  %t170 = load i64, ptr %l4, !tbaa !24
  %t173 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t169, i64 %t170)
  store { i64, ptr } %t173, ptr %l75
  br label %bb61
bb61:
  %t174 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t174, ptr %l8, !tbaa !27
  %t175 = load ptr, ptr %l2, !tbaa !29
  store ptr %t175, ptr %l76, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t176, i32 %t177)
  store %"compiler/source:Span" %t180, ptr %l79
  br label %bb62
bb62:
  %t181 = load ptr, ptr %l5, !tbaa !29
  %t183 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t181)
  store { i64, ptr } %t183, ptr %l81
  br label %bb63
bb63:
  %t184 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t186 = load i1, ptr %l7, !tbaa !21
  %t187 = load %"compiler/source:Span", ptr %l79
  %t188 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t192 = call %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t187, { i64, ptr } %t188, { i64, ptr } %t184, { i64, ptr } %t185, i1 %t186)
  store %"compiler/ast:Catch" %t192, ptr %l85
  br label %bb64
bb64:
  %t193 = load %"compiler/ast:Catch", ptr %l85
  %t194 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:Catch" %t193, ptr %t194
  %t195 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCatch_26_3e_2ePush_3ccompiler_2fast_3aCatch_26_3e(ptr %v0, ptr %v0, ptr %t195, ptr %t194)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s1)
  br label %bb66
bb66:
  br label %bb2
bb67:
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t199 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCatch_26_3e_2eToAr_He5e8e2567a6e85f3fd99cc3485ad491f(ptr %v0, ptr %v0, ptr %t197)
  store { i64, ptr } %t199, ptr %l88
  br label %bb68
bb68:
  %t200 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t201 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t200, 1
  store { i32, { i64, ptr } } %t201, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 79 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 87 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 80 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb9:
  %t22 = load i32, ptr %l1
  %t24 = trunc i64 67 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l12, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l25 = alloca i1
  %l28 = alloca { i64, ptr }
  %l37 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/scan:Tokens", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr %"compiler/token:Token", ptr %t16, i64 %t13
  %t18 = getelementptr %"compiler/token:Token", ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  %t21 = trunc i64 8 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/scan:Tokens", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = sub i64 %t33, 1
  %t38 = icmp slt i64 %t24, %t35
  store i1 %t38, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t40 = load i1, ptr %l10, !tbaa !21
  %t41 = xor i1 %t40, true
  br i1 %t41, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 7
  %t50 = load i32, ptr %t49
  %t52 = trunc i64 0 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb12
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/scan:Tokens", ptr %t60, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l28, !tbaa !27
  %t64 = load i64, ptr %l1, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr %"compiler/token:Token", ptr %t67, i64 %t64
  %t69 = getelementptr %"compiler/token:Token", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69
  %t72 = trunc i64 24 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t75 = xor i1 %t73, true
  store i1 %t75, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t77 = load i1, ptr %l25, !tbaa !21
  br i1 %t77, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l1, !tbaa !24
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t79, i32 0, i32 6
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t84)
  store i32 %t86, ptr %l37
  br label %bb16
bb16:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l23 = alloca i1
  %l25 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i32
  %l47 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i32
  %l59 = alloca i1
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i32
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i32
  %l99 = alloca %"compiler/source:Span"
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca i32
  %l109 = alloca %"compiler/ast:Compr"
  %s9 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t161 = alloca { i64, [5 x i64] }, align 8
  %t272 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 17
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l4, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 17
  store i1 true, ptr %t8, !tbaa !21
  store i32 0, ptr %l5, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t9)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l17
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15
ok.15:
  store i32 %t12, ptr %l16
  br label %bb1
bb1:
  %t16 = load i32, ptr %l16, !tbaa !23
  store i32 %t16, ptr %l14, !tbaa !23
  br label %bb3
bb2:
  %t17 = load i32, ptr %l17, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i1, ptr %l4, !tbaa !21
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 17
  store i1 %t27, ptr %t30, !tbaa !21
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t25, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb3:
  %t33 = load i32, ptr %l14, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t37 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t34, i32 55)
  store i1 %t37, ptr %l23
  br label %bb4
bb4:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb5, label %bb6
bb5:
  %t39 = load i32, ptr %l6, !tbaa !23
  store i32 %t39, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t41)
  %t44 = extractvalue { i32, i32 } %t43, 1
  %t45 = extractvalue { i32, i32 } %t43, 0
  store i32 %t45, ptr %l28
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47
ok.47:
  store i32 %t44, ptr %l27
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t48 = load i32, ptr %l27, !tbaa !23
  store i32 %t48, ptr %l25, !tbaa !23
  br label %bb9
bb8:
  %t49 = load i32, ptr %l28, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i1, ptr %l4, !tbaa !21
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 17
  store i1 %t59, ptr %t62, !tbaa !21
  %t64 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t64, ptr %rv
  br label %ret
bb9:
  %t65 = load i32, ptr %l25, !tbaa !23
  store i32 %t65, ptr %l6, !tbaa !23
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t66, i32 26)
  %t70 = extractvalue { i32, i32 } %t69, 1
  %t71 = extractvalue { i32, i32 } %t69, 0
  store i32 %t71, ptr %l36
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb12, label %ok.73
ok.73:
  store i32 %t70, ptr %l35
  br label %bb11
bb11:
  %t74 = load i32, ptr %l35, !tbaa !23
  store i32 %t74, ptr %l32, !tbaa !23
  br label %bb13
bb12:
  %t75 = load i32, ptr %l36, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i1, ptr %l4, !tbaa !21
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 17
  store i1 %t85, ptr %t88, !tbaa !21
  %t90 = insertvalue { i32, ptr } zeroinitializer, i32 %t83, 0
  store { i32, ptr } %t90, ptr %rv
  br label %ret
bb13:
  store ptr null, ptr %l7, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t91, i32 29)
  store i1 %t94, ptr %l42
  br label %bb14
bb14:
  %t95 = load i1, ptr %l42, !tbaa !21
  br i1 %t95, label %bb15, label %bb16
bb15:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t96)
  store i32 %t98, ptr %l44
  br label %bb17
bb16:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t99, i64 1)
  %t102 = extractvalue { i32, ptr } %t101, 1
  %t103 = extractvalue { i32, ptr } %t101, 0
  store i32 %t103, ptr %l73
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb33, label %ok.105
ok.105:
  store ptr %t102, ptr %l72
  br label %bb32
bb17:
  %t106 = load i32, ptr %l44, !tbaa !23
  store i32 %t106, ptr %l8, !tbaa !23
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/parse:Parser", ptr %t107, i32 0, i32 28
  %t111 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l47
  br label %bb18
bb18:
  %t112 = load i64, ptr %l47, !tbaa !24
  store i64 %t112, ptr %l9, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s9
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t113, i32 0, i32 28
  store ptr %t115, ptr %l49, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t116, i64 1)
  %t119 = extractvalue { i32, ptr } %t118, 1
  %t120 = extractvalue { i32, ptr } %t118, 0
  store i32 %t120, ptr %l53
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb21, label %ok.122
ok.122:
  store ptr %t119, ptr %l52
  br label %bb20
bb20:
  %t123 = load ptr, ptr %l52, !tbaa !29
  store ptr %t123, ptr %l50, !tbaa !29
  br label %bb22
bb21:
  %t124 = load i32, ptr %l53, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  call void @__olang_scope_close(ptr %s9)
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i1, ptr %l4, !tbaa !21
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 17
  store i1 %t134, ptr %t137, !tbaa !21
  %t139 = insertvalue { i32, ptr } zeroinitializer, i32 %t132, 0
  store { i32, ptr } %t139, ptr %rv
  br label %ret
bb22:
  %t140 = load ptr, ptr %l49, !tbaa !29
  %t141 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t140, ptr %t141)
  br label %bb23
bb23:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t142, i32 55)
  store i1 %t145, ptr %l59
  br label %bb24
bb24:
  %t146 = load i1, ptr %l59, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s9)
  br label %bb29
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  br label %bb19
bb29:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l8, !tbaa !23
  %t153 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t149, i32 %t150)
  store %"compiler/source:Span" %t153, ptr %l63
  br label %bb30
bb30:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/parse:Parser", ptr %t154, i32 0, i32 28
  %t157 = load i64, ptr %l9, !tbaa !24
  %t160 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t156, i64 %t157)
  store { i64, ptr } %t160, ptr %l67
  br label %bb31
bb31:
  store { i64, [5 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 0
  store i64 25, ptr %t162
  %t163 = load %"compiler/source:Span", ptr %l63
  %t164 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t163, 0
  %t165 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t166 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t164, { i64, ptr } %t165, 1
  %t167 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t166, ptr %t167
  %t168 = load { i64, [5 x i64] }, ptr %t161
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t168, ptr %t170
  store ptr %t170, ptr %l7, !tbaa !29
  br label %bb35
bb32:
  %t172 = load ptr, ptr %l72, !tbaa !29
  store ptr %t172, ptr %l70, !tbaa !29
  br label %bb34
bb33:
  %t173 = load i32, ptr %l73, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 1, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l4, !tbaa !21
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t182, i32 0, i32 17
  store i1 %t183, ptr %t186, !tbaa !21
  %t188 = insertvalue { i32, ptr } zeroinitializer, i32 %t181, 0
  store { i32, ptr } %t188, ptr %rv
  br label %ret
bb34:
  %t189 = load ptr, ptr %l70, !tbaa !29
  store ptr %t189, ptr %l7, !tbaa !29
  br label %bb35
bb35:
  store ptr null, ptr %l10, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t194 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t191, i32 9)
  store i1 %t194, ptr %l80
  br label %bb36
bb36:
  %t195 = load i1, ptr %l80, !tbaa !21
  br i1 %t195, label %bb37, label %bb38
bb37:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t196, i64 1)
  %t199 = extractvalue { i32, ptr } %t198, 1
  %t200 = extractvalue { i32, ptr } %t198, 0
  store i32 %t200, ptr %l84
  %t201 = icmp ne i32 %t200, 0
  br i1 %t201, label %bb40, label %ok.202
ok.202:
  store ptr %t199, ptr %l83
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t203 = load ptr, ptr %l83, !tbaa !29
  store ptr %t203, ptr %l81, !tbaa !29
  br label %bb41
bb40:
  %t204 = load i32, ptr %l84, !tbaa !23
  %t205 = lshr i32 %t204, 16
  %t206 = and i32 %t204, 65535
  %t207 = icmp eq i32 %t205, 1
  %t208 = select i1 %t207, i32 1, i32 0
  %t209 = icmp eq i32 %t204, 0
  %t210 = shl i32 %t208, 16
  %t211 = or i32 %t210, %t206
  %t212 = select i1 %t209, i32 0, i32 %t211
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i1, ptr %l4, !tbaa !21
  %t217 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 17
  store i1 %t214, ptr %t217, !tbaa !21
  %t219 = insertvalue { i32, ptr } zeroinitializer, i32 %t212, 0
  store { i32, ptr } %t219, ptr %rv
  br label %ret
bb41:
  %t220 = load ptr, ptr %l81, !tbaa !29
  store ptr %t220, ptr %l10, !tbaa !29
  br label %bb42
bb42:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t225 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t222, i32 91)
  %t226 = extractvalue { i32, i32 } %t225, 1
  %t227 = extractvalue { i32, i32 } %t225, 0
  store i32 %t227, ptr %l93
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb44, label %ok.229
ok.229:
  store i32 %t226, ptr %l92
  br label %bb43
bb43:
  %t230 = load i32, ptr %l92, !tbaa !23
  store i32 %t230, ptr %l89, !tbaa !23
  br label %bb45
bb44:
  %t231 = load i32, ptr %l93, !tbaa !23
  %t232 = lshr i32 %t231, 16
  %t233 = and i32 %t231, 65535
  %t234 = icmp eq i32 %t232, 1
  %t235 = select i1 %t234, i32 1, i32 0
  %t236 = icmp eq i32 %t231, 0
  %t237 = shl i32 %t235, 16
  %t238 = or i32 %t237, %t233
  %t239 = select i1 %t236, i32 0, i32 %t238
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i1, ptr %l4, !tbaa !21
  %t244 = getelementptr %"compiler/parse:Parser", ptr %t240, i32 0, i32 17
  store i1 %t241, ptr %t244, !tbaa !21
  %t246 = insertvalue { i32, ptr } zeroinitializer, i32 %t239, 0
  store { i32, ptr } %t246, ptr %rv
  br label %ret
bb45:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t251 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t247, i32 %a1)
  store %"compiler/source:Span" %t251, ptr %l99
  br label %bb46
bb46:
  store ptr %a2, ptr %l101, !tbaa !29
  store ptr %a3, ptr %l102, !tbaa !29
  %t255 = load i32, ptr %l5, !tbaa !23
  store i32 %t255, ptr %l103, !tbaa !23
  %t256 = load i32, ptr %l6, !tbaa !23
  store i32 %t256, ptr %l104, !tbaa !23
  %t257 = load ptr, ptr %l7, !tbaa !29
  %t259 = icmp eq ptr %t257, null
  br i1 %t259, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_562ee49de0d7f4dc_ca929e902ecee878)
  unreachable
bb48:
  br label %bb49
bb49:
  %t261 = load ptr, ptr %l7, !tbaa !29
  %t262 = load ptr, ptr %l10, !tbaa !29
  %t263 = load ptr, ptr %l101, !tbaa !29
  %t264 = load ptr, ptr %l102, !tbaa !29
  %t265 = load i32, ptr %l103, !tbaa !23
  %t266 = load i32, ptr %l104, !tbaa !23
  %t269 = call %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t263, ptr %t264, i32 %t265, i32 %t266, ptr %t261, ptr %t262)
  store %"compiler/ast:Compr" %t269, ptr %l109
  br label %bb50
bb50:
  %t270 = load %"compiler/ast:Compr", ptr %l109
  %t271 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:Compr" %t270, ptr %t271
  store { i64, [5 x i64] } zeroinitializer, ptr %t272
  %t273 = getelementptr { i64, [5 x i64] }, ptr %t272, i32 0, i32 0
  store i64 20, ptr %t273
  %t274 = load %"compiler/source:Span", ptr %l99
  %t275 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t274, 0
  %t277 = insertvalue { %"compiler/source:Span", ptr } %t275, ptr %t271, 1
  %t278 = getelementptr { i64, [5 x i64] }, ptr %t272, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t277, ptr %t278
  %t279 = load { i64, [5 x i64] }, ptr %t272
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t279, ptr %t281
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i1, ptr %l4, !tbaa !21
  %t286 = getelementptr %"compiler/parse:Parser", ptr %t282, i32 0, i32 17
  store i1 %t283, ptr %t286, !tbaa !21
  %t288 = insertvalue { i32, ptr } zeroinitializer, ptr %t281, 1
  store { i32, ptr } %t288, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t102 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 9)
  store i1 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i1, ptr %l6, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb8
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 16
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t15)
  store i1 %t17, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i1, ptr %l14, !tbaa !21
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l12, !tbaa !21
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = insertvalue { i32, ptr } zeroinitializer, ptr %t21, 1
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l17
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t27, i64 1)
  %t30 = extractvalue { i32, ptr } %t29, 1
  %t31 = extractvalue { i32, ptr } %t29, 0
  store i32 %t31, ptr %l21
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb14, label %ok.33
ok.33:
  store ptr %t30, ptr %l20
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l20, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  br label %bb15
bb14:
  %t35 = load i32, ptr %l21, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load ptr, ptr %l18, !tbaa !29
  store ptr %t46, ptr %l2, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t47, i32 10)
  %t51 = extractvalue { i32, i32 } %t50, 1
  %t52 = extractvalue { i32, i32 } %t50, 0
  store i32 %t52, ptr %l27
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb17, label %ok.54
ok.54:
  store i32 %t51, ptr %l26
  br label %bb16
bb16:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l23, !tbaa !23
  br label %bb18
bb17:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t67)
  %t70 = extractvalue { i32, ptr } %t69, 1
  %t71 = extractvalue { i32, ptr } %t69, 0
  store i32 %t71, ptr %l32
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb20, label %ok.73
ok.73:
  store ptr %t70, ptr %l31
  br label %bb19
bb19:
  %t74 = load ptr, ptr %l31, !tbaa !29
  store ptr %t74, ptr %l29, !tbaa !29
  br label %bb21
bb20:
  %t75 = load i32, ptr %l32, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t85 = insertvalue { i32, ptr } zeroinitializer, i32 %t83, 0
  store { i32, ptr } %t85, ptr %rv
  br label %ret
bb21:
  %t86 = load ptr, ptr %l29, !tbaa !29
  store ptr %t86, ptr %l3, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t87)
  store %"compiler/source:Span" %t89, ptr %l35
  br label %bb22
bb22:
  %t90 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 0
  %t91 = load i32, ptr %t90, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 10
  %t95 = load i32, ptr %t94, !tbaa !23
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t91, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l39
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 0
  store i64 8, ptr %t103
  %t104 = load %"compiler/source:Span", ptr %l39
  %t105 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } undef, %"compiler/source:Span" %t104, 0
  %t107 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t105, ptr %t99, 1
  %t109 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t107, ptr %t100, 2
  %t111 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t109, ptr %t101, 3
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, ptr } %t111, ptr %t112
  %t113 = load { i64, [5 x i64] }, ptr %t102
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t113, ptr %t115
  %t117 = insertvalue { i32, ptr } zeroinitializer, ptr %t115, 1
  store { i32, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtract(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l29 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i32
  %l73 = alloca ptr
  %l76 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i32
  %l88 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l100 = alloca i32
  %l101 = alloca i32
  %l109 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca %"compiler/ast:ContractBlock"
  %l126 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 40
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 6
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t4, i64 %t8)
  store i64 %t11, ptr %l13
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t12, i64 %t13)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t14, i32 90)
  %t18 = extractvalue { i32, i32 } %t17, 1
  %t19 = extractvalue { i32, i32 } %t17, 0
  store i32 %t19, ptr %l18
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb4, label %ok.21
ok.21:
  store i32 %t18, ptr %l17
  br label %bb3
bb3:
  %t22 = load i32, ptr %l17, !tbaa !23
  store i32 %t22, ptr %l14, !tbaa !23
  br label %bb5
bb4:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  %t33 = insertvalue { i32, ptr } zeroinitializer, i32 %t31, 0
  store { i32, ptr } %t33, ptr %rv
  br label %ret
bb5:
  %t34 = load i32, ptr %l14, !tbaa !23
  store i32 %t34, ptr %l1, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 14
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l2, !tbaa !21
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 18
  %t43 = load i1, ptr %t42, !tbaa !21
  store i1 %t43, ptr %l3, !tbaa !21
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/parse:Parser", ptr %t45, i32 0, i32 17
  %t48 = load i1, ptr %t47, !tbaa !21
  store i1 %t48, ptr %l4, !tbaa !21
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 14
  store i1 true, ptr %t52, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 18
  store i1 false, ptr %t55, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 17
  store i1 false, ptr %t58, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l29, !tbaa !29
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 16
  %t62 = load i64, ptr %t61, !tbaa !24
  %t64 = add i64 %t62, 1
  %t66 = load ptr, ptr %l29, !tbaa !29
  %t67 = getelementptr %"compiler/parse:Parser", ptr %t66, i32 0, i32 16
  store i64 %t64, ptr %t67, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 29
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l34
  br label %bb6
bb6:
  %t73 = load i64, ptr %l34, !tbaa !24
  store i64 %t73, ptr %l5, !tbaa !24
  %t74 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aOutlives_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l35
  br label %bb7
bb7:
  %t75 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %t76
  store ptr %t76, ptr %l6, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t78)
  br label %bb8
bb8:
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t83 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t80, i32 91)
  store i1 %t83, ptr %l40
  br label %bb10
bb10:
  %t84 = load i1, ptr %l40, !tbaa !21
  %t85 = xor i1 %t84, true
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb12:
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlivesHere(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l44
  br label %bb14
bb14:
  %t92 = load i1, ptr %l44, !tbaa !21
  br i1 %t92, label %bb15, label %bb16
bb15:
  %t93 = load ptr, ptr %l6, !tbaa !29
  store ptr %t93, ptr %l45, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlives(ptr %v0, ptr %t94)
  %t97 = extractvalue { i32, ptr } %t96, 1
  %t98 = extractvalue { i32, ptr } %t96, 0
  store i32 %t98, ptr %l49
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb18, label %ok.100
ok.100:
  store ptr %t97, ptr %l48
  br label %bb17
bb16:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/parse:Parser", ptr %t101, i32 0, i32 29
  store ptr %t103, ptr %l61, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractItem(ptr %v0, ptr %t104)
  %t107 = extractvalue { i32, ptr } %t106, 1
  %t108 = extractvalue { i32, ptr } %t106, 0
  store i32 %t108, ptr %l65
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb22, label %ok.110
ok.110:
  store ptr %t107, ptr %l64
  br label %bb21
bb17:
  %t111 = load ptr, ptr %l48, !tbaa !29
  store ptr %t111, ptr %l46, !tbaa !29
  br label %bb19
bb18:
  %t112 = load i32, ptr %l49, !tbaa !23
  %t113 = lshr i32 %t112, 16
  %t114 = and i32 %t112, 65535
  %t115 = icmp eq i32 %t113, 1
  %t116 = select i1 %t115, i32 1, i32 0
  %t117 = icmp eq i32 %t112, 0
  %t118 = shl i32 %t116, 16
  %t119 = or i32 %t118, %t114
  %t120 = select i1 %t117, i32 0, i32 %t119
  call void @__olang_scope_close(ptr %s1)
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i1, ptr %l2, !tbaa !21
  %t125 = getelementptr %"compiler/parse:Parser", ptr %t121, i32 0, i32 14
  store i1 %t122, ptr %t125, !tbaa !21
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i1, ptr %l3, !tbaa !21
  %t130 = getelementptr %"compiler/parse:Parser", ptr %t126, i32 0, i32 18
  store i1 %t127, ptr %t130, !tbaa !21
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i1, ptr %l4, !tbaa !21
  %t135 = getelementptr %"compiler/parse:Parser", ptr %t131, i32 0, i32 17
  store i1 %t132, ptr %t135, !tbaa !21
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l57, !tbaa !29
  %t137 = load ptr, ptr %l57, !tbaa !29
  %t138 = getelementptr %"compiler/parse:Parser", ptr %t137, i32 0, i32 16
  %t139 = load i64, ptr %t138, !tbaa !24
  %t141 = sub i64 %t139, 1
  %t143 = load ptr, ptr %l57, !tbaa !29
  %t144 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 16
  store i64 %t141, ptr %t144, !tbaa !24
  %t146 = insertvalue { i32, ptr } zeroinitializer, i32 %t120, 0
  store { i32, ptr } %t146, ptr %rv
  br label %ret
bb19:
  %t147 = load ptr, ptr %l45, !tbaa !29
  %t148 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aOutlives_26_3e_2eP_Hc29bd3cdf9acdad35b29137e924c1046(ptr %v0, ptr %v0, ptr %t147, ptr %t148)
  br label %bb20
bb20:
  br label %bb25
bb21:
  %t149 = load ptr, ptr %l64, !tbaa !29
  store ptr %t149, ptr %l62, !tbaa !29
  br label %bb23
bb22:
  %t150 = load i32, ptr %l65, !tbaa !23
  %t151 = lshr i32 %t150, 16
  %t152 = and i32 %t150, 65535
  %t153 = icmp eq i32 %t151, 1
  %t154 = select i1 %t153, i32 1, i32 0
  %t155 = icmp eq i32 %t150, 0
  %t156 = shl i32 %t154, 16
  %t157 = or i32 %t156, %t152
  %t158 = select i1 %t155, i32 0, i32 %t157
  call void @__olang_scope_close(ptr %s1)
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i1, ptr %l2, !tbaa !21
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 14
  store i1 %t160, ptr %t163, !tbaa !21
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i1, ptr %l3, !tbaa !21
  %t168 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 18
  store i1 %t165, ptr %t168, !tbaa !21
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i1, ptr %l4, !tbaa !21
  %t173 = getelementptr %"compiler/parse:Parser", ptr %t169, i32 0, i32 17
  store i1 %t170, ptr %t173, !tbaa !21
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l73, !tbaa !29
  %t175 = load ptr, ptr %l73, !tbaa !29
  %t176 = getelementptr %"compiler/parse:Parser", ptr %t175, i32 0, i32 16
  %t177 = load i64, ptr %t176, !tbaa !24
  %t179 = sub i64 %t177, 1
  %t181 = load ptr, ptr %l73, !tbaa !29
  %t182 = getelementptr %"compiler/parse:Parser", ptr %t181, i32 0, i32 16
  store i64 %t179, ptr %t182, !tbaa !24
  %t184 = insertvalue { i32, ptr } zeroinitializer, i32 %t158, 0
  store { i32, ptr } %t184, ptr %rv
  br label %ret
bb23:
  %t185 = load ptr, ptr %l61, !tbaa !29
  %t186 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t185, ptr %t186)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t190 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t187, i32 91)
  %t191 = extractvalue { i32, i1 } %t190, 1
  %t192 = extractvalue { i32, i1 } %t190, 0
  store i32 %t192, ptr %l80
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb27, label %ok.194
ok.194:
  store i1 %t191, ptr %l79
  br label %bb26
bb26:
  %t195 = load i1, ptr %l79, !tbaa !21
  store i1 %t195, ptr %l76, !tbaa !21
  br label %bb28
bb27:
  %t196 = load i32, ptr %l80, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  call void @__olang_scope_close(ptr %s1)
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i1, ptr %l2, !tbaa !21
  %t209 = getelementptr %"compiler/parse:Parser", ptr %t205, i32 0, i32 14
  store i1 %t206, ptr %t209, !tbaa !21
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i1, ptr %l3, !tbaa !21
  %t214 = getelementptr %"compiler/parse:Parser", ptr %t210, i32 0, i32 18
  store i1 %t211, ptr %t214, !tbaa !21
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i1, ptr %l4, !tbaa !21
  %t219 = getelementptr %"compiler/parse:Parser", ptr %t215, i32 0, i32 17
  store i1 %t216, ptr %t219, !tbaa !21
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l88, !tbaa !29
  %t221 = load ptr, ptr %l88, !tbaa !29
  %t222 = getelementptr %"compiler/parse:Parser", ptr %t221, i32 0, i32 16
  %t223 = load i64, ptr %t222, !tbaa !24
  %t225 = sub i64 %t223, 1
  %t227 = load ptr, ptr %l88, !tbaa !29
  %t228 = getelementptr %"compiler/parse:Parser", ptr %t227, i32 0, i32 16
  store i64 %t225, ptr %t228, !tbaa !24
  %t230 = insertvalue { i32, ptr } zeroinitializer, i32 %t204, 0
  store { i32, ptr } %t230, ptr %rv
  br label %ret
bb28:
  %t231 = load i1, ptr %l76, !tbaa !21
  %t232 = xor i1 %t231, true
  br i1 %t232, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s1)
  br label %bb32
bb32:
  br label %bb9
bb33:
  %t234 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t234)
  br label %bb34
bb34:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 29
  %t239 = load i64, ptr %l5, !tbaa !24
  %t242 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t238, i64 %t239)
  store { i64, ptr } %t242, ptr %l96
  br label %bb35
bb35:
  %t243 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t243, ptr %l7, !tbaa !27
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t247 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t244, i32 91)
  %t248 = extractvalue { i32, i32 } %t247, 1
  %t249 = extractvalue { i32, i32 } %t247, 0
  store i32 %t249, ptr %l101
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb37, label %ok.251
ok.251:
  store i32 %t248, ptr %l100
  br label %bb36
bb36:
  %t252 = load i32, ptr %l100, !tbaa !23
  store i32 %t252, ptr %l97, !tbaa !23
  br label %bb38
bb37:
  %t253 = load i32, ptr %l101, !tbaa !23
  %t254 = lshr i32 %t253, 16
  %t255 = and i32 %t253, 65535
  %t256 = icmp eq i32 %t254, 1
  %t257 = select i1 %t256, i32 1, i32 0
  %t258 = icmp eq i32 %t253, 0
  %t259 = shl i32 %t257, 16
  %t260 = or i32 %t259, %t255
  %t261 = select i1 %t258, i32 0, i32 %t260
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i1, ptr %l2, !tbaa !21
  %t266 = getelementptr %"compiler/parse:Parser", ptr %t262, i32 0, i32 14
  store i1 %t263, ptr %t266, !tbaa !21
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i1, ptr %l3, !tbaa !21
  %t271 = getelementptr %"compiler/parse:Parser", ptr %t267, i32 0, i32 18
  store i1 %t268, ptr %t271, !tbaa !21
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i1, ptr %l4, !tbaa !21
  %t276 = getelementptr %"compiler/parse:Parser", ptr %t272, i32 0, i32 17
  store i1 %t273, ptr %t276, !tbaa !21
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l109, !tbaa !29
  %t278 = load ptr, ptr %l109, !tbaa !29
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t278, i32 0, i32 16
  %t280 = load i64, ptr %t279, !tbaa !24
  %t282 = sub i64 %t280, 1
  %t284 = load ptr, ptr %l109, !tbaa !29
  %t285 = getelementptr %"compiler/parse:Parser", ptr %t284, i32 0, i32 16
  store i64 %t282, ptr %t285, !tbaa !24
  %t287 = insertvalue { i32, ptr } zeroinitializer, i32 %t261, 0
  store { i32, ptr } %t287, ptr %rv
  br label %ret
bb38:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i32, ptr %l1, !tbaa !23
  %t292 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t288, i32 %t289)
  store %"compiler/source:Span" %t292, ptr %l114
  br label %bb39
bb39:
  %t293 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t293, ptr %l115, !tbaa !27
  %t294 = load ptr, ptr %l6, !tbaa !29
  %t296 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aOutlives_26_3e_2eT_H8c6640c549d72ea52a64aaf5c359b5b4(ptr %v0, ptr %v0, ptr %t294)
  store { i64, ptr } %t296, ptr %l117
  br label %bb40
bb40:
  %t297 = load %"compiler/source:Span", ptr %l114
  %t298 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t300 = call %"compiler/ast:ContractBlock" @compiler_2fast_3aContractBlock_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t297, { i64, ptr } %t298, { i64, ptr } %t299)
  store %"compiler/ast:ContractBlock" %t300, ptr %l118
  br label %bb41
bb41:
  %t301 = load %"compiler/ast:ContractBlock", ptr %l118
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:ContractBlock" %t301, ptr %t302
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i1, ptr %l2, !tbaa !21
  %t307 = getelementptr %"compiler/parse:Parser", ptr %t303, i32 0, i32 14
  store i1 %t304, ptr %t307, !tbaa !21
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i1, ptr %l3, !tbaa !21
  %t312 = getelementptr %"compiler/parse:Parser", ptr %t308, i32 0, i32 18
  store i1 %t309, ptr %t312, !tbaa !21
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i1, ptr %l4, !tbaa !21
  %t317 = getelementptr %"compiler/parse:Parser", ptr %t313, i32 0, i32 17
  store i1 %t314, ptr %t317, !tbaa !21
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l126, !tbaa !29
  %t319 = load ptr, ptr %l126, !tbaa !29
  %t320 = getelementptr %"compiler/parse:Parser", ptr %t319, i32 0, i32 16
  %t321 = load i64, ptr %t320, !tbaa !24
  %t323 = sub i64 %t321, 1
  %t325 = load ptr, ptr %l126, !tbaa !29
  %t326 = getelementptr %"compiler/parse:Parser", ptr %t325, i32 0, i32 16
  store i64 %t323, ptr %t326, !tbaa !24
  %t328 = insertvalue { i32, ptr } zeroinitializer, ptr %t302, 1
  store { i32, ptr } %t328, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca ptr
  %l12 = alloca i64
  %l15 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca i64
  %l37 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca %"compiler/msgs:Msg"
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i32
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 59)
  store i1 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i1, ptr %l6, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 40
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t9, i64 %t13)
  store i64 %t16, ptr %l12
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t19, i32 59)
  store i1 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractItem(ptr %v0, ptr %t24)
  %t27 = extractvalue { i32, ptr } %t26, 1
  %t28 = extractvalue { i32, ptr } %t26, 0
  store i32 %t28, ptr %l19
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb11, label %ok.30
ok.30:
  store ptr %t27, ptr %l18
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t31 = load ptr, ptr %l18, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  br label %bb12
bb11:
  %t32 = load i32, ptr %l19, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t40, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load ptr, ptr %l16, !tbaa !29
  %t46 = insertvalue [1 x ptr] undef, ptr %t43, 0
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call ptr @__olang_scope_alloc(ptr %t48, i64 8)
  store [1 x ptr] %t46, ptr %t49
  %t50 = insertvalue { i64, ptr } undef, i64 1, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 8
  %t56 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t61, i32 92)
  %t65 = extractvalue { i32, i32 } %t64, 1
  %t66 = extractvalue { i32, i32 } %t64, 0
  store i32 %t66, ptr %l29
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb15, label %ok.68
ok.68:
  store i32 %t65, ptr %l28
  br label %bb14
bb14:
  %t69 = load i32, ptr %l28, !tbaa !23
  store i32 %t69, ptr %l25, !tbaa !23
  br label %bb16
bb15:
  %t70 = load i32, ptr %l29, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  %t80 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t78, 0
  store { i32, { i64, ptr } } %t80, ptr %rv
  br label %ret
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 29
  %t85 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t83)
  store i64 %t85, ptr %l33
  br label %bb17
bb17:
  %t86 = load i64, ptr %l33, !tbaa !24
  store i64 %t86, ptr %l2, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t87)
  br label %bb18
bb18:
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t89, i32 93)
  store i1 %t92, ptr %l37
  br label %bb20
bb20:
  %t93 = load i1, ptr %l37, !tbaa !21
  %t94 = xor i1 %t93, true
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb22:
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlivesHere(ptr %v0, ptr %t98)
  store i1 %t100, ptr %l41
  br label %bb24
bb24:
  %t101 = load i1, ptr %l41, !tbaa !21
  br i1 %t101, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l42, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t103)
  store i32 %t105, ptr %l44
  br label %bb27
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 29
  store ptr %t108, ptr %l55, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractItem(ptr %v0, ptr %t109)
  %t112 = extractvalue { i32, ptr } %t111, 1
  %t113 = extractvalue { i32, ptr } %t111, 0
  store i32 %t113, ptr %l59
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb35, label %ok.115
ok.115:
  store ptr %t112, ptr %l58
  br label %bb34
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t116)
  store i32 %t118, ptr %l46
  br label %bb28
bb28:
  %t119 = load i32, ptr %l46, !tbaa !23
  %t120 = add i32 %t119, 1
  store i32 %t120, ptr %l47, !tbaa !23
  %t121 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutlivesNested(ptr %s4)
  store %"compiler/msgs:Msg" %t121, ptr %l48
  br label %bb29
bb29:
  %t122 = load ptr, ptr %l42, !tbaa !29
  %t123 = load i32, ptr %l44, !tbaa !23
  %t124 = load i32, ptr %l47, !tbaa !23
  %t125 = load %"compiler/msgs:Msg", ptr %l48
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s4, ptr %t122, i32 %t123, i32 %t124, %"compiler/msgs:Msg" %t125)
  br label %bb30
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlives(ptr %v0, ptr %t126)
  %t129 = extractvalue { i32, ptr } %t128, 1
  %t130 = extractvalue { i32, ptr } %t128, 0
  store i32 %t130, ptr %l52
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb32, label %ok.132
ok.132:
  store ptr %t129, ptr %l51
  br label %bb31
bb31:
  %t133 = load ptr, ptr %l51, !tbaa !29
  store ptr %t133, ptr %l49, !tbaa !29
  br label %bb33
bb32:
  %t134 = load i32, ptr %l52, !tbaa !23
  %t135 = lshr i32 %t134, 16
  %t136 = and i32 %t134, 65535
  %t137 = icmp eq i32 %t135, 1
  %t138 = select i1 %t137, i32 1, i32 0
  %t139 = icmp eq i32 %t134, 0
  %t140 = shl i32 %t138, 16
  %t141 = or i32 %t140, %t136
  %t142 = select i1 %t139, i32 0, i32 %t141
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  %t144 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t142, 0
  store { i32, { i64, ptr } } %t144, ptr %rv
  br label %ret
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb34:
  %t145 = load ptr, ptr %l58, !tbaa !29
  store ptr %t145, ptr %l56, !tbaa !29
  br label %bb36
bb35:
  %t146 = load i32, ptr %l59, !tbaa !23
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t146, 0
  %t152 = shl i32 %t150, 16
  %t153 = or i32 %t152, %t148
  %t154 = select i1 %t151, i32 0, i32 %t153
  call void @__olang_scope_close(ptr %s3)
  %t156 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t154, 0
  store { i32, { i64, ptr } } %t156, ptr %rv
  br label %ret
bb36:
  %t157 = load ptr, ptr %l55, !tbaa !29
  %t158 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t157, ptr %t158)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t162 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t159, i32 93)
  %t163 = extractvalue { i32, i1 } %t162, 1
  %t164 = extractvalue { i32, i1 } %t162, 0
  store i32 %t164, ptr %l65
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb40, label %ok.166
ok.166:
  store i1 %t163, ptr %l64
  br label %bb39
bb39:
  %t167 = load i1, ptr %l64, !tbaa !21
  store i1 %t167, ptr %l61, !tbaa !21
  br label %bb41
bb40:
  %t168 = load i32, ptr %l65, !tbaa !23
  %t169 = lshr i32 %t168, 16
  %t170 = and i32 %t168, 65535
  %t171 = icmp eq i32 %t169, 1
  %t172 = select i1 %t171, i32 1, i32 0
  %t173 = icmp eq i32 %t168, 0
  %t174 = shl i32 %t172, 16
  %t175 = or i32 %t174, %t170
  %t176 = select i1 %t173, i32 0, i32 %t175
  call void @__olang_scope_close(ptr %s3)
  %t178 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t176, 0
  store { i32, { i64, ptr } } %t178, ptr %rv
  br label %ret
bb41:
  %t179 = load i1, ptr %l61, !tbaa !21
  %t180 = xor i1 %t179, true
  br i1 %t180, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb45:
  br label %bb19
bb46:
  %t182 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t182)
  br label %bb47
bb47:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t184, i32 0, i32 29
  %t187 = load i64, ptr %l2, !tbaa !24
  %t190 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t186, i64 %t187)
  store { i64, ptr } %t190, ptr %l72
  br label %bb48
bb48:
  %t191 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t191, ptr %l3, !tbaa !27
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t195 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t192, i32 93)
  %t196 = extractvalue { i32, i32 } %t195, 1
  %t197 = extractvalue { i32, i32 } %t195, 0
  store i32 %t197, ptr %l77
  %t198 = icmp ne i32 %t197, 0
  br i1 %t198, label %bb50, label %ok.199
ok.199:
  store i32 %t196, ptr %l76
  br label %bb49
bb49:
  %t200 = load i32, ptr %l76, !tbaa !23
  store i32 %t200, ptr %l73, !tbaa !23
  br label %bb51
bb50:
  %t201 = load i32, ptr %l77, !tbaa !23
  %t202 = lshr i32 %t201, 16
  %t203 = and i32 %t201, 65535
  %t204 = icmp eq i32 %t202, 1
  %t205 = select i1 %t204, i32 1, i32 0
  %t206 = icmp eq i32 %t201, 0
  %t207 = shl i32 %t205, 16
  %t208 = or i32 %t207, %t203
  %t209 = select i1 %t206, i32 0, i32 %t208
  %t211 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t209, 0
  store { i32, { i64, ptr } } %t211, ptr %rv
  br label %ret
bb51:
  %t212 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t214 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t212, 1
  store { i32, { i64, ptr } } %t214, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/parse:NameList", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/source:Span", ptr %t6, i64 0
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l3
  store ptr %a0, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l8, !tbaa !23
  %t13 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %l9, !tbaa !23
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/parse:NameList", ptr %t15, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarListCount(ptr %s0, i64 %t20, i64 %a2)
  store %"compiler/msgs:Msg" %t24, ptr %l14
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i32, ptr %l8, !tbaa !23
  %t27 = load i32, ptr %l9, !tbaa !23
  %t28 = load %"compiler/msgs:Msg", ptr %l14
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s0, ptr %t25, i32 %t26, i32 %t27, %"compiler/msgs:Msg" %t28)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca i64
  %l13 = alloca %"compiler/token:Token"
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l35 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca i32
  %l44 = alloca %"compiler/token:Token"
  %l46 = alloca i32
  %l49 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca i32
  %l57 = alloca %"compiler/source:Span"
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i32
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i32
  %l81 = alloca i32
  %l82 = alloca i32
  %l85 = alloca i32
  %l86 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i32
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l100 = alloca %"compiler/source:Span"
  %l102 = alloca i32
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca i32
  %l106 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l113 = alloca %"compiler/ast:Func"
  %l120 = alloca i32
  %l121 = alloca i32
  %l123 = alloca i32
  %l124 = alloca i32
  %l126 = alloca i32
  %l129 = alloca i32
  %l130 = alloca i32
  %l134 = alloca i64
  %l138 = alloca i1
  %l141 = alloca i32
  %l143 = alloca i32
  %l144 = alloca i32
  %l150 = alloca i32
  %l153 = alloca i32
  %l156 = alloca %"compiler/source:Span"
  %l157 = alloca i32
  %l161 = alloca { i64, ptr }
  %l167 = alloca i32
  %l170 = alloca i1
  %l172 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l176 = alloca i32
  %l179 = alloca %"compiler/token:Token"
  %l181 = alloca i32
  %l182 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca i32
  %l189 = alloca %"compiler/source:Span"
  %l192 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l200 = alloca ptr
  %l201 = alloca i32
  %l206 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l215 = alloca i32
  %l222 = alloca i32
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t113 = alloca { i64, [4 x i64] }, align 8
  %t180 = alloca { i64, [4 x i64] }, align 8
  %t307 = alloca { i64, [4 x i64] }, align 8
  %t440 = alloca { i64, [4 x i64] }, align 8
  %t535 = alloca { i64, [4 x i64] }, align 8
  %t625 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load i32, ptr %l18, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l20
  br label %bb2
bb2:
  %t8 = load i32, ptr %l20
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2
  %t11 = trunc i64 40 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb29
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l24
  br label %bb6
bb6:
  store i32 0, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t17, i32 1)
  store i1 %t20, ptr %l27
  br label %bb7
bb7:
  %t21 = load i1, ptr %l27, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t22)
  %t25 = extractvalue { i32, i32 } %t24, 1
  %t26 = extractvalue { i32, i32 } %t24, 0
  store i32 %t26, ptr %l31
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb11, label %ok.28
ok.28:
  store i32 %t25, ptr %l30
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t29 = load i32, ptr %l30, !tbaa !23
  store i32 %t29, ptr %l28, !tbaa !23
  br label %bb12
bb11:
  %t30 = load i32, ptr %l31, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb12:
  %t41 = load i32, ptr %l28, !tbaa !23
  store i32 %t41, ptr %l3, !tbaa !23
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t42, i32 5)
  store i1 %t45, ptr %l35
  br label %bb14
bb14:
  %t46 = load i1, ptr %l35, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l37, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s3, i32 5)
  store { i64, ptr } %t51, ptr %l39
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t52 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t61 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s3, ptr %t59, { i64, ptr } %t58)
  store i32 %t61, ptr %l41
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb19, label %ok.63
ok.63:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  call void @__olang_scope_close(ptr %s3)
  %t74 = insertvalue { i32, ptr } zeroinitializer, i32 %t72, 0
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t75)
  store %"compiler/token:Token" %t77, ptr %l44
  br label %bb22
bb22:
  %t78 = load %"compiler/token:Token", ptr %l44
  store %"compiler/token:Token" %t78, ptr %l4
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l46
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t82, i32 %t83)
  store %"compiler/source:Span" %t86, ptr %l49
  br label %bb24
bb24:
  %t87 = load %"compiler/source:Span", ptr %l49
  store %"compiler/source:Span" %t87, ptr %l5
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t88)
  store i32 %t90, ptr %l51
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb26, label %ok.92
ok.92:
  br label %bb25
bb25:
  br label %bb27
bb26:
  %t93 = load i32, ptr %l51, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  %t103 = insertvalue { i32, ptr } zeroinitializer, i32 %t101, 0
  store { i32, ptr } %t103, ptr %rv
  br label %ret
bb27:
  %t104 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t104, ptr %l53
  %t105 = load i32, ptr %l3, !tbaa !23
  store i32 %t105, ptr %l54, !tbaa !23
  %t106 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 2
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t109 = load i32, ptr %t108, !tbaa !23
  %t112 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t107, i32 %t109)
  store %"compiler/source:Span" %t112, ptr %l57
  br label %bb28
bb28:
  store { i64, [4 x i64] } zeroinitializer, ptr %t113
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 0
  store i64 4, ptr %t114
  %t115 = load %"compiler/source:Span", ptr %l53
  %t116 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span" } undef, %"compiler/source:Span" %t115, 0
  %t117 = load i32, ptr %l54, !tbaa !23
  %t118 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span" } %t116, i32 %t117, 1
  %t119 = load %"compiler/source:Span", ptr %l57
  %t120 = insertvalue { %"compiler/source:Span", i32, %"compiler/source:Span" } %t118, %"compiler/source:Span" %t119, 2
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  store { %"compiler/source:Span", i32, %"compiler/source:Span" } %t120, ptr %t121
  %t122 = load { i64, [4 x i64] }, ptr %t113
  %t124 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t122, ptr %t124
  %t126 = insertvalue { i32, ptr } zeroinitializer, ptr %t124, 1
  store { i32, ptr } %t126, ptr %rv
  br label %ret
bb29:
  %t127 = load i32, ptr %l2
  %t129 = trunc i64 33 to i32
  %t130 = icmp eq i32 %t127, %t129
  br i1 %t130, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDecl(ptr %v0, ptr %t132)
  %t135 = extractvalue { i32, ptr } %t134, 1
  %t136 = extractvalue { i32, ptr } %t134, 0
  store i32 %t136, ptr %l65
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb34, label %ok.138
ok.138:
  store ptr %t135, ptr %l64
  br label %bb33
bb33:
  %t139 = load ptr, ptr %l64, !tbaa !29
  store ptr %t139, ptr %l62, !tbaa !29
  br label %bb35
bb34:
  %t140 = load i32, ptr %l65, !tbaa !23
  %t141 = lshr i32 %t140, 16
  %t142 = and i32 %t140, 65535
  %t143 = icmp eq i32 %t141, 1
  %t144 = select i1 %t143, i32 1, i32 0
  %t145 = icmp eq i32 %t140, 0
  %t146 = shl i32 %t144, 16
  %t147 = or i32 %t146, %t142
  %t148 = select i1 %t145, i32 0, i32 %t147
  %t150 = insertvalue { i32, ptr } zeroinitializer, i32 %t148, 0
  store { i32, ptr } %t150, ptr %rv
  br label %ret
bb35:
  %t151 = load ptr, ptr %l62, !tbaa !29
  %t153 = insertvalue { i32, ptr } zeroinitializer, ptr %t151, 1
  store { i32, ptr } %t153, ptr %rv
  br label %ret
bb36:
  %t154 = load i32, ptr %l2
  %t156 = trunc i64 37 to i32
  %t157 = icmp eq i32 %t154, %t156
  br i1 %t157, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efunction(ptr %v0, ptr %t159)
  %t162 = extractvalue { i32, ptr } %t161, 1
  %t163 = extractvalue { i32, ptr } %t161, 0
  store i32 %t163, ptr %l73
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb41, label %ok.165
ok.165:
  store ptr %t162, ptr %l72
  br label %bb40
bb40:
  %t166 = load ptr, ptr %l72, !tbaa !29
  store ptr %t166, ptr %l70, !tbaa !29
  br label %bb42
bb41:
  %t167 = load i32, ptr %l73, !tbaa !23
  %t168 = lshr i32 %t167, 16
  %t169 = and i32 %t167, 65535
  %t170 = icmp eq i32 %t168, 1
  %t171 = select i1 %t170, i32 1, i32 0
  %t172 = icmp eq i32 %t167, 0
  %t173 = shl i32 %t171, 16
  %t174 = or i32 %t173, %t169
  %t175 = select i1 %t172, i32 0, i32 %t174
  %t177 = insertvalue { i32, ptr } zeroinitializer, i32 %t175, 0
  store { i32, ptr } %t177, ptr %rv
  br label %ret
bb42:
  %t178 = load ptr, ptr %l70, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 0
  store i64 0, ptr %t181
  %t183 = insertvalue { ptr } undef, ptr %t178, 0
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  store { ptr } %t183, ptr %t184
  %t185 = load { i64, [4 x i64] }, ptr %t180
  %t187 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t185, ptr %t187
  %t189 = insertvalue { i32, ptr } zeroinitializer, ptr %t187, 1
  store { i32, ptr } %t189, ptr %rv
  br label %ret
bb43:
  %t190 = load i32, ptr %l2
  %t192 = trunc i64 43 to i32
  %t193 = icmp eq i32 %t190, %t192
  br i1 %t193, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb70
bb46:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t195)
  store i32 %t197, ptr %l81
  br label %bb47
bb47:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t201 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t198, i32 37)
  %t202 = extractvalue { i32, i32 } %t201, 1
  %t203 = extractvalue { i32, i32 } %t201, 0
  store i32 %t203, ptr %l86
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb49, label %ok.205
ok.205:
  store i32 %t202, ptr %l85
  br label %bb48
bb48:
  %t206 = load i32, ptr %l85, !tbaa !23
  store i32 %t206, ptr %l82, !tbaa !23
  br label %bb50
bb49:
  %t207 = load i32, ptr %l86, !tbaa !23
  %t208 = lshr i32 %t207, 16
  %t209 = and i32 %t207, 65535
  %t210 = icmp eq i32 %t208, 1
  %t211 = select i1 %t210, i32 1, i32 0
  %t212 = icmp eq i32 %t207, 0
  %t213 = shl i32 %t211, 16
  %t214 = or i32 %t213, %t209
  %t215 = select i1 %t212, i32 0, i32 %t214
  %t217 = insertvalue { i32, ptr } zeroinitializer, i32 %t215, 0
  store { i32, ptr } %t217, ptr %rv
  br label %ret
bb50:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t218)
  %t221 = extractvalue { i32, i32 } %t220, 1
  %t222 = extractvalue { i32, i32 } %t220, 0
  store i32 %t222, ptr %l91
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb52, label %ok.224
ok.224:
  store i32 %t221, ptr %l90
  br label %bb51
bb51:
  %t225 = load i32, ptr %l90, !tbaa !23
  store i32 %t225, ptr %l88, !tbaa !23
  br label %bb53
bb52:
  %t226 = load i32, ptr %l91, !tbaa !23
  %t227 = lshr i32 %t226, 16
  %t228 = and i32 %t226, 65535
  %t229 = icmp eq i32 %t227, 1
  %t230 = select i1 %t229, i32 1, i32 0
  %t231 = icmp eq i32 %t226, 0
  %t232 = shl i32 %t230, 16
  %t233 = or i32 %t232, %t228
  %t234 = select i1 %t231, i32 0, i32 %t233
  %t236 = insertvalue { i32, ptr } zeroinitializer, i32 %t234, 0
  store { i32, ptr } %t236, ptr %rv
  br label %ret
bb53:
  %t237 = load i32, ptr %l88, !tbaa !23
  store i32 %t237, ptr %l7, !tbaa !23
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t238, i1 false, i1 false, i1 false)
  %t241 = extractvalue { i32, ptr } %t240, 1
  %t242 = extractvalue { i32, ptr } %t240, 0
  store i32 %t242, ptr %l96
  %t243 = icmp ne i32 %t242, 0
  br i1 %t243, label %bb55, label %ok.244
ok.244:
  store ptr %t241, ptr %l95
  br label %bb54
bb54:
  %t245 = load ptr, ptr %l95, !tbaa !29
  store ptr %t245, ptr %l93, !tbaa !29
  br label %bb56
bb55:
  %t246 = load i32, ptr %l96, !tbaa !23
  %t247 = lshr i32 %t246, 16
  %t248 = and i32 %t246, 65535
  %t249 = icmp eq i32 %t247, 1
  %t250 = select i1 %t249, i32 1, i32 0
  %t251 = icmp eq i32 %t246, 0
  %t252 = shl i32 %t250, 16
  %t253 = or i32 %t252, %t248
  %t254 = select i1 %t251, i32 0, i32 %t253
  %t256 = insertvalue { i32, ptr } zeroinitializer, i32 %t254, 0
  store { i32, ptr } %t256, ptr %rv
  br label %ret
bb56:
  %t257 = load ptr, ptr %l93, !tbaa !29
  store ptr %t257, ptr %l8, !tbaa !29
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l1, !tbaa !23
  %t262 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t258, i32 %t259)
  store %"compiler/source:Span" %t262, ptr %l100
  br label %bb57
bb57:
  %t263 = load %"compiler/source:Span", ptr %l100
  store %"compiler/source:Span" %t263, ptr %l9
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t264)
  store i32 %t266, ptr %l102
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb59, label %ok.268
ok.268:
  br label %bb58
bb58:
  br label %bb60
bb59:
  %t269 = load i32, ptr %l102, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 1, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  %t279 = insertvalue { i32, ptr } zeroinitializer, i32 %t277, 0
  store { i32, ptr } %t279, ptr %rv
  br label %ret
bb60:
  %t280 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t280, ptr %l104
  %t281 = load i32, ptr %l7, !tbaa !23
  store i32 %t281, ptr %l105, !tbaa !23
  %t282 = load ptr, ptr %l8, !tbaa !29
  store ptr %t282, ptr %l106, !tbaa !29
  %t283 = icmp sge i64 0, 0
  br i1 %t283, label %bb61, label %bb62
bb61:
  %t285 = icmp sle i64 0, 1152921504606846975
  br i1 %t285, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe)
  unreachable
bb63:
  %t287 = mul i64 0, 8
  %t288 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t287)
  %t289 = insertvalue { i64, ptr } undef, i64 0, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  store { i64, ptr } %t290, ptr %l109, !tbaa !27
  %t291 = icmp sge i64 0, 0
  br i1 %t291, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe)
  unreachable
bb65:
  %t293 = icmp sle i64 0, 1152921504606846975
  br i1 %t293, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe)
  unreachable
bb67:
  %t295 = mul i64 0, 8
  %t296 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t295)
  %t297 = insertvalue { i64, ptr } undef, i64 0, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  %t299 = load %"compiler/source:Span", ptr %l104
  %t300 = load i32, ptr %l105, !tbaa !23
  %t301 = load ptr, ptr %l106, !tbaa !29
  %t302 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t304 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t299, ptr null, i32 %t300, ptr %t301, { i64, ptr } %t302, { i64, ptr } %t298, i1 false)
  store %"compiler/ast:Func" %t304, ptr %l113
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe)
  unreachable
bb69:
  %t305 = load %"compiler/ast:Func", ptr %l113
  %t306 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t305, ptr %t306
  store { i64, [4 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [4 x i64] }, ptr %t307, i32 0, i32 0
  store i64 1, ptr %t308
  %t310 = insertvalue { ptr } undef, ptr %t306, 0
  %t311 = getelementptr { i64, [4 x i64] }, ptr %t307, i32 0, i32 1
  store { ptr } %t310, ptr %t311
  %t312 = load { i64, [4 x i64] }, ptr %t307
  %t314 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t312, ptr %t314
  %t316 = insertvalue { i32, ptr } zeroinitializer, ptr %t314, 1
  store { i32, ptr } %t316, ptr %rv
  br label %ret
bb70:
  %t317 = load i32, ptr %l2
  %t319 = trunc i64 38 to i32
  %t320 = icmp eq i32 %t317, %t319
  br i1 %t320, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb100
bb73:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t322)
  store i32 %t324, ptr %l120
  br label %bb74
bb74:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t325)
  %t328 = extractvalue { i32, i32 } %t327, 1
  %t329 = extractvalue { i32, i32 } %t327, 0
  store i32 %t329, ptr %l124
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb76, label %ok.331
ok.331:
  store i32 %t328, ptr %l123
  br label %bb75
bb75:
  %t332 = load i32, ptr %l123, !tbaa !23
  store i32 %t332, ptr %l121, !tbaa !23
  br label %bb77
bb76:
  %t333 = load i32, ptr %l124, !tbaa !23
  %t334 = lshr i32 %t333, 16
  %t335 = and i32 %t333, 65535
  %t336 = icmp eq i32 %t334, 1
  %t337 = select i1 %t336, i32 1, i32 0
  %t338 = icmp eq i32 %t333, 0
  %t339 = shl i32 %t337, 16
  %t340 = or i32 %t339, %t335
  %t341 = select i1 %t338, i32 0, i32 %t340
  %t343 = insertvalue { i32, ptr } zeroinitializer, i32 %t341, 0
  store { i32, ptr } %t343, ptr %rv
  br label %ret
bb77:
  %t344 = load i32, ptr %l121, !tbaa !23
  store i32 %t344, ptr %l10, !tbaa !23
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t348 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t345, i32 92)
  %t349 = extractvalue { i32, i32 } %t348, 1
  %t350 = extractvalue { i32, i32 } %t348, 0
  store i32 %t350, ptr %l130
  %t351 = icmp ne i32 %t350, 0
  br i1 %t351, label %bb79, label %ok.352
ok.352:
  store i32 %t349, ptr %l129
  br label %bb78
bb78:
  %t353 = load i32, ptr %l129, !tbaa !23
  store i32 %t353, ptr %l126, !tbaa !23
  br label %bb80
bb79:
  %t354 = load i32, ptr %l130, !tbaa !23
  %t355 = lshr i32 %t354, 16
  %t356 = and i32 %t354, 65535
  %t357 = icmp eq i32 %t355, 1
  %t358 = select i1 %t357, i32 1, i32 0
  %t359 = icmp eq i32 %t354, 0
  %t360 = shl i32 %t358, 16
  %t361 = or i32 %t360, %t356
  %t362 = select i1 %t359, i32 0, i32 %t361
  %t364 = insertvalue { i32, ptr } zeroinitializer, i32 %t362, 0
  store { i32, ptr } %t364, ptr %rv
  br label %ret
bb80:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/parse:Parser", ptr %t365, i32 0, i32 33
  %t369 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t367)
  store i64 %t369, ptr %l134
  br label %bb81
bb81:
  %t370 = load i64, ptr %l134, !tbaa !24
  store i64 %t370, ptr %l11, !tbaa !24
  %t371 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t371)
  br label %bb82
bb82:
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s8
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t376 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t373, i32 93)
  store i1 %t376, ptr %l138
  br label %bb84
bb84:
  %t377 = load i1, ptr %l138, !tbaa !21
  %t378 = xor i1 %t377, true
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s8)
  br label %bb96
bb86:
  br label %bb87
bb87:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t382)
  %t385 = extractvalue { i32, i32 } %t384, 1
  %t386 = extractvalue { i32, i32 } %t384, 0
  store i32 %t386, ptr %l144
  %t387 = icmp ne i32 %t386, 0
  br i1 %t387, label %bb89, label %ok.388
ok.388:
  store i32 %t385, ptr %l143
  br label %bb88
bb88:
  %t389 = load i32, ptr %l143, !tbaa !23
  store i32 %t389, ptr %l141, !tbaa !23
  br label %bb90
bb89:
  %t390 = load i32, ptr %l144, !tbaa !23
  %t391 = lshr i32 %t390, 16
  %t392 = and i32 %t390, 65535
  %t393 = icmp eq i32 %t391, 1
  %t394 = select i1 %t393, i32 1, i32 0
  %t395 = icmp eq i32 %t390, 0
  %t396 = shl i32 %t394, 16
  %t397 = or i32 %t396, %t392
  %t398 = select i1 %t395, i32 0, i32 %t397
  call void @__olang_scope_close(ptr %s8)
  %t400 = insertvalue { i32, ptr } zeroinitializer, i32 %t398, 0
  store { i32, ptr } %t400, ptr %rv
  br label %ret
bb90:
  %t401 = load i32, ptr %l141, !tbaa !23
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/parse:Parser", ptr %t402, i32 0, i32 33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t404, i32 %t401)
  br label %bb91
bb91:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t408)
  store i32 %t410, ptr %l150
  %t411 = icmp ne i32 %t410, 0
  br i1 %t411, label %bb93, label %ok.412
ok.412:
  br label %bb92
bb92:
  br label %bb94
bb93:
  %t413 = load i32, ptr %l150, !tbaa !23
  %t414 = lshr i32 %t413, 16
  %t415 = and i32 %t413, 65535
  %t416 = icmp eq i32 %t414, 1
  %t417 = select i1 %t416, i32 1, i32 0
  %t418 = icmp eq i32 %t413, 0
  %t419 = shl i32 %t417, 16
  %t420 = or i32 %t419, %t415
  %t421 = select i1 %t418, i32 0, i32 %t420
  call void @__olang_scope_close(ptr %s8)
  %t423 = insertvalue { i32, ptr } zeroinitializer, i32 %t421, 0
  store { i32, ptr } %t423, ptr %rv
  br label %ret
bb94:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb95:
  br label %bb83
bb96:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t424)
  store i32 %t426, ptr %l153
  br label %bb97
bb97:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l1, !tbaa !23
  %t431 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t427, i32 %t428)
  store %"compiler/source:Span" %t431, ptr %l156
  br label %bb98
bb98:
  %t432 = load i32, ptr %l10, !tbaa !23
  store i32 %t432, ptr %l157, !tbaa !23
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/parse:Parser", ptr %t433, i32 0, i32 33
  %t436 = load i64, ptr %l11, !tbaa !24
  %t439 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t435, i64 %t436)
  store { i64, ptr } %t439, ptr %l161
  br label %bb99
bb99:
  store { i64, [4 x i64] } zeroinitializer, ptr %t440
  %t441 = getelementptr { i64, [4 x i64] }, ptr %t440, i32 0, i32 0
  store i64 5, ptr %t441
  %t442 = load %"compiler/source:Span", ptr %l156
  %t443 = insertvalue { %"compiler/source:Span", i32, { i64, ptr } } undef, %"compiler/source:Span" %t442, 0
  %t444 = load i32, ptr %l157, !tbaa !23
  %t445 = insertvalue { %"compiler/source:Span", i32, { i64, ptr } } %t443, i32 %t444, 1
  %t446 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t447 = insertvalue { %"compiler/source:Span", i32, { i64, ptr } } %t445, { i64, ptr } %t446, 2
  %t448 = getelementptr { i64, [4 x i64] }, ptr %t440, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, ptr } } %t447, ptr %t448
  %t449 = load { i64, [4 x i64] }, ptr %t440
  %t451 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t449, ptr %t451
  %t453 = insertvalue { i32, ptr } zeroinitializer, ptr %t451, 1
  store { i32, ptr } %t453, ptr %rv
  br label %ret
bb100:
  %t454 = load i32, ptr %l2
  %t456 = trunc i64 41 to i32
  %t457 = icmp eq i32 %t454, %t456
  br i1 %t457, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb120
bb103:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t459)
  store i32 %t461, ptr %l167
  br label %bb104
bb104:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t465 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t462, i32 5)
  store i1 %t465, ptr %l170
  br label %bb105
bb105:
  %t466 = load i1, ptr %l170, !tbaa !21
  %t467 = xor i1 %t466, true
  br i1 %t467, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s10
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l172, !tbaa !29
  %t471 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s10, i32 5)
  store { i64, ptr } %t471, ptr %l174
  br label %bb108
bb107:
  br label %bb112
bb108:
  %t472 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t472, 0
  %t474 = extractvalue { i64, ptr } %t472, 1
  %t475 = mul i64 %t473, 1
  %t476 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t475)
  call void @llvm.memcpy.p0.p0.i64(ptr %t476, ptr %t474, i64 %t475, i1 false)
  %t477 = insertvalue { i64, ptr } undef, i64 %t473, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t476, 1
  %t479 = load ptr, ptr %l172, !tbaa !29
  %t481 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s10, ptr %t479, { i64, ptr } %t478)
  store i32 %t481, ptr %l176
  %t482 = icmp ne i32 %t481, 0
  br i1 %t482, label %bb110, label %ok.483
ok.483:
  br label %bb109
bb109:
  br label %bb111
bb110:
  %t484 = load i32, ptr %l176, !tbaa !23
  %t485 = lshr i32 %t484, 16
  %t486 = and i32 %t484, 65535
  %t487 = icmp eq i32 %t485, 1
  %t488 = select i1 %t487, i32 1, i32 0
  %t489 = icmp eq i32 %t484, 0
  %t490 = shl i32 %t488, 16
  %t491 = or i32 %t490, %t486
  %t492 = select i1 %t489, i32 0, i32 %t491
  call void @__olang_scope_close(ptr %s10)
  %t494 = insertvalue { i32, ptr } zeroinitializer, i32 %t492, 0
  store { i32, ptr } %t494, ptr %rv
  br label %ret
bb111:
  call void @__olang_scope_close(ptr %s10)
  br label %bb112
bb112:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t495)
  store %"compiler/token:Token" %t497, ptr %l179
  br label %bb113
bb113:
  %t498 = load %"compiler/token:Token", ptr %l179
  store %"compiler/token:Token" %t498, ptr %l13
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t499)
  store i32 %t501, ptr %l181
  br label %bb114
bb114:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t502)
  %t505 = extractvalue { i32, { i64, ptr } } %t504, 1
  %t506 = extractvalue { i32, { i64, ptr } } %t504, 0
  store i32 %t506, ptr %l185
  %t507 = icmp ne i32 %t506, 0
  br i1 %t507, label %bb116, label %ok.508
ok.508:
  store { i64, ptr } %t505, ptr %l184
  br label %bb115
bb115:
  %t509 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t509, ptr %l182, !tbaa !27
  br label %bb117
bb116:
  %t510 = load i32, ptr %l185, !tbaa !23
  %t511 = lshr i32 %t510, 16
  %t512 = and i32 %t510, 65535
  %t513 = icmp eq i32 %t511, 1
  %t514 = select i1 %t513, i32 1, i32 0
  %t515 = icmp eq i32 %t510, 0
  %t516 = shl i32 %t514, 16
  %t517 = or i32 %t516, %t512
  %t518 = select i1 %t515, i32 0, i32 %t517
  %t520 = insertvalue { i32, ptr } zeroinitializer, i32 %t518, 0
  store { i32, ptr } %t520, ptr %rv
  br label %ret
bb117:
  %t521 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t521, ptr %l14, !tbaa !27
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load i32, ptr %l1, !tbaa !23
  %t526 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t522, i32 %t523)
  store %"compiler/source:Span" %t526, ptr %l189
  br label %bb118
bb118:
  %t527 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 2
  %t528 = load i32, ptr %t527, !tbaa !23
  %t529 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 3
  %t530 = load i32, ptr %t529, !tbaa !23
  %t533 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t528, i32 %t530)
  store %"compiler/source:Span" %t533, ptr %l192
  br label %bb119
bb119:
  %t534 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t535
  %t536 = getelementptr { i64, [4 x i64] }, ptr %t535, i32 0, i32 0
  store i64 6, ptr %t536
  %t537 = load %"compiler/source:Span", ptr %l189
  %t538 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t537, 0
  %t539 = load %"compiler/source:Span", ptr %l192
  %t540 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t538, %"compiler/source:Span" %t539, 1
  %t542 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t540, { i64, ptr } %t534, 2
  %t543 = getelementptr { i64, [4 x i64] }, ptr %t535, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t542, ptr %t543
  %t544 = load { i64, [4 x i64] }, ptr %t535
  %t546 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t544, ptr %t546
  %t548 = insertvalue { i32, ptr } zeroinitializer, ptr %t546, 1
  store { i32, ptr } %t548, ptr %rv
  br label %ret
bb120:
  %t549 = load i32, ptr %l2
  %t551 = trunc i64 9 to i32
  %t552 = icmp eq i32 %t549, %t551
  br i1 %t552, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb127
bb123:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t556 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIf(ptr %v0, ptr %t554)
  %t557 = extractvalue { i32, ptr } %t556, 1
  %t558 = extractvalue { i32, ptr } %t556, 0
  store i32 %t558, ptr %l201
  %t559 = icmp ne i32 %t558, 0
  br i1 %t559, label %bb125, label %ok.560
ok.560:
  store ptr %t557, ptr %l200
  br label %bb124
bb124:
  %t561 = load ptr, ptr %l200, !tbaa !29
  store ptr %t561, ptr %l198, !tbaa !29
  br label %bb126
bb125:
  %t562 = load i32, ptr %l201, !tbaa !23
  %t563 = lshr i32 %t562, 16
  %t564 = and i32 %t562, 65535
  %t565 = icmp eq i32 %t563, 1
  %t566 = select i1 %t565, i32 1, i32 0
  %t567 = icmp eq i32 %t562, 0
  %t568 = shl i32 %t566, 16
  %t569 = or i32 %t568, %t564
  %t570 = select i1 %t567, i32 0, i32 %t569
  %t572 = insertvalue { i32, ptr } zeroinitializer, i32 %t570, 0
  store { i32, ptr } %t572, ptr %rv
  br label %ret
bb126:
  %t573 = load ptr, ptr %l198, !tbaa !29
  %t575 = insertvalue { i32, ptr } zeroinitializer, ptr %t573, 1
  store { i32, ptr } %t575, ptr %rv
  br label %ret
bb127:
  %t576 = load i32, ptr %l2
  %t578 = trunc i64 1 to i32
  %t579 = icmp eq i32 %t576, %t578
  br i1 %t579, label %bb128, label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb138
bb130:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclNames(ptr %v0, ptr %t581, i1 false)
  %t584 = extractvalue { i32, ptr } %t583, 1
  %t585 = extractvalue { i32, ptr } %t583, 0
  store i32 %t585, ptr %l209
  %t586 = icmp ne i32 %t585, 0
  br i1 %t586, label %bb132, label %ok.587
ok.587:
  store ptr %t584, ptr %l208
  br label %bb131
bb131:
  %t588 = load ptr, ptr %l208, !tbaa !29
  store ptr %t588, ptr %l206, !tbaa !29
  br label %bb133
bb132:
  %t589 = load i32, ptr %l209, !tbaa !23
  %t590 = lshr i32 %t589, 16
  %t591 = and i32 %t589, 65535
  %t592 = icmp eq i32 %t590, 1
  %t593 = select i1 %t592, i32 1, i32 0
  %t594 = icmp eq i32 %t589, 0
  %t595 = shl i32 %t593, 16
  %t596 = or i32 %t595, %t591
  %t597 = select i1 %t594, i32 0, i32 %t596
  %t599 = insertvalue { i32, ptr } zeroinitializer, i32 %t597, 0
  store { i32, ptr } %t599, ptr %rv
  br label %ret
bb133:
  %t600 = load ptr, ptr %l206, !tbaa !29
  store ptr %t600, ptr %l15, !tbaa !29
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load i32, ptr %l1, !tbaa !23
  %t605 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t601, i32 %t602)
  store %"compiler/source:Span" %t605, ptr %l213
  br label %bb134
bb134:
  %t606 = load %"compiler/source:Span", ptr %l213
  store %"compiler/source:Span" %t606, ptr %l16
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t609 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t607)
  store i32 %t609, ptr %l215
  %t610 = icmp ne i32 %t609, 0
  br i1 %t610, label %bb136, label %ok.611
ok.611:
  br label %bb135
bb135:
  br label %bb137
bb136:
  %t612 = load i32, ptr %l215, !tbaa !23
  %t613 = lshr i32 %t612, 16
  %t614 = and i32 %t612, 65535
  %t615 = icmp eq i32 %t613, 1
  %t616 = select i1 %t615, i32 1, i32 0
  %t617 = icmp eq i32 %t612, 0
  %t618 = shl i32 %t616, 16
  %t619 = or i32 %t618, %t614
  %t620 = select i1 %t617, i32 0, i32 %t619
  %t622 = insertvalue { i32, ptr } zeroinitializer, i32 %t620, 0
  store { i32, ptr } %t622, ptr %rv
  br label %ret
bb137:
  %t623 = load %"compiler/source:Span", ptr %l16
  %t624 = load ptr, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t625
  %t626 = getelementptr { i64, [4 x i64] }, ptr %t625, i32 0, i32 0
  store i64 3, ptr %t626
  %t628 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t623, 0
  %t630 = insertvalue { %"compiler/source:Span", ptr } %t628, ptr %t624, 1
  %t631 = getelementptr { i64, [4 x i64] }, ptr %t625, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t630, ptr %t631
  %t632 = load { i64, [4 x i64] }, ptr %t625
  %t634 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t632, ptr %t634
  %t636 = insertvalue { i32, ptr } zeroinitializer, ptr %t634, 1
  store { i32, ptr } %t636, ptr %rv
  br label %ret
bb138:
  store %olang.scope zeroinitializer, ptr %s13
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t639 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s13, ptr %t637, { i64, ptr } { i64 13, ptr @.d19 })
  store i32 %t639, ptr %l222
  %t640 = icmp ne i32 %t639, 0
  br i1 %t640, label %bb140, label %ok.641
ok.641:
  br label %bb139
bb139:
  br label %bb141
bb140:
  %t642 = load i32, ptr %l222, !tbaa !23
  %t643 = lshr i32 %t642, 16
  %t644 = and i32 %t642, 65535
  %t645 = icmp eq i32 %t643, 1
  %t646 = select i1 %t645, i32 1, i32 0
  %t647 = icmp eq i32 %t642, 0
  %t648 = shl i32 %t646, 16
  %t649 = or i32 %t648, %t644
  %t650 = select i1 %t647, i32 0, i32 %t649
  call void @__olang_scope_close(ptr %s13)
  %t652 = insertvalue { i32, ptr } zeroinitializer, i32 %t650, 0
  store { i32, ptr } %t652, ptr %rv
  br label %ret
bb141:
  call void @__olang_scope_close(ptr %s13)
  br label %bb142
bb142:
  call void @__olang_check_failed(ptr @olang_loc_2df52f758a425120_e9eb2ffac7d00514)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  store i32 %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 12
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %t10)
  store i1 %t12, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 37 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb11
bb10:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 33 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t26 = load i1, ptr %l12, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t27, i64 1)
  store i32 %t29, ptr %l16
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t30 = load i32, ptr %l16
  %t32 = trunc i64 1 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %rv
  br label %ret
bb15:
  %t35 = load i32, ptr %l1
  %t37 = trunc i64 41 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb18
bb17:
  %t40 = load i32, ptr %l1
  %t42 = trunc i64 40 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb18
bb18:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb21
bb20:
  %t46 = load i32, ptr %l1
  %t48 = trunc i64 43 to i32
  %t49 = icmp eq i32 %t46, %t48
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb21
bb21:
  %t51 = load i1, ptr %l24, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclNames(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/token:Token"
  %lp5 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"compiler/token:Token"
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca %"compiler/parse:NameList"
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t7, i32 0, i32 34
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t13)
  store %"compiler/token:Token" %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load %"compiler/token:Token", ptr %l13
  store %"compiler/token:Token" %t16, ptr %l4
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 33
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t20)
  %t23 = extractvalue { i32, i32 } %t22, 1
  %t24 = extractvalue { i32, i32 } %t22, 0
  store i32 %t24, ptr %l19
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb6, label %ok.26
ok.26:
  store i32 %t23, ptr %l18
  br label %bb5
bb5:
  %t27 = load i32, ptr %l18, !tbaa !23
  store i32 %t27, ptr %l16, !tbaa !23
  br label %bb7
bb6:
  %t28 = load i32, ptr %l19, !tbaa !23
  %t29 = lshr i32 %t28, 16
  %t30 = and i32 %t28, 65535
  %t31 = icmp eq i32 %t29, 1
  %t32 = select i1 %t31, i32 1, i32 0
  %t33 = icmp eq i32 %t28, 0
  %t34 = shl i32 %t32, 16
  %t35 = or i32 %t34, %t30
  %t36 = select i1 %t33, i32 0, i32 %t35
  call void @__olang_scope_close(ptr %s1)
  %t38 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t38, ptr %rv
  br label %ret
bb7:
  %t39 = load ptr, ptr %l15, !tbaa !29
  %t40 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t39, i32 %t40)
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 34
  store ptr %t43, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 2
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t45, i32 %t47)
  store %"compiler/source:Span" %t50, ptr %l25
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t53, i32 55)
  store i1 %t56, ptr %l28
  br label %bb11
bb11:
  %t57 = load i1, ptr %l28, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb15:
  br label %bb3
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 33
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t62, i64 %t63)
  store { i64, ptr } %t66, ptr %l33
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t67, i32 0, i32 34
  %t70 = load i64, ptr %l3, !tbaa !24
  %t73 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l37
  br label %bb18
bb18:
  %t74 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t76 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t74, { i64, ptr } %t75)
  store %"compiler/parse:NameList" %t76, ptr %l38
  br label %bb19
bb19:
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t77, ptr %lp5
  %t78 = load %"compiler/parse:NameList", ptr %l38
  %t79 = load ptr, ptr %lp5
  store %"compiler/parse:NameList" %t78, ptr %t79
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %lp5
  %t86 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v0, ptr %t80, ptr %t81, i1 %a1)
  %t87 = extractvalue { i32, ptr } %t86, 1
  %t88 = extractvalue { i32, ptr } %t86, 0
  store i32 %t88, ptr %l44
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb21, label %ok.90
ok.90:
  store ptr %t87, ptr %l43
  br label %bb20
bb20:
  %t91 = load ptr, ptr %l43, !tbaa !29
  store ptr %t91, ptr %l39, !tbaa !29
  br label %bb22
bb21:
  %t92 = load i32, ptr %l44, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  %t102 = insertvalue { i32, ptr } zeroinitializer, i32 %t100, 0
  store { i32, ptr } %t102, ptr %rv
  br label %ret
bb22:
  %t103 = load ptr, ptr %l39, !tbaa !29
  %t104 = insertvalue { i32, ptr } zeroinitializer, ptr %t103, 1
  store { i32, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %lp4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i32
  %l18 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l40 = alloca %"compiler/ast:VarDecl"
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l56 = alloca i1
  %l73 = alloca %"compiler/ast:VarDecl"
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i32
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l99 = alloca i1
  %l116 = alloca %"compiler/ast:VarDecl"
  %rv = alloca { i32, ptr }
  %t27 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 39)
  store i1 %t4, ptr %l11
  br label %bb1
bb1:
  %t5 = load i1, ptr %l11, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t6, i64 1)
  store i32 %t8, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t9 = load i32, ptr %l14
  %t11 = trunc i64 60 to i32
  %t12 = icmp eq i32 %t9, %t11
  store i1 %t12, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l18
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t18 = load i32, ptr %l18, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 10
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t18, i32 %t23)
  store %"compiler/source:Span" %t26, ptr %l22
  br label %bb9
bb9:
  store { i64, [5 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 0
  store i64 4, ptr %t28
  %t29 = load %"compiler/source:Span", ptr %l22
  %t30 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t29, 0
  %t31 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t30, ptr null, 1
  %t32 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t31, i1 true, 2
  %t33 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t32, i1 false, 3
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t33, ptr %t34
  %t35 = load { i64, [5 x i64] }, ptr %t27
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t36, ptr %lp4
  %t38 = load ptr, ptr %lp4
  store { i64, [5 x i64] } %t35, ptr %t38
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load i1, ptr %l2, !tbaa !21
  %t48 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %t42, ptr %t43, i1 %t44)
  %t49 = extractvalue { i32, { i64, ptr } } %t48, 1
  %t50 = extractvalue { i32, { i64, ptr } } %t48, 0
  store i32 %t50, ptr %l31
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb12, label %ok.52
ok.52:
  store { i64, ptr } %t49, ptr %l30
  br label %bb11
bb11:
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %l26, !tbaa !27
  br label %bb13
bb12:
  %t54 = load i32, ptr %l31, !tbaa !23
  %t55 = lshr i32 %t54, 16
  %t56 = and i32 %t54, 65535
  %t57 = icmp eq i32 %t55, 1
  %t58 = select i1 %t57, i32 1, i32 0
  %t59 = icmp eq i32 %t54, 0
  %t60 = shl i32 %t58, 16
  %t61 = or i32 %t60, %t56
  %t62 = select i1 %t59, i32 0, i32 %t61
  %t64 = insertvalue { i32, ptr } zeroinitializer, i32 %t62, 0
  store { i32, ptr } %t64, ptr %rv
  br label %ret
bb13:
  %t65 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/parse:NameList", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/parse:NameList", ptr %t70, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t74 = load ptr, ptr %lp4
  %t76 = load i1, ptr %l2, !tbaa !21
  %t82 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t69, { i64, ptr } %t73, ptr %t74, { i64, ptr } %t65, i1 true, i1 %t76)
  store %"compiler/ast:VarDecl" %t82, ptr %l40
  br label %bb14
bb14:
  %t83 = load %"compiler/ast:VarDecl", ptr %l40
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t83, ptr %t84
  %t86 = insertvalue { i32, ptr } zeroinitializer, ptr %t84, 1
  store { i32, ptr } %t86, ptr %rv
  br label %ret
bb15:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t90 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t87, i32 60)
  store i1 %t90, ptr %l44
  br label %bb16
bb16:
  %t91 = load i1, ptr %l44, !tbaa !21
  br i1 %t91, label %bb17, label %bb18
bb17:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t94 = load i1, ptr %l2, !tbaa !21
  %t98 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %t92, ptr %t93, i1 %t94)
  %t99 = extractvalue { i32, { i64, ptr } } %t98, 1
  %t100 = extractvalue { i32, { i64, ptr } } %t98, 0
  store i32 %t100, ptr %l50
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb20, label %ok.102
ok.102:
  store { i64, ptr } %t99, ptr %l49
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t103 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t103, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t104 = load i32, ptr %l50, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  %t114 = insertvalue { i32, ptr } zeroinitializer, i32 %t112, 0
  store { i32, ptr } %t114, ptr %rv
  br label %ret
bb21:
  %t115 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t115, ptr %l6, !tbaa !27
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/parse:NameList", ptr %t116, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t123 = icmp sgt i64 %t121, 1
  br i1 %t123, label %bb22, label %bb23
bb22:
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr %"compiler/parse:NameList", ptr %t128, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t136 = icmp ne i64 %t127, %t133
  store i1 %t136, ptr %l56, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t138 = load i1, ptr %l56, !tbaa !21
  br i1 %t138, label %bb25, label %bb26
bb25:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %t139, ptr %t140, i64 %t143)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/parse:NameList", ptr %t147, i32 0, i32 0
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr %"compiler/parse:NameList", ptr %t151, i32 0, i32 1
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t156 = load i1, ptr %l2, !tbaa !21
  %t161 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t150, { i64, ptr } %t154, ptr null, { i64, ptr } %t155, i1 true, i1 %t156)
  store %"compiler/ast:VarDecl" %t161, ptr %l73
  br label %bb29
bb29:
  %t162 = load %"compiler/ast:VarDecl", ptr %l73
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t162, ptr %t163
  %t165 = insertvalue { i32, ptr } zeroinitializer, ptr %t163, 1
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb30:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t166)
  %t169 = extractvalue { i32, ptr } %t168, 1
  %t170 = extractvalue { i32, ptr } %t168, 0
  store i32 %t170, ptr %l78
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb32, label %ok.172
ok.172:
  store ptr %t169, ptr %l77
  br label %bb31
bb31:
  %t173 = load ptr, ptr %l77, !tbaa !29
  store ptr %t173, ptr %l75, !tbaa !29
  br label %bb33
bb32:
  %t174 = load i32, ptr %l78, !tbaa !23
  %t175 = lshr i32 %t174, 16
  %t176 = and i32 %t174, 65535
  %t177 = icmp eq i32 %t175, 1
  %t178 = select i1 %t177, i32 1, i32 0
  %t179 = icmp eq i32 %t174, 0
  %t180 = shl i32 %t178, 16
  %t181 = or i32 %t180, %t176
  %t182 = select i1 %t179, i32 0, i32 %t181
  %t184 = insertvalue { i32, ptr } zeroinitializer, i32 %t182, 0
  store { i32, ptr } %t184, ptr %rv
  br label %ret
bb33:
  %t185 = load ptr, ptr %l75, !tbaa !29
  store ptr %t185, ptr %l7, !tbaa !29
  %t186 = icmp sge i64 0, 0
  br i1 %t186, label %bb34, label %bb35
bb34:
  %t188 = icmp sle i64 0, 1152921504606846975
  br i1 %t188, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_88b4df24f395cba0_7a8585039ef7582c)
  unreachable
bb36:
  %t190 = mul i64 0, 8
  %t191 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 0, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l8, !tbaa !27
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t198 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t195, i32 58)
  store i1 %t198, ptr %l85
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_88b4df24f395cba0_7a8585039ef7582c)
  unreachable
bb38:
  %t199 = load i1, ptr %l85, !tbaa !21
  br i1 %t199, label %bb39, label %bb40
bb39:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t202 = load i1, ptr %l2, !tbaa !21
  %t206 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %t200, ptr %t201, i1 %t202)
  %t207 = extractvalue { i32, { i64, ptr } } %t206, 1
  %t208 = extractvalue { i32, { i64, ptr } } %t206, 0
  store i32 %t208, ptr %l91
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb42, label %ok.210
ok.210:
  store { i64, ptr } %t207, ptr %l90
  br label %bb41
bb40:
  br label %bb51
bb41:
  %t211 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t211, ptr %l86, !tbaa !27
  br label %bb43
bb42:
  %t212 = load i32, ptr %l91, !tbaa !23
  %t213 = lshr i32 %t212, 16
  %t214 = and i32 %t212, 65535
  %t215 = icmp eq i32 %t213, 1
  %t216 = select i1 %t215, i32 1, i32 0
  %t217 = icmp eq i32 %t212, 0
  %t218 = shl i32 %t216, 16
  %t219 = or i32 %t218, %t214
  %t220 = select i1 %t217, i32 0, i32 %t219
  %t222 = insertvalue { i32, ptr } zeroinitializer, i32 %t220, 0
  store { i32, ptr } %t222, ptr %rv
  br label %ret
bb43:
  %t223 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t223, ptr %l8, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr %"compiler/parse:NameList", ptr %t227, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t235 = icmp ne i64 %t226, %t232
  br i1 %t235, label %bb44, label %bb45
bb44:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/parse:NameList", ptr %t237, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t244 = icmp sgt i64 %t242, 1
  store i1 %t244, ptr %l99, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t246 = load i1, ptr %l99, !tbaa !21
  br i1 %t246, label %bb47, label %bb48
bb47:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t249, 0
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecountDiag(ptr %v0, ptr %v1, ptr %t247, ptr %t248, i64 %t251)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr %"compiler/parse:NameList", ptr %t255, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr %"compiler/parse:NameList", ptr %t259, i32 0, i32 1
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t263 = load ptr, ptr %l7, !tbaa !29
  %t265 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t266 = load i1, ptr %l2, !tbaa !21
  %t272 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t258, { i64, ptr } %t262, ptr %t263, { i64, ptr } %t265, i1 false, i1 %t266)
  store %"compiler/ast:VarDecl" %t272, ptr %l116
  br label %bb52
bb52:
  %t273 = load %"compiler/ast:VarDecl", ptr %l116
  %t274 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t273, ptr %t274
  %t276 = insertvalue { i32, ptr } zeroinitializer, ptr %t274, 1
  store { i32, ptr } %t276, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendsRendering(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca i32
  %l47 = alloca i1
  %l52 = alloca i64
  %l60 = alloca i32
  %l66 = alloca i64
  %l69 = alloca i64
  %l71 = alloca i1
  %l74 = alloca i32
  %l75 = alloca i1
  %l82 = alloca i32
  %l88 = alloca i32
  %l91 = alloca i1
  %l95 = alloca i32
  %l96 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i1, ptr %l14, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 256, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t38 = load i64, ptr %l24, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb13:
  br label %bb14
bb14:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l8, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l2, !tbaa !24
  %t62 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t58, i64 %t59)
  store i32 %t62, ptr %l44
  br label %bb15
bb15:
  %t63 = load i32, ptr %l44
  store i32 %t63, ptr %l9
  %t64 = load i32, ptr %l9
  %t66 = trunc i64 89 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb18
bb17:
  %t69 = load i32, ptr %l9
  %t71 = trunc i64 91 to i32
  %t72 = icmp eq i32 %t69, %t71
  store i1 %t72, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t74 = load i1, ptr %l47, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l2, !tbaa !24
  %t79 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenerOf(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l52
  br label %bb21
bb20:
  br label %bb39
bb21:
  %t80 = load i64, ptr %l52, !tbaa !24
  store i64 %t80, ptr %l2, !tbaa !24
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = icmp slt i64 %t81, 0
  br i1 %t83, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t88 = sub i64 %t86, 1
  store i64 %t88, ptr %l10, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t90, i64 %t91)
  store i32 %t94, ptr %l60
  br label %bb25
bb25:
  %t95 = load i32, ptr %l60
  %t97 = trunc i64 85 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t101, i64 %t102)
  store i64 %t105, ptr %l66
  br label %bb29
bb29:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l2, !tbaa !24
  %t110 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t106, i64 %t107)
  store i64 %t110, ptr %l69
  br label %bb30
bb30:
  %t111 = load i64, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l69, !tbaa !24
  %t113 = icmp eq i64 %t111, %t112
  br i1 %t113, label %bb31, label %bb32
bb31:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l10, !tbaa !24
  %t119 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t115, i64 %t116)
  store i32 %t119, ptr %l74
  br label %bb33
bb32:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb35
bb33:
  %t120 = load i32, ptr %l74
  %t121 = call i1 @compiler_2fparse_2eisOperandTail(i32 %t120)
  store i1 %t121, ptr %l75
  br label %bb34
bb34:
  %t122 = load i1, ptr %l75, !tbaa !21
  store i1 %t122, ptr %l71, !tbaa !21
  br label %bb35
bb35:
  %t123 = load i1, ptr %l71, !tbaa !21
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t124 = load i64, ptr %l10, !tbaa !24
  store i64 %t124, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb53
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb39:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t129 = sub i64 %t127, 1
  store i64 %t129, ptr %l11, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t131, i64 %t132)
  store i32 %t135, ptr %l82
  br label %bb40
bb40:
  %t136 = load i32, ptr %l82
  %t138 = trunc i64 85 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t142, i64 %t143)
  store i32 %t146, ptr %l88
  br label %bb44
bb44:
  %t147 = load i32, ptr %l88
  %t149 = trunc i64 56 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb45, label %bb46
bb45:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l2, !tbaa !24
  %t155 = sub i64 %t153, 2
  %t158 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t152, i64 %t155)
  store i32 %t158, ptr %l95
  br label %bb47
bb46:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb49
bb47:
  %t159 = load i32, ptr %l95
  %t160 = call i1 @compiler_2fparse_2eisOperandTail(i32 %t159)
  store i1 %t160, ptr %l96
  br label %bb48
bb48:
  %t161 = load i1, ptr %l96, !tbaa !21
  store i1 %t161, ptr %l91, !tbaa !21
  br label %bb49
bb49:
  %t162 = load i1, ptr %l91, !tbaa !21
  br i1 %t162, label %bb50, label %bb51
bb50:
  %t163 = load i64, ptr %l2, !tbaa !24
  %t165 = sub i64 %t163, 2
  store i64 %t165, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb53
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb53:
  %t168 = load i64, ptr %l7, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l7, !tbaa !24
  br label %bb11
bb54:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l11 = alloca %"compiler/token:Token"
  %l13 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca i32
  %l21 = alloca { i64, [3 x i64] }
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l31 = alloca i1
  %l38 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i32
  %t41 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 19
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t8 = icmp sge i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 20
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb10
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 20
  store i1 true, ptr %t19, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t20)
  store %"compiler/token:Token" %t22, ptr %l11
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t23 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t23, ptr %l1
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 4
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 5
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t32)
  store i32 %t34, ptr %l17
  br label %bb6
bb6:
  %t35 = load i32, ptr %l17, !tbaa !23
  %t36 = sext i32 %t35 to i64
  %t37 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t38 = load i32, ptr %t37, !tbaa !23
  %t40 = sext i32 %t38 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t43 = load i64, ptr %l15, !tbaa !24
  %t44 = insertvalue { i64, i64, i64 } undef, i64 %t43, 0
  %t46 = insertvalue { i64, i64, i64 } %t44, i64 %t36, 1
  %t48 = insertvalue { i64, i64, i64 } %t46, i64 %t40, 2
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 1
  store { i64, i64, i64 } %t48, ptr %t49
  %t50 = load { i64, [3 x i64] }, ptr %t41
  store { i64, [3 x i64] } %t50, ptr %l21
  %t51 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %s2, i64 %t51)
  store %"compiler/msgs:Msg" %t53, ptr %l23
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l13, !tbaa !29
  %t55 = load { i64, [3 x i64] }, ptr %l21
  %t56 = load %"compiler/msgs:Msg", ptr %l23
  %t57 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %s2, ptr %t54, { i64, [3 x i64] } %t55, %"compiler/msgs:Msg" %t56)
  store i64 %t57, ptr %l24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  store i32 65536, ptr %rv
  br label %ret
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 19
  %t62 = load i64, ptr %t61, !tbaa !24
  %t64 = add i64 %t62, 1
  %t65 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t68 = icmp eq i64 %t64, %t65
  br i1 %t68, label %bb11, label %bb12
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 21
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  store i1 %t75, ptr %l31, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t77 = load i1, ptr %l31, !tbaa !21
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/parse:Parser", ptr %t79, i32 0, i32 6
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t78, i32 0, i32 21
  store i64 %t82, ptr %t85, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l38, !tbaa !29
  %t87 = load ptr, ptr %l38, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 19
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = add i64 %t89, 1
  %t93 = load ptr, ptr %l38, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t93, i32 0, i32 19
  store i64 %t91, ptr %t94, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca %"compiler/ast:Sig"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i32
  %l36 = alloca i1
  %l39 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l55 = alloca %"compiler/ast:Sig"
  %s3 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 57)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb4, label %bb5
bb3:
  br label %bb25
bb4:
  %t10 = icmp sle i64 0, 1152921504606846975
  br i1 %t10, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb6:
  %t12 = mul i64 0, 8
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = icmp sge i64 0, 0
  br i1 %t16, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb8:
  %t18 = icmp sle i64 0, 1152921504606846975
  br i1 %t18, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb10:
  %t20 = mul i64 0, 8
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 0, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l12, !tbaa !27
  %t24 = icmp sge i64 0, 0
  br i1 %t24, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb12:
  %t26 = icmp sle i64 0, 1152921504606846975
  br i1 %t26, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb14:
  %t28 = mul i64 0, 8
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 0, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l15, !tbaa !27
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1981dec301b76378_38f305e42bd9bf3c)
  unreachable
bb16:
  %t34 = icmp sle i64 0, 2305843009213693951
  br i1 %t34, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb18:
  %t36 = mul i64 0, 4
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l18, !tbaa !27
  %t40 = icmp sge i64 0, 0
  br i1 %t40, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb20:
  %t42 = icmp sle i64 0, 1152921504606846975
  br i1 %t42, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_7f2178e2c302e3c6_11752dec4e05ebca)
  unreachable
bb22:
  %t44 = mul i64 0, 8
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 0, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t48 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t53 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t48, { i64, ptr } %t49, i1 false, { i64, ptr } %t50, i1 false, { i64, ptr } %t51, { i64, ptr } %t47, ptr null)
  store %"compiler/ast:Sig" %t53, ptr %l22
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_7f2178e2c302e3c6_11752dec4e05ebca)
  unreachable
bb24:
  %t54 = load %"compiler/ast:Sig", ptr %l22
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 104, i64 8)
  store %"compiler/ast:Sig" %t54, ptr %t55
  %t57 = insertvalue { i32, ptr } zeroinitializer, ptr %t55, 1
  store { i32, ptr } %t57, ptr %rv
  br label %ret
bb25:
  %t58 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l24
  br label %bb26
bb26:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %t60
  store ptr %t60, ptr %l2, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t62, i32 1)
  store i1 %t65, ptr %l28
  br label %bb27
bb27:
  %t66 = load i1, ptr %l28, !tbaa !21
  br i1 %t66, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb44
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l2, !tbaa !29
  store ptr %t67, ptr %l29, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t68)
  %t71 = extractvalue { i32, ptr } %t70, 1
  %t72 = extractvalue { i32, ptr } %t70, 0
  store i32 %t72, ptr %l33
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb32, label %ok.74
ok.74:
  store ptr %t71, ptr %l32
  br label %bb31
bb31:
  %t75 = load ptr, ptr %l32, !tbaa !29
  store ptr %t75, ptr %l30, !tbaa !29
  br label %bb33
bb32:
  %t76 = load i32, ptr %l33, !tbaa !23
  %t77 = lshr i32 %t76, 16
  %t78 = and i32 %t76, 65535
  %t79 = icmp eq i32 %t77, 1
  %t80 = select i1 %t79, i32 1, i32 0
  %t81 = icmp eq i32 %t76, 0
  %t82 = shl i32 %t80, 16
  %t83 = or i32 %t82, %t78
  %t84 = select i1 %t81, i32 0, i32 %t83
  call void @__olang_scope_close(ptr %s3)
  %t86 = insertvalue { i32, ptr } zeroinitializer, i32 %t84, 0
  store { i32, ptr } %t86, ptr %rv
  br label %ret
bb33:
  %t87 = load ptr, ptr %l29, !tbaa !29
  %t88 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t87, ptr %t88)
  br label %bb34
bb34:
  br i1 %a1, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb38
bb36:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t91, i32 55)
  store i1 %t94, ptr %l39
  br label %bb37
bb37:
  %t95 = load i1, ptr %l39, !tbaa !21
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l36, !tbaa !21
  br label %bb38
bb38:
  %t98 = load i1, ptr %l36, !tbaa !21
  br i1 %t98, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  br label %bb30
bb43:
  br label %bb44
bb44:
  %t99 = icmp sge i64 0, 0
  br i1 %t99, label %bb45, label %bb46
bb45:
  %t101 = icmp sle i64 0, 1152921504606846975
  br i1 %t101, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_8f09c4a5443f675b_29c7c4947190fc9f)
  unreachable
bb47:
  %t103 = mul i64 0, 8
  %t104 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 0, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = icmp sge i64 0, 0
  br i1 %t107, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_8f09c4a5443f675b_29c7c4947190fc9f)
  unreachable
bb49:
  %t109 = icmp sle i64 0, 1152921504606846975
  br i1 %t109, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_8f09c4a5443f675b_29c7c4947190fc9f)
  unreachable
bb51:
  %t111 = mul i64 0, 8
  %t112 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 0, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l46, !tbaa !27
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v0, ptr %t115)
  store { i64, ptr } %t117, ptr %l48
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_8f09c4a5443f675b_29c7c4947190fc9f)
  unreachable
bb53:
  %t118 = icmp sge i64 0, 0
  br i1 %t118, label %bb54, label %bb55
bb54:
  %t120 = icmp sle i64 0, 2305843009213693951
  br i1 %t120, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb56:
  %t122 = mul i64 0, 4
  %t123 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 0, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l51, !tbaa !27
  %t126 = icmp sge i64 0, 0
  br i1 %t126, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_cd306f178609e3e5_44435844e9b3da89)
  unreachable
bb58:
  %t128 = icmp sle i64 0, 1152921504606846975
  br i1 %t128, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_7f2178e2c302e3c6_11752dec4e05ebca)
  unreachable
bb60:
  %t130 = mul i64 0, 8
  %t131 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 0, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t134 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t139 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t134, { i64, ptr } %t135, i1 true, { i64, ptr } %t136, i1 false, { i64, ptr } %t137, { i64, ptr } %t133, ptr null)
  store %"compiler/ast:Sig" %t139, ptr %l55
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_7f2178e2c302e3c6_11752dec4e05ebca)
  unreachable
bb62:
  %t140 = load %"compiler/ast:Sig", ptr %l55
  %t141 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 104, i64 8)
  store %"compiler/ast:Sig" %t140, ptr %t141
  %t143 = insertvalue { i32, ptr } zeroinitializer, ptr %t141, 1
  store { i32, ptr } %t143, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/token:Token"
  %l5 = alloca i1
  %l11 = alloca i1
  %l14 = alloca %"compiler/token:Token"
  %l15 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca %"compiler/msgs:Msg"
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 22
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i32 65536, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehint(ptr %v0, ptr %v1, ptr %t13, { i64, ptr } %t14)
  store i1 %t17, ptr %l11
  br label %bb7
bb7:
  %t18 = load i1, ptr %l11, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t21)
  store %"compiler/token:Token" %t23, ptr %l14
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t24 = load %"compiler/token:Token", ptr %l14
  store %"compiler/token:Token" %t24, ptr %l2
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t26)
  store i32 %t28, ptr %l17
  br label %bb11
bb11:
  %t29 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l18, !tbaa !23
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %s2, ptr %t32)
  store { i64, ptr } %t34, ptr %l21
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t44 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExpected(ptr %v1, ptr %s2, ptr %s2, { i64, ptr } %t42, { i64, ptr } %t41)
  store %"compiler/msgs:Msg" %t44, ptr %l23
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l15, !tbaa !29
  %t46 = load i32, ptr %l17, !tbaa !23
  %t47 = load i32, ptr %l18, !tbaa !23
  %t48 = load %"compiler/msgs:Msg", ptr %l23
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s2, ptr %t45, i32 %t46, i32 %t47, %"compiler/msgs:Msg" %t48)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efieldDecl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/token:Token"
  %l5 = alloca i32
  %l7 = alloca %"compiler/token:Token"
  %l9 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t5)
  store %"compiler/token:Token" %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load %"compiler/token:Token", ptr %l7
  store %"compiler/token:Token" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l9
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/token:Token", ptr %l2
  %t20 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t16, %"compiler/token:Token" %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t23 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  store i32 %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  store i32 %t26, ptr %l18, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i32 %t24, ptr %l20, !tbaa !23
  %t29 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t31 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t32 = load i32, ptr %t31, !tbaa !23
  %t35 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t30, i32 %t32)
  store %"compiler/source:Span" %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i32, ptr %l20, !tbaa !23
  %t38 = load %"compiler/source:Span", ptr %l23
  %t39 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %t36, i32 %t37, %"compiler/source:Span" %t38)
  store ptr %t39, ptr %l24
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l18, !tbaa !23
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v0, ptr %t40, i32 %t41, ptr %t42)
  %t44 = extractvalue { i32, ptr } %t43, 1
  %t45 = extractvalue { i32, ptr } %t43, 0
  store i32 %t45, ptr %l26
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb9, label %ok.47
ok.47:
  store ptr %t44, ptr %l25
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l25, !tbaa !29
  store ptr %t48, ptr %l16, !tbaa !29
  br label %bb10
bb9:
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s0)
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load ptr, ptr %l16, !tbaa !29
  %t61 = insertvalue { i32, ptr } zeroinitializer, ptr %t60, 1
  store { i32, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %rv = alloca { i32, ptr }
  %t36 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 29)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t6)
  store i32 %t8, ptr %l7
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l1, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %t10)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l10
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l8, !tbaa !27
  br label %bb7
bb6:
  %t18 = load i32, ptr %l11, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t30, i32 %t31)
  store %"compiler/source:Span" %t34, ptr %l15
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 25, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l15
  %t39 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t38, 0
  %t41 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t39, { i64, ptr } %t35, 1
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t41, ptr %t42
  %t43 = load { i64, [5 x i64] }, ptr %t36
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t43, ptr %t45
  %t47 = insertvalue { i32, ptr } zeroinitializer, ptr %t45, 1
  store { i32, ptr } %t47, ptr %rv
  br label %ret
bb9:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t48)
  %t51 = extractvalue { i32, ptr } %t50, 1
  %t52 = extractvalue { i32, ptr } %t50, 0
  store i32 %t52, ptr %l22
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb11, label %ok.54
ok.54:
  store ptr %t51, ptr %l21
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l21, !tbaa !29
  store ptr %t55, ptr %l19, !tbaa !29
  br label %bb12
bb11:
  %t56 = load i32, ptr %l22, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb12:
  %t67 = load ptr, ptr %l19, !tbaa !29
  %t68 = insertvalue { i32, ptr } zeroinitializer, ptr %t67, 1
  store { i32, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca %"compiler/token:Token"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 7
  %t14 = load i32, ptr %t13
  %t16 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v1, i32 %t14)
  store { i64, ptr } %t16, ptr %l8
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t18 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v1, ptr %v1, { i64, ptr } %t17)
  store { i64, ptr } %t18, ptr %l9
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t20)
  store %"compiler/token:Token" %t22, ptr %l11
  br label %bb6
bb6:
  %t23 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t23, ptr %l1
  %t24 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t25 = load i32, ptr %t24
  %t27 = trunc i64 8 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, !tbaa !27
  store { i64, ptr } %t30, ptr %l14, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l15, !tbaa !24
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l15, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t44, ptr %l14, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t47 = load i32, ptr %t46
  %t49 = trunc i64 0 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, !tbaa !27
  store { i64, ptr } %t52, ptr %l19, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l20, !tbaa !24
  %t55 = load i64, ptr %l20, !tbaa !24
  %t56 = mul i64 %t55, 1
  %t57 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l21, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l20, !tbaa !24
  %t65 = mul i64 %t64, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t66, ptr %l19, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t67, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load %"compiler/token:Token", ptr %l1
  %t72 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t68, %"compiler/token:Token" %t69)
  store { i64, ptr } %t72, ptr %l24
  br label %bb13
bb13:
  %t73 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t74 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t73)
  store { i64, ptr } %t74, ptr %l25
  br label %bb14
bb14:
  %t75 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l5 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 10
  %t5 = load i32, ptr %t4, !tbaa !23
  %t8 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %a1, i32 %t5)
  store %"compiler/source:Span" %t8, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efunction(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l53 = alloca i1
  %l58 = alloca ptr
  %l65 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i32
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l85 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca ptr
  %l96 = alloca %"compiler/ast:Func"
  %l103 = alloca %"compiler/source:Span"
  %l109 = alloca %"compiler/ast:Func"
  %rv = alloca { i32, ptr }
  %t260 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 37)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l12
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t9 = load i32, ptr %l11, !tbaa !23
  store i32 %t9, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l12, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l8, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  store ptr null, ptr %l2, !tbaa !29
  store i32 0, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t22, i32 88)
  store i1 %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %t27, i1 false)
  %t30 = extractvalue { i32, ptr } %t29, 1
  %t31 = extractvalue { i32, ptr } %t29, 0
  store i32 %t31, ptr %l20
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb8, label %ok.33
ok.33:
  store ptr %t30, ptr %l19
  br label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t34)
  %t37 = extractvalue { i32, i32 } %t36, 1
  %t38 = extractvalue { i32, i32 } %t36, 0
  store i32 %t38, ptr %l37
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb17, label %ok.40
ok.40:
  store i32 %t37, ptr %l36
  br label %bb16
bb7:
  %t41 = load ptr, ptr %l19, !tbaa !29
  store ptr %t41, ptr %l17, !tbaa !29
  br label %bb9
bb8:
  %t42 = load i32, ptr %l20, !tbaa !23
  %t43 = lshr i32 %t42, 16
  %t44 = and i32 %t42, 65535
  %t45 = icmp eq i32 %t43, 1
  %t46 = select i1 %t45, i32 1, i32 0
  %t47 = icmp eq i32 %t42, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t44
  %t50 = select i1 %t47, i32 0, i32 %t49
  %t52 = insertvalue { i32, ptr } zeroinitializer, i32 %t50, 0
  store { i32, ptr } %t52, ptr %rv
  br label %ret
bb9:
  %t53 = load ptr, ptr %l17, !tbaa !29
  store ptr %t53, ptr %l2, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t58 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t55, i32 89)
  %t59 = extractvalue { i32, i32 } %t58, 1
  %t60 = extractvalue { i32, i32 } %t58, 0
  store i32 %t60, ptr %l27
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb11, label %ok.62
ok.62:
  store i32 %t59, ptr %l26
  br label %bb10
bb10:
  %t63 = load i32, ptr %l26, !tbaa !23
  store i32 %t63, ptr %l23, !tbaa !23
  br label %bb12
bb11:
  %t64 = load i32, ptr %l27, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  %t74 = insertvalue { i32, ptr } zeroinitializer, i32 %t72, 0
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t75)
  %t78 = extractvalue { i32, i32 } %t77, 1
  %t79 = extractvalue { i32, i32 } %t77, 0
  store i32 %t79, ptr %l32
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb14, label %ok.81
ok.81:
  store i32 %t78, ptr %l31
  br label %bb13
bb13:
  %t82 = load i32, ptr %l31, !tbaa !23
  store i32 %t82, ptr %l29, !tbaa !23
  br label %bb15
bb14:
  %t83 = load i32, ptr %l32, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  %t93 = insertvalue { i32, ptr } zeroinitializer, i32 %t91, 0
  store { i32, ptr } %t93, ptr %rv
  br label %ret
bb15:
  %t94 = load i32, ptr %l29, !tbaa !23
  store i32 %t94, ptr %l3, !tbaa !23
  br label %bb19
bb16:
  %t95 = load i32, ptr %l36, !tbaa !23
  store i32 %t95, ptr %l34, !tbaa !23
  br label %bb18
bb17:
  %t96 = load i32, ptr %l37, !tbaa !23
  %t97 = lshr i32 %t96, 16
  %t98 = and i32 %t96, 65535
  %t99 = icmp eq i32 %t97, 1
  %t100 = select i1 %t99, i32 1, i32 0
  %t101 = icmp eq i32 %t96, 0
  %t102 = shl i32 %t100, 16
  %t103 = or i32 %t102, %t98
  %t104 = select i1 %t101, i32 0, i32 %t103
  %t106 = insertvalue { i32, ptr } zeroinitializer, i32 %t104, 0
  store { i32, ptr } %t106, ptr %rv
  br label %ret
bb18:
  %t107 = load i32, ptr %l34, !tbaa !23
  store i32 %t107, ptr %l3, !tbaa !23
  br label %bb19
bb19:
  %t108 = icmp sge i64 0, 0
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t110 = icmp sle i64 0, 1152921504606846975
  br i1 %t110, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea)
  unreachable
bb22:
  %t112 = mul i64 0, 8
  %t113 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 0, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l4, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t117, i32 77)
  store i1 %t120, ptr %l44
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea)
  unreachable
bb24:
  %t121 = load i1, ptr %l44, !tbaa !21
  br i1 %t121, label %bb25, label %bb26
bb25:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %t122)
  %t125 = extractvalue { i32, { i64, ptr } } %t124, 1
  %t126 = extractvalue { i32, { i64, ptr } } %t124, 0
  store i32 %t126, ptr %l48
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb28, label %ok.128
ok.128:
  store { i64, ptr } %t125, ptr %l47
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t129 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t129, ptr %l45, !tbaa !27
  br label %bb29
bb28:
  %t130 = load i32, ptr %l48, !tbaa !23
  %t131 = lshr i32 %t130, 16
  %t132 = and i32 %t130, 65535
  %t133 = icmp eq i32 %t131, 1
  %t134 = select i1 %t133, i32 1, i32 0
  %t135 = icmp eq i32 %t130, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t132
  %t138 = select i1 %t135, i32 0, i32 %t137
  %t140 = insertvalue { i32, ptr } zeroinitializer, i32 %t138, 0
  store { i32, ptr } %t140, ptr %rv
  br label %ret
bb29:
  %t141 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t141, ptr %l4, !tbaa !27
  br label %bb30
bb30:
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb31, label %bb32
bb31:
  %t148 = load ptr, ptr %l2, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Param", ptr %t148, i32 0, i32 2
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  store i1 %t155, ptr %l53, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb33
bb33:
  %t157 = load i1, ptr %l53, !tbaa !21
  br i1 %t157, label %bb34, label %bb35
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l58, !tbaa !29
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Param", ptr %t159, i32 0, i32 2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb36, label %bb37
bb35:
  br label %bb40
bb36:
  call void @__olang_check_failed(ptr @olang_loc_b7532cf042be3d05_817bd3bc9b025111)
  unreachable
bb37:
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr %"compiler/ast:Param", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t170 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v0, ptr %t170, ptr %t169, i1 false)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t172 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2escopeDecl(ptr %v0, ptr %t172)
  br label %bb41
bb41:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t174, i1 false, i1 false, i1 true)
  %t177 = extractvalue { i32, ptr } %t176, 1
  %t178 = extractvalue { i32, ptr } %t176, 0
  store i32 %t178, ptr %l68
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb43, label %ok.180
ok.180:
  store ptr %t177, ptr %l67
  br label %bb42
bb42:
  %t181 = load ptr, ptr %l67, !tbaa !29
  store ptr %t181, ptr %l65, !tbaa !29
  br label %bb44
bb43:
  %t182 = load i32, ptr %l68, !tbaa !23
  %t183 = lshr i32 %t182, 16
  %t184 = and i32 %t182, 65535
  %t185 = icmp eq i32 %t183, 1
  %t186 = select i1 %t185, i32 1, i32 0
  %t187 = icmp eq i32 %t182, 0
  %t188 = shl i32 %t186, 16
  %t189 = or i32 %t188, %t184
  %t190 = select i1 %t187, i32 0, i32 %t189
  %t192 = insertvalue { i32, ptr } zeroinitializer, i32 %t190, 0
  store { i32, ptr } %t192, ptr %rv
  br label %ret
bb44:
  %t193 = load ptr, ptr %l65, !tbaa !29
  store ptr %t193, ptr %l5, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l5, !tbaa !29
  %t198 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractOn(ptr %v0, ptr %t194, ptr %t195)
  %t199 = extractvalue { i32, ptr } %t198, 1
  %t200 = extractvalue { i32, ptr } %t198, 0
  store i32 %t200, ptr %l74
  %t201 = icmp ne i32 %t200, 0
  br i1 %t201, label %bb46, label %ok.202
ok.202:
  store ptr %t199, ptr %l73
  br label %bb45
bb45:
  %t203 = load ptr, ptr %l73, !tbaa !29
  store ptr %t203, ptr %l70, !tbaa !29
  br label %bb47
bb46:
  %t204 = load i32, ptr %l74, !tbaa !23
  %t205 = lshr i32 %t204, 16
  %t206 = and i32 %t204, 65535
  %t207 = icmp eq i32 %t205, 1
  %t208 = select i1 %t207, i32 1, i32 0
  %t209 = icmp eq i32 %t204, 0
  %t210 = shl i32 %t208, 16
  %t211 = or i32 %t210, %t206
  %t212 = select i1 %t209, i32 0, i32 %t211
  %t214 = insertvalue { i32, ptr } zeroinitializer, i32 %t212, 0
  store { i32, ptr } %t214, ptr %rv
  br label %ret
bb47:
  %t215 = load ptr, ptr %l70, !tbaa !29
  store ptr %t215, ptr %l5, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t219 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t216, i32 92)
  store i1 %t219, ptr %l78
  br label %bb48
bb48:
  %t220 = load i1, ptr %l78, !tbaa !21
  store i1 %t220, ptr %l6, !tbaa !21
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t221)
  %t224 = extractvalue { i32, { i64, ptr } } %t223, 1
  %t225 = extractvalue { i32, { i64, ptr } } %t223, 0
  store i32 %t225, ptr %l82
  %t226 = icmp ne i32 %t225, 0
  br i1 %t226, label %bb50, label %ok.227
ok.227:
  store { i64, ptr } %t224, ptr %l81
  br label %bb49
bb49:
  %t228 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t228, ptr %l79, !tbaa !27
  br label %bb62
bb50:
  br label %bb51
bb51:
  %t229 = load i1, ptr %l6, !tbaa !21
  br i1 %t229, label %bb52, label %bb53
bb52:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/parse:Parser", ptr %t231, i32 0, i32 36
  store ptr %t233, ptr %l85, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i32, ptr %l1, !tbaa !23
  %t238 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t234, i32 %t235)
  store %"compiler/source:Span" %t238, ptr %l88
  br label %bb54
bb53:
  br label %bb61
bb54:
  %t239 = load ptr, ptr %l2, !tbaa !29
  store ptr %t239, ptr %l89, !tbaa !29
  %t240 = load i32, ptr %l3, !tbaa !23
  store i32 %t240, ptr %l90, !tbaa !23
  %t241 = load ptr, ptr %l5, !tbaa !29
  store ptr %t241, ptr %l91, !tbaa !29
  %t242 = icmp sge i64 0, 0
  br i1 %t242, label %bb55, label %bb56
bb55:
  %t244 = icmp sle i64 0, 1152921504606846975
  br i1 %t244, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c)
  unreachable
bb57:
  %t246 = mul i64 0, 8
  %t247 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t246)
  %t248 = insertvalue { i64, ptr } undef, i64 0, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  %t250 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t251 = load %"compiler/source:Span", ptr %l88
  %t252 = load ptr, ptr %l89, !tbaa !29
  %t253 = load i32, ptr %l90, !tbaa !23
  %t254 = load ptr, ptr %l91, !tbaa !29
  %t257 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t251, ptr %t252, i32 %t253, ptr %t254, { i64, ptr } %t249, { i64, ptr } %t250, i1 false)
  store %"compiler/ast:Func" %t257, ptr %l96
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c)
  unreachable
bb59:
  %t258 = load %"compiler/ast:Func", ptr %l96
  %t259 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t258, ptr %t259
  store { i64, [4 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [4 x i64] }, ptr %t260, i32 0, i32 0
  store i64 0, ptr %t261
  %t263 = insertvalue { ptr } undef, ptr %t259, 0
  %t264 = getelementptr { i64, [4 x i64] }, ptr %t260, i32 0, i32 1
  store { ptr } %t263, ptr %t264
  %t265 = load { i64, [4 x i64] }, ptr %t260
  %t267 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t265, ptr %t267
  %t268 = load ptr, ptr %l85, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t268, ptr %t267)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t271 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t271, ptr %rv
  br label %ret
bb62:
  %t272 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t272, ptr %l7, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i32, ptr %l1, !tbaa !23
  %t277 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t273, i32 %t274)
  store %"compiler/source:Span" %t277, ptr %l103
  br label %bb63
bb63:
  %t278 = load ptr, ptr %l2, !tbaa !29
  %t279 = load i32, ptr %l3, !tbaa !23
  %t280 = load ptr, ptr %l5, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t283 = load %"compiler/source:Span", ptr %l103
  %t289 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t283, ptr %t278, i32 %t279, ptr %t280, { i64, ptr } %t281, { i64, ptr } %t282, i1 true)
  store %"compiler/ast:Func" %t289, ptr %l109
  br label %bb64
bb64:
  %t290 = load %"compiler/ast:Func", ptr %l109
  %t291 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t290, ptr %t291
  %t293 = insertvalue { i32, ptr } zeroinitializer, ptr %t291, 1
  store { i32, ptr } %t293, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l13 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Sig", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 1
  br i1 %t23, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Sig", ptr %t25, i32 0, i32 3
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp sgt i64 %t30, 1
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l13, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Sig", ptr %t36, i32 0, i32 2
  %t39 = load i1, ptr %t38, !tbaa !21
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t46 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 57)
  store i1 %t46, ptr %l25
  br label %bb14
bb13:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb15
bb14:
  %t47 = load i1, ptr %l25, !tbaa !21
  store i1 %t47, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t48 = load i1, ptr %l22, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 8
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/scan:Tokens", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l9, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 6
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t23, i64 %t27)
  store i64 %t30, ptr %l13
  br label %bb4
bb4:
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i64 %t31
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  store i32 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eidenStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/token:Token"
  %l10 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l25 = alloca %"compiler/token:Token"
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l37 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l50 = alloca %"compiler/ast:VarDecl"
  %l57 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l73 = alloca %"compiler/token:Token"
  %l74 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca ptr
  %l83 = alloca i32
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t86 = alloca i64
  %t110 = alloca i64
  %t137 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t5, i64 1)
  store i32 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load i32, ptr %l12
  store i32 %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 12
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i32, ptr %l2
  %t16 = trunc i64 8 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t19 = load i32, ptr %l2
  %t21 = trunc i64 93 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb9:
  %t25 = load i32, ptr %l2
  %t27 = trunc i64 0 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l21, !tbaa !21
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t32)
  store %"compiler/token:Token" %t34, ptr %l25
  br label %bb14
bb13:
  br label %bb36
bb14:
  %t35 = load %"compiler/token:Token", ptr %l25
  store %"compiler/token:Token" %t35, ptr %l3
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t36)
  %t39 = extractvalue { i32, i32 } %t38, 1
  %t40 = extractvalue { i32, i32 } %t38, 0
  store i32 %t40, ptr %l29
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb16, label %ok.42
ok.42:
  store i32 %t39, ptr %l28
  br label %bb15
bb15:
  %t43 = load i32, ptr %l28, !tbaa !23
  store i32 %t43, ptr %l26, !tbaa !23
  br label %bb17
bb16:
  %t44 = load i32, ptr %l29, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t54 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t54, ptr %rv
  br label %ret
bb17:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l4, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t60 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t56, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l33
  br label %bb18
bb18:
  %t61 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t61, ptr %l5
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t62)
  store i32 %t64, ptr %l35
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb20, label %ok.66
ok.66:
  br label %bb19
bb19:
  br label %bb21
bb20:
  %t67 = load i32, ptr %l35, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, ptr } zeroinitializer, i32 %t75, 0
  store { i32, ptr } %t77, ptr %rv
  br label %ret
bb21:
  %t78 = load i32, ptr %l4, !tbaa !23
  store i32 %t78, ptr %l37, !tbaa !23
  %t79 = icmp sge i64 1, 0
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t81 = icmp sle i64 1, 2305843009213693951
  br i1 %t81, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb24:
  %t83 = mul i64 1, 4
  %t84 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t83)
  %t85 = load i32, ptr %l37, !tbaa !23
  store i64 0, ptr %t86
  br label %fill.87
fill.87:
  %t90 = load i64, ptr %t86
  %t91 = icmp slt i64 %t90, 1
  br i1 %t91, label %fillb.88, label %filld.89
fillb.88:
  %t92 = getelementptr i32, ptr %t84, i64 %t90
  store i32 %t85, ptr %t92
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %t86
  br label %fill.87
filld.89:
  %t94 = insertvalue { i64, ptr } undef, i64 1, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t84, 1
  store { i64, ptr } %t95, ptr %l40, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t99 = load i32, ptr %t98, !tbaa !23
  %t102 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t97, i32 %t99)
  store %"compiler/source:Span" %t102, ptr %l43
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb26:
  %t103 = icmp sge i64 1, 0
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = icmp sle i64 1, 1152921504606846975
  br i1 %t105, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb29:
  %t107 = mul i64 1, 8
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = load %"compiler/source:Span", ptr %l43
  store i64 0, ptr %t110
  br label %fill.111
fill.111:
  %t114 = load i64, ptr %t110
  %t115 = icmp slt i64 %t114, 1
  br i1 %t115, label %fillb.112, label %filld.113
fillb.112:
  %t116 = getelementptr %"compiler/source:Span", ptr %t108, i64 %t114
  store %"compiler/source:Span" %t109, ptr %t116
  %t117 = add i64 %t114, 1
  store i64 %t117, ptr %t110
  br label %fill.111
filld.113:
  %t118 = insertvalue { i64, ptr } undef, i64 1, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t108, 1
  store { i64, ptr } %t119, ptr %l46, !tbaa !27
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba)
  unreachable
bb31:
  %t122 = icmp sle i64 0, 1152921504606846975
  br i1 %t122, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b5d05676e64fefab_5744e152e232520f)
  unreachable
bb33:
  %t124 = mul i64 0, 8
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t128 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t131 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t128, { i64, ptr } %t129, ptr null, { i64, ptr } %t127, i1 false, i1 true)
  store %"compiler/ast:VarDecl" %t131, ptr %l50
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_b5d05676e64fefab_5744e152e232520f)
  unreachable
bb35:
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store ptr %t132, ptr %lp6
  %t133 = load %"compiler/ast:VarDecl", ptr %l50
  %t134 = load ptr, ptr %lp6
  store %"compiler/ast:VarDecl" %t133, ptr %t134
  %t135 = load %"compiler/source:Span", ptr %l5
  %t136 = load ptr, ptr %lp6
  store { i64, [5 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [5 x i64] }, ptr %t137, i32 0, i32 0
  store i64 1, ptr %t138
  %t140 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t135, 0
  %t142 = insertvalue { %"compiler/source:Span", ptr } %t140, ptr %t136, 1
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t137, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t142, ptr %t143
  %t144 = load { i64, [5 x i64] }, ptr %t137
  %t146 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t144, ptr %t146
  %t148 = insertvalue { i32, ptr } zeroinitializer, ptr %t146, 1
  store { i32, ptr } %t148, ptr %rv
  br label %ret
bb36:
  %t149 = load i32, ptr %l2
  %t151 = trunc i64 60 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb39
bb38:
  %t154 = load i32, ptr %l2
  %t156 = trunc i64 1 to i32
  %t157 = icmp eq i32 %t154, %t156
  store i1 %t157, ptr %l57, !tbaa !21
  br label %bb39
bb39:
  %t159 = load i1, ptr %l57, !tbaa !21
  br i1 %t159, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb42
bb41:
  %t160 = load i32, ptr %l2
  %t162 = trunc i64 39 to i32
  %t163 = icmp eq i32 %t160, %t162
  store i1 %t163, ptr %l60, !tbaa !21
  br label %bb42
bb42:
  %t165 = load i1, ptr %l60, !tbaa !21
  br i1 %t165, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb45
bb44:
  %t166 = load i32, ptr %l2
  %t168 = trunc i64 37 to i32
  %t169 = icmp eq i32 %t166, %t168
  store i1 %t169, ptr %l63, !tbaa !21
  br label %bb45
bb45:
  %t171 = load i1, ptr %l63, !tbaa !21
  br i1 %t171, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb48
bb47:
  %t172 = load i32, ptr %l2
  %t174 = trunc i64 35 to i32
  %t175 = icmp eq i32 %t172, %t174
  store i1 %t175, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t177 = load i1, ptr %l66, !tbaa !21
  br i1 %t177, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb51
bb50:
  %t178 = load i32, ptr %l2
  %t180 = trunc i64 34 to i32
  %t181 = icmp eq i32 %t178, %t180
  store i1 %t181, ptr %l69, !tbaa !21
  br label %bb51
bb51:
  %t183 = load i1, ptr %l69, !tbaa !21
  br i1 %t183, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s2
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t184)
  store %"compiler/token:Token" %t186, ptr %l73
  br label %bb54
bb53:
  br label %bb63
bb54:
  %t187 = load %"compiler/token:Token", ptr %l73
  store %"compiler/token:Token" %t187, ptr %l7
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t188)
  %t191 = extractvalue { i32, i32 } %t190, 1
  %t192 = extractvalue { i32, i32 } %t190, 0
  store i32 %t192, ptr %l77
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb56, label %ok.194
ok.194:
  store i32 %t191, ptr %l76
  br label %bb55
bb55:
  %t195 = load i32, ptr %l76, !tbaa !23
  store i32 %t195, ptr %l74, !tbaa !23
  br label %bb57
bb56:
  %t196 = load i32, ptr %l77, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  call void @__olang_scope_close(ptr %s2)
  %t206 = insertvalue { i32, ptr } zeroinitializer, i32 %t204, 0
  store { i32, ptr } %t206, ptr %rv
  br label %ret
bb57:
  %t207 = load i32, ptr %l74, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l80, !tbaa !29
  %t209 = load i32, ptr %l1, !tbaa !23
  store i32 %t209, ptr %l81, !tbaa !23
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l82, !tbaa !29
  store i32 %t207, ptr %l83, !tbaa !23
  %t212 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 2
  %t213 = load i32, ptr %t212, !tbaa !23
  %t214 = getelementptr %"compiler/token:Token", ptr %l7, i32 0, i32 3
  %t215 = load i32, ptr %t214, !tbaa !23
  %t218 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t213, i32 %t215)
  store %"compiler/source:Span" %t218, ptr %l86
  br label %bb58
bb58:
  %t219 = load ptr, ptr %l82, !tbaa !29
  %t220 = load i32, ptr %l83, !tbaa !23
  %t221 = load %"compiler/source:Span", ptr %l86
  %t222 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %t219, i32 %t220, %"compiler/source:Span" %t221)
  store ptr %t222, ptr %l87
  br label %bb59
bb59:
  %t223 = load ptr, ptr %l80, !tbaa !29
  %t224 = load i32, ptr %l81, !tbaa !23
  %t225 = load ptr, ptr %l87, !tbaa !29
  %t226 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v0, ptr %t223, i32 %t224, ptr %t225)
  %t227 = extractvalue { i32, ptr } %t226, 1
  %t228 = extractvalue { i32, ptr } %t226, 0
  store i32 %t228, ptr %l89
  %t229 = icmp ne i32 %t228, 0
  br i1 %t229, label %bb61, label %ok.230
ok.230:
  store ptr %t227, ptr %l88
  br label %bb60
bb60:
  %t231 = load ptr, ptr %l88, !tbaa !29
  store ptr %t231, ptr %l79, !tbaa !29
  br label %bb62
bb61:
  %t232 = load i32, ptr %l89, !tbaa !23
  %t233 = lshr i32 %t232, 16
  %t234 = and i32 %t232, 65535
  %t235 = icmp eq i32 %t233, 1
  %t236 = select i1 %t235, i32 1, i32 0
  %t237 = icmp eq i32 %t232, 0
  %t238 = shl i32 %t236, 16
  %t239 = or i32 %t238, %t234
  %t240 = select i1 %t237, i32 0, i32 %t239
  call void @__olang_scope_close(ptr %s2)
  %t242 = insertvalue { i32, ptr } zeroinitializer, i32 %t240, 0
  store { i32, ptr } %t242, ptr %rv
  br label %ret
bb62:
  call void @__olang_scope_close(ptr %s2)
  %t243 = load ptr, ptr %l79, !tbaa !29
  %t244 = insertvalue { i32, ptr } zeroinitializer, ptr %t243, 1
  store { i32, ptr } %t244, ptr %rv
  br label %ret
bb63:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %t245)
  %t248 = extractvalue { i32, ptr } %t247, 1
  %t249 = extractvalue { i32, ptr } %t247, 0
  store i32 %t249, ptr %l94
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb65, label %ok.251
ok.251:
  store ptr %t248, ptr %l93
  br label %bb64
bb64:
  %t252 = load ptr, ptr %l93, !tbaa !29
  store ptr %t252, ptr %l91, !tbaa !29
  br label %bb66
bb65:
  %t253 = load i32, ptr %l94, !tbaa !23
  %t254 = lshr i32 %t253, 16
  %t255 = and i32 %t253, 65535
  %t256 = icmp eq i32 %t254, 1
  %t257 = select i1 %t256, i32 1, i32 0
  %t258 = icmp eq i32 %t253, 0
  %t259 = shl i32 %t257, 16
  %t260 = or i32 %t259, %t255
  %t261 = select i1 %t258, i32 0, i32 %t260
  %t263 = insertvalue { i32, ptr } zeroinitializer, i32 %t261, 0
  store { i32, ptr } %t263, ptr %rv
  br label %ret
bb66:
  %t264 = load ptr, ptr %l91, !tbaa !29
  %t265 = insertvalue { i32, ptr } zeroinitializer, ptr %t264, 1
  store { i32, ptr } %t265, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca ptr
  %l76 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i32
  %l84 = alloca ptr
  %l91 = alloca ptr
  %l100 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i32
  %l110 = alloca ptr
  %l118 = alloca i32
  %l121 = alloca i32
  %l122 = alloca i32
  %l124 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l139 = alloca ptr
  %l148 = alloca i64
  %l150 = alloca ptr
  %l154 = alloca i1
  %l157 = alloca i1
  %l158 = alloca i32
  %l160 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l172 = alloca ptr
  %l173 = alloca i32
  %l175 = alloca ptr
  %l184 = alloca i1
  %l189 = alloca ptr
  %l191 = alloca { i64, ptr }
  %l193 = alloca i32
  %l195 = alloca ptr
  %l203 = alloca i32
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca ptr
  %l211 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l222 = alloca i32
  %l225 = alloca %"compiler/source:Span"
  %l226 = alloca ptr
  %l232 = alloca ptr
  %s1 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t341 = alloca { i64, [5 x i64] }, align 8
  %t551 = alloca { i64, [5 x i64] }, align 8
  %t601 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t7)
  store i32 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t10, i32 89)
  store i1 %t13, ptr %l16
  br label %bb3
bb3:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb7
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t15, i32 93)
  store i1 %t18, ptr %l20
  br label %bb6
bb6:
  %t19 = load i1, ptr %l20, !tbaa !21
  store i1 %t19, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l17, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  %t23 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 91)
  store { i64, ptr } %t23, ptr %l23
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t24 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t31, { i64, ptr } %t30)
  store i32 %t33, ptr %l25
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb12, label %ok.35
ok.35:
  br label %bb11
bb11:
  br label %bb13
bb12:
  %t36 = load i32, ptr %l25, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  call void @__olang_scope_close(ptr %s1)
  %t46 = insertvalue { i32, ptr } zeroinitializer, i32 %t44, 0
  store { i32, ptr } %t46, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 11
  %t50 = load i1, ptr %t49, !tbaa !21
  store i1 %t50, ptr %l3, !tbaa !21
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 18
  %t55 = load i1, ptr %t54, !tbaa !21
  store i1 %t55, ptr %l4, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 11
  store i1 false, ptr %t59, !tbaa !21
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 18
  store i1 true, ptr %t62, !tbaa !21
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t64, i32 0, i32 16
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = add i64 %t66, 1
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 16
  store i64 %t68, ptr %t71, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t72, i32 59)
  store i1 %t75, ptr %l38
  br label %bb15
bb15:
  %t76 = load i1, ptr %l38, !tbaa !21
  br i1 %t76, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb19
bb17:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t77, i32 91)
  store i1 %t80, ptr %l42
  br label %bb18
bb18:
  %t81 = load i1, ptr %l42, !tbaa !21
  %t82 = xor i1 %t81, true
  store i1 %t82, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l39, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  store ptr null, ptr %l5, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 59)
  store i1 %t88, ptr %l46
  br label %bb22
bb21:
  br label %bb84
bb22:
  %t89 = load i1, ptr %l46, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t92)
  %t95 = extractvalue { i32, ptr } %t94, 1
  %t96 = extractvalue { i32, ptr } %t94, 0
  store i32 %t96, ptr %l51
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb26, label %ok.98
ok.98:
  store ptr %t95, ptr %l50
  br label %bb25
bb24:
  br label %bb38
bb25:
  %t99 = load ptr, ptr %l50, !tbaa !29
  store ptr %t99, ptr %l48, !tbaa !29
  br label %bb27
bb26:
  %t100 = load i32, ptr %l51, !tbaa !23
  %t101 = lshr i32 %t100, 16
  %t102 = and i32 %t100, 65535
  %t103 = icmp eq i32 %t101, 1
  %t104 = select i1 %t103, i32 1, i32 0
  %t105 = icmp eq i32 %t100, 0
  %t106 = shl i32 %t104, 16
  %t107 = or i32 %t106, %t102
  %t108 = select i1 %t105, i32 0, i32 %t107
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l53, !tbaa !29
  %t110 = load ptr, ptr %l53, !tbaa !29
  %t111 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 16
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = sub i64 %t112, 1
  %t116 = load ptr, ptr %l53, !tbaa !29
  %t117 = getelementptr %"compiler/parse:Parser", ptr %t116, i32 0, i32 16
  store i64 %t114, ptr %t117, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i1, ptr %l3, !tbaa !21
  %t122 = getelementptr %"compiler/parse:Parser", ptr %t118, i32 0, i32 11
  store i1 %t119, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i1, ptr %l4, !tbaa !21
  %t127 = getelementptr %"compiler/parse:Parser", ptr %t123, i32 0, i32 18
  store i1 %t124, ptr %t127, !tbaa !21
  %t129 = insertvalue { i32, ptr } zeroinitializer, i32 %t108, 0
  store { i32, ptr } %t129, ptr %rv
  br label %ret
bb27:
  %t130 = load ptr, ptr %l48, !tbaa !29
  store ptr %t130, ptr %l5, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t132)
  store i1 %t134, ptr %l62
  br label %bb28
bb28:
  %t135 = load i1, ptr %l62, !tbaa !21
  br i1 %t135, label %bb29, label %bb30
bb29:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t140 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %t136, ptr %t137)
  %t141 = extractvalue { i32, ptr } %t140, 1
  %t142 = extractvalue { i32, ptr } %t140, 0
  store i32 %t142, ptr %l67
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb32, label %ok.144
ok.144:
  store ptr %t141, ptr %l66
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t145 = load ptr, ptr %l66, !tbaa !29
  store ptr %t145, ptr %l63, !tbaa !29
  br label %bb33
bb32:
  %t146 = load i32, ptr %l67, !tbaa !23
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t146, 0
  %t152 = shl i32 %t150, 16
  %t153 = or i32 %t152, %t148
  %t154 = select i1 %t151, i32 0, i32 %t153
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = getelementptr %"compiler/parse:Parser", ptr %t156, i32 0, i32 16
  %t158 = load i64, ptr %t157, !tbaa !24
  %t160 = sub i64 %t158, 1
  %t162 = load ptr, ptr %l69, !tbaa !29
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t162, i32 0, i32 16
  store i64 %t160, ptr %t163, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i1, ptr %l3, !tbaa !21
  %t168 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 11
  store i1 %t165, ptr %t168, !tbaa !21
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i1, ptr %l4, !tbaa !21
  %t173 = getelementptr %"compiler/parse:Parser", ptr %t169, i32 0, i32 18
  store i1 %t170, ptr %t173, !tbaa !21
  %t175 = insertvalue { i32, ptr } zeroinitializer, i32 %t154, 0
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb33:
  %t176 = load ptr, ptr %l63, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l2, !tbaa !23
  %t180 = load ptr, ptr %l5, !tbaa !29
  %t185 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %t177, i32 %t178, ptr %t176, ptr %t180)
  %t186 = extractvalue { i32, ptr } %t185, 1
  %t187 = extractvalue { i32, ptr } %t185, 0
  store i32 %t187, ptr %l82
  %t188 = icmp ne i32 %t187, 0
  br i1 %t188, label %bb35, label %ok.189
ok.189:
  store ptr %t186, ptr %l81
  br label %bb34
bb34:
  %t190 = load ptr, ptr %l81, !tbaa !29
  store ptr %t190, ptr %l76, !tbaa !29
  br label %bb36
bb35:
  %t191 = load i32, ptr %l82, !tbaa !23
  %t192 = lshr i32 %t191, 16
  %t193 = and i32 %t191, 65535
  %t194 = icmp eq i32 %t192, 1
  %t195 = select i1 %t194, i32 1, i32 0
  %t196 = icmp eq i32 %t191, 0
  %t197 = shl i32 %t195, 16
  %t198 = or i32 %t197, %t193
  %t199 = select i1 %t196, i32 0, i32 %t198
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l84, !tbaa !29
  %t201 = load ptr, ptr %l84, !tbaa !29
  %t202 = getelementptr %"compiler/parse:Parser", ptr %t201, i32 0, i32 16
  %t203 = load i64, ptr %t202, !tbaa !24
  %t205 = sub i64 %t203, 1
  %t207 = load ptr, ptr %l84, !tbaa !29
  %t208 = getelementptr %"compiler/parse:Parser", ptr %t207, i32 0, i32 16
  store i64 %t205, ptr %t208, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i1, ptr %l3, !tbaa !21
  %t213 = getelementptr %"compiler/parse:Parser", ptr %t209, i32 0, i32 11
  store i1 %t210, ptr %t213, !tbaa !21
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i1, ptr %l4, !tbaa !21
  %t218 = getelementptr %"compiler/parse:Parser", ptr %t214, i32 0, i32 18
  store i1 %t215, ptr %t218, !tbaa !21
  %t220 = insertvalue { i32, ptr } zeroinitializer, i32 %t199, 0
  store { i32, ptr } %t220, ptr %rv
  br label %ret
bb36:
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l91, !tbaa !29
  %t222 = load ptr, ptr %l91, !tbaa !29
  %t223 = getelementptr %"compiler/parse:Parser", ptr %t222, i32 0, i32 16
  %t224 = load i64, ptr %t223, !tbaa !24
  %t226 = sub i64 %t224, 1
  %t228 = load ptr, ptr %l91, !tbaa !29
  %t229 = getelementptr %"compiler/parse:Parser", ptr %t228, i32 0, i32 16
  store i64 %t226, ptr %t229, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i1, ptr %l3, !tbaa !21
  %t234 = getelementptr %"compiler/parse:Parser", ptr %t230, i32 0, i32 11
  store i1 %t231, ptr %t234, !tbaa !21
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i1, ptr %l4, !tbaa !21
  %t239 = getelementptr %"compiler/parse:Parser", ptr %t235, i32 0, i32 18
  store i1 %t236, ptr %t239, !tbaa !21
  %t240 = load ptr, ptr %l76, !tbaa !29
  %t241 = insertvalue { i32, ptr } zeroinitializer, ptr %t240, 1
  store { i32, ptr } %t241, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t245 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t242, i32 59)
  store i1 %t245, ptr %l100
  br label %bb39
bb39:
  %t246 = load i1, ptr %l100, !tbaa !21
  br i1 %t246, label %bb40, label %bb41
bb40:
  store ptr null, ptr %l7, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t250 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t247, i32 91)
  store i1 %t250, ptr %l103
  br label %bb42
bb41:
  br label %bb53
bb42:
  %t251 = load i1, ptr %l103, !tbaa !21
  %t252 = xor i1 %t251, true
  br i1 %t252, label %bb43, label %bb44
bb43:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t254)
  %t257 = extractvalue { i32, ptr } %t256, 1
  %t258 = extractvalue { i32, ptr } %t256, 0
  store i32 %t258, ptr %l108
  %t259 = icmp ne i32 %t258, 0
  br i1 %t259, label %bb46, label %ok.260
ok.260:
  store ptr %t257, ptr %l107
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t261 = load ptr, ptr %l107, !tbaa !29
  store ptr %t261, ptr %l105, !tbaa !29
  br label %bb47
bb46:
  %t262 = load i32, ptr %l108, !tbaa !23
  %t263 = lshr i32 %t262, 16
  %t264 = and i32 %t262, 65535
  %t265 = icmp eq i32 %t263, 1
  %t266 = select i1 %t265, i32 1, i32 0
  %t267 = icmp eq i32 %t262, 0
  %t268 = shl i32 %t266, 16
  %t269 = or i32 %t268, %t264
  %t270 = select i1 %t267, i32 0, i32 %t269
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l110, !tbaa !29
  %t272 = load ptr, ptr %l110, !tbaa !29
  %t273 = getelementptr %"compiler/parse:Parser", ptr %t272, i32 0, i32 16
  %t274 = load i64, ptr %t273, !tbaa !24
  %t276 = sub i64 %t274, 1
  %t278 = load ptr, ptr %l110, !tbaa !29
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t278, i32 0, i32 16
  store i64 %t276, ptr %t279, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i1, ptr %l3, !tbaa !21
  %t284 = getelementptr %"compiler/parse:Parser", ptr %t280, i32 0, i32 11
  store i1 %t281, ptr %t284, !tbaa !21
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i1, ptr %l4, !tbaa !21
  %t289 = getelementptr %"compiler/parse:Parser", ptr %t285, i32 0, i32 18
  store i1 %t286, ptr %t289, !tbaa !21
  %t291 = insertvalue { i32, ptr } zeroinitializer, i32 %t270, 0
  store { i32, ptr } %t291, ptr %rv
  br label %ret
bb47:
  %t292 = load ptr, ptr %l105, !tbaa !29
  store ptr %t292, ptr %l7, !tbaa !29
  br label %bb48
bb48:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t297 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t294, i32 91)
  %t298 = extractvalue { i32, i32 } %t297, 1
  %t299 = extractvalue { i32, i32 } %t297, 0
  store i32 %t299, ptr %l122
  %t300 = icmp ne i32 %t299, 0
  br i1 %t300, label %bb50, label %ok.301
ok.301:
  store i32 %t298, ptr %l121
  br label %bb49
bb49:
  %t302 = load i32, ptr %l121, !tbaa !23
  store i32 %t302, ptr %l118, !tbaa !23
  br label %bb51
bb50:
  %t303 = load i32, ptr %l122, !tbaa !23
  %t304 = lshr i32 %t303, 16
  %t305 = and i32 %t303, 65535
  %t306 = icmp eq i32 %t304, 1
  %t307 = select i1 %t306, i32 1, i32 0
  %t308 = icmp eq i32 %t303, 0
  %t309 = shl i32 %t307, 16
  %t310 = or i32 %t309, %t305
  %t311 = select i1 %t308, i32 0, i32 %t310
  %t312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t312, ptr %l124, !tbaa !29
  %t313 = load ptr, ptr %l124, !tbaa !29
  %t314 = getelementptr %"compiler/parse:Parser", ptr %t313, i32 0, i32 16
  %t315 = load i64, ptr %t314, !tbaa !24
  %t317 = sub i64 %t315, 1
  %t319 = load ptr, ptr %l124, !tbaa !29
  %t320 = getelementptr %"compiler/parse:Parser", ptr %t319, i32 0, i32 16
  store i64 %t317, ptr %t320, !tbaa !24
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i1, ptr %l3, !tbaa !21
  %t325 = getelementptr %"compiler/parse:Parser", ptr %t321, i32 0, i32 11
  store i1 %t322, ptr %t325, !tbaa !21
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i1, ptr %l4, !tbaa !21
  %t330 = getelementptr %"compiler/parse:Parser", ptr %t326, i32 0, i32 18
  store i1 %t327, ptr %t330, !tbaa !21
  %t332 = insertvalue { i32, ptr } zeroinitializer, i32 %t311, 0
  store { i32, ptr } %t332, ptr %rv
  br label %ret
bb51:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l2, !tbaa !23
  %t337 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t333, i32 %t334)
  store %"compiler/source:Span" %t337, ptr %l133
  br label %bb52
bb52:
  %t338 = load ptr, ptr %l1, !tbaa !29
  %t339 = load ptr, ptr %l5, !tbaa !29
  %t340 = load ptr, ptr %l7, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 0
  store i64 17, ptr %t342
  %t343 = load %"compiler/source:Span", ptr %l133
  %t344 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } undef, %"compiler/source:Span" %t343, 0
  %t346 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t344, ptr %t338, 1
  %t348 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t346, ptr %t339, 2
  %t350 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t348, ptr %t340, 3
  %t351 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, ptr } %t350, ptr %t351
  %t352 = load { i64, [5 x i64] }, ptr %t341
  %t354 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t352, ptr %t354
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l139, !tbaa !29
  %t356 = load ptr, ptr %l139, !tbaa !29
  %t357 = getelementptr %"compiler/parse:Parser", ptr %t356, i32 0, i32 16
  %t358 = load i64, ptr %t357, !tbaa !24
  %t360 = sub i64 %t358, 1
  %t362 = load ptr, ptr %l139, !tbaa !29
  %t363 = getelementptr %"compiler/parse:Parser", ptr %t362, i32 0, i32 16
  store i64 %t360, ptr %t363, !tbaa !24
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load i1, ptr %l3, !tbaa !21
  %t368 = getelementptr %"compiler/parse:Parser", ptr %t364, i32 0, i32 11
  store i1 %t365, ptr %t368, !tbaa !21
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i1, ptr %l4, !tbaa !21
  %t373 = getelementptr %"compiler/parse:Parser", ptr %t369, i32 0, i32 18
  store i1 %t370, ptr %t373, !tbaa !21
  %t375 = insertvalue { i32, ptr } zeroinitializer, ptr %t354, 1
  store { i32, ptr } %t375, ptr %rv
  br label %ret
bb53:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/parse:Parser", ptr %t376, i32 0, i32 28
  %t380 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t378)
  store i64 %t380, ptr %l148
  br label %bb54
bb54:
  %t381 = load i64, ptr %l148, !tbaa !24
  store i64 %t381, ptr %l8, !tbaa !24
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/parse:Parser", ptr %t382, i32 0, i32 28
  store ptr %t384, ptr %l150, !tbaa !29
  %t385 = load ptr, ptr %l5, !tbaa !29
  %t387 = icmp eq ptr %t385, null
  br i1 %t387, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f067807cf96ff280_872aeb81d2c2c23c)
  unreachable
bb56:
  br label %bb57
bb57:
  %t389 = load ptr, ptr %l5, !tbaa !29
  %t390 = load ptr, ptr %l150, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t390, ptr %t389)
  br label %bb58
bb58:
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s21
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t395 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t392, i32 91)
  %t396 = extractvalue { i32, i1 } %t395, 1
  %t397 = extractvalue { i32, i1 } %t395, 0
  store i32 %t397, ptr %l158
  %t398 = icmp ne i32 %t397, 0
  br i1 %t398, label %bb61, label %ok.399
ok.399:
  store i1 %t396, ptr %l157
  br label %bb60
bb60:
  %t400 = load i1, ptr %l157, !tbaa !21
  store i1 %t400, ptr %l154, !tbaa !21
  br label %bb62
bb61:
  %t401 = load i32, ptr %l158, !tbaa !23
  %t402 = lshr i32 %t401, 16
  %t403 = and i32 %t401, 65535
  %t404 = icmp eq i32 %t402, 1
  %t405 = select i1 %t404, i32 1, i32 0
  %t406 = icmp eq i32 %t401, 0
  %t407 = shl i32 %t405, 16
  %t408 = or i32 %t407, %t403
  %t409 = select i1 %t406, i32 0, i32 %t408
  call void @__olang_scope_close(ptr %s21)
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l160, !tbaa !29
  %t411 = load ptr, ptr %l160, !tbaa !29
  %t412 = getelementptr %"compiler/parse:Parser", ptr %t411, i32 0, i32 16
  %t413 = load i64, ptr %t412, !tbaa !24
  %t415 = sub i64 %t413, 1
  %t417 = load ptr, ptr %l160, !tbaa !29
  %t418 = getelementptr %"compiler/parse:Parser", ptr %t417, i32 0, i32 16
  store i64 %t415, ptr %t418, !tbaa !24
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load i1, ptr %l3, !tbaa !21
  %t423 = getelementptr %"compiler/parse:Parser", ptr %t419, i32 0, i32 11
  store i1 %t420, ptr %t423, !tbaa !21
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load i1, ptr %l4, !tbaa !21
  %t428 = getelementptr %"compiler/parse:Parser", ptr %t424, i32 0, i32 18
  store i1 %t425, ptr %t428, !tbaa !21
  %t430 = insertvalue { i32, ptr } zeroinitializer, i32 %t409, 0
  store { i32, ptr } %t430, ptr %rv
  br label %ret
bb62:
  %t431 = load i1, ptr %l154, !tbaa !21
  %t432 = xor i1 %t431, true
  br i1 %t432, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s21)
  br label %bb71
bb64:
  br label %bb65
bb65:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/parse:Parser", ptr %t434, i32 0, i32 28
  store ptr %t436, ptr %l169, !tbaa !29
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t437)
  %t440 = extractvalue { i32, ptr } %t439, 1
  %t441 = extractvalue { i32, ptr } %t439, 0
  store i32 %t441, ptr %l173
  %t442 = icmp ne i32 %t441, 0
  br i1 %t442, label %bb67, label %ok.443
ok.443:
  store ptr %t440, ptr %l172
  br label %bb66
bb66:
  %t444 = load ptr, ptr %l172, !tbaa !29
  store ptr %t444, ptr %l170, !tbaa !29
  br label %bb68
bb67:
  %t445 = load i32, ptr %l173, !tbaa !23
  %t446 = lshr i32 %t445, 16
  %t447 = and i32 %t445, 65535
  %t448 = icmp eq i32 %t446, 1
  %t449 = select i1 %t448, i32 1, i32 0
  %t450 = icmp eq i32 %t445, 0
  %t451 = shl i32 %t449, 16
  %t452 = or i32 %t451, %t447
  %t453 = select i1 %t450, i32 0, i32 %t452
  call void @__olang_scope_close(ptr %s21)
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l175, !tbaa !29
  %t455 = load ptr, ptr %l175, !tbaa !29
  %t456 = getelementptr %"compiler/parse:Parser", ptr %t455, i32 0, i32 16
  %t457 = load i64, ptr %t456, !tbaa !24
  %t459 = sub i64 %t457, 1
  %t461 = load ptr, ptr %l175, !tbaa !29
  %t462 = getelementptr %"compiler/parse:Parser", ptr %t461, i32 0, i32 16
  store i64 %t459, ptr %t462, !tbaa !24
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load i1, ptr %l3, !tbaa !21
  %t467 = getelementptr %"compiler/parse:Parser", ptr %t463, i32 0, i32 11
  store i1 %t464, ptr %t467, !tbaa !21
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load i1, ptr %l4, !tbaa !21
  %t472 = getelementptr %"compiler/parse:Parser", ptr %t468, i32 0, i32 18
  store i1 %t469, ptr %t472, !tbaa !21
  %t474 = insertvalue { i32, ptr } zeroinitializer, i32 %t453, 0
  store { i32, ptr } %t474, ptr %rv
  br label %ret
bb68:
  %t475 = load ptr, ptr %l169, !tbaa !29
  %t476 = load ptr, ptr %l170, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t475, ptr %t476)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s21)
  br label %bb70
bb70:
  br label %bb59
bb71:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t480 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t477, i32 91)
  store i1 %t480, ptr %l184
  br label %bb72
bb72:
  %t481 = load i1, ptr %l184, !tbaa !21
  %t482 = xor i1 %t481, true
  br i1 %t482, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s26
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = getelementptr %"compiler/parse:Parser", ptr %t484, i32 0, i32 28
  %t487 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t486, i64 %t487)
  br label %bb75
bb74:
  br label %bb80
bb75:
  %t490 = load ptr, ptr %l0, !tbaa !29
  store ptr %t490, ptr %l189, !tbaa !29
  %t492 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s26, i32 91)
  store { i64, ptr } %t492, ptr %l191
  br label %bb76
bb76:
  %t493 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t493, 0
  %t495 = extractvalue { i64, ptr } %t493, 1
  %t496 = mul i64 %t494, 1
  %t497 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t496)
  call void @llvm.memcpy.p0.p0.i64(ptr %t497, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t497, 1
  %t500 = load ptr, ptr %l189, !tbaa !29
  %t502 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s26, ptr %t500, { i64, ptr } %t499)
  store i32 %t502, ptr %l193
  %t503 = icmp ne i32 %t502, 0
  br i1 %t503, label %bb78, label %ok.504
ok.504:
  br label %bb77
bb77:
  br label %bb79
bb78:
  %t505 = load i32, ptr %l193, !tbaa !23
  %t506 = lshr i32 %t505, 16
  %t507 = and i32 %t505, 65535
  %t508 = icmp eq i32 %t506, 1
  %t509 = select i1 %t508, i32 1, i32 0
  %t510 = icmp eq i32 %t505, 0
  %t511 = shl i32 %t509, 16
  %t512 = or i32 %t511, %t507
  %t513 = select i1 %t510, i32 0, i32 %t512
  call void @__olang_scope_close(ptr %s26)
  %t514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t514, ptr %l195, !tbaa !29
  %t515 = load ptr, ptr %l195, !tbaa !29
  %t516 = getelementptr %"compiler/parse:Parser", ptr %t515, i32 0, i32 16
  %t517 = load i64, ptr %t516, !tbaa !24
  %t519 = sub i64 %t517, 1
  %t521 = load ptr, ptr %l195, !tbaa !29
  %t522 = getelementptr %"compiler/parse:Parser", ptr %t521, i32 0, i32 16
  store i64 %t519, ptr %t522, !tbaa !24
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load i1, ptr %l3, !tbaa !21
  %t527 = getelementptr %"compiler/parse:Parser", ptr %t523, i32 0, i32 11
  store i1 %t524, ptr %t527, !tbaa !21
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load i1, ptr %l4, !tbaa !21
  %t532 = getelementptr %"compiler/parse:Parser", ptr %t528, i32 0, i32 18
  store i1 %t529, ptr %t532, !tbaa !21
  %t534 = insertvalue { i32, ptr } zeroinitializer, i32 %t513, 0
  store { i32, ptr } %t534, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s26)
  br label %bb80
bb80:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t535)
  store i32 %t537, ptr %l203
  br label %bb81
bb81:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i32, ptr %l2, !tbaa !23
  %t542 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t538, i32 %t539)
  store %"compiler/source:Span" %t542, ptr %l206
  br label %bb82
bb82:
  %t543 = load ptr, ptr %l1, !tbaa !29
  store ptr %t543, ptr %l207, !tbaa !29
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t546 = getelementptr %"compiler/parse:Parser", ptr %t544, i32 0, i32 28
  %t547 = load i64, ptr %l8, !tbaa !24
  %t550 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t546, i64 %t547)
  store { i64, ptr } %t550, ptr %l211
  br label %bb83
bb83:
  store { i64, [5 x i64] } zeroinitializer, ptr %t551
  %t552 = getelementptr { i64, [5 x i64] }, ptr %t551, i32 0, i32 0
  store i64 16, ptr %t552
  %t553 = load %"compiler/source:Span", ptr %l206
  %t554 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t553, 0
  %t555 = load ptr, ptr %l207, !tbaa !29
  %t556 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t554, ptr %t555, 1
  %t557 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t558 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t556, { i64, ptr } %t557, 2
  %t559 = getelementptr { i64, [5 x i64] }, ptr %t551, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t558, ptr %t559
  %t560 = load { i64, [5 x i64] }, ptr %t551
  %t562 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t560, ptr %t562
  %t563 = load ptr, ptr %l0, !tbaa !29
  store ptr %t563, ptr %l214, !tbaa !29
  %t564 = load ptr, ptr %l214, !tbaa !29
  %t565 = getelementptr %"compiler/parse:Parser", ptr %t564, i32 0, i32 16
  %t566 = load i64, ptr %t565, !tbaa !24
  %t568 = sub i64 %t566, 1
  %t570 = load ptr, ptr %l214, !tbaa !29
  %t571 = getelementptr %"compiler/parse:Parser", ptr %t570, i32 0, i32 16
  store i64 %t568, ptr %t571, !tbaa !24
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load i1, ptr %l3, !tbaa !21
  %t576 = getelementptr %"compiler/parse:Parser", ptr %t572, i32 0, i32 11
  store i1 %t573, ptr %t576, !tbaa !21
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load i1, ptr %l4, !tbaa !21
  %t581 = getelementptr %"compiler/parse:Parser", ptr %t577, i32 0, i32 18
  store i1 %t578, ptr %t581, !tbaa !21
  %t583 = insertvalue { i32, ptr } zeroinitializer, ptr %t562, 1
  store { i32, ptr } %t583, ptr %rv
  br label %ret
bb84:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t586 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t584)
  store i32 %t586, ptr %l222
  br label %bb85
bb85:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load i32, ptr %l2, !tbaa !23
  %t591 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t587, i32 %t588)
  store %"compiler/source:Span" %t591, ptr %l225
  br label %bb86
bb86:
  %t592 = load ptr, ptr %l1, !tbaa !29
  store ptr %t592, ptr %l226, !tbaa !29
  %t593 = icmp sge i64 0, 0
  br i1 %t593, label %bb87, label %bb88
bb87:
  %t595 = icmp sle i64 0, 1152921504606846975
  br i1 %t595, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_882dfc00c36114e5_890842da0dcd92c9)
  unreachable
bb89:
  %t597 = mul i64 0, 8
  %t598 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t597)
  %t599 = insertvalue { i64, ptr } undef, i64 0, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t598, 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t601
  %t602 = getelementptr { i64, [5 x i64] }, ptr %t601, i32 0, i32 0
  store i64 16, ptr %t602
  %t603 = load %"compiler/source:Span", ptr %l225
  %t604 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t603, 0
  %t605 = load ptr, ptr %l226, !tbaa !29
  %t606 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t604, ptr %t605, 1
  %t608 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t606, { i64, ptr } %t600, 2
  %t609 = getelementptr { i64, [5 x i64] }, ptr %t601, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t608, ptr %t609
  %t610 = load { i64, [5 x i64] }, ptr %t601
  %t612 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t610, ptr %t612
  %t613 = load ptr, ptr %l0, !tbaa !29
  store ptr %t613, ptr %l232, !tbaa !29
  %t614 = load ptr, ptr %l232, !tbaa !29
  %t615 = getelementptr %"compiler/parse:Parser", ptr %t614, i32 0, i32 16
  %t616 = load i64, ptr %t615, !tbaa !24
  %t618 = sub i64 %t616, 1
  %t620 = load ptr, ptr %l232, !tbaa !29
  %t621 = getelementptr %"compiler/parse:Parser", ptr %t620, i32 0, i32 16
  store i64 %t618, ptr %t621, !tbaa !24
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load i1, ptr %l3, !tbaa !21
  %t626 = getelementptr %"compiler/parse:Parser", ptr %t622, i32 0, i32 11
  store i1 %t623, ptr %t626, !tbaa !21
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load i1, ptr %l4, !tbaa !21
  %t631 = getelementptr %"compiler/parse:Parser", ptr %t627, i32 0, i32 18
  store i1 %t628, ptr %t631, !tbaa !21
  %t633 = insertvalue { i32, ptr } zeroinitializer, ptr %t612, 1
  store { i32, ptr } %t633, ptr %rv
  br label %ret
bb90:
  call void @__olang_check_failed(ptr @olang_loc_882dfc00c36114e5_890842da0dcd92c9)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/token:Token"
  %l6 = alloca i32
  %l9 = alloca i1
  %l12 = alloca i1
  %l18 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 1 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  %t12 = load i32, ptr %l2
  %t14 = trunc i64 0 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i32, ptr %l2
  %t20 = trunc i64 8 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/scan:Tokens", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i64 %t32
  %t37 = load %"compiler/token:Token", ptr %t36
  store %"compiler/token:Token" %t37, ptr %l3
  %t39 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = icmp sgt i32 %t40, %t42
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/source:Source", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l27, !tbaa !27
  %t54 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t58 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t57
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t61)
  store i1 %t63, ptr %l30
  br label %bb13
bb12:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb14
bb13:
  %t64 = load i1, ptr %l30, !tbaa !21
  store i1 %t64, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t65 = load i1, ptr %l24, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t7 = call i1 @compiler_2fparse_2eisOperandEndTok(i32 %t6)
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb10
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l9
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t15, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb8
bb7:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t22 = load i32, ptr %l14
  %t24 = trunc i64 56 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l10, !tbaa !21
  store i1 %t27, ptr %l6, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l6, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fparse_2eisPath(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 3
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Oracle", ptr %t11, i32 0, i32 1
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/parse:Parser", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l10, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t18)
  store %"compiler/source:Span" %t20, ptr %l12
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l10, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l12
  %t23 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %t21, %"compiler/source:Span" %t22)
  store { i64, ptr } %t23, ptr %l13
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l8, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t26 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  store i1 %t26, ptr %l14
  br label %bb7
bb7:
  %t27 = load i1, ptr %l14, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l22 = alloca i1
  %l24 = alloca i32
  %l28 = alloca %"compiler/ast:JoinS"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 15)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l8
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t21)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l13
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27
ok.27:
  store { i64, ptr } %t24, ptr %l12
  br label %bb4
bb4:
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l10, !tbaa !27
  br label %bb6
bb5:
  %t29 = load i32, ptr %l13, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 %t37, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t40, ptr %l2, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t41, i1 false)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l18
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47
ok.47:
  store { i64, ptr } %t44, ptr %l17
  br label %bb7
bb7:
  %t48 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t48, ptr %l15, !tbaa !27
  br label %bb9
bb8:
  %t49 = load i32, ptr %l18, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb9:
  %t60 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t60, ptr %l3, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t61, i32 8)
  store i1 %t64, ptr %l22
  br label %bb10
bb10:
  %t65 = load i1, ptr %l22, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t66)
  store i32 %t68, ptr %l24
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = call %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v0, ptr %v0, ptr %v0, i1 %a1, { i64, ptr } %t70, { i64, ptr } %t71)
  store %"compiler/ast:JoinS" %t75, ptr %l28
  br label %bb15
bb15:
  %t76 = load %"compiler/ast:JoinS", ptr %l28
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:JoinS" %t76, ptr %t77
  %t79 = insertvalue { i32, ptr } zeroinitializer, ptr %t77, 1
  store { i32, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l11 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l19 = alloca %"compiler/ast:VarDecl"
  %rv = alloca ptr
  %t9 = alloca i64
  %t27 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l4, !tbaa !23
  %t2 = icmp sge i64 1, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 1, 2305843009213693951
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb3:
  %t6 = mul i64 1, 4
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  %t8 = load i32, ptr %l4, !tbaa !23
  store i64 0, ptr %t9
  br label %fill.10
fill.10:
  %t13 = load i64, ptr %t9
  %t14 = icmp slt i64 %t13, 1
  br i1 %t14, label %fillb.11, label %filld.12
fillb.11:
  %t15 = getelementptr i32, ptr %t7, i64 %t13
  store i32 %t8, ptr %t15
  %t16 = add i64 %t13, 1
  store i64 %t16, ptr %t9
  br label %fill.10
filld.12:
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t7, 1
  store { i64, ptr } %t18, ptr %l7, !tbaa !27
  store %"compiler/source:Span" %a3, ptr %l8
  %t20 = icmp sge i64 1, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb5:
  %t22 = icmp sle i64 1, 1152921504606846975
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb7:
  %t24 = mul i64 1, 8
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  %t26 = load %"compiler/source:Span", ptr %l8
  store i64 0, ptr %t27
  br label %fill.28
fill.28:
  %t31 = load i64, ptr %t27
  %t32 = icmp slt i64 %t31, 1
  br i1 %t32, label %fillb.29, label %filld.30
fillb.29:
  %t33 = getelementptr %"compiler/source:Span", ptr %t25, i64 %t31
  store %"compiler/source:Span" %t26, ptr %t33
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %t27
  br label %fill.28
filld.30:
  %t35 = insertvalue { i64, ptr } undef, i64 1, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t25, 1
  store { i64, ptr } %t36, ptr %l11, !tbaa !27
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/ast:VarDecl", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l13, !tbaa !29
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb9:
  %t43 = icmp sle i64 0, 1152921504606846975
  br i1 %t43, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb11:
  %t45 = mul i64 0, 8
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 0, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/ast:VarDecl", ptr %t49, i32 0, i32 4
  %t52 = load i1, ptr %t51, !tbaa !21
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t55 = load ptr, ptr %l13, !tbaa !29
  %t58 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t53, { i64, ptr } %t54, ptr %t55, { i64, ptr } %t48, i1 %t52, i1 true)
  store %"compiler/ast:VarDecl" %t58, ptr %l19
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3f19ed1436e26d3c_ab56bc721c08c978)
  unreachable
bb13:
  %t59 = load %"compiler/ast:VarDecl", ptr %l19
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t59, ptr %t60
  store ptr %t60, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca %"compiler/token:Token"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/token:Token"
  %l12 = alloca i32
  %l14 = alloca %"compiler/token:Token"
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i32
  %l30 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l47 = alloca %"compiler/msgs:Msg"
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l79 = alloca %"compiler/msgs:Msg"
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i32
  %l94 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t1)
  store %"compiler/token:Token" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l10
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t8)
  store %"compiler/token:Token" %t10, ptr %l14
  br label %bb3
bb3:
  %t11 = load %"compiler/token:Token", ptr %l14
  store %"compiler/token:Token" %t11, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t12, i32 8)
  store i1 %t15, ptr %l17
  br label %bb4
bb4:
  %t16 = load i1, ptr %l17, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t17, i32 0)
  store i1 %t20, ptr %l21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l21, !tbaa !21
  store i1 %t21, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l18, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb13
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t26, i32 %t28)
  store i32 %t31, ptr %l26
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t35, i32 %t37)
  store i32 %t40, ptr %l30
  br label %bb12
bb12:
  %t41 = load i32, ptr %l26, !tbaa !23
  %t42 = load i32, ptr %l30, !tbaa !23
  %t43 = icmp ne i32 %t41, %t42
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s1
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  %t47 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t48 = load i32, ptr %t47, !tbaa !23
  store i32 %t48, ptr %l33, !tbaa !23
  %t49 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t50 = load i32, ptr %t49, !tbaa !23
  store i32 %t50, ptr %l34, !tbaa !23
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %s1)
  store %"compiler/msgs:Msg" %t51, ptr %l35
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l32, !tbaa !29
  %t53 = load i32, ptr %l33, !tbaa !23
  %t54 = load i32, ptr %l34, !tbaa !23
  %t55 = load %"compiler/msgs:Msg", ptr %l35
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s1, ptr %t52, i32 %t53, i32 %t54, %"compiler/msgs:Msg" %t55)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb18:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l38
  br label %bb19
bb19:
  %t61 = load i32, ptr %l38
  %t62 = call { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %s0, i32 %t61)
  store { i64, ptr } %t62, ptr %l39
  br label %bb20
bb20:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t63, ptr %l3, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t64, { i64, ptr } { i64 0, ptr @.d20 })
  store i1 %t66, ptr %l41
  br label %bb21
bb21:
  %t67 = load i1, ptr %l41, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s2
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l43, !tbaa !29
  %t71 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  store i32 %t72, ptr %l44, !tbaa !23
  %t73 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t74 = load i32, ptr %t73, !tbaa !23
  store i32 %t74, ptr %l45, !tbaa !23
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t77 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s0, ptr %s2, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t77, ptr %l47
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = load i32, ptr %l44, !tbaa !23
  %t80 = load i32, ptr %l45, !tbaa !23
  %t81 = load %"compiler/msgs:Msg", ptr %l47
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s2, ptr %t78, i32 %t79, i32 %t80, %"compiler/msgs:Msg" %t81)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t83, ptr %rv
  br label %ret
bb26:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 13
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l4, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t89, i32 0, i32 13
  store i1 true, ptr %t91, !tbaa !21
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 12
  %t95 = load i1, ptr %t94, !tbaa !21
  store i1 %t95, ptr %l5, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Parser", ptr %t97, i32 0, i32 12
  store i1 false, ptr %t99, !tbaa !21
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %t100)
  %t103 = extractvalue { i32, ptr } %t102, 1
  %t104 = extractvalue { i32, ptr } %t102, 0
  store i32 %t104, ptr %l58
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb28, label %ok.106
ok.106:
  store ptr %t103, ptr %l57
  br label %bb27
bb27:
  %t107 = load ptr, ptr %l57, !tbaa !29
  store ptr %t107, ptr %l55, !tbaa !29
  br label %bb29
bb28:
  %t108 = load i32, ptr %l58, !tbaa !23
  %t109 = lshr i32 %t108, 16
  %t110 = and i32 %t108, 65535
  %t111 = icmp eq i32 %t109, 1
  %t112 = select i1 %t111, i32 1, i32 0
  %t113 = icmp eq i32 %t108, 0
  %t114 = shl i32 %t112, 16
  %t115 = or i32 %t114, %t110
  %t116 = select i1 %t113, i32 0, i32 %t115
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i1, ptr %l5, !tbaa !21
  %t121 = getelementptr %"compiler/parse:Parser", ptr %t117, i32 0, i32 12
  store i1 %t118, ptr %t121, !tbaa !21
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i1, ptr %l4, !tbaa !21
  %t126 = getelementptr %"compiler/parse:Parser", ptr %t122, i32 0, i32 13
  store i1 %t123, ptr %t126, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t128 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t116, 0
  store { i32, { i64, ptr } } %t128, ptr %rv
  br label %ret
bb29:
  %t129 = load ptr, ptr %l55, !tbaa !29
  store ptr %t129, ptr %l6, !tbaa !29
  %t130 = load ptr, ptr %l6, !tbaa !29
  store ptr %t130, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t131 = load ptr, ptr %l64, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb30, label %bb31
bb30:
  %t134 = load ptr, ptr %l64, !tbaa !29
  %t135 = load i64, ptr %t134
  %t137 = icmp eq i64 %t135, 1
  store i1 %t137, ptr %l65, !tbaa !21
  br label %bb31
bb31:
  %t138 = load i1, ptr %l65, !tbaa !21
  br i1 %t138, label %bb32, label %bb33
bb32:
  %t139 = load ptr, ptr %l6, !tbaa !29
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr }, ptr %t141, i32 0, i32 0
  %t143 = load %"compiler/source:Span", ptr %t142
  store %"compiler/source:Span" %t143, ptr %l7
  br label %bb38
bb33:
  %t145 = load ptr, ptr %l6, !tbaa !29
  store ptr %t145, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t146 = load ptr, ptr %l70, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb34, label %bb35
bb34:
  %t149 = load ptr, ptr %l70, !tbaa !29
  %t150 = load i64, ptr %t149
  %t152 = icmp eq i64 %t150, 2
  store i1 %t152, ptr %l71, !tbaa !21
  br label %bb35
bb35:
  %t153 = load i1, ptr %l71, !tbaa !21
  br i1 %t153, label %bb36, label %bb37
bb36:
  %t154 = load ptr, ptr %l6, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", ptr }, ptr %t156, i32 0, i32 0
  %t158 = load %"compiler/source:Span", ptr %t157
  store %"compiler/source:Span" %t158, ptr %l7
  br label %bb38
bb37:
  br label %bb41
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l76, !tbaa !29
  %t161 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t162 = load i32, ptr %t161, !tbaa !23
  store i32 %t162, ptr %l77, !tbaa !23
  %t163 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t164 = load i32, ptr %t163, !tbaa !23
  store i32 %t164, ptr %l78, !tbaa !23
  %t165 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s7, ptr %s7, { i64, ptr } { i64 13, ptr @.d21 })
  store %"compiler/msgs:Msg" %t165, ptr %l79
  br label %bb39
bb39:
  %t166 = load ptr, ptr %l76, !tbaa !29
  %t167 = load i32, ptr %l77, !tbaa !23
  %t168 = load i32, ptr %l78, !tbaa !23
  %t169 = load %"compiler/msgs:Msg", ptr %l79
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s7, ptr %t166, i32 %t167, i32 %t168, %"compiler/msgs:Msg" %t169)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i1, ptr %l5, !tbaa !21
  %t174 = getelementptr %"compiler/parse:Parser", ptr %t170, i32 0, i32 12
  store i1 %t171, ptr %t174, !tbaa !21
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i1, ptr %l4, !tbaa !21
  %t179 = getelementptr %"compiler/parse:Parser", ptr %t175, i32 0, i32 13
  store i1 %t176, ptr %t179, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t181 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t181, ptr %rv
  br label %ret
bb41:
  %t182 = load ptr, ptr %l6, !tbaa !29
  store ptr %t182, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t183 = load ptr, ptr %l85, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb42, label %bb43
bb42:
  %t186 = load ptr, ptr %l85, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 17
  store i1 %t189, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t190 = load i1, ptr %l86, !tbaa !21
  br i1 %t190, label %bb44, label %bb45
bb44:
  %t191 = load ptr, ptr %l6, !tbaa !29
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", ptr }, ptr %t193, i32 0, i32 0
  %t195 = load %"compiler/source:Span", ptr %t194
  store %"compiler/source:Span" %t195, ptr %l8
  br label %bb46
bb45:
  br label %bb49
bb46:
  store %olang.scope zeroinitializer, ptr %s12
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l91, !tbaa !29
  %t198 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  store i32 %t199, ptr %l92, !tbaa !23
  %t200 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t201 = load i32, ptr %t200, !tbaa !23
  store i32 %t201, ptr %l93, !tbaa !23
  %t202 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %s12, ptr %s12, { i64, ptr } { i64 6, ptr @.d22 })
  store %"compiler/msgs:Msg" %t202, ptr %l94
  br label %bb47
bb47:
  %t203 = load ptr, ptr %l91, !tbaa !29
  %t204 = load i32, ptr %l92, !tbaa !23
  %t205 = load i32, ptr %l93, !tbaa !23
  %t206 = load %"compiler/msgs:Msg", ptr %l94
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s12, ptr %t203, i32 %t204, i32 %t205, %"compiler/msgs:Msg" %t206)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s12)
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i1, ptr %l5, !tbaa !21
  %t211 = getelementptr %"compiler/parse:Parser", ptr %t207, i32 0, i32 12
  store i1 %t208, ptr %t211, !tbaa !21
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i1, ptr %l4, !tbaa !21
  %t216 = getelementptr %"compiler/parse:Parser", ptr %t212, i32 0, i32 13
  store i1 %t213, ptr %t216, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t218 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t218, ptr %rv
  br label %ret
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a66f16e9609fdd27_2fbef1e5bed159db)
  unreachable
bb54:
  %t219 = load ptr, ptr %l6, !tbaa !29
  %t221 = insertvalue [1 x ptr] undef, ptr %t219, 0
  %t223 = load ptr, ptr @__olang_prog_scope
  %t224 = call ptr @__olang_scope_alloc(ptr %t223, i64 8)
  store [1 x ptr] %t221, ptr %t224
  %t225 = insertvalue { i64, ptr } undef, i64 1, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 8
  %t231 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i1, ptr %l5, !tbaa !21
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t234, i32 0, i32 12
  store i1 %t235, ptr %t238, !tbaa !21
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i1, ptr %l4, !tbaa !21
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t239, i32 0, i32 13
  store i1 %t240, ptr %t243, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t245 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t233, 1
  store { i32, { i64, ptr } } %t245, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/parse:stackMarks"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/parse:stackMarks"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 28
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 29
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 30
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eLe_H079a49ca86fbf0542fec862c08432034(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 31
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l12
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 32
  %t25 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eLe_Hc3a9f67fd4028c52dcd01e744501edd7(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 33
  %t30 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 34
  %t35 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l21
  br label %bb7
bb7:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l9, !tbaa !24
  %t39 = load i64, ptr %l12, !tbaa !24
  %t40 = load i64, ptr %l15, !tbaa !24
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = call %"compiler/parse:stackMarks" @compiler_2fparse_3astackMarks_2ector(ptr %s0, i64 %t36, i64 %t37, i64 %t38, i64 %t39, i64 %t40, i64 %t41, i64 %t42)
  store %"compiler/parse:stackMarks" %t43, ptr %l22
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load %"compiler/parse:stackMarks", ptr %l22
  store %"compiler/parse:stackMarks" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:stackMarks", ptr %rv
  ret %"compiler/parse:stackMarks" %rr
}

define dso_local { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/token:Token"
  %l4 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i32
  %l16 = alloca %"compiler/token:Token"
  %l18 = alloca i32
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 1 to i32
  %t8 = icmp eq i32 %t5, %t7
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l1
  %t14 = call i1 @compiler_2fparse_2eisWordKeyword(i32 %t12)
  store i1 %t14, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } { i64 6, ptr @.d23 })
  store i32 %t21, ptr %l13
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb9, label %ok.23
ok.23:
  br label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb10
bb9:
  %t24 = load i32, ptr %l13, !tbaa !23
  %t25 = lshr i32 %t24, 16
  %t26 = and i32 %t24, 65535
  %t27 = icmp eq i32 %t25, 1
  %t28 = select i1 %t27, i32 1, i32 0
  %t29 = icmp eq i32 %t24, 0
  %t30 = shl i32 %t28, 16
  %t31 = or i32 %t30, %t26
  %t32 = select i1 %t29, i32 0, i32 %t31
  call void @__olang_scope_close(ptr %s1)
  %t34 = insertvalue { i32, i32 } zeroinitializer, i32 %t32, 0
  store { i32, i32 } %t34, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t35)
  store %"compiler/token:Token" %t37, ptr %l16
  br label %bb12
bb12:
  %t38 = load %"compiler/token:Token", ptr %l16
  store %"compiler/token:Token" %t38, ptr %l2
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l18
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/parse:Parser", ptr %t42, i32 0, i32 2
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load %"compiler/token:Token", ptr %l2
  %t50 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t46, %"compiler/token:Token" %t47)
  store { i64, ptr } %t50, ptr %l23
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l20, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t53 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t51, { i64, ptr } %t52)
  store i32 %t53, ptr %l24
  br label %bb15
bb15:
  %t54 = load i32, ptr %l24, !tbaa !23
  %t55 = insertvalue { i32, i32 } zeroinitializer, i32 %t54, 1
  store { i32, i32 } %t55, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamedResult(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l8 = alloca i32
  %l12 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l26 = alloca %"compiler/token:Token"
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 1)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t9, i64 1)
  store i32 %t11, ptr %l8
  br label %bb5
bb5:
  %t12 = load i32, ptr %l8
  store i32 %t12, ptr %l1
  %t13 = load i32, ptr %l1
  %t15 = trunc i64 1 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load i32, ptr %l1
  %t22 = trunc i64 39 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load i32, ptr %l1
  %t30 = trunc i64 37 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t36 = load i32, ptr %l1
  %t38 = trunc i64 88 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  store i1 %t41, ptr %l20, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t45, i64 1)
  store %"compiler/token:Token" %t47, ptr %l26
  br label %bb18
bb18:
  %t48 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t49 = load %"compiler/token:Token", ptr %l26
  %t51 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t49, i8 %t48)
  store i1 %t51, ptr %l28
  br label %bb19
bb19:
  %t52 = load i1, ptr %l28, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i32
  %l13 = alloca %"compiler/token:Token"
  %l14 = alloca i32
  %l16 = alloca %"compiler/token:Token"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 57)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t8, i64 1)
  store i32 %t10, ptr %l7
  br label %bb4
bb4:
  %t11 = load i32, ptr %l7
  %t13 = trunc i64 81 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  store i1 %t16, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l5, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t20, i64 0)
  store %"compiler/token:Token" %t22, ptr %l13
  br label %bb9
bb9:
  %t23 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 3
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l14, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t25, i64 1)
  store %"compiler/token:Token" %t27, ptr %l16
  br label %bb10
bb10:
  %t28 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t29 = load i32, ptr %t28, !tbaa !23
  %t30 = load i32, ptr %l14, !tbaa !23
  %t32 = icmp eq i32 %t30, %t29
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/parse:NameList"
  %rv = alloca ptr
  %t9 = alloca i64
  %t27 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l3, !tbaa !23
  %t2 = icmp sge i64 1, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 1, 2305843009213693951
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_56ae34a9066c1560_be19fd249755f1d4)
  unreachable
bb3:
  %t6 = mul i64 1, 4
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  %t8 = load i32, ptr %l3, !tbaa !23
  store i64 0, ptr %t9
  br label %fill.10
fill.10:
  %t13 = load i64, ptr %t9
  %t14 = icmp slt i64 %t13, 1
  br i1 %t14, label %fillb.11, label %filld.12
fillb.11:
  %t15 = getelementptr i32, ptr %t7, i64 %t13
  store i32 %t8, ptr %t15
  %t16 = add i64 %t13, 1
  store i64 %t16, ptr %t9
  br label %fill.10
filld.12:
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t7, 1
  store { i64, ptr } %t18, ptr %l6, !tbaa !27
  store %"compiler/source:Span" %a2, ptr %l7
  %t20 = icmp sge i64 1, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_56ae34a9066c1560_be19fd249755f1d4)
  unreachable
bb5:
  %t22 = icmp sle i64 1, 1152921504606846975
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_56ae34a9066c1560_be19fd249755f1d4)
  unreachable
bb7:
  %t24 = mul i64 1, 8
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  %t26 = load %"compiler/source:Span", ptr %l7
  store i64 0, ptr %t27
  br label %fill.28
fill.28:
  %t31 = load i64, ptr %t27
  %t32 = icmp slt i64 %t31, 1
  br i1 %t32, label %fillb.29, label %filld.30
fillb.29:
  %t33 = getelementptr %"compiler/source:Span", ptr %t25, i64 %t31
  store %"compiler/source:Span" %t26, ptr %t33
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %t27
  br label %fill.28
filld.30:
  %t35 = insertvalue { i64, ptr } undef, i64 1, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t25, 1
  %t37 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t39 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t37, { i64, ptr } %t36)
  store %"compiler/parse:NameList" %t39, ptr %l11
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_56ae34a9066c1560_be19fd249755f1d4)
  unreachable
bb9:
  %t40 = load %"compiler/parse:NameList", ptr %l11
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/parse:NameList" %t40, ptr %t41
  store ptr %t41, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenerOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i1
  %l29 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 89 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i32 88, ptr %l12
  br label %bb4
bb3:
  store i32 90, ptr %l12
  br label %bb4
bb4:
  %t14 = load i32, ptr %l12
  store i32 %t14, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb22
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t23, i64 %t24)
  store i32 %t27, ptr %l21
  br label %bb9
bb9:
  %t28 = load i32, ptr %l21
  store i32 %t28, ptr %l6
  %t29 = load i32, ptr %l6
  store i32 %t29, ptr %l22
  %t30 = load i32, ptr %l2
  store i32 %t30, ptr %l24
  %t33 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l22, ptr %l24)
  store i1 %t33, ptr %l26
  br label %bb10
bb10:
  %t34 = load i1, ptr %l26, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb20
bb12:
  %t39 = load i32, ptr %l6
  store i32 %t39, ptr %l29
  %t40 = load i32, ptr %l3
  store i32 %t40, ptr %l31
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l29, ptr %l31)
  store i1 %t43, ptr %l33
  br label %bb13
bb13:
  %t44 = load i1, ptr %l33, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb16, label %bb17
bb15:
  br label %bb19
bb16:
  %t53 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t53, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = sub i64 %t55, 1
  store i64 %t57, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  br label %bb5
bb22:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandEndAfter(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i1
  %l56 = alloca i32
  %l65 = alloca i32
  %l66 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i1
  %l73 = alloca i32
  %l75 = alloca i32
  %l77 = alloca i1
  %l92 = alloca i64
  %l95 = alloca i64
  %l100 = alloca i32
  %l103 = alloca i1
  %l107 = alloca i32
  %l110 = alloca i1
  %l114 = alloca i1
  %l119 = alloca i32
  %l122 = alloca i1
  %l125 = alloca i32
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/scan:Tokens", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 256, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb6
bb3:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l27, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb5
bb5:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l2, !tbaa !24
  %t63 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t59, i64 %t60)
  store i32 %t63, ptr %l47
  br label %bb11
bb11:
  %t64 = load i32, ptr %l47
  store i32 %t64, ptr %l10
  %t65 = load i32, ptr %l10
  %t67 = trunc i64 88 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb14
bb13:
  %t70 = load i32, ptr %l10
  %t72 = trunc i64 90 to i32
  %t73 = icmp eq i32 %t70, %t72
  store i1 %t73, ptr %l50, !tbaa !21
  br label %bb14
bb14:
  %t75 = load i1, ptr %l50, !tbaa !21
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t76 = load i32, ptr %l10
  store i32 %t76, ptr %l11
  %t78 = load i32, ptr %l10
  %t80 = trunc i64 88 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb17, label %bb18
bb16:
  br label %bb41
bb17:
  store i32 89, ptr %l56
  br label %bb19
bb18:
  store i32 91, ptr %l56
  br label %bb19
bb19:
  %t85 = load i32, ptr %l56
  store i32 %t85, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l3, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l2, !tbaa !24
  %t98 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t94, i64 %t95)
  store i32 %t98, ptr %l65
  br label %bb24
bb24:
  %t99 = load i32, ptr %l65
  store i32 %t99, ptr %l14
  %t100 = load i32, ptr %l14
  store i32 %t100, ptr %l66
  %t101 = load i32, ptr %l11
  store i32 %t101, ptr %l68
  %t104 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l66, ptr %l68)
  store i1 %t104, ptr %l70
  br label %bb25
bb25:
  %t105 = load i1, ptr %l70, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load i64, ptr %l13, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l13, !tbaa !24
  br label %bb35
bb27:
  %t110 = load i32, ptr %l14
  store i32 %t110, ptr %l73
  %t111 = load i32, ptr %l12
  store i32 %t111, ptr %l75
  %t114 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l73, ptr %l75)
  store i1 %t114, ptr %l77
  br label %bb28
bb28:
  %t115 = load i1, ptr %l77, !tbaa !21
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t118 = sub i64 %t116, 1
  store i64 %t118, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp eq i64 %t120, 0
  br i1 %t122, label %bb31, label %bb32
bb30:
  br label %bb34
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t124 = load i64, ptr %l2, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  br label %bb20
bb37:
  %t128 = load i64, ptr %l2, !tbaa !24
  %t129 = load i64, ptr %l3, !tbaa !24
  %t132 = icmp sge i64 %t128, %t129
  br i1 %t132, label %bb38, label %bb39
bb38:
  %t134 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t134, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t136 = load i64, ptr %l2, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l15, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l15, !tbaa !24
  %t144 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t140, i64 %t141)
  store i64 %t144, ptr %l92
  br label %bb42
bb42:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l2, !tbaa !24
  %t149 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t145, i64 %t146)
  store i64 %t149, ptr %l95
  br label %bb43
bb43:
  %t150 = load i64, ptr %l92, !tbaa !24
  %t151 = load i64, ptr %l95, !tbaa !24
  %t152 = icmp ne i64 %t150, %t151
  br i1 %t152, label %bb44, label %bb45
bb44:
  %t154 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t154, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l15, !tbaa !24
  %t160 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t156, i64 %t157)
  store i32 %t160, ptr %l100
  br label %bb47
bb47:
  %t161 = load i32, ptr %l100
  %t163 = trunc i64 56 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb48, label %bb49
bb48:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l15, !tbaa !24
  %t169 = add i64 %t167, 1
  %t172 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t166, i64 %t169)
  store i32 %t172, ptr %l107
  br label %bb50
bb49:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb55
bb50:
  %t173 = load i32, ptr %l107
  %t175 = trunc i64 1 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb54
bb52:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i64, ptr %l15, !tbaa !24
  %t181 = add i64 %t179, 1
  %t184 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t178, i64 %t181)
  store i1 %t184, ptr %l114
  br label %bb53
bb53:
  %t185 = load i1, ptr %l114, !tbaa !21
  store i1 %t185, ptr %l110, !tbaa !21
  br label %bb54
bb54:
  %t186 = load i1, ptr %l110, !tbaa !21
  store i1 %t186, ptr %l103, !tbaa !21
  br label %bb55
bb55:
  %t187 = load i1, ptr %l103, !tbaa !21
  br i1 %t187, label %bb56, label %bb57
bb56:
  %t188 = load i64, ptr %l15, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb57:
  br label %bb58
bb58:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i64, ptr %l15, !tbaa !24
  %t196 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t192, i64 %t193)
  store i32 %t196, ptr %l119
  br label %bb59
bb59:
  %t197 = load i32, ptr %l119
  %t199 = trunc i64 88 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb63
bb61:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l15, !tbaa !24
  %t206 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t202, i64 %t203)
  store i32 %t206, ptr %l125
  br label %bb62
bb62:
  %t207 = load i32, ptr %l125
  %t209 = trunc i64 90 to i32
  %t210 = icmp eq i32 %t207, %t209
  store i1 %t210, ptr %l122, !tbaa !21
  br label %bb63
bb63:
  %t212 = load i1, ptr %l122, !tbaa !21
  br i1 %t212, label %bb64, label %bb65
bb64:
  %t213 = load i64, ptr %l15, !tbaa !24
  store i64 %t213, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb65:
  br label %bb66
bb66:
  %t215 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t215, ptr %rv
  br label %ret
bb67:
  %t217 = load i64, ptr %l8, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l8, !tbaa !24
  br label %bb7
bb68:
  %t221 = load i64, ptr %l2, !tbaa !24
  store i64 %t221, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandStartBefore(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l38 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i1
  %l62 = alloca i32
  %l63 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i32
  %l74 = alloca i1
  %l78 = alloca i32
  %l79 = alloca i1
  %l86 = alloca i32
  %l89 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 256, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l18, !tbaa !24
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l15, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l2, !tbaa !24
  %t53 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t49, i64 %t50)
  store i32 %t53, ptr %l38
  br label %bb11
bb11:
  %t54 = load i32, ptr %l38
  store i32 %t54, ptr %l9
  %t55 = load i32, ptr %l9
  %t57 = trunc i64 89 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb14
bb13:
  %t60 = load i32, ptr %l9
  %t62 = trunc i64 91 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l41, !tbaa !21
  br label %bb14
bb14:
  %t65 = load i1, ptr %l41, !tbaa !21
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenerOf(ptr %v0, ptr %t66, i64 %t67)
  store i64 %t70, ptr %l46
  br label %bb17
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l67
  br label %bb31
bb17:
  %t76 = load i64, ptr %l46, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  %t77 = load i64, ptr %l2, !tbaa !24
  %t79 = icmp slt i64 %t77, 0
  br i1 %t79, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = sub i64 %t82, 1
  store i64 %t84, ptr %l10, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l10, !tbaa !24
  %t90 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t86, i64 %t87)
  store i64 %t90, ptr %l54
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l2, !tbaa !24
  %t95 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l57
  br label %bb22
bb22:
  %t96 = load i64, ptr %l54, !tbaa !24
  %t97 = load i64, ptr %l57, !tbaa !24
  %t98 = icmp eq i64 %t96, %t97
  br i1 %t98, label %bb23, label %bb24
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t100, i64 %t101)
  store i32 %t104, ptr %l62
  br label %bb25
bb24:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb27
bb25:
  %t105 = load i32, ptr %l62
  %t106 = call i1 @compiler_2fparse_2eisOperandTail(i32 %t105)
  store i1 %t106, ptr %l63
  br label %bb26
bb26:
  %t107 = load i1, ptr %l63, !tbaa !21
  store i1 %t107, ptr %l59, !tbaa !21
  br label %bb27
bb27:
  %t108 = load i1, ptr %l59, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t109 = load i64, ptr %l10, !tbaa !24
  store i64 %t109, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb29:
  br label %bb30
bb30:
  br label %bb44
bb31:
  %t111 = load i1, ptr %l67, !tbaa !21
  br i1 %t111, label %bb32, label %bb33
bb32:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l2, !tbaa !24
  %t115 = sub i64 %t113, 1
  %t118 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t112, i64 %t115)
  store i32 %t118, ptr %l71
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb34:
  %t120 = load i32, ptr %l71
  %t122 = trunc i64 56 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l2, !tbaa !24
  %t128 = sub i64 %t126, 2
  %t131 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t125, i64 %t128)
  store i32 %t131, ptr %l78
  br label %bb37
bb36:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb39
bb37:
  %t132 = load i32, ptr %l78
  %t133 = call i1 @compiler_2fparse_2eisOperandTail(i32 %t132)
  store i1 %t133, ptr %l79
  br label %bb38
bb38:
  %t134 = load i1, ptr %l79, !tbaa !21
  store i1 %t134, ptr %l74, !tbaa !21
  br label %bb39
bb39:
  %t135 = load i1, ptr %l74, !tbaa !21
  br i1 %t135, label %bb40, label %bb41
bb40:
  %t136 = load i64, ptr %l2, !tbaa !24
  %t138 = sub i64 %t136, 2
  store i64 %t138, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l2, !tbaa !24
  %t143 = sub i64 %t141, 1
  %t146 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t140, i64 %t143)
  store i32 %t146, ptr %l86
  br label %bb45
bb45:
  %t147 = load i32, ptr %l86
  %t149 = trunc i64 85 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb46, label %bb47
bb46:
  store i64 -1, ptr %l89, !tbaa !24
  br label %bb48
bb47:
  %t152 = load i64, ptr %l2, !tbaa !24
  store i64 %t152, ptr %l89, !tbaa !24
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s2)
  %t154 = load i64, ptr %l89, !tbaa !24
  store i64 %t154, ptr %rv
  br label %ret
bb49:
  %t155 = load i64, ptr %l7, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l7, !tbaa !24
  br label %bb7
bb50:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l57 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 16
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = add i64 %t10, 1
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t14, i32 0, i32 16
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 17
  %t19 = load i1, ptr %t18, !tbaa !21
  store i1 %t19, ptr %l3, !tbaa !21
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 18
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l4, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 17
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 18
  store i1 true, ptr %t31, !tbaa !21
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t32, i32 89)
  store i1 %t35, ptr %l19
  br label %bb3
bb3:
  %t36 = load i1, ptr %l19, !tbaa !21
  %t37 = xor i1 %t36, true
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 31
  store ptr %t43, ptr %l23, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t48 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %t44, i1 %a1)
  %t49 = extractvalue { i32, ptr } %t48, 1
  %t50 = extractvalue { i32, ptr } %t48, 0
  store i32 %t50, ptr %l28
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb8, label %ok.52
ok.52:
  store ptr %t49, ptr %l27
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l27, !tbaa !29
  store ptr %t53, ptr %l24, !tbaa !29
  br label %bb9
bb8:
  %t54 = load i32, ptr %l28, !tbaa !23
  %t55 = lshr i32 %t54, 16
  %t56 = and i32 %t54, 65535
  %t57 = icmp eq i32 %t55, 1
  %t58 = select i1 %t57, i32 1, i32 0
  %t59 = icmp eq i32 %t54, 0
  %t60 = shl i32 %t58, 16
  %t61 = or i32 %t60, %t56
  %t62 = select i1 %t59, i32 0, i32 %t61
  call void @__olang_scope_close(ptr %s1)
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i1, ptr %l4, !tbaa !21
  %t67 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 18
  store i1 %t64, ptr %t67, !tbaa !21
  %t69 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t62, 0
  store { i32, { i64, ptr } } %t69, ptr %rv
  br label %ret
bb9:
  %t70 = load ptr, ptr %l23, !tbaa !29
  %t71 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v0, ptr %t70, ptr %t71)
  br label %bb10
bb10:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t72, i32 89)
  %t76 = extractvalue { i32, i1 } %t75, 1
  %t77 = extractvalue { i32, i1 } %t75, 0
  store i32 %t77, ptr %l36
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb12, label %ok.79
ok.79:
  store i1 %t76, ptr %l35
  br label %bb11
bb11:
  %t80 = load i1, ptr %l35, !tbaa !21
  store i1 %t80, ptr %l32, !tbaa !21
  br label %bb13
bb12:
  %t81 = load i32, ptr %l36, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  call void @__olang_scope_close(ptr %s1)
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i1, ptr %l4, !tbaa !21
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t90, i32 0, i32 18
  store i1 %t91, ptr %t94, !tbaa !21
  %t96 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t89, 0
  store { i32, { i64, ptr } } %t96, ptr %rv
  br label %ret
bb13:
  %t97 = load i1, ptr %l32, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i1, ptr %l3, !tbaa !21
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t100, i32 0, i32 17
  store i1 %t101, ptr %t104, !tbaa !21
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l43, !tbaa !29
  %t106 = load ptr, ptr %l43, !tbaa !29
  %t107 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 16
  %t108 = load i64, ptr %t107, !tbaa !24
  %t110 = sub i64 %t108, 1
  %t112 = load ptr, ptr %l43, !tbaa !29
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t112, i32 0, i32 16
  store i64 %t110, ptr %t113, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t117 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t114, i32 89)
  %t118 = extractvalue { i32, i32 } %t117, 1
  %t119 = extractvalue { i32, i32 } %t117, 0
  store i32 %t119, ptr %l50
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb20, label %ok.121
ok.121:
  store i32 %t118, ptr %l49
  br label %bb19
bb19:
  %t122 = load i32, ptr %l49, !tbaa !23
  store i32 %t122, ptr %l46, !tbaa !23
  br label %bb21
bb20:
  %t123 = load i32, ptr %l50, !tbaa !23
  %t124 = lshr i32 %t123, 16
  %t125 = and i32 %t123, 65535
  %t126 = icmp eq i32 %t124, 1
  %t127 = select i1 %t126, i32 1, i32 0
  %t128 = icmp eq i32 %t123, 0
  %t129 = shl i32 %t127, 16
  %t130 = or i32 %t129, %t125
  %t131 = select i1 %t128, i32 0, i32 %t130
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i1, ptr %l4, !tbaa !21
  %t136 = getelementptr %"compiler/parse:Parser", ptr %t132, i32 0, i32 18
  store i1 %t133, ptr %t136, !tbaa !21
  %t138 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t131, 0
  store { i32, { i64, ptr } } %t138, ptr %rv
  br label %ret
bb21:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/parse:Parser", ptr %t139, i32 0, i32 31
  %t142 = load i64, ptr %l2, !tbaa !24
  %t145 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t141, i64 %t142)
  store { i64, ptr } %t145, ptr %l57
  br label %bb22
bb22:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i1, ptr %l4, !tbaa !21
  %t150 = getelementptr %"compiler/parse:Parser", ptr %t146, i32 0, i32 18
  store i1 %t147, ptr %t150, !tbaa !21
  %t151 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t152 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t151, 1
  store { i32, { i64, ptr } } %t152, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i64
  %l73 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i1
  %l86 = alloca i1
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l113 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  %t34 = alloca { i64, [4 x i64] }, align 8
  %t47 = alloca { i64, [4 x i64] }, align 8
  %t60 = alloca { i64, [4 x i64] }, align 8
  %t88 = alloca { i64, [4 x i64] }, align 8
  %t193 = alloca { i64, [4 x i64] }, align 8
  %t223 = alloca { i64, [4 x i64] }, align 8
  %t238 = alloca { i64, [4 x i64] }, align 8
  %t253 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb14
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l27
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 1, ptr @.d24 })
  store i1 %t31, ptr %l28
  br label %bb7
bb7:
  %t32 = load i1, ptr %l28, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t33 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t33, 0
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span" } %t37, ptr %t38
  %t39 = load { i64, [4 x i64] }, ptr %t34
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t39, ptr %t41
  call void @__olang_scope_close(ptr %s1)
  store ptr %t41, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br i1 %a2, label %bb11, label %bb12
bb11:
  %t45 = load %"compiler/source:Span", ptr %l3
  %t46 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 0
  store i64 1, ptr %t48
  %t50 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t45, 0
  %t52 = insertvalue { %"compiler/source:Span", ptr } %t50, ptr %t46, 1
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t52, ptr %t53
  %t54 = load { i64, [4 x i64] }, ptr %t47
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t54, ptr %t56
  call void @__olang_scope_close(ptr %s1)
  store ptr %t56, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t58 = load %"compiler/source:Span", ptr %l3
  %t59 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t60
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 0
  store i64 3, ptr %t61
  %t63 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t58, 0
  %t65 = insertvalue { %"compiler/source:Span", i32 } %t63, i32 %t59, 1
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t65, ptr %t66
  %t67 = load { i64, [4 x i64] }, ptr %t60
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t67, ptr %t69
  call void @__olang_scope_close(ptr %s1)
  store ptr %t69, ptr %rv
  br label %ret
bb14:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load ptr, ptr %l41, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 15
  store i1 %t78, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l42, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t82, i32 0, i32 0
  %t84 = load %"compiler/source:Span", ptr %t83
  store %"compiler/source:Span" %t84, ptr %l5
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t86 = load %"compiler/source:Span", ptr %l5
  %t87 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 0
  store i64 1, ptr %t89
  %t91 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t86, 0
  %t93 = insertvalue { %"compiler/source:Span", ptr } %t91, ptr %t87, 1
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t93, ptr %t94
  %t95 = load { i64, [4 x i64] }, ptr %t88
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t95, ptr %t97
  store ptr %t97, ptr %rv
  br label %ret
bb20:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb21, label %bb22
bb21:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 12
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb23, label %bb24
bb23:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t110, i32 0, i32 0
  %t112 = load %"compiler/source:Span", ptr %t111
  store %"compiler/source:Span" %t112, ptr %l6
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t116, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l7, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t122, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123
  store { i64, ptr } %t124, ptr %l8, !tbaa !27
  br label %bb25
bb24:
  br label %bb52
bb25:
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t128 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t126)
  store i1 %t128, ptr %l62
  br label %bb26
bb26:
  %t129 = load i1, ptr %l62, !tbaa !21
  br i1 %t129, label %bb27, label %bb28
bb27:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/parse:Parser", ptr %t130, i32 0, i32 32
  %t134 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eLe_Hc3a9f67fd4028c52dcd01e744501edd7(ptr %v0, ptr %t132)
  store i64 %t134, ptr %l65
  br label %bb29
bb28:
  br label %bb51
bb29:
  %t135 = load i64, ptr %l65, !tbaa !24
  store i64 %t135, ptr %l9, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t136, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l12, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb32:
  br label %bb33
bb33:
  %t150 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t150, ptr %l73, !tbaa !27
  %t151 = load i64, ptr %l11, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr ptr, ptr %t154, i64 %t151
  %t156 = load ptr, ptr %t155, !tbaa !39
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t162 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %t158, ptr %t156, i1 false)
  store ptr %t162, ptr %l78
  br label %bb34
bb34:
  %t163 = load ptr, ptr %l78, !tbaa !29
  store ptr %t163, ptr %l14, !tbaa !29
  %t164 = load ptr, ptr %l14, !tbaa !29
  store ptr %t164, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t165 = load ptr, ptr %l79, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb35, label %bb36
bb35:
  %t168 = load ptr, ptr %l79, !tbaa !29
  %t169 = load i64, ptr %t168
  %t171 = icmp eq i64 %t169, 4
  store i1 %t171, ptr %l80, !tbaa !21
  br label %bb36
bb36:
  %t172 = load i1, ptr %l80, !tbaa !21
  br i1 %t172, label %bb37, label %bb38
bb37:
  %t173 = load ptr, ptr %l14, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l15, !tbaa !29
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t179 = load ptr, ptr %l15, !tbaa !29
  %t181 = call i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %t179)
  store i1 %t181, ptr %l86
  br label %bb40
bb40:
  %t182 = load i1, ptr %l86, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/parse:Parser", ptr %t185, i32 0, i32 32
  %t188 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eTr_H502888c3fa90c24fa361ddb6e04085c1(ptr %v0, ptr %t187, i64 %t188)
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t191 = load %"compiler/source:Span", ptr %l6
  %t192 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 0
  store i64 4, ptr %t194
  %t196 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t191, 0
  %t198 = insertvalue { %"compiler/source:Span", ptr } %t196, ptr %t192, 1
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t198, ptr %t199
  %t200 = load { i64, [4 x i64] }, ptr %t193
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t200, ptr %t202
  call void @__olang_scope_close(ptr %s8)
  store ptr %t202, ptr %rv
  br label %ret
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/parse:Parser", ptr %t204, i32 0, i32 32
  %t207 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v0, ptr %t206, ptr %t207)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  %t210 = load i64, ptr %l11, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l11, !tbaa !24
  br label %bb30
bb49:
  %t214 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t214, ptr %l100
  %t215 = load ptr, ptr %l7, !tbaa !29
  store ptr %t215, ptr %l101, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/parse:Parser", ptr %t216, i32 0, i32 32
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t218, i64 %t219)
  store { i64, ptr } %t222, ptr %l105
  br label %bb50
bb50:
  store { i64, [4 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 0
  store i64 2, ptr %t224
  %t225 = load %"compiler/source:Span", ptr %l100
  %t226 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t225, 0
  %t227 = load ptr, ptr %l101, !tbaa !29
  %t228 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t226, ptr %t227, 1
  %t229 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t230 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t228, { i64, ptr } %t229, 2
  %t231 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t230, ptr %t231
  %t232 = load { i64, [4 x i64] }, ptr %t223
  %t234 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t232, ptr %t234
  store ptr %t234, ptr %rv
  br label %ret
bb51:
  %t236 = load %"compiler/source:Span", ptr %l6
  %t237 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 0
  store i64 4, ptr %t239
  %t241 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t236, 0
  %t243 = insertvalue { %"compiler/source:Span", ptr } %t241, ptr %t237, 1
  %t244 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t243, ptr %t244
  %t245 = load { i64, [4 x i64] }, ptr %t238
  %t247 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t245, ptr %t247
  store ptr %t247, ptr %rv
  br label %ret
bb52:
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t251 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t249)
  store %"compiler/source:Span" %t251, ptr %l113
  br label %bb53
bb53:
  %t252 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 0
  store i64 4, ptr %t254
  %t255 = load %"compiler/source:Span", ptr %l113
  %t256 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t255, 0
  %t258 = insertvalue { %"compiler/source:Span", ptr } %t256, ptr %t252, 1
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t258, ptr %t259
  %t260 = load { i64, [4 x i64] }, ptr %t253
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t260, ptr %t262
  store ptr %t262, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i1
  %l12 = alloca i32
  %l16 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l40 = alloca i32
  %l42 = alloca i32
  %l43 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i32
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l54 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i32
  %l68 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t36 = alloca { i64, [5 x i64] }, align 8
  %t128 = alloca { i64, [5 x i64] }, align 8
  %t140 = alloca { i64, [5 x i64] }, align 8
  %t180 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 5)
  store i1 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t10)
  store i32 %t12, ptr %l12
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb6, label %ok.14
ok.14:
  br label %bb5
bb4:
  br label %bb11
bb5:
  br label %bb7
bb6:
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, ptr } zeroinitializer, i32 %t23, 0
  store { i32, ptr } %t25, ptr %rv
  br label %ret
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t26)
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l16
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t31, i32 %t32)
  store %"compiler/source:Span" %t35, ptr %l19
  br label %bb10
bb10:
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 1, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l19
  %t39 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t38, 0
  %t41 = insertvalue { %"compiler/source:Span", i32 } %t39, i32 5, 1
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t41, ptr %t42
  %t43 = load { i64, [5 x i64] }, ptr %t36
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t43, ptr %t45
  %t47 = insertvalue { i32, ptr } zeroinitializer, ptr %t45, 1
  store { i32, ptr } %t47, ptr %rv
  br label %ret
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t48, i32 85)
  %t52 = extractvalue { i32, i32 } %t51, 1
  %t53 = extractvalue { i32, i32 } %t51, 0
  store i32 %t53, ptr %l27
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb13, label %ok.55
ok.55:
  store i32 %t52, ptr %l26
  br label %bb12
bb12:
  %t56 = load i32, ptr %l26, !tbaa !23
  store i32 %t56, ptr %l23, !tbaa !23
  br label %bb14
bb13:
  %t57 = load i32, ptr %l27, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  %t67 = insertvalue { i32, ptr } zeroinitializer, i32 %t65, 0
  store { i32, ptr } %t67, ptr %rv
  br label %ret
bb14:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t68)
  store i32 %t70, ptr %l30
  br label %bb15
bb15:
  %t71 = load i32, ptr %l30
  store i32 %t71, ptr %l2
  %t72 = load i32, ptr %l2
  %t74 = trunc i64 50 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb18
bb17:
  %t77 = load i32, ptr %l2
  %t79 = trunc i64 84 to i32
  %t80 = icmp eq i32 %t77, %t79
  store i1 %t80, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t82 = load i1, ptr %l33, !tbaa !21
  br i1 %t82, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb21
bb20:
  %t83 = load i32, ptr %l2
  %t85 = trunc i64 85 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l36, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t89)
  store i32 %t91, ptr %l40
  br label %bb24
bb23:
  br label %bb31
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t92)
  store i32 %t94, ptr %l42
  br label %bb25
bb25:
  %t95 = load i32, ptr %l42, !tbaa !23
  store i32 %t95, ptr %l3, !tbaa !23
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t96)
  %t99 = extractvalue { i32, ptr } %t98, 1
  %t100 = extractvalue { i32, ptr } %t98, 0
  store i32 %t100, ptr %l46
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb27, label %ok.102
ok.102:
  store ptr %t99, ptr %l45
  br label %bb26
bb26:
  %t103 = load ptr, ptr %l45, !tbaa !29
  store ptr %t103, ptr %l43, !tbaa !29
  br label %bb28
bb27:
  %t104 = load i32, ptr %l46, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  %t114 = insertvalue { i32, ptr } zeroinitializer, i32 %t112, 0
  store { i32, ptr } %t114, ptr %rv
  br label %ret
bb28:
  %t115 = load ptr, ptr %l43, !tbaa !29
  store ptr %t115, ptr %l4, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l1, !tbaa !23
  %t120 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t116, i32 %t117)
  store %"compiler/source:Span" %t120, ptr %l50
  br label %bb29
bb29:
  store i32 85, ptr %l51
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l3, !tbaa !23
  %t125 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t121, i32 %t122)
  store %"compiler/source:Span" %t125, ptr %l54
  br label %bb30
bb30:
  %t126 = load i32, ptr %l2
  %t127 = load ptr, ptr %l4, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 0
  store i64 3, ptr %t129
  %t130 = load %"compiler/source:Span", ptr %l54
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t130, 0
  %t133 = insertvalue { %"compiler/source:Span", i32, ptr } %t131, i32 %t126, 1
  %t135 = insertvalue { %"compiler/source:Span", i32, ptr } %t133, ptr %t127, 2
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t135, ptr %t136
  %t137 = load { i64, [5 x i64] }, ptr %t128
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t137, ptr %t139
  store { i64, [5 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 0
  store i64 3, ptr %t141
  %t142 = load %"compiler/source:Span", ptr %l50
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t142, 0
  %t144 = load i32, ptr %l51
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr } %t143, i32 %t144, 1
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } %t145, ptr %t139, 2
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t147, ptr %t148
  %t149 = load { i64, [5 x i64] }, ptr %t140
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t149, ptr %t151
  %t153 = insertvalue { i32, ptr } zeroinitializer, ptr %t151, 1
  store { i32, ptr } %t153, ptr %rv
  br label %ret
bb31:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t154)
  %t157 = extractvalue { i32, ptr } %t156, 1
  %t158 = extractvalue { i32, ptr } %t156, 0
  store i32 %t158, ptr %l64
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb33, label %ok.160
ok.160:
  store ptr %t157, ptr %l63
  br label %bb32
bb32:
  %t161 = load ptr, ptr %l63, !tbaa !29
  store ptr %t161, ptr %l61, !tbaa !29
  br label %bb34
bb33:
  %t162 = load i32, ptr %l64, !tbaa !23
  %t163 = lshr i32 %t162, 16
  %t164 = and i32 %t162, 65535
  %t165 = icmp eq i32 %t163, 1
  %t166 = select i1 %t165, i32 1, i32 0
  %t167 = icmp eq i32 %t162, 0
  %t168 = shl i32 %t166, 16
  %t169 = or i32 %t168, %t164
  %t170 = select i1 %t167, i32 0, i32 %t169
  %t172 = insertvalue { i32, ptr } zeroinitializer, i32 %t170, 0
  store { i32, ptr } %t172, ptr %rv
  br label %ret
bb34:
  %t173 = load ptr, ptr %l61, !tbaa !29
  store ptr %t173, ptr %l5, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l1, !tbaa !23
  %t178 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t174, i32 %t175)
  store %"compiler/source:Span" %t178, ptr %l68
  br label %bb35
bb35:
  %t179 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 0
  store i64 3, ptr %t181
  %t182 = load %"compiler/source:Span", ptr %l68
  %t183 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t182, 0
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } %t183, i32 85, 1
  %t187 = insertvalue { %"compiler/source:Span", i32, ptr } %t185, ptr %t179, 2
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t187, ptr %t188
  %t189 = load { i64, [5 x i64] }, ptr %t180
  %t191 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t189, ptr %t191
  %t193 = insertvalue { i32, ptr } zeroinitializer, ptr %t191, 1
  store { i32, ptr } %t193, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l35 = alloca i64
  %l42 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1
  %t3 = trunc i64 46 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb77
bb4:
  %t6 = load i32, ptr %l1
  %t8 = trunc i64 47 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 2, ptr %l2, !tbaa !24
  br label %bb77
bb8:
  %t11 = load i32, ptr %l1
  %t13 = trunc i64 45 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 3, ptr %l2, !tbaa !24
  br label %bb77
bb12:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 82 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 4, ptr %l2, !tbaa !24
  br label %bb77
bb16:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 83 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 5, ptr %l2, !tbaa !24
  br label %bb77
bb20:
  %t26 = load i32, ptr %l1
  %t28 = trunc i64 81 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 6, ptr %l2, !tbaa !24
  br label %bb77
bb24:
  %t31 = load i32, ptr %l1
  %t33 = trunc i64 73 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  %t36 = load i32, ptr %l1
  %t38 = trunc i64 75 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i64 7, ptr %l2, !tbaa !24
  br label %bb77
bb30:
  %t41 = load i32, ptr %l1
  %t43 = trunc i64 26 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  %t46 = load i32, ptr %l1
  %t48 = trunc i64 27 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t51 = load i32, ptr %l1
  %t53 = trunc i64 48 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i64 8, ptr %l2, !tbaa !24
  br label %bb77
bb38:
  %t56 = load i32, ptr %l1
  %t58 = trunc i64 77 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  %t61 = load i32, ptr %l1
  %t63 = trunc i64 78 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb41, label %bb42
bb41:
  br label %bb47
bb42:
  %t66 = load i32, ptr %l1
  %t68 = trunc i64 79 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb43, label %bb44
bb43:
  br label %bb47
bb44:
  %t71 = load i32, ptr %l1
  %t73 = trunc i64 80 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/parse:Parser", ptr %t76, i32 0, i32 11
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb48, label %bb49
bb48:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb50
bb49:
  store i64 8, ptr %l35, !tbaa !24
  br label %bb50
bb50:
  %t81 = load i64, ptr %l35, !tbaa !24
  store i64 %t81, ptr %l2, !tbaa !24
  br label %bb77
bb51:
  %t82 = load i32, ptr %l1
  %t84 = trunc i64 86 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb52, label %bb53
bb52:
  br label %bb56
bb53:
  %t87 = load i32, ptr %l1
  %t89 = trunc i64 87 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb60
bb56:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 11
  %t95 = load i1, ptr %t94, !tbaa !21
  br i1 %t95, label %bb57, label %bb58
bb57:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb59
bb58:
  store i64 9, ptr %l42, !tbaa !24
  br label %bb59
bb59:
  %t97 = load i64, ptr %l42, !tbaa !24
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb77
bb60:
  %t98 = load i32, ptr %l1
  %t100 = trunc i64 49 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb61, label %bb62
bb61:
  br label %bb65
bb62:
  %t103 = load i32, ptr %l1
  %t105 = trunc i64 50 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i64 10, ptr %l2, !tbaa !24
  br label %bb77
bb66:
  %t108 = load i32, ptr %l1
  %t110 = trunc i64 51 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb67, label %bb68
bb67:
  br label %bb75
bb68:
  %t113 = load i32, ptr %l1
  %t115 = trunc i64 52 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb69, label %bb70
bb69:
  br label %bb75
bb70:
  %t118 = load i32, ptr %l1
  %t120 = trunc i64 53 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb71, label %bb72
bb71:
  br label %bb75
bb72:
  %t123 = load i32, ptr %l1
  %t125 = trunc i64 54 to i32
  %t126 = icmp eq i32 %t123, %t125
  br i1 %t126, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store i64 11, ptr %l2, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb77
bb77:
  %t128 = load i64, ptr %l2, !tbaa !24
  store i64 %t128, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca %"compiler/token:Token"
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %lp18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l21 = alloca i32
  %l25 = alloca i32
  %l27 = alloca i32
  %l41 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l55 = alloca ptr
  %l64 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca ptr
  %l78 = alloca ptr
  %l83 = alloca i32
  %l86 = alloca i32
  %l87 = alloca i32
  %l95 = alloca %"compiler/source:Span"
  %l109 = alloca i1
  %l111 = alloca i32
  %l112 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i32
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i32
  %l125 = alloca %"compiler/source:Span"
  %l134 = alloca i32
  %l135 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca i32
  %l140 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i32
  %l147 = alloca %"compiler/source:Span"
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l156 = alloca %"compiler/ast:Func"
  %l162 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca i32
  %l169 = alloca %"compiler/source:Span"
  %l176 = alloca %"compiler/token:Token"
  %l178 = alloca i32
  %l180 = alloca ptr
  %l183 = alloca { i64, ptr }
  %l184 = alloca i32
  %l187 = alloca i1
  %l192 = alloca i1
  %l194 = alloca i32
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca i32
  %l202 = alloca %"compiler/source:Span"
  %l205 = alloca %"compiler/source:Span"
  %l211 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca i32
  %l220 = alloca i1
  %l225 = alloca i1
  %l227 = alloca i32
  %l228 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca i32
  %l235 = alloca %"compiler/source:Span"
  %l238 = alloca %"compiler/source:Span"
  %l247 = alloca i1
  %l249 = alloca i32
  %l252 = alloca i1
  %l254 = alloca i32
  %l258 = alloca i32
  %l260 = alloca i1
  %l263 = alloca %"compiler/source:Span"
  %l264 = alloca i32
  %l267 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l274 = alloca ptr
  %l275 = alloca i32
  %l279 = alloca ptr
  %l280 = alloca ptr
  %l281 = alloca i32
  %l285 = alloca %"compiler/source:Span"
  %l292 = alloca i32
  %l295 = alloca i1
  %l298 = alloca i1
  %l300 = alloca i32
  %l303 = alloca i1
  %l308 = alloca i1
  %l310 = alloca i32
  %l313 = alloca %"compiler/source:Span"
  %l314 = alloca i32
  %l317 = alloca { i64, ptr }
  %l326 = alloca ptr
  %l327 = alloca ptr
  %l331 = alloca ptr
  %l332 = alloca i32
  %l335 = alloca i32
  %l338 = alloca %"compiler/source:Span"
  %l345 = alloca i32
  %l348 = alloca i32
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t48 = alloca { i64, [5 x i64] }, align 8
  %t177 = alloca { i64, [5 x i64] }, align 8
  %t266 = alloca { i64, [5 x i64] }, align 8
  %t357 = alloca { i64, [5 x i64] }, align 8
  %t400 = alloca { i64, [5 x i64] }, align 8
  %t489 = alloca { i64, [5 x i64] }, align 8
  %t500 = alloca { i64, [5 x i64] }, align 8
  %t589 = alloca { i64, [5 x i64] }, align 8
  %t600 = alloca { i64, [5 x i64] }, align 8
  %t657 = alloca i64
  %t675 = alloca { i64, [5 x i64] }, align 8
  %t725 = alloca { i64, [5 x i64] }, align 8
  %t794 = alloca i64
  %t812 = alloca { i64, [5 x i64] }, align 8
  %t867 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l25
  br label %bb1
bb1:
  %t4 = load i32, ptr %l25, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l27
  br label %bb2
bb2:
  %t8 = load i32, ptr %l27
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2
  %t11 = trunc i64 2 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  %t14 = load i32, ptr %l2
  %t16 = trunc i64 3 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  %t19 = load i32, ptr %l2
  %t21 = trunc i64 4 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t24 = load i32, ptr %l2
  %t26 = trunc i64 6 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load i32, ptr %l2
  %t31 = trunc i64 7 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load i32, ptr %l2
  %t36 = trunc i64 5 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l41
  br label %bb16
bb16:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t42, i32 %t43)
  store %"compiler/source:Span" %t46, ptr %l44
  br label %bb17
bb17:
  %t47 = load i32, ptr %l2
  store { i64, [5 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 0
  store i64 1, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l44
  %t51 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t50, 0
  %t53 = insertvalue { %"compiler/source:Span", i32 } %t51, i32 %t47, 1
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t53, ptr %t54
  %t55 = load { i64, [5 x i64] }, ptr %t48
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t55, ptr %t57
  %t59 = insertvalue { i32, ptr } zeroinitializer, ptr %t57, 1
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb18:
  %t60 = load i32, ptr %l2
  %t62 = trunc i64 88 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t65)
  store i32 %t67, ptr %l51
  br label %bb22
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 11
  %t71 = load i1, ptr %t70, !tbaa !21
  store i1 %t71, ptr %l3, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 11
  store i1 false, ptr %t75, !tbaa !21
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l55, !tbaa !29
  %t77 = load ptr, ptr %l55, !tbaa !29
  %t78 = getelementptr %"compiler/parse:Parser", ptr %t77, i32 0, i32 16
  %t79 = load i64, ptr %t78, !tbaa !24
  %t81 = add i64 %t79, 1
  %t83 = load ptr, ptr %l55, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 16
  store i64 %t81, ptr %t84, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 17
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l4, !tbaa !21
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/parse:Parser", ptr %t90, i32 0, i32 18
  %t93 = load i1, ptr %t92, !tbaa !21
  store i1 %t93, ptr %l5, !tbaa !21
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/parse:Parser", ptr %t95, i32 0, i32 17
  store i1 true, ptr %t97, !tbaa !21
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/parse:Parser", ptr %t98, i32 0, i32 18
  store i1 false, ptr %t100, !tbaa !21
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t101)
  %t104 = extractvalue { i32, ptr } %t103, 1
  %t105 = extractvalue { i32, ptr } %t103, 0
  store i32 %t105, ptr %l67
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb24, label %ok.107
ok.107:
  store ptr %t104, ptr %l66
  br label %bb23
bb23:
  %t108 = load ptr, ptr %l66, !tbaa !29
  store ptr %t108, ptr %l64, !tbaa !29
  br label %bb26
bb24:
  br label %bb25
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l68, !tbaa !29
  %t110 = load ptr, ptr %l68, !tbaa !29
  %t111 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 16
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = sub i64 %t112, 1
  %t116 = load ptr, ptr %l68, !tbaa !29
  %t117 = getelementptr %"compiler/parse:Parser", ptr %t116, i32 0, i32 16
  store i64 %t114, ptr %t117, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i1, ptr %l4, !tbaa !21
  %t122 = getelementptr %"compiler/parse:Parser", ptr %t118, i32 0, i32 17
  store i1 %t119, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i1, ptr %l5, !tbaa !21
  %t127 = getelementptr %"compiler/parse:Parser", ptr %t123, i32 0, i32 18
  store i1 %t124, ptr %t127, !tbaa !21
  %t129 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t129, ptr %rv
  br label %ret
bb26:
  %t130 = load ptr, ptr %l64, !tbaa !29
  store ptr %t130, ptr %l6, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i1, ptr %l5, !tbaa !21
  %t135 = getelementptr %"compiler/parse:Parser", ptr %t131, i32 0, i32 18
  store i1 %t132, ptr %t135, !tbaa !21
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = load ptr, ptr %l78, !tbaa !29
  %t138 = getelementptr %"compiler/parse:Parser", ptr %t137, i32 0, i32 16
  %t139 = load i64, ptr %t138, !tbaa !24
  %t141 = sub i64 %t139, 1
  %t143 = load ptr, ptr %l78, !tbaa !29
  %t144 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 16
  store i64 %t141, ptr %t144, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i1, ptr %l3, !tbaa !21
  %t149 = getelementptr %"compiler/parse:Parser", ptr %t145, i32 0, i32 11
  store i1 %t146, ptr %t149, !tbaa !21
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t153 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t150, i32 89)
  %t154 = extractvalue { i32, i32 } %t153, 1
  %t155 = extractvalue { i32, i32 } %t153, 0
  store i32 %t155, ptr %l87
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb28, label %ok.157
ok.157:
  store i32 %t154, ptr %l86
  br label %bb27
bb27:
  %t158 = load i32, ptr %l86, !tbaa !23
  store i32 %t158, ptr %l83, !tbaa !23
  br label %bb30
bb28:
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i1, ptr %l4, !tbaa !21
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 17
  store i1 %t160, ptr %t163, !tbaa !21
  %t165 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb30:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i1, ptr %l4, !tbaa !21
  %t170 = getelementptr %"compiler/parse:Parser", ptr %t166, i32 0, i32 17
  store i1 %t167, ptr %t170, !tbaa !21
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l1, !tbaa !23
  %t175 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t171, i32 %t172)
  store %"compiler/source:Span" %t175, ptr %l95
  br label %bb31
bb31:
  %t176 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 0
  store i64 2, ptr %t178
  %t179 = load %"compiler/source:Span", ptr %l95
  %t180 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t179, 0
  %t182 = insertvalue { %"compiler/source:Span", ptr } %t180, ptr %t176, 1
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t182, ptr %t183
  %t184 = load { i64, [5 x i64] }, ptr %t177
  %t186 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t184, ptr %t186
  %t188 = insertvalue { i32, ptr } zeroinitializer, ptr %t186, 1
  store { i32, ptr } %t188, ptr %rv
  br label %ret
bb32:
  %t189 = load i32, ptr %l2
  %t191 = trunc i64 11 to i32
  %t192 = icmp eq i32 %t189, %t191
  br i1 %t192, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t194 = load i32, ptr %l2
  %t196 = trunc i64 12 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb47
bb37:
  %t199 = load i32, ptr %l1, !tbaa !23
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/parse:Parser", ptr %t200, i32 0, i32 23
  %t203 = load i32, ptr %t202, !tbaa !23
  %t206 = icmp eq i32 %t199, %t203
  store i1 %t206, ptr %l7, !tbaa !21
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t211 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t208, i32 12)
  store i1 %t211, ptr %l109
  br label %bb38
bb38:
  %t212 = load i1, ptr %l109, !tbaa !21
  store i1 %t212, ptr %l8, !tbaa !21
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t213)
  store i32 %t215, ptr %l111
  br label %bb39
bb39:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t216)
  %t219 = extractvalue { i32, ptr } %t218, 1
  %t220 = extractvalue { i32, ptr } %t218, 0
  store i32 %t220, ptr %l115
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb41, label %ok.222
ok.222:
  store ptr %t219, ptr %l114
  br label %bb40
bb40:
  %t223 = load ptr, ptr %l114, !tbaa !29
  store ptr %t223, ptr %l112, !tbaa !29
  br label %bb42
bb41:
  %t224 = load i32, ptr %l115, !tbaa !23
  %t225 = lshr i32 %t224, 16
  %t226 = and i32 %t224, 65535
  %t227 = icmp eq i32 %t225, 1
  %t228 = select i1 %t227, i32 1, i32 0
  %t229 = icmp eq i32 %t224, 0
  %t230 = shl i32 %t228, 16
  %t231 = or i32 %t230, %t226
  %t232 = select i1 %t229, i32 0, i32 %t231
  %t234 = insertvalue { i32, ptr } zeroinitializer, i32 %t232, 0
  store { i32, ptr } %t234, ptr %rv
  br label %ret
bb42:
  %t235 = load ptr, ptr %l112, !tbaa !29
  store ptr %t235, ptr %l9, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i1, ptr %l7, !tbaa !21
  %t240 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t236, i1 %t237)
  %t241 = extractvalue { i32, { i64, ptr } } %t240, 1
  %t242 = extractvalue { i32, { i64, ptr } } %t240, 0
  store i32 %t242, ptr %l121
  %t243 = icmp ne i32 %t242, 0
  br i1 %t243, label %bb44, label %ok.244
ok.244:
  store { i64, ptr } %t241, ptr %l120
  br label %bb43
bb43:
  %t245 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t245, ptr %l117, !tbaa !27
  br label %bb45
bb44:
  %t246 = load i32, ptr %l121, !tbaa !23
  %t247 = lshr i32 %t246, 16
  %t248 = and i32 %t246, 65535
  %t249 = icmp eq i32 %t247, 1
  %t250 = select i1 %t249, i32 1, i32 0
  %t251 = icmp eq i32 %t246, 0
  %t252 = shl i32 %t250, 16
  %t253 = or i32 %t252, %t248
  %t254 = select i1 %t251, i32 0, i32 %t253
  %t256 = insertvalue { i32, ptr } zeroinitializer, i32 %t254, 0
  store { i32, ptr } %t256, ptr %rv
  br label %ret
bb45:
  %t257 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t257, ptr %l10, !tbaa !27
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l1, !tbaa !23
  %t262 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t258, i32 %t259)
  store %"compiler/source:Span" %t262, ptr %l125
  br label %bb46
bb46:
  %t263 = load ptr, ptr %l9, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t265 = load i1, ptr %l8, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [5 x i64] }, ptr %t266, i32 0, i32 0
  store i64 22, ptr %t267
  %t268 = load %"compiler/source:Span", ptr %l125
  %t269 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } undef, %"compiler/source:Span" %t268, 0
  %t271 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t269, ptr %t263, 1
  %t273 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t271, { i64, ptr } %t264, 2
  %t275 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t273, i1 %t265, 3
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t266, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t275, ptr %t276
  %t277 = load { i64, [5 x i64] }, ptr %t266
  %t279 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t277, ptr %t279
  %t281 = insertvalue { i32, ptr } zeroinitializer, ptr %t279, 1
  store { i32, ptr } %t281, ptr %rv
  br label %ret
bb47:
  %t282 = load i32, ptr %l2
  %t284 = trunc i64 37 to i32
  %t285 = icmp eq i32 %t282, %t284
  br i1 %t285, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb65
bb50:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t287)
  store i32 %t289, ptr %l134
  br label %bb51
bb51:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t290, i1 true, i1 true, i1 false)
  %t293 = extractvalue { i32, ptr } %t292, 1
  %t294 = extractvalue { i32, ptr } %t292, 0
  store i32 %t294, ptr %l138
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb53, label %ok.296
ok.296:
  store ptr %t293, ptr %l137
  br label %bb52
bb52:
  %t297 = load ptr, ptr %l137, !tbaa !29
  store ptr %t297, ptr %l135, !tbaa !29
  br label %bb54
bb53:
  %t298 = load i32, ptr %l138, !tbaa !23
  %t299 = lshr i32 %t298, 16
  %t300 = and i32 %t298, 65535
  %t301 = icmp eq i32 %t299, 1
  %t302 = select i1 %t301, i32 1, i32 0
  %t303 = icmp eq i32 %t298, 0
  %t304 = shl i32 %t302, 16
  %t305 = or i32 %t304, %t300
  %t306 = select i1 %t303, i32 0, i32 %t305
  %t308 = insertvalue { i32, ptr } zeroinitializer, i32 %t306, 0
  store { i32, ptr } %t308, ptr %rv
  br label %ret
bb54:
  %t309 = load ptr, ptr %l135, !tbaa !29
  store ptr %t309, ptr %l11, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t310)
  %t313 = extractvalue { i32, { i64, ptr } } %t312, 1
  %t314 = extractvalue { i32, { i64, ptr } } %t312, 0
  store i32 %t314, ptr %l143
  %t315 = icmp ne i32 %t314, 0
  br i1 %t315, label %bb56, label %ok.316
ok.316:
  store { i64, ptr } %t313, ptr %l142
  br label %bb55
bb55:
  %t317 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t317, ptr %l140, !tbaa !27
  br label %bb57
bb56:
  %t318 = load i32, ptr %l143, !tbaa !23
  %t319 = lshr i32 %t318, 16
  %t320 = and i32 %t318, 65535
  %t321 = icmp eq i32 %t319, 1
  %t322 = select i1 %t321, i32 1, i32 0
  %t323 = icmp eq i32 %t318, 0
  %t324 = shl i32 %t322, 16
  %t325 = or i32 %t324, %t320
  %t326 = select i1 %t323, i32 0, i32 %t325
  %t328 = insertvalue { i32, ptr } zeroinitializer, i32 %t326, 0
  store { i32, ptr } %t328, ptr %rv
  br label %ret
bb57:
  %t329 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t329, ptr %l12, !tbaa !27
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i32, ptr %l1, !tbaa !23
  %t334 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t330, i32 %t331)
  store %"compiler/source:Span" %t334, ptr %l147
  br label %bb58
bb58:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l1, !tbaa !23
  %t339 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t335, i32 %t336)
  store %"compiler/source:Span" %t339, ptr %l150
  br label %bb59
bb59:
  %t340 = load ptr, ptr %l11, !tbaa !29
  store ptr %t340, ptr %l151, !tbaa !29
  %t341 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t341, ptr %l152, !tbaa !27
  %t342 = icmp sge i64 0, 0
  br i1 %t342, label %bb60, label %bb61
bb60:
  %t344 = icmp sle i64 0, 1152921504606846975
  br i1 %t344, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a)
  unreachable
bb62:
  %t346 = mul i64 0, 8
  %t347 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t346)
  %t348 = insertvalue { i64, ptr } undef, i64 0, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t350 = load %"compiler/source:Span", ptr %l150
  %t351 = load ptr, ptr %l151, !tbaa !29
  %t352 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t354 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t350, ptr null, i32 0, ptr %t351, { i64, ptr } %t352, { i64, ptr } %t349, i1 true)
  store %"compiler/ast:Func" %t354, ptr %l156
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a)
  unreachable
bb64:
  %t355 = load %"compiler/ast:Func", ptr %l156
  %t356 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t355, ptr %t356
  store { i64, [5 x i64] } zeroinitializer, ptr %t357
  %t358 = getelementptr { i64, [5 x i64] }, ptr %t357, i32 0, i32 0
  store i64 23, ptr %t358
  %t359 = load %"compiler/source:Span", ptr %l147
  %t360 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t359, 0
  %t362 = insertvalue { %"compiler/source:Span", ptr } %t360, ptr %t356, 1
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t357, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t362, ptr %t363
  %t364 = load { i64, [5 x i64] }, ptr %t357
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t364, ptr %t366
  %t368 = insertvalue { i32, ptr } zeroinitializer, ptr %t366, 1
  store { i32, ptr } %t368, ptr %rv
  br label %ret
bb65:
  %t369 = load i32, ptr %l2
  %t371 = trunc i64 30 to i32
  %t372 = icmp eq i32 %t369, %t371
  br i1 %t372, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb73
bb68:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %t374)
  %t377 = extractvalue { i32, ptr } %t376, 1
  %t378 = extractvalue { i32, ptr } %t376, 0
  store i32 %t378, ptr %l165
  %t379 = icmp ne i32 %t378, 0
  br i1 %t379, label %bb70, label %ok.380
ok.380:
  store ptr %t377, ptr %l164
  br label %bb69
bb69:
  %t381 = load ptr, ptr %l164, !tbaa !29
  store ptr %t381, ptr %l162, !tbaa !29
  br label %bb71
bb70:
  %t382 = load i32, ptr %l165, !tbaa !23
  %t383 = lshr i32 %t382, 16
  %t384 = and i32 %t382, 65535
  %t385 = icmp eq i32 %t383, 1
  %t386 = select i1 %t385, i32 1, i32 0
  %t387 = icmp eq i32 %t382, 0
  %t388 = shl i32 %t386, 16
  %t389 = or i32 %t388, %t384
  %t390 = select i1 %t387, i32 0, i32 %t389
  %t392 = insertvalue { i32, ptr } zeroinitializer, i32 %t390, 0
  store { i32, ptr } %t392, ptr %rv
  br label %ret
bb71:
  %t393 = load ptr, ptr %l162, !tbaa !29
  store ptr %t393, ptr %l13, !tbaa !29
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i32, ptr %l1, !tbaa !23
  %t398 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t394, i32 %t395)
  store %"compiler/source:Span" %t398, ptr %l169
  br label %bb72
bb72:
  %t399 = load ptr, ptr %l13, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t400
  %t401 = getelementptr { i64, [5 x i64] }, ptr %t400, i32 0, i32 0
  store i64 24, ptr %t401
  %t402 = load %"compiler/source:Span", ptr %l169
  %t403 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t402, 0
  %t405 = insertvalue { %"compiler/source:Span", ptr } %t403, ptr %t399, 1
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t400, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t405, ptr %t406
  %t407 = load { i64, [5 x i64] }, ptr %t400
  %t409 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t407, ptr %t409
  %t411 = insertvalue { i32, ptr } zeroinitializer, ptr %t409, 1
  store { i32, ptr } %t411, ptr %rv
  br label %ret
bb73:
  %t412 = load i32, ptr %l2
  %t414 = trunc i64 1 to i32
  %t415 = icmp eq i32 %t412, %t414
  br i1 %t415, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb174
bb76:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t417)
  store %"compiler/token:Token" %t419, ptr %l176
  br label %bb77
bb77:
  %t420 = load %"compiler/token:Token", ptr %l176
  store %"compiler/token:Token" %t420, ptr %l14
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t421, i64 1)
  store i32 %t423, ptr %l178
  br label %bb78
bb78:
  %t424 = load i32, ptr %l178
  store i32 %t424, ptr %l15
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/parse:Parser", ptr %t425, i32 0, i32 2
  %t428 = load ptr, ptr %t427, !tbaa !29
  store ptr %t428, ptr %l180, !tbaa !29
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load %"compiler/token:Token", ptr %l14
  %t433 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t429, %"compiler/token:Token" %t430)
  store { i64, ptr } %t433, ptr %l183
  br label %bb79
bb79:
  %t434 = load ptr, ptr %l180, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t436 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t434, { i64, ptr } %t435)
  store i32 %t436, ptr %l184
  br label %bb80
bb80:
  %t437 = load i32, ptr %l184, !tbaa !23
  store i32 %t437, ptr %l16, !tbaa !23
  %t438 = load i32, ptr %l15
  %t440 = trunc i64 77 to i32
  %t441 = icmp eq i32 %t438, %t440
  br i1 %t441, label %bb81, label %bb82
bb81:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/parse:Parser", ptr %t443, i32 0, i32 3
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/parse:Oracle", ptr %t446, i32 0, i32 0
  %t449 = load i32, ptr %l16, !tbaa !23
  %t452 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t448, i32 %t449)
  store i1 %t452, ptr %l192
  br label %bb83
bb82:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb84
bb83:
  %t453 = load i1, ptr %l192, !tbaa !21
  store i1 %t453, ptr %l187, !tbaa !21
  br label %bb84
bb84:
  %t454 = load i1, ptr %l187, !tbaa !21
  br i1 %t454, label %bb85, label %bb86
bb85:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t455)
  store i32 %t457, ptr %l194
  br label %bb87
bb86:
  br label %bb96
bb87:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t458)
  %t461 = extractvalue { i32, { i64, ptr } } %t460, 1
  %t462 = extractvalue { i32, { i64, ptr } } %t460, 0
  store i32 %t462, ptr %l198
  %t463 = icmp ne i32 %t462, 0
  br i1 %t463, label %bb89, label %ok.464
ok.464:
  store { i64, ptr } %t461, ptr %l197
  br label %bb88
bb88:
  %t465 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t465, ptr %l195, !tbaa !27
  br label %bb90
bb89:
  %t466 = load i32, ptr %l198, !tbaa !23
  %t467 = lshr i32 %t466, 16
  %t468 = and i32 %t466, 65535
  %t469 = icmp eq i32 %t467, 1
  %t470 = select i1 %t469, i32 1, i32 0
  %t471 = icmp eq i32 %t466, 0
  %t472 = shl i32 %t470, 16
  %t473 = or i32 %t472, %t468
  %t474 = select i1 %t471, i32 0, i32 %t473
  %t476 = insertvalue { i32, ptr } zeroinitializer, i32 %t474, 0
  store { i32, ptr } %t476, ptr %rv
  br label %ret
bb90:
  %t477 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t477, ptr %l17, !tbaa !27
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i32, ptr %l1, !tbaa !23
  %t482 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t478, i32 %t479)
  store %"compiler/source:Span" %t482, ptr %l202
  br label %bb91
bb91:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i32, ptr %l1, !tbaa !23
  %t487 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t483, i32 %t484)
  store %"compiler/source:Span" %t487, ptr %l205
  br label %bb92
bb92:
  %t488 = load i32, ptr %l16, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t489
  %t490 = getelementptr { i64, [5 x i64] }, ptr %t489, i32 0, i32 0
  store i64 0, ptr %t490
  %t491 = load %"compiler/source:Span", ptr %l205
  %t492 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t491, 0
  %t494 = insertvalue { %"compiler/source:Span", i32 } %t492, i32 %t488, 1
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t489, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t494, ptr %t495
  %t496 = load { i64, [5 x i64] }, ptr %t489
  %t498 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t496, ptr %t498
  %t499 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t500
  %t501 = getelementptr { i64, [5 x i64] }, ptr %t500, i32 0, i32 0
  store i64 14, ptr %t501
  %t502 = load %"compiler/source:Span", ptr %l202
  %t503 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t502, 0
  %t505 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t503, ptr %t498, 1
  %t507 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t505, { i64, ptr } %t499, 2
  %t508 = getelementptr { i64, [5 x i64] }, ptr %t500, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t507, ptr %t508
  %t509 = load { i64, [5 x i64] }, ptr %t500
  %t510 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t510, ptr %lp18
  %t512 = load ptr, ptr %lp18
  store { i64, [5 x i64] } %t509, ptr %t512
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load i32, ptr %l1, !tbaa !23
  %t515 = load ptr, ptr %lp18
  %t519 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %t513, i32 %t514, ptr %t515)
  %t520 = extractvalue { i32, ptr } %t519, 1
  %t521 = extractvalue { i32, ptr } %t519, 0
  store i32 %t521, ptr %l216
  %t522 = icmp ne i32 %t521, 0
  br i1 %t522, label %bb94, label %ok.523
ok.523:
  store ptr %t520, ptr %l215
  br label %bb93
bb93:
  %t524 = load ptr, ptr %l215, !tbaa !29
  store ptr %t524, ptr %l211, !tbaa !29
  br label %bb95
bb94:
  %t525 = load i32, ptr %l216, !tbaa !23
  %t526 = lshr i32 %t525, 16
  %t527 = and i32 %t525, 65535
  %t528 = icmp eq i32 %t526, 1
  %t529 = select i1 %t528, i32 1, i32 0
  %t530 = icmp eq i32 %t525, 0
  %t531 = shl i32 %t529, 16
  %t532 = or i32 %t531, %t527
  %t533 = select i1 %t530, i32 0, i32 %t532
  %t535 = insertvalue { i32, ptr } zeroinitializer, i32 %t533, 0
  store { i32, ptr } %t535, ptr %rv
  br label %ret
bb95:
  %t536 = load ptr, ptr %l211, !tbaa !29
  %t537 = insertvalue { i32, ptr } zeroinitializer, ptr %t536, 1
  store { i32, ptr } %t537, ptr %rv
  br label %ret
bb96:
  %t538 = load i32, ptr %l15
  %t540 = trunc i64 77 to i32
  %t541 = icmp eq i32 %t538, %t540
  br i1 %t541, label %bb97, label %bb98
bb97:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/parse:Parser", ptr %t543, i32 0, i32 3
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = getelementptr %"compiler/parse:Oracle", ptr %t546, i32 0, i32 2
  %t549 = load i32, ptr %l16, !tbaa !23
  %t552 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t548, i32 %t549)
  store i1 %t552, ptr %l225
  br label %bb99
bb98:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb100
bb99:
  %t553 = load i1, ptr %l225, !tbaa !21
  store i1 %t553, ptr %l220, !tbaa !21
  br label %bb100
bb100:
  %t554 = load i1, ptr %l220, !tbaa !21
  br i1 %t554, label %bb101, label %bb102
bb101:
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t557 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t555)
  store i32 %t557, ptr %l227
  br label %bb103
bb102:
  br label %bb109
bb103:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t560 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t558)
  %t561 = extractvalue { i32, { i64, ptr } } %t560, 1
  %t562 = extractvalue { i32, { i64, ptr } } %t560, 0
  store i32 %t562, ptr %l231
  %t563 = icmp ne i32 %t562, 0
  br i1 %t563, label %bb105, label %ok.564
ok.564:
  store { i64, ptr } %t561, ptr %l230
  br label %bb104
bb104:
  %t565 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t565, ptr %l228, !tbaa !27
  br label %bb106
bb105:
  %t566 = load i32, ptr %l231, !tbaa !23
  %t567 = lshr i32 %t566, 16
  %t568 = and i32 %t566, 65535
  %t569 = icmp eq i32 %t567, 1
  %t570 = select i1 %t569, i32 1, i32 0
  %t571 = icmp eq i32 %t566, 0
  %t572 = shl i32 %t570, 16
  %t573 = or i32 %t572, %t568
  %t574 = select i1 %t571, i32 0, i32 %t573
  %t576 = insertvalue { i32, ptr } zeroinitializer, i32 %t574, 0
  store { i32, ptr } %t576, ptr %rv
  br label %ret
bb106:
  %t577 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t577, ptr %l19, !tbaa !27
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load i32, ptr %l1, !tbaa !23
  %t582 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t578, i32 %t579)
  store %"compiler/source:Span" %t582, ptr %l235
  br label %bb107
bb107:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load i32, ptr %l1, !tbaa !23
  %t587 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t583, i32 %t584)
  store %"compiler/source:Span" %t587, ptr %l238
  br label %bb108
bb108:
  %t588 = load i32, ptr %l16, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t589
  %t590 = getelementptr { i64, [5 x i64] }, ptr %t589, i32 0, i32 0
  store i64 0, ptr %t590
  %t591 = load %"compiler/source:Span", ptr %l238
  %t592 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t591, 0
  %t594 = insertvalue { %"compiler/source:Span", i32 } %t592, i32 %t588, 1
  %t595 = getelementptr { i64, [5 x i64] }, ptr %t589, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t594, ptr %t595
  %t596 = load { i64, [5 x i64] }, ptr %t589
  %t598 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t596, ptr %t598
  %t599 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t600
  %t601 = getelementptr { i64, [5 x i64] }, ptr %t600, i32 0, i32 0
  store i64 14, ptr %t601
  %t602 = load %"compiler/source:Span", ptr %l235
  %t603 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t602, 0
  %t605 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t603, ptr %t598, 1
  %t607 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t605, { i64, ptr } %t599, 2
  %t608 = getelementptr { i64, [5 x i64] }, ptr %t600, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t607, ptr %t608
  %t609 = load { i64, [5 x i64] }, ptr %t600
  %t611 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t609, ptr %t611
  %t613 = insertvalue { i32, ptr } zeroinitializer, ptr %t611, 1
  store { i32, ptr } %t613, ptr %rv
  br label %ret
bb109:
  %t614 = load i32, ptr %l15
  %t616 = trunc i64 57 to i32
  %t617 = icmp eq i32 %t614, %t616
  br i1 %t617, label %bb110, label %bb111
bb110:
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t621 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t619, i64 2)
  store i32 %t621, ptr %l249
  br label %bb112
bb111:
  store i1 false, ptr %l247, !tbaa !21
  br label %bb113
bb112:
  %t622 = load i32, ptr %l249
  %t624 = trunc i64 81 to i32
  %t625 = icmp eq i32 %t622, %t624
  store i1 %t625, ptr %l247, !tbaa !21
  br label %bb113
bb113:
  %t627 = load i1, ptr %l247, !tbaa !21
  br i1 %t627, label %bb114, label %bb115
bb114:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t628, i64 3)
  store i32 %t630, ptr %l254
  br label %bb116
bb115:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb117
bb116:
  %t631 = load i32, ptr %l254
  %t633 = trunc i64 90 to i32
  %t634 = icmp eq i32 %t631, %t633
  store i1 %t634, ptr %l252, !tbaa !21
  br label %bb117
bb117:
  %t636 = load i1, ptr %l252, !tbaa !21
  br i1 %t636, label %bb118, label %bb119
bb118:
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t639 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t637)
  store i32 %t639, ptr %l258
  br label %bb120
bb119:
  br label %bb139
bb120:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t640)
  store i1 %t642, ptr %l260
  br label %bb121
bb121:
  %t643 = load i1, ptr %l260, !tbaa !21
  br i1 %t643, label %bb122, label %bb123
bb122:
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t645 = load i32, ptr %l1, !tbaa !23
  %t648 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t644, i32 %t645)
  store %"compiler/source:Span" %t648, ptr %l263
  br label %bb124
bb123:
  br label %bb137
bb124:
  %t649 = load i32, ptr %l16, !tbaa !23
  store i32 %t649, ptr %l264, !tbaa !23
  %t650 = icmp sge i64 1, 0
  br i1 %t650, label %bb125, label %bb126
bb125:
  %t652 = icmp sle i64 1, 2305843009213693951
  br i1 %t652, label %bb127, label %bb128
bb126:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb127:
  %t654 = mul i64 1, 4
  %t655 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t654)
  %t656 = load i32, ptr %l264, !tbaa !23
  store i64 0, ptr %t657
  br label %fill.658
fill.658:
  %t661 = load i64, ptr %t657
  %t662 = icmp slt i64 %t661, 1
  br i1 %t662, label %fillb.659, label %filld.660
fillb.659:
  %t663 = getelementptr i32, ptr %t655, i64 %t661
  store i32 %t656, ptr %t663
  %t664 = add i64 %t661, 1
  store i64 %t664, ptr %t657
  br label %fill.658
filld.660:
  %t665 = insertvalue { i64, ptr } undef, i64 1, 0
  %t666 = insertvalue { i64, ptr } %t665, ptr %t655, 1
  store { i64, ptr } %t666, ptr %l267, !tbaa !27
  %t667 = icmp sge i64 0, 0
  br i1 %t667, label %bb129, label %bb130
bb128:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb129:
  %t669 = icmp sle i64 0, 1152921504606846975
  br i1 %t669, label %bb131, label %bb132
bb130:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb131:
  %t671 = mul i64 0, 8
  %t672 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t671)
  %t673 = insertvalue { i64, ptr } undef, i64 0, 0
  %t674 = insertvalue { i64, ptr } %t673, ptr %t672, 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t675
  %t676 = getelementptr { i64, [5 x i64] }, ptr %t675, i32 0, i32 0
  store i64 0, ptr %t676
  %t677 = load %"compiler/source:Span", ptr %l263
  %t678 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t677, 0
  %t679 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t680 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t678, { i64, ptr } %t679, 1
  %t682 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t680, { i64, ptr } %t674, 2
  %t683 = getelementptr { i64, [5 x i64] }, ptr %t675, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t682, ptr %t683
  %t684 = load { i64, [5 x i64] }, ptr %t675
  %t686 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t684, ptr %t686
  %t688 = load ptr, ptr %l0, !tbaa !29
  store ptr %t688, ptr %l274, !tbaa !29
  %t689 = load i32, ptr %l1, !tbaa !23
  store i32 %t689, ptr %l275, !tbaa !23
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load i32, ptr %l1, !tbaa !23
  %t696 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t690, i32 %t691, ptr %t686)
  store ptr %t696, ptr %l279
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_fd55a40e832939eb_76ee8367288fff1f)
  unreachable
bb133:
  %t697 = load ptr, ptr %l274, !tbaa !29
  %t698 = load i32, ptr %l275, !tbaa !23
  %t699 = load ptr, ptr %l279, !tbaa !29
  %t700 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t697, i32 %t698, ptr %t699)
  %t701 = extractvalue { i32, ptr } %t700, 1
  %t702 = extractvalue { i32, ptr } %t700, 0
  store i32 %t702, ptr %l281
  %t703 = icmp ne i32 %t702, 0
  br i1 %t703, label %bb135, label %ok.704
ok.704:
  store ptr %t701, ptr %l280
  br label %bb134
bb134:
  %t705 = load ptr, ptr %l280, !tbaa !29
  store ptr %t705, ptr %l273, !tbaa !29
  br label %bb136
bb135:
  %t706 = load i32, ptr %l281, !tbaa !23
  %t707 = lshr i32 %t706, 16
  %t708 = and i32 %t706, 65535
  %t709 = icmp eq i32 %t707, 1
  %t710 = select i1 %t709, i32 1, i32 0
  %t711 = icmp eq i32 %t706, 0
  %t712 = shl i32 %t710, 16
  %t713 = or i32 %t712, %t708
  %t714 = select i1 %t711, i32 0, i32 %t713
  %t716 = insertvalue { i32, ptr } zeroinitializer, i32 %t714, 0
  store { i32, ptr } %t716, ptr %rv
  br label %ret
bb136:
  %t717 = load ptr, ptr %l273, !tbaa !29
  %t718 = insertvalue { i32, ptr } zeroinitializer, ptr %t717, 1
  store { i32, ptr } %t718, ptr %rv
  br label %ret
bb137:
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load i32, ptr %l1, !tbaa !23
  %t723 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t719, i32 %t720)
  store %"compiler/source:Span" %t723, ptr %l285
  br label %bb138
bb138:
  %t724 = load i32, ptr %l16, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t725
  %t726 = getelementptr { i64, [5 x i64] }, ptr %t725, i32 0, i32 0
  store i64 0, ptr %t726
  %t727 = load %"compiler/source:Span", ptr %l285
  %t728 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t727, 0
  %t730 = insertvalue { %"compiler/source:Span", i32 } %t728, i32 %t724, 1
  %t731 = getelementptr { i64, [5 x i64] }, ptr %t725, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t730, ptr %t731
  %t732 = load { i64, [5 x i64] }, ptr %t725
  %t734 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t732, ptr %t734
  %t736 = insertvalue { i32, ptr } zeroinitializer, ptr %t734, 1
  store { i32, ptr } %t736, ptr %rv
  br label %ret
bb139:
  %t737 = load i32, ptr %l15
  %t739 = trunc i64 81 to i32
  %t740 = icmp eq i32 %t737, %t739
  br i1 %t740, label %bb140, label %bb141
bb140:
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t744 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t742, i64 2)
  store i32 %t744, ptr %l292
  br label %bb142
bb141:
  br label %bb171
bb142:
  %t745 = load i32, ptr %l292
  store i32 %t745, ptr %l21
  %t746 = load i32, ptr %l21
  %t748 = trunc i64 90 to i32
  %t749 = icmp eq i32 %t746, %t748
  br i1 %t749, label %bb143, label %bb144
bb143:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb153
bb144:
  %t751 = load i32, ptr %l21
  %t753 = trunc i64 1 to i32
  %t754 = icmp eq i32 %t751, %t753
  br i1 %t754, label %bb145, label %bb146
bb145:
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t758 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t756, i64 3)
  store i32 %t758, ptr %l300
  br label %bb147
bb146:
  store i1 false, ptr %l298, !tbaa !21
  br label %bb148
bb147:
  %t759 = load i32, ptr %l300
  %t761 = trunc i64 90 to i32
  %t762 = icmp eq i32 %t759, %t761
  store i1 %t762, ptr %l298, !tbaa !21
  br label %bb148
bb148:
  %t764 = load i1, ptr %l298, !tbaa !21
  br i1 %t764, label %bb149, label %bb150
bb149:
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t767 = getelementptr %"compiler/parse:Parser", ptr %t765, i32 0, i32 3
  %t768 = load ptr, ptr %t767, !tbaa !29
  %t770 = getelementptr %"compiler/parse:Oracle", ptr %t768, i32 0, i32 0
  %t771 = load i32, ptr %l16, !tbaa !23
  %t774 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t770, i32 %t771)
  store i1 %t774, ptr %l308
  br label %bb151
bb150:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb152
bb151:
  %t775 = load i1, ptr %l308, !tbaa !21
  store i1 %t775, ptr %l303, !tbaa !21
  br label %bb152
bb152:
  %t776 = load i1, ptr %l303, !tbaa !21
  store i1 %t776, ptr %l295, !tbaa !21
  br label %bb153
bb153:
  %t777 = load i1, ptr %l295, !tbaa !21
  br i1 %t777, label %bb154, label %bb155
bb154:
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t780 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t778)
  store i32 %t780, ptr %l310
  br label %bb156
bb155:
  br label %bb170
bb156:
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t782 = load i32, ptr %l1, !tbaa !23
  %t785 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t781, i32 %t782)
  store %"compiler/source:Span" %t785, ptr %l313
  br label %bb157
bb157:
  %t786 = load i32, ptr %l16, !tbaa !23
  store i32 %t786, ptr %l314, !tbaa !23
  %t787 = icmp sge i64 1, 0
  br i1 %t787, label %bb158, label %bb159
bb158:
  %t789 = icmp sle i64 1, 2305843009213693951
  br i1 %t789, label %bb160, label %bb161
bb159:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb160:
  %t791 = mul i64 1, 4
  %t792 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t791)
  %t793 = load i32, ptr %l314, !tbaa !23
  store i64 0, ptr %t794
  br label %fill.795
fill.795:
  %t798 = load i64, ptr %t794
  %t799 = icmp slt i64 %t798, 1
  br i1 %t799, label %fillb.796, label %filld.797
fillb.796:
  %t800 = getelementptr i32, ptr %t792, i64 %t798
  store i32 %t793, ptr %t800
  %t801 = add i64 %t798, 1
  store i64 %t801, ptr %t794
  br label %fill.795
filld.797:
  %t802 = insertvalue { i64, ptr } undef, i64 1, 0
  %t803 = insertvalue { i64, ptr } %t802, ptr %t792, 1
  store { i64, ptr } %t803, ptr %l317, !tbaa !27
  %t804 = icmp sge i64 0, 0
  br i1 %t804, label %bb162, label %bb163
bb161:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb162:
  %t806 = icmp sle i64 0, 1152921504606846975
  br i1 %t806, label %bb164, label %bb165
bb163:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb164:
  %t808 = mul i64 0, 8
  %t809 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t808)
  %t810 = insertvalue { i64, ptr } undef, i64 0, 0
  %t811 = insertvalue { i64, ptr } %t810, ptr %t809, 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t812
  %t813 = getelementptr { i64, [5 x i64] }, ptr %t812, i32 0, i32 0
  store i64 0, ptr %t813
  %t814 = load %"compiler/source:Span", ptr %l313
  %t815 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t814, 0
  %t816 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t817 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t815, { i64, ptr } %t816, 1
  %t819 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t817, { i64, ptr } %t811, 2
  %t820 = getelementptr { i64, [5 x i64] }, ptr %t812, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t819, ptr %t820
  %t821 = load { i64, [5 x i64] }, ptr %t812
  %t823 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t821, ptr %t823
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load i32, ptr %l1, !tbaa !23
  %t831 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t825, i32 %t826, ptr %t823)
  store ptr %t831, ptr %l326
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc)
  unreachable
bb166:
  %t832 = load ptr, ptr %l326, !tbaa !29
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t834 = load i32, ptr %l1, !tbaa !23
  %t839 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t833, i32 %t834, ptr %t832)
  %t840 = extractvalue { i32, ptr } %t839, 1
  %t841 = extractvalue { i32, ptr } %t839, 0
  store i32 %t841, ptr %l332
  %t842 = icmp ne i32 %t841, 0
  br i1 %t842, label %bb168, label %ok.843
ok.843:
  store ptr %t840, ptr %l331
  br label %bb167
bb167:
  %t844 = load ptr, ptr %l331, !tbaa !29
  store ptr %t844, ptr %l327, !tbaa !29
  br label %bb169
bb168:
  %t845 = load i32, ptr %l332, !tbaa !23
  %t846 = lshr i32 %t845, 16
  %t847 = and i32 %t845, 65535
  %t848 = icmp eq i32 %t846, 1
  %t849 = select i1 %t848, i32 1, i32 0
  %t850 = icmp eq i32 %t845, 0
  %t851 = shl i32 %t849, 16
  %t852 = or i32 %t851, %t847
  %t853 = select i1 %t850, i32 0, i32 %t852
  %t855 = insertvalue { i32, ptr } zeroinitializer, i32 %t853, 0
  store { i32, ptr } %t855, ptr %rv
  br label %ret
bb169:
  %t856 = load ptr, ptr %l327, !tbaa !29
  %t857 = insertvalue { i32, ptr } zeroinitializer, ptr %t856, 1
  store { i32, ptr } %t857, ptr %rv
  br label %ret
bb170:
  br label %bb171
bb171:
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t860 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t858)
  store i32 %t860, ptr %l335
  br label %bb172
bb172:
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t862 = load i32, ptr %l1, !tbaa !23
  %t865 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t861, i32 %t862)
  store %"compiler/source:Span" %t865, ptr %l338
  br label %bb173
bb173:
  %t866 = load i32, ptr %l16, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t867
  %t868 = getelementptr { i64, [5 x i64] }, ptr %t867, i32 0, i32 0
  store i64 0, ptr %t868
  %t869 = load %"compiler/source:Span", ptr %l338
  %t870 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t869, 0
  %t872 = insertvalue { %"compiler/source:Span", i32 } %t870, i32 %t866, 1
  %t873 = getelementptr { i64, [5 x i64] }, ptr %t867, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t872, ptr %t873
  %t874 = load { i64, [5 x i64] }, ptr %t867
  %t876 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t874, ptr %t876
  %t878 = insertvalue { i32, ptr } zeroinitializer, ptr %t876, 1
  store { i32, ptr } %t878, ptr %rv
  br label %ret
bb174:
  %t879 = load i32, ptr %l2
  %t881 = trunc i64 90 to i32
  %t882 = icmp eq i32 %t879, %t881
  br i1 %t882, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb181
bb177:
  store %olang.scope zeroinitializer, ptr %s15
  %t884 = load ptr, ptr %l0, !tbaa !29
  %t886 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s15, ptr %t884, { i64, ptr } { i64 44, ptr @.d25 })
  store i32 %t886, ptr %l345
  %t887 = icmp ne i32 %t886, 0
  br i1 %t887, label %bb179, label %ok.888
ok.888:
  br label %bb178
bb178:
  br label %bb180
bb179:
  %t889 = load i32, ptr %l345, !tbaa !23
  %t890 = lshr i32 %t889, 16
  %t891 = and i32 %t889, 65535
  %t892 = icmp eq i32 %t890, 1
  %t893 = select i1 %t892, i32 1, i32 0
  %t894 = icmp eq i32 %t889, 0
  %t895 = shl i32 %t893, 16
  %t896 = or i32 %t895, %t891
  %t897 = select i1 %t894, i32 0, i32 %t896
  call void @__olang_scope_close(ptr %s15)
  %t899 = insertvalue { i32, ptr } zeroinitializer, i32 %t897, 0
  store { i32, ptr } %t899, ptr %rv
  br label %ret
bb180:
  call void @__olang_scope_close(ptr %s15)
  br label %bb185
bb181:
  store %olang.scope zeroinitializer, ptr %s16
  %t900 = load ptr, ptr %l0, !tbaa !29
  %t902 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s16, ptr %t900, { i64, ptr } { i64 13, ptr @.d26 })
  store i32 %t902, ptr %l348
  %t903 = icmp ne i32 %t902, 0
  br i1 %t903, label %bb183, label %ok.904
ok.904:
  br label %bb182
bb182:
  br label %bb184
bb183:
  %t905 = load i32, ptr %l348, !tbaa !23
  %t906 = lshr i32 %t905, 16
  %t907 = and i32 %t905, 65535
  %t908 = icmp eq i32 %t906, 1
  %t909 = select i1 %t908, i32 1, i32 0
  %t910 = icmp eq i32 %t905, 0
  %t911 = shl i32 %t909, 16
  %t912 = or i32 %t911, %t907
  %t913 = select i1 %t910, i32 0, i32 %t912
  call void @__olang_scope_close(ptr %s16)
  %t915 = insertvalue { i32, ptr } zeroinitializer, i32 %t913, 0
  store { i32, ptr } %t915, ptr %rv
  br label %ret
bb184:
  call void @__olang_scope_close(ptr %s16)
  br label %bb185
bb185:
  call void @__olang_check_failed(ptr @olang_loc_c608f7f9cf1bb136_7782a31fde86d192)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/msgs:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l14 = alloca i64
  %l18 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i64
  %t15 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 4
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 5
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i32, ptr %l1, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t14 = sext i32 %a2 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 0
  store i64 3, ptr %t16
  %t18 = insertvalue { i64, i64, i64 } undef, i64 %t8, 0
  %t20 = insertvalue { i64, i64, i64 } %t18, i64 %t11, 1
  %t22 = insertvalue { i64, i64, i64 } %t20, i64 %t14, 2
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  store { i64, i64, i64 } %t22, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t15
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t4, { i64, [3 x i64] } %t24, %"compiler/msgs:Msg" %a3)
  store i64 %t29, ptr %l14
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 26
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eHas_3cI32_2c_20I64_3e(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l18
  br label %bb2
bb2:
  %t37 = load i1, ptr %l18, !tbaa !21
  %t38 = xor i1 %t37, true
  br i1 %t38, label %bb3, label %bb4
bb3:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 26
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  store i32 %t43, ptr %l22, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 24
  %t48 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l25
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = sub i64 %t49, 1
  %t51 = load ptr, ptr %l21, !tbaa !29
  %t52 = load i32, ptr %l22, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %t51, i32 %t52, i64 %t50)
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2escopeDecl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca %"compiler/token:Token"
  %l7 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l14 = alloca %"compiler/token:Token"
  %l16 = alloca i1
  %l18 = alloca %"compiler/token:Token"
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l31 = alloca %"compiler/token:Token"
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i32
  %l39 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t11, i32 81)
  store i1 %t14, ptr %l10
  br label %bb3
bb3:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb9
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t19)
  store %"compiler/token:Token" %t21, ptr %l14
  br label %bb7
bb7:
  %t22 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t23 = load %"compiler/token:Token", ptr %l14
  %t25 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t23, i8 %t22)
  store i1 %t25, ptr %l16
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t28, i64 1)
  store %"compiler/token:Token" %t30, ptr %l18
  br label %bb13
bb13:
  %t31 = load %"compiler/token:Token", ptr %l18
  store %"compiler/token:Token" %t31, ptr %l1
  %t32 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t33 = load i32, ptr %t32
  %t35 = trunc i64 1 to i32
  %t36 = icmp eq i32 %t33, %t35
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb14, label %bb15
bb14:
  %t40 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t43 = trunc i64 14 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l22, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb20
bb18:
  %t49 = load %"compiler/token:Token", ptr %l1
  %t50 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t53 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t49, i8 %t50)
  store i1 %t53, ptr %l29
  br label %bb19
bb19:
  %t54 = load i1, ptr %l29, !tbaa !21
  store i1 %t54, ptr %l26, !tbaa !21
  br label %bb20
bb20:
  %t55 = load i1, ptr %l26, !tbaa !21
  br i1 %t55, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t56)
  store %"compiler/token:Token" %t58, ptr %l31
  br label %bb24
bb24:
  %t59 = load %"compiler/token:Token", ptr %l31
  store %"compiler/token:Token" %t59, ptr %l2
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  store i32 %t62, ptr %l33, !tbaa !23
  %t63 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l34, !tbaa !23
  %t65 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeDecl(ptr %s0)
  store %"compiler/msgs:Msg" %t65, ptr %l35
  br label %bb25
bb25:
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load i32, ptr %l33, !tbaa !23
  %t68 = load i32, ptr %l34, !tbaa !23
  %t69 = load %"compiler/msgs:Msg", ptr %l35
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s0, ptr %t66, i32 %t67, i32 %t68, %"compiler/msgs:Msg" %t69)
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t70)
  store i32 %t72, ptr %l37
  br label %bb27
bb27:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l39
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  store i32 %a1, ptr %l5
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l3, ptr %l5)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i32
  %l12 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 55)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etrailing(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l8
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  br label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb6
bb5:
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, i1 } zeroinitializer, i32 %t21, 0
  store { i32, i1 } %t23, ptr %rv
  br label %ret
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l12
  br label %bb7
bb7:
  %t29 = load i1, ptr %l12, !tbaa !21
  %t30 = xor i1 %t29, true
  %t32 = insertvalue { i32, i1 } zeroinitializer, i1 %t30, 1
  store { i32, i1 } %t32, ptr %rv
  br label %ret
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t33, i32 8)
  store i1 %t36, ptr %l16
  br label %bb9
bb9:
  %t37 = load i1, ptr %l16, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t38)
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l1
  %t44 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l20
  br label %bb13
bb13:
  %t45 = load i1, ptr %l20, !tbaa !21
  %t46 = xor i1 %t45, true
  %t48 = insertvalue { i32, i1 } zeroinitializer, i1 %t46, 1
  store { i32, i1 } %t48, ptr %rv
  br label %ret
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t49, i32 0, i32 9
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l2
  %t54 = load i32, ptr %l2
  %t56 = trunc i64 93 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  %t59 = load i32, ptr %l2
  %t61 = trunc i64 79 to i32
  %t62 = icmp eq i32 %t59, %t61
  store i1 %t62, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t64 = load i1, ptr %l26, !tbaa !21
  br i1 %t64, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  %t65 = load i32, ptr %l2
  %t67 = trunc i64 81 to i32
  %t68 = icmp eq i32 %t65, %t67
  store i1 %t68, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l29, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t71)
  store i1 %t73, ptr %l34
  br label %bb23
bb22:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb24
bb23:
  %t74 = load i1, ptr %l34, !tbaa !21
  store i1 %t74, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t75 = load i1, ptr %l32, !tbaa !21
  br i1 %t75, label %bb25, label %bb26
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l1
  %t80 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l37
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t81 = load i1, ptr %l37, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t84, i32 0)
  store i1 %t87, ptr %l42
  br label %bb30
bb29:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb31
bb30:
  %t88 = load i1, ptr %l42, !tbaa !21
  %t89 = xor i1 %t88, true
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb31
bb31:
  %t91 = load i1, ptr %l39, !tbaa !21
  %t92 = insertvalue { i32, i1 } zeroinitializer, i1 %t91, 1
  store { i32, i1 } %t92, ptr %rv
  br label %ret
bb32:
  %t94 = insertvalue { i32, i1 } zeroinitializer, i1 false, 1
  store { i32, i1 } %t94, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t64 = alloca { i64, [5 x i64] }, align 8
  %t86 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store ptr %t8, ptr %l9
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l7, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t25)
  store i32 %t27, ptr %l13
  br label %bb5
bb5:
  %t28 = load i32, ptr %l13
  store i32 %t28, ptr %l3
  %t29 = load i32, ptr %l3
  %t31 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t29)
  store i1 %t31, ptr %l15
  br label %bb6
bb6:
  %t32 = load i1, ptr %l15, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t33)
  store i32 %t35, ptr %l17
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t36)
  %t39 = extractvalue { i32, ptr } %t38, 1
  %t40 = extractvalue { i32, ptr } %t38, 0
  store i32 %t40, ptr %l21
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb11, label %ok.42
ok.42:
  store ptr %t39, ptr %l20
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l20, !tbaa !29
  store ptr %t43, ptr %l18, !tbaa !29
  br label %bb12
bb11:
  %t44 = load i32, ptr %l21, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t54 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t54, ptr %rv
  br label %ret
bb12:
  %t55 = load ptr, ptr %l18, !tbaa !29
  store ptr %t55, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t60 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t56, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l25
  br label %bb13
bb13:
  %t61 = load i32, ptr %l3
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 0
  store i64 3, ptr %t65
  %t66 = load %"compiler/source:Span", ptr %l25
  %t67 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t66, 0
  %t69 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t67, i32 %t61, 1
  %t71 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t69, ptr %t62, 2
  %t73 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t71, ptr %t63, 3
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t73, ptr %t74
  %t75 = load { i64, [5 x i64] }, ptr %t64
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t75, ptr %t77
  %t79 = insertvalue { i32, ptr } zeroinitializer, ptr %t77, 1
  store { i32, ptr } %t79, ptr %rv
  br label %ret
bb14:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t80, i32 %t81)
  store %"compiler/source:Span" %t84, ptr %l33
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l2, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 0
  store i64 0, ptr %t87
  %t88 = load %"compiler/source:Span", ptr %l33
  %t89 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t88, 0
  %t91 = insertvalue { %"compiler/source:Span", ptr } %t89, ptr %t85, 1
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t91, ptr %t92
  %t93 = load { i64, [5 x i64] }, ptr %t86
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t93, ptr %t95
  %t97 = insertvalue { i32, ptr } zeroinitializer, ptr %t95, 1
  store { i32, ptr } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 1 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 39 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 37 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb9:
  %t22 = load i32, ptr %l1
  %t24 = trunc i64 88 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i32, ptr %l1
  %t30 = trunc i64 35 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i32, ptr %l1
  %t36 = trunc i64 34 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb19
bb18:
  %t40 = load i32, ptr %l1
  %t42 = trunc i64 36 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb19
bb19:
  %t45 = load i1, ptr %l21, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %lp23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i32
  %l45 = alloca i32
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i32
  %l64 = alloca i32
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l70 = alloca i32
  %l73 = alloca i32
  %l74 = alloca i32
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca i32
  %l83 = alloca %"compiler/source:Span"
  %l85 = alloca i32
  %l94 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i32
  %l101 = alloca %"compiler/source:Span"
  %l104 = alloca i1
  %l106 = alloca i32
  %l114 = alloca i32
  %l119 = alloca i1
  %l121 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i32
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l146 = alloca i32
  %l148 = alloca i32
  %l151 = alloca i1
  %l153 = alloca i1
  %l155 = alloca ptr
  %l157 = alloca ptr
  %l158 = alloca i32
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l175 = alloca i32
  %l176 = alloca ptr
  %l178 = alloca ptr
  %l179 = alloca i32
  %l183 = alloca i1
  %l184 = alloca ptr
  %l186 = alloca ptr
  %l187 = alloca i32
  %l192 = alloca %"compiler/source:Span"
  %l194 = alloca i32
  %l204 = alloca i32
  %l205 = alloca ptr
  %l207 = alloca ptr
  %l208 = alloca i32
  %l212 = alloca %"compiler/source:Span"
  %l214 = alloca i32
  %l224 = alloca i32
  %l227 = alloca i64
  %l229 = alloca ptr
  %l230 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca i32
  %l237 = alloca i1
  %l241 = alloca i1
  %l245 = alloca { i64, ptr }
  %l249 = alloca ptr
  %l251 = alloca i32
  %l252 = alloca ptr
  %l254 = alloca ptr
  %l255 = alloca i32
  %l259 = alloca %"compiler/source:Span"
  %l261 = alloca i32
  %l270 = alloca i64
  %l277 = alloca ptr
  %l279 = alloca { i64, ptr }
  %l281 = alloca i32
  %l286 = alloca ptr
  %l292 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l296 = alloca %"compiler/source:Span"
  %l305 = alloca ptr
  %l307 = alloca ptr
  %l308 = alloca i32
  %l312 = alloca %"compiler/source:Span"
  %l319 = alloca i32
  %l322 = alloca i1
  %l323 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l326 = alloca i32
  %l330 = alloca %"compiler/source:Span"
  %l333 = alloca i1
  %l335 = alloca i32
  %l343 = alloca ptr
  %l345 = alloca ptr
  %l346 = alloca i32
  %l350 = alloca %"compiler/source:Span"
  %l356 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l359 = alloca i32
  %l363 = alloca %"compiler/source:Span"
  %l366 = alloca i1
  %l368 = alloca i32
  %l377 = alloca ptr
  %l379 = alloca ptr
  %l380 = alloca i32
  %l384 = alloca ptr
  %l386 = alloca ptr
  %l387 = alloca i32
  %l389 = alloca ptr
  %l391 = alloca ptr
  %l392 = alloca i32
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t189 = alloca { i64, [5 x i64] }, align 8
  %t244 = alloca { i64, [5 x i64] }, align 8
  %t330 = alloca { i64, [5 x i64] }, align 8
  %t422 = alloca { i64, [5 x i64] }, align 8
  %t515 = alloca { i64, [5 x i64] }, align 8
  %t582 = alloca { i64, [5 x i64] }, align 8
  %t710 = alloca { i64, [5 x i64] }, align 8
  %t817 = alloca { i64, [5 x i64] }, align 8
  %t862 = alloca { i64, [5 x i64] }, align 8
  %t924 = alloca { i64, [5 x i64] }, align 8
  %t934 = alloca { i64, [5 x i64] }, align 8
  %t972 = alloca { i64, [5 x i64] }, align 8
  %t1025 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l32
  br label %bb1
bb1:
  %t4 = load i32, ptr %l32, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 12
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %t10)
  store i1 %t12, ptr %l37
  br label %bb4
bb3:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i1, ptr %l37, !tbaa !21
  store i1 %t13, ptr %l35, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l35, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efieldDecl(ptr %v0, ptr %t15)
  %t18 = extractvalue { i32, ptr } %t17, 1
  %t19 = extractvalue { i32, ptr } %t17, 0
  store i32 %t19, ptr %l41
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb9, label %ok.21
ok.21:
  store ptr %t18, ptr %l40
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t22 = load ptr, ptr %l40, !tbaa !29
  store ptr %t22, ptr %l38, !tbaa !29
  br label %bb10
bb9:
  %t23 = load i32, ptr %l41, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  %t33 = insertvalue { i32, ptr } zeroinitializer, i32 %t31, 0
  store { i32, ptr } %t33, ptr %rv
  br label %ret
bb10:
  %t34 = load ptr, ptr %l38, !tbaa !29
  %t35 = insertvalue { i32, ptr } zeroinitializer, ptr %t34, 1
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %t36)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l45
  br label %bb13
bb13:
  %t41 = load i32, ptr %l45
  store i32 %t41, ptr %l2
  %t42 = load i32, ptr %l2
  %t44 = trunc i64 9 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %t47)
  %t50 = extractvalue { i32, ptr } %t49, 1
  %t51 = extractvalue { i32, ptr } %t49, 0
  store i32 %t51, ptr %l51
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb18, label %ok.53
ok.53:
  store ptr %t50, ptr %l50
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l50, !tbaa !29
  store ptr %t54, ptr %l48, !tbaa !29
  br label %bb19
bb18:
  %t55 = load i32, ptr %l51, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  %t65 = insertvalue { i32, ptr } zeroinitializer, i32 %t63, 0
  store { i32, ptr } %t65, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l48, !tbaa !29
  %t69 = insertvalue { i32, ptr } zeroinitializer, ptr %t66, 1
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb20:
  %t70 = load i32, ptr %l2
  %t72 = trunc i64 24 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %t75)
  %t78 = extractvalue { i32, ptr } %t77, 1
  %t79 = extractvalue { i32, ptr } %t77, 0
  store i32 %t79, ptr %l59
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb25, label %ok.81
ok.81:
  store ptr %t78, ptr %l58
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l58, !tbaa !29
  store ptr %t82, ptr %l56, !tbaa !29
  br label %bb26
bb25:
  %t83 = load i32, ptr %l59, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  %t93 = insertvalue { i32, ptr } zeroinitializer, i32 %t91, 0
  store { i32, ptr } %t93, ptr %rv
  br label %ret
bb26:
  %t94 = load ptr, ptr %l56, !tbaa !29
  %t95 = insertvalue { i32, ptr } zeroinitializer, ptr %t94, 1
  store { i32, ptr } %t95, ptr %rv
  br label %ret
bb27:
  %t96 = load i32, ptr %l2
  %t98 = trunc i64 25 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb45
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l64
  br label %bb31
bb31:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t104)
  %t107 = extractvalue { i32, { i64, ptr } } %t106, 1
  %t108 = extractvalue { i32, { i64, ptr } } %t106, 0
  store i32 %t108, ptr %l68
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb33, label %ok.110
ok.110:
  store { i64, ptr } %t107, ptr %l67
  br label %bb32
bb32:
  %t111 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t111, ptr %l65, !tbaa !27
  br label %bb34
bb33:
  %t112 = load i32, ptr %l68, !tbaa !23
  %t113 = lshr i32 %t112, 16
  %t114 = and i32 %t112, 65535
  %t115 = icmp eq i32 %t113, 1
  %t116 = select i1 %t115, i32 1, i32 0
  %t117 = icmp eq i32 %t112, 0
  %t118 = shl i32 %t116, 16
  %t119 = or i32 %t118, %t114
  %t120 = select i1 %t117, i32 0, i32 %t119
  %t122 = insertvalue { i32, ptr } zeroinitializer, i32 %t120, 0
  store { i32, ptr } %t122, ptr %rv
  br label %ret
bb34:
  %t123 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t123, ptr %l4, !tbaa !27
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t127 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t124, i32 24)
  %t128 = extractvalue { i32, i32 } %t127, 1
  %t129 = extractvalue { i32, i32 } %t127, 0
  store i32 %t129, ptr %l74
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb36, label %ok.131
ok.131:
  store i32 %t128, ptr %l73
  br label %bb35
bb35:
  %t132 = load i32, ptr %l73, !tbaa !23
  store i32 %t132, ptr %l70, !tbaa !23
  br label %bb37
bb36:
  %t133 = load i32, ptr %l74, !tbaa !23
  %t134 = lshr i32 %t133, 16
  %t135 = and i32 %t133, 65535
  %t136 = icmp eq i32 %t134, 1
  %t137 = select i1 %t136, i32 1, i32 0
  %t138 = icmp eq i32 %t133, 0
  %t139 = shl i32 %t137, 16
  %t140 = or i32 %t139, %t135
  %t141 = select i1 %t138, i32 0, i32 %t140
  %t143 = insertvalue { i32, ptr } zeroinitializer, i32 %t141, 0
  store { i32, ptr } %t143, ptr %rv
  br label %ret
bb37:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t144)
  %t147 = extractvalue { i32, ptr } %t146, 1
  %t148 = extractvalue { i32, ptr } %t146, 0
  store i32 %t148, ptr %l79
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb39, label %ok.150
ok.150:
  store ptr %t147, ptr %l78
  br label %bb38
bb38:
  %t151 = load ptr, ptr %l78, !tbaa !29
  store ptr %t151, ptr %l76, !tbaa !29
  br label %bb40
bb39:
  %t152 = load i32, ptr %l79, !tbaa !23
  %t153 = lshr i32 %t152, 16
  %t154 = and i32 %t152, 65535
  %t155 = icmp eq i32 %t153, 1
  %t156 = select i1 %t155, i32 1, i32 0
  %t157 = icmp eq i32 %t152, 0
  %t158 = shl i32 %t156, 16
  %t159 = or i32 %t158, %t154
  %t160 = select i1 %t157, i32 0, i32 %t159
  %t162 = insertvalue { i32, ptr } zeroinitializer, i32 %t160, 0
  store { i32, ptr } %t162, ptr %rv
  br label %ret
bb40:
  %t163 = load ptr, ptr %l76, !tbaa !29
  store ptr %t163, ptr %l5, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l1, !tbaa !23
  %t168 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t164, i32 %t165)
  store %"compiler/source:Span" %t168, ptr %l83
  br label %bb41
bb41:
  %t169 = load %"compiler/source:Span", ptr %l83
  store %"compiler/source:Span" %t169, ptr %l6
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t170)
  store i32 %t172, ptr %l85
  %t173 = icmp ne i32 %t172, 0
  br i1 %t173, label %bb43, label %ok.174
ok.174:
  br label %bb42
bb42:
  br label %bb44
bb43:
  %t175 = load i32, ptr %l85, !tbaa !23
  %t176 = lshr i32 %t175, 16
  %t177 = and i32 %t175, 65535
  %t178 = icmp eq i32 %t176, 1
  %t179 = select i1 %t178, i32 1, i32 0
  %t180 = icmp eq i32 %t175, 0
  %t181 = shl i32 %t179, 16
  %t182 = or i32 %t181, %t177
  %t183 = select i1 %t180, i32 0, i32 %t182
  %t185 = insertvalue { i32, ptr } zeroinitializer, i32 %t183, 0
  store { i32, ptr } %t185, ptr %rv
  br label %ret
bb44:
  %t186 = load %"compiler/source:Span", ptr %l6
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 0
  store i64 10, ptr %t190
  %t192 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t186, 0
  %t194 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t192, { i64, ptr } %t187, 1
  %t196 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t194, ptr %t188, 2
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t196, ptr %t197
  %t198 = load { i64, [5 x i64] }, ptr %t189
  %t200 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t198, ptr %t200
  %t202 = insertvalue { i32, ptr } zeroinitializer, ptr %t200, 1
  store { i32, ptr } %t202, ptr %rv
  br label %ret
bb45:
  %t203 = load i32, ptr %l2
  %t205 = trunc i64 30 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb58
bb48:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %t208)
  %t211 = extractvalue { i32, ptr } %t210, 1
  %t212 = extractvalue { i32, ptr } %t210, 0
  store i32 %t212, ptr %l97
  %t213 = icmp ne i32 %t212, 0
  br i1 %t213, label %bb50, label %ok.214
ok.214:
  store ptr %t211, ptr %l96
  br label %bb49
bb49:
  %t215 = load ptr, ptr %l96, !tbaa !29
  store ptr %t215, ptr %l94, !tbaa !29
  br label %bb51
bb50:
  %t216 = load i32, ptr %l97, !tbaa !23
  %t217 = lshr i32 %t216, 16
  %t218 = and i32 %t216, 65535
  %t219 = icmp eq i32 %t217, 1
  %t220 = select i1 %t219, i32 1, i32 0
  %t221 = icmp eq i32 %t216, 0
  %t222 = shl i32 %t220, 16
  %t223 = or i32 %t222, %t218
  %t224 = select i1 %t221, i32 0, i32 %t223
  %t226 = insertvalue { i32, ptr } zeroinitializer, i32 %t224, 0
  store { i32, ptr } %t226, ptr %rv
  br label %ret
bb51:
  %t227 = load ptr, ptr %l94, !tbaa !29
  store ptr %t227, ptr %l7, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i32, ptr %l1, !tbaa !23
  %t232 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t228, i32 %t229)
  store %"compiler/source:Span" %t232, ptr %l101
  br label %bb52
bb52:
  %t233 = load %"compiler/source:Span", ptr %l101
  store %"compiler/source:Span" %t233, ptr %l8
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t237 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t234, i32 8)
  store i1 %t237, ptr %l104
  br label %bb53
bb53:
  %t238 = load i1, ptr %l104, !tbaa !21
  br i1 %t238, label %bb54, label %bb55
bb54:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t239)
  store i32 %t241, ptr %l106
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t242 = load %"compiler/source:Span", ptr %l8
  %t243 = load ptr, ptr %l7, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t244
  %t245 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 0
  store i64 11, ptr %t245
  %t247 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t242, 0
  %t249 = insertvalue { %"compiler/source:Span", ptr } %t247, ptr %t243, 1
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t249, ptr %t250
  %t251 = load { i64, [5 x i64] }, ptr %t244
  %t253 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t251, ptr %t253
  %t255 = insertvalue { i32, ptr } zeroinitializer, ptr %t253, 1
  store { i32, ptr } %t255, ptr %rv
  br label %ret
bb58:
  %t256 = load i32, ptr %l2
  %t258 = trunc i64 14 to i32
  %t259 = icmp eq i32 %t256, %t258
  br i1 %t259, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb79
bb61:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t261)
  store i32 %t263, ptr %l114
  br label %bb62
bb62:
  %t264 = icmp sge i64 0, 0
  br i1 %t264, label %bb63, label %bb64
bb63:
  %t266 = icmp sle i64 0, 1152921504606846975
  br i1 %t266, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_405430454c9e5d04_720bbb7e3dc9fd0)
  unreachable
bb65:
  %t268 = mul i64 0, 8
  %t269 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t268)
  %t270 = insertvalue { i64, ptr } undef, i64 0, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l9, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %t273)
  store i1 %t275, ptr %l119
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_405430454c9e5d04_720bbb7e3dc9fd0)
  unreachable
bb67:
  %t276 = load i1, ptr %l119, !tbaa !21
  %t277 = xor i1 %t276, true
  br i1 %t277, label %bb68, label %bb69
bb68:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l121, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l123
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t283 = load i32, ptr %l123, !tbaa !23
  %t284 = load ptr, ptr %l121, !tbaa !29
  %t285 = getelementptr %"compiler/parse:Parser", ptr %t284, i32 0, i32 23
  store i32 %t283, ptr %t285, !tbaa !23
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %t286)
  %t289 = extractvalue { i32, { i64, ptr } } %t288, 1
  %t290 = extractvalue { i32, { i64, ptr } } %t288, 0
  store i32 %t290, ptr %l127
  %t291 = icmp ne i32 %t290, 0
  br i1 %t291, label %bb72, label %ok.292
ok.292:
  store { i64, ptr } %t289, ptr %l126
  br label %bb71
bb71:
  %t293 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t293, ptr %l124, !tbaa !27
  br label %bb73
bb72:
  %t294 = load i32, ptr %l127, !tbaa !23
  %t295 = lshr i32 %t294, 16
  %t296 = and i32 %t294, 65535
  %t297 = icmp eq i32 %t295, 1
  %t298 = select i1 %t297, i32 1, i32 0
  %t299 = icmp eq i32 %t294, 0
  %t300 = shl i32 %t298, 16
  %t301 = or i32 %t300, %t296
  %t302 = select i1 %t299, i32 0, i32 %t301
  %t304 = insertvalue { i32, ptr } zeroinitializer, i32 %t302, 0
  store { i32, ptr } %t304, ptr %rv
  br label %ret
bb73:
  %t305 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t305, ptr %l9, !tbaa !27
  br label %bb74
bb74:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load i32, ptr %l1, !tbaa !23
  %t310 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t306, i32 %t307)
  store %"compiler/source:Span" %t310, ptr %l131
  br label %bb75
bb75:
  %t311 = load %"compiler/source:Span", ptr %l131
  store %"compiler/source:Span" %t311, ptr %l10
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t312)
  store i32 %t314, ptr %l133
  %t315 = icmp ne i32 %t314, 0
  br i1 %t315, label %bb77, label %ok.316
ok.316:
  br label %bb76
bb76:
  br label %bb78
bb77:
  %t317 = load i32, ptr %l133, !tbaa !23
  %t318 = lshr i32 %t317, 16
  %t319 = and i32 %t317, 65535
  %t320 = icmp eq i32 %t318, 1
  %t321 = select i1 %t320, i32 1, i32 0
  %t322 = icmp eq i32 %t317, 0
  %t323 = shl i32 %t321, 16
  %t324 = or i32 %t323, %t319
  %t325 = select i1 %t322, i32 0, i32 %t324
  %t327 = insertvalue { i32, ptr } zeroinitializer, i32 %t325, 0
  store { i32, ptr } %t327, ptr %rv
  br label %ret
bb78:
  %t328 = load %"compiler/source:Span", ptr %l10
  %t329 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t330
  %t331 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 0
  store i64 12, ptr %t331
  %t333 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t328, 0
  %t335 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t333, { i64, ptr } %t329, 1
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t335, ptr %t336
  %t337 = load { i64, [5 x i64] }, ptr %t330
  %t339 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t337, ptr %t339
  %t341 = insertvalue { i32, ptr } zeroinitializer, ptr %t339, 1
  store { i32, ptr } %t341, ptr %rv
  br label %ret
bb79:
  %t342 = load i32, ptr %l2
  %t344 = trunc i64 18 to i32
  %t345 = icmp eq i32 %t342, %t344
  br i1 %t345, label %bb80, label %bb81
bb80:
  br label %bb86
bb81:
  %t347 = load i32, ptr %l2
  %t349 = trunc i64 19 to i32
  %t350 = icmp eq i32 %t347, %t349
  br i1 %t350, label %bb82, label %bb83
bb82:
  br label %bb86
bb83:
  %t352 = load i32, ptr %l2
  %t354 = trunc i64 20 to i32
  %t355 = icmp eq i32 %t352, %t354
  br i1 %t355, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb103
bb86:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t357)
  store i32 %t359, ptr %l146
  br label %bb87
bb87:
  %t360 = load i32, ptr %l146
  store i32 %t360, ptr %l11
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t361)
  store i32 %t363, ptr %l148
  br label %bb88
bb88:
  store ptr null, ptr %l12, !tbaa !29
  %t364 = load i32, ptr %l11
  %t366 = trunc i64 20 to i32
  %t367 = icmp eq i32 %t364, %t366
  br i1 %t367, label %bb89, label %bb90
bb89:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eatEnd(ptr %v0, ptr %t369)
  store i1 %t371, ptr %l153
  br label %bb91
bb90:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb92
bb91:
  %t372 = load i1, ptr %l153, !tbaa !21
  %t373 = xor i1 %t372, true
  store i1 %t373, ptr %l151, !tbaa !21
  br label %bb92
bb92:
  %t375 = load i1, ptr %l151, !tbaa !21
  br i1 %t375, label %bb93, label %bb94
bb93:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t376)
  %t379 = extractvalue { i32, ptr } %t378, 1
  %t380 = extractvalue { i32, ptr } %t378, 0
  store i32 %t380, ptr %l158
  %t381 = icmp ne i32 %t380, 0
  br i1 %t381, label %bb96, label %ok.382
ok.382:
  store ptr %t379, ptr %l157
  br label %bb95
bb94:
  br label %bb98
bb95:
  %t383 = load ptr, ptr %l157, !tbaa !29
  store ptr %t383, ptr %l155, !tbaa !29
  br label %bb97
bb96:
  %t384 = load i32, ptr %l158, !tbaa !23
  %t385 = lshr i32 %t384, 16
  %t386 = and i32 %t384, 65535
  %t387 = icmp eq i32 %t385, 1
  %t388 = select i1 %t387, i32 1, i32 0
  %t389 = icmp eq i32 %t384, 0
  %t390 = shl i32 %t388, 16
  %t391 = or i32 %t390, %t386
  %t392 = select i1 %t389, i32 0, i32 %t391
  %t394 = insertvalue { i32, ptr } zeroinitializer, i32 %t392, 0
  store { i32, ptr } %t394, ptr %rv
  br label %ret
bb97:
  %t395 = load ptr, ptr %l155, !tbaa !29
  store ptr %t395, ptr %l12, !tbaa !29
  br label %bb98
bb98:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i32, ptr %l1, !tbaa !23
  %t401 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t397, i32 %t398)
  store %"compiler/source:Span" %t401, ptr %l163
  br label %bb99
bb99:
  %t402 = load %"compiler/source:Span", ptr %l163
  store %"compiler/source:Span" %t402, ptr %l13
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t403)
  store i32 %t405, ptr %l165
  %t406 = icmp ne i32 %t405, 0
  br i1 %t406, label %bb101, label %ok.407
ok.407:
  br label %bb100
bb100:
  br label %bb102
bb101:
  %t408 = load i32, ptr %l165, !tbaa !23
  %t409 = lshr i32 %t408, 16
  %t410 = and i32 %t408, 65535
  %t411 = icmp eq i32 %t409, 1
  %t412 = select i1 %t411, i32 1, i32 0
  %t413 = icmp eq i32 %t408, 0
  %t414 = shl i32 %t412, 16
  %t415 = or i32 %t414, %t410
  %t416 = select i1 %t413, i32 0, i32 %t415
  %t418 = insertvalue { i32, ptr } zeroinitializer, i32 %t416, 0
  store { i32, ptr } %t418, ptr %rv
  br label %ret
bb102:
  %t419 = load %"compiler/source:Span", ptr %l13
  %t420 = load i32, ptr %l11
  %t421 = load ptr, ptr %l12, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t422
  %t423 = getelementptr { i64, [5 x i64] }, ptr %t422, i32 0, i32 0
  store i64 13, ptr %t423
  %t425 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t419, 0
  %t427 = insertvalue { %"compiler/source:Span", i32, ptr } %t425, i32 %t420, 1
  %t429 = insertvalue { %"compiler/source:Span", i32, ptr } %t427, ptr %t421, 2
  %t430 = getelementptr { i64, [5 x i64] }, ptr %t422, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t429, ptr %t430
  %t431 = load { i64, [5 x i64] }, ptr %t422
  %t433 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t431, ptr %t433
  %t435 = insertvalue { i32, ptr } zeroinitializer, ptr %t433, 1
  store { i32, ptr } %t435, ptr %rv
  br label %ret
bb103:
  %t436 = load i32, ptr %l2
  %t438 = trunc i64 23 to i32
  %t439 = icmp eq i32 %t436, %t438
  br i1 %t439, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb122
bb106:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t441)
  store i32 %t443, ptr %l175
  br label %bb107
bb107:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t444)
  %t447 = extractvalue { i32, ptr } %t446, 1
  %t448 = extractvalue { i32, ptr } %t446, 0
  store i32 %t448, ptr %l179
  %t449 = icmp ne i32 %t448, 0
  br i1 %t449, label %bb109, label %ok.450
ok.450:
  store ptr %t447, ptr %l178
  br label %bb108
bb108:
  %t451 = load ptr, ptr %l178, !tbaa !29
  store ptr %t451, ptr %l176, !tbaa !29
  br label %bb110
bb109:
  %t452 = load i32, ptr %l179, !tbaa !23
  %t453 = lshr i32 %t452, 16
  %t454 = and i32 %t452, 65535
  %t455 = icmp eq i32 %t453, 1
  %t456 = select i1 %t455, i32 1, i32 0
  %t457 = icmp eq i32 %t452, 0
  %t458 = shl i32 %t456, 16
  %t459 = or i32 %t458, %t454
  %t460 = select i1 %t457, i32 0, i32 %t459
  %t462 = insertvalue { i32, ptr } zeroinitializer, i32 %t460, 0
  store { i32, ptr } %t462, ptr %rv
  br label %ret
bb110:
  %t463 = load ptr, ptr %l176, !tbaa !29
  store ptr %t463, ptr %l14, !tbaa !29
  store ptr null, ptr %l15, !tbaa !29
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t467 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t464, i32 55)
  store i1 %t467, ptr %l183
  br label %bb111
bb111:
  %t468 = load i1, ptr %l183, !tbaa !21
  br i1 %t468, label %bb112, label %bb113
bb112:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t469)
  %t472 = extractvalue { i32, ptr } %t471, 1
  %t473 = extractvalue { i32, ptr } %t471, 0
  store i32 %t473, ptr %l187
  %t474 = icmp ne i32 %t473, 0
  br i1 %t474, label %bb115, label %ok.475
ok.475:
  store ptr %t472, ptr %l186
  br label %bb114
bb113:
  br label %bb117
bb114:
  %t476 = load ptr, ptr %l186, !tbaa !29
  store ptr %t476, ptr %l184, !tbaa !29
  br label %bb116
bb115:
  %t477 = load i32, ptr %l187, !tbaa !23
  %t478 = lshr i32 %t477, 16
  %t479 = and i32 %t477, 65535
  %t480 = icmp eq i32 %t478, 1
  %t481 = select i1 %t480, i32 1, i32 0
  %t482 = icmp eq i32 %t477, 0
  %t483 = shl i32 %t481, 16
  %t484 = or i32 %t483, %t479
  %t485 = select i1 %t482, i32 0, i32 %t484
  %t487 = insertvalue { i32, ptr } zeroinitializer, i32 %t485, 0
  store { i32, ptr } %t487, ptr %rv
  br label %ret
bb116:
  %t488 = load ptr, ptr %l184, !tbaa !29
  store ptr %t488, ptr %l15, !tbaa !29
  br label %bb117
bb117:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load i32, ptr %l1, !tbaa !23
  %t494 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t490, i32 %t491)
  store %"compiler/source:Span" %t494, ptr %l192
  br label %bb118
bb118:
  %t495 = load %"compiler/source:Span", ptr %l192
  store %"compiler/source:Span" %t495, ptr %l16
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t496)
  store i32 %t498, ptr %l194
  %t499 = icmp ne i32 %t498, 0
  br i1 %t499, label %bb120, label %ok.500
ok.500:
  br label %bb119
bb119:
  br label %bb121
bb120:
  %t501 = load i32, ptr %l194, !tbaa !23
  %t502 = lshr i32 %t501, 16
  %t503 = and i32 %t501, 65535
  %t504 = icmp eq i32 %t502, 1
  %t505 = select i1 %t504, i32 1, i32 0
  %t506 = icmp eq i32 %t501, 0
  %t507 = shl i32 %t505, 16
  %t508 = or i32 %t507, %t503
  %t509 = select i1 %t506, i32 0, i32 %t508
  %t511 = insertvalue { i32, ptr } zeroinitializer, i32 %t509, 0
  store { i32, ptr } %t511, ptr %rv
  br label %ret
bb121:
  %t512 = load %"compiler/source:Span", ptr %l16
  %t513 = load ptr, ptr %l14, !tbaa !29
  %t514 = load ptr, ptr %l15, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t515
  %t516 = getelementptr { i64, [5 x i64] }, ptr %t515, i32 0, i32 0
  store i64 14, ptr %t516
  %t518 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t512, 0
  %t520 = insertvalue { %"compiler/source:Span", ptr, ptr } %t518, ptr %t513, 1
  %t522 = insertvalue { %"compiler/source:Span", ptr, ptr } %t520, ptr %t514, 2
  %t523 = getelementptr { i64, [5 x i64] }, ptr %t515, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t522, ptr %t523
  %t524 = load { i64, [5 x i64] }, ptr %t515
  %t526 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t524, ptr %t526
  %t528 = insertvalue { i32, ptr } zeroinitializer, ptr %t526, 1
  store { i32, ptr } %t528, ptr %rv
  br label %ret
bb122:
  %t529 = load i32, ptr %l2
  %t531 = trunc i64 38 to i32
  %t532 = icmp eq i32 %t529, %t531
  br i1 %t532, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb134
bb125:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t534)
  store i32 %t536, ptr %l204
  br label %bb126
bb126:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %t537)
  %t540 = extractvalue { i32, ptr } %t539, 1
  %t541 = extractvalue { i32, ptr } %t539, 0
  store i32 %t541, ptr %l208
  %t542 = icmp ne i32 %t541, 0
  br i1 %t542, label %bb128, label %ok.543
ok.543:
  store ptr %t540, ptr %l207
  br label %bb127
bb127:
  %t544 = load ptr, ptr %l207, !tbaa !29
  store ptr %t544, ptr %l205, !tbaa !29
  br label %bb129
bb128:
  %t545 = load i32, ptr %l208, !tbaa !23
  %t546 = lshr i32 %t545, 16
  %t547 = and i32 %t545, 65535
  %t548 = icmp eq i32 %t546, 1
  %t549 = select i1 %t548, i32 1, i32 0
  %t550 = icmp eq i32 %t545, 0
  %t551 = shl i32 %t549, 16
  %t552 = or i32 %t551, %t547
  %t553 = select i1 %t550, i32 0, i32 %t552
  %t555 = insertvalue { i32, ptr } zeroinitializer, i32 %t553, 0
  store { i32, ptr } %t555, ptr %rv
  br label %ret
bb129:
  %t556 = load ptr, ptr %l205, !tbaa !29
  store ptr %t556, ptr %l17, !tbaa !29
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load i32, ptr %l1, !tbaa !23
  %t561 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t557, i32 %t558)
  store %"compiler/source:Span" %t561, ptr %l212
  br label %bb130
bb130:
  %t562 = load %"compiler/source:Span", ptr %l212
  store %"compiler/source:Span" %t562, ptr %l18
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t563)
  store i32 %t565, ptr %l214
  %t566 = icmp ne i32 %t565, 0
  br i1 %t566, label %bb132, label %ok.567
ok.567:
  br label %bb131
bb131:
  br label %bb133
bb132:
  %t568 = load i32, ptr %l214, !tbaa !23
  %t569 = lshr i32 %t568, 16
  %t570 = and i32 %t568, 65535
  %t571 = icmp eq i32 %t569, 1
  %t572 = select i1 %t571, i32 1, i32 0
  %t573 = icmp eq i32 %t568, 0
  %t574 = shl i32 %t572, 16
  %t575 = or i32 %t574, %t570
  %t576 = select i1 %t573, i32 0, i32 %t575
  %t578 = insertvalue { i32, ptr } zeroinitializer, i32 %t576, 0
  store { i32, ptr } %t578, ptr %rv
  br label %ret
bb133:
  %t579 = load %"compiler/source:Span", ptr %l18
  %t580 = load ptr, ptr %l17, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t582
  %t583 = getelementptr { i64, [5 x i64] }, ptr %t582, i32 0, i32 0
  store i64 15, ptr %t583
  %t585 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t579, 0
  %t587 = insertvalue { %"compiler/source:Span", ptr } %t585, ptr %t580, 1
  %t588 = getelementptr { i64, [5 x i64] }, ptr %t582, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t587, ptr %t588
  %t589 = load { i64, [5 x i64] }, ptr %t582
  %t591 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t589, ptr %t591
  %t593 = insertvalue { i32, ptr } zeroinitializer, ptr %t591, 1
  store { i32, ptr } %t593, ptr %rv
  br label %ret
bb134:
  %t594 = load i32, ptr %l2
  %t596 = trunc i64 16 to i32
  %t597 = icmp eq i32 %t594, %t596
  br i1 %t597, label %bb135, label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb186
bb137:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t601 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t599)
  store i32 %t601, ptr %l224
  br label %bb138
bb138:
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t604 = getelementptr %"compiler/parse:Parser", ptr %t602, i32 0, i32 28
  %t606 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t604)
  store i64 %t606, ptr %l227
  br label %bb139
bb139:
  %t607 = load i64, ptr %l227, !tbaa !24
  store i64 %t607, ptr %l19, !tbaa !24
  br label %bb140
bb140:
  store %olang.scope zeroinitializer, ptr %s15
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/parse:Parser", ptr %t608, i32 0, i32 28
  store ptr %t610, ptr %l229, !tbaa !29
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t611)
  %t614 = extractvalue { i32, ptr } %t613, 1
  %t615 = extractvalue { i32, ptr } %t613, 0
  store i32 %t615, ptr %l233
  %t616 = icmp ne i32 %t615, 0
  br i1 %t616, label %bb142, label %ok.617
ok.617:
  store ptr %t614, ptr %l232
  br label %bb141
bb141:
  %t618 = load ptr, ptr %l232, !tbaa !29
  store ptr %t618, ptr %l230, !tbaa !29
  br label %bb143
bb142:
  %t619 = load i32, ptr %l233, !tbaa !23
  %t620 = lshr i32 %t619, 16
  %t621 = and i32 %t619, 65535
  %t622 = icmp eq i32 %t620, 1
  %t623 = select i1 %t622, i32 1, i32 0
  %t624 = icmp eq i32 %t619, 0
  %t625 = shl i32 %t623, 16
  %t626 = or i32 %t625, %t621
  %t627 = select i1 %t624, i32 0, i32 %t626
  call void @__olang_scope_close(ptr %s15)
  %t629 = insertvalue { i32, ptr } zeroinitializer, i32 %t627, 0
  store { i32, ptr } %t629, ptr %rv
  br label %ret
bb143:
  %t630 = load ptr, ptr %l229, !tbaa !29
  %t631 = load ptr, ptr %l230, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t630, ptr %t631)
  br label %bb144
bb144:
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t635 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t632, i32 55)
  store i1 %t635, ptr %l237
  br label %bb145
bb145:
  %t636 = load i1, ptr %l237, !tbaa !21
  %t637 = xor i1 %t636, true
  br i1 %t637, label %bb146, label %bb147
bb146:
  call void @__olang_scope_close(ptr %s15)
  br label %bb150
bb147:
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s15)
  br label %bb149
bb149:
  br label %bb140
bb150:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t642 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t639, i32 58)
  store i1 %t642, ptr %l241
  br label %bb151
bb151:
  %t643 = load i1, ptr %l241, !tbaa !21
  br i1 %t643, label %bb152, label %bb153
bb152:
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t646 = getelementptr %"compiler/parse:Parser", ptr %t644, i32 0, i32 28
  %t647 = load i64, ptr %l19, !tbaa !24
  %t650 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t646, i64 %t647)
  store { i64, ptr } %t650, ptr %l245
  br label %bb154
bb153:
  br label %bb166
bb154:
  %t651 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t651, ptr %l20, !tbaa !27
  %t652 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t656 = icmp sgt i64 %t654, 1
  br i1 %t656, label %bb155, label %bb156
bb155:
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l249, !tbaa !29
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t659)
  store i32 %t661, ptr %l251
  br label %bb157
bb156:
  br label %bb158
bb157:
  %t662 = load i32, ptr %l251, !tbaa !23
  %t663 = load ptr, ptr %l249, !tbaa !29
  %t664 = getelementptr %"compiler/parse:Parser", ptr %t663, i32 0, i32 23
  store i32 %t662, ptr %t664, !tbaa !23
  br label %bb158
bb158:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t665)
  %t668 = extractvalue { i32, ptr } %t667, 1
  %t669 = extractvalue { i32, ptr } %t667, 0
  store i32 %t669, ptr %l255
  %t670 = icmp ne i32 %t669, 0
  br i1 %t670, label %bb160, label %ok.671
ok.671:
  store ptr %t668, ptr %l254
  br label %bb159
bb159:
  %t672 = load ptr, ptr %l254, !tbaa !29
  store ptr %t672, ptr %l252, !tbaa !29
  br label %bb161
bb160:
  %t673 = load i32, ptr %l255, !tbaa !23
  %t674 = lshr i32 %t673, 16
  %t675 = and i32 %t673, 65535
  %t676 = icmp eq i32 %t674, 1
  %t677 = select i1 %t676, i32 1, i32 0
  %t678 = icmp eq i32 %t673, 0
  %t679 = shl i32 %t677, 16
  %t680 = or i32 %t679, %t675
  %t681 = select i1 %t678, i32 0, i32 %t680
  %t683 = insertvalue { i32, ptr } zeroinitializer, i32 %t681, 0
  store { i32, ptr } %t683, ptr %rv
  br label %ret
bb161:
  %t684 = load ptr, ptr %l252, !tbaa !29
  store ptr %t684, ptr %l21, !tbaa !29
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load i32, ptr %l1, !tbaa !23
  %t689 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t685, i32 %t686)
  store %"compiler/source:Span" %t689, ptr %l259
  br label %bb162
bb162:
  %t690 = load %"compiler/source:Span", ptr %l259
  store %"compiler/source:Span" %t690, ptr %l22
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t693 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t691)
  store i32 %t693, ptr %l261
  %t694 = icmp ne i32 %t693, 0
  br i1 %t694, label %bb164, label %ok.695
ok.695:
  br label %bb163
bb163:
  br label %bb165
bb164:
  %t696 = load i32, ptr %l261, !tbaa !23
  %t697 = lshr i32 %t696, 16
  %t698 = and i32 %t696, 65535
  %t699 = icmp eq i32 %t697, 1
  %t700 = select i1 %t699, i32 1, i32 0
  %t701 = icmp eq i32 %t696, 0
  %t702 = shl i32 %t700, 16
  %t703 = or i32 %t702, %t698
  %t704 = select i1 %t701, i32 0, i32 %t703
  %t706 = insertvalue { i32, ptr } zeroinitializer, i32 %t704, 0
  store { i32, ptr } %t706, ptr %rv
  br label %ret
bb165:
  %t707 = load %"compiler/source:Span", ptr %l22
  %t708 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t709 = load ptr, ptr %l21, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t710
  %t711 = getelementptr { i64, [5 x i64] }, ptr %t710, i32 0, i32 0
  store i64 16, ptr %t711
  %t713 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t707, 0
  %t715 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t713, { i64, ptr } %t708, 1
  %t717 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t715, ptr %t709, 2
  %t718 = getelementptr { i64, [5 x i64] }, ptr %t710, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t717, ptr %t718
  %t719 = load { i64, [5 x i64] }, ptr %t710
  %t721 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t719, ptr %t721
  %t723 = insertvalue { i32, ptr } zeroinitializer, ptr %t721, 1
  store { i32, ptr } %t723, ptr %rv
  br label %ret
bb166:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t726 = getelementptr %"compiler/parse:Parser", ptr %t724, i32 0, i32 28
  %t728 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t726)
  store i64 %t728, ptr %l270
  br label %bb167
bb167:
  %t729 = load i64, ptr %l19, !tbaa !24
  %t730 = load i64, ptr %l270, !tbaa !24
  %t732 = sub i64 %t730, %t729
  %t734 = icmp ne i64 %t732, 1
  br i1 %t734, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s19
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t738 = getelementptr %"compiler/parse:Parser", ptr %t736, i32 0, i32 28
  %t739 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t738, i64 %t739)
  br label %bb170
bb169:
  br label %bb175
bb170:
  %t742 = load ptr, ptr %l0, !tbaa !29
  store ptr %t742, ptr %l277, !tbaa !29
  %t744 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s19, i32 58)
  store { i64, ptr } %t744, ptr %l279
  br label %bb171
bb171:
  %t745 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t746 = extractvalue { i64, ptr } %t745, 0
  %t747 = extractvalue { i64, ptr } %t745, 1
  %t748 = mul i64 %t746, 1
  %t749 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t748)
  call void @llvm.memcpy.p0.p0.i64(ptr %t749, ptr %t747, i64 %t748, i1 false)
  %t750 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t751 = insertvalue { i64, ptr } %t750, ptr %t749, 1
  %t752 = load ptr, ptr %l277, !tbaa !29
  %t754 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s19, ptr %t752, { i64, ptr } %t751)
  store i32 %t754, ptr %l281
  %t755 = icmp ne i32 %t754, 0
  br i1 %t755, label %bb173, label %ok.756
ok.756:
  br label %bb172
bb172:
  br label %bb174
bb173:
  %t757 = load i32, ptr %l281, !tbaa !23
  %t758 = lshr i32 %t757, 16
  %t759 = and i32 %t757, 65535
  %t760 = icmp eq i32 %t758, 1
  %t761 = select i1 %t760, i32 1, i32 0
  %t762 = icmp eq i32 %t757, 0
  %t763 = shl i32 %t761, 16
  %t764 = or i32 %t763, %t759
  %t765 = select i1 %t762, i32 0, i32 %t764
  call void @__olang_scope_close(ptr %s19)
  %t767 = insertvalue { i32, ptr } zeroinitializer, i32 %t765, 0
  store { i32, ptr } %t767, ptr %rv
  br label %ret
bb174:
  call void @__olang_scope_close(ptr %s19)
  br label %bb175
bb175:
  %t768 = load ptr, ptr %l0, !tbaa !29
  %t770 = getelementptr %"compiler/parse:Parser", ptr %t768, i32 0, i32 28
  %t771 = load i64, ptr %l19, !tbaa !24
  %t774 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eAt_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t770, i64 %t771)
  store ptr %t774, ptr %l286
  br label %bb176
bb176:
  %t775 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t775, ptr %lp23
  %t776 = load ptr, ptr %l286, !tbaa !29
  %t777 = load ptr, ptr %lp23
  store ptr %t776, ptr %t777, !tbaa !29
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t780 = getelementptr %"compiler/parse:Parser", ptr %t778, i32 0, i32 28
  %t781 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t780, i64 %t781)
  br label %bb177
bb177:
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t785 = load i32, ptr %l1, !tbaa !23
  %t788 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t784, i32 %t785)
  store %"compiler/source:Span" %t788, ptr %l292
  br label %bb178
bb178:
  %t789 = load %"compiler/source:Span", ptr %l292
  store %"compiler/source:Span" %t789, ptr %l24
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t792 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t790)
  store i32 %t792, ptr %l294
  %t793 = icmp ne i32 %t792, 0
  br i1 %t793, label %bb180, label %ok.794
ok.794:
  br label %bb179
bb179:
  br label %bb181
bb180:
  %t795 = load i32, ptr %l294, !tbaa !23
  %t796 = lshr i32 %t795, 16
  %t797 = and i32 %t795, 65535
  %t798 = icmp eq i32 %t796, 1
  %t799 = select i1 %t798, i32 1, i32 0
  %t800 = icmp eq i32 %t795, 0
  %t801 = shl i32 %t799, 16
  %t802 = or i32 %t801, %t797
  %t803 = select i1 %t800, i32 0, i32 %t802
  %t805 = insertvalue { i32, ptr } zeroinitializer, i32 %t803, 0
  store { i32, ptr } %t805, ptr %rv
  br label %ret
bb181:
  %t806 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t806, ptr %l296
  %t807 = icmp sge i64 0, 0
  br i1 %t807, label %bb182, label %bb183
bb182:
  %t809 = icmp sle i64 0, 1152921504606846975
  br i1 %t809, label %bb184, label %bb185
bb183:
  call void @__olang_check_failed(ptr @olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd)
  unreachable
bb184:
  %t811 = mul i64 0, 8
  %t812 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t811)
  %t813 = insertvalue { i64, ptr } undef, i64 0, 0
  %t814 = insertvalue { i64, ptr } %t813, ptr %t812, 1
  %t815 = load ptr, ptr %lp23
  %t816 = load ptr, ptr %t815, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t817
  %t818 = getelementptr { i64, [5 x i64] }, ptr %t817, i32 0, i32 0
  store i64 16, ptr %t818
  %t819 = load %"compiler/source:Span", ptr %l296
  %t820 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } undef, %"compiler/source:Span" %t819, 0
  %t822 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t820, { i64, ptr } %t814, 1
  %t824 = insertvalue { %"compiler/source:Span", { i64, ptr }, ptr } %t822, ptr %t816, 2
  %t825 = getelementptr { i64, [5 x i64] }, ptr %t817, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, ptr } %t824, ptr %t825
  %t826 = load { i64, [5 x i64] }, ptr %t817
  %t828 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t826, ptr %t828
  %t830 = insertvalue { i32, ptr } zeroinitializer, ptr %t828, 1
  store { i32, ptr } %t830, ptr %rv
  br label %ret
bb185:
  call void @__olang_check_failed(ptr @olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd)
  unreachable
bb186:
  %t831 = load i32, ptr %l2
  %t833 = trunc i64 15 to i32
  %t834 = icmp eq i32 %t831, %t833
  br i1 %t834, label %bb187, label %bb188
bb187:
  br label %bb189
bb188:
  br label %bb194
bb189:
  %t836 = load ptr, ptr %l0, !tbaa !29
  %t838 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %t836, i1 false)
  %t839 = extractvalue { i32, ptr } %t838, 1
  %t840 = extractvalue { i32, ptr } %t838, 0
  store i32 %t840, ptr %l308
  %t841 = icmp ne i32 %t840, 0
  br i1 %t841, label %bb191, label %ok.842
ok.842:
  store ptr %t839, ptr %l307
  br label %bb190
bb190:
  %t843 = load ptr, ptr %l307, !tbaa !29
  store ptr %t843, ptr %l305, !tbaa !29
  br label %bb192
bb191:
  %t844 = load i32, ptr %l308, !tbaa !23
  %t845 = lshr i32 %t844, 16
  %t846 = and i32 %t844, 65535
  %t847 = icmp eq i32 %t845, 1
  %t848 = select i1 %t847, i32 1, i32 0
  %t849 = icmp eq i32 %t844, 0
  %t850 = shl i32 %t848, 16
  %t851 = or i32 %t850, %t846
  %t852 = select i1 %t849, i32 0, i32 %t851
  %t854 = insertvalue { i32, ptr } zeroinitializer, i32 %t852, 0
  store { i32, ptr } %t854, ptr %rv
  br label %ret
bb192:
  %t855 = load ptr, ptr %l305, !tbaa !29
  store ptr %t855, ptr %l25, !tbaa !29
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t857 = load i32, ptr %l1, !tbaa !23
  %t860 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t856, i32 %t857)
  store %"compiler/source:Span" %t860, ptr %l312
  br label %bb193
bb193:
  %t861 = load ptr, ptr %l25, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t862
  %t863 = getelementptr { i64, [5 x i64] }, ptr %t862, i32 0, i32 0
  store i64 17, ptr %t863
  %t864 = load %"compiler/source:Span", ptr %l312
  %t865 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t864, 0
  %t867 = insertvalue { %"compiler/source:Span", ptr } %t865, ptr %t861, 1
  %t868 = getelementptr { i64, [5 x i64] }, ptr %t862, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t867, ptr %t868
  %t869 = load { i64, [5 x i64] }, ptr %t862
  %t871 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t869, ptr %t871
  %t873 = insertvalue { i32, ptr } zeroinitializer, ptr %t871, 1
  store { i32, ptr } %t873, ptr %rv
  br label %ret
bb194:
  %t874 = load i32, ptr %l2
  %t876 = trunc i64 17 to i32
  %t877 = icmp eq i32 %t874, %t876
  br i1 %t877, label %bb195, label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb216
bb197:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t881 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t879)
  store i32 %t881, ptr %l319
  br label %bb198
bb198:
  %t882 = load ptr, ptr %l0, !tbaa !29
  %t885 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t882, i32 92)
  store i1 %t885, ptr %l322
  br label %bb199
bb199:
  %t886 = load i1, ptr %l322, !tbaa !21
  br i1 %t886, label %bb200, label %bb201
bb200:
  %t887 = load ptr, ptr %l0, !tbaa !29
  %t889 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t887)
  %t890 = extractvalue { i32, { i64, ptr } } %t889, 1
  %t891 = extractvalue { i32, { i64, ptr } } %t889, 0
  store i32 %t891, ptr %l326
  %t892 = icmp ne i32 %t891, 0
  br i1 %t892, label %bb203, label %ok.893
ok.893:
  store { i64, ptr } %t890, ptr %l325
  br label %bb202
bb201:
  br label %bb211
bb202:
  %t894 = load { i64, ptr }, ptr %l325, !tbaa !27
  store { i64, ptr } %t894, ptr %l323, !tbaa !27
  br label %bb204
bb203:
  %t895 = load i32, ptr %l326, !tbaa !23
  %t896 = lshr i32 %t895, 16
  %t897 = and i32 %t895, 65535
  %t898 = icmp eq i32 %t896, 1
  %t899 = select i1 %t898, i32 1, i32 0
  %t900 = icmp eq i32 %t895, 0
  %t901 = shl i32 %t899, 16
  %t902 = or i32 %t901, %t897
  %t903 = select i1 %t900, i32 0, i32 %t902
  %t905 = insertvalue { i32, ptr } zeroinitializer, i32 %t903, 0
  store { i32, ptr } %t905, ptr %rv
  br label %ret
bb204:
  %t906 = load { i64, ptr }, ptr %l323, !tbaa !27
  store { i64, ptr } %t906, ptr %l26, !tbaa !27
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t908 = load i32, ptr %l1, !tbaa !23
  %t911 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t907, i32 %t908)
  store %"compiler/source:Span" %t911, ptr %l330
  br label %bb205
bb205:
  %t912 = load %"compiler/source:Span", ptr %l330
  store %"compiler/source:Span" %t912, ptr %l27
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t916 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t913, i32 8)
  store i1 %t916, ptr %l333
  br label %bb206
bb206:
  %t917 = load i1, ptr %l333, !tbaa !21
  br i1 %t917, label %bb207, label %bb208
bb207:
  %t918 = load ptr, ptr %l0, !tbaa !29
  %t920 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t918)
  store i32 %t920, ptr %l335
  br label %bb209
bb208:
  br label %bb210
bb209:
  br label %bb210
bb210:
  %t921 = load %"compiler/source:Span", ptr %l27
  %t922 = load %"compiler/source:Span", ptr %l27
  %t923 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t924
  %t925 = getelementptr { i64, [5 x i64] }, ptr %t924, i32 0, i32 0
  store i64 19, ptr %t925
  %t927 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t922, 0
  %t929 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t927, { i64, ptr } %t923, 1
  %t930 = getelementptr { i64, [5 x i64] }, ptr %t924, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t929, ptr %t930
  %t931 = load { i64, [5 x i64] }, ptr %t924
  %t933 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t931, ptr %t933
  store { i64, [5 x i64] } zeroinitializer, ptr %t934
  %t935 = getelementptr { i64, [5 x i64] }, ptr %t934, i32 0, i32 0
  store i64 18, ptr %t935
  %t937 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t921, 0
  %t939 = insertvalue { %"compiler/source:Span", ptr } %t937, ptr %t933, 1
  %t940 = getelementptr { i64, [5 x i64] }, ptr %t934, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t939, ptr %t940
  %t941 = load { i64, [5 x i64] }, ptr %t934
  %t943 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t941, ptr %t943
  %t945 = insertvalue { i32, ptr } zeroinitializer, ptr %t943, 1
  store { i32, ptr } %t945, ptr %rv
  br label %ret
bb211:
  %t946 = load ptr, ptr %l0, !tbaa !29
  %t948 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %t946)
  %t949 = extractvalue { i32, ptr } %t948, 1
  %t950 = extractvalue { i32, ptr } %t948, 0
  store i32 %t950, ptr %l346
  %t951 = icmp ne i32 %t950, 0
  br i1 %t951, label %bb213, label %ok.952
ok.952:
  store ptr %t949, ptr %l345
  br label %bb212
bb212:
  %t953 = load ptr, ptr %l345, !tbaa !29
  store ptr %t953, ptr %l343, !tbaa !29
  br label %bb214
bb213:
  %t954 = load i32, ptr %l346, !tbaa !23
  %t955 = lshr i32 %t954, 16
  %t956 = and i32 %t954, 65535
  %t957 = icmp eq i32 %t955, 1
  %t958 = select i1 %t957, i32 1, i32 0
  %t959 = icmp eq i32 %t954, 0
  %t960 = shl i32 %t958, 16
  %t961 = or i32 %t960, %t956
  %t962 = select i1 %t959, i32 0, i32 %t961
  %t964 = insertvalue { i32, ptr } zeroinitializer, i32 %t962, 0
  store { i32, ptr } %t964, ptr %rv
  br label %ret
bb214:
  %t965 = load ptr, ptr %l343, !tbaa !29
  store ptr %t965, ptr %l28, !tbaa !29
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load i32, ptr %l1, !tbaa !23
  %t970 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t966, i32 %t967)
  store %"compiler/source:Span" %t970, ptr %l350
  br label %bb215
bb215:
  %t971 = load ptr, ptr %l28, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t972
  %t973 = getelementptr { i64, [5 x i64] }, ptr %t972, i32 0, i32 0
  store i64 18, ptr %t973
  %t974 = load %"compiler/source:Span", ptr %l350
  %t975 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t974, 0
  %t977 = insertvalue { %"compiler/source:Span", ptr } %t975, ptr %t971, 1
  %t978 = getelementptr { i64, [5 x i64] }, ptr %t972, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t977, ptr %t978
  %t979 = load { i64, [5 x i64] }, ptr %t972
  %t981 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t979, ptr %t981
  %t983 = insertvalue { i32, ptr } zeroinitializer, ptr %t981, 1
  store { i32, ptr } %t983, ptr %rv
  br label %ret
bb216:
  %t984 = load i32, ptr %l2
  %t986 = trunc i64 92 to i32
  %t987 = icmp eq i32 %t984, %t986
  br i1 %t987, label %bb217, label %bb218
bb217:
  br label %bb219
bb218:
  br label %bb229
bb219:
  %t989 = load ptr, ptr %l0, !tbaa !29
  %t991 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t989)
  %t992 = extractvalue { i32, { i64, ptr } } %t991, 1
  %t993 = extractvalue { i32, { i64, ptr } } %t991, 0
  store i32 %t993, ptr %l359
  %t994 = icmp ne i32 %t993, 0
  br i1 %t994, label %bb221, label %ok.995
ok.995:
  store { i64, ptr } %t992, ptr %l358
  br label %bb220
bb220:
  %t996 = load { i64, ptr }, ptr %l358, !tbaa !27
  store { i64, ptr } %t996, ptr %l356, !tbaa !27
  br label %bb222
bb221:
  %t997 = load i32, ptr %l359, !tbaa !23
  %t998 = lshr i32 %t997, 16
  %t999 = and i32 %t997, 65535
  %t1000 = icmp eq i32 %t998, 1
  %t1001 = select i1 %t1000, i32 1, i32 0
  %t1002 = icmp eq i32 %t997, 0
  %t1003 = shl i32 %t1001, 16
  %t1004 = or i32 %t1003, %t999
  %t1005 = select i1 %t1002, i32 0, i32 %t1004
  %t1007 = insertvalue { i32, ptr } zeroinitializer, i32 %t1005, 0
  store { i32, ptr } %t1007, ptr %rv
  br label %ret
bb222:
  %t1008 = load { i64, ptr }, ptr %l356, !tbaa !27
  store { i64, ptr } %t1008, ptr %l29, !tbaa !27
  %t1009 = load ptr, ptr %l0, !tbaa !29
  %t1010 = load i32, ptr %l1, !tbaa !23
  %t1013 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t1009, i32 %t1010)
  store %"compiler/source:Span" %t1013, ptr %l363
  br label %bb223
bb223:
  %t1014 = load %"compiler/source:Span", ptr %l363
  store %"compiler/source:Span" %t1014, ptr %l30
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1018 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1015, i32 8)
  store i1 %t1018, ptr %l366
  br label %bb224
bb224:
  %t1019 = load i1, ptr %l366, !tbaa !21
  br i1 %t1019, label %bb225, label %bb226
bb225:
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1022 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1020)
  store i32 %t1022, ptr %l368
  br label %bb227
bb226:
  br label %bb228
bb227:
  br label %bb228
bb228:
  %t1023 = load %"compiler/source:Span", ptr %l30
  %t1024 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t1025
  %t1026 = getelementptr { i64, [5 x i64] }, ptr %t1025, i32 0, i32 0
  store i64 19, ptr %t1026
  %t1028 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t1023, 0
  %t1030 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t1028, { i64, ptr } %t1024, 1
  %t1031 = getelementptr { i64, [5 x i64] }, ptr %t1025, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t1030, ptr %t1031
  %t1032 = load { i64, [5 x i64] }, ptr %t1025
  %t1034 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1032, ptr %t1034
  %t1036 = insertvalue { i32, ptr } zeroinitializer, ptr %t1034, 1
  store { i32, ptr } %t1036, ptr %rv
  br label %ret
bb229:
  %t1037 = load i32, ptr %l2
  %t1039 = trunc i64 11 to i32
  %t1040 = icmp eq i32 %t1037, %t1039
  br i1 %t1040, label %bb230, label %bb231
bb230:
  br label %bb234
bb231:
  %t1042 = load i32, ptr %l2
  %t1044 = trunc i64 12 to i32
  %t1045 = icmp eq i32 %t1042, %t1044
  br i1 %t1045, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb238
bb234:
  %t1047 = load ptr, ptr %l0, !tbaa !29
  %t1049 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %t1047)
  %t1050 = extractvalue { i32, ptr } %t1049, 1
  %t1051 = extractvalue { i32, ptr } %t1049, 0
  store i32 %t1051, ptr %l380
  %t1052 = icmp ne i32 %t1051, 0
  br i1 %t1052, label %bb236, label %ok.1053
ok.1053:
  store ptr %t1050, ptr %l379
  br label %bb235
bb235:
  %t1054 = load ptr, ptr %l379, !tbaa !29
  store ptr %t1054, ptr %l377, !tbaa !29
  br label %bb237
bb236:
  %t1055 = load i32, ptr %l380, !tbaa !23
  %t1056 = lshr i32 %t1055, 16
  %t1057 = and i32 %t1055, 65535
  %t1058 = icmp eq i32 %t1056, 1
  %t1059 = select i1 %t1058, i32 1, i32 0
  %t1060 = icmp eq i32 %t1055, 0
  %t1061 = shl i32 %t1059, 16
  %t1062 = or i32 %t1061, %t1057
  %t1063 = select i1 %t1060, i32 0, i32 %t1062
  %t1065 = insertvalue { i32, ptr } zeroinitializer, i32 %t1063, 0
  store { i32, ptr } %t1065, ptr %rv
  br label %ret
bb237:
  %t1066 = load ptr, ptr %l377, !tbaa !29
  %t1067 = insertvalue { i32, ptr } zeroinitializer, ptr %t1066, 1
  store { i32, ptr } %t1067, ptr %rv
  br label %ret
bb238:
  %t1068 = load i32, ptr %l2
  %t1070 = trunc i64 1 to i32
  %t1071 = icmp eq i32 %t1068, %t1070
  br i1 %t1071, label %bb239, label %bb240
bb239:
  br label %bb241
bb240:
  br label %bb245
bb241:
  %t1073 = load ptr, ptr %l0, !tbaa !29
  %t1075 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eidenStmt(ptr %v0, ptr %t1073)
  %t1076 = extractvalue { i32, ptr } %t1075, 1
  %t1077 = extractvalue { i32, ptr } %t1075, 0
  store i32 %t1077, ptr %l387
  %t1078 = icmp ne i32 %t1077, 0
  br i1 %t1078, label %bb243, label %ok.1079
ok.1079:
  store ptr %t1076, ptr %l386
  br label %bb242
bb242:
  %t1080 = load ptr, ptr %l386, !tbaa !29
  store ptr %t1080, ptr %l384, !tbaa !29
  br label %bb244
bb243:
  %t1081 = load i32, ptr %l387, !tbaa !23
  %t1082 = lshr i32 %t1081, 16
  %t1083 = and i32 %t1081, 65535
  %t1084 = icmp eq i32 %t1082, 1
  %t1085 = select i1 %t1084, i32 1, i32 0
  %t1086 = icmp eq i32 %t1081, 0
  %t1087 = shl i32 %t1085, 16
  %t1088 = or i32 %t1087, %t1083
  %t1089 = select i1 %t1086, i32 0, i32 %t1088
  %t1091 = insertvalue { i32, ptr } zeroinitializer, i32 %t1089, 0
  store { i32, ptr } %t1091, ptr %rv
  br label %ret
bb244:
  %t1092 = load ptr, ptr %l384, !tbaa !29
  %t1093 = insertvalue { i32, ptr } zeroinitializer, ptr %t1092, 1
  store { i32, ptr } %t1093, ptr %rv
  br label %ret
bb245:
  %t1094 = load ptr, ptr %l0, !tbaa !29
  %t1096 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %t1094)
  %t1097 = extractvalue { i32, ptr } %t1096, 1
  %t1098 = extractvalue { i32, ptr } %t1096, 0
  store i32 %t1098, ptr %l392
  %t1099 = icmp ne i32 %t1098, 0
  br i1 %t1099, label %bb247, label %ok.1100
ok.1100:
  store ptr %t1097, ptr %l391
  br label %bb246
bb246:
  %t1101 = load ptr, ptr %l391, !tbaa !29
  store ptr %t1101, ptr %l389, !tbaa !29
  br label %bb248
bb247:
  %t1102 = load i32, ptr %l392, !tbaa !23
  %t1103 = lshr i32 %t1102, 16
  %t1104 = and i32 %t1102, 65535
  %t1105 = icmp eq i32 %t1103, 1
  %t1106 = select i1 %t1105, i32 1, i32 0
  %t1107 = icmp eq i32 %t1102, 0
  %t1108 = shl i32 %t1106, 16
  %t1109 = or i32 %t1108, %t1104
  %t1110 = select i1 %t1107, i32 0, i32 %t1109
  %t1112 = insertvalue { i32, ptr } zeroinitializer, i32 %t1110, 0
  store { i32, ptr } %t1112, ptr %rv
  br label %ret
bb248:
  %t1113 = load ptr, ptr %l389, !tbaa !29
  %t1114 = insertvalue { i32, ptr } zeroinitializer, ptr %t1113, 1
  store { i32, ptr } %t1114, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncItem(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca %"compiler/token:Token"
  %l11 = alloca %"compiler/token:Token"
  %l16 = alloca i1
  %l20 = alloca i32
  %l32 = alloca %"compiler/token:Token"
  %l35 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 7
  store i32 0, ptr %t9
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 11
  store i1 false, ptr %t12, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t13)
  store %"compiler/token:Token" %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t16, ptr %l3
  %t17 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t18 = load i32, ptr %t17
  %t20 = trunc i64 0 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t23 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 93 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l20
  br label %bb12
bb12:
  %t37 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t38 = load i32, ptr %t37
  %t40 = trunc i64 92 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb38
bb14:
  %t47 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t48 = load i32, ptr %t47
  %t50 = trunc i64 93 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t55 = sub i64 %t53, 1
  store i64 %t55, ptr %l2, !tbaa !24
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = icmp eq i64 %t57, 0
  br i1 %t59, label %bb17, label %bb18
bb16:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb31, label %bb32
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t65)
  store %"compiler/token:Token" %t67, ptr %l32
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t68 = load %"compiler/token:Token", ptr %l32
  store %"compiler/token:Token" %t68, ptr %l4
  %t69 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 0
  %t70 = load i32, ptr %t69
  %t72 = trunc i64 0 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  %t75 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 0
  %t76 = load i32, ptr %t75
  %t78 = trunc i64 8 to i32
  %t79 = icmp eq i32 %t76, %t78
  store i1 %t79, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb26
bb24:
  %t82 = load %"compiler/token:Token", ptr %l4
  %t83 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t86 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t82, i8 %t83)
  store i1 %t86, ptr %l41
  br label %bb25
bb25:
  %t87 = load i1, ptr %l41, !tbaa !21
  store i1 %t87, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l38, !tbaa !21
  br i1 %t88, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb37
bb31:
  %t89 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 0
  %t90 = load i32, ptr %t89
  %t92 = trunc i64 8 to i32
  %t93 = icmp eq i32 %t90, %t92
  store i1 %t93, ptr %l44, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb33
bb33:
  %t95 = load i1, ptr %l44, !tbaa !21
  br i1 %t95, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s1)
  br label %bb39
bb39:
  br label %bb1
ret:
  ret void
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etextPieceCalled(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %l16 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i64
  %l42 = alloca i32
  %l45 = alloca i1
  %l48 = alloca i32
  %l51 = alloca i1
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t20, 1
  %t23 = load i64, ptr %l16, !tbaa !24
  %t25 = icmp sge i64 %t23, %t22
  store i1 %t25, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t30 = load i64, ptr %l4, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = sub i64 %t32, 1
  store i64 %t34, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/parse:Parser", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/scan:Tokens", ptr %t42, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t50 = icmp slt i64 %t38, %t47
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l34, !tbaa !24
  %t60 = icmp sle i64 %t58, %t57
  store i1 %t60, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t62 = load i1, ptr %l31, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb18:
  br label %bb19
bb19:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l5, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t69, i64 %t70)
  store i32 %t73, ptr %l42
  br label %bb20
bb20:
  %t74 = load i32, ptr %l42
  %t76 = trunc i64 5 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb21, label %bb22
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l5, !tbaa !24
  %t83 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t79, i64 %t80)
  store i32 %t83, ptr %l48
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  %t84 = load i32, ptr %l48
  %t86 = trunc i64 88 to i32
  %t87 = icmp eq i32 %t84, %t86
  store i1 %t87, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t89 = load i1, ptr %l45, !tbaa !21
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l54
  br label %bb27
bb26:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb29
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t95, i64 %t96)
  store i64 %t99, ptr %l57
  br label %bb28
bb28:
  %t100 = load i64, ptr %l54, !tbaa !24
  %t101 = load i64, ptr %l57, !tbaa !24
  %t102 = icmp eq i64 %t100, %t101
  store i1 %t102, ptr %l51, !tbaa !21
  br label %bb29
bb29:
  %t104 = load i1, ptr %l51, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load i64, ptr %l5, !tbaa !24
  store i64 %t106, ptr %l60, !tbaa !24
  %t107 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s3)
  store %"compiler/msgs:Msg" %t107, ptr %l61
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t108 = load ptr, ptr %l59, !tbaa !29
  %t109 = load i64, ptr %l60, !tbaa !24
  %t110 = load %"compiler/msgs:Msg", ptr %l61
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s3, ptr %t108, i64 %t109, %"compiler/msgs:Msg" %t110)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb34:
  %t112 = load i64, ptr %l5, !tbaa !24
  %t113 = load i64, ptr %l1, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb36:
  br label %bb37
bb37:
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb38:
  br label %bb12
bb39:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t31 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store ptr %t8, ptr %l7
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l7, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l5, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t25, i32 %t26)
  store %"compiler/source:Span" %t29, ptr %l12
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 0
  store i64 7, ptr %t32
  %t33 = load %"compiler/source:Span", ptr %l12
  %t34 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t33, 0
  %t36 = insertvalue { %"compiler/source:Span", ptr } %t34, ptr %t30, 1
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t36, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t31
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t38, ptr %t40
  %t42 = insertvalue { i32, ptr } zeroinitializer, ptr %t40, 1
  store { i32, ptr } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l23 = alloca i1
  %l29 = alloca %"compiler/ast:TopIf"
  %l33 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l45 = alloca %"compiler/ast:TopIf"
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i32
  %l58 = alloca %"compiler/ast:TopIf"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 9)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l9
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t21)
  %t24 = extractvalue { i32, ptr } %t23, 1
  %t25 = extractvalue { i32, ptr } %t23, 0
  store i32 %t25, ptr %l14
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb5, label %ok.27
ok.27:
  store ptr %t24, ptr %l13
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l13, !tbaa !29
  store ptr %t28, ptr %l11, !tbaa !29
  br label %bb6
bb5:
  %t29 = load i32, ptr %l14, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 %t37, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
bb6:
  %t40 = load ptr, ptr %l11, !tbaa !29
  store ptr %t40, ptr %l1, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %t41)
  %t44 = extractvalue { i32, ptr } %t43, 1
  %t45 = extractvalue { i32, ptr } %t43, 0
  store i32 %t45, ptr %l19
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb8, label %ok.47
ok.47:
  store ptr %t44, ptr %l18
  br label %bb7
bb7:
  %t48 = load ptr, ptr %l18, !tbaa !29
  store ptr %t48, ptr %l16, !tbaa !29
  br label %bb9
bb8:
  %t49 = load i32, ptr %l19, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb9:
  %t60 = load ptr, ptr %l16, !tbaa !29
  store ptr %t60, ptr %l2, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t61, i32 10)
  store i1 %t64, ptr %l23
  br label %bb10
bb10:
  %t65 = load i1, ptr %l23, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t74 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t68, ptr %t70, ptr null, ptr null)
  store %"compiler/ast:TopIf" %t74, ptr %l29
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t75 = load %"compiler/ast:TopIf", ptr %l29
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t75, ptr %t76
  %t78 = insertvalue { i32, ptr } zeroinitializer, ptr %t76, 1
  store { i32, ptr } %t78, ptr %rv
  br label %ret
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t79, i32 9)
  store i1 %t82, ptr %l33
  br label %bb15
bb15:
  %t83 = load i1, ptr %l33, !tbaa !21
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopIfRest(ptr %v0, ptr %t84)
  %t87 = extractvalue { i32, ptr } %t86, 1
  %t88 = extractvalue { i32, ptr } %t86, 0
  store i32 %t88, ptr %l37
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb19, label %ok.90
ok.90:
  store ptr %t87, ptr %l36
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t91 = load ptr, ptr %l36, !tbaa !29
  store ptr %t91, ptr %l34, !tbaa !29
  br label %bb20
bb19:
  %t92 = load i32, ptr %l37, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  %t102 = insertvalue { i32, ptr } zeroinitializer, i32 %t100, 0
  store { i32, ptr } %t102, ptr %rv
  br label %ret
bb20:
  %t103 = load ptr, ptr %l34, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t113 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t104, ptr %t106, ptr %t103, ptr null)
  store %"compiler/ast:TopIf" %t113, ptr %l45
  br label %bb21
bb21:
  %t114 = load %"compiler/ast:TopIf", ptr %l45
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t114, ptr %t115
  %t117 = insertvalue { i32, ptr } zeroinitializer, ptr %t115, 1
  store { i32, ptr } %t117, ptr %rv
  br label %ret
bb22:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %t118)
  %t121 = extractvalue { i32, ptr } %t120, 1
  %t122 = extractvalue { i32, ptr } %t120, 0
  store i32 %t122, ptr %l50
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb24, label %ok.124
ok.124:
  store ptr %t121, ptr %l49
  br label %bb23
bb23:
  %t125 = load ptr, ptr %l49, !tbaa !29
  store ptr %t125, ptr %l47, !tbaa !29
  br label %bb25
bb24:
  %t126 = load i32, ptr %l50, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  %t136 = insertvalue { i32, ptr } zeroinitializer, i32 %t134, 0
  store { i32, ptr } %t136, ptr %rv
  br label %ret
bb25:
  %t137 = load ptr, ptr %l47, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t147 = call %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t138, ptr %t140, ptr null, ptr %t137)
  store %"compiler/ast:TopIf" %t147, ptr %l58
  br label %bb26
bb26:
  %t148 = load %"compiler/ast:TopIf", ptr %l58
  %t149 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:TopIf" %t148, ptr %t149
  %t151 = insertvalue { i32, ptr } zeroinitializer, ptr %t149, 1
  store { i32, ptr } %t151, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etrailing(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1
  %t5 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t7)
  store i1 %t9, ptr %l7
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l9, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 10
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sub i32 %t18, 1
  store i32 %t20, ptr %l12, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 10
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l14, !tbaa !23
  %t25 = load i32, ptr %l1
  %t27 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t25)
  store { i64, ptr } %t27, ptr %l16
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s1, ptr %s1, { i64, ptr } %t28)
  store { i64, ptr } %t29, ptr %l17
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %s1, ptr %s1, { i64, ptr } %t36)
  store %"compiler/msgs:Msg" %t38, ptr %l19
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l9, !tbaa !29
  %t40 = load i32, ptr %l12, !tbaa !23
  %t41 = load i32, ptr %l14, !tbaa !23
  %t42 = load %"compiler/msgs:Msg", ptr %l19
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s1, ptr %t39, i32 %t40, i32 %t41, %"compiler/msgs:Msg" %t42)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %rv
  br label %ret
bb12:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %rv = alloca { i32, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l1, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = insertvalue { i32, ptr } zeroinitializer, ptr %t20, 1
  store { i32, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/token:Token"
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %lp30 = alloca ptr
  %l32 = alloca i32
  %l36 = alloca i32
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i32
  %l51 = alloca i32
  %l52 = alloca i32
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i32
  %l66 = alloca ptr
  %l67 = alloca i32
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l75 = alloca %"compiler/source:Span"
  %l81 = alloca i1
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i32
  %l91 = alloca %"compiler/source:Span"
  %l99 = alloca %"compiler/ast:StructBody"
  %l106 = alloca i32
  %l107 = alloca i32
  %l110 = alloca i32
  %l111 = alloca i32
  %l113 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l118 = alloca i1
  %l122 = alloca i32
  %l123 = alloca i32
  %l125 = alloca i32
  %l126 = alloca i32
  %l133 = alloca i1
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i32
  %l141 = alloca i1
  %l143 = alloca i1
  %l146 = alloca i1
  %l148 = alloca i1
  %l151 = alloca i1
  %l153 = alloca i1
  %l156 = alloca i1
  %l159 = alloca i32
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca i32
  %l167 = alloca %"compiler/source:Span"
  %l171 = alloca %"compiler/ast:Param"
  %l176 = alloca ptr
  %l179 = alloca %"compiler/source:Span"
  %l183 = alloca %"compiler/ast:CaseDecl"
  %l186 = alloca i32
  %l189 = alloca i32
  %l191 = alloca { i64, ptr }
  %l197 = alloca i32
  %l198 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l202 = alloca i32
  %l204 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca i32
  %l210 = alloca i32
  %l213 = alloca i32
  %l214 = alloca i32
  %l216 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l221 = alloca i1
  %l225 = alloca i32
  %l228 = alloca i1
  %l230 = alloca %"compiler/token:Token"
  %l232 = alloca i32
  %l235 = alloca %"compiler/source:Span"
  %l240 = alloca %"compiler/ast:Param"
  %l242 = alloca i32
  %l244 = alloca i32
  %l245 = alloca i32
  %l247 = alloca ptr
  %l249 = alloca ptr
  %l250 = alloca i32
  %l252 = alloca ptr
  %l255 = alloca %"compiler/source:Span"
  %l256 = alloca ptr
  %l257 = alloca i32
  %l258 = alloca ptr
  %l261 = alloca { i64, ptr }
  %l265 = alloca %"compiler/ast:Func"
  %l268 = alloca i32
  %l271 = alloca i32
  %l273 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l280 = alloca ptr
  %l281 = alloca i32
  %l285 = alloca i1
  %l287 = alloca i32
  %l288 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l291 = alloca i32
  %l293 = alloca ptr
  %l294 = alloca ptr
  %l295 = alloca ptr
  %l297 = alloca ptr
  %l298 = alloca i32
  %l300 = alloca ptr
  %l301 = alloca i32
  %l303 = alloca { i64, ptr }
  %l305 = alloca { i64, ptr }
  %l306 = alloca i32
  %l308 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l313 = alloca i1
  %l315 = alloca { i64, ptr }
  %l318 = alloca { i64, ptr }
  %l324 = alloca %"compiler/ast:Sig"
  %l325 = alloca ptr
  %l328 = alloca %"compiler/source:Span"
  %l329 = alloca ptr
  %l330 = alloca { i64, ptr }
  %l334 = alloca %"compiler/ast:Func"
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t212 = alloca { i64, [6 x i64] }, align 8
  %t447 = alloca { i64, [6 x i64] }, align 8
  %t568 = alloca { i64, [5 x i64] }, align 8
  %t685 = alloca { i64, [6 x i64] }, align 8
  %t879 = alloca { i64, [6 x i64] }, align 8
  %t892 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l32
  br label %bb1
bb1:
  %t4 = load i32, ptr %l32
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 34 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb47
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t10)
  store i32 %t12, ptr %l36
  br label %bb5
bb5:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e980cdf5146ac576_c2415009b5e84a7a)
  unreachable
bb8:
  %t17 = mul i64 0, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 77)
  store i1 %t25, ptr %l42
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e980cdf5146ac576_c2415009b5e84a7a)
  unreachable
bb10:
  %t26 = load i1, ptr %l42, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l46
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb14, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l45
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t34 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t34, ptr %l43, !tbaa !27
  br label %bb15
bb14:
  %t35 = load i32, ptr %l46, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  call void @__olang_scope_close(ptr %s1)
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t46, ptr %l2, !tbaa !27
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t47, i32 88)
  %t51 = extractvalue { i32, i32 } %t50, 1
  %t52 = extractvalue { i32, i32 } %t50, 0
  store i32 %t52, ptr %l52
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb18, label %ok.54
ok.54:
  store i32 %t51, ptr %l51
  br label %bb17
bb17:
  %t55 = load i32, ptr %l51, !tbaa !23
  store i32 %t55, ptr %l48, !tbaa !23
  br label %bb19
bb18:
  %t56 = load i32, ptr %l52, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  call void @__olang_scope_close(ptr %s1)
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %t67, i1 false)
  %t70 = extractvalue { i32, { i64, ptr } } %t69, 1
  %t71 = extractvalue { i32, { i64, ptr } } %t69, 0
  store i32 %t71, ptr %l57
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb21, label %ok.73
ok.73:
  store { i64, ptr } %t70, ptr %l56
  br label %bb20
bb20:
  %t74 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t74, ptr %l54, !tbaa !27
  br label %bb22
bb21:
  %t75 = load i32, ptr %l57, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  call void @__olang_scope_close(ptr %s1)
  %t85 = insertvalue { i32, ptr } zeroinitializer, i32 %t83, 0
  store { i32, ptr } %t85, ptr %rv
  br label %ret
bb22:
  %t86 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t86, ptr %l3, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l60, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %t88, i1 false)
  %t91 = extractvalue { i32, ptr } %t90, 1
  %t92 = extractvalue { i32, ptr } %t90, 0
  store i32 %t92, ptr %l64
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb24, label %ok.94
ok.94:
  store ptr %t91, ptr %l63
  br label %bb23
bb23:
  %t95 = load ptr, ptr %l63, !tbaa !29
  store ptr %t95, ptr %l61, !tbaa !29
  br label %bb25
bb24:
  %t96 = load i32, ptr %l64, !tbaa !23
  %t97 = lshr i32 %t96, 16
  %t98 = and i32 %t96, 65535
  %t99 = icmp eq i32 %t97, 1
  %t100 = select i1 %t99, i32 1, i32 0
  %t101 = icmp eq i32 %t96, 0
  %t102 = shl i32 %t100, 16
  %t103 = or i32 %t102, %t98
  %t104 = select i1 %t101, i32 0, i32 %t103
  call void @__olang_scope_close(ptr %s1)
  %t106 = insertvalue { i32, ptr } zeroinitializer, i32 %t104, 0
  store { i32, ptr } %t106, ptr %rv
  br label %ret
bb25:
  %t107 = load ptr, ptr %l60, !tbaa !29
  %t108 = load ptr, ptr %l61, !tbaa !29
  %t109 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractOn(ptr %v0, ptr %t107, ptr %t108)
  %t110 = extractvalue { i32, ptr } %t109, 1
  %t111 = extractvalue { i32, ptr } %t109, 0
  store i32 %t111, ptr %l67
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb27, label %ok.113
ok.113:
  store ptr %t110, ptr %l66
  br label %bb26
bb26:
  %t114 = load ptr, ptr %l66, !tbaa !29
  store ptr %t114, ptr %l59, !tbaa !29
  br label %bb28
bb27:
  %t115 = load i32, ptr %l67, !tbaa !23
  %t116 = lshr i32 %t115, 16
  %t117 = and i32 %t115, 65535
  %t118 = icmp eq i32 %t116, 1
  %t119 = select i1 %t118, i32 1, i32 0
  %t120 = icmp eq i32 %t115, 0
  %t121 = shl i32 %t119, 16
  %t122 = or i32 %t121, %t117
  %t123 = select i1 %t120, i32 0, i32 %t122
  call void @__olang_scope_close(ptr %s1)
  %t125 = insertvalue { i32, ptr } zeroinitializer, i32 %t123, 0
  store { i32, ptr } %t125, ptr %rv
  br label %ret
bb28:
  %t126 = load ptr, ptr %l59, !tbaa !29
  store ptr %t126, ptr %l4, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/parse:Parser", ptr %t127, i32 0, i32 15
  store i1 true, ptr %t129, !tbaa !21
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t130)
  %t133 = extractvalue { i32, { i64, ptr } } %t132, 1
  %t134 = extractvalue { i32, { i64, ptr } } %t132, 0
  store i32 %t134, ptr %l73
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb30, label %ok.136
ok.136:
  store { i64, ptr } %t133, ptr %l72
  br label %bb29
bb29:
  %t137 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t137, ptr %l70, !tbaa !27
  br label %bb31
bb30:
  %t138 = load i32, ptr %l73, !tbaa !23
  %t139 = lshr i32 %t138, 16
  %t140 = and i32 %t138, 65535
  %t141 = icmp eq i32 %t139, 1
  %t142 = select i1 %t141, i32 1, i32 0
  %t143 = icmp eq i32 %t138, 0
  %t144 = shl i32 %t142, 16
  %t145 = or i32 %t144, %t140
  %t146 = select i1 %t143, i32 0, i32 %t145
  call void @__olang_scope_close(ptr %s1)
  %t148 = insertvalue { i32, ptr } zeroinitializer, i32 %t146, 0
  store { i32, ptr } %t148, ptr %rv
  br label %ret
bb31:
  %t149 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t149, ptr %l5, !tbaa !27
  %t150 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t150, ptr %l75
  br label %bb32
bb32:
  %t151 = load %"compiler/source:Span", ptr %l75
  store %"compiler/source:Span" %t151, ptr %l6
  %t152 = icmp sge i64 0, 0
  br i1 %t152, label %bb33, label %bb34
bb33:
  %t154 = icmp sle i64 0, 1152921504606846975
  br i1 %t154, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_1539ac39f97600b_6c3b4513fd4221cf)
  unreachable
bb35:
  %t156 = mul i64 0, 8
  %t157 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 0, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l7, !tbaa !27
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t164 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t161, i32 42)
  store i1 %t164, ptr %l81
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_1539ac39f97600b_6c3b4513fd4221cf)
  unreachable
bb37:
  %t165 = load i1, ptr %l81, !tbaa !21
  br i1 %t165, label %bb38, label %bb39
bb38:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t166)
  store i32 %t168, ptr %l83
  br label %bb40
bb39:
  br label %bb45
bb40:
  %t169 = load i32, ptr %l83, !tbaa !23
  store i32 %t169, ptr %l8, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t170)
  %t173 = extractvalue { i32, { i64, ptr } } %t172, 1
  %t174 = extractvalue { i32, { i64, ptr } } %t172, 0
  store i32 %t174, ptr %l87
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb42, label %ok.176
ok.176:
  store { i64, ptr } %t173, ptr %l86
  br label %bb41
bb41:
  %t177 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t177, ptr %l84, !tbaa !27
  br label %bb43
bb42:
  %t178 = load i32, ptr %l87, !tbaa !23
  %t179 = lshr i32 %t178, 16
  %t180 = and i32 %t178, 65535
  %t181 = icmp eq i32 %t179, 1
  %t182 = select i1 %t181, i32 1, i32 0
  %t183 = icmp eq i32 %t178, 0
  %t184 = shl i32 %t182, 16
  %t185 = or i32 %t184, %t180
  %t186 = select i1 %t183, i32 0, i32 %t185
  call void @__olang_scope_close(ptr %s1)
  %t188 = insertvalue { i32, ptr } zeroinitializer, i32 %t186, 0
  store { i32, ptr } %t188, ptr %rv
  br label %ret
bb43:
  %t189 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t189, ptr %l7, !tbaa !27
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l8, !tbaa !23
  %t194 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t190, i32 %t191)
  store %"compiler/source:Span" %t194, ptr %l91
  br label %bb44
bb44:
  %t195 = load %"compiler/source:Span", ptr %l91
  store %"compiler/source:Span" %t195, ptr %l6
  br label %bb45
bb45:
  %t196 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t197 = load ptr, ptr %l4, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t200 = load %"compiler/source:Span", ptr %l6
  %t201 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t209 = call %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t196, ptr %t197, { i64, ptr } %t199, %"compiler/source:Span" %t200, { i64, ptr } %t201, { i64, ptr } %t202)
  store %"compiler/ast:StructBody" %t209, ptr %l99
  br label %bb46
bb46:
  %t210 = load %"compiler/ast:StructBody", ptr %l99
  %t211 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store %"compiler/ast:StructBody" %t210, ptr %t211
  store { i64, [6 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [6 x i64] }, ptr %t212, i32 0, i32 0
  store i64 0, ptr %t213
  %t215 = insertvalue { ptr } undef, ptr %t211, 0
  %t216 = getelementptr { i64, [6 x i64] }, ptr %t212, i32 0, i32 1
  store { ptr } %t215, ptr %t216
  %t217 = load { i64, [6 x i64] }, ptr %t212
  %t219 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t217, ptr %t219
  call void @__olang_scope_close(ptr %s1)
  %t221 = insertvalue { i32, ptr } zeroinitializer, ptr %t219, 1
  store { i32, ptr } %t221, ptr %rv
  br label %ret
bb47:
  %t222 = load i32, ptr %l1
  %t224 = trunc i64 35 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb109
bb50:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t227)
  store i32 %t229, ptr %l106
  br label %bb51
bb51:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t233 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t230, i32 92)
  %t234 = extractvalue { i32, i32 } %t233, 1
  %t235 = extractvalue { i32, i32 } %t233, 0
  store i32 %t235, ptr %l111
  %t236 = icmp ne i32 %t235, 0
  br i1 %t236, label %bb53, label %ok.237
ok.237:
  store i32 %t234, ptr %l110
  br label %bb52
bb52:
  %t238 = load i32, ptr %l110, !tbaa !23
  store i32 %t238, ptr %l107, !tbaa !23
  br label %bb54
bb53:
  %t239 = load i32, ptr %l111, !tbaa !23
  %t240 = lshr i32 %t239, 16
  %t241 = and i32 %t239, 65535
  %t242 = icmp eq i32 %t240, 1
  %t243 = select i1 %t242, i32 1, i32 0
  %t244 = icmp eq i32 %t239, 0
  %t245 = shl i32 %t243, 16
  %t246 = or i32 %t245, %t241
  %t247 = select i1 %t244, i32 0, i32 %t246
  %t249 = insertvalue { i32, ptr } zeroinitializer, i32 %t247, 0
  store { i32, ptr } %t249, ptr %rv
  br label %ret
bb54:
  %t250 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aCaseDecl_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t250, ptr %l113
  br label %bb55
bb55:
  %t251 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l113
  %t252 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t251, ptr %t252
  store ptr %t252, ptr %l9, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t254)
  br label %bb56
bb56:
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s5
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t259 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t256, i32 93)
  store i1 %t259, ptr %l118
  br label %bb58
bb58:
  %t260 = load i1, ptr %l118, !tbaa !21
  %t261 = xor i1 %t260, true
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s5)
  br label %bb106
bb60:
  br label %bb61
bb61:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t265)
  store i32 %t267, ptr %l122
  br label %bb62
bb62:
  %t268 = load i32, ptr %l122, !tbaa !23
  store i32 %t268, ptr %l10, !tbaa !23
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t269)
  %t272 = extractvalue { i32, i32 } %t271, 1
  %t273 = extractvalue { i32, i32 } %t271, 0
  store i32 %t273, ptr %l126
  %t274 = icmp ne i32 %t273, 0
  br i1 %t274, label %bb64, label %ok.275
ok.275:
  store i32 %t272, ptr %l125
  br label %bb63
bb63:
  %t276 = load i32, ptr %l125, !tbaa !23
  store i32 %t276, ptr %l123, !tbaa !23
  br label %bb65
bb64:
  %t277 = load i32, ptr %l126, !tbaa !23
  %t278 = lshr i32 %t277, 16
  %t279 = and i32 %t277, 65535
  %t280 = icmp eq i32 %t278, 1
  %t281 = select i1 %t280, i32 1, i32 0
  %t282 = icmp eq i32 %t277, 0
  %t283 = shl i32 %t281, 16
  %t284 = or i32 %t283, %t279
  %t285 = select i1 %t282, i32 0, i32 %t284
  call void @__olang_scope_close(ptr %s5)
  %t287 = insertvalue { i32, ptr } zeroinitializer, i32 %t285, 0
  store { i32, ptr } %t287, ptr %rv
  br label %ret
bb65:
  %t288 = load i32, ptr %l123, !tbaa !23
  store i32 %t288, ptr %l11, !tbaa !23
  %t289 = icmp sge i64 0, 0
  br i1 %t289, label %bb66, label %bb67
bb66:
  %t291 = icmp sle i64 0, 1152921504606846975
  br i1 %t291, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_17377aefad64a2a8_5cc0f861968a066c)
  unreachable
bb68:
  %t293 = mul i64 0, 8
  %t294 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t293)
  %t295 = insertvalue { i64, ptr } undef, i64 0, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  store { i64, ptr } %t296, ptr %l12, !tbaa !27
  store i1 false, ptr %l13, !tbaa !21
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t301 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t298, i32 88)
  store i1 %t301, ptr %l133
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_17377aefad64a2a8_5cc0f861968a066c)
  unreachable
bb70:
  %t302 = load i1, ptr %l133, !tbaa !21
  br i1 %t302, label %bb71, label %bb72
bb71:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %t303, i1 false)
  %t306 = extractvalue { i32, { i64, ptr } } %t305, 1
  %t307 = extractvalue { i32, { i64, ptr } } %t305, 0
  store i32 %t307, ptr %l137
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb74, label %ok.309
ok.309:
  store { i64, ptr } %t306, ptr %l136
  br label %bb73
bb72:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t313 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t310, i32 55)
  store i1 %t313, ptr %l141
  br label %bb76
bb73:
  %t314 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t314, ptr %l134, !tbaa !27
  br label %bb75
bb74:
  %t315 = load i32, ptr %l137, !tbaa !23
  %t316 = lshr i32 %t315, 16
  %t317 = and i32 %t315, 65535
  %t318 = icmp eq i32 %t316, 1
  %t319 = select i1 %t318, i32 1, i32 0
  %t320 = icmp eq i32 %t315, 0
  %t321 = shl i32 %t319, 16
  %t322 = or i32 %t321, %t317
  %t323 = select i1 %t320, i32 0, i32 %t322
  call void @__olang_scope_close(ptr %s5)
  %t325 = insertvalue { i32, ptr } zeroinitializer, i32 %t323, 0
  store { i32, ptr } %t325, ptr %rv
  br label %ret
bb75:
  %t326 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t326, ptr %l12, !tbaa !27
  br label %bb98
bb76:
  %t327 = load i1, ptr %l141, !tbaa !21
  %t328 = xor i1 %t327, true
  br i1 %t328, label %bb77, label %bb78
bb77:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t333 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t330, i32 8)
  store i1 %t333, ptr %l146
  br label %bb79
bb78:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb80
bb79:
  %t334 = load i1, ptr %l146, !tbaa !21
  %t335 = xor i1 %t334, true
  store i1 %t335, ptr %l143, !tbaa !21
  br label %bb80
bb80:
  %t337 = load i1, ptr %l143, !tbaa !21
  br i1 %t337, label %bb81, label %bb82
bb81:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t341 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t338, i32 93)
  store i1 %t341, ptr %l151
  br label %bb83
bb82:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb84
bb83:
  %t342 = load i1, ptr %l151, !tbaa !21
  %t343 = xor i1 %t342, true
  store i1 %t343, ptr %l148, !tbaa !21
  br label %bb84
bb84:
  %t345 = load i1, ptr %l148, !tbaa !21
  br i1 %t345, label %bb85, label %bb86
bb85:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t349 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t346, i32 0)
  store i1 %t349, ptr %l156
  br label %bb87
bb86:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb88
bb87:
  %t350 = load i1, ptr %l156, !tbaa !21
  %t351 = xor i1 %t350, true
  store i1 %t351, ptr %l153, !tbaa !21
  br label %bb88
bb88:
  %t353 = load i1, ptr %l153, !tbaa !21
  br i1 %t353, label %bb89, label %bb90
bb89:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t354)
  store i32 %t356, ptr %l159
  br label %bb91
bb90:
  br label %bb97
bb91:
  %t357 = load i32, ptr %l159, !tbaa !23
  store i32 %t357, ptr %l14, !tbaa !23
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t358)
  %t361 = extractvalue { i32, ptr } %t360, 1
  %t362 = extractvalue { i32, ptr } %t360, 0
  store i32 %t362, ptr %l163
  %t363 = icmp ne i32 %t362, 0
  br i1 %t363, label %bb93, label %ok.364
ok.364:
  store ptr %t361, ptr %l162
  br label %bb92
bb92:
  %t365 = load ptr, ptr %l162, !tbaa !29
  store ptr %t365, ptr %l160, !tbaa !29
  br label %bb94
bb93:
  %t366 = load i32, ptr %l163, !tbaa !23
  %t367 = lshr i32 %t366, 16
  %t368 = and i32 %t366, 65535
  %t369 = icmp eq i32 %t367, 1
  %t370 = select i1 %t369, i32 1, i32 0
  %t371 = icmp eq i32 %t366, 0
  %t372 = shl i32 %t370, 16
  %t373 = or i32 %t372, %t368
  %t374 = select i1 %t371, i32 0, i32 %t373
  call void @__olang_scope_close(ptr %s5)
  %t376 = insertvalue { i32, ptr } zeroinitializer, i32 %t374, 0
  store { i32, ptr } %t376, ptr %rv
  br label %ret
bb94:
  %t377 = load ptr, ptr %l160, !tbaa !29
  store ptr %t377, ptr %l15, !tbaa !29
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l14, !tbaa !23
  %t382 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t378, i32 %t379)
  store %"compiler/source:Span" %t382, ptr %l167
  br label %bb95
bb95:
  %t383 = load i32, ptr %l11, !tbaa !23
  %t384 = load ptr, ptr %l15, !tbaa !29
  %t386 = load %"compiler/source:Span", ptr %l167
  %t389 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t386, i32 %t383, ptr %t384, ptr null)
  store %"compiler/ast:Param" %t389, ptr %l171
  br label %bb96
bb96:
  %t390 = load %"compiler/ast:Param", ptr %l171
  %t391 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Param" %t390, ptr %t391
  %t393 = insertvalue [1 x ptr] undef, ptr %t391, 0
  %t395 = load ptr, ptr @__olang_prog_scope
  %t396 = call ptr @__olang_scope_alloc(ptr %t395, i64 8)
  store [1 x ptr] %t393, ptr %t396
  %t397 = insertvalue { i64, ptr } undef, i64 1, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t400 = extractvalue { i64, ptr } %t398, 0
  %t401 = extractvalue { i64, ptr } %t398, 1
  %t402 = mul i64 %t400, 8
  %t403 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t402)
  call void @llvm.memcpy.p0.p0.i64(ptr %t403, ptr %t401, i64 %t402, i1 false)
  %t404 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  store { i64, ptr } %t405, ptr %l12, !tbaa !27
  store i1 true, ptr %l13, !tbaa !21
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t407 = load ptr, ptr %l9, !tbaa !29
  store ptr %t407, ptr %l176, !tbaa !29
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load i32, ptr %l10, !tbaa !23
  %t412 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t408, i32 %t409)
  store %"compiler/source:Span" %t412, ptr %l179
  br label %bb99
bb99:
  %t413 = load i32, ptr %l11, !tbaa !23
  %t414 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t415 = load i1, ptr %l13, !tbaa !21
  %t416 = load %"compiler/source:Span", ptr %l179
  %t420 = call %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t416, i32 %t413, { i64, ptr } %t414, i1 %t415)
  store %"compiler/ast:CaseDecl" %t420, ptr %l183
  br label %bb100
bb100:
  %t421 = load %"compiler/ast:CaseDecl", ptr %l183
  %t422 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:CaseDecl" %t421, ptr %t422
  %t423 = load ptr, ptr %l176, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCaseDecl_26_3e_2eP_Hac49d5e46df3e44965095ee011894e38(ptr %v0, ptr %v0, ptr %t423, ptr %t422)
  br label %bb101
bb101:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t425)
  store i32 %t427, ptr %l186
  %t428 = icmp ne i32 %t427, 0
  br i1 %t428, label %bb103, label %ok.429
ok.429:
  br label %bb102
bb102:
  br label %bb104
bb103:
  %t430 = load i32, ptr %l186, !tbaa !23
  %t431 = lshr i32 %t430, 16
  %t432 = and i32 %t430, 65535
  %t433 = icmp eq i32 %t431, 1
  %t434 = select i1 %t433, i32 1, i32 0
  %t435 = icmp eq i32 %t430, 0
  %t436 = shl i32 %t434, 16
  %t437 = or i32 %t436, %t432
  %t438 = select i1 %t435, i32 0, i32 %t437
  call void @__olang_scope_close(ptr %s5)
  %t440 = insertvalue { i32, ptr } zeroinitializer, i32 %t438, 0
  store { i32, ptr } %t440, ptr %rv
  br label %ret
bb104:
  call void @__olang_scope_close(ptr %s5)
  br label %bb105
bb105:
  br label %bb57
bb106:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t441)
  store i32 %t443, ptr %l189
  br label %bb107
bb107:
  %t444 = load ptr, ptr %l9, !tbaa !29
  %t446 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCaseDecl_26_3e_2eT_Hf31095eea39f139de74728895711bde1(ptr %v0, ptr %v0, ptr %t444)
  store { i64, ptr } %t446, ptr %l191
  br label %bb108
bb108:
  store { i64, [6 x i64] } zeroinitializer, ptr %t447
  %t448 = getelementptr { i64, [6 x i64] }, ptr %t447, i32 0, i32 0
  store i64 1, ptr %t448
  %t449 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t450 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t449, 0
  %t451 = getelementptr { i64, [6 x i64] }, ptr %t447, i32 0, i32 1
  store { { i64, ptr } } %t450, ptr %t451
  %t452 = load { i64, [6 x i64] }, ptr %t447
  %t454 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t452, ptr %t454
  %t456 = insertvalue { i32, ptr } zeroinitializer, ptr %t454, 1
  store { i32, ptr } %t456, ptr %rv
  br label %ret
bb109:
  %t457 = load i32, ptr %l1
  %t459 = trunc i64 36 to i32
  %t460 = icmp eq i32 %t457, %t459
  br i1 %t460, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb163
bb112:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t462)
  store i32 %t464, ptr %l197
  br label %bb113
bb113:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t468 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %t465, i32 21)
  %t469 = extractvalue { i32, { i64, ptr } } %t468, 1
  %t470 = extractvalue { i32, { i64, ptr } } %t468, 0
  store i32 %t470, ptr %l202
  %t471 = icmp ne i32 %t470, 0
  br i1 %t471, label %bb115, label %ok.472
ok.472:
  store { i64, ptr } %t469, ptr %l201
  br label %bb114
bb114:
  %t473 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t473, ptr %l198, !tbaa !27
  br label %bb116
bb115:
  %t474 = load i32, ptr %l202, !tbaa !23
  %t475 = lshr i32 %t474, 16
  %t476 = and i32 %t474, 65535
  %t477 = icmp eq i32 %t475, 1
  %t478 = select i1 %t477, i32 1, i32 0
  %t479 = icmp eq i32 %t474, 0
  %t480 = shl i32 %t478, 16
  %t481 = or i32 %t480, %t476
  %t482 = select i1 %t479, i32 0, i32 %t481
  %t484 = insertvalue { i32, ptr } zeroinitializer, i32 %t482, 0
  store { i32, ptr } %t484, ptr %rv
  br label %ret
bb116:
  %t485 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t485, ptr %l16, !tbaa !27
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t489 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %t486, i32 24)
  %t490 = extractvalue { i32, { i64, ptr } } %t489, 1
  %t491 = extractvalue { i32, { i64, ptr } } %t489, 0
  store i32 %t491, ptr %l208
  %t492 = icmp ne i32 %t491, 0
  br i1 %t492, label %bb118, label %ok.493
ok.493:
  store { i64, ptr } %t490, ptr %l207
  br label %bb117
bb117:
  %t494 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t494, ptr %l204, !tbaa !27
  br label %bb119
bb118:
  %t495 = load i32, ptr %l208, !tbaa !23
  %t496 = lshr i32 %t495, 16
  %t497 = and i32 %t495, 65535
  %t498 = icmp eq i32 %t496, 1
  %t499 = select i1 %t498, i32 1, i32 0
  %t500 = icmp eq i32 %t495, 0
  %t501 = shl i32 %t499, 16
  %t502 = or i32 %t501, %t497
  %t503 = select i1 %t500, i32 0, i32 %t502
  %t505 = insertvalue { i32, ptr } zeroinitializer, i32 %t503, 0
  store { i32, ptr } %t505, ptr %rv
  br label %ret
bb119:
  %t506 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t506, ptr %l17, !tbaa !27
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t510 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t507, i32 92)
  %t511 = extractvalue { i32, i32 } %t510, 1
  %t512 = extractvalue { i32, i32 } %t510, 0
  store i32 %t512, ptr %l214
  %t513 = icmp ne i32 %t512, 0
  br i1 %t513, label %bb121, label %ok.514
ok.514:
  store i32 %t511, ptr %l213
  br label %bb120
bb120:
  %t515 = load i32, ptr %l213, !tbaa !23
  store i32 %t515, ptr %l210, !tbaa !23
  br label %bb122
bb121:
  %t516 = load i32, ptr %l214, !tbaa !23
  %t517 = lshr i32 %t516, 16
  %t518 = and i32 %t516, 65535
  %t519 = icmp eq i32 %t517, 1
  %t520 = select i1 %t519, i32 1, i32 0
  %t521 = icmp eq i32 %t516, 0
  %t522 = shl i32 %t520, 16
  %t523 = or i32 %t522, %t518
  %t524 = select i1 %t521, i32 0, i32 %t523
  %t526 = insertvalue { i32, ptr } zeroinitializer, i32 %t524, 0
  store { i32, ptr } %t526, ptr %rv
  br label %ret
bb122:
  %t527 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aFunc_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t527, ptr %l216
  br label %bb123
bb123:
  %t528 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l216
  %t529 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t528, ptr %t529
  store ptr %t529, ptr %l18, !tbaa !29
  %t531 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t531)
  br label %bb124
bb124:
  br label %bb125
bb125:
  store %olang.scope zeroinitializer, ptr %s10
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t536 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t533, i32 93)
  store i1 %t536, ptr %l221
  br label %bb126
bb126:
  %t537 = load i1, ptr %l221, !tbaa !21
  %t538 = xor i1 %t537, true
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s10)
  br label %bb160
bb128:
  br label %bb129
bb129:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t542)
  store i32 %t544, ptr %l225
  br label %bb130
bb130:
  %t545 = load i32, ptr %l225, !tbaa !23
  store i32 %t545, ptr %l19, !tbaa !23
  store ptr null, ptr %l20, !tbaa !29
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t549 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t546, i32 39)
  store i1 %t549, ptr %l228
  br label %bb131
bb131:
  %t550 = load i1, ptr %l228, !tbaa !21
  br i1 %t550, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s11
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t551)
  store %"compiler/token:Token" %t553, ptr %l230
  br label %bb134
bb133:
  br label %bb138
bb134:
  %t554 = load %"compiler/token:Token", ptr %l230
  store %"compiler/token:Token" %t554, ptr %l21
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t557 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t555)
  store i32 %t557, ptr %l232
  br label %bb135
bb135:
  %t558 = getelementptr %"compiler/token:Token", ptr %l21, i32 0, i32 2
  %t559 = load i32, ptr %t558, !tbaa !23
  %t560 = getelementptr %"compiler/token:Token", ptr %l21, i32 0, i32 3
  %t561 = load i32, ptr %t560, !tbaa !23
  %t564 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t559, i32 %t561)
  store %"compiler/source:Span" %t564, ptr %l235
  br label %bb136
bb136:
  %t565 = load %"compiler/source:Span", ptr %l235
  store %"compiler/source:Span" %t565, ptr %l22
  %t566 = load %"compiler/source:Span", ptr %l22
  %t567 = load %"compiler/source:Span", ptr %l22
  store { i64, [5 x i64] } zeroinitializer, ptr %t568
  %t569 = getelementptr { i64, [5 x i64] }, ptr %t568, i32 0, i32 0
  store i64 4, ptr %t569
  %t571 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t567, 0
  %t572 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t571, ptr null, 1
  %t573 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t572, i1 true, 2
  %t574 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t573, i1 false, 3
  %t575 = getelementptr { i64, [5 x i64] }, ptr %t568, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t574, ptr %t575
  %t576 = load { i64, [5 x i64] }, ptr %t568
  %t578 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t576, ptr %t578
  %t581 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t566, i32 0, ptr %t578, ptr null)
  store %"compiler/ast:Param" %t581, ptr %l240
  br label %bb137
bb137:
  %t582 = load %"compiler/ast:Param", ptr %l240
  %t583 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Param" %t582, ptr %t583
  store ptr %t583, ptr %l20, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  br label %bb138
bb138:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t585)
  %t588 = extractvalue { i32, i32 } %t587, 1
  %t589 = extractvalue { i32, i32 } %t587, 0
  store i32 %t589, ptr %l245
  %t590 = icmp ne i32 %t589, 0
  br i1 %t590, label %bb140, label %ok.591
ok.591:
  store i32 %t588, ptr %l244
  br label %bb139
bb139:
  %t592 = load i32, ptr %l244, !tbaa !23
  store i32 %t592, ptr %l242, !tbaa !23
  br label %bb141
bb140:
  %t593 = load i32, ptr %l245, !tbaa !23
  %t594 = lshr i32 %t593, 16
  %t595 = and i32 %t593, 65535
  %t596 = icmp eq i32 %t594, 1
  %t597 = select i1 %t596, i32 1, i32 0
  %t598 = icmp eq i32 %t593, 0
  %t599 = shl i32 %t597, 16
  %t600 = or i32 %t599, %t595
  %t601 = select i1 %t598, i32 0, i32 %t600
  call void @__olang_scope_close(ptr %s10)
  %t603 = insertvalue { i32, ptr } zeroinitializer, i32 %t601, 0
  store { i32, ptr } %t603, ptr %rv
  br label %ret
bb141:
  %t604 = load i32, ptr %l242, !tbaa !23
  store i32 %t604, ptr %l23, !tbaa !23
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t605, i1 false, i1 false, i1 false)
  %t608 = extractvalue { i32, ptr } %t607, 1
  %t609 = extractvalue { i32, ptr } %t607, 0
  store i32 %t609, ptr %l250
  %t610 = icmp ne i32 %t609, 0
  br i1 %t610, label %bb143, label %ok.611
ok.611:
  store ptr %t608, ptr %l249
  br label %bb142
bb142:
  %t612 = load ptr, ptr %l249, !tbaa !29
  store ptr %t612, ptr %l247, !tbaa !29
  br label %bb144
bb143:
  %t613 = load i32, ptr %l250, !tbaa !23
  %t614 = lshr i32 %t613, 16
  %t615 = and i32 %t613, 65535
  %t616 = icmp eq i32 %t614, 1
  %t617 = select i1 %t616, i32 1, i32 0
  %t618 = icmp eq i32 %t613, 0
  %t619 = shl i32 %t617, 16
  %t620 = or i32 %t619, %t615
  %t621 = select i1 %t618, i32 0, i32 %t620
  call void @__olang_scope_close(ptr %s10)
  %t623 = insertvalue { i32, ptr } zeroinitializer, i32 %t621, 0
  store { i32, ptr } %t623, ptr %rv
  br label %ret
bb144:
  %t624 = load ptr, ptr %l247, !tbaa !29
  store ptr %t624, ptr %l24, !tbaa !29
  %t625 = load ptr, ptr %l18, !tbaa !29
  store ptr %t625, ptr %l252, !tbaa !29
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load i32, ptr %l19, !tbaa !23
  %t630 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t626, i32 %t627)
  store %"compiler/source:Span" %t630, ptr %l255
  br label %bb145
bb145:
  %t631 = load ptr, ptr %l20, !tbaa !29
  store ptr %t631, ptr %l256, !tbaa !29
  %t632 = load i32, ptr %l23, !tbaa !23
  store i32 %t632, ptr %l257, !tbaa !23
  %t633 = load ptr, ptr %l24, !tbaa !29
  store ptr %t633, ptr %l258, !tbaa !29
  %t634 = icmp sge i64 0, 0
  br i1 %t634, label %bb146, label %bb147
bb146:
  %t636 = icmp sle i64 0, 1152921504606846975
  br i1 %t636, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb148:
  %t638 = mul i64 0, 8
  %t639 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t638)
  %t640 = insertvalue { i64, ptr } undef, i64 0, 0
  %t641 = insertvalue { i64, ptr } %t640, ptr %t639, 1
  store { i64, ptr } %t641, ptr %l261, !tbaa !27
  %t642 = icmp sge i64 0, 0
  br i1 %t642, label %bb150, label %bb151
bb149:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb150:
  %t644 = icmp sle i64 0, 1152921504606846975
  br i1 %t644, label %bb152, label %bb153
bb151:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb152:
  %t646 = mul i64 0, 8
  %t647 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t646)
  %t648 = insertvalue { i64, ptr } undef, i64 0, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t647, 1
  %t650 = load %"compiler/source:Span", ptr %l255
  %t651 = load ptr, ptr %l256, !tbaa !29
  %t652 = load i32, ptr %l257, !tbaa !23
  %t653 = load ptr, ptr %l258, !tbaa !29
  %t654 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t656 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t650, ptr %t651, i32 %t652, ptr %t653, { i64, ptr } %t654, { i64, ptr } %t649, i1 false)
  store %"compiler/ast:Func" %t656, ptr %l265
  br label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_2302adf5d350ae95_7d513dc9152d99f9)
  unreachable
bb154:
  %t657 = load %"compiler/ast:Func", ptr %l265
  %t658 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t657, ptr %t658
  %t659 = load ptr, ptr %l252, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aFunc_26_3e_2ePush_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v0, ptr %t659, ptr %t658)
  br label %bb155
bb155:
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t661)
  store i32 %t663, ptr %l268
  %t664 = icmp ne i32 %t663, 0
  br i1 %t664, label %bb157, label %ok.665
ok.665:
  br label %bb156
bb156:
  br label %bb158
bb157:
  %t666 = load i32, ptr %l268, !tbaa !23
  %t667 = lshr i32 %t666, 16
  %t668 = and i32 %t666, 65535
  %t669 = icmp eq i32 %t667, 1
  %t670 = select i1 %t669, i32 1, i32 0
  %t671 = icmp eq i32 %t666, 0
  %t672 = shl i32 %t670, 16
  %t673 = or i32 %t672, %t668
  %t674 = select i1 %t671, i32 0, i32 %t673
  call void @__olang_scope_close(ptr %s10)
  %t676 = insertvalue { i32, ptr } zeroinitializer, i32 %t674, 0
  store { i32, ptr } %t676, ptr %rv
  br label %ret
bb158:
  call void @__olang_scope_close(ptr %s10)
  br label %bb159
bb159:
  br label %bb125
bb160:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t679 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t677)
  store i32 %t679, ptr %l271
  br label %bb161
bb161:
  %t680 = load ptr, ptr %l18, !tbaa !29
  %t682 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aFunc_26_3e_2eToArray_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v0, ptr %t680)
  store { i64, ptr } %t682, ptr %l273
  br label %bb162
bb162:
  %t683 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t684 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t685
  %t686 = getelementptr { i64, [6 x i64] }, ptr %t685, i32 0, i32 0
  store i64 2, ptr %t686
  %t687 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t688 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t687, 0
  %t690 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t688, { i64, ptr } %t683, 1
  %t692 = insertvalue { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t690, { i64, ptr } %t684, 2
  %t693 = getelementptr { i64, [6 x i64] }, ptr %t685, i32 0, i32 1
  store { { i64, ptr }, { i64, ptr }, { i64, ptr } } %t692, ptr %t693
  %t694 = load { i64, [6 x i64] }, ptr %t685
  %t696 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t694, ptr %t696
  %t698 = insertvalue { i32, ptr } zeroinitializer, ptr %t696, 1
  store { i32, ptr } %t698, ptr %rv
  br label %ret
bb163:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t701 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t699)
  %t702 = extractvalue { i32, ptr } %t701, 1
  %t703 = extractvalue { i32, ptr } %t701, 0
  store i32 %t703, ptr %l281
  %t704 = icmp ne i32 %t703, 0
  br i1 %t704, label %bb165, label %ok.705
ok.705:
  store ptr %t702, ptr %l280
  br label %bb164
bb164:
  %t706 = load ptr, ptr %l280, !tbaa !29
  store ptr %t706, ptr %l278, !tbaa !29
  br label %bb166
bb165:
  %t707 = load i32, ptr %l281, !tbaa !23
  %t708 = lshr i32 %t707, 16
  %t709 = and i32 %t707, 65535
  %t710 = icmp eq i32 %t708, 1
  %t711 = select i1 %t710, i32 1, i32 0
  %t712 = icmp eq i32 %t707, 0
  %t713 = shl i32 %t711, 16
  %t714 = or i32 %t713, %t709
  %t715 = select i1 %t712, i32 0, i32 %t714
  %t717 = insertvalue { i32, ptr } zeroinitializer, i32 %t715, 0
  store { i32, ptr } %t717, ptr %rv
  br label %ret
bb166:
  %t718 = load ptr, ptr %l278, !tbaa !29
  store ptr %t718, ptr %l25, !tbaa !29
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t722 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t719, i32 88)
  store i1 %t722, ptr %l285
  br label %bb167
bb167:
  %t723 = load i1, ptr %l285, !tbaa !21
  br i1 %t723, label %bb168, label %bb169
bb168:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t726 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t724)
  store i32 %t726, ptr %l287
  br label %bb170
bb169:
  br label %bb202
bb170:
  %t727 = load i32, ptr %l287, !tbaa !23
  store i32 %t727, ptr %l26, !tbaa !23
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %t728, i1 false)
  %t731 = extractvalue { i32, { i64, ptr } } %t730, 1
  %t732 = extractvalue { i32, { i64, ptr } } %t730, 0
  store i32 %t732, ptr %l291
  %t733 = icmp ne i32 %t732, 0
  br i1 %t733, label %bb172, label %ok.734
ok.734:
  store { i64, ptr } %t731, ptr %l290
  br label %bb171
bb171:
  %t735 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t735, ptr %l288, !tbaa !27
  br label %bb173
bb172:
  %t736 = load i32, ptr %l291, !tbaa !23
  %t737 = lshr i32 %t736, 16
  %t738 = and i32 %t736, 65535
  %t739 = icmp eq i32 %t737, 1
  %t740 = select i1 %t739, i32 1, i32 0
  %t741 = icmp eq i32 %t736, 0
  %t742 = shl i32 %t740, 16
  %t743 = or i32 %t742, %t738
  %t744 = select i1 %t741, i32 0, i32 %t743
  %t746 = insertvalue { i32, ptr } zeroinitializer, i32 %t744, 0
  store { i32, ptr } %t746, ptr %rv
  br label %ret
bb173:
  %t747 = load { i64, ptr }, ptr %l288, !tbaa !27
  store { i64, ptr } %t747, ptr %l27, !tbaa !27
  %t748 = load ptr, ptr %l0, !tbaa !29
  store ptr %t748, ptr %l294, !tbaa !29
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t751 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %t749, i1 false)
  %t752 = extractvalue { i32, ptr } %t751, 1
  %t753 = extractvalue { i32, ptr } %t751, 0
  store i32 %t753, ptr %l298
  %t754 = icmp ne i32 %t753, 0
  br i1 %t754, label %bb175, label %ok.755
ok.755:
  store ptr %t752, ptr %l297
  br label %bb174
bb174:
  %t756 = load ptr, ptr %l297, !tbaa !29
  store ptr %t756, ptr %l295, !tbaa !29
  br label %bb176
bb175:
  %t757 = load i32, ptr %l298, !tbaa !23
  %t758 = lshr i32 %t757, 16
  %t759 = and i32 %t757, 65535
  %t760 = icmp eq i32 %t758, 1
  %t761 = select i1 %t760, i32 1, i32 0
  %t762 = icmp eq i32 %t757, 0
  %t763 = shl i32 %t761, 16
  %t764 = or i32 %t763, %t759
  %t765 = select i1 %t762, i32 0, i32 %t764
  %t767 = insertvalue { i32, ptr } zeroinitializer, i32 %t765, 0
  store { i32, ptr } %t767, ptr %rv
  br label %ret
bb176:
  %t768 = load ptr, ptr %l294, !tbaa !29
  %t769 = load ptr, ptr %l295, !tbaa !29
  %t770 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractOn(ptr %v0, ptr %t768, ptr %t769)
  %t771 = extractvalue { i32, ptr } %t770, 1
  %t772 = extractvalue { i32, ptr } %t770, 0
  store i32 %t772, ptr %l301
  %t773 = icmp ne i32 %t772, 0
  br i1 %t773, label %bb178, label %ok.774
ok.774:
  store ptr %t771, ptr %l300
  br label %bb177
bb177:
  %t775 = load ptr, ptr %l300, !tbaa !29
  store ptr %t775, ptr %l293, !tbaa !29
  br label %bb179
bb178:
  %t776 = load i32, ptr %l301, !tbaa !23
  %t777 = lshr i32 %t776, 16
  %t778 = and i32 %t776, 65535
  %t779 = icmp eq i32 %t777, 1
  %t780 = select i1 %t779, i32 1, i32 0
  %t781 = icmp eq i32 %t776, 0
  %t782 = shl i32 %t780, 16
  %t783 = or i32 %t782, %t778
  %t784 = select i1 %t781, i32 0, i32 %t783
  %t786 = insertvalue { i32, ptr } zeroinitializer, i32 %t784, 0
  store { i32, ptr } %t786, ptr %rv
  br label %ret
bb179:
  %t787 = load ptr, ptr %l293, !tbaa !29
  store ptr %t787, ptr %l28, !tbaa !29
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t790 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t788)
  %t791 = extractvalue { i32, { i64, ptr } } %t790, 1
  %t792 = extractvalue { i32, { i64, ptr } } %t790, 0
  store i32 %t792, ptr %l306
  %t793 = icmp ne i32 %t792, 0
  br i1 %t793, label %bb181, label %ok.794
ok.794:
  store { i64, ptr } %t791, ptr %l305
  br label %bb180
bb180:
  %t795 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t795, ptr %l303, !tbaa !27
  br label %bb182
bb181:
  %t796 = load i32, ptr %l306, !tbaa !23
  %t797 = lshr i32 %t796, 16
  %t798 = and i32 %t796, 65535
  %t799 = icmp eq i32 %t797, 1
  %t800 = select i1 %t799, i32 1, i32 0
  %t801 = icmp eq i32 %t796, 0
  %t802 = shl i32 %t800, 16
  %t803 = or i32 %t802, %t798
  %t804 = select i1 %t801, i32 0, i32 %t803
  %t806 = insertvalue { i32, ptr } zeroinitializer, i32 %t804, 0
  store { i32, ptr } %t806, ptr %rv
  br label %ret
bb182:
  %t807 = load { i64, ptr }, ptr %l303, !tbaa !27
  store { i64, ptr } %t807, ptr %l29, !tbaa !27
  %t808 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t808, ptr %l308, !tbaa !27
  %t809 = icmp sge i64 0, 0
  br i1 %t809, label %bb183, label %bb184
bb183:
  %t811 = icmp sle i64 0, 1152921504606846975
  br i1 %t811, label %bb185, label %bb186
bb184:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb185:
  %t813 = mul i64 0, 8
  %t814 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t813)
  %t815 = insertvalue { i64, ptr } undef, i64 0, 0
  %t816 = insertvalue { i64, ptr } %t815, ptr %t814, 1
  store { i64, ptr } %t816, ptr %l311, !tbaa !27
  %t817 = load ptr, ptr %l28, !tbaa !29
  %t819 = getelementptr %"compiler/ast:Sig", ptr %t817, i32 0, i32 2
  %t820 = load i1, ptr %t819, !tbaa !21
  store i1 %t820, ptr %l313, !tbaa !21
  %t821 = load ptr, ptr %l28, !tbaa !29
  %t823 = getelementptr %"compiler/ast:Sig", ptr %t821, i32 0, i32 3
  %t824 = load { i64, ptr }, ptr %t823, !tbaa !27
  store { i64, ptr } %t824, ptr %l315, !tbaa !27
  %t825 = icmp sge i64 0, 0
  br i1 %t825, label %bb187, label %bb188
bb186:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb187:
  %t827 = icmp sle i64 0, 2305843009213693951
  br i1 %t827, label %bb189, label %bb190
bb188:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb189:
  %t829 = mul i64 0, 4
  %t830 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t829)
  %t831 = insertvalue { i64, ptr } undef, i64 0, 0
  %t832 = insertvalue { i64, ptr } %t831, ptr %t830, 1
  store { i64, ptr } %t832, ptr %l318, !tbaa !27
  %t833 = icmp sge i64 0, 0
  br i1 %t833, label %bb191, label %bb192
bb190:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb191:
  %t835 = icmp sle i64 0, 1152921504606846975
  br i1 %t835, label %bb193, label %bb194
bb192:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb193:
  %t837 = mul i64 0, 8
  %t838 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t837)
  %t839 = insertvalue { i64, ptr } undef, i64 0, 0
  %t840 = insertvalue { i64, ptr } %t839, ptr %t838, 1
  %t841 = load ptr, ptr %l28, !tbaa !29
  %t843 = getelementptr %"compiler/ast:Sig", ptr %t841, i32 0, i32 7
  %t844 = load ptr, ptr %t843, !tbaa !29
  %t845 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t846 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t847 = load i1, ptr %l313, !tbaa !21
  %t848 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t849 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t852 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t845, { i64, ptr } %t846, i1 %t847, { i64, ptr } %t848, i1 false, { i64, ptr } %t849, { i64, ptr } %t840, ptr %t844)
  store %"compiler/ast:Sig" %t852, ptr %l324
  br label %bb195
bb194:
  call void @__olang_check_failed(ptr @olang_loc_46374d1b7bb67262_72dce1a2b91be04e)
  unreachable
bb195:
  %t853 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 104, i64 8)
  store ptr %t853, ptr %lp30
  %t854 = load %"compiler/ast:Sig", ptr %l324
  %t855 = load ptr, ptr %lp30
  store %"compiler/ast:Sig" %t854, ptr %t855
  %t856 = load ptr, ptr %l25, !tbaa !29
  store ptr %t856, ptr %l325, !tbaa !29
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t858 = load i32, ptr %l26, !tbaa !23
  %t861 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t857, i32 %t858)
  store %"compiler/source:Span" %t861, ptr %l328
  br label %bb196
bb196:
  %t862 = load ptr, ptr %lp30
  store ptr %t862, ptr %l329, !tbaa !29
  %t863 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t863, ptr %l330, !tbaa !27
  %t864 = icmp sge i64 0, 0
  br i1 %t864, label %bb197, label %bb198
bb197:
  %t866 = icmp sle i64 0, 1152921504606846975
  br i1 %t866, label %bb199, label %bb200
bb198:
  call void @__olang_check_failed(ptr @olang_loc_1c3aa98278e4117_19ec5e3b00828443)
  unreachable
bb199:
  %t868 = mul i64 0, 8
  %t869 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t868)
  %t870 = insertvalue { i64, ptr } undef, i64 0, 0
  %t871 = insertvalue { i64, ptr } %t870, ptr %t869, 1
  %t872 = load %"compiler/source:Span", ptr %l328
  %t873 = load ptr, ptr %l329, !tbaa !29
  %t874 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t876 = call %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t872, ptr null, i32 0, ptr %t873, { i64, ptr } %t874, { i64, ptr } %t871, i1 true)
  store %"compiler/ast:Func" %t876, ptr %l334
  br label %bb201
bb200:
  call void @__olang_check_failed(ptr @olang_loc_1c3aa98278e4117_19ec5e3b00828443)
  unreachable
bb201:
  %t877 = load %"compiler/ast:Func", ptr %l334
  %t878 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Func" %t877, ptr %t878
  store { i64, [6 x i64] } zeroinitializer, ptr %t879
  %t880 = getelementptr { i64, [6 x i64] }, ptr %t879, i32 0, i32 0
  store i64 3, ptr %t880
  %t881 = load ptr, ptr %l325, !tbaa !29
  %t882 = insertvalue { ptr, ptr } undef, ptr %t881, 0
  %t884 = insertvalue { ptr, ptr } %t882, ptr %t878, 1
  %t885 = getelementptr { i64, [6 x i64] }, ptr %t879, i32 0, i32 1
  store { ptr, ptr } %t884, ptr %t885
  %t886 = load { i64, [6 x i64] }, ptr %t879
  %t888 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t886, ptr %t888
  %t890 = insertvalue { i32, ptr } zeroinitializer, ptr %t888, 1
  store { i32, ptr } %t890, ptr %rv
  br label %ret
bb202:
  %t891 = load ptr, ptr %l25, !tbaa !29
  store { i64, [6 x i64] } zeroinitializer, ptr %t892
  %t893 = getelementptr { i64, [6 x i64] }, ptr %t892, i32 0, i32 0
  store i64 3, ptr %t893
  %t895 = insertvalue { ptr, ptr } undef, ptr %t891, 0
  %t896 = insertvalue { ptr, ptr } %t895, ptr null, 1
  %t897 = getelementptr { i64, [6 x i64] }, ptr %t892, i32 0, i32 1
  store { ptr, ptr } %t896, ptr %t897
  %t898 = load { i64, [6 x i64] }, ptr %t892
  %t900 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t898, ptr %t900
  %t902 = insertvalue { i32, ptr } zeroinitializer, ptr %t900, 1
  store { i32, ptr } %t902, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDecl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l14 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l28 = alloca %"compiler/ast:TypeDecl"
  %rv = alloca { i32, ptr }
  %t72 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 33)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l7
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l3, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t22)
  %t25 = extractvalue { i32, i32 } %t24, 1
  %t26 = extractvalue { i32, i32 } %t24, 0
  store i32 %t26, ptr %l12
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb5, label %ok.28
ok.28:
  store i32 %t25, ptr %l11
  br label %bb4
bb4:
  %t29 = load i32, ptr %l11, !tbaa !23
  store i32 %t29, ptr %l9, !tbaa !23
  br label %bb6
bb5:
  %t30 = load i32, ptr %l12, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb6:
  %t41 = load i32, ptr %l9, !tbaa !23
  store i32 %t41, ptr %l2, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t44 = load i32, ptr %l2, !tbaa !23
  %t48 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDeclRest(ptr %v0, ptr %t42, i32 %t43, i32 %t44)
  %t49 = extractvalue { i32, ptr } %t48, 1
  %t50 = extractvalue { i32, ptr } %t48, 0
  store i32 %t50, ptr %l19
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb8, label %ok.52
ok.52:
  store ptr %t49, ptr %l18
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l18, !tbaa !29
  store ptr %t53, ptr %l14, !tbaa !29
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/parse:Parser", ptr %t54, i32 0, i32 36
  store ptr %t56, ptr %l21, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t57, i32 %t58)
  store %"compiler/source:Span" %t61, ptr %l24
  br label %bb10
bb10:
  %t62 = load i32, ptr %l2, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 37
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t69 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t62, { i64, ptr } %t66, i1 false, ptr null)
  store %"compiler/ast:TypeDecl" %t69, ptr %l28
  br label %bb11
bb11:
  %t70 = load %"compiler/ast:TypeDecl", ptr %l28
  %t71 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:TypeDecl" %t70, ptr %t71
  store { i64, [4 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 0
  store i64 2, ptr %t73
  %t74 = load %"compiler/source:Span", ptr %l24
  %t75 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t74, 0
  %t77 = insertvalue { %"compiler/source:Span", ptr } %t75, ptr %t71, 1
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t77, ptr %t78
  %t79 = load { i64, [4 x i64] }, ptr %t72
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t79, ptr %t81
  %t82 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t82, ptr %t81)
  br label %bb12
bb12:
  %t85 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t85, ptr %rv
  br label %ret
bb13:
  %t86 = load ptr, ptr %l14, !tbaa !29
  %t87 = insertvalue { i32, ptr } zeroinitializer, ptr %t86, 1
  store { i32, ptr } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeDeclRest(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l26 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l35 = alloca %"compiler/source:Span"
  %l38 = alloca i1
  %l40 = alloca i32
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca %"compiler/ast:TypeDecl"
  %rv = alloca { i32, ptr }
  %t105 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = icmp sge i64 0, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 0, 1152921504606846975
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4)
  unreachable
bb3:
  %t6 = mul i64 0, 8
  %t7 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t6)
  %t8 = insertvalue { i64, ptr } undef, i64 0, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 37
  store { i64, ptr } %t9, ptr %t12, !tbaa !27
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4)
  unreachable
bb5:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a3bb9cce88491c55_2084ae246c483bc1)
  unreachable
bb7:
  %t17 = mul i64 0, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 77)
  store i1 %t25, ptr %l16
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a3bb9cce88491c55_2084ae246c483bc1)
  unreachable
bb9:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l20
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb13, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l19
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  br label %bb14
bb13:
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb14:
  %t46 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t46, ptr %l3, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 37
  store { i64, ptr } %t48, ptr %t51, !tbaa !27
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t52, i32 21)
  store i1 %t55, ptr %l26
  br label %bb16
bb16:
  %t56 = load i1, ptr %l26, !tbaa !21
  store i1 %t56, ptr %l4, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2escopeDecl(ptr %v0, ptr %t57)
  br label %bb17
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %t59)
  %t62 = extractvalue { i32, ptr } %t61, 1
  %t63 = extractvalue { i32, ptr } %t61, 0
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb19, label %ok.65
ok.65:
  store ptr %t62, ptr %l30
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l30, !tbaa !29
  store ptr %t66, ptr %l28, !tbaa !29
  br label %bb20
bb19:
  %t67 = load i32, ptr %l31, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, ptr } zeroinitializer, i32 %t75, 0
  store { i32, ptr } %t77, ptr %rv
  br label %ret
bb20:
  %t78 = load ptr, ptr %l28, !tbaa !29
  store ptr %t78, ptr %l5, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t83 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t79, i32 %a1)
  store %"compiler/source:Span" %t83, ptr %l35
  br label %bb21
bb21:
  %t84 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t84, ptr %l6
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 8)
  store i1 %t88, ptr %l38
  br label %bb22
bb22:
  %t89 = load i1, ptr %l38, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t90)
  store i32 %t92, ptr %l40
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t93 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t93, ptr %l41
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t96 = load i1, ptr %l4, !tbaa !21
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t102 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %a2, { i64, ptr } %t95, i1 %t96, ptr %t97)
  store %"compiler/ast:TypeDecl" %t102, ptr %l46
  br label %bb27
bb27:
  %t103 = load %"compiler/ast:TypeDecl", ptr %l46
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:TypeDecl" %t103, ptr %t104
  store { i64, [4 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t105, i32 0, i32 0
  store i64 2, ptr %t106
  %t107 = load %"compiler/source:Span", ptr %l41
  %t108 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t107, 0
  %t110 = insertvalue { %"compiler/source:Span", ptr } %t108, ptr %t104, 1
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t105, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t110, ptr %t111
  %t112 = load { i64, [4 x i64] }, ptr %t105
  %t114 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t112, ptr %t114
  %t116 = insertvalue { i32, ptr } zeroinitializer, ptr %t114, 1
  store { i32, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l20 = alloca i1
  %l23 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 %a1)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t11 = icmp sle i64 0, 1152921504606846975
  br i1 %t11, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2c29cc2313aef596_a74c39ade1a5acca)
  unreachable
bb6:
  %t13 = mul i64 0, 8
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  %t18 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t16, 1
  store { i32, { i64, ptr } } %t18, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2c29cc2313aef596_a74c39ade1a5acca)
  unreachable
bb8:
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l10
  br label %bb9
bb9:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %t21
  store ptr %t21, ptr %l2, !tbaa !29
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l12, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t24)
  %t27 = extractvalue { i32, ptr } %t26, 1
  %t28 = extractvalue { i32, ptr } %t26, 0
  store i32 %t28, ptr %l16
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb12, label %ok.30
ok.30:
  store ptr %t27, ptr %l15
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l15, !tbaa !29
  store ptr %t31, ptr %l13, !tbaa !29
  br label %bb13
bb12:
  %t32 = load i32, ptr %l16, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  call void @__olang_scope_close(ptr %s2)
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t40, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb13:
  %t43 = load ptr, ptr %l12, !tbaa !29
  %t44 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ePu_H3ee2e85b2a4851b98bd769b1572633fb(ptr %v0, ptr %v0, ptr %t43, ptr %t44)
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t48 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t45, i32 55)
  store i1 %t48, ptr %l20
  br label %bb15
bb15:
  %t49 = load i1, ptr %l20, !tbaa !21
  %t50 = xor i1 %t49, true
  br i1 %t50, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb10
bb20:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eTo_H4f2168e1c9bf42ebe84c301eff3fa7ab(ptr %v0, ptr %v0, ptr %t52)
  store { i64, ptr } %t54, ptr %l23
  br label %bb21
bb21:
  %t55 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t55, 1
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeParams(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca i32
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l50 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i32
  %l65 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l70 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/ast:TypeParam"
  %l75 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i32
  %l85 = alloca i32
  %l88 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l11
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l11, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t14, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 17
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l1, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 17
  store i1 false, ptr %t24, !tbaa !21
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeParam_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %t27
  store ptr %t27, ptr %l2, !tbaa !29
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t29)
  store i32 %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load i32, ptr %l19, !tbaa !23
  store i32 %t32, ptr %l3, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t33)
  %t36 = extractvalue { i32, i32 } %t35, 1
  %t37 = extractvalue { i32, i32 } %t35, 0
  store i32 %t37, ptr %l23
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb8, label %ok.39
ok.39:
  store i32 %t36, ptr %l22
  br label %bb7
bb7:
  %t40 = load i32, ptr %l22, !tbaa !23
  store i32 %t40, ptr %l20, !tbaa !23
  br label %bb9
bb8:
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = lshr i32 %t41, 16
  %t43 = and i32 %t41, 65535
  %t44 = icmp eq i32 %t42, 1
  %t45 = select i1 %t44, i32 1, i32 0
  %t46 = icmp eq i32 %t41, 0
  %t47 = shl i32 %t45, 16
  %t48 = or i32 %t47, %t43
  %t49 = select i1 %t46, i32 0, i32 %t48
  call void @__olang_scope_close(ptr %s1)
  %t51 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t49, 0
  store { i32, { i64, ptr } } %t51, ptr %rv
  br label %ret
bb9:
  %t52 = load i32, ptr %l20, !tbaa !23
  store i32 %t52, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 27
  %t56 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t55, i32 %t56)
  br label %bb10
bb10:
  store ptr null, ptr %l5, !tbaa !29
  %t59 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l28
  br label %bb11
bb11:
  %t60 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  %t61 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %t61
  store ptr %t61, ptr %l6, !tbaa !29
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t63, i32 55)
  store i1 %t66, ptr %l32
  br label %bb13
bb13:
  %t67 = load i1, ptr %l32, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t70, i32 8)
  store i1 %t73, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb17
bb16:
  %t74 = load i1, ptr %l37, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l34, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %t78)
  store i1 %t80, ptr %l41
  br label %bb20
bb19:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb21
bb20:
  %t81 = load i1, ptr %l41, !tbaa !21
  %t82 = xor i1 %t81, true
  store i1 %t82, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t84 = load i1, ptr %l39, !tbaa !21
  %t85 = xor i1 %t84, true
  br i1 %t85, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb23:
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 11
  %t90 = load i1, ptr %t89, !tbaa !21
  store i1 %t90, ptr %l7, !tbaa !21
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 18
  %t95 = load i1, ptr %t94, !tbaa !21
  store i1 %t95, ptr %l8, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Parser", ptr %t97, i32 0, i32 11
  store i1 true, ptr %t99, !tbaa !21
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/parse:Parser", ptr %t100, i32 0, i32 18
  store i1 true, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t103)
  %t106 = extractvalue { i32, ptr } %t105, 1
  %t107 = extractvalue { i32, ptr } %t105, 0
  store i32 %t107, ptr %l53
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb26, label %ok.109
ok.109:
  store ptr %t106, ptr %l52
  br label %bb25
bb25:
  %t110 = load ptr, ptr %l52, !tbaa !29
  store ptr %t110, ptr %l50, !tbaa !29
  br label %bb27
bb26:
  %t111 = load i32, ptr %l53, !tbaa !23
  %t112 = lshr i32 %t111, 16
  %t113 = and i32 %t111, 65535
  %t114 = icmp eq i32 %t112, 1
  %t115 = select i1 %t114, i32 1, i32 0
  %t116 = icmp eq i32 %t111, 0
  %t117 = shl i32 %t115, 16
  %t118 = or i32 %t117, %t113
  %t119 = select i1 %t116, i32 0, i32 %t118
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t121 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t119, 0
  store { i32, { i64, ptr } } %t121, ptr %rv
  br label %ret
bb27:
  %t122 = load ptr, ptr %l50, !tbaa !29
  store ptr %t122, ptr %l9, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i1, ptr %l7, !tbaa !21
  %t127 = getelementptr %"compiler/parse:Parser", ptr %t123, i32 0, i32 11
  store i1 %t124, ptr %t127, !tbaa !21
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i1, ptr %l8, !tbaa !21
  %t132 = getelementptr %"compiler/parse:Parser", ptr %t128, i32 0, i32 18
  store i1 %t129, ptr %t132, !tbaa !21
  %t133 = load ptr, ptr %l5, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  br i1 %t135, label %bb28, label %bb29
bb28:
  %t137 = load ptr, ptr %l9, !tbaa !29
  store ptr %t137, ptr %l5, !tbaa !29
  br label %bb31
bb29:
  %t140 = load ptr, ptr %l6, !tbaa !29
  %t141 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ePu_H3ee2e85b2a4851b98bd769b1572633fb(ptr %v0, ptr %v0, ptr %t140, ptr %t141)
  br label %bb30
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  br label %bb12
bb33:
  %t144 = load ptr, ptr %l2, !tbaa !29
  store ptr %t144, ptr %l65, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l3, !tbaa !23
  %t149 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t145, i32 %t146)
  store %"compiler/source:Span" %t149, ptr %l68
  br label %bb34
bb34:
  %t150 = load i32, ptr %l4, !tbaa !23
  store i32 %t150, ptr %l69, !tbaa !23
  %t151 = load ptr, ptr %l5, !tbaa !29
  store ptr %t151, ptr %l70, !tbaa !29
  %t152 = load ptr, ptr %l6, !tbaa !29
  %t154 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eTo_H4f2168e1c9bf42ebe84c301eff3fa7ab(ptr %v0, ptr %v0, ptr %t152)
  store { i64, ptr } %t154, ptr %l72
  br label %bb35
bb35:
  %t155 = load %"compiler/source:Span", ptr %l68
  %t156 = load i32, ptr %l69, !tbaa !23
  %t157 = load ptr, ptr %l70, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t159 = call %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t155, i32 %t156, ptr %t157, { i64, ptr } %t158)
  store %"compiler/ast:TypeParam" %t159, ptr %l73
  br label %bb36
bb36:
  %t160 = load %"compiler/ast:TypeParam", ptr %l73
  %t161 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:TypeParam" %t160, ptr %t161
  %t162 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeParam_26_3e_2e_H622427a16afa724df9ecb1a5411e43d7(ptr %v0, ptr %v0, ptr %t162, ptr %t161)
  br label %bb37
bb37:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t167 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t164, i32 79)
  %t168 = extractvalue { i32, i1 } %t167, 1
  %t169 = extractvalue { i32, i1 } %t167, 0
  store i32 %t169, ptr %l79
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb39, label %ok.171
ok.171:
  store i1 %t168, ptr %l78
  br label %bb38
bb38:
  %t172 = load i1, ptr %l78, !tbaa !21
  store i1 %t172, ptr %l75, !tbaa !21
  br label %bb40
bb39:
  %t173 = load i32, ptr %l79, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 1, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  call void @__olang_scope_close(ptr %s1)
  %t183 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t181, 0
  store { i32, { i64, ptr } } %t183, ptr %rv
  br label %ret
bb40:
  %t184 = load i1, ptr %l75, !tbaa !21
  %t185 = xor i1 %t184, true
  br i1 %t185, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s1)
  br label %bb44
bb44:
  br label %bb5
bb45:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i1, ptr %l1, !tbaa !21
  %t191 = getelementptr %"compiler/parse:Parser", ptr %t187, i32 0, i32 17
  store i1 %t188, ptr %t191, !tbaa !21
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %t192)
  store i32 %t194, ptr %l85
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb47, label %ok.196
ok.196:
  br label %bb46
bb46:
  br label %bb48
bb47:
  %t197 = load i32, ptr %l85, !tbaa !23
  %t198 = lshr i32 %t197, 16
  %t199 = and i32 %t197, 65535
  %t200 = icmp eq i32 %t198, 1
  %t201 = select i1 %t200, i32 1, i32 0
  %t202 = icmp eq i32 %t197, 0
  %t203 = shl i32 %t201, 16
  %t204 = or i32 %t203, %t199
  %t205 = select i1 %t202, i32 0, i32 %t204
  %t207 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t205, 0
  store { i32, { i64, ptr } } %t207, ptr %rv
  br label %ret
bb48:
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t210 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeParam_26_3e_2e_H199d2dad4eb2295b0ddf16d41b64b3d4(ptr %v0, ptr %v0, ptr %t208)
  store { i64, ptr } %t210, ptr %l88
  br label %bb49
bb49:
  %t211 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t212 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t211, 1
  store { i32, { i64, ptr } } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalues(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l23 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i1
  %l38 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = xor i1 %a2, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb4, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l8
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb5:
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t24, 1
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 28
  %t30 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l13
  br label %bb7
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 28
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t35)
  %t38 = extractvalue { i32, ptr } %t37, 1
  %t39 = extractvalue { i32, ptr } %t37, 0
  store i32 %t39, ptr %l19
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb10, label %ok.41
ok.41:
  store ptr %t38, ptr %l18
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l18, !tbaa !29
  store ptr %t42, ptr %l16, !tbaa !29
  br label %bb11
bb10:
  %t43 = load i32, ptr %l19, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 1, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  call void @__olang_scope_close(ptr %s2)
  %t53 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t51, 0
  store { i32, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb11:
  %t54 = load ptr, ptr %l15, !tbaa !29
  %t55 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t54, ptr %t55)
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 28
  %t60 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l23
  br label %bb13
bb13:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l23, !tbaa !24
  %t64 = sub i64 %t62, %t61
  %t67 = getelementptr %"compiler/parse:NameList", ptr %a1, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t64, %t70
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t78 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t75, i32 55)
  store i1 %t78, ptr %l33
  br label %bb16
bb16:
  %t79 = load i1, ptr %l33, !tbaa !21
  %t80 = xor i1 %t79, true
  store i1 %t80, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t82 = load i1, ptr %l30, !tbaa !21
  br i1 %t82, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb8
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 28
  %t86 = load i64, ptr %l3, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l38
  br label %bb23
bb23:
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l13 = alloca i32
  %l16 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l1
  store i32 %t4, ptr %l5
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l3, ptr %l5)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = load i32, ptr %l1
  %t14 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 %t12)
  store { i64, ptr } %t14, ptr %l11
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t24 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } %t21)
  store i32 %t24, ptr %l13
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb7, label %ok.26
ok.26:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t27 = load i32, ptr %l13, !tbaa !23
  %t28 = lshr i32 %t27, 16
  %t29 = and i32 %t27, 65535
  %t30 = icmp eq i32 %t28, 1
  %t31 = select i1 %t30, i32 1, i32 0
  %t32 = icmp eq i32 %t27, 0
  %t33 = shl i32 %t31, 16
  %t34 = or i32 %t33, %t29
  %t35 = select i1 %t32, i32 0, i32 %t34
  call void @__olang_scope_close(ptr %s1)
  %t37 = insertvalue { i32, i32 } zeroinitializer, i32 %t35, 0
  store { i32, i32 } %t37, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l16
  br label %bb10
bb10:
  %t41 = load i32, ptr %l16, !tbaa !23
  %t42 = insertvalue { i32, i32 } zeroinitializer, i32 %t41, 1
  store { i32, i32 } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i1 @compiler_2fparse_2eisJoiningOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 49 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb13
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 50 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 51 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 52 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 53 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 54 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb47
bb14:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 45 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb15, label %bb16
bb15:
  br label %bb29
bb16:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 46 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb17, label %bb18
bb17:
  br label %bb29
bb18:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 47 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb29
bb20:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 73 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 75 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 77 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 78 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb47
bb30:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 79 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb31, label %bb32
bb31:
  br label %bb45
bb32:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 80 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb33, label %bb34
bb33:
  br label %bb45
bb34:
  %t76 = load i32, ptr %l0
  %t78 = trunc i64 81 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb35, label %bb36
bb35:
  br label %bb45
bb36:
  %t81 = load i32, ptr %l0
  %t83 = trunc i64 82 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb37, label %bb38
bb37:
  br label %bb45
bb38:
  %t86 = load i32, ptr %l0
  %t88 = trunc i64 83 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  %t91 = load i32, ptr %l0
  %t93 = trunc i64 86 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb41, label %bb42
bb41:
  br label %bb45
bb42:
  %t96 = load i32, ptr %l0
  %t98 = trunc i64 87 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb47
bb47:
  %t101 = load i1, ptr %l1, !tbaa !21
  store i1 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb17
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t31 = load i32, ptr %l1
  %t33 = trunc i64 50 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = call i1 @compiler_2fparse_2eisLiteral(ptr %v0, ptr %t36)
  store i1 %t38, ptr %l20
  br label %bb14
bb13:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t39 = load i1, ptr %l20, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t40 = load i1, ptr %l18, !tbaa !21
  store i1 %t40, ptr %l3, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l3, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisOperandTail(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 1 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 89 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 91 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb14
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 15
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l14
  br label %bb12
bb12:
  %t28 = load i1, ptr %l14, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb14
bb14:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisWordKeyword(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  %t3 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 0
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t15)
  store i1 %t17, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  store i1 %t18, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l7, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load i32, ptr %l0
  %t22 = trunc i64 6 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  store i1 %t25, ptr %l11, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load i32, ptr %l0
  %t30 = trunc i64 7 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ekeywordNamesField(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 18 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb17
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 19 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 20 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 26 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 27 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 28 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 45 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 46 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb51
bb18:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 47 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb31
bb20:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 29 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 31 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 32 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 33 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 34 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb51
bb32:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 35 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb33, label %bb34
bb33:
  br label %bb43
bb34:
  %t76 = load i32, ptr %l0
  %t78 = trunc i64 36 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  %t81 = load i32, ptr %l0
  %t83 = trunc i64 21 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  %t86 = load i32, ptr %l0
  %t88 = trunc i64 40 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb39, label %bb40
bb39:
  br label %bb43
bb40:
  %t91 = load i32, ptr %l0
  %t93 = trunc i64 41 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb51
bb44:
  %t96 = load i32, ptr %l0
  %t98 = trunc i64 43 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  %t101 = load i32, ptr %l0
  %t103 = trunc i64 44 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb51
bb51:
  %t106 = load i1, ptr %l1, !tbaa !21
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca i64
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i64
  %l66 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t17, { i64, ptr } %t18)
  store { i64, ptr } %t22, ptr %l18
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  br label %bb48
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t25 = load ptr, ptr %l19, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 12
  store i1 %t31, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l20, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t35, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l29, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 0
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %t49, ptr %t50, { i64, ptr } %t51)
  store { i64, ptr } %t55, ptr %l33
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr @.d27 }, ptr %l28, !tbaa !27
  br label %bb16
bb15:
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 0
  %t58 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t56, i64 %t57)
  %t63 = getelementptr i8, ptr %t62, i64 %t57
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l28, !tbaa !27
  br label %bb16
bb16:
  %t74 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 1
  %t75 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 0
  %t76 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t74, i64 %t75)
  %t81 = getelementptr i8, ptr %t80, i64 %t75
  call void @olang_textcopy(ptr %t81, ptr %t77, i64 %t78)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  store { i64, ptr } %t83, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t86 = load ptr, ptr %l37, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load ptr, ptr %l37, !tbaa !29
  %t90 = load i64, ptr %t89
  %t92 = icmp eq i64 %t90, 1
  store i1 %t92, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t93 = load i1, ptr %l38, !tbaa !21
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", ptr }, ptr %t96, i32 0, i32 1
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb29
bb22:
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l45, !tbaa !24
  %t106 = load ptr, ptr %l5, !tbaa !29
  %t108 = getelementptr %"compiler/ast:VarDecl", ptr %t106, i32 0, i32 4
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 3, ptr @.d30 }, ptr %l48, !tbaa !27
  br label %bb25
bb24:
  store { i64, ptr } { i64 0, ptr @.d31 }, ptr %l48, !tbaa !27
  br label %bb25
bb25:
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr %"compiler/ast:VarDecl", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 6, ptr @.d32 }, ptr %l53, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 0, ptr @.d33 }, ptr %l53, !tbaa !27
  br label %bb28
bb28:
  %t120 = extractvalue { i64, ptr } { i64 3, ptr @.d34 }, 1
  %t121 = extractvalue { i64, ptr } { i64 3, ptr @.d34 }, 0
  %t122 = load i64, ptr %l45, !tbaa !24
  %t123 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t124 = add i64 %t121, %t123
  %t125 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = add i64 %t124, %t127
  %t129 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  %t135 = call i64 @__olang_fmt_i64(ptr %t134, i64 %t122)
  %t136 = getelementptr i8, ptr %t134, i64 %t123
  call void @olang_textcopy(ptr %t136, ptr %t126, i64 %t127)
  %t137 = getelementptr i8, ptr %t136, i64 %t127
  call void @olang_textcopy(ptr %t137, ptr %t130, i64 %t131)
  %t138 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t133, 1
  store { i64, ptr } %t139, ptr %l8, !tbaa !27
  br label %bb48
bb29:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t142 = load ptr, ptr %l55, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb30, label %bb31
bb30:
  %t145 = load ptr, ptr %l55, !tbaa !29
  %t146 = load i64, ptr %t145
  %t148 = icmp eq i64 %t146, 2
  store i1 %t148, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t149 = load i1, ptr %l56, !tbaa !21
  br i1 %t149, label %bb32, label %bb33
bb32:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr }, ptr %t152, i32 0, i32 1
  %t154 = load ptr, ptr %t153
  store ptr %t154, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t156 = load ptr, ptr %l6, !tbaa !29
  %t158 = getelementptr %"compiler/ast:Multi", ptr %t156, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  store i64 %t161, ptr %l63, !tbaa !24
  %t162 = load ptr, ptr %l6, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Multi", ptr %t162, i32 0, i32 1
  %t165 = load i1, ptr %t164, !tbaa !21
  br i1 %t165, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 2, ptr @.d35 }, ptr %l66, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 1, ptr @.d36 }, ptr %l66, !tbaa !27
  br label %bb37
bb37:
  %t167 = load ptr, ptr %l6, !tbaa !29
  %t169 = getelementptr %"compiler/ast:Multi", ptr %t167, i32 0, i32 2
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } { i64 5, ptr @.d37 }, 1
  %t174 = extractvalue { i64, ptr } { i64 5, ptr @.d37 }, 0
  %t175 = load i64, ptr %l63, !tbaa !24
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t177 = add i64 %t174, %t176
  %t178 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = add i64 %t177, %t180
  %t183 = call i64 @__olang_fmt_i64(ptr null, i64 %t172)
  %t184 = add i64 %t181, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t173, i64 %t174)
  %t186 = getelementptr i8, ptr %t185, i64 %t174
  %t187 = call i64 @__olang_fmt_i64(ptr %t186, i64 %t175)
  %t188 = getelementptr i8, ptr %t186, i64 %t176
  call void @olang_textcopy(ptr %t188, ptr %t179, i64 %t180)
  %t189 = getelementptr i8, ptr %t188, i64 %t180
  %t190 = call i64 @__olang_fmt_i64(ptr %t189, i64 %t172)
  %t191 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t185, 1
  store { i64, ptr } %t192, ptr %l8, !tbaa !27
  br label %bb48
bb38:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t195 = load ptr, ptr %l71, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb39, label %bb40
bb39:
  %t198 = load ptr, ptr %l71, !tbaa !29
  %t199 = load i64, ptr %t198
  %t201 = icmp eq i64 %t199, 5
  store i1 %t201, ptr %l72, !tbaa !21
  br label %bb40
bb40:
  %t202 = load i1, ptr %l72, !tbaa !21
  br i1 %t202, label %bb41, label %bb42
bb41:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr { i64, [5 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l7, !tbaa !29
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t209 = load ptr, ptr %l7, !tbaa !29
  %t211 = getelementptr %"compiler/ast:If", ptr %t209, i32 0, i32 2
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = icmp eq ptr %t212, null
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 5, ptr @.d38 }, ptr %l81, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr @.d39 }, ptr %l81, !tbaa !27
  br label %bb46
bb46:
  %t218 = extractvalue { i64, ptr } { i64 2, ptr @.d40 }, 1
  %t219 = extractvalue { i64, ptr } { i64 2, ptr @.d40 }, 0
  %t220 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = add i64 %t219, %t222
  %t224 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = getelementptr i8, ptr %t224, i64 %t219
  call void @olang_textcopy(ptr %t225, ptr %t221, i64 %t222)
  %t226 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t224, 1
  store { i64, ptr } %t227, ptr %l8, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 4, ptr @.d41 }, ptr %l83, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t229, ptr %l8, !tbaa !27
  br label %bb48
bb48:
  %t231 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l85, !tbaa !24
  %t233 = load i64, ptr %l85, !tbaa !24
  %t234 = mul i64 %t233, 1
  %t235 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t234)
  %t236 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  store { i64, ptr } %t237, ptr %l86, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = load i64, ptr %l85, !tbaa !24
  %t243 = mul i64 %t242, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t239, ptr %t241, i64 %t243, i1 false)
  %t244 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t244, ptr %l8, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t245, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/parse:Oracle"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l5
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %t7)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l6
  br label %bb3
bb3:
  %t9 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l2
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t10)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l7
  br label %bb4
bb4:
  %t12 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t14 = insertvalue %"compiler/parse:Oracle" undef, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 0
  %t15 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t16 = insertvalue %"compiler/parse:Oracle" %t14, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 1
  %t17 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t18 = insertvalue %"compiler/parse:Oracle" %t16, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 2
  %t20 = insertvalue %"compiler/parse:Oracle" %t18, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, 3
  store %"compiler/parse:Oracle" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:Oracle", ptr %rv
  ret %"compiler/parse:Oracle" %rr
}

define dso_local %"compiler/parse:stackMarks" @compiler_2fparse_3astackMarks_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %rv = alloca %"compiler/parse:stackMarks"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/parse:stackMarks" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/parse:stackMarks" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/parse:stackMarks" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/parse:stackMarks" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/parse:stackMarks" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/parse:stackMarks" %t24, i64 %a5, 5
  %t28 = insertvalue %"compiler/parse:stackMarks" %t26, i64 %a6, 6
  store %"compiler/parse:stackMarks" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:stackMarks", ptr %rv
  ret %"compiler/parse:stackMarks" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fparse() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fparse_2eMaxNesting_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
@.d0 = private constant [4 x i8] c"Bool"
@.d1 = private constant [5 x i8] c"Array"
@.d2 = private constant [2 x i8] c"I8"
@.d3 = private constant [3 x i8] c"I16"
@.d4 = private constant [3 x i8] c"I32"
@.d5 = private constant [3 x i8] c"I64"
@.d6 = private constant [2 x i8] c"U8"
@.d7 = private constant [3 x i8] c"U16"
@.d8 = private constant [3 x i8] c"U32"
@.d9 = private constant [3 x i8] c"U64"
@.d10 = private constant [3 x i8] c"F16"
@.d11 = private constant [4 x i8] c"BF16"
@.d12 = private constant [3 x i8] c"F32"
@.d13 = private constant [3 x i8] c"F64"
@.d14 = private constant [0 x i8] c""
@.d15 = private constant [1 x i8] c"."
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d16 = private constant [0 x i8] c""
@.d17 = private constant [1 x i8] c"."
@.d18 = private constant [13 x i8] c"a declaration"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d19 = private constant [13 x i8] c"a declaration"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d20 = private constant [0 x i8] c""
@.d21 = private constant [13 x i8] c"a declaration"
@.d22 = private constant [6 x i8] c"a join"
@.d23 = private constant [6 x i8] c"a name"
@.d24 = private constant [1 x i8] c"_"
@.d25 = private constant [44 x i8] c"an element type before the [, as in I32[...]"
@.d26 = private constant [13 x i8] c"an expression"
@.d27 = private constant [0 x i8] c""
@.d28 = private constant [1 x i8] c" "
@.d29 = private constant [6 x i8] c"return"
@.d30 = private constant [3 x i8] c" :="
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [6 x i8] c" typed"
@.d33 = private constant [0 x i8] c""
@.d34 = private constant [3 x i8] c"var"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d35 = private constant [2 x i8] c":="
@.d36 = private constant [1 x i8] c"="
@.d37 = private constant [5 x i8] c"multi"
@.d38 = private constant [5 x i8] c" else"
@.d39 = private constant [0 x i8] c""
@.d40 = private constant [2 x i8] c"if"
@.d41 = private constant [4 x i8] c"stmt"
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
@olang_loc_d732b4b75ca0d086_f16e80b591ad44e2 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eTru_He4c1b4b0580574c1753e0fdf1e83e9c5(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %v0, i32 %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %a0)
@olang_loc_3a014922d706f8ae_e8b2af70e71e377a = external constant [0 x i8]
declare %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e5b5865feda95523_92aca47b2e780ecf = external constant [0 x i8]
declare %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %a0)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
@olang_loc_1409caed80efd5ca_aa5da404b7edad6 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aCatch_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2ector(ptr %v0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2ePush_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e74fa2d3d14c2452_7ce0d57fd3650746 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPath_26_3e_2eToArray_3ccompiler_2fast_3aPath_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCatch_26_3e_2ePush_3ccompiler_2fast_3aCatch_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCatch_26_3e_2eToAr_He5e8e2567a6e85f3fd99cc3485ad491f(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_562ee49de0d7f4dc_ca929e902ecee878 = external constant [0 x i8]
declare %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aOutlives_26_3e_2ector(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlivesHere(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlives(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractItem(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aOutlives_26_3e_2eP_Hc29bd3cdf9acdad35b29137e924c1046(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aOutlives_26_3e_2eT_H8c6640c549d72ea52a64aaf5c359b5b4(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:ContractBlock" @compiler_2fast_3aContractBlock_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutlivesNested(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarListCount(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %a0, i1 %a1, i1 %a2, i1 %a3)
@olang_loc_acdf3c0d270865a2_ccca0ad6e9b656fe = external constant [0 x i8]
declare %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, ptr %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2df52f758a425120_e9eb2ffac7d00514 = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5)
@olang_loc_88b4df24f395cba0_7a8585039ef7582c = external constant [0 x i8]
@G_2ecompiler_2fparse_2eMaxNesting = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\4E\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %v0, i64 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_1981dec301b76378_38f305e42bd9bf3c = external constant [0 x i8]
@olang_loc_cd306f178609e3e5_44435844e9b3da89 = external constant [0 x i8]
@olang_loc_7f2178e2c302e3c6_11752dec4e05ebca = external constant [0 x i8]
declare %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4, { i64, ptr } %a5, { i64, ptr } %a6, ptr %a7)
@olang_loc_8f09c4a5443f675b_29c7c4947190fc9f = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExpected(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %a0, %"compiler/token:Token" %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2fmsgs_2eEndOfLine = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fmsgs_2eEndOfFile = external constant <{ [8 x i8], ptr }>
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_4c43f34f877e1376_ed14b5a1f1e9a1ea = external constant [0 x i8]
@olang_loc_b7532cf042be3d05_817bd3bc9b025111 = external constant [0 x i8]
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractOn(ptr %v0, ptr %a0, ptr %a1)
@olang_loc_79faa04a2077f0a8_b4c818f5d0d3035c = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_13a9b66eb9aa3f96_3dd1d0a593daf8ba = external constant [0 x i8]
@olang_loc_b5d05676e64fefab_5744e152e232520f = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %a0, ptr %a1)
@olang_loc_f067807cf96ff280_872aeb81d2c2c23c = external constant [0 x i8]
@olang_loc_882dfc00c36114e5_890842da0dcd92c9 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @compiler_2fparse_2eisOperandEndTok(i32 %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_3f19ed1436e26d3c_ab56bc721c08c978 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0)
declare { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %v0, i32 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_a66f16e9609fdd27_2fbef1e5bed159db = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eLe_H079a49ca86fbf0542fec862c08432034(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eLe_Hc3a9f67fd4028c52dcd01e744501edd7(ptr %v0, ptr %a0)
declare %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_56ae34a9066c1560_be19fd249755f1d4 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eTr_H502888c3fa90c24fa361ddb6e04085c1(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %a0)
@olang_loc_b6007e4d1245e4d6_5e9becbf0504ee4a = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_fd55a40e832939eb_76ee8367288fff1f = external constant [0 x i8]
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_f58c14e72eb20088_8619c4b6e2d8c1bc = external constant [0 x i8]
@olang_loc_c608f7f9cf1bb136_7782a31fde86d192 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eHas_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeDecl(ptr %v0)
declare i1 @compiler_2fparse_2eisAssignOp(i32 %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %a0)
@olang_loc_405430454c9e5d04_720bbb7e3dc9fd0 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eAt_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_52ee6a0603ddde11_c2fcf6abb1634cfd = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/msgs:Msg" %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %a0)
declare %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e980cdf5146ac576_c2415009b5e84a7a = external constant [0 x i8]
@olang_loc_1539ac39f97600b_6c3b4513fd4221cf = external constant [0 x i8]
declare %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aCaseDecl_26_3e_2ector(ptr %v0)
@olang_loc_17377aefad64a2a8_5cc0f861968a066c = external constant [0 x i8]
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
declare %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2, i1 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCaseDecl_26_3e_2eP_Hac49d5e46df3e44965095ee011894e38(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCaseDecl_26_3e_2eT_Hf31095eea39f139de74728895711bde1(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aFunc_26_3e_2ector(ptr %v0)
@olang_loc_2302adf5d350ae95_7d513dc9152d99f9 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aFunc_26_3e_2ePush_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aFunc_26_3e_2eToArray_3ccompiler_2fast_3aFunc_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_46374d1b7bb67262_72dce1a2b91be04e = external constant [0 x i8]
@olang_loc_1c3aa98278e4117_19ec5e3b00828443 = external constant [0 x i8]
declare %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
@olang_loc_411e8cbc479e6c68_8a93085e0dfe7db4 = external constant [0 x i8]
@olang_loc_a3bb9cce88491c55_2084ae246c483bc1 = external constant [0 x i8]
@olang_loc_2c29cc2313aef596_a74c39ade1a5acca = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ePu_H3ee2e85b2a4851b98bd769b1572633fb(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eTo_H4f2168e1c9bf42ebe84c301eff3fa7ab(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeParam_26_3e_2ector(ptr %v0)
declare %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeParam_26_3e_2e_H622427a16afa724df9ecb1a5411e43d7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeParam_26_3e_2e_H199d2dad4eb2295b0ddf16d41b64b3d4(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare void @compiler_2fparse_2eMaxNesting_2einit()
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
