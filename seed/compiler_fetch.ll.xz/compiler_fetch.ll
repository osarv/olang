; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>" }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
define dso_local { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr @.d0 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t6, ptr %l2
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d1 }, ptr %l5
  %t7 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t7, ptr %l6
  %t8 = load { i64, ptr }, ptr %l6
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l7
  %t15 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t15, ptr %l2
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t16, ptr %l0
  %t17 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t17, ptr %l8
  %t18 = load { i64, ptr }, ptr %l8
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 0, ptr @.d2 })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l10
  %t22 = load i1, ptr %l10
  br i1 %t22, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t23, ptr %l11
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t24 = load { i64, ptr }, ptr %l11
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  call void @__olang_sb_put(ptr %s2, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %s2
  %t28 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t29 = load i64, ptr %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t27, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l12
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t34 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr @.d3 })
  %t35 = extractvalue { i32, { i64, ptr } } %t34, 1
  %t36 = extractvalue { i32, { i64, ptr } } %t34, 0
  store i32 %t36, ptr %l15
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38
ok.38:
  store { i64, ptr } %t35, ptr %l14
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t39, ptr %l13
  br label %bb12
bb10:
  br label %bb11
bb11:
  store { i64, ptr } { i64 1, ptr @.d4 }, ptr %l16
  %t40 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t40, ptr %l17
  %t41 = load { i64, ptr }, ptr %l17
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l18
  %t48 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t48, ptr %l13
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t49, ptr %l1
  %t50 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t50, ptr %l19
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t51 = load { i64, ptr }, ptr %l19
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  call void @__olang_sb_put(ptr %s3, ptr %t52, i64 %t53)
  %t54 = extractvalue { i64, ptr } { i64 13, ptr @.d5 }, 1
  %t55 = extractvalue { i64, ptr } { i64 13, ptr @.d5 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t54, i64 %t55)
  %t56 = load ptr, ptr %s3
  %t57 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t58 = load i64, ptr %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t56, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l20
  call void @__olang_sb_done(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d6 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t6, ptr %l1
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d7 }, ptr %l4
  %t7 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t7, ptr %l5
  %t8 = load { i64, ptr }, ptr %l5
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l6
  %t15 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t15, ptr %l1
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t16, ptr %l0
  %t17 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t17, ptr %l7
  %t18 = load { i64, ptr }, ptr %l7
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 0, ptr @.d8 })
  store i1 %t19, ptr %l8
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l9
  %t22 = load i1, ptr %l9
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t23, ptr %l11
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t24 = load { i64, ptr }, ptr %l11
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  call void @__olang_sb_put(ptr %s1, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %s1
  %t28 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t29 = load i64, ptr %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t27, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l12
  call void @__olang_sb_done(ptr %s1)
  %t33 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t33, ptr %l10
  br label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr @.d9 }, ptr %l13
  %t34 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t34, ptr %l14
  %t35 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t35, ptr %l10
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffetch_2eIsCommit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i8
  %l23 = alloca i8
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i8
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i8
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l5
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l6
  %t4 = load i64, ptr %l6
  %t5 = icmp ne i64 %t4, 40
  store i1 %t5, ptr %l7
  %t6 = load i1, ptr %l7
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t7, ptr %l9
  %t8 = load { i64, ptr }, ptr %l9
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l10
  %t10 = load i64, ptr %l10
  %t11 = icmp ne i64 %t10, 64
  store i1 %t11, ptr %l11
  %t12 = load i1, ptr %l11
  store i1 %t12, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l8
  br label %bb3
bb3:
  %t13 = load i1, ptr %l8
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l12
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l12
  store i1 %t14, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t15, ptr %l13
  %t16 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t16, ptr %l1
  store i64 0, ptr %l2
  %t17 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t17, ptr %l14
  %t18 = load { i64, ptr }, ptr %l14
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l15
  %t20 = load i64, ptr %l15
  store i64 %t20, ptr %l3
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load i64, ptr %l2
  store i64 %t21, ptr %l16
  %t22 = load i64, ptr %l3
  store i64 %t22, ptr %l17
  %t23 = load i64, ptr %l16
  %t24 = load i64, ptr %l17
  %t25 = icmp slt i64 %t23, %t24
  store i1 %t25, ptr %l18
  %t26 = load i1, ptr %l18
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l19
  %t28 = load i1, ptr %l19
  br i1 %t28, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t29 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t29, ptr %l20
  %t30 = load i64, ptr %l2
  store i64 %t30, ptr %l21
  %t31 = load i64, ptr %l21
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  %t34 = getelementptr i8, ptr %t33, i64 %t31
  %t35 = load i8, ptr %t34
  store i8 %t35, ptr %l22
  %t36 = load i8, ptr %l22
  store i8 %t36, ptr %l4
  %t37 = load i8, ptr %l4
  store i8 %t37, ptr %l23
  %t38 = load i8, ptr %l23
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t38)
  store i1 %t39, ptr %l24
  br label %bb11
bb11:
  %t40 = load i1, ptr %l24
  br i1 %t40, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l25
  br label %bb17
bb13:
  %t41 = load i8, ptr %l4
  store i8 %t41, ptr %l26
  %t42 = load i8, ptr %l26
  %t43 = icmp uge i8 %t42, 97
  store i1 %t43, ptr %l27
  %t44 = load i1, ptr %l27
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i8, ptr %l4
  store i8 %t45, ptr %l29
  %t46 = load i8, ptr %l29
  %t47 = icmp ule i8 %t46, 102
  store i1 %t47, ptr %l30
  %t48 = load i1, ptr %l30
  store i1 %t48, ptr %l28
  br label %bb16
bb15:
  store i1 false, ptr %l28
  br label %bb16
bb16:
  %t49 = load i1, ptr %l28
  store i1 %t49, ptr %l25
  br label %bb17
bb17:
  %t50 = load i1, ptr %l25
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l31
  %t52 = load i1, ptr %l31
  br i1 %t52, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l32
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i1, ptr %l32
  store i1 %t53, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t54 = load i64, ptr %l2
  store i64 %t54, ptr %l33
  %t55 = load i64, ptr %l33
  %t56 = add i64 %t55, 1
  store i64 %t56, ptr %l34
  %t57 = load i64, ptr %l34
  store i64 %t57, ptr %l2
  call void @__olang_scope_close(ptr %s5)
  br label %bb7
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %l35
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i1, ptr %l35
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2eNamePart(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i8
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i8
  %l32 = alloca i8
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i8
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i8
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i8
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i8
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l5
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l6
  %t4 = load i64, ptr %l6
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l7
  %t6 = load i1, ptr %l7
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t7, ptr %l9
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10
  store i8 %t11, ptr %l10
  %t12 = load i8, ptr %l10
  %t13 = icmp eq i8 %t12, 46
  store i1 %t13, ptr %l11
  %t14 = load i1, ptr %l11
  store i1 %t14, ptr %l8
  br label %bb3
bb3:
  %t15 = load i1, ptr %l8
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t16, ptr %l13
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  %t19 = getelementptr i8, ptr %t18, i64 0
  %t20 = load i8, ptr %t19
  store i8 %t20, ptr %l14
  %t21 = load i8, ptr %l14
  %t22 = icmp eq i8 %t21, 45
  store i1 %t22, ptr %l15
  %t23 = load i1, ptr %l15
  store i1 %t23, ptr %l12
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16
  br label %bb10
bb8:
  %t25 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t25, ptr %l17
  %t26 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t26, ptr %l18
  store { i64, ptr } { i64 2, ptr @.d10 }, ptr %l19
  %t27 = load { i64, ptr }, ptr %l18
  %t28 = load { i64, ptr }, ptr %l19
  %t29 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t27, { i64, ptr } %t28)
  store i1 %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load i1, ptr %l20
  store i1 %t30, ptr %l16
  br label %bb10
bb10:
  %t31 = load i1, ptr %l16
  br i1 %t31, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l21
  store i1 %t32, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t33, ptr %l22
  %t34 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t34, ptr %l1
  store i64 0, ptr %l2
  %t35 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t35, ptr %l23
  %t36 = load { i64, ptr }, ptr %l23
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l24
  %t38 = load i64, ptr %l24
  store i64 %t38, ptr %l3
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l2
  store i64 %t39, ptr %l25
  %t40 = load i64, ptr %l3
  store i64 %t40, ptr %l26
  %t41 = load i64, ptr %l25
  %t42 = load i64, ptr %l26
  %t43 = icmp slt i64 %t41, %t42
  store i1 %t43, ptr %l27
  %t44 = load i1, ptr %l27
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l28
  %t46 = load i1, ptr %l28
  br i1 %t46, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t47 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t47, ptr %l29
  %t48 = load i64, ptr %l2
  store i64 %t48, ptr %l30
  %t49 = load i64, ptr %l30
  %t50 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  %t52 = getelementptr i8, ptr %t51, i64 %t49
  %t53 = load i8, ptr %t52
  store i8 %t53, ptr %l31
  %t54 = load i8, ptr %l31
  store i8 %t54, ptr %l4
  %t55 = load i8, ptr %l4
  store i8 %t55, ptr %l32
  %t56 = load i8, ptr %l32
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t56)
  store i1 %t57, ptr %l33
  br label %bb18
bb18:
  %t58 = load i1, ptr %l33
  br i1 %t58, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l34
  br label %bb22
bb20:
  %t59 = load i8, ptr %l4
  store i8 %t59, ptr %l35
  %t60 = load i8, ptr %l35
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t60)
  store i1 %t61, ptr %l36
  br label %bb21
bb21:
  %t62 = load i1, ptr %l36
  store i1 %t62, ptr %l34
  br label %bb22
bb22:
  %t63 = load i1, ptr %l34
  br i1 %t63, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l37
  br label %bb25
bb24:
  %t64 = load i8, ptr %l4
  store i8 %t64, ptr %l38
  %t65 = load i8, ptr %l38
  %t66 = icmp eq i8 %t65, 46
  store i1 %t66, ptr %l39
  %t67 = load i1, ptr %l39
  store i1 %t67, ptr %l37
  br label %bb25
bb25:
  %t68 = load i1, ptr %l37
  br i1 %t68, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l40
  br label %bb28
bb27:
  %t69 = load i8, ptr %l4
  store i8 %t69, ptr %l41
  %t70 = load i8, ptr %l41
  %t71 = icmp eq i8 %t70, 95
  store i1 %t71, ptr %l42
  %t72 = load i1, ptr %l42
  store i1 %t72, ptr %l40
  br label %bb28
bb28:
  %t73 = load i1, ptr %l40
  br i1 %t73, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l43
  br label %bb31
bb30:
  %t74 = load i8, ptr %l4
  store i8 %t74, ptr %l44
  %t75 = load i8, ptr %l44
  %t76 = icmp eq i8 %t75, 45
  store i1 %t76, ptr %l45
  %t77 = load i1, ptr %l45
  store i1 %t77, ptr %l43
  br label %bb31
bb31:
  %t78 = load i1, ptr %l43
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l46
  %t80 = load i1, ptr %l46
  br i1 %t80, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l47
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i1, ptr %l47
  store i1 %t81, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t82 = load i64, ptr %l2
  store i64 %t82, ptr %l48
  %t83 = load i64, ptr %l48
  %t84 = add i64 %t83, 1
  store i64 %t84, ptr %l49
  %t85 = load i64, ptr %l49
  store i64 %t85, ptr %l2
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb36:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %l50
  call void @__olang_scope_close(ptr %s0)
  %t86 = load i1, ptr %l50
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %lp15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %lp17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %lp21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i8
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l71 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca { i64, ptr }
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca i32
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i1
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca i32
  %l145 = alloca i32
  %l146 = alloca i1
  %l147 = alloca i32
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i32
  %l153 = alloca i32
  %l154 = alloca i1
  %l155 = alloca i32
  %l156 = alloca i32
  %l157 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l161 = alloca i64
  %l162 = alloca i1
  %l163 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca [4 x { i64, ptr }]
  %l173 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i1
  %l176 = alloca i1
  %l177 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l180 = alloca [10 x { i64, ptr }]
  %l181 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca i1
  %l184 = alloca i1
  %l185 = alloca { i64, ptr }
  %l186 = alloca [6 x { i64, ptr }]
  %l187 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca i1
  %l190 = alloca i1
  %l191 = alloca i1
  %l192 = alloca { i64, ptr }
  %l193 = alloca i32
  %l194 = alloca i32
  %l195 = alloca i1
  %l196 = alloca i32
  %l197 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca [6 x { i64, ptr }]
  %l200 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l202 = alloca i1
  %l203 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l205 = alloca [6 x { i64, ptr }]
  %l206 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca i1
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l213 = alloca i1
  %l214 = alloca i1
  %l215 = alloca { i64, ptr }
  %l216 = alloca i32
  %l217 = alloca i32
  %l218 = alloca i1
  %l219 = alloca i32
  %l220 = alloca i32
  %l221 = alloca { i64, ptr }
  %l222 = alloca i1
  %l223 = alloca i1
  %l224 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l226 = alloca i32
  %l227 = alloca i32
  %l228 = alloca i1
  %l229 = alloca i32
  %l230 = alloca { i64, ptr }
  %l231 = alloca i32
  %l232 = alloca i32
  %l233 = alloca i1
  %l234 = alloca i32
  %l235 = alloca i32
  %l236 = alloca { i64, ptr }
  %l237 = alloca i32
  %l238 = alloca i32
  %l239 = alloca i1
  %l240 = alloca i32
  %l241 = alloca { i64, ptr }
  %l242 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l247 = alloca i64
  %l248 = alloca { i64, ptr }
  %l249 = alloca i64
  %l250 = alloca i1
  %l251 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l256 = alloca i32
  %l257 = alloca i32
  %l258 = alloca i1
  %l259 = alloca i32
  %l260 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l262 = alloca i64
  %l263 = alloca { i64, ptr }
  %l264 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l267 = alloca [9 x { i64, ptr }]
  %l268 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l270 = alloca i1
  %l271 = alloca { i64, ptr }
  %l272 = alloca { i64, ptr }
  %l273 = alloca i64
  %l274 = alloca i64
  %l275 = alloca i1
  %l276 = alloca { i64, ptr }
  %l277 = alloca i1
  %l278 = alloca { i64, ptr }
  %l279 = alloca i32
  %l280 = alloca i32
  %l281 = alloca i1
  %l282 = alloca i32
  %l283 = alloca i32
  %l284 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l288 = alloca i1
  %l289 = alloca { i64, ptr }
  %l290 = alloca i32
  %l291 = alloca i32
  %l292 = alloca i1
  %l293 = alloca i32
  %l294 = alloca { i64, ptr }
  %l295 = alloca { i64, ptr }
  %l296 = alloca i32
  %l297 = alloca i32
  %l298 = alloca i1
  %l299 = alloca i32
  %l300 = alloca { i64, ptr }
  %l301 = alloca i32
  %l302 = alloca i32
  %l303 = alloca i1
  %l304 = alloca i32
  %l305 = alloca i32
  %l306 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l309 = alloca ptr
  %l310 = alloca i1
  %l311 = alloca ptr
  %l312 = alloca { i64, ptr }
  %l313 = alloca i1
  %l314 = alloca i1
  %l315 = alloca i1
  %l316 = alloca { i64, ptr }
  %l317 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l320 = alloca i64
  %l321 = alloca i1
  %l322 = alloca i1
  %l323 = alloca i1
  %l324 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %l327 = alloca i1
  %l328 = alloca i1
  %l329 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l331 = alloca i1
  %l332 = alloca i1
  %l333 = alloca ptr
  %l334 = alloca { i64, ptr }
  %l335 = alloca i64
  %l336 = alloca i1
  %l337 = alloca i1
  %l338 = alloca i1
  %l339 = alloca { i64, ptr }
  %l340 = alloca i64
  %l341 = alloca i1
  %l342 = alloca i1
  %l343 = alloca i1
  %l344 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l346 = alloca { i64, ptr }
  %l347 = alloca i1
  %l348 = alloca ptr
  %l349 = alloca { i64, ptr }
  %l350 = alloca i64
  %l351 = alloca i1
  %l352 = alloca i1
  %l353 = alloca i1
  %l354 = alloca { i64, ptr }
  %l355 = alloca { i64, ptr }
  %l356 = alloca { i64, ptr }
  %l357 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %s17 = alloca %olang.builder
  %s17room = alloca [64 x i8], align 8
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.builder
  %s27room = alloca [64 x i8], align 8
  %s28 = alloca %olang.builder
  %s28room = alloca [64 x i8], align 8
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.builder
  %s33room = alloca [64 x i8], align 8
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.builder
  %s41room = alloca [64 x i8], align 8
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.builder
  %s44room = alloca [64 x i8], align 8
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s47 = alloca %olang.builder
  %s47room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t1, ptr %l23
  store i8 64, ptr %l24
  %t2 = load { i64, ptr }, ptr %l23
  %t3 = load i8, ptr %l24
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v3, { i64, ptr } %t2, i8 %t3)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l26
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i64 %t5, ptr %l25
  br label %bb1
bb1:
  %t9 = load i64, ptr %l25
  store i64 %t9, ptr %l22
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t10, ptr %l27
  %t11 = load { i64, ptr }, ptr %l27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l28
  %t13 = load i64, ptr %l28
  store i64 %t13, ptr %l22
  br label %bb4
bb4:
  %t14 = load i64, ptr %l22
  store i64 %t14, ptr %l4
  %t15 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t15, ptr %l29
  %t16 = load i64, ptr %l4
  store i64 %t16, ptr %l30
  %t17 = load { i64, ptr }, ptr %l29
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l31
  %t19 = icmp sge i64 0, 0
  store i1 %t19, ptr %l32
  %t20 = load i1, ptr %l32
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l30
  %t22 = icmp sle i64 0, %t21
  store i1 %t22, ptr %l33
  %t23 = load i1, ptr %l33
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb7:
  %t24 = load i64, ptr %l30
  %t25 = load i64, ptr %l31
  %t26 = icmp sle i64 %t24, %t25
  store i1 %t26, ptr %l34
  %t27 = load i1, ptr %l34
  br i1 %t27, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  %t30 = load i64, ptr %l30
  %t31 = getelementptr i8, ptr %t29, i64 0
  %t32 = sub i64 %t30, 0
  %t33 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l35
  %t35 = load { i64, ptr }, ptr %l35
  store { i64, ptr } %t35, ptr %l5
  %t36 = load i64, ptr %l4
  store i64 %t36, ptr %l36
  %t37 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t37, ptr %l37
  %t38 = load { i64, ptr }, ptr %l37
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l38
  %t40 = load i64, ptr %l36
  %t41 = load i64, ptr %l38
  %t42 = icmp slt i64 %t40, %t41
  store i1 %t42, ptr %l39
  %t43 = load i1, ptr %l39
  br i1 %t43, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb11:
  %t44 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t44, ptr %l41
  %t45 = load i64, ptr %l4
  store i64 %t45, ptr %l42
  %t46 = load i64, ptr %l42
  %t47 = add i64 %t46, 1
  store i64 %t47, ptr %l43
  %t48 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t48, ptr %l44
  %t49 = load { i64, ptr }, ptr %l44
  store { i64, ptr } %t49, ptr %l45
  %t50 = load { i64, ptr }, ptr %l45
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l46
  %t52 = load { i64, ptr }, ptr %l41
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l47
  %t54 = load i64, ptr %l43
  %t55 = icmp sge i64 %t54, 0
  store i1 %t55, ptr %l48
  %t56 = load i1, ptr %l48
  br i1 %t56, label %bb13, label %bb14
bb12:
  %t57 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t57, ptr %l52
  %t58 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t58, ptr %l53
  %t59 = load { i64, ptr }, ptr %l53
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l54
  %t61 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t61, ptr %l55
  %t62 = load { i64, ptr }, ptr %l55
  store { i64, ptr } %t62, ptr %l56
  %t63 = load { i64, ptr }, ptr %l56
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l57
  %t65 = load { i64, ptr }, ptr %l52
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l58
  %t67 = load i64, ptr %l54
  %t68 = icmp sge i64 %t67, 0
  store i1 %t68, ptr %l59
  %t69 = load i1, ptr %l59
  br i1 %t69, label %bb19, label %bb20
bb13:
  %t70 = load i64, ptr %l43
  %t71 = load i64, ptr %l46
  %t72 = icmp sle i64 %t70, %t71
  store i1 %t72, ptr %l49
  %t73 = load i1, ptr %l49
  br i1 %t73, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb15:
  %t74 = load i64, ptr %l46
  %t75 = load i64, ptr %l47
  %t76 = icmp sle i64 %t74, %t75
  store i1 %t76, ptr %l50
  %t77 = load i1, ptr %l50
  br i1 %t77, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  %t80 = load i64, ptr %l43
  %t81 = load i64, ptr %l46
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l51
  %t86 = load { i64, ptr }, ptr %l51
  store { i64, ptr } %t86, ptr %l40
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb19:
  %t87 = load i64, ptr %l54
  %t88 = load i64, ptr %l57
  %t89 = icmp sle i64 %t87, %t88
  store i1 %t89, ptr %l60
  %t90 = load i1, ptr %l60
  br i1 %t90, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb21:
  %t91 = load i64, ptr %l57
  %t92 = load i64, ptr %l58
  %t93 = icmp sle i64 %t91, %t92
  store i1 %t93, ptr %l61
  %t94 = load i1, ptr %l61
  br i1 %t94, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb23:
  %t95 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t96 = load ptr, ptr %t95
  %t97 = load i64, ptr %l54
  %t98 = load i64, ptr %l57
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l62
  %t103 = load { i64, ptr }, ptr %l62
  store { i64, ptr } %t103, ptr %l40
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb25:
  %t104 = load { i64, ptr }, ptr %l40
  store { i64, ptr } %t104, ptr %l6
  %t105 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t105, ptr %l63
  %t106 = load { i64, ptr }, ptr %l63
  %t107 = call i1 @compiler_2ffetch_2eNamePart(ptr %v1, { i64, ptr } %t106)
  store i1 %t107, ptr %l64
  br label %bb26
bb26:
  %t108 = load i1, ptr %l64
  %t109 = xor i1 %t108, true
  store i1 %t109, ptr %l65
  %t110 = load i1, ptr %l65
  br i1 %t110, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l66
  br label %bb30
bb28:
  %t111 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t111, ptr %l67
  %t112 = load { i64, ptr }, ptr %l67
  %t113 = call i1 @compiler_2ffetch_2eNamePart(ptr %v2, { i64, ptr } %t112)
  store i1 %t113, ptr %l68
  br label %bb29
bb29:
  %t114 = load i1, ptr %l68
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l69
  %t116 = load i1, ptr %l69
  store i1 %t116, ptr %l66
  br label %bb30
bb30:
  %t117 = load i1, ptr %l66
  br i1 %t117, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l70
  br label %bb34
bb32:
  %t118 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t118, ptr %l71
  %t119 = load { i64, ptr }, ptr %l71
  %t120 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t119)
  store i1 %t120, ptr %l72
  br label %bb33
bb33:
  %t121 = load i1, ptr %l72
  %t122 = xor i1 %t121, true
  store i1 %t122, ptr %l73
  %t123 = load i1, ptr %l73
  store i1 %t123, ptr %l70
  br label %bb34
bb34:
  %t124 = load i1, ptr %l70
  br i1 %t124, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l74
  br label %bb41
bb36:
  %t125 = load i64, ptr %l4
  store i64 %t125, ptr %l75
  %t126 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t126, ptr %l76
  %t127 = load { i64, ptr }, ptr %l76
  %t128 = extractvalue { i64, ptr } %t127, 0
  store i64 %t128, ptr %l77
  %t129 = load i64, ptr %l75
  %t130 = load i64, ptr %l77
  %t131 = icmp slt i64 %t129, %t130
  store i1 %t131, ptr %l78
  %t132 = load i1, ptr %l78
  br i1 %t132, label %bb37, label %bb38
bb37:
  %t133 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t133, ptr %l80
  %t134 = load { i64, ptr }, ptr %l80
  %t135 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t134)
  store i1 %t135, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l79
  br label %bb40
bb39:
  %t136 = load i1, ptr %l81
  %t137 = xor i1 %t136, true
  store i1 %t137, ptr %l82
  %t138 = load i1, ptr %l82
  store i1 %t138, ptr %l79
  br label %bb40
bb40:
  %t139 = load i1, ptr %l79
  store i1 %t139, ptr %l74
  br label %bb41
bb41:
  %t140 = load i1, ptr %l74
  br i1 %t140, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l83
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l83
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t141, 0
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l0
  store ptr %t143, ptr %l84
  %t144 = load ptr, ptr %l84
  %t145 = getelementptr %"compiler/fetch:Fetcher", ptr %t144, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145
  store { i64, ptr } %t146, ptr %l85
  %t147 = load { i64, ptr }, ptr %l85
  store { i64, ptr } %t147, ptr %l7
  %t148 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t148, ptr %l86
  %t149 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t149, ptr %l87
  %t150 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t150, ptr %l88
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t151 = load { i64, ptr }, ptr %l86
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  call void @__olang_sb_put(ptr %s2, ptr %t152, i64 %t153)
  %t154 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t154, i64 %t155)
  %t156 = load { i64, ptr }, ptr %l87
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  call void @__olang_sb_put(ptr %s2, ptr %t157, i64 %t158)
  %t159 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t159, i64 %t160)
  %t161 = load { i64, ptr }, ptr %l88
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  call void @__olang_sb_put(ptr %s2, ptr %t162, i64 %t163)
  %t164 = load ptr, ptr %s2
  %t165 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t166 = load i64, ptr %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t167, ptr %t164, i64 %t166, i1 false)
  %t168 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l89
  call void @__olang_sb_done(ptr %s2)
  %t170 = load { i64, ptr }, ptr %l89
  store { i64, ptr } %t170, ptr %l8
  %t171 = load ptr, ptr %l0
  store ptr %t171, ptr %l90
  %t172 = load ptr, ptr %l90
  %t173 = getelementptr %"compiler/fetch:Fetcher", ptr %t172, i32 0, i32 2
  %t174 = load { i64, ptr }, ptr %t173
  store { i64, ptr } %t174, ptr %l91
  %t175 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t175, ptr %l92
  %t176 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t176, ptr %l93
  %t177 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t177, ptr %l94
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t178 = load { i64, ptr }, ptr %l91
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  call void @__olang_sb_put(ptr %s3, ptr %t179, i64 %t180)
  %t181 = load { i64, ptr }, ptr %l92
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  call void @__olang_sb_put(ptr %s3, ptr %t182, i64 %t183)
  %t184 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t185 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t184, i64 %t185)
  %t186 = load { i64, ptr }, ptr %l93
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  call void @__olang_sb_put(ptr %s3, ptr %t187, i64 %t188)
  %t189 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 1
  %t190 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t189, i64 %t190)
  %t191 = load { i64, ptr }, ptr %l94
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  call void @__olang_sb_put(ptr %s3, ptr %t192, i64 %t193)
  %t194 = load ptr, ptr %s3
  %t195 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t196 = load i64, ptr %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t194, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  store { i64, ptr } %t199, ptr %l95
  call void @__olang_sb_done(ptr %s3)
  %t200 = load { i64, ptr }, ptr %l95
  store { i64, ptr } %t200, ptr %l9
  %t201 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t201, ptr %l96
  %t202 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t202, ptr %l97
  %t203 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t203, ptr %l98
  %t204 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t204, ptr %l99
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t205 = load { i64, ptr }, ptr %l96
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  call void @__olang_sb_put(ptr %s4, ptr %t206, i64 %t207)
  %t208 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t208, i64 %t209)
  %t210 = load { i64, ptr }, ptr %l97
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  call void @__olang_sb_put(ptr %s4, ptr %t211, i64 %t212)
  %t213 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t213, i64 %t214)
  %t215 = load { i64, ptr }, ptr %l98
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  call void @__olang_sb_put(ptr %s4, ptr %t216, i64 %t217)
  %t218 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t219 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t218, i64 %t219)
  %t220 = load { i64, ptr }, ptr %l99
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  call void @__olang_sb_put(ptr %s4, ptr %t221, i64 %t222)
  %t223 = load ptr, ptr %s4
  %t224 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t225 = load i64, ptr %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t223, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  store { i64, ptr } %t228, ptr %l100
  call void @__olang_sb_done(ptr %s4)
  %t229 = load { i64, ptr }, ptr %l100
  store { i64, ptr } %t229, ptr %l10
  store i1 true, ptr %l11
  %t230 = load ptr, ptr %l0
  store ptr %t230, ptr %l102
  %t231 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t231, ptr %l103
  %t232 = load ptr, ptr %l102
  %t233 = load { i64, ptr }, ptr %l103
  %t234 = call { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %s0, ptr %t232, { i64, ptr } %t233)
  %t235 = extractvalue { i32, { i64, ptr } } %t234, 1
  %t236 = extractvalue { i32, { i64, ptr } } %t234, 0
  store i32 %t236, ptr %l105
  %t237 = icmp ne i32 %t236, 0
  br i1 %t237, label %bb46, label %ok.238
ok.238:
  store { i64, ptr } %t235, ptr %l104
  br label %bb45
bb45:
  %t239 = load { i64, ptr }, ptr %l104
  store { i64, ptr } %t239, ptr %l101
  br label %bb48
bb46:
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s5
  store i1 false, ptr %l11
  call void @__olang_scope_close(ptr %s5)
  store { i64, ptr } { i64 0, ptr @.d20 }, ptr %l101
  br label %bb48
bb48:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t240 = load { i64, ptr }, ptr %l101
  %t241 = extractvalue { i64, ptr } %t240, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  call void @__olang_sb_put(ptr %s6, ptr %t241, i64 %t242)
  %t243 = load ptr, ptr %s6
  %t244 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t245 = load i64, ptr %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t245)
  call void @llvm.memcpy.p0.p0.i64(ptr %t246, ptr %t243, i64 %t245, i1 false)
  %t247 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  store { i64, ptr } %t248, ptr %l106
  call void @__olang_sb_done(ptr %s6)
  %t249 = load { i64, ptr }, ptr %l106
  store { i64, ptr } %t249, ptr %l12
  store { i64, ptr } { i64 0, ptr @.d21 }, ptr %l107
  %t250 = load { i64, ptr }, ptr %l107
  store { i64, ptr } %t250, ptr %l108
  %t251 = load { i64, ptr }, ptr %l108
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l109
  %t253 = load i64, ptr %l109
  %t254 = mul i64 %t253, 1
  %t255 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t254)
  %t256 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  store { i64, ptr } %t257, ptr %l110
  %t258 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t259 = load ptr, ptr %t258
  %t260 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t261 = load ptr, ptr %t260
  %t262 = load i64, ptr %l109
  %t263 = mul i64 %t262, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t259, ptr %t261, i64 %t263, i1 false)
  %t264 = load { i64, ptr }, ptr %l110
  store { i64, ptr } %t264, ptr %l13
  store i1 false, ptr %l14
  %t265 = load i1, ptr %l11
  store i1 %t265, ptr %l111
  %t266 = load i1, ptr %l111
  br i1 %t266, label %bb49, label %bb50
bb49:
  %t267 = load ptr, ptr %l0
  store ptr %t267, ptr %l113
  %t268 = load ptr, ptr %l113
  %t269 = getelementptr %"compiler/fetch:Fetcher", ptr %t268, i32 0, i32 3
  %t270 = load i1, ptr %t269
  store i1 %t270, ptr %l114
  %t271 = load i1, ptr %l114
  store i1 %t271, ptr %l112
  br label %bb51
bb50:
  store i1 false, ptr %l112
  br label %bb51
bb51:
  %t272 = load i1, ptr %l112
  br i1 %t272, label %bb52, label %bb53
bb52:
  %t273 = load ptr, ptr %l0
  store ptr %t273, ptr %l116
  %t274 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t274, ptr %l117
  %t275 = load ptr, ptr %l116
  %t276 = load { i64, ptr }, ptr %l117
  %t277 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %s0, ptr %t275, { i64, ptr } %t276, i1 false)
  store i1 %t277, ptr %l118
  br label %bb54
bb53:
  store i1 false, ptr %l115
  br label %bb55
bb54:
  %t278 = load i1, ptr %l118
  %t279 = xor i1 %t278, true
  store i1 %t279, ptr %l119
  %t280 = load i1, ptr %l119
  store i1 %t280, ptr %l115
  br label %bb55
bb55:
  %t281 = load i1, ptr %l115
  br i1 %t281, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s7
  %t282 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t282, ptr %l120
  %t283 = load { i64, ptr }, ptr %l120
  %t284 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t283)
  store i1 %t284, ptr %l121
  br label %bb58
bb57:
  br label %bb65
bb58:
  %t285 = load i1, ptr %l121
  br i1 %t285, label %bb59, label %bb60
bb59:
  %t286 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t286, ptr %l123
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t287 = load { i64, ptr }, ptr %l123
  %t288 = extractvalue { i64, ptr } %t287, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  call void @__olang_sb_put(ptr %s8, ptr %t288, i64 %t289)
  %t290 = load ptr, ptr %s8
  %t291 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t292 = load i64, ptr %t291
  %t293 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t290, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  store { i64, ptr } %t295, ptr %l124
  call void @__olang_sb_done(ptr %s8)
  %t296 = load { i64, ptr }, ptr %l124
  store { i64, ptr } %t296, ptr %l122
  br label %bb61
bb60:
  store { i64, ptr } { i64 0, ptr @.d22 }, ptr %l125
  %t297 = load { i64, ptr }, ptr %l125
  store { i64, ptr } %t297, ptr %l126
  %t298 = load { i64, ptr }, ptr %l126
  store { i64, ptr } %t298, ptr %l122
  br label %bb61
bb61:
  %t299 = load { i64, ptr }, ptr %l13
  %t300 = extractvalue { i64, ptr } %t299, 0
  store i64 %t300, ptr %l127
  %t301 = load { i64, ptr }, ptr %l122
  %t302 = extractvalue { i64, ptr } %t301, 0
  store i64 %t302, ptr %l128
  %t303 = load i64, ptr %l127
  %t304 = load i64, ptr %l128
  %t305 = icmp eq i64 %t303, %t304
  store i1 %t305, ptr %l129
  %t306 = load i1, ptr %l129
  br i1 %t306, label %bb62, label %bb63
bb62:
  %t307 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t308 = load ptr, ptr %t307
  %t309 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t310 = load ptr, ptr %t309
  %t311 = load i64, ptr %l128
  %t312 = mul i64 %t311, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t308, ptr %t310, i64 %t312, i1 false)
  br label %bb64
bb63:
  %t313 = load { i64, ptr }, ptr %l122
  store { i64, ptr } %t313, ptr %l13
  br label %bb64
bb64:
  store i1 true, ptr %l14
  store i1 false, ptr %l11
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb65:
  %t314 = load i1, ptr %l11
  store i1 %t314, ptr %l130
  %t315 = load i1, ptr %l130
  br i1 %t315, label %bb66, label %bb67
bb66:
  %t316 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t316, ptr %l132
  %t317 = load { i64, ptr }, ptr %l132
  %t318 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t317)
  store i1 %t318, ptr %l133
  br label %bb68
bb67:
  store i1 false, ptr %l131
  br label %bb69
bb68:
  %t319 = load i1, ptr %l133
  %t320 = xor i1 %t319, true
  store i1 %t320, ptr %l134
  %t321 = load i1, ptr %l134
  store i1 %t321, ptr %l131
  br label %bb69
bb69:
  %t322 = load i1, ptr %l131
  br i1 %t322, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s9
  store i32 65537, ptr %l135
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t323 = load i32, ptr %l135
  %t324 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t323, 0
  store { i32, { i64, ptr } } %t324, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t325 = load i1, ptr %l11
  store i1 %t325, ptr %l136
  %t326 = load i1, ptr %l136
  br i1 %t326, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s10
  %t327 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t327, ptr %l137
  %t328 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t328, ptr %l138
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  %t329 = load { i64, ptr }, ptr %l137
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  call void @__olang_sb_put(ptr %s11, ptr %t330, i64 %t331)
  %t332 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 0
  call void @__olang_sb_put(ptr %s11, ptr %t332, i64 %t333)
  %t334 = load { i64, ptr }, ptr %l138
  %t335 = extractvalue { i64, ptr } %t334, 1
  %t336 = extractvalue { i64, ptr } %t334, 0
  call void @__olang_sb_put(ptr %s11, ptr %t335, i64 %t336)
  %t337 = load ptr, ptr %s11
  %t338 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t339 = load i64, ptr %t338
  %t340 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t337, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  store { i64, ptr } %t342, ptr %l139
  call void @__olang_sb_done(ptr %s11)
  %t343 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t343, ptr %lp15
  %t344 = load { i64, ptr }, ptr %l139
  %t345 = load ptr, ptr %lp15
  store { i64, ptr } %t344, ptr %t345
  %t346 = load ptr, ptr %lp15
  %t347 = load { i64, ptr }, ptr %t346
  store { i64, ptr } %t347, ptr %l140
  %t348 = load { i64, ptr }, ptr %l140
  %t349 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t348)
  store i1 %t349, ptr %l141
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t350 = load i1, ptr %l141
  br i1 %t350, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s12
  %t351 = load ptr, ptr %lp15
  %t352 = load { i64, ptr }, ptr %t351
  store { i64, ptr } %t352, ptr %l142
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t353 = load { i64, ptr }, ptr %l142
  %t354 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t353, 1
  store { i32, { i64, ptr } } %t354, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s10)
  br label %bb79
bb79:
  %t355 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t355, ptr %l143
  %t356 = load { i64, ptr }, ptr %l143
  %t357 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t356)
  store i32 %t357, ptr %l144
  %t358 = icmp ne i32 %t357, 0
  br i1 %t358, label %bb81, label %ok.359
ok.359:
  br label %bb80
bb80:
  br label %bb85
bb81:
  %t360 = load i32, ptr %l144
  %t361 = ashr i32 %t360, 16
  store i32 %t361, ptr %l145
  %t362 = load i32, ptr %l145
  %t363 = icmp eq i32 %t362, 1
  store i1 %t363, ptr %l146
  %t364 = load i1, ptr %l146
  br i1 %t364, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  %t365 = load i32, ptr %l144
  %t366 = lshr i32 %t365, 16
  %t367 = and i32 %t365, 65535
  %t368 = icmp eq i32 %t366, 1
  %t369 = select i1 %t368, i32 0, i32 0
  %t370 = icmp eq i32 %t365, 0
  %t371 = shl i32 %t369, 16
  %t372 = or i32 %t371, %t367
  %t373 = select i1 %t370, i32 0, i32 %t372
  store i32 %t373, ptr %l147
  call void @__olang_scope_close(ptr %s0)
  %t374 = load i32, ptr %l147
  %t375 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t374, 0
  store { i32, { i64, ptr } } %t375, ptr %rv
  br label %ret
bb84:
  store %olang.scope zeroinitializer, ptr %s13
  store i32 65538, ptr %l148
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t376 = load i32, ptr %l148
  %t377 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t376, 0
  store { i32, { i64, ptr } } %t377, ptr %rv
  br label %ret
bb85:
  %t378 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t378, ptr %l150
  %t379 = load { i64, ptr }, ptr %l150
  %t380 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t379, { i64, ptr } { i64 7, ptr @.d24 })
  %t381 = extractvalue { i32, { i64, ptr } } %t380, 1
  %t382 = extractvalue { i32, { i64, ptr } } %t380, 0
  store i32 %t382, ptr %l152
  %t383 = icmp ne i32 %t382, 0
  br i1 %t383, label %bb87, label %ok.384
ok.384:
  store { i64, ptr } %t381, ptr %l151
  br label %bb86
bb86:
  %t385 = load { i64, ptr }, ptr %l151
  store { i64, ptr } %t385, ptr %l149
  br label %bb91
bb87:
  %t386 = load i32, ptr %l152
  %t387 = ashr i32 %t386, 16
  store i32 %t387, ptr %l153
  %t388 = load i32, ptr %l153
  %t389 = icmp eq i32 %t388, 1
  store i1 %t389, ptr %l154
  %t390 = load i1, ptr %l154
  br i1 %t390, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  %t391 = load i32, ptr %l152
  %t392 = lshr i32 %t391, 16
  %t393 = and i32 %t391, 65535
  %t394 = icmp eq i32 %t392, 1
  %t395 = select i1 %t394, i32 0, i32 0
  %t396 = icmp eq i32 %t391, 0
  %t397 = shl i32 %t395, 16
  %t398 = or i32 %t397, %t393
  %t399 = select i1 %t396, i32 0, i32 %t398
  store i32 %t399, ptr %l155
  call void @__olang_scope_close(ptr %s0)
  %t400 = load i32, ptr %l155
  %t401 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t400, 0
  store { i32, { i64, ptr } } %t401, ptr %rv
  br label %ret
bb90:
  store %olang.scope zeroinitializer, ptr %s14
  store i32 65538, ptr %l156
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t402 = load i32, ptr %l156
  %t403 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t402, 0
  store { i32, { i64, ptr } } %t403, ptr %rv
  br label %ret
bb91:
  %t404 = load { i64, ptr }, ptr %l149
  store { i64, ptr } %t404, ptr %l16
  %t405 = load i1, ptr %l11
  store i1 %t405, ptr %l157
  %t406 = load i1, ptr %l157
  br i1 %t406, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s15
  %t407 = load ptr, ptr %l0
  store ptr %t407, ptr %l158
  %t408 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t408, ptr %l159
  %t409 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t409, ptr %l160
  %t410 = load { i64, ptr }, ptr %l12
  %t411 = extractvalue { i64, ptr } %t410, 0
  store i64 %t411, ptr %l161
  %t412 = icmp sge i64 0, 0
  store i1 %t412, ptr %l162
  %t413 = load i1, ptr %l162
  br i1 %t413, label %bb94, label %bb95
bb93:
  br label %bb157
bb94:
  %t414 = icmp sle i64 0, 12
  store i1 %t414, ptr %l163
  %t415 = load i1, ptr %l163
  br i1 %t415, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb96:
  %t416 = load i64, ptr %l161
  %t417 = icmp sle i64 12, %t416
  store i1 %t417, ptr %l164
  %t418 = load i1, ptr %l164
  br i1 %t418, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb98:
  %t419 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t420 = load ptr, ptr %t419
  %t421 = getelementptr i8, ptr %t420, i64 0
  %t422 = sub i64 12, 0
  %t423 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t421, 1
  store { i64, ptr } %t424, ptr %l165
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  %t425 = extractvalue { i64, ptr } { i64 16, ptr @.d26 }, 1
  %t426 = extractvalue { i64, ptr } { i64 16, ptr @.d26 }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t425, i64 %t426)
  %t427 = load { i64, ptr }, ptr %l159
  %t428 = extractvalue { i64, ptr } %t427, 1
  %t429 = extractvalue { i64, ptr } %t427, 0
  call void @__olang_sb_put(ptr %s16, ptr %t428, i64 %t429)
  %t430 = extractvalue { i64, ptr } { i64 6, ptr @.d27 }, 1
  %t431 = extractvalue { i64, ptr } { i64 6, ptr @.d27 }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t430, i64 %t431)
  %t432 = load { i64, ptr }, ptr %l160
  %t433 = extractvalue { i64, ptr } %t432, 1
  %t434 = extractvalue { i64, ptr } %t432, 0
  call void @__olang_sb_put(ptr %s16, ptr %t433, i64 %t434)
  %t435 = extractvalue { i64, ptr } { i64 4, ptr @.d28 }, 1
  %t436 = extractvalue { i64, ptr } { i64 4, ptr @.d28 }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t435, i64 %t436)
  %t437 = load { i64, ptr }, ptr %l165
  %t438 = extractvalue { i64, ptr } %t437, 1
  %t439 = extractvalue { i64, ptr } %t437, 0
  call void @__olang_sb_put(ptr %s16, ptr %t438, i64 %t439)
  %t440 = extractvalue { i64, ptr } { i64 20, ptr @.d29 }, 1
  %t441 = extractvalue { i64, ptr } { i64 20, ptr @.d29 }, 0
  call void @__olang_sb_put(ptr %s16, ptr %t440, i64 %t441)
  %t442 = load ptr, ptr %s16
  %t443 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t444 = load i64, ptr %t443
  %t445 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t444)
  call void @llvm.memcpy.p0.p0.i64(ptr %t445, ptr %t442, i64 %t444, i1 false)
  %t446 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t445, 1
  store { i64, ptr } %t447, ptr %l166
  call void @__olang_sb_done(ptr %s16)
  %t448 = load { i64, ptr }, ptr %l166
  %t449 = extractvalue { i64, ptr } %t448, 0
  %t450 = extractvalue { i64, ptr } %t448, 1
  %t451 = mul i64 %t449, 1
  %t452 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t451)
  call void @llvm.memcpy.p0.p0.i64(ptr %t452, ptr %t450, i64 %t451, i1 false)
  %t453 = insertvalue { i64, ptr } undef, i64 %t449, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t452, 1
  store { i64, ptr } %t454, ptr %l167
  %t455 = load ptr, ptr %l158
  %t456 = load { i64, ptr }, ptr %l167
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s15, ptr %t455, { i64, ptr } %t456)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb100:
  %t457 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t457, ptr %l168
  %t458 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t458, ptr %l169
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s17
  store ptr %s17room, ptr %s17
  %t459 = load { i64, ptr }, ptr %l168
  %t460 = extractvalue { i64, ptr } %t459, 1
  %t461 = extractvalue { i64, ptr } %t459, 0
  call void @__olang_sb_put(ptr %s17, ptr %t460, i64 %t461)
  %t462 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t463 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  call void @__olang_sb_put(ptr %s17, ptr %t462, i64 %t463)
  %t464 = load { i64, ptr }, ptr %l169
  %t465 = extractvalue { i64, ptr } %t464, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  call void @__olang_sb_put(ptr %s17, ptr %t465, i64 %t466)
  %t467 = load ptr, ptr %s17
  %t468 = getelementptr %olang.builder, ptr %s17, i32 0, i32 1
  %t469 = load i64, ptr %t468
  %t470 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t467, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  store { i64, ptr } %t472, ptr %l170
  call void @__olang_sb_done(ptr %s17)
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t473, ptr %lp17
  %t474 = load { i64, ptr }, ptr %l170
  %t475 = load ptr, ptr %lp17
  store { i64, ptr } %t474, ptr %t475
  %t476 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t476, ptr %l171
  %t477 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d31 }, 0
  %t478 = insertvalue [4 x { i64, ptr }] %t477, { i64, ptr } { i64 4, ptr @.d32 }, 1
  %t479 = insertvalue [4 x { i64, ptr }] %t478, { i64, ptr } { i64 2, ptr @.d33 }, 2
  %t480 = load { i64, ptr }, ptr %l171
  %t481 = insertvalue [4 x { i64, ptr }] %t479, { i64, ptr } %t480, 3
  store [4 x { i64, ptr }] %t481, ptr %l172
  %t482 = load [4 x { i64, ptr }], ptr %l172
  %t483 = load ptr, ptr @__olang_prog_scope
  %t484 = call ptr @__olang_scope_alloc(ptr %t483, i64 64)
  store [4 x { i64, ptr }] %t482, ptr %t484
  %t485 = insertvalue { i64, ptr } undef, i64 4, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  store { i64, ptr } %t486, ptr %l173
  %t487 = load { i64, ptr }, ptr %l173
  %t488 = extractvalue { i64, ptr } %t487, 0
  %t489 = extractvalue { i64, ptr } %t487, 1
  %t490 = mul i64 %t488, 16
  %t491 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  store { i64, ptr } %t493, ptr %l174
  %t494 = load { i64, ptr }, ptr %l174
  %t495 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t494)
  store i1 %t495, ptr %l175
  br label %bb101
bb101:
  %t496 = load i1, ptr %l175
  br i1 %t496, label %bb102, label %bb103
bb102:
  %t497 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t497, ptr %l177
  %t498 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t498, ptr %l178
  %t499 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t499, ptr %l179
  %t500 = insertvalue [10 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d34 }, 0
  %t501 = insertvalue [10 x { i64, ptr }] %t500, { i64, ptr } { i64 2, ptr @.d35 }, 1
  %t502 = load { i64, ptr }, ptr %l177
  %t503 = insertvalue [10 x { i64, ptr }] %t501, { i64, ptr } %t502, 2
  %t504 = insertvalue [10 x { i64, ptr }] %t503, { i64, ptr } { i64 5, ptr @.d36 }, 3
  %t505 = insertvalue [10 x { i64, ptr }] %t504, { i64, ptr } { i64 2, ptr @.d37 }, 4
  %t506 = insertvalue [10 x { i64, ptr }] %t505, { i64, ptr } { i64 7, ptr @.d38 }, 5
  %t507 = insertvalue [10 x { i64, ptr }] %t506, { i64, ptr } { i64 1, ptr @.d39 }, 6
  %t508 = insertvalue [10 x { i64, ptr }] %t507, { i64, ptr } { i64 2, ptr @.d40 }, 7
  %t509 = load { i64, ptr }, ptr %l178
  %t510 = insertvalue [10 x { i64, ptr }] %t508, { i64, ptr } %t509, 8
  %t511 = load { i64, ptr }, ptr %l179
  %t512 = insertvalue [10 x { i64, ptr }] %t510, { i64, ptr } %t511, 9
  store [10 x { i64, ptr }] %t512, ptr %l180
  %t513 = load [10 x { i64, ptr }], ptr %l180
  %t514 = load ptr, ptr @__olang_prog_scope
  %t515 = call ptr @__olang_scope_alloc(ptr %t514, i64 160)
  store [10 x { i64, ptr }] %t513, ptr %t515
  %t516 = insertvalue { i64, ptr } undef, i64 10, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t515, 1
  store { i64, ptr } %t517, ptr %l181
  %t518 = load { i64, ptr }, ptr %l181
  %t519 = extractvalue { i64, ptr } %t518, 0
  %t520 = extractvalue { i64, ptr } %t518, 1
  %t521 = mul i64 %t519, 16
  %t522 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t521)
  call void @llvm.memcpy.p0.p0.i64(ptr %t522, ptr %t520, i64 %t521, i1 false)
  %t523 = insertvalue { i64, ptr } undef, i64 %t519, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t522, 1
  store { i64, ptr } %t524, ptr %l182
  %t525 = load { i64, ptr }, ptr %l182
  %t526 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t525)
  store i1 %t526, ptr %l183
  br label %bb104
bb103:
  store i1 false, ptr %l176
  br label %bb105
bb104:
  %t527 = load i1, ptr %l183
  store i1 %t527, ptr %l176
  br label %bb105
bb105:
  %t528 = load i1, ptr %l176
  br i1 %t528, label %bb106, label %bb107
bb106:
  %t529 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t529, ptr %l185
  %t530 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d41 }, 0
  %t531 = insertvalue [6 x { i64, ptr }] %t530, { i64, ptr } { i64 2, ptr @.d42 }, 1
  %t532 = load { i64, ptr }, ptr %l185
  %t533 = insertvalue [6 x { i64, ptr }] %t531, { i64, ptr } %t532, 2
  %t534 = insertvalue [6 x { i64, ptr }] %t533, { i64, ptr } { i64 8, ptr @.d43 }, 3
  %t535 = insertvalue [6 x { i64, ptr }] %t534, { i64, ptr } { i64 2, ptr @.d44 }, 4
  %t536 = insertvalue [6 x { i64, ptr }] %t535, { i64, ptr } { i64 10, ptr @.d45 }, 5
  store [6 x { i64, ptr }] %t536, ptr %l186
  %t537 = load [6 x { i64, ptr }], ptr %l186
  %t538 = load ptr, ptr @__olang_prog_scope
  %t539 = call ptr @__olang_scope_alloc(ptr %t538, i64 96)
  store [6 x { i64, ptr }] %t537, ptr %t539
  %t540 = insertvalue { i64, ptr } undef, i64 6, 0
  %t541 = insertvalue { i64, ptr } %t540, ptr %t539, 1
  store { i64, ptr } %t541, ptr %l187
  %t542 = load { i64, ptr }, ptr %l187
  %t543 = extractvalue { i64, ptr } %t542, 0
  %t544 = extractvalue { i64, ptr } %t542, 1
  %t545 = mul i64 %t543, 16
  %t546 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t545)
  call void @llvm.memcpy.p0.p0.i64(ptr %t546, ptr %t544, i64 %t545, i1 false)
  %t547 = insertvalue { i64, ptr } undef, i64 %t543, 0
  %t548 = insertvalue { i64, ptr } %t547, ptr %t546, 1
  store { i64, ptr } %t548, ptr %l188
  %t549 = load { i64, ptr }, ptr %l188
  %t550 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t549)
  store i1 %t550, ptr %l189
  br label %bb108
bb107:
  store i1 false, ptr %l184
  br label %bb109
bb108:
  %t551 = load i1, ptr %l189
  store i1 %t551, ptr %l184
  br label %bb109
bb109:
  %t552 = load i1, ptr %l184
  store i1 %t552, ptr %l18
  %t553 = load i1, ptr %l18
  store i1 %t553, ptr %l190
  %t554 = load i1, ptr %l190
  %t555 = xor i1 %t554, true
  store i1 %t555, ptr %l191
  %t556 = load i1, ptr %l191
  br i1 %t556, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s18
  %t557 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t557, ptr %l192
  %t558 = load { i64, ptr }, ptr %l192
  %t559 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t558)
  store i32 %t559, ptr %l193
  %t560 = icmp ne i32 %t559, 0
  br i1 %t560, label %bb113, label %ok.561
ok.561:
  br label %bb112
bb111:
  br label %bb123
bb112:
  br label %bb117
bb113:
  %t562 = load i32, ptr %l193
  %t563 = ashr i32 %t562, 16
  store i32 %t563, ptr %l194
  %t564 = load i32, ptr %l194
  %t565 = icmp eq i32 %t564, 1
  store i1 %t565, ptr %l195
  %t566 = load i1, ptr %l195
  br i1 %t566, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  %t567 = load i32, ptr %l193
  %t568 = lshr i32 %t567, 16
  %t569 = and i32 %t567, 65535
  %t570 = icmp eq i32 %t568, 1
  %t571 = select i1 %t570, i32 0, i32 0
  %t572 = icmp eq i32 %t567, 0
  %t573 = shl i32 %t571, 16
  %t574 = or i32 %t573, %t569
  %t575 = select i1 %t572, i32 0, i32 %t574
  store i32 %t575, ptr %l196
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t576 = load i32, ptr %l196
  %t577 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t576, 0
  store { i32, { i64, ptr } } %t577, ptr %rv
  br label %ret
bb116:
  store %olang.scope zeroinitializer, ptr %s19
  call void @__olang_scope_close(ptr %s19)
  br label %bb117
bb117:
  %t578 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t578, ptr %l197
  %t579 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t579, ptr %l198
  %t580 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d46 }, 0
  %t581 = insertvalue [6 x { i64, ptr }] %t580, { i64, ptr } { i64 5, ptr @.d47 }, 1
  %t582 = insertvalue [6 x { i64, ptr }] %t581, { i64, ptr } { i64 2, ptr @.d48 }, 2
  %t583 = insertvalue [6 x { i64, ptr }] %t582, { i64, ptr } { i64 2, ptr @.d49 }, 3
  %t584 = load { i64, ptr }, ptr %l197
  %t585 = insertvalue [6 x { i64, ptr }] %t583, { i64, ptr } %t584, 4
  %t586 = load { i64, ptr }, ptr %l198
  %t587 = insertvalue [6 x { i64, ptr }] %t585, { i64, ptr } %t586, 5
  store [6 x { i64, ptr }] %t587, ptr %l199
  %t588 = load [6 x { i64, ptr }], ptr %l199
  %t589 = load ptr, ptr @__olang_prog_scope
  %t590 = call ptr @__olang_scope_alloc(ptr %t589, i64 96)
  store [6 x { i64, ptr }] %t588, ptr %t590
  %t591 = insertvalue { i64, ptr } undef, i64 6, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  store { i64, ptr } %t592, ptr %l200
  %t593 = load { i64, ptr }, ptr %l200
  %t594 = extractvalue { i64, ptr } %t593, 0
  %t595 = extractvalue { i64, ptr } %t593, 1
  %t596 = mul i64 %t594, 16
  %t597 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t596)
  call void @llvm.memcpy.p0.p0.i64(ptr %t597, ptr %t595, i64 %t596, i1 false)
  %t598 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t597, 1
  store { i64, ptr } %t599, ptr %l201
  %t600 = load { i64, ptr }, ptr %l201
  %t601 = call i1 @compiler_2ffetch_2egit(ptr %s18, { i64, ptr } %t600)
  store i1 %t601, ptr %l202
  br label %bb118
bb118:
  %t602 = load i1, ptr %l202
  br i1 %t602, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s20
  %t603 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t603, ptr %l203
  %t604 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t604, ptr %l204
  %t605 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d50 }, 0
  %t606 = insertvalue [6 x { i64, ptr }] %t605, { i64, ptr } { i64 2, ptr @.d51 }, 1
  %t607 = load { i64, ptr }, ptr %l203
  %t608 = insertvalue [6 x { i64, ptr }] %t606, { i64, ptr } %t607, 2
  %t609 = insertvalue [6 x { i64, ptr }] %t608, { i64, ptr } { i64 8, ptr @.d52 }, 3
  %t610 = insertvalue [6 x { i64, ptr }] %t609, { i64, ptr } { i64 2, ptr @.d53 }, 4
  %t611 = load { i64, ptr }, ptr %l204
  %t612 = insertvalue [6 x { i64, ptr }] %t610, { i64, ptr } %t611, 5
  store [6 x { i64, ptr }] %t612, ptr %l205
  %t613 = load [6 x { i64, ptr }], ptr %l205
  %t614 = load ptr, ptr @__olang_prog_scope
  %t615 = call ptr @__olang_scope_alloc(ptr %t614, i64 96)
  store [6 x { i64, ptr }] %t613, ptr %t615
  %t616 = insertvalue { i64, ptr } undef, i64 6, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  store { i64, ptr } %t617, ptr %l206
  %t618 = load { i64, ptr }, ptr %l206
  %t619 = extractvalue { i64, ptr } %t618, 0
  %t620 = extractvalue { i64, ptr } %t618, 1
  %t621 = mul i64 %t619, 16
  %t622 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t621)
  call void @llvm.memcpy.p0.p0.i64(ptr %t622, ptr %t620, i64 %t621, i1 false)
  %t623 = insertvalue { i64, ptr } undef, i64 %t619, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t622, 1
  store { i64, ptr } %t624, ptr %l207
  %t625 = load { i64, ptr }, ptr %l207
  %t626 = call i1 @compiler_2ffetch_2egit(ptr %s20, { i64, ptr } %t625)
  store i1 %t626, ptr %l208
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s20)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s18)
  br label %bb123
bb123:
  %t627 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t627, ptr %l209
  %t628 = load { i64, ptr }, ptr %l209
  %t629 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s15, { i64, ptr } %t628)
  store { i64, ptr } %t629, ptr %l210
  br label %bb124
bb124:
  %t630 = load { i64, ptr }, ptr %l210
  %t631 = extractvalue { i64, ptr } %t630, 0
  %t632 = extractvalue { i64, ptr } %t630, 1
  %t633 = mul i64 %t631, 1
  %t634 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t633)
  call void @llvm.memcpy.p0.p0.i64(ptr %t634, ptr %t632, i64 %t633, i1 false)
  %t635 = insertvalue { i64, ptr } undef, i64 %t631, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t634, 1
  store { i64, ptr } %t636, ptr %l211
  %t637 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t637, ptr %l212
  %t638 = load { i64, ptr }, ptr %l211
  %t639 = load { i64, ptr }, ptr %l212
  %t640 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s0, { i64, ptr } %t638, { i64, ptr } %t639)
  store i1 %t640, ptr %l213
  br label %bb125
bb125:
  %t641 = load i1, ptr %l213
  %t642 = xor i1 %t641, true
  store i1 %t642, ptr %l214
  %t643 = load i1, ptr %l214
  br i1 %t643, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s21
  %t644 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t644, ptr %l215
  %t645 = load { i64, ptr }, ptr %l215
  %t646 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t645)
  store i32 %t646, ptr %l216
  %t647 = icmp ne i32 %t646, 0
  br i1 %t647, label %bb129, label %ok.648
ok.648:
  br label %bb128
bb127:
  br label %bb134
bb128:
  br label %bb133
bb129:
  %t649 = load i32, ptr %l216
  %t650 = ashr i32 %t649, 16
  store i32 %t650, ptr %l217
  %t651 = load i32, ptr %l217
  %t652 = icmp eq i32 %t651, 1
  store i1 %t652, ptr %l218
  %t653 = load i1, ptr %l218
  br i1 %t653, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  %t654 = load i32, ptr %l216
  %t655 = lshr i32 %t654, 16
  %t656 = and i32 %t654, 65535
  %t657 = icmp eq i32 %t655, 1
  %t658 = select i1 %t657, i32 0, i32 0
  %t659 = icmp eq i32 %t654, 0
  %t660 = shl i32 %t658, 16
  %t661 = or i32 %t660, %t656
  %t662 = select i1 %t659, i32 0, i32 %t661
  store i32 %t662, ptr %l219
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t663 = load i32, ptr %l219
  %t664 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t663, 0
  store { i32, { i64, ptr } } %t664, ptr %rv
  br label %ret
bb132:
  store %olang.scope zeroinitializer, ptr %s22
  call void @__olang_scope_close(ptr %s22)
  br label %bb133
bb133:
  store i32 65539, ptr %l220
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t665 = load i32, ptr %l220
  %t666 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t665, 0
  store { i32, { i64, ptr } } %t666, ptr %rv
  br label %ret
bb134:
  %t667 = load ptr, ptr %lp17
  %t668 = load { i64, ptr }, ptr %t667
  store { i64, ptr } %t668, ptr %l221
  %t669 = load { i64, ptr }, ptr %l221
  %t670 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t669)
  store i1 %t670, ptr %l222
  br label %bb135
bb135:
  %t671 = load i1, ptr %l222
  %t672 = xor i1 %t671, true
  store i1 %t672, ptr %l223
  %t673 = load i1, ptr %l223
  br i1 %t673, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s23
  %t674 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t674, ptr %l224
  %t675 = load ptr, ptr %lp17
  %t676 = load { i64, ptr }, ptr %t675
  store { i64, ptr } %t676, ptr %l225
  %t677 = load { i64, ptr }, ptr %l224
  %t678 = load { i64, ptr }, ptr %l225
  %t679 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t677, { i64, ptr } %t678)
  store i32 %t679, ptr %l226
  %t680 = icmp ne i32 %t679, 0
  br i1 %t680, label %bb139, label %ok.681
ok.681:
  br label %bb138
bb137:
  br label %bb150
bb138:
  br label %bb149
bb139:
  %t682 = load i32, ptr %l226
  %t683 = ashr i32 %t682, 16
  store i32 %t683, ptr %l227
  %t684 = load i32, ptr %l227
  %t685 = icmp eq i32 %t684, 1
  store i1 %t685, ptr %l228
  %t686 = load i1, ptr %l228
  br i1 %t686, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  %t687 = load i32, ptr %l226
  %t688 = lshr i32 %t687, 16
  %t689 = and i32 %t687, 65535
  %t690 = icmp eq i32 %t688, 1
  %t691 = select i1 %t690, i32 0, i32 0
  %t692 = icmp eq i32 %t687, 0
  %t693 = shl i32 %t691, 16
  %t694 = or i32 %t693, %t689
  %t695 = select i1 %t692, i32 0, i32 %t694
  store i32 %t695, ptr %l229
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t696 = load i32, ptr %l229
  %t697 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t696, 0
  store { i32, { i64, ptr } } %t697, ptr %rv
  br label %ret
bb142:
  store %olang.scope zeroinitializer, ptr %s24
  %t698 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t698, ptr %l230
  %t699 = load { i64, ptr }, ptr %l230
  %t700 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t699)
  store i32 %t700, ptr %l231
  %t701 = icmp ne i32 %t700, 0
  br i1 %t701, label %bb144, label %ok.702
ok.702:
  br label %bb143
bb143:
  br label %bb148
bb144:
  %t703 = load i32, ptr %l231
  %t704 = ashr i32 %t703, 16
  store i32 %t704, ptr %l232
  %t705 = load i32, ptr %l232
  %t706 = icmp eq i32 %t705, 1
  store i1 %t706, ptr %l233
  %t707 = load i1, ptr %l233
  br i1 %t707, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  %t708 = load i32, ptr %l231
  %t709 = lshr i32 %t708, 16
  %t710 = and i32 %t708, 65535
  %t711 = icmp eq i32 %t709, 1
  %t712 = select i1 %t711, i32 0, i32 0
  %t713 = icmp eq i32 %t708, 0
  %t714 = shl i32 %t712, 16
  %t715 = or i32 %t714, %t710
  %t716 = select i1 %t713, i32 0, i32 %t715
  store i32 %t716, ptr %l234
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t717 = load i32, ptr %l234
  %t718 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t717, 0
  store { i32, { i64, ptr } } %t718, ptr %rv
  br label %ret
bb147:
  store %olang.scope zeroinitializer, ptr %s25
  call void @__olang_scope_close(ptr %s25)
  br label %bb148
bb148:
  store i32 65539, ptr %l235
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t719 = load i32, ptr %l235
  %t720 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t719, 0
  store { i32, { i64, ptr } } %t720, ptr %rv
  br label %ret
bb149:
  call void @__olang_scope_close(ptr %s23)
  br label %bb150
bb150:
  %t721 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t721, ptr %l236
  %t722 = load { i64, ptr }, ptr %l236
  %t723 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t722)
  store i32 %t723, ptr %l237
  %t724 = icmp ne i32 %t723, 0
  br i1 %t724, label %bb152, label %ok.725
ok.725:
  br label %bb151
bb151:
  br label %bb156
bb152:
  %t726 = load i32, ptr %l237
  %t727 = ashr i32 %t726, 16
  store i32 %t727, ptr %l238
  %t728 = load i32, ptr %l238
  %t729 = icmp eq i32 %t728, 1
  store i1 %t729, ptr %l239
  %t730 = load i1, ptr %l239
  br i1 %t730, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  %t731 = load i32, ptr %l237
  %t732 = lshr i32 %t731, 16
  %t733 = and i32 %t731, 65535
  %t734 = icmp eq i32 %t732, 1
  %t735 = select i1 %t734, i32 0, i32 0
  %t736 = icmp eq i32 %t731, 0
  %t737 = shl i32 %t735, 16
  %t738 = or i32 %t737, %t733
  %t739 = select i1 %t736, i32 0, i32 %t738
  store i32 %t739, ptr %l240
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t740 = load i32, ptr %l240
  %t741 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t740, 0
  store { i32, { i64, ptr } } %t741, ptr %rv
  br label %ret
bb155:
  store %olang.scope zeroinitializer, ptr %s26
  call void @__olang_scope_close(ptr %s26)
  br label %bb156
bb156:
  %t742 = load ptr, ptr %lp17
  %t743 = load { i64, ptr }, ptr %t742
  store { i64, ptr } %t743, ptr %l241
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t744 = load { i64, ptr }, ptr %l241
  %t745 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t744, 1
  store { i32, { i64, ptr } } %t745, ptr %rv
  br label %ret
bb157:
  %t746 = load ptr, ptr %l0
  store ptr %t746, ptr %l242
  %t747 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t747, ptr %l243
  %t748 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t748, ptr %l244
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s27
  store ptr %s27room, ptr %s27
  %t749 = extractvalue { i64, ptr } { i64 16, ptr @.d54 }, 1
  %t750 = extractvalue { i64, ptr } { i64 16, ptr @.d54 }, 0
  call void @__olang_sb_put(ptr %s27, ptr %t749, i64 %t750)
  %t751 = load { i64, ptr }, ptr %l243
  %t752 = extractvalue { i64, ptr } %t751, 1
  %t753 = extractvalue { i64, ptr } %t751, 0
  call void @__olang_sb_put(ptr %s27, ptr %t752, i64 %t753)
  %t754 = extractvalue { i64, ptr } { i64 6, ptr @.d55 }, 1
  %t755 = extractvalue { i64, ptr } { i64 6, ptr @.d55 }, 0
  call void @__olang_sb_put(ptr %s27, ptr %t754, i64 %t755)
  %t756 = load { i64, ptr }, ptr %l244
  %t757 = extractvalue { i64, ptr } %t756, 1
  %t758 = extractvalue { i64, ptr } %t756, 0
  call void @__olang_sb_put(ptr %s27, ptr %t757, i64 %t758)
  %t759 = load ptr, ptr %s27
  %t760 = getelementptr %olang.builder, ptr %s27, i32 0, i32 1
  %t761 = load i64, ptr %t760
  %t762 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t761)
  call void @llvm.memcpy.p0.p0.i64(ptr %t762, ptr %t759, i64 %t761, i1 false)
  %t763 = insertvalue { i64, ptr } undef, i64 %t761, 0
  %t764 = insertvalue { i64, ptr } %t763, ptr %t762, 1
  store { i64, ptr } %t764, ptr %l245
  call void @__olang_sb_done(ptr %s27)
  %t765 = load { i64, ptr }, ptr %l245
  %t766 = extractvalue { i64, ptr } %t765, 0
  %t767 = extractvalue { i64, ptr } %t765, 1
  %t768 = mul i64 %t766, 1
  %t769 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t768)
  call void @llvm.memcpy.p0.p0.i64(ptr %t769, ptr %t767, i64 %t768, i1 false)
  %t770 = insertvalue { i64, ptr } undef, i64 %t766, 0
  %t771 = insertvalue { i64, ptr } %t770, ptr %t769, 1
  store { i64, ptr } %t771, ptr %l246
  %t772 = load ptr, ptr %l242
  %t773 = load { i64, ptr }, ptr %l246
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s0, ptr %t772, { i64, ptr } %t773)
  br label %bb158
bb158:
  %t774 = load i64, ptr %l4
  store i64 %t774, ptr %l247
  %t775 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t775, ptr %l248
  %t776 = load { i64, ptr }, ptr %l248
  %t777 = extractvalue { i64, ptr } %t776, 0
  store i64 %t777, ptr %l249
  %t778 = load i64, ptr %l247
  %t779 = load i64, ptr %l249
  %t780 = icmp slt i64 %t778, %t779
  store i1 %t780, ptr %l250
  %t781 = load i1, ptr %l250
  br i1 %t781, label %bb159, label %bb160
bb159:
  %t782 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t782, ptr %l252
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s28
  store ptr %s28room, ptr %s28
  %t783 = extractvalue { i64, ptr } { i64 9, ptr @.d56 }, 1
  %t784 = extractvalue { i64, ptr } { i64 9, ptr @.d56 }, 0
  call void @__olang_sb_put(ptr %s28, ptr %t783, i64 %t784)
  %t785 = load { i64, ptr }, ptr %l252
  %t786 = extractvalue { i64, ptr } %t785, 1
  %t787 = extractvalue { i64, ptr } %t785, 0
  call void @__olang_sb_put(ptr %s28, ptr %t786, i64 %t787)
  %t788 = load ptr, ptr %s28
  %t789 = getelementptr %olang.builder, ptr %s28, i32 0, i32 1
  %t790 = load i64, ptr %t789
  %t791 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t790)
  call void @llvm.memcpy.p0.p0.i64(ptr %t791, ptr %t788, i64 %t790, i1 false)
  %t792 = insertvalue { i64, ptr } undef, i64 %t790, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t791, 1
  store { i64, ptr } %t793, ptr %l253
  call void @__olang_sb_done(ptr %s28)
  %t794 = load { i64, ptr }, ptr %l253
  %t795 = extractvalue { i64, ptr } %t794, 0
  %t796 = extractvalue { i64, ptr } %t794, 1
  %t797 = mul i64 %t795, 1
  %t798 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t797)
  call void @llvm.memcpy.p0.p0.i64(ptr %t798, ptr %t796, i64 %t797, i1 false)
  %t799 = insertvalue { i64, ptr } undef, i64 %t795, 0
  %t800 = insertvalue { i64, ptr } %t799, ptr %t798, 1
  store { i64, ptr } %t800, ptr %l254
  %t801 = load { i64, ptr }, ptr %l254
  store { i64, ptr } %t801, ptr %l251
  br label %bb161
bb160:
  store { i64, ptr } { i64 7, ptr @.d57 }, ptr %l251
  br label %bb161
bb161:
  %t802 = load { i64, ptr }, ptr %l251
  store { i64, ptr } %t802, ptr %l19
  %t803 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t803, ptr %l255
  %t804 = load { i64, ptr }, ptr %l255
  %t805 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t804)
  store i32 %t805, ptr %l256
  %t806 = icmp ne i32 %t805, 0
  br i1 %t806, label %bb163, label %ok.807
ok.807:
  br label %bb162
bb162:
  br label %bb167
bb163:
  %t808 = load i32, ptr %l256
  %t809 = ashr i32 %t808, 16
  store i32 %t809, ptr %l257
  %t810 = load i32, ptr %l257
  %t811 = icmp eq i32 %t810, 1
  store i1 %t811, ptr %l258
  %t812 = load i1, ptr %l258
  br i1 %t812, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  %t813 = load i32, ptr %l256
  %t814 = lshr i32 %t813, 16
  %t815 = and i32 %t813, 65535
  %t816 = icmp eq i32 %t814, 1
  %t817 = select i1 %t816, i32 0, i32 0
  %t818 = icmp eq i32 %t813, 0
  %t819 = shl i32 %t817, 16
  %t820 = or i32 %t819, %t815
  %t821 = select i1 %t818, i32 0, i32 %t820
  store i32 %t821, ptr %l259
  call void @__olang_scope_close(ptr %s0)
  %t822 = load i32, ptr %l259
  %t823 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t822, 0
  store { i32, { i64, ptr } } %t823, ptr %rv
  br label %ret
bb166:
  store %olang.scope zeroinitializer, ptr %s29
  call void @__olang_scope_close(ptr %s29)
  br label %bb167
bb167:
  store { i64, ptr } { i64 0, ptr @.d58 }, ptr %l260
  %t824 = load { i64, ptr }, ptr %l260
  store { i64, ptr } %t824, ptr %l261
  %t825 = load { i64, ptr }, ptr %l261
  %t826 = extractvalue { i64, ptr } %t825, 0
  store i64 %t826, ptr %l262
  %t827 = load i64, ptr %l262
  %t828 = mul i64 %t827, 1
  %t829 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t828)
  %t830 = insertvalue { i64, ptr } undef, i64 %t827, 0
  %t831 = insertvalue { i64, ptr } %t830, ptr %t829, 1
  store { i64, ptr } %t831, ptr %l263
  %t832 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t833 = load ptr, ptr %t832
  %t834 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t835 = load ptr, ptr %t834
  %t836 = load i64, ptr %l262
  %t837 = mul i64 %t836, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t833, ptr %t835, i64 %t837, i1 false)
  %t838 = load { i64, ptr }, ptr %l263
  store { i64, ptr } %t838, ptr %l20
  %t839 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t839, ptr %l264
  %t840 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t840, ptr %l265
  %t841 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t841, ptr %l266
  %t842 = insertvalue [9 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d59 }, 0
  %t843 = insertvalue [9 x { i64, ptr }] %t842, { i64, ptr } { i64 5, ptr @.d60 }, 1
  %t844 = insertvalue [9 x { i64, ptr }] %t843, { i64, ptr } { i64 7, ptr @.d61 }, 2
  %t845 = insertvalue [9 x { i64, ptr }] %t844, { i64, ptr } { i64 7, ptr @.d62 }, 3
  %t846 = insertvalue [9 x { i64, ptr }] %t845, { i64, ptr } { i64 1, ptr @.d63 }, 4
  %t847 = load { i64, ptr }, ptr %l264
  %t848 = insertvalue [9 x { i64, ptr }] %t846, { i64, ptr } %t847, 5
  %t849 = insertvalue [9 x { i64, ptr }] %t848, { i64, ptr } { i64 2, ptr @.d64 }, 6
  %t850 = load { i64, ptr }, ptr %l265
  %t851 = insertvalue [9 x { i64, ptr }] %t849, { i64, ptr } %t850, 7
  %t852 = load { i64, ptr }, ptr %l266
  %t853 = insertvalue [9 x { i64, ptr }] %t851, { i64, ptr } %t852, 8
  store [9 x { i64, ptr }] %t853, ptr %l267
  %t854 = load [9 x { i64, ptr }], ptr %l267
  %t855 = load ptr, ptr @__olang_prog_scope
  %t856 = call ptr @__olang_scope_alloc(ptr %t855, i64 144)
  store [9 x { i64, ptr }] %t854, ptr %t856
  %t857 = insertvalue { i64, ptr } undef, i64 9, 0
  %t858 = insertvalue { i64, ptr } %t857, ptr %t856, 1
  store { i64, ptr } %t858, ptr %l268
  %t859 = load { i64, ptr }, ptr %l268
  %t860 = extractvalue { i64, ptr } %t859, 0
  %t861 = extractvalue { i64, ptr } %t859, 1
  %t862 = mul i64 %t860, 16
  %t863 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t862)
  call void @llvm.memcpy.p0.p0.i64(ptr %t863, ptr %t861, i64 %t862, i1 false)
  %t864 = insertvalue { i64, ptr } undef, i64 %t860, 0
  %t865 = insertvalue { i64, ptr } %t864, ptr %t863, 1
  store { i64, ptr } %t865, ptr %l269
  %t866 = load { i64, ptr }, ptr %l269
  %t867 = call i1 @compiler_2ffetch_2egit(ptr %s0, { i64, ptr } %t866)
  store i1 %t867, ptr %l270
  br label %bb168
bb168:
  %t868 = load i1, ptr %l270
  br i1 %t868, label %bb169, label %bb170
bb169:
  store %olang.scope zeroinitializer, ptr %s30
  %t869 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t869, ptr %l271
  %t870 = load { i64, ptr }, ptr %l271
  %t871 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s0, { i64, ptr } %t870)
  store { i64, ptr } %t871, ptr %l272
  br label %bb171
bb170:
  br label %bb175
bb171:
  %t872 = load { i64, ptr }, ptr %l20
  %t873 = extractvalue { i64, ptr } %t872, 0
  store i64 %t873, ptr %l273
  %t874 = load { i64, ptr }, ptr %l272
  %t875 = extractvalue { i64, ptr } %t874, 0
  store i64 %t875, ptr %l274
  %t876 = load i64, ptr %l273
  %t877 = load i64, ptr %l274
  %t878 = icmp eq i64 %t876, %t877
  store i1 %t878, ptr %l275
  %t879 = load i1, ptr %l275
  br i1 %t879, label %bb172, label %bb173
bb172:
  %t880 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t881 = load ptr, ptr %t880
  %t882 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t883 = load ptr, ptr %t882
  %t884 = load i64, ptr %l274
  %t885 = mul i64 %t884, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t881, ptr %t883, i64 %t885, i1 false)
  br label %bb174
bb173:
  %t886 = load { i64, ptr }, ptr %l272
  store { i64, ptr } %t886, ptr %l20
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s30)
  br label %bb175
bb175:
  %t887 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t887, ptr %l276
  %t888 = load { i64, ptr }, ptr %l276
  %t889 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t888, { i64, ptr } { i64 0, ptr @.d65 })
  store i1 %t889, ptr %l277
  br label %bb176
bb176:
  %t890 = load i1, ptr %l277
  br i1 %t890, label %bb177, label %bb178
bb177:
  store %olang.scope zeroinitializer, ptr %s31
  %t891 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t891, ptr %l278
  %t892 = load { i64, ptr }, ptr %l278
  %t893 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t892)
  store i32 %t893, ptr %l279
  %t894 = icmp ne i32 %t893, 0
  br i1 %t894, label %bb180, label %ok.895
ok.895:
  br label %bb179
bb178:
  br label %bb185
bb179:
  br label %bb184
bb180:
  %t896 = load i32, ptr %l279
  %t897 = ashr i32 %t896, 16
  store i32 %t897, ptr %l280
  %t898 = load i32, ptr %l280
  %t899 = icmp eq i32 %t898, 1
  store i1 %t899, ptr %l281
  %t900 = load i1, ptr %l281
  br i1 %t900, label %bb181, label %bb182
bb181:
  br label %bb183
bb182:
  %t901 = load i32, ptr %l279
  %t902 = lshr i32 %t901, 16
  %t903 = and i32 %t901, 65535
  %t904 = icmp eq i32 %t902, 1
  %t905 = select i1 %t904, i32 0, i32 0
  %t906 = icmp eq i32 %t901, 0
  %t907 = shl i32 %t905, 16
  %t908 = or i32 %t907, %t903
  %t909 = select i1 %t906, i32 0, i32 %t908
  store i32 %t909, ptr %l282
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  %t910 = load i32, ptr %l282
  %t911 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t910, 0
  store { i32, { i64, ptr } } %t911, ptr %rv
  br label %ret
bb183:
  store %olang.scope zeroinitializer, ptr %s32
  call void @__olang_scope_close(ptr %s32)
  br label %bb184
bb184:
  store i32 65538, ptr %l283
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  %t912 = load i32, ptr %l283
  %t913 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t912, 0
  store { i32, { i64, ptr } } %t913, ptr %rv
  br label %ret
bb185:
  %t914 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t914, ptr %l284
  %t915 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t915, ptr %l285
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s33
  store ptr %s33room, ptr %s33
  %t916 = load { i64, ptr }, ptr %l284
  %t917 = extractvalue { i64, ptr } %t916, 1
  %t918 = extractvalue { i64, ptr } %t916, 0
  call void @__olang_sb_put(ptr %s33, ptr %t917, i64 %t918)
  %t919 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 1
  %t920 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 0
  call void @__olang_sb_put(ptr %s33, ptr %t919, i64 %t920)
  %t921 = load { i64, ptr }, ptr %l285
  %t922 = extractvalue { i64, ptr } %t921, 1
  %t923 = extractvalue { i64, ptr } %t921, 0
  call void @__olang_sb_put(ptr %s33, ptr %t922, i64 %t923)
  %t924 = load ptr, ptr %s33
  %t925 = getelementptr %olang.builder, ptr %s33, i32 0, i32 1
  %t926 = load i64, ptr %t925
  %t927 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t926)
  call void @llvm.memcpy.p0.p0.i64(ptr %t927, ptr %t924, i64 %t926, i1 false)
  %t928 = insertvalue { i64, ptr } undef, i64 %t926, 0
  %t929 = insertvalue { i64, ptr } %t928, ptr %t927, 1
  store { i64, ptr } %t929, ptr %l286
  call void @__olang_sb_done(ptr %s33)
  %t930 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t930, ptr %lp21
  %t931 = load { i64, ptr }, ptr %l286
  %t932 = load ptr, ptr %lp21
  store { i64, ptr } %t931, ptr %t932
  %t933 = load ptr, ptr %lp21
  %t934 = load { i64, ptr }, ptr %t933
  store { i64, ptr } %t934, ptr %l287
  %t935 = load { i64, ptr }, ptr %l287
  %t936 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t935)
  store i1 %t936, ptr %l288
  br label %bb186
bb186:
  %t937 = load i1, ptr %l288
  br i1 %t937, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s34
  %t938 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t938, ptr %l289
  %t939 = load { i64, ptr }, ptr %l289
  %t940 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t939)
  store i32 %t940, ptr %l290
  %t941 = icmp ne i32 %t940, 0
  br i1 %t941, label %bb190, label %ok.942
ok.942:
  br label %bb189
bb188:
  store %olang.scope zeroinitializer, ptr %s36
  %t943 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t943, ptr %l294
  %t944 = load ptr, ptr %lp21
  %t945 = load { i64, ptr }, ptr %t944
  store { i64, ptr } %t945, ptr %l295
  %t946 = load { i64, ptr }, ptr %l294
  %t947 = load { i64, ptr }, ptr %l295
  %t948 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t946, { i64, ptr } %t947)
  store i32 %t948, ptr %l296
  %t949 = icmp ne i32 %t948, 0
  br i1 %t949, label %bb196, label %ok.950
ok.950:
  br label %bb195
bb189:
  br label %bb194
bb190:
  %t951 = load i32, ptr %l290
  %t952 = ashr i32 %t951, 16
  store i32 %t952, ptr %l291
  %t953 = load i32, ptr %l291
  %t954 = icmp eq i32 %t953, 1
  store i1 %t954, ptr %l292
  %t955 = load i1, ptr %l292
  br i1 %t955, label %bb191, label %bb192
bb191:
  br label %bb193
bb192:
  %t956 = load i32, ptr %l290
  %t957 = lshr i32 %t956, 16
  %t958 = and i32 %t956, 65535
  %t959 = icmp eq i32 %t957, 1
  %t960 = select i1 %t959, i32 0, i32 0
  %t961 = icmp eq i32 %t956, 0
  %t962 = shl i32 %t960, 16
  %t963 = or i32 %t962, %t958
  %t964 = select i1 %t961, i32 0, i32 %t963
  store i32 %t964, ptr %l293
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  %t965 = load i32, ptr %l293
  %t966 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t965, 0
  store { i32, { i64, ptr } } %t966, ptr %rv
  br label %ret
bb193:
  store %olang.scope zeroinitializer, ptr %s35
  call void @__olang_scope_close(ptr %s35)
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s34)
  br label %bb207
bb195:
  br label %bb206
bb196:
  %t967 = load i32, ptr %l296
  %t968 = ashr i32 %t967, 16
  store i32 %t968, ptr %l297
  %t969 = load i32, ptr %l297
  %t970 = icmp eq i32 %t969, 1
  store i1 %t970, ptr %l298
  %t971 = load i1, ptr %l298
  br i1 %t971, label %bb197, label %bb198
bb197:
  br label %bb199
bb198:
  %t972 = load i32, ptr %l296
  %t973 = lshr i32 %t972, 16
  %t974 = and i32 %t972, 65535
  %t975 = icmp eq i32 %t973, 1
  %t976 = select i1 %t975, i32 0, i32 0
  %t977 = icmp eq i32 %t972, 0
  %t978 = shl i32 %t976, 16
  %t979 = or i32 %t978, %t974
  %t980 = select i1 %t977, i32 0, i32 %t979
  store i32 %t980, ptr %l299
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s0)
  %t981 = load i32, ptr %l299
  %t982 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t981, 0
  store { i32, { i64, ptr } } %t982, ptr %rv
  br label %ret
bb199:
  store %olang.scope zeroinitializer, ptr %s37
  %t983 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t983, ptr %l300
  %t984 = load { i64, ptr }, ptr %l300
  %t985 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t984)
  store i32 %t985, ptr %l301
  %t986 = icmp ne i32 %t985, 0
  br i1 %t986, label %bb201, label %ok.987
ok.987:
  br label %bb200
bb200:
  br label %bb205
bb201:
  %t988 = load i32, ptr %l301
  %t989 = ashr i32 %t988, 16
  store i32 %t989, ptr %l302
  %t990 = load i32, ptr %l302
  %t991 = icmp eq i32 %t990, 1
  store i1 %t991, ptr %l303
  %t992 = load i1, ptr %l303
  br i1 %t992, label %bb202, label %bb203
bb202:
  br label %bb204
bb203:
  %t993 = load i32, ptr %l301
  %t994 = lshr i32 %t993, 16
  %t995 = and i32 %t993, 65535
  %t996 = icmp eq i32 %t994, 1
  %t997 = select i1 %t996, i32 0, i32 0
  %t998 = icmp eq i32 %t993, 0
  %t999 = shl i32 %t997, 16
  %t1000 = or i32 %t999, %t995
  %t1001 = select i1 %t998, i32 0, i32 %t1000
  store i32 %t1001, ptr %l304
  call void @__olang_scope_close(ptr %s37)
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s0)
  %t1002 = load i32, ptr %l304
  %t1003 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t1002, 0
  store { i32, { i64, ptr } } %t1003, ptr %rv
  br label %ret
bb204:
  store %olang.scope zeroinitializer, ptr %s38
  call void @__olang_scope_close(ptr %s38)
  br label %bb205
bb205:
  store i32 65538, ptr %l305
  call void @__olang_scope_close(ptr %s37)
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s0)
  %t1004 = load i32, ptr %l305
  %t1005 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t1004, 0
  store { i32, { i64, ptr } } %t1005, ptr %rv
  br label %ret
bb206:
  call void @__olang_scope_close(ptr %s36)
  br label %bb207
bb207:
  %t1006 = load ptr, ptr %l0
  store ptr %t1006, ptr %l306
  %t1007 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t1007, ptr %l307
  %t1008 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t1008, ptr %l308
  %t1009 = load ptr, ptr %l306
  %t1010 = load { i64, ptr }, ptr %l307
  %t1011 = load { i64, ptr }, ptr %l308
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %s0, ptr %s0, ptr %t1009, { i64, ptr } %t1010, { i64, ptr } %t1011)
  br label %bb208
bb208:
  %t1012 = load ptr, ptr %l0
  store ptr %t1012, ptr %l309
  %t1013 = load ptr, ptr %l309
  %t1014 = getelementptr %"compiler/fetch:Fetcher", ptr %t1013, i32 0, i32 3
  %t1015 = load i1, ptr %t1014
  store i1 %t1015, ptr %l310
  %t1016 = load i1, ptr %l310
  br i1 %t1016, label %bb209, label %bb210
bb209:
  store %olang.scope zeroinitializer, ptr %s39
  %t1017 = load ptr, ptr %l0
  store ptr %t1017, ptr %l311
  %t1018 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t1018, ptr %l312
  %t1019 = load ptr, ptr %l311
  %t1020 = load { i64, ptr }, ptr %l312
  %t1021 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %s0, ptr %t1019, { i64, ptr } %t1020, i1 true)
  store i1 %t1021, ptr %l313
  br label %bb211
bb210:
  br label %bb256
bb211:
  %t1022 = load i1, ptr %l14
  store i1 %t1022, ptr %l314
  %t1023 = load i1, ptr %l314
  br i1 %t1023, label %bb212, label %bb213
bb212:
  %t1024 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t1024, ptr %l316
  %t1025 = load { i64, ptr }, ptr %l316
  %t1026 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t1025, { i64, ptr } { i64 0, ptr @.d67 })
  store i1 %t1026, ptr %l317
  br label %bb214
bb213:
  store i1 false, ptr %l315
  br label %bb215
bb214:
  %t1027 = load i1, ptr %l317
  store i1 %t1027, ptr %l315
  br label %bb215
bb215:
  %t1028 = load i1, ptr %l315
  br i1 %t1028, label %bb216, label %bb217
bb216:
  store %olang.scope zeroinitializer, ptr %s40
  %t1029 = load ptr, ptr %l0
  store ptr %t1029, ptr %l318
  %t1030 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t1030, ptr %l319
  %t1031 = load { i64, ptr }, ptr %l20
  %t1032 = extractvalue { i64, ptr } %t1031, 0
  store i64 %t1032, ptr %l320
  %t1033 = icmp sge i64 0, 0
  store i1 %t1033, ptr %l321
  %t1034 = load i1, ptr %l321
  br i1 %t1034, label %bb218, label %bb219
bb217:
  store %olang.scope zeroinitializer, ptr %s42
  %t1035 = load i1, ptr %l14
  store i1 %t1035, ptr %l327
  %t1036 = load i1, ptr %l327
  br i1 %t1036, label %bb225, label %bb226
bb218:
  %t1037 = icmp sle i64 0, 12
  store i1 %t1037, ptr %l322
  %t1038 = load i1, ptr %l322
  br i1 %t1038, label %bb220, label %bb221
bb219:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb220:
  %t1039 = load i64, ptr %l320
  %t1040 = icmp sle i64 12, %t1039
  store i1 %t1040, ptr %l323
  %t1041 = load i1, ptr %l323
  br i1 %t1041, label %bb222, label %bb223
bb221:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb222:
  %t1042 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1043 = load ptr, ptr %t1042
  %t1044 = getelementptr i8, ptr %t1043, i64 0
  %t1045 = sub i64 12, 0
  %t1046 = insertvalue { i64, ptr } undef, i64 %t1045, 0
  %t1047 = insertvalue { i64, ptr } %t1046, ptr %t1044, 1
  store { i64, ptr } %t1047, ptr %l324
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s41
  store ptr %s41room, ptr %s41
  %t1048 = extractvalue { i64, ptr } { i64 15, ptr @.d69 }, 1
  %t1049 = extractvalue { i64, ptr } { i64 15, ptr @.d69 }, 0
  call void @__olang_sb_put(ptr %s41, ptr %t1048, i64 %t1049)
  %t1050 = load { i64, ptr }, ptr %l319
  %t1051 = extractvalue { i64, ptr } %t1050, 1
  %t1052 = extractvalue { i64, ptr } %t1050, 0
  call void @__olang_sb_put(ptr %s41, ptr %t1051, i64 %t1052)
  %t1053 = extractvalue { i64, ptr } { i64 4, ptr @.d70 }, 1
  %t1054 = extractvalue { i64, ptr } { i64 4, ptr @.d70 }, 0
  call void @__olang_sb_put(ptr %s41, ptr %t1053, i64 %t1054)
  %t1055 = load { i64, ptr }, ptr %l324
  %t1056 = extractvalue { i64, ptr } %t1055, 1
  %t1057 = extractvalue { i64, ptr } %t1055, 0
  call void @__olang_sb_put(ptr %s41, ptr %t1056, i64 %t1057)
  %t1058 = load ptr, ptr %s41
  %t1059 = getelementptr %olang.builder, ptr %s41, i32 0, i32 1
  %t1060 = load i64, ptr %t1059
  %t1061 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1060)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1061, ptr %t1058, i64 %t1060, i1 false)
  %t1062 = insertvalue { i64, ptr } undef, i64 %t1060, 0
  %t1063 = insertvalue { i64, ptr } %t1062, ptr %t1061, 1
  store { i64, ptr } %t1063, ptr %l325
  call void @__olang_sb_done(ptr %s41)
  %t1064 = load { i64, ptr }, ptr %l325
  %t1065 = extractvalue { i64, ptr } %t1064, 0
  %t1066 = extractvalue { i64, ptr } %t1064, 1
  %t1067 = mul i64 %t1065, 1
  %t1068 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1067)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1068, ptr %t1066, i64 %t1067, i1 false)
  %t1069 = insertvalue { i64, ptr } undef, i64 %t1065, 0
  %t1070 = insertvalue { i64, ptr } %t1069, ptr %t1068, 1
  store { i64, ptr } %t1070, ptr %l326
  %t1071 = load ptr, ptr %l318
  %t1072 = load { i64, ptr }, ptr %l326
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s40, ptr %t1071, { i64, ptr } %t1072)
  br label %bb224
bb223:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb224:
  call void @__olang_scope_close(ptr %s40)
  br label %bb255
bb225:
  %t1073 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t1073, ptr %l329
  %t1074 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t1074, ptr %l330
  %t1075 = load { i64, ptr }, ptr %l329
  %t1076 = load { i64, ptr }, ptr %l330
  %t1077 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1075, { i64, ptr } %t1076)
  store i1 %t1077, ptr %l331
  br label %bb227
bb226:
  store i1 false, ptr %l328
  br label %bb228
bb227:
  %t1078 = load i1, ptr %l331
  %t1079 = xor i1 %t1078, true
  store i1 %t1079, ptr %l332
  %t1080 = load i1, ptr %l332
  store i1 %t1080, ptr %l328
  br label %bb228
bb228:
  %t1081 = load i1, ptr %l328
  br i1 %t1081, label %bb229, label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s43
  %t1082 = load ptr, ptr %l0
  store ptr %t1082, ptr %l333
  %t1083 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t1083, ptr %l334
  %t1084 = load { i64, ptr }, ptr %l20
  %t1085 = extractvalue { i64, ptr } %t1084, 0
  store i64 %t1085, ptr %l335
  %t1086 = icmp sge i64 0, 0
  store i1 %t1086, ptr %l336
  %t1087 = load i1, ptr %l336
  br i1 %t1087, label %bb231, label %bb232
bb230:
  store %olang.scope zeroinitializer, ptr %s45
  %t1088 = load i1, ptr %l14
  store i1 %t1088, ptr %l347
  %t1089 = load i1, ptr %l347
  br i1 %t1089, label %bb244, label %bb245
bb231:
  %t1090 = icmp sle i64 0, 12
  store i1 %t1090, ptr %l337
  %t1091 = load i1, ptr %l337
  br i1 %t1091, label %bb233, label %bb234
bb232:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb233:
  %t1092 = load i64, ptr %l335
  %t1093 = icmp sle i64 12, %t1092
  store i1 %t1093, ptr %l338
  %t1094 = load i1, ptr %l338
  br i1 %t1094, label %bb235, label %bb236
bb234:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb235:
  %t1095 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1096 = load ptr, ptr %t1095
  %t1097 = getelementptr i8, ptr %t1096, i64 0
  %t1098 = sub i64 12, 0
  %t1099 = insertvalue { i64, ptr } undef, i64 %t1098, 0
  %t1100 = insertvalue { i64, ptr } %t1099, ptr %t1097, 1
  store { i64, ptr } %t1100, ptr %l339
  %t1101 = load { i64, ptr }, ptr %l13
  %t1102 = extractvalue { i64, ptr } %t1101, 0
  store i64 %t1102, ptr %l340
  %t1103 = icmp sge i64 0, 0
  store i1 %t1103, ptr %l341
  %t1104 = load i1, ptr %l341
  br i1 %t1104, label %bb237, label %bb238
bb236:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb237:
  %t1105 = icmp sle i64 0, 12
  store i1 %t1105, ptr %l342
  %t1106 = load i1, ptr %l342
  br i1 %t1106, label %bb239, label %bb240
bb238:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb239:
  %t1107 = load i64, ptr %l340
  %t1108 = icmp sle i64 12, %t1107
  store i1 %t1108, ptr %l343
  %t1109 = load i1, ptr %l343
  br i1 %t1109, label %bb241, label %bb242
bb240:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb241:
  %t1110 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t1111 = load ptr, ptr %t1110
  %t1112 = getelementptr i8, ptr %t1111, i64 0
  %t1113 = sub i64 12, 0
  %t1114 = insertvalue { i64, ptr } undef, i64 %t1113, 0
  %t1115 = insertvalue { i64, ptr } %t1114, ptr %t1112, 1
  store { i64, ptr } %t1115, ptr %l344
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s44
  store ptr %s44room, ptr %s44
  %t1116 = extractvalue { i64, ptr } { i64 15, ptr @.d72 }, 1
  %t1117 = extractvalue { i64, ptr } { i64 15, ptr @.d72 }, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1116, i64 %t1117)
  %t1118 = load { i64, ptr }, ptr %l334
  %t1119 = extractvalue { i64, ptr } %t1118, 1
  %t1120 = extractvalue { i64, ptr } %t1118, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1119, i64 %t1120)
  %t1121 = extractvalue { i64, ptr } { i64 4, ptr @.d73 }, 1
  %t1122 = extractvalue { i64, ptr } { i64 4, ptr @.d73 }, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1121, i64 %t1122)
  %t1123 = load { i64, ptr }, ptr %l339
  %t1124 = extractvalue { i64, ptr } %t1123, 1
  %t1125 = extractvalue { i64, ptr } %t1123, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1124, i64 %t1125)
  %t1126 = extractvalue { i64, ptr } { i64 6, ptr @.d74 }, 1
  %t1127 = extractvalue { i64, ptr } { i64 6, ptr @.d74 }, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1126, i64 %t1127)
  %t1128 = load { i64, ptr }, ptr %l344
  %t1129 = extractvalue { i64, ptr } %t1128, 1
  %t1130 = extractvalue { i64, ptr } %t1128, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1129, i64 %t1130)
  %t1131 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 1
  %t1132 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1131, i64 %t1132)
  %t1133 = load ptr, ptr %s44
  %t1134 = getelementptr %olang.builder, ptr %s44, i32 0, i32 1
  %t1135 = load i64, ptr %t1134
  %t1136 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1136, ptr %t1133, i64 %t1135, i1 false)
  %t1137 = insertvalue { i64, ptr } undef, i64 %t1135, 0
  %t1138 = insertvalue { i64, ptr } %t1137, ptr %t1136, 1
  store { i64, ptr } %t1138, ptr %l345
  call void @__olang_sb_done(ptr %s44)
  %t1139 = load { i64, ptr }, ptr %l345
  %t1140 = extractvalue { i64, ptr } %t1139, 0
  %t1141 = extractvalue { i64, ptr } %t1139, 1
  %t1142 = mul i64 %t1140, 1
  %t1143 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1143, ptr %t1141, i64 %t1142, i1 false)
  %t1144 = insertvalue { i64, ptr } undef, i64 %t1140, 0
  %t1145 = insertvalue { i64, ptr } %t1144, ptr %t1143, 1
  store { i64, ptr } %t1145, ptr %l346
  %t1146 = load ptr, ptr %l333
  %t1147 = load { i64, ptr }, ptr %l346
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s43, ptr %t1146, { i64, ptr } %t1147)
  br label %bb243
bb242:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb243:
  call void @__olang_scope_close(ptr %s43)
  br label %bb254
bb244:
  store %olang.scope zeroinitializer, ptr %s46
  %t1148 = load ptr, ptr %l0
  store ptr %t1148, ptr %l348
  %t1149 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t1149, ptr %l349
  %t1150 = load { i64, ptr }, ptr %l20
  %t1151 = extractvalue { i64, ptr } %t1150, 0
  store i64 %t1151, ptr %l350
  %t1152 = icmp sge i64 0, 0
  store i1 %t1152, ptr %l351
  %t1153 = load i1, ptr %l351
  br i1 %t1153, label %bb246, label %bb247
bb245:
  br label %bb253
bb246:
  %t1154 = icmp sle i64 0, 12
  store i1 %t1154, ptr %l352
  %t1155 = load i1, ptr %l352
  br i1 %t1155, label %bb248, label %bb249
bb247:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb248:
  %t1156 = load i64, ptr %l350
  %t1157 = icmp sle i64 12, %t1156
  store i1 %t1157, ptr %l353
  %t1158 = load i1, ptr %l353
  br i1 %t1158, label %bb250, label %bb251
bb249:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb250:
  %t1159 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1160 = load ptr, ptr %t1159
  %t1161 = getelementptr i8, ptr %t1160, i64 0
  %t1162 = sub i64 12, 0
  %t1163 = insertvalue { i64, ptr } undef, i64 %t1162, 0
  %t1164 = insertvalue { i64, ptr } %t1163, ptr %t1161, 1
  store { i64, ptr } %t1164, ptr %l354
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s47
  store ptr %s47room, ptr %s47
  %t1165 = extractvalue { i64, ptr } { i64 7, ptr @.d77 }, 1
  %t1166 = extractvalue { i64, ptr } { i64 7, ptr @.d77 }, 0
  call void @__olang_sb_put(ptr %s47, ptr %t1165, i64 %t1166)
  %t1167 = load { i64, ptr }, ptr %l349
  %t1168 = extractvalue { i64, ptr } %t1167, 1
  %t1169 = extractvalue { i64, ptr } %t1167, 0
  call void @__olang_sb_put(ptr %s47, ptr %t1168, i64 %t1169)
  %t1170 = extractvalue { i64, ptr } { i64 15, ptr @.d78 }, 1
  %t1171 = extractvalue { i64, ptr } { i64 15, ptr @.d78 }, 0
  call void @__olang_sb_put(ptr %s47, ptr %t1170, i64 %t1171)
  %t1172 = load { i64, ptr }, ptr %l354
  %t1173 = extractvalue { i64, ptr } %t1172, 1
  %t1174 = extractvalue { i64, ptr } %t1172, 0
  call void @__olang_sb_put(ptr %s47, ptr %t1173, i64 %t1174)
  %t1175 = load ptr, ptr %s47
  %t1176 = getelementptr %olang.builder, ptr %s47, i32 0, i32 1
  %t1177 = load i64, ptr %t1176
  %t1178 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1178, ptr %t1175, i64 %t1177, i1 false)
  %t1179 = insertvalue { i64, ptr } undef, i64 %t1177, 0
  %t1180 = insertvalue { i64, ptr } %t1179, ptr %t1178, 1
  store { i64, ptr } %t1180, ptr %l355
  call void @__olang_sb_done(ptr %s47)
  %t1181 = load { i64, ptr }, ptr %l355
  %t1182 = extractvalue { i64, ptr } %t1181, 0
  %t1183 = extractvalue { i64, ptr } %t1181, 1
  %t1184 = mul i64 %t1182, 1
  %t1185 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1185, ptr %t1183, i64 %t1184, i1 false)
  %t1186 = insertvalue { i64, ptr } undef, i64 %t1182, 0
  %t1187 = insertvalue { i64, ptr } %t1186, ptr %t1185, 1
  store { i64, ptr } %t1187, ptr %l356
  %t1188 = load ptr, ptr %l348
  %t1189 = load { i64, ptr }, ptr %l356
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s46, ptr %t1188, { i64, ptr } %t1189)
  br label %bb252
bb251:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb252:
  call void @__olang_scope_close(ptr %s46)
  br label %bb253
bb253:
  call void @__olang_scope_close(ptr %s45)
  br label %bb254
bb254:
  call void @__olang_scope_close(ptr %s42)
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s39)
  br label %bb256
bb256:
  %t1190 = load ptr, ptr %lp21
  %t1191 = load { i64, ptr }, ptr %t1190
  store { i64, ptr } %t1191, ptr %l357
  call void @__olang_scope_close(ptr %s0)
  %t1192 = load { i64, ptr }, ptr %l357
  %t1193 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t1192, 1
  store { i32, { i64, ptr } } %t1193, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l8
  %t2 = load ptr, ptr %l8
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t2)
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2
  %t3 = load ptr, ptr %l0
  store ptr %t3, ptr %l9
  %t4 = load ptr, ptr %l9
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t4, i32 0, i32 6
  store ptr %t5, ptr %l10
  %t6 = load ptr, ptr %l10
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t6)
  store i64 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i64, ptr %l11
  store i64 %t8, ptr %l3
  store i64 1, ptr %l4
  %t9 = load i64, ptr %l3
  store i64 %t9, ptr %l12
  %t10 = load i64, ptr %l2
  store i64 %t10, ptr %l13
  %t11 = load i64, ptr %l12
  %t12 = load i64, ptr %l13
  %t13 = icmp sgt i64 %t11, %t12
  store i1 %t13, ptr %l14
  %t14 = load i1, ptr %l14
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4
  store i64 %t15, ptr %l16
  %t16 = load i64, ptr %l16
  %t17 = icmp sgt i64 %t16, 0
  store i1 %t17, ptr %l17
  %t18 = load i1, ptr %l17
  br i1 %t18, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3
  store i64 %t19, ptr %l19
  %t20 = load i64, ptr %l2
  store i64 %t20, ptr %l20
  %t21 = load i64, ptr %l19
  %t22 = load i64, ptr %l20
  %t23 = sub i64 %t21, %t22
  store i64 %t23, ptr %l21
  %t24 = load i64, ptr %l4
  store i64 %t24, ptr %l22
  %t25 = load i64, ptr %l21
  %t26 = load i64, ptr %l22
  %t27 = add i64 %t25, %t26
  store i64 %t27, ptr %l23
  %t28 = load i64, ptr %l23
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l24
  %t30 = load i64, ptr %l4
  store i64 %t30, ptr %l25
  %t31 = load i64, ptr %l24
  %t32 = load i64, ptr %l25
  %t33 = sdiv i64 %t31, %t32
  store i64 %t33, ptr %l26
  %t34 = load i64, ptr %l26
  store i64 %t34, ptr %l18
  br label %bb7
bb6:
  store i64 0, ptr %l18
  br label %bb7
bb7:
  %t35 = load i64, ptr %l18
  store i64 %t35, ptr %l15
  br label %bb8
bb8:
  %t36 = load i64, ptr %l15
  store i64 %t36, ptr %l5
  store i64 0, ptr %l6
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6
  store i64 %t37, ptr %l27
  %t38 = load i64, ptr %l5
  store i64 %t38, ptr %l28
  %t39 = load i64, ptr %l27
  %t40 = load i64, ptr %l28
  %t41 = icmp slt i64 %t39, %t40
  store i1 %t41, ptr %l29
  %t42 = load i1, ptr %l29
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l30
  %t44 = load i1, ptr %l30
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2
  store i64 %t45, ptr %l31
  %t46 = load i64, ptr %l6
  store i64 %t46, ptr %l32
  %t47 = load i64, ptr %l4
  store i64 %t47, ptr %l33
  %t48 = load i64, ptr %l32
  %t49 = load i64, ptr %l33
  %t50 = mul i64 %t48, %t49
  store i64 %t50, ptr %l34
  %t51 = load i64, ptr %l31
  %t52 = load i64, ptr %l34
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l35
  %t54 = load i64, ptr %l35
  store i64 %t54, ptr %l7
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l36
  %t56 = load ptr, ptr %l36
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t56, i32 0, i32 6
  store ptr %t57, ptr %l37
  %t58 = load i64, ptr %l7
  store i64 %t58, ptr %l38
  %t59 = load ptr, ptr %l37
  %t60 = load i64, ptr %l38
  %t61 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store { i64, ptr } %t61, ptr %l39
  br label %bb13
bb13:
  %t62 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t62, ptr %l40
  %t63 = load { i64, ptr }, ptr %l39
  %t64 = load { i64, ptr }, ptr %l40
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t64)
  store i1 %t65, ptr %l41
  br label %bb14
bb14:
  %t66 = load i1, ptr %l41
  br i1 %t66, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0
  store ptr %t67, ptr %l42
  %t68 = load ptr, ptr %l42
  %t69 = getelementptr %"compiler/fetch:Fetcher", ptr %t68, i32 0, i32 7
  store ptr %t69, ptr %l43
  %t70 = load i64, ptr %l7
  store i64 %t70, ptr %l44
  %t71 = load ptr, ptr %l43
  %t72 = load i64, ptr %l44
  %t73 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store { i64, ptr } %t73, ptr %l45
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l45
  %t75 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t74, 1
  store { i32, { i64, ptr } } %t75, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = load i64, ptr %l6
  store i64 %t76, ptr %l46
  %t77 = load i64, ptr %l46
  %t78 = add i64 %t77, 1
  store i64 %t78, ptr %l47
  %t79 = load i64, ptr %l47
  store i64 %t79, ptr %l6
  call void @__olang_scope_close(ptr %s4)
  br label %bb9
bb20:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %l48
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l48
  %t81 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t80, 0
  store { i32, { i64, ptr } } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:LineIter"
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %s17 = alloca %olang.builder
  %s17room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l11
  %t2 = load ptr, ptr %l11
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t2, i32 0, i32 5
  %t4 = load i1, ptr %t3
  store i1 %t4, ptr %l12
  %t5 = load i1, ptr %l12
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l13
  %t7 = load ptr, ptr %l13
  %t8 = getelementptr %"compiler/fetch:Fetcher", ptr %t7, i32 0, i32 5
  store i1 true, ptr %t8
  %t9 = load ptr, ptr %l0
  store ptr %t9, ptr %l15
  %t10 = load ptr, ptr %l15
  %t11 = getelementptr %"compiler/fetch:Fetcher", ptr %t10, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11
  store { i64, ptr } %t12, ptr %l16
  %t13 = load { i64, ptr }, ptr %l16
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %t13)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l18
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l17
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t19, ptr %l14
  br label %bb9
bb5:
  %t20 = load i32, ptr %l18
  %t21 = ashr i32 %t20, 16
  store i32 %t21, ptr %l19
  %t22 = load i32, ptr %l19
  %t23 = icmp eq i32 %t22, 1
  store i1 %t23, ptr %l20
  %t24 = load i1, ptr %l20
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t25 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t25, ptr %l1
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t26, ptr %l21
  %t27 = load { i64, ptr }, ptr %l21
  %t28 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t27)
  store %"std/prelude/text:LineIter" %t28, ptr %l22
  br label %bb10
bb10:
  %t29 = load %"std/prelude/text:LineIter", ptr %l22
  store %"std/prelude/text:LineIter" %t29, ptr %l2
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l24
  %t30 = load ptr, ptr %l24
  %t31 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %t30)
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l26
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb13, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l25
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t36, ptr %l23
  br label %bb17
bb13:
  %t37 = load i32, ptr %l26
  %t38 = ashr i32 %t37, 16
  store i32 %t38, ptr %l27
  %t39 = load i32, ptr %l27
  %t40 = icmp eq i32 %t39, 1
  store i1 %t40, ptr %l28
  %t41 = load i1, ptr %l28
  br i1 %t41, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c80)
  unreachable
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb17:
  %t42 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t42, ptr %l3
  %t43 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t43, ptr %l29
  %t44 = load { i64, ptr }, ptr %l29
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t44, { i64, ptr } { i64 1, ptr @.d81 })
  store i1 %t45, ptr %l30
  br label %bb18
bb18:
  %t46 = load i1, ptr %l30
  br i1 %t46, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb20:
  br label %bb21
bb21:
  %t47 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t47, ptr %l31
  %t48 = load { i64, ptr }, ptr %l31
  %t49 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t48)
  store { i64, ptr } %t49, ptr %l32
  br label %bb22
bb22:
  %t50 = load { i64, ptr }, ptr %l32
  %t51 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s4, { i64, ptr } %t50, { i64, ptr } { i64 1, ptr @.d82 })
  store { i64, ptr } %t51, ptr %l33
  br label %bb23
bb23:
  %t52 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t52, ptr %l4
  store { i64, ptr } { i64 0, ptr @.d83 }, ptr %l34
  %t53 = load { i64, ptr }, ptr %l34
  store { i64, ptr } %t53, ptr %l35
  %t54 = load { i64, ptr }, ptr %l35
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l36
  %t56 = load i64, ptr %l36
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l37
  %t61 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  %t63 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  %t65 = load i64, ptr %l36
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l37
  store { i64, ptr } %t67, ptr %l5
  store { i64, ptr } { i64 0, ptr @.d84 }, ptr %l38
  %t68 = load { i64, ptr }, ptr %l38
  store { i64, ptr } %t68, ptr %l39
  %t69 = load { i64, ptr }, ptr %l39
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l40
  %t71 = load i64, ptr %l40
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l41
  %t76 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  %t78 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  %t80 = load i64, ptr %l40
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l41
  store { i64, ptr } %t82, ptr %l6
  store %olang.scope zeroinitializer, ptr %s6
  %t83 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t83, ptr %l42
  %t84 = load { i64, ptr }, ptr %l42
  store { i64, ptr } %t84, ptr %l7
  store i64 0, ptr %l8
  %t85 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t85, ptr %l43
  %t86 = load { i64, ptr }, ptr %l43
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l44
  %t88 = load i64, ptr %l44
  store i64 %t88, ptr %l9
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load i64, ptr %l8
  store i64 %t89, ptr %l45
  %t90 = load i64, ptr %l9
  store i64 %t90, ptr %l46
  %t91 = load i64, ptr %l45
  %t92 = load i64, ptr %l46
  %t93 = icmp slt i64 %t91, %t92
  store i1 %t93, ptr %l47
  %t94 = load i1, ptr %l47
  %t95 = xor i1 %t94, true
  store i1 %t95, ptr %l48
  %t96 = load i1, ptr %l48
  br i1 %t96, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t97 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t97, ptr %l49
  %t98 = load i64, ptr %l8
  store i64 %t98, ptr %l50
  %t99 = load i64, ptr %l50
  %t100 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t101 = load ptr, ptr %t100
  %t102 = getelementptr { i64, ptr }, ptr %t101, i64 %t99
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l51
  %t104 = load { i64, ptr }, ptr %l51
  store { i64, ptr } %t104, ptr %l10
  %t105 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t105, ptr %l52
  %t106 = load { i64, ptr }, ptr %l52
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t106, { i64, ptr } { i64 0, ptr @.d85 })
  store i1 %t107, ptr %l53
  br label %bb28
bb28:
  %t108 = load i1, ptr %l53
  br i1 %t108, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb30:
  br label %bb31
bb31:
  %t109 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t109, ptr %l54
  %t110 = load { i64, ptr }, ptr %l54
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s7, { i64, ptr } %t110, { i64, ptr } { i64 0, ptr @.d86 })
  store i1 %t111, ptr %l55
  br label %bb32
bb32:
  %t112 = load i1, ptr %l55
  br i1 %t112, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t113 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t113, ptr %l56
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t114 = load { i64, ptr }, ptr %l56
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  call void @__olang_sb_put(ptr %s10, ptr %t115, i64 %t116)
  %t117 = load ptr, ptr %s10
  %t118 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t119 = load i64, ptr %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t117, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l57
  call void @__olang_sb_done(ptr %s10)
  %t123 = load { i64, ptr }, ptr %l5
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l58
  %t125 = load { i64, ptr }, ptr %l57
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l59
  %t127 = load i64, ptr %l58
  %t128 = load i64, ptr %l59
  %t129 = icmp eq i64 %t127, %t128
  store i1 %t129, ptr %l60
  %t130 = load i1, ptr %l60
  br i1 %t130, label %bb35, label %bb36
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t131 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t131, ptr %l61
  %t132 = load { i64, ptr }, ptr %l61
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s11, { i64, ptr } %t132, { i64, ptr } { i64 0, ptr @.d87 })
  store i1 %t133, ptr %l62
  br label %bb38
bb35:
  %t134 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t135 = load ptr, ptr %t134
  %t136 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  %t138 = load i64, ptr %l59
  %t139 = mul i64 %t138, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t135, ptr %t137, i64 %t139, i1 false)
  br label %bb37
bb36:
  %t140 = load { i64, ptr }, ptr %l57
  store { i64, ptr } %t140, ptr %l5
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb45
bb38:
  %t141 = load i1, ptr %l62
  br i1 %t141, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s12
  %t142 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t142, ptr %l63
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t143 = load { i64, ptr }, ptr %l63
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  call void @__olang_sb_put(ptr %s13, ptr %t144, i64 %t145)
  %t146 = load ptr, ptr %s13
  %t147 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t148 = load i64, ptr %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t146, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l64
  call void @__olang_sb_done(ptr %s13)
  %t152 = load { i64, ptr }, ptr %l6
  %t153 = extractvalue { i64, ptr } %t152, 0
  store i64 %t153, ptr %l65
  %t154 = load { i64, ptr }, ptr %l64
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l66
  %t156 = load i64, ptr %l65
  %t157 = load i64, ptr %l66
  %t158 = icmp eq i64 %t156, %t157
  store i1 %t158, ptr %l67
  %t159 = load i1, ptr %l67
  br i1 %t159, label %bb41, label %bb42
bb40:
  br label %bb44
bb41:
  %t160 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t161 = load ptr, ptr %t160
  %t162 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t163 = load ptr, ptr %t162
  %t164 = load i64, ptr %l66
  %t165 = mul i64 %t164, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t161, ptr %t163, i64 %t165, i1 false)
  br label %bb43
bb42:
  %t166 = load { i64, ptr }, ptr %l64
  store { i64, ptr } %t166, ptr %l6
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s11)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s14
  %t167 = load i64, ptr %l8
  store i64 %t167, ptr %l68
  %t168 = load i64, ptr %l68
  %t169 = add i64 %t168, 1
  store i64 %t169, ptr %l69
  %t170 = load i64, ptr %l69
  store i64 %t170, ptr %l8
  call void @__olang_scope_close(ptr %s14)
  br label %bb24
bb47:
  call void @__olang_scope_close(ptr %s6)
  %t171 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t171, ptr %l70
  %t172 = load { i64, ptr }, ptr %l70
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t172, { i64, ptr } { i64 0, ptr @.d88 })
  store i1 %t173, ptr %l71
  br label %bb48
bb48:
  %t174 = load i1, ptr %l71
  br i1 %t174, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s15
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb50:
  br label %bb51
bb51:
  %t175 = load ptr, ptr %l0
  store ptr %t175, ptr %l72
  %t176 = load ptr, ptr %l72
  %t177 = getelementptr %"compiler/fetch:Fetcher", ptr %t176, i32 0, i32 6
  store ptr %t177, ptr %l73
  %t178 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t178, ptr %l74
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  %t179 = load { i64, ptr }, ptr %l74
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  call void @__olang_sb_put(ptr %s16, ptr %t180, i64 %t181)
  %t182 = load ptr, ptr %s16
  %t183 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t184 = load i64, ptr %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t182, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l75
  call void @__olang_sb_done(ptr %s16)
  %t188 = load { i64, ptr }, ptr %l75
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  store { i64, ptr } %t194, ptr %l76
  %t195 = load ptr, ptr %l73
  %t196 = load { i64, ptr }, ptr %l76
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t195, { i64, ptr } %t196)
  br label %bb52
bb52:
  %t197 = load ptr, ptr %l0
  store ptr %t197, ptr %l77
  %t198 = load ptr, ptr %l77
  %t199 = getelementptr %"compiler/fetch:Fetcher", ptr %t198, i32 0, i32 7
  store ptr %t199, ptr %l78
  %t200 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t200, ptr %l79
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s17
  store ptr %s17room, ptr %s17
  %t201 = load { i64, ptr }, ptr %l79
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  call void @__olang_sb_put(ptr %s17, ptr %t202, i64 %t203)
  %t204 = load ptr, ptr %s17
  %t205 = getelementptr %olang.builder, ptr %s17, i32 0, i32 1
  %t206 = load i64, ptr %t205
  %t207 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t204, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  store { i64, ptr } %t209, ptr %l80
  call void @__olang_sb_done(ptr %s17)
  %t210 = load { i64, ptr }, ptr %l80
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l81
  %t217 = load ptr, ptr %l78
  %t218 = load { i64, ptr }, ptr %l81
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t217, { i64, ptr } %t218)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  br label %bb11
bb55:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %l123 = alloca ptr
  %l124 = alloca { ptr, ptr }
  %l125 = alloca %"std/prelude/text:StringBuilder"
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l141 = alloca i64
  %l142 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca i64
  %l148 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca i32
  %l158 = alloca i32
  %l159 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %t244 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l22
  %t2 = load ptr, ptr %l22
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t2)
  br label %bb1
bb1:
  store i64 -1, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4
  %t3 = load ptr, ptr %l0
  store ptr %t3, ptr %l23
  %t4 = load ptr, ptr %l23
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t4, i32 0, i32 6
  store ptr %t5, ptr %l24
  %t6 = load ptr, ptr %l24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t6)
  store i64 %t7, ptr %l25
  br label %bb2
bb2:
  %t8 = load i64, ptr %l25
  store i64 %t8, ptr %l5
  store i64 1, ptr %l6
  %t9 = load i64, ptr %l5
  store i64 %t9, ptr %l26
  %t10 = load i64, ptr %l4
  store i64 %t10, ptr %l27
  %t11 = load i64, ptr %l26
  %t12 = load i64, ptr %l27
  %t13 = icmp sgt i64 %t11, %t12
  store i1 %t13, ptr %l28
  %t14 = load i1, ptr %l28
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l6
  store i64 %t15, ptr %l30
  %t16 = load i64, ptr %l30
  %t17 = icmp sgt i64 %t16, 0
  store i1 %t17, ptr %l31
  %t18 = load i1, ptr %l31
  br i1 %t18, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l29
  br label %bb8
bb5:
  %t19 = load i64, ptr %l5
  store i64 %t19, ptr %l33
  %t20 = load i64, ptr %l4
  store i64 %t20, ptr %l34
  %t21 = load i64, ptr %l33
  %t22 = load i64, ptr %l34
  %t23 = sub i64 %t21, %t22
  store i64 %t23, ptr %l35
  %t24 = load i64, ptr %l6
  store i64 %t24, ptr %l36
  %t25 = load i64, ptr %l35
  %t26 = load i64, ptr %l36
  %t27 = add i64 %t25, %t26
  store i64 %t27, ptr %l37
  %t28 = load i64, ptr %l37
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l38
  %t30 = load i64, ptr %l6
  store i64 %t30, ptr %l39
  %t31 = load i64, ptr %l38
  %t32 = load i64, ptr %l39
  %t33 = sdiv i64 %t31, %t32
  store i64 %t33, ptr %l40
  %t34 = load i64, ptr %l40
  store i64 %t34, ptr %l32
  br label %bb7
bb6:
  store i64 0, ptr %l32
  br label %bb7
bb7:
  %t35 = load i64, ptr %l32
  store i64 %t35, ptr %l29
  br label %bb8
bb8:
  %t36 = load i64, ptr %l29
  store i64 %t36, ptr %l7
  store i64 0, ptr %l8
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l8
  store i64 %t37, ptr %l41
  %t38 = load i64, ptr %l7
  store i64 %t38, ptr %l42
  %t39 = load i64, ptr %l41
  %t40 = load i64, ptr %l42
  %t41 = icmp slt i64 %t39, %t40
  store i1 %t41, ptr %l43
  %t42 = load i1, ptr %l43
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l44
  %t44 = load i1, ptr %l44
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l4
  store i64 %t45, ptr %l45
  %t46 = load i64, ptr %l8
  store i64 %t46, ptr %l46
  %t47 = load i64, ptr %l6
  store i64 %t47, ptr %l47
  %t48 = load i64, ptr %l46
  %t49 = load i64, ptr %l47
  %t50 = mul i64 %t48, %t49
  store i64 %t50, ptr %l48
  %t51 = load i64, ptr %l45
  %t52 = load i64, ptr %l48
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l49
  %t54 = load i64, ptr %l49
  store i64 %t54, ptr %l9
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l50
  %t56 = load ptr, ptr %l50
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t56, i32 0, i32 6
  store ptr %t57, ptr %l51
  %t58 = load i64, ptr %l9
  store i64 %t58, ptr %l52
  %t59 = load ptr, ptr %l51
  %t60 = load i64, ptr %l52
  %t61 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store { i64, ptr } %t61, ptr %l53
  br label %bb13
bb13:
  %t62 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t62, ptr %l54
  %t63 = load { i64, ptr }, ptr %l53
  %t64 = load { i64, ptr }, ptr %l54
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t64)
  store i1 %t65, ptr %l55
  br label %bb14
bb14:
  %t66 = load i1, ptr %l55
  br i1 %t66, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9
  store i64 %t67, ptr %l56
  %t68 = load i64, ptr %l56
  store i64 %t68, ptr %l3
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load i64, ptr %l8
  store i64 %t69, ptr %l57
  %t70 = load i64, ptr %l57
  %t71 = add i64 %t70, 1
  store i64 %t71, ptr %l58
  %t72 = load i64, ptr %l58
  store i64 %t72, ptr %l8
  call void @__olang_scope_close(ptr %s4)
  br label %bb9
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t73 = load i64, ptr %l3
  store i64 %t73, ptr %l59
  %t74 = load i64, ptr %l59
  %t75 = icmp sge i64 %t74, 0
  store i1 %t75, ptr %l60
  %t76 = load i1, ptr %l60
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0
  store ptr %t77, ptr %l62
  %t78 = load ptr, ptr %l62
  %t79 = getelementptr %"compiler/fetch:Fetcher", ptr %t78, i32 0, i32 7
  store ptr %t79, ptr %l63
  %t80 = load i64, ptr %l3
  store i64 %t80, ptr %l64
  %t81 = load ptr, ptr %l63
  %t82 = load i64, ptr %l64
  %t83 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t81, i64 %t82)
  store { i64, ptr } %t83, ptr %l65
  br label %bb22
bb21:
  store i1 false, ptr %l61
  br label %bb24
bb22:
  %t84 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t84, ptr %l66
  %t85 = load { i64, ptr }, ptr %l65
  %t86 = load { i64, ptr }, ptr %l66
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t85, { i64, ptr } %t86)
  store i1 %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load i1, ptr %l67
  store i1 %t88, ptr %l61
  br label %bb24
bb24:
  %t89 = load i1, ptr %l61
  br i1 %t89, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t90 = load i64, ptr %l3
  store i64 %t90, ptr %l68
  %t91 = load i64, ptr %l68
  %t92 = icmp sge i64 %t91, 0
  store i1 %t92, ptr %l69
  %t93 = load i1, ptr %l69
  br i1 %t93, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t94 = load ptr, ptr %l0
  store ptr %t94, ptr %l70
  %t95 = load ptr, ptr %l70
  %t96 = getelementptr %"compiler/fetch:Fetcher", ptr %t95, i32 0, i32 7
  store ptr %t96, ptr %l71
  %t97 = load i64, ptr %l3
  store i64 %t97, ptr %l72
  %t98 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t98, ptr %l73
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t99 = load { i64, ptr }, ptr %l73
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  call void @__olang_sb_put(ptr %s7, ptr %t100, i64 %t101)
  %t102 = load ptr, ptr %s7
  %t103 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t104 = load i64, ptr %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t102, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l74
  call void @__olang_sb_done(ptr %s7)
  %t108 = load { i64, ptr }, ptr %l74
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l75
  %t115 = load ptr, ptr %l71
  %t116 = load i64, ptr %l72
  %t117 = load { i64, ptr }, ptr %l75
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v0, ptr %t115, i64 %t116, { i64, ptr } %t117)
  br label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t118 = load ptr, ptr %l0
  store ptr %t118, ptr %l76
  %t119 = load ptr, ptr %l76
  %t120 = getelementptr %"compiler/fetch:Fetcher", ptr %t119, i32 0, i32 6
  store ptr %t120, ptr %l77
  %t121 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t121, ptr %l78
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t122 = load { i64, ptr }, ptr %l78
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  call void @__olang_sb_put(ptr %s9, ptr %t123, i64 %t124)
  %t125 = load ptr, ptr %s9
  %t126 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t127 = load i64, ptr %t126
  %t128 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t125, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  store { i64, ptr } %t130, ptr %l79
  call void @__olang_sb_done(ptr %s9)
  %t131 = load { i64, ptr }, ptr %l79
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l80
  %t138 = load ptr, ptr %l77
  %t139 = load { i64, ptr }, ptr %l80
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t138, { i64, ptr } %t139)
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb31:
  %t140 = load ptr, ptr %l0
  store ptr %t140, ptr %l81
  %t141 = load ptr, ptr %l81
  %t142 = getelementptr %"compiler/fetch:Fetcher", ptr %t141, i32 0, i32 7
  store ptr %t142, ptr %l82
  %t143 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t143, ptr %l83
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t144 = load { i64, ptr }, ptr %l83
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  call void @__olang_sb_put(ptr %s10, ptr %t145, i64 %t146)
  %t147 = load ptr, ptr %s10
  %t148 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t149 = load i64, ptr %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t147, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  store { i64, ptr } %t152, ptr %l84
  call void @__olang_sb_done(ptr %s10)
  %t153 = load { i64, ptr }, ptr %l84
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l85
  %t160 = load ptr, ptr %l82
  %t161 = load { i64, ptr }, ptr %l85
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t160, { i64, ptr } %t161)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l0
  store ptr %t162, ptr %l86
  %t163 = load ptr, ptr %l86
  %t164 = getelementptr %"compiler/fetch:Fetcher", ptr %t163, i32 0, i32 6
  store ptr %t164, ptr %l87
  %t165 = load ptr, ptr %l87
  %t166 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t165)
  store i64 %t166, ptr %l88
  br label %bb34
bb34:
  %t167 = load i64, ptr %l88
  %t168 = icmp sge i64 %t167, 0
  store i1 %t168, ptr %l89
  %t169 = load i1, ptr %l89
  br i1 %t169, label %bb35, label %bb36
bb35:
  %t170 = load i64, ptr %l88
  %t171 = icmp sle i64 %t170, 1152921504606846975
  store i1 %t171, ptr %l90
  %t172 = load i1, ptr %l90
  br i1 %t172, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @.c89)
  unreachable
bb37:
  %t173 = load i64, ptr %l88
  %t174 = mul i64 %t173, 8
  %t175 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  store { i64, ptr } %t177, ptr %l91
  %t178 = load { i64, ptr }, ptr %l91
  store { i64, ptr } %t178, ptr %l10
  store %olang.scope zeroinitializer, ptr %s11
  store i64 0, ptr %l11
  %t179 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t179, ptr %l92
  %t180 = load { i64, ptr }, ptr %l92
  %t181 = extractvalue { i64, ptr } %t180, 0
  store i64 %t181, ptr %l93
  %t182 = load i64, ptr %l93
  store i64 %t182, ptr %l12
  store i64 1, ptr %l13
  %t183 = load i64, ptr %l12
  store i64 %t183, ptr %l94
  %t184 = load i64, ptr %l11
  store i64 %t184, ptr %l95
  %t185 = load i64, ptr %l94
  %t186 = load i64, ptr %l95
  %t187 = icmp sgt i64 %t185, %t186
  store i1 %t187, ptr %l96
  %t188 = load i1, ptr %l96
  br i1 %t188, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @.c89)
  unreachable
bb39:
  %t189 = load i64, ptr %l13
  store i64 %t189, ptr %l98
  %t190 = load i64, ptr %l98
  %t191 = icmp sgt i64 %t190, 0
  store i1 %t191, ptr %l99
  %t192 = load i1, ptr %l99
  br i1 %t192, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l97
  br label %bb44
bb41:
  %t193 = load i64, ptr %l12
  store i64 %t193, ptr %l101
  %t194 = load i64, ptr %l11
  store i64 %t194, ptr %l102
  %t195 = load i64, ptr %l101
  %t196 = load i64, ptr %l102
  %t197 = sub i64 %t195, %t196
  store i64 %t197, ptr %l103
  %t198 = load i64, ptr %l13
  store i64 %t198, ptr %l104
  %t199 = load i64, ptr %l103
  %t200 = load i64, ptr %l104
  %t201 = add i64 %t199, %t200
  store i64 %t201, ptr %l105
  %t202 = load i64, ptr %l105
  %t203 = sub i64 %t202, 1
  store i64 %t203, ptr %l106
  %t204 = load i64, ptr %l13
  store i64 %t204, ptr %l107
  %t205 = load i64, ptr %l106
  %t206 = load i64, ptr %l107
  %t207 = sdiv i64 %t205, %t206
  store i64 %t207, ptr %l108
  %t208 = load i64, ptr %l108
  store i64 %t208, ptr %l100
  br label %bb43
bb42:
  store i64 0, ptr %l100
  br label %bb43
bb43:
  %t209 = load i64, ptr %l100
  store i64 %t209, ptr %l97
  br label %bb44
bb44:
  %t210 = load i64, ptr %l97
  store i64 %t210, ptr %l14
  store i64 0, ptr %l15
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s12
  %t211 = load i64, ptr %l15
  store i64 %t211, ptr %l109
  %t212 = load i64, ptr %l14
  store i64 %t212, ptr %l110
  %t213 = load i64, ptr %l109
  %t214 = load i64, ptr %l110
  %t215 = icmp slt i64 %t213, %t214
  store i1 %t215, ptr %l111
  %t216 = load i1, ptr %l111
  %t217 = xor i1 %t216, true
  store i1 %t217, ptr %l112
  %t218 = load i1, ptr %l112
  br i1 %t218, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s12)
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t219 = load i64, ptr %l11
  store i64 %t219, ptr %l113
  %t220 = load i64, ptr %l15
  store i64 %t220, ptr %l114
  %t221 = load i64, ptr %l13
  store i64 %t221, ptr %l115
  %t222 = load i64, ptr %l114
  %t223 = load i64, ptr %l115
  %t224 = mul i64 %t222, %t223
  store i64 %t224, ptr %l116
  %t225 = load i64, ptr %l113
  %t226 = load i64, ptr %l116
  %t227 = add i64 %t225, %t226
  store i64 %t227, ptr %l117
  %t228 = load i64, ptr %l117
  store i64 %t228, ptr %l16
  %t229 = load i64, ptr %l16
  store i64 %t229, ptr %l118
  %t230 = load i64, ptr %l16
  store i64 %t230, ptr %l119
  %t231 = load i64, ptr %l119
  %t232 = load i64, ptr %l118
  %t233 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t234 = load ptr, ptr %t233
  %t235 = getelementptr i64, ptr %t234, i64 %t232
  store i64 %t231, ptr %t235
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s13
  %t236 = load i64, ptr %l15
  store i64 %t236, ptr %l120
  %t237 = load i64, ptr %l120
  %t238 = add i64 %t237, 1
  store i64 %t238, ptr %l121
  %t239 = load i64, ptr %l121
  store i64 %t239, ptr %l15
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb50:
  call void @__olang_scope_close(ptr %s11)
  %t240 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t240, ptr %l122
  %t241 = load ptr, ptr %l0
  store ptr %t241, ptr %l123
  %t242 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t243 = ptrtoint ptr %t242 to i64
  %t245 = load ptr, ptr %l123
  %t246 = getelementptr { ptr, ptr }, ptr %t244, i32 0, i32 0
  store ptr %t245, ptr %t246
  %t247 = getelementptr { ptr, ptr }, ptr %t244, i32 0, i32 1
  store ptr %v0, ptr %t247
  %t248 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_90, 0
  %t249 = insertvalue { ptr, ptr } %t248, ptr %t244, 1
  store { ptr, ptr } %t249, ptr %l124
  %t250 = load { i64, ptr }, ptr %l122
  %t251 = load { ptr, ptr }, ptr %l124
  %t252 = extractvalue { ptr, ptr } %t251, 0
  %t253 = extractvalue { ptr, ptr } %t251, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %s0, ptr %s0, { i64, ptr } %t250, ptr %t252, ptr %t253)
  br label %bb51
bb51:
  %t254 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t254, ptr %l125
  br label %bb52
bb52:
  %t255 = load %"std/prelude/text:StringBuilder", ptr %l125
  store %"std/prelude/text:StringBuilder" %t255, ptr %l17
  store ptr %l17, ptr %l126
  %t256 = load ptr, ptr %l126
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t256, { i64, ptr } { i64 100, ptr @.d91 })
  br label %bb53
bb53:
  store ptr %l17, ptr %l127
  %t257 = load ptr, ptr %l127
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t257, { i64, ptr } { i64 77, ptr @.d92 })
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s14
  %t258 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t258, ptr %l128
  %t259 = load { i64, ptr }, ptr %l128
  store { i64, ptr } %t259, ptr %l18
  store i64 0, ptr %l19
  %t260 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t260, ptr %l129
  %t261 = load { i64, ptr }, ptr %l129
  %t262 = extractvalue { i64, ptr } %t261, 0
  store i64 %t262, ptr %l130
  %t263 = load i64, ptr %l130
  store i64 %t263, ptr %l20
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s15
  %t264 = load i64, ptr %l19
  store i64 %t264, ptr %l131
  %t265 = load i64, ptr %l20
  store i64 %t265, ptr %l132
  %t266 = load i64, ptr %l131
  %t267 = load i64, ptr %l132
  %t268 = icmp slt i64 %t266, %t267
  store i1 %t268, ptr %l133
  %t269 = load i1, ptr %l133
  %t270 = xor i1 %t269, true
  store i1 %t270, ptr %l134
  %t271 = load i1, ptr %l134
  br i1 %t271, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s15)
  br label %bb66
bb57:
  br label %bb58
bb58:
  %t272 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t272, ptr %l135
  %t273 = load i64, ptr %l19
  store i64 %t273, ptr %l136
  %t274 = load i64, ptr %l136
  %t275 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t276 = load ptr, ptr %t275
  %t277 = getelementptr i64, ptr %t276, i64 %t274
  %t278 = load i64, ptr %t277
  store i64 %t278, ptr %l137
  %t279 = load i64, ptr %l137
  store i64 %t279, ptr %l21
  store ptr %l17, ptr %l138
  %t280 = load ptr, ptr %l0
  store ptr %t280, ptr %l139
  %t281 = load ptr, ptr %l139
  %t282 = getelementptr %"compiler/fetch:Fetcher", ptr %t281, i32 0, i32 6
  store ptr %t282, ptr %l140
  %t283 = load i64, ptr %l21
  store i64 %t283, ptr %l141
  %t284 = load ptr, ptr %l140
  %t285 = load i64, ptr %l141
  %t286 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t284, i64 %t285)
  store { i64, ptr } %t286, ptr %l142
  br label %bb59
bb59:
  %t287 = load ptr, ptr %l138
  %t288 = load { i64, ptr }, ptr %l142
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t287, { i64, ptr } %t288)
  br label %bb60
bb60:
  store ptr %l17, ptr %l143
  %t289 = load ptr, ptr %l143
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t289, i8 32)
  br label %bb61
bb61:
  store ptr %l17, ptr %l144
  %t290 = load ptr, ptr %l0
  store ptr %t290, ptr %l145
  %t291 = load ptr, ptr %l145
  %t292 = getelementptr %"compiler/fetch:Fetcher", ptr %t291, i32 0, i32 7
  store ptr %t292, ptr %l146
  %t293 = load i64, ptr %l21
  store i64 %t293, ptr %l147
  %t294 = load ptr, ptr %l146
  %t295 = load i64, ptr %l147
  %t296 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t294, i64 %t295)
  store { i64, ptr } %t296, ptr %l148
  br label %bb62
bb62:
  %t297 = load ptr, ptr %l144
  %t298 = load { i64, ptr }, ptr %l148
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t297, { i64, ptr } %t298)
  br label %bb63
bb63:
  store ptr %l17, ptr %l149
  %t299 = load ptr, ptr %l149
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t299, i8 10)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s15)
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s16
  %t300 = load i64, ptr %l19
  store i64 %t300, ptr %l150
  %t301 = load i64, ptr %l150
  %t302 = add i64 %t301, 1
  store i64 %t302, ptr %l151
  %t303 = load i64, ptr %l151
  store i64 %t303, ptr %l19
  call void @__olang_scope_close(ptr %s16)
  br label %bb55
bb66:
  call void @__olang_scope_close(ptr %s14)
  %t304 = load ptr, ptr %l0
  store ptr %t304, ptr %l152
  %t305 = load ptr, ptr %l152
  %t306 = getelementptr %"compiler/fetch:Fetcher", ptr %t305, i32 0, i32 0
  %t307 = load { i64, ptr }, ptr %t306
  store { i64, ptr } %t307, ptr %l153
  store ptr %l17, ptr %l154
  %t308 = load ptr, ptr %l154
  %t309 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t308)
  store { i64, ptr } %t309, ptr %l155
  br label %bb67
bb67:
  %t310 = load { i64, ptr }, ptr %l155
  store { i64, ptr } %t310, ptr %l156
  %t311 = load { i64, ptr }, ptr %l153
  %t312 = load { i64, ptr }, ptr %l156
  %t313 = call i32 @std_2fos_2eWriteFile(ptr %v0, ptr %s0, { i64, ptr } %t311, { i64, ptr } %t312)
  store i32 %t313, ptr %l157
  %t314 = icmp ne i32 %t313, 0
  br i1 %t314, label %bb69, label %ok.315
ok.315:
  br label %bb68
bb68:
  br label %bb73
bb69:
  %t316 = load i32, ptr %l157
  %t317 = ashr i32 %t316, 16
  store i32 %t317, ptr %l158
  %t318 = load i32, ptr %l158
  %t319 = icmp eq i32 %t318, 1
  store i1 %t319, ptr %l159
  %t320 = load i1, ptr %l159
  br i1 %t320, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @.c93)
  unreachable
bb72:
  store %olang.scope zeroinitializer, ptr %s17
  call void @__olang_scope_close(ptr %s17)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  %t2 = load ptr, ptr %l2
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t2, i32 0, i32 9
  store ptr %t3, ptr %l3
  %t4 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t4, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l4
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l5
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l6
  %t21 = load ptr, ptr %l3
  %t22 = load { i64, ptr }, ptr %l6
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l0
  store ptr %t23, ptr %l7
  %t24 = load ptr, ptr %l7
  %t25 = getelementptr %"compiler/fetch:Fetcher", ptr %t24, i32 0, i32 4
  %t26 = load i1, ptr %t25
  store i1 %t26, ptr %l8
  %t27 = load i1, ptr %l8
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l9
  %t29 = load i1, ptr %l9
  br i1 %t29, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t30, ptr %l10
  %t31 = load { i64, ptr }, ptr %l10
  %t32 = call i32 @std_2fio_2ePrintErrln(ptr %v1, { i64, ptr } %t31)
  store i32 %t32, ptr %l11
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb5, label %ok.34
ok.34:
  br label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb9
bb5:
  %t35 = load i32, ptr %l11
  %t36 = ashr i32 %t35, 16
  store i32 %t36, ptr %l12
  %t37 = load i32, ptr %l12
  %t38 = icmp eq i32 %t37, 1
  store i1 %t38, ptr %l13
  %t39 = load i1, ptr %l13
  br i1 %t39, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l9
  %t2 = load ptr, ptr %l9
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t2, i32 0, i32 8
  store ptr %t3, ptr %l10
  %t4 = load ptr, ptr %l10
  store ptr %t4, ptr %l3
  store i64 0, ptr %l4
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3
  store ptr %t5, ptr %l12
  %t6 = load i64, ptr %l4
  store i64 %t6, ptr %l13
  %t7 = load ptr, ptr %l12
  %t8 = load i64, ptr %l13
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l15
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l14
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t14, ptr %l11
  br label %bb7
bb3:
  %t15 = load i32, ptr %l15
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l16
  %t17 = load i32, ptr %l16
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l17
  %t19 = load i1, ptr %l17
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t20 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t20, ptr %l5
  %t21 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t21, ptr %l18
  %t22 = load { i64, ptr }, ptr %l18
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l19
  %t24 = load i64, ptr %l19
  store i64 %t24, ptr %l6
  store i64 0, ptr %l7
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7
  store i64 %t25, ptr %l20
  %t26 = load i64, ptr %l6
  store i64 %t26, ptr %l21
  %t27 = load i64, ptr %l20
  %t28 = load i64, ptr %l21
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l22
  %t30 = load i1, ptr %l22
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l23
  %t32 = load i1, ptr %l23
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t33, ptr %l24
  %t34 = load i64, ptr %l7
  store i64 %t34, ptr %l25
  %t35 = load i64, ptr %l25
  %t36 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t35
  %t39 = load { i64, ptr }, ptr %t38
  store { i64, ptr } %t39, ptr %l26
  %t40 = load { i64, ptr }, ptr %l26
  store { i64, ptr } %t40, ptr %l8
  %t41 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t41, ptr %l27
  %t42 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t42, ptr %l28
  %t43 = load { i64, ptr }, ptr %l27
  %t44 = load { i64, ptr }, ptr %l28
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t43, { i64, ptr } %t44)
  store i1 %t45, ptr %l29
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29
  br i1 %t46, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l30
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i1, ptr %l30
  store i1 %t47, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load i64, ptr %l7
  store i64 %t48, ptr %l31
  %t49 = load i64, ptr %l31
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l32
  %t51 = load i64, ptr %l32
  store i64 %t51, ptr %l7
  call void @__olang_scope_close(ptr %s5)
  br label %bb8
bb17:
  %t52 = load i64, ptr %l4
  store i64 %t52, ptr %l33
  %t53 = load i64, ptr %l6
  store i64 %t53, ptr %l34
  %t54 = load i64, ptr %l33
  %t55 = load i64, ptr %l34
  %t56 = add i64 %t54, %t55
  store i64 %t56, ptr %l35
  %t57 = load i64, ptr %l35
  store i64 %t57, ptr %l4
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t58 = load i1, ptr %l2
  store i1 %t58, ptr %l36
  %t59 = load i1, ptr %l36
  br i1 %t59, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t60 = load ptr, ptr %l0
  store ptr %t60, ptr %l37
  %t61 = load ptr, ptr %l37
  %t62 = getelementptr %"compiler/fetch:Fetcher", ptr %t61, i32 0, i32 8
  store ptr %t62, ptr %l38
  %t63 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t63, ptr %l39
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t64 = load { i64, ptr }, ptr %l39
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  call void @__olang_sb_put(ptr %s7, ptr %t65, i64 %t66)
  %t67 = load ptr, ptr %s7
  %t68 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t69 = load i64, ptr %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t67, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l40
  call void @__olang_sb_done(ptr %s7)
  %t73 = load { i64, ptr }, ptr %l40
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l41
  %t80 = load ptr, ptr %l38
  %t81 = load { i64, ptr }, ptr %l41
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t80, { i64, ptr } %t81)
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  store i1 false, ptr %l42
  call void @__olang_scope_close(ptr %s0)
  %t82 = load i1, ptr %l42
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2egit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:Output"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  store { i64, ptr } { i64 0, ptr @.d96 }, ptr %l4
  %t2 = load { i64, ptr }, ptr %l3
  %t3 = load { i64, ptr }, ptr %l4
  %t4 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t2, { i64, ptr } %t3, i1 true, { i64, ptr } { i64 0, ptr @.d97 })
  %t5 = extractvalue { i32, %"std/os:Output" } %t4, 1
  %t6 = extractvalue { i32, %"std/os:Output" } %t4, 0
  store i32 %t6, ptr %l6
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store %"std/os:Output" %t5, ptr %l5
  br label %bb1
bb1:
  %t9 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t9, ptr %l2
  br label %bb6
bb2:
  %t10 = load i32, ptr %l6
  %t11 = ashr i32 %t10, 16
  store i32 %t11, ptr %l7
  %t12 = load i32, ptr %l7
  %t13 = icmp eq i32 %t12, 1
  store i1 %t13, ptr %l8
  %t14 = load i1, ptr %l8
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l9
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i1, ptr %l9
  store i1 %t15, ptr %rv
  br label %ret
bb6:
  %t16 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t16, ptr %l1
  %t17 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l10
  %t19 = load i32, ptr %l10
  %t20 = icmp eq i32 %t19, 0
  store i1 %t20, ptr %l11
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l11
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ehead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/os:Output"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/os:Output"
  %l7 = alloca { i64, ptr }
  %l8 = alloca [5 x { i64, ptr }]
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/os:Output"
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l4
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load ptr, ptr %s1
  %t6 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t7 = load i64, ptr %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t5, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t11 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t11, ptr %l1
  %t12 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t12, ptr %l7
  %t13 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d99 }, 0
  %t14 = insertvalue [5 x { i64, ptr }] %t13, { i64, ptr } { i64 2, ptr @.d100 }, 1
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = insertvalue [5 x { i64, ptr }] %t14, { i64, ptr } %t15, 2
  %t17 = insertvalue [5 x { i64, ptr }] %t16, { i64, ptr } { i64 9, ptr @.d101 }, 3
  %t18 = insertvalue [5 x { i64, ptr }] %t17, { i64, ptr } { i64 4, ptr @.d102 }, 4
  store [5 x { i64, ptr }] %t18, ptr %l8
  %t19 = load [5 x { i64, ptr }], ptr %l8
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call ptr @__olang_scope_alloc(ptr %t20, i64 80)
  store [5 x { i64, ptr }] %t19, ptr %t21
  %t22 = insertvalue { i64, ptr } undef, i64 5, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l9
  %t24 = load { i64, ptr }, ptr %l9
  %t25 = extractvalue { i64, ptr } %t24, 0
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = mul i64 %t25, 16
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l10
  store { i64, ptr } { i64 0, ptr @.d103 }, ptr %l11
  %t31 = load { i64, ptr }, ptr %l10
  %t32 = load { i64, ptr }, ptr %l11
  %t33 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } %t32, i1 true, { i64, ptr } { i64 0, ptr @.d104 })
  %t34 = extractvalue { i32, %"std/os:Output" } %t33, 1
  %t35 = extractvalue { i32, %"std/os:Output" } %t33, 0
  store i32 %t35, ptr %l13
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb2, label %ok.37
ok.37:
  store %"std/os:Output" %t34, ptr %l12
  br label %bb1
bb1:
  %t38 = load %"std/os:Output", ptr %l12
  store %"std/os:Output" %t38, ptr %l6
  br label %bb6
bb2:
  %t39 = load i32, ptr %l13
  %t40 = ashr i32 %t39, 16
  store i32 %t40, ptr %l14
  %t41 = load i32, ptr %l14
  %t42 = icmp eq i32 %t41, 1
  store i1 %t42, ptr %l15
  %t43 = load i1, ptr %l15
  br i1 %t43, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 0, ptr @.d106 }, ptr %l16
  %t44 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t44, ptr %l17
  %t45 = load { i64, ptr }, ptr %l17
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l18
  %t47 = load i64, ptr %l18
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l19
  %t52 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  %t54 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t55 = load ptr, ptr %t54
  %t56 = load i64, ptr %l18
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t58, ptr %l17
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb6:
  %t60 = load %"std/os:Output", ptr %l6
  store %"std/os:Output" %t60, ptr %l2
  %t61 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l20
  %t63 = load i32, ptr %l20
  %t64 = icmp ne i32 %t63, 0
  store i1 %t64, ptr %l21
  %t65 = load i1, ptr %l21
  br i1 %t65, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 0, ptr @.d107 }, ptr %l22
  %t66 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t66, ptr %l23
  %t67 = load { i64, ptr }, ptr %l23
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l24
  %t69 = load i64, ptr %l24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l25
  %t74 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t75 = load ptr, ptr %t74
  %t76 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  %t78 = load i64, ptr %l24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t80, ptr %l23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t82 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 1
  %t83 = load { i64, ptr }, ptr %t82
  store { i64, ptr } %t83, ptr %l26
  %t84 = load { i64, ptr }, ptr %l26
  %t85 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t84)
  store { i64, ptr } %t85, ptr %l27
  br label %bb10
bb10:
  %t86 = load { i64, ptr }, ptr %l27
  store { i64, ptr } %t86, ptr %l3
  %t87 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t87, ptr %l28
  %t88 = load { i64, ptr }, ptr %l28
  %t89 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t88)
  store i1 %t89, ptr %l29
  br label %bb11
bb11:
  %t90 = load i1, ptr %l29
  br i1 %t90, label %bb12, label %bb13
bb12:
  %t91 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t91, ptr %l31
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t92 = load { i64, ptr }, ptr %l31
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  call void @__olang_sb_put(ptr %s4, ptr %t93, i64 %t94)
  %t95 = load ptr, ptr %s4
  %t96 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t97 = load i64, ptr %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t95, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l32
  call void @__olang_sb_done(ptr %s4)
  %t101 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t101, ptr %l30
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr @.d108 }, ptr %l33
  %t102 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t102, ptr %l34
  %t103 = load { i64, ptr }, ptr %l34
  store { i64, ptr } %t103, ptr %l30
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t104 = load { i64, ptr }, ptr %l30
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l12 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l13 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l14 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l21 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l22 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l23 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l24 = alloca %"compiler/fetch:Fetcher"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/fetch:Fetcher"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l15
  %t2 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l16
  %t4 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t4, ptr %l6
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l17
  %t6 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t6, ptr %l7
  %t7 = load i1, ptr %l3
  store i1 %t7, ptr %l18
  %t8 = load i1, ptr %l18
  store i1 %t8, ptr %l8
  %t9 = load i1, ptr %l4
  store i1 %t9, ptr %l19
  %t10 = load i1, ptr %l19
  store i1 %t10, ptr %l9
  store i1 false, ptr %l10
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t11)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t12, ptr %l20
  br label %bb1
bb1:
  %t13 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l20
  store %"std/prelude/list:List<std/prelude/text:String&>" %t13, ptr %l11
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t14)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t15, ptr %l21
  br label %bb2
bb2:
  %t16 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l21
  store %"std/prelude/list:List<std/prelude/text:String&>" %t16, ptr %l12
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t17)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t18, ptr %l22
  br label %bb3
bb3:
  %t19 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l22
  store %"std/prelude/list:List<std/prelude/text:String&>" %t19, ptr %l13
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t20)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l23
  store %"std/prelude/list:List<std/prelude/text:String&>" %t22, ptr %l14
  %t23 = load { i64, ptr }, ptr %l5
  %t24 = insertvalue %"compiler/fetch:Fetcher" undef, { i64, ptr } %t23, 0
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = insertvalue %"compiler/fetch:Fetcher" %t24, { i64, ptr } %t25, 1
  %t27 = load { i64, ptr }, ptr %l7
  %t28 = insertvalue %"compiler/fetch:Fetcher" %t26, { i64, ptr } %t27, 2
  %t29 = load i1, ptr %l8
  %t30 = insertvalue %"compiler/fetch:Fetcher" %t28, i1 %t29, 3
  %t31 = load i1, ptr %l9
  %t32 = insertvalue %"compiler/fetch:Fetcher" %t30, i1 %t31, 4
  %t33 = load i1, ptr %l10
  %t34 = insertvalue %"compiler/fetch:Fetcher" %t32, i1 %t33, 5
  %t35 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l11
  %t36 = insertvalue %"compiler/fetch:Fetcher" %t34, %"std/prelude/list:List<std/prelude/text:String&>" %t35, 6
  %t37 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l12
  %t38 = insertvalue %"compiler/fetch:Fetcher" %t36, %"std/prelude/list:List<std/prelude/text:String&>" %t37, 7
  %t39 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l13
  %t40 = insertvalue %"compiler/fetch:Fetcher" %t38, %"std/prelude/list:List<std/prelude/text:String&>" %t39, 8
  %t41 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l14
  %t42 = insertvalue %"compiler/fetch:Fetcher" %t40, %"std/prelude/list:List<std/prelude/text:String&>" %t41, 9
  store %"compiler/fetch:Fetcher" %t42, ptr %l24
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/fetch:Fetcher", ptr %l24
  store %"compiler/fetch:Fetcher" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/fetch:Fetcher", ptr %rv
  ret %"compiler/fetch:Fetcher" %rr
}

@.d0 = private constant [11 x i8] c"OLANG_CACHE"
@.d1 = private constant [0 x i8] c""
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant [0 x i8] c""
declare void @__olang_sb_put(ptr, ptr, i64)
declare void @__olang_sb_done(ptr)
declare void @__olang_scope_close(ptr)
@.d3 = private constant [4 x i8] c"HOME"
@.d4 = private constant [1 x i8] c"."
@.d5 = private constant [13 x i8] c"/.cache/olang"
@.d6 = private constant [14 x i8] c"OLANG_GIT_BASE"
@.d7 = private constant [0 x i8] c""
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [8 x i8] c"https://"
@.d10 = private constant [2 x i8] c".."
declare void @__olang_check_failed(ptr)
@.c11 = private unnamed_addr constant [53 x i8] c"compiler/fetch.olang:168: slice bounds out of range\0A\00"
@.c12 = private unnamed_addr constant [53 x i8] c"compiler/fetch.olang:169: slice bounds out of range\0A\00"
@.d13 = private constant [1 x i8] c"/"
@.d14 = private constant [1 x i8] c"/"
@.d15 = private constant [1 x i8] c"/"
@.d16 = private constant [1 x i8] c"/"
@.d17 = private constant [1 x i8] c"/"
@.d18 = private constant [1 x i8] c"/"
@.d19 = private constant [1 x i8] c"/"
@.d20 = private constant [0 x i8] c""
@.d21 = private constant [0 x i8] c""
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d22 = private constant [0 x i8] c""
@.d23 = private constant [1 x i8] c"/"
declare ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d24 = private constant [7 x i8] c".fetch-"
@.c25 = private unnamed_addr constant [53 x i8] c"compiler/fetch.olang:195: slice bounds out of range\0A\00"
@.d26 = private constant [16 x i8] c"olang: fetching "
@.d27 = private constant [6 x i8] c" into "
@.d28 = private constant [4 x i8] c" at "
@.d29 = private constant [20 x i8] c", as olang.lock says"
@.d30 = private constant [1 x i8] c"/"
@.d31 = private constant [3 x i8] c"git"
@.d32 = private constant [4 x i8] c"init"
@.d33 = private constant [2 x i8] c"-q"
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d34 = private constant [3 x i8] c"git"
@.d35 = private constant [2 x i8] c"-C"
@.d36 = private constant [5 x i8] c"fetch"
@.d37 = private constant [2 x i8] c"-q"
@.d38 = private constant [7 x i8] c"--depth"
@.d39 = private constant [1 x i8] c"1"
@.d40 = private constant [2 x i8] c"--"
@.d41 = private constant [3 x i8] c"git"
@.d42 = private constant [2 x i8] c"-C"
@.d43 = private constant [8 x i8] c"checkout"
@.d44 = private constant [2 x i8] c"-q"
@.d45 = private constant [10 x i8] c"FETCH_HEAD"
@.d46 = private constant [3 x i8] c"git"
@.d47 = private constant [5 x i8] c"clone"
@.d48 = private constant [2 x i8] c"-q"
@.d49 = private constant [2 x i8] c"--"
@.d50 = private constant [3 x i8] c"git"
@.d51 = private constant [2 x i8] c"-C"
@.d52 = private constant [8 x i8] c"checkout"
@.d53 = private constant [2 x i8] c"-q"
@.d54 = private constant [16 x i8] c"olang: fetching "
@.d55 = private constant [6 x i8] c" into "
@.d56 = private constant [9 x i8] c"--branch="
@.d57 = private constant [7 x i8] c"--quiet"
@.d58 = private constant [0 x i8] c""
@.d59 = private constant [3 x i8] c"git"
@.d60 = private constant [5 x i8] c"clone"
@.d61 = private constant [7 x i8] c"--quiet"
@.d62 = private constant [7 x i8] c"--depth"
@.d63 = private constant [1 x i8] c"1"
@.d64 = private constant [2 x i8] c"--"
@.d65 = private constant [0 x i8] c""
@.d66 = private constant [1 x i8] c"/"
@.d67 = private constant [0 x i8] c""
@.c68 = private unnamed_addr constant [53 x i8] c"compiler/fetch.olang:242: slice bounds out of range\0A\00"
@.d69 = private constant [15 x i8] c"olang: updated "
@.d70 = private constant [4 x i8] c" to "
@.c71 = private unnamed_addr constant [53 x i8] c"compiler/fetch.olang:244: slice bounds out of range\0A\00"
@.d72 = private constant [15 x i8] c"olang: updated "
@.d73 = private constant [4 x i8] c" to "
@.d74 = private constant [6 x i8] c" (was "
@.d75 = private constant [1 x i8] c")"
@.c76 = private unnamed_addr constant [53 x i8] c"compiler/fetch.olang:246: slice bounds out of range\0A\00"
@.d77 = private constant [7 x i8] c"olang: "
@.d78 = private constant [15 x i8] c" is already at "
@.c79 = private unnamed_addr constant [51 x i8] c"compiler/fetch.olang:66: reached unreachable code\0A\00"
@.c80 = private unnamed_addr constant [51 x i8] c"compiler/fetch.olang:67: reached unreachable code\0A\00"
@.d81 = private constant [1 x i8] c"#"
@.d82 = private constant [1 x i8] c" "
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [0 x i8] c""
@.d86 = private constant [0 x i8] c""
@.d87 = private constant [0 x i8] c""
@.d88 = private constant [0 x i8] c""
@.c89 = private unnamed_addr constant [53 x i8] c"compiler/fetch.olang:111: array length out of range\0A\00"
define internal i1 @olang_lambda_90(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t2, i32 0, i32 6
  store ptr %t3, ptr %l4
  %t4 = load i64, ptr %l0
  store i64 %t4, ptr %l5
  %t5 = load ptr, ptr %l4
  %t6 = load i64, ptr %l5
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %vc0, ptr %vc0, ptr %t5, i64 %t6)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l2
  store ptr %t8, ptr %l7
  %t9 = load ptr, ptr %l7
  %t10 = getelementptr %"compiler/fetch:Fetcher", ptr %t9, i32 0, i32 6
  store ptr %t10, ptr %l8
  %t11 = load i64, ptr %l1
  store i64 %t11, ptr %l9
  %t12 = load ptr, ptr %l8
  %t13 = load i64, ptr %l9
  %t14 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %vc0, ptr %vc0, ptr %t12, i64 %t13)
  store { i64, ptr } %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l6
  %t16 = load { i64, ptr }, ptr %l10
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t15, { i64, ptr } %t16)
  store i1 %t17, ptr %l11
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i1, ptr %l11
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d91 = private constant [100 x i8] c"# olang.lock - the commit each remote repository is built from (M23b). Delete a line to update that\0A"
@.d92 = private constant [77 x i8] c"# repository, or build with -u to update every one the build reaches (M23c).\0A"
@.c93 = private unnamed_addr constant [52 x i8] c"compiler/fetch.olang:123: reached unreachable code\0A\00"
@.c94 = private unnamed_addr constant [51 x i8] c"compiler/fetch.olang:60: reached unreachable code\0A\00"
@.c95 = private unnamed_addr constant [52 x i8] c"compiler/fetch.olang:128: reached unreachable code\0A\00"
@.d96 = private constant [0 x i8] c""
@.d97 = private constant [0 x i8] c""
@.c98 = private unnamed_addr constant [52 x i8] c"compiler/fetch.olang:137: reached unreachable code\0A\00"
@.d99 = private constant [3 x i8] c"git"
@.d100 = private constant [2 x i8] c"-C"
@.d101 = private constant [9 x i8] c"rev-parse"
@.d102 = private constant [4 x i8] c"HEAD"
@.d103 = private constant [0 x i8] c""
@.d104 = private constant [0 x i8] c""
@.c105 = private unnamed_addr constant [52 x i8] c"compiler/fetch.olang:144: reached unreachable code\0A\00"
@.d106 = private constant [0 x i8] c""
@.d107 = private constant [0 x i8] c""
@.d108 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

declare ptr @__olang_capture_scope(ptr)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
