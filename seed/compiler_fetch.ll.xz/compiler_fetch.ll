; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
define dso_local { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr @.d0 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d1 }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr @.d2 })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t31 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr @.d3 })
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l15
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l14
  br label %bb9
bb9:
  %t36 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t36, ptr %l13, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr @.d4 }, ptr %l16, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l13, !tbaa !27
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = extractvalue { i64, ptr } %t46, 0
  %t51 = extractvalue { i64, ptr } { i64 13, ptr @.d5 }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr @.d5 }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = getelementptr i8, ptr %t54, i64 %t50
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d6 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d7 }, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr @.d8 })
  store i1 %t19, ptr %l8
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr @.d9 }, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l10, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l15, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l15, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffetch_2eIsCommit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp ne i64 %t3, 40
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 64
  store i1 %t11, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l4, !tbaa !22
  %t37 = load i8, ptr %l4, !tbaa !22
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t37)
  store i1 %t39, ptr %l24
  br label %bb11
bb11:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb17
bb13:
  %t41 = load i8, ptr %l4, !tbaa !22
  %t43 = icmp uge i8 %t41, 97
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load i8, ptr %l4, !tbaa !22
  %t47 = icmp ule i8 %t45, 102
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l28, !tbaa !21
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t50 = load i1, ptr %l25, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l2, !tbaa !24
  br label %bb7
bb22:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2eNamePart(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp eq i8 %t11, 46
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 0
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = icmp eq i8 %t20, 45
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 2, ptr @.d10 }, ptr %l19, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t29 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } %t28)
  store i1 %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load i1, ptr %l20, !tbaa !21
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t33, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i8, ptr %t51, i64 %t48
  %t53 = load i8, ptr %t52, !tbaa !32
  store i8 %t53, ptr %l4, !tbaa !22
  %t55 = load i8, ptr %l4, !tbaa !22
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t55)
  store i1 %t57, ptr %l33
  br label %bb18
bb18:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb22
bb20:
  %t59 = load i8, ptr %l4, !tbaa !22
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t59)
  store i1 %t61, ptr %l36
  br label %bb21
bb21:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb25
bb24:
  %t64 = load i8, ptr %l4, !tbaa !22
  %t66 = icmp eq i8 %t64, 46
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb28
bb27:
  %t69 = load i8, ptr %l4, !tbaa !22
  %t71 = icmp eq i8 %t69, 95
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb30:
  %t74 = load i8, ptr %l4, !tbaa !22
  %t76 = icmp eq i8 %t74, 45
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t78 = load i1, ptr %l43, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l2, !tbaa !24
  br label %bb14
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ecommitAgain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr @.d11 }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d11 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d12 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d12 }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t41 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t36, { i64, ptr } %a2)
  store i32 %t41, ptr %l13
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb2, label %ok.43
ok.43:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t44 = load i32, ptr %l13, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  br i1 %t47, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_d3373a347b8bef1c_6787ad888ff53eb8)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d13 }, ptr %l16, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t49, ptr %l17, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l18, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l18, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t63, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t64 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
bb6:
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 12, ptr @.d14 })
  store i1 %t67, ptr %l21
  br label %bb7
bb7:
  %t68 = load i1, ptr %l21, !tbaa !21
  br i1 %t68, label %bb8, label %bb9
bb8:
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v3, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l25
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr @.d15 }, ptr %l26, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t74, ptr %l23, !tbaa !27
  br label %bb11
bb10:
  %t76 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t76, ptr %l23, !tbaa !27
  br label %bb11
bb11:
  %t77 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l28, !tbaa !24
  %t79 = load i64, ptr %l28, !tbaa !24
  %t80 = mul i64 %t79, 1
  %t81 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l29, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l28, !tbaa !24
  %t89 = mul i64 %t88, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %t87, i64 %t89, i1 false)
  %t90 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t90, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t91 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %lp15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %lp17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %lp21 = alloca ptr
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l79 = alloca i1
  %l81 = alloca i1
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l128 = alloca i64
  %l131 = alloca i1
  %l133 = alloca i1
  %l141 = alloca i1
  %l144 = alloca i32
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l161 = alloca i64
  %l172 = alloca { i64, ptr }
  %l173 = alloca i1
  %l174 = alloca i1
  %l178 = alloca { i64, ptr }
  %l179 = alloca i1
  %l180 = alloca i1
  %l182 = alloca { i64, ptr }
  %l183 = alloca i1
  %l187 = alloca i32
  %l193 = alloca { i64, ptr }
  %l194 = alloca i1
  %l197 = alloca { i64, ptr }
  %l198 = alloca i1
  %l200 = alloca { i64, ptr }
  %l203 = alloca i1
  %l206 = alloca i32
  %l212 = alloca i1
  %l216 = alloca i32
  %l221 = alloca i32
  %l227 = alloca i32
  %l241 = alloca { i64, ptr }
  %l246 = alloca i32
  %l250 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l252 = alloca i64
  %l253 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l258 = alloca i1
  %l260 = alloca { i64, ptr }
  %l262 = alloca i64
  %l265 = alloca i1
  %l267 = alloca i32
  %l276 = alloca i1
  %l278 = alloca i32
  %l284 = alloca i32
  %l289 = alloca i32
  %l301 = alloca i1
  %l303 = alloca i1
  %l305 = alloca i1
  %l306 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l308 = alloca i64
  %l316 = alloca i1
  %l319 = alloca i1
  %l321 = alloca ptr
  %l322 = alloca { i64, ptr }
  %l323 = alloca i64
  %l327 = alloca { i64, ptr }
  %l328 = alloca i64
  %l336 = alloca ptr
  %l337 = alloca { i64, ptr }
  %l338 = alloca i64
  %s0 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v3, { i64, ptr } %t1, i8 64)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l26
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i64 %t5, ptr %l25
  br label %bb1
bb1:
  %t9 = load i64, ptr %l25, !tbaa !24
  store i64 %t9, ptr %l22, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l22, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l22, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l29, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l30, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l30, !tbaa !24
  %t22 = icmp sle i64 0, %t21
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb7:
  %t24 = load i64, ptr %l30, !tbaa !24
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  br i1 %t26, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l30, !tbaa !24
  %t31 = getelementptr i8, ptr %t29, i64 0
  %t32 = sub i64 %t30, 0
  %t33 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t36, %t39
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb11:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l41, !tbaa !27
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l43, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t48, 0
  store i64 %t51, ptr %l46, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l47, !tbaa !24
  %t54 = load i64, ptr %l43, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb12:
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t57, ptr %l52, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l54, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t61, 0
  store i64 %t64, ptr %l57, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l58, !tbaa !24
  %t67 = load i64, ptr %l54, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb19, label %bb20
bb13:
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = load i64, ptr %l46, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb15:
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l43, !tbaa !24
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l40, !tbaa !27
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb19:
  %t87 = load i64, ptr %l54, !tbaa !24
  %t88 = load i64, ptr %l57, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb21:
  %t91 = load i64, ptr %l57, !tbaa !24
  %t92 = load i64, ptr %l58, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb23:
  %t95 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l54, !tbaa !24
  %t98 = load i64, ptr %l57, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l40, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb25:
  %t104 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t104, ptr %l6, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2ffetch_2eNamePart(ptr %v1, { i64, ptr } %t105)
  store i1 %t107, ptr %l64
  br label %bb26
bb26:
  %t108 = load i1, ptr %l64, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t113 = call i1 @compiler_2ffetch_2eNamePart(ptr %v2, { i64, ptr } %t111)
  store i1 %t113, ptr %l68
  br label %bb29
bb29:
  %t114 = load i1, ptr %l68, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t117 = load i1, ptr %l66, !tbaa !21
  br i1 %t117, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb34
bb32:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t120 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t118)
  store i1 %t120, ptr %l72
  br label %bb33
bb33:
  %t121 = load i1, ptr %l72, !tbaa !21
  %t122 = xor i1 %t121, true
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb41
bb36:
  %t125 = load i64, ptr %l4, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t131 = icmp slt i64 %t125, %t128
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t133 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t135 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t133)
  store i1 %t135, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t136 = load i1, ptr %l81, !tbaa !21
  %t137 = xor i1 %t136, true
  store i1 %t137, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t139 = load i1, ptr %l79, !tbaa !21
  store i1 %t139, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t140 = load i1, ptr %l74, !tbaa !21
  br i1 %t140, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/fetch:Fetcher", ptr %t143, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l7, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t148, 1
  %t153 = extractvalue { i64, ptr } %t148, 0
  %t154 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t149, 1
  %t159 = extractvalue { i64, ptr } %t149, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t163 = add i64 %t160, %t162
  %t165 = extractvalue { i64, ptr } %t150, 1
  %t166 = extractvalue { i64, ptr } %t150, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t152, i64 %t153)
  %t169 = getelementptr i8, ptr %t168, i64 %t153
  call void @olang_textcopy(ptr %t169, ptr %t154, i64 %t155)
  %t170 = getelementptr i8, ptr %t169, i64 %t155
  call void @olang_textcopy(ptr %t170, ptr %t158, i64 %t159)
  %t171 = getelementptr i8, ptr %t170, i64 %t159
  call void @olang_textcopy(ptr %t171, ptr %t161, i64 %t162)
  %t172 = getelementptr i8, ptr %t171, i64 %t162
  call void @olang_textcopy(ptr %t172, ptr %t165, i64 %t166)
  %t173 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t168, 1
  store { i64, ptr } %t174, ptr %l8, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/fetch:Fetcher", ptr %t176, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t179, 1
  %t185 = extractvalue { i64, ptr } %t179, 0
  %t187 = extractvalue { i64, ptr } %t180, 1
  %t188 = extractvalue { i64, ptr } %t180, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t192 = add i64 %t189, %t191
  %t194 = extractvalue { i64, ptr } %t181, 1
  %t195 = extractvalue { i64, ptr } %t181, 0
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t198 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  %t199 = add i64 %t196, %t198
  %t201 = extractvalue { i64, ptr } %t182, 1
  %t202 = extractvalue { i64, ptr } %t182, 0
  %t203 = add i64 %t199, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t184, i64 %t185)
  %t205 = getelementptr i8, ptr %t204, i64 %t185
  call void @olang_textcopy(ptr %t205, ptr %t187, i64 %t188)
  %t206 = getelementptr i8, ptr %t205, i64 %t188
  call void @olang_textcopy(ptr %t206, ptr %t190, i64 %t191)
  %t207 = getelementptr i8, ptr %t206, i64 %t191
  call void @olang_textcopy(ptr %t207, ptr %t194, i64 %t195)
  %t208 = getelementptr i8, ptr %t207, i64 %t195
  call void @olang_textcopy(ptr %t208, ptr %t197, i64 %t198)
  %t209 = getelementptr i8, ptr %t208, i64 %t198
  call void @olang_textcopy(ptr %t209, ptr %t201, i64 %t202)
  %t210 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t204, 1
  store { i64, ptr } %t211, ptr %l9, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t213, 1
  %t219 = extractvalue { i64, ptr } %t213, 0
  %t220 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t222 = add i64 %t219, %t221
  %t224 = extractvalue { i64, ptr } %t214, 1
  %t225 = extractvalue { i64, ptr } %t214, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 0
  %t229 = add i64 %t226, %t228
  %t231 = extractvalue { i64, ptr } %t215, 1
  %t232 = extractvalue { i64, ptr } %t215, 0
  %t233 = add i64 %t229, %t232
  %t234 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t235 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t236 = add i64 %t233, %t235
  %t238 = extractvalue { i64, ptr } %t216, 1
  %t239 = extractvalue { i64, ptr } %t216, 0
  %t240 = add i64 %t236, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t218, i64 %t219)
  %t242 = getelementptr i8, ptr %t241, i64 %t219
  call void @olang_textcopy(ptr %t242, ptr %t220, i64 %t221)
  %t243 = getelementptr i8, ptr %t242, i64 %t221
  call void @olang_textcopy(ptr %t243, ptr %t224, i64 %t225)
  %t244 = getelementptr i8, ptr %t243, i64 %t225
  call void @olang_textcopy(ptr %t244, ptr %t227, i64 %t228)
  %t245 = getelementptr i8, ptr %t244, i64 %t228
  call void @olang_textcopy(ptr %t245, ptr %t231, i64 %t232)
  %t246 = getelementptr i8, ptr %t245, i64 %t232
  call void @olang_textcopy(ptr %t246, ptr %t234, i64 %t235)
  %t247 = getelementptr i8, ptr %t246, i64 %t235
  call void @olang_textcopy(ptr %t247, ptr %t238, i64 %t239)
  %t248 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t241, 1
  store { i64, ptr } %t249, ptr %l10, !tbaa !27
  store i1 true, ptr %l11, !tbaa !21
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t255 = call { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %s0, ptr %t251, { i64, ptr } %t252)
  %t256 = extractvalue { i32, { i64, ptr } } %t255, 1
  %t257 = extractvalue { i32, { i64, ptr } } %t255, 0
  store i32 %t257, ptr %l105
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb46, label %ok.259
ok.259:
  store { i64, ptr } %t256, ptr %l104
  br label %bb45
bb45:
  %t260 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t260, ptr %l101, !tbaa !27
  br label %bb48
bb46:
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l11, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d23 }, ptr %l101, !tbaa !27
  br label %bb48
bb48:
  %t261 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t262, i64 %t263)
  %t265 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  store { i64, ptr } %t266, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d24 }, ptr %l107, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t268, ptr %l108, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l109, !tbaa !24
  %t271 = load i64, ptr %l109, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l110, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l109, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t282, ptr %l13, !tbaa !27
  store i1 false, ptr %l14, !tbaa !21
  %t283 = load i1, ptr %l11, !tbaa !21
  br i1 %t283, label %bb49, label %bb50
bb49:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/fetch:Fetcher", ptr %t285, i32 0, i32 3
  %t288 = load i1, ptr %t287, !tbaa !21
  store i1 %t288, ptr %l112, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb51
bb51:
  %t290 = load i1, ptr %l112, !tbaa !21
  br i1 %t290, label %bb52, label %bb53
bb52:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t295 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %s0, ptr %t291, { i64, ptr } %t292, i1 false)
  store i1 %t295, ptr %l118
  br label %bb54
bb53:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb55
bb54:
  %t296 = load i1, ptr %l118, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l115, !tbaa !21
  br label %bb55
bb55:
  %t299 = load i1, ptr %l115, !tbaa !21
  br i1 %t299, label %bb56, label %bb57
bb56:
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t300)
  store i1 %t302, ptr %l121
  br label %bb58
bb57:
  br label %bb65
bb58:
  %t303 = load i1, ptr %l121, !tbaa !21
  br i1 %t303, label %bb59, label %bb60
bb59:
  %t304 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 1
  %t307 = extractvalue { i64, ptr } %t304, 0
  %t308 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t306, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l122, !tbaa !27
  br label %bb61
bb60:
  store { i64, ptr } { i64 0, ptr @.d25 }, ptr %l125, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t312, ptr %l122, !tbaa !27
  br label %bb61
bb61:
  %t314 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 0
  %t316 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l128, !tbaa !24
  %t319 = load i64, ptr %l128, !tbaa !24
  %t320 = icmp eq i64 %t315, %t319
  br i1 %t320, label %bb62, label %bb63
bb62:
  %t322 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = load i64, ptr %l128, !tbaa !24
  %t327 = mul i64 %t326, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t323, ptr %t325, i64 %t327, i1 false)
  br label %bb64
bb63:
  %t328 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t328, ptr %l13, !tbaa !27
  br label %bb64
bb64:
  store i1 true, ptr %l14, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  br label %bb65
bb65:
  %t329 = load i1, ptr %l11, !tbaa !21
  br i1 %t329, label %bb66, label %bb67
bb66:
  %t331 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t333 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t331)
  store i1 %t333, ptr %l133
  br label %bb68
bb67:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb69
bb68:
  %t334 = load i1, ptr %l133, !tbaa !21
  %t335 = xor i1 %t334, true
  store i1 %t335, ptr %l131, !tbaa !21
  br label %bb69
bb69:
  %t337 = load i1, ptr %l131, !tbaa !21
  br i1 %t337, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t339 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65537, 0
  store { i32, { i64, ptr } } %t339, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t340 = load i1, ptr %l11, !tbaa !21
  br i1 %t340, label %bb73, label %bb74
bb73:
  %t342 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t342, 1
  %t346 = extractvalue { i64, ptr } %t342, 0
  %t347 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t348 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t349 = add i64 %t346, %t348
  %t351 = extractvalue { i64, ptr } %t343, 1
  %t352 = extractvalue { i64, ptr } %t343, 0
  %t353 = add i64 %t349, %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t353)
  call void @olang_textcopy(ptr %t354, ptr %t345, i64 %t346)
  %t355 = getelementptr i8, ptr %t354, i64 %t346
  call void @olang_textcopy(ptr %t355, ptr %t347, i64 %t348)
  %t356 = getelementptr i8, ptr %t355, i64 %t348
  call void @olang_textcopy(ptr %t356, ptr %t351, i64 %t352)
  %t357 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t354, 1
  %t359 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t359, ptr %lp15
  %t361 = load ptr, ptr %lp15
  store { i64, ptr } %t358, ptr %t361, !tbaa !27
  %t362 = load ptr, ptr %lp15
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  %t365 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t363)
  store i1 %t365, ptr %l141
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t366 = load i1, ptr %l141, !tbaa !21
  br i1 %t366, label %bb76, label %bb77
bb76:
  %t367 = load ptr, ptr %lp15
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t370 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t368, 1
  store { i32, { i64, ptr } } %t370, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t371 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t373 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t371)
  store i32 %t373, ptr %l144
  %t374 = icmp ne i32 %t373, 0
  br i1 %t374, label %bb81, label %ok.375
ok.375:
  br label %bb80
bb80:
  br label %bb85
bb81:
  %t376 = load i32, ptr %l144, !tbaa !23
  %t377 = ashr i32 %t376, 16
  %t379 = icmp eq i32 %t377, 1
  br i1 %t379, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  %t381 = load i32, ptr %l144, !tbaa !23
  %t382 = lshr i32 %t381, 16
  %t383 = and i32 %t381, 65535
  %t384 = icmp eq i32 %t382, 1
  %t385 = select i1 %t384, i32 0, i32 0
  %t386 = icmp eq i32 %t381, 0
  %t387 = shl i32 %t385, 16
  %t388 = or i32 %t387, %t383
  %t389 = select i1 %t386, i32 0, i32 %t388
  call void @__olang_scope_close(ptr %s0)
  %t391 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t389, 0
  store { i32, { i64, ptr } } %t391, ptr %rv
  br label %ret
bb84:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t393 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t393, ptr %rv
  br label %ret
bb85:
  %t394 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t396 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t394, { i64, ptr } { i64 7, ptr @.d27 })
  %t397 = extractvalue { i32, { i64, ptr } } %t396, 1
  %t398 = extractvalue { i32, { i64, ptr } } %t396, 0
  store i32 %t398, ptr %l152
  %t399 = icmp ne i32 %t398, 0
  br i1 %t399, label %bb87, label %ok.400
ok.400:
  store { i64, ptr } %t397, ptr %l151
  br label %bb86
bb86:
  %t401 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t401, ptr %l149, !tbaa !27
  br label %bb91
bb87:
  %t402 = load i32, ptr %l152, !tbaa !23
  %t403 = ashr i32 %t402, 16
  %t405 = icmp eq i32 %t403, 1
  br i1 %t405, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  %t407 = load i32, ptr %l152, !tbaa !23
  %t408 = lshr i32 %t407, 16
  %t409 = and i32 %t407, 65535
  %t410 = icmp eq i32 %t408, 1
  %t411 = select i1 %t410, i32 0, i32 0
  %t412 = icmp eq i32 %t407, 0
  %t413 = shl i32 %t411, 16
  %t414 = or i32 %t413, %t409
  %t415 = select i1 %t412, i32 0, i32 %t414
  call void @__olang_scope_close(ptr %s0)
  %t417 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t415, 0
  store { i32, { i64, ptr } } %t417, ptr %rv
  br label %ret
bb90:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t419 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t419, ptr %rv
  br label %ret
bb91:
  %t420 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t420, ptr %l16, !tbaa !27
  %t421 = load i1, ptr %l11, !tbaa !21
  br i1 %t421, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s15
  %t423 = load ptr, ptr %l0, !tbaa !29
  store ptr %t423, ptr %l158, !tbaa !29
  %t424 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t424, ptr %l159, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t425, ptr %l160, !tbaa !27
  %t426 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t426, 0
  store i64 %t427, ptr %l161, !tbaa !24
  %t428 = icmp sge i64 0, 0
  br i1 %t428, label %bb94, label %bb95
bb93:
  br label %bb157
bb94:
  %t430 = icmp sle i64 0, 12
  br i1 %t430, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb96:
  %t432 = load i64, ptr %l161, !tbaa !24
  %t433 = icmp sle i64 12, %t432
  br i1 %t433, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb98:
  %t435 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr i8, ptr %t436, i64 0
  %t438 = sub i64 12, 0
  %t439 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t437, 1
  %t441 = extractvalue { i64, ptr } { i64 16, ptr @.d28 }, 1
  %t442 = extractvalue { i64, ptr } { i64 16, ptr @.d28 }, 0
  %t443 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t443, 1
  %t445 = extractvalue { i64, ptr } %t443, 0
  %t446 = add i64 %t442, %t445
  %t447 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 1
  %t448 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 0
  %t449 = add i64 %t446, %t448
  %t450 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 1
  %t452 = extractvalue { i64, ptr } %t450, 0
  %t453 = add i64 %t449, %t452
  %t454 = extractvalue { i64, ptr } { i64 4, ptr @.d30 }, 1
  %t455 = extractvalue { i64, ptr } { i64 4, ptr @.d30 }, 0
  %t456 = add i64 %t453, %t455
  %t458 = extractvalue { i64, ptr } %t440, 1
  %t459 = extractvalue { i64, ptr } %t440, 0
  %t460 = add i64 %t456, %t459
  %t461 = extractvalue { i64, ptr } { i64 20, ptr @.d31 }, 1
  %t462 = extractvalue { i64, ptr } { i64 20, ptr @.d31 }, 0
  %t463 = add i64 %t460, %t462
  %t464 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t463)
  call void @olang_textcopy(ptr %t464, ptr %t441, i64 %t442)
  %t465 = getelementptr i8, ptr %t464, i64 %t442
  call void @olang_textcopy(ptr %t465, ptr %t444, i64 %t445)
  %t466 = getelementptr i8, ptr %t465, i64 %t445
  call void @olang_textcopy(ptr %t466, ptr %t447, i64 %t448)
  %t467 = getelementptr i8, ptr %t466, i64 %t448
  call void @olang_textcopy(ptr %t467, ptr %t451, i64 %t452)
  %t468 = getelementptr i8, ptr %t467, i64 %t452
  call void @olang_textcopy(ptr %t468, ptr %t454, i64 %t455)
  %t469 = getelementptr i8, ptr %t468, i64 %t455
  call void @olang_textcopy(ptr %t469, ptr %t458, i64 %t459)
  %t470 = getelementptr i8, ptr %t469, i64 %t459
  call void @olang_textcopy(ptr %t470, ptr %t461, i64 %t462)
  %t471 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t464, 1
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t475 = extractvalue { i64, ptr } %t472, 1
  %t476 = mul i64 %t474, 1
  %t477 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t476)
  call void @llvm.memcpy.p0.p0.i64(ptr %t477, ptr %t475, i64 %t476, i1 false)
  %t478 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t477, 1
  %t480 = load ptr, ptr %l158, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s15, ptr %t480, { i64, ptr } %t479)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb100:
  %t482 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t483 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t482, 1
  %t486 = extractvalue { i64, ptr } %t482, 0
  %t487 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t488 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  %t489 = add i64 %t486, %t488
  %t491 = extractvalue { i64, ptr } %t483, 1
  %t492 = extractvalue { i64, ptr } %t483, 0
  %t493 = add i64 %t489, %t492
  %t494 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t493)
  call void @olang_textcopy(ptr %t494, ptr %t485, i64 %t486)
  %t495 = getelementptr i8, ptr %t494, i64 %t486
  call void @olang_textcopy(ptr %t495, ptr %t487, i64 %t488)
  %t496 = getelementptr i8, ptr %t495, i64 %t488
  call void @olang_textcopy(ptr %t496, ptr %t491, i64 %t492)
  %t497 = insertvalue { i64, ptr } undef, i64 %t493, 0
  %t498 = insertvalue { i64, ptr } %t497, ptr %t494, 1
  %t499 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t499, ptr %lp17
  %t501 = load ptr, ptr %lp17
  store { i64, ptr } %t498, ptr %t501, !tbaa !27
  %t502 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t503 = mul i64 4, 16
  %t504 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t503)
  %t505 = insertvalue { i64, ptr } undef, i64 4, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t504, 1
  store { i64, ptr } %t506, ptr %l172, !tbaa !27
  %t507 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr { i64, ptr }, ptr %t508, i64 0
  store { i64, ptr } { i64 3, ptr @.d33 }, ptr %t509, !tbaa !37
  %t510 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr { i64, ptr }, ptr %t511, i64 1
  store { i64, ptr } { i64 4, ptr @.d34 }, ptr %t512, !tbaa !37
  %t513 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = getelementptr { i64, ptr }, ptr %t514, i64 2
  store { i64, ptr } { i64 2, ptr @.d35 }, ptr %t515, !tbaa !37
  %t517 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !27
  %t519 = getelementptr { i64, ptr }, ptr %t518, i64 3
  store { i64, ptr } %t502, ptr %t519, !tbaa !37
  %t520 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t521 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t520)
  store i1 %t521, ptr %l173
  br label %bb101
bb101:
  %t522 = load i1, ptr %l173, !tbaa !21
  br i1 %t522, label %bb102, label %bb103
bb102:
  %t523 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t524 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t525 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t526 = mul i64 10, 16
  %t527 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t526)
  %t528 = insertvalue { i64, ptr } undef, i64 10, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t527, 1
  store { i64, ptr } %t529, ptr %l178, !tbaa !27
  %t530 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t531 = load ptr, ptr %t530, !tbaa !27
  %t532 = getelementptr { i64, ptr }, ptr %t531, i64 0
  store { i64, ptr } { i64 3, ptr @.d36 }, ptr %t532, !tbaa !37
  %t533 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = getelementptr { i64, ptr }, ptr %t534, i64 1
  store { i64, ptr } { i64 2, ptr @.d37 }, ptr %t535, !tbaa !37
  %t537 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t538 = load ptr, ptr %t537, !tbaa !27
  %t539 = getelementptr { i64, ptr }, ptr %t538, i64 2
  store { i64, ptr } %t523, ptr %t539, !tbaa !37
  %t540 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr { i64, ptr }, ptr %t541, i64 3
  store { i64, ptr } { i64 5, ptr @.d38 }, ptr %t542, !tbaa !37
  %t543 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr { i64, ptr }, ptr %t544, i64 4
  store { i64, ptr } { i64 2, ptr @.d39 }, ptr %t545, !tbaa !37
  %t546 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr { i64, ptr }, ptr %t547, i64 5
  store { i64, ptr } { i64 7, ptr @.d40 }, ptr %t548, !tbaa !37
  %t549 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !27
  %t551 = getelementptr { i64, ptr }, ptr %t550, i64 6
  store { i64, ptr } { i64 1, ptr @.d41 }, ptr %t551, !tbaa !37
  %t552 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !27
  %t554 = getelementptr { i64, ptr }, ptr %t553, i64 7
  store { i64, ptr } { i64 2, ptr @.d42 }, ptr %t554, !tbaa !37
  %t556 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t557 = load ptr, ptr %t556, !tbaa !27
  %t558 = getelementptr { i64, ptr }, ptr %t557, i64 8
  store { i64, ptr } %t524, ptr %t558, !tbaa !37
  %t560 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t561 = load ptr, ptr %t560, !tbaa !27
  %t562 = getelementptr { i64, ptr }, ptr %t561, i64 9
  store { i64, ptr } %t525, ptr %t562, !tbaa !37
  %t563 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t564 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t563)
  store i1 %t564, ptr %l179
  br label %bb104
bb103:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb105
bb104:
  %t565 = load i1, ptr %l179, !tbaa !21
  store i1 %t565, ptr %l174, !tbaa !21
  br label %bb105
bb105:
  %t566 = load i1, ptr %l174, !tbaa !21
  br i1 %t566, label %bb106, label %bb107
bb106:
  %t567 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t568 = mul i64 6, 16
  %t569 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t568)
  %t570 = insertvalue { i64, ptr } undef, i64 6, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  store { i64, ptr } %t571, ptr %l182, !tbaa !27
  %t572 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr { i64, ptr }, ptr %t573, i64 0
  store { i64, ptr } { i64 3, ptr @.d43 }, ptr %t574, !tbaa !37
  %t575 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !27
  %t577 = getelementptr { i64, ptr }, ptr %t576, i64 1
  store { i64, ptr } { i64 2, ptr @.d44 }, ptr %t577, !tbaa !37
  %t579 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = getelementptr { i64, ptr }, ptr %t580, i64 2
  store { i64, ptr } %t567, ptr %t581, !tbaa !37
  %t582 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t583 = load ptr, ptr %t582, !tbaa !27
  %t584 = getelementptr { i64, ptr }, ptr %t583, i64 3
  store { i64, ptr } { i64 8, ptr @.d45 }, ptr %t584, !tbaa !37
  %t585 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !27
  %t587 = getelementptr { i64, ptr }, ptr %t586, i64 4
  store { i64, ptr } { i64 2, ptr @.d46 }, ptr %t587, !tbaa !37
  %t588 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t589 = load ptr, ptr %t588, !tbaa !27
  %t590 = getelementptr { i64, ptr }, ptr %t589, i64 5
  store { i64, ptr } { i64 10, ptr @.d47 }, ptr %t590, !tbaa !37
  %t591 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t592 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t591)
  store i1 %t592, ptr %l183
  br label %bb108
bb107:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb109
bb108:
  %t593 = load i1, ptr %l183, !tbaa !21
  store i1 %t593, ptr %l180, !tbaa !21
  br label %bb109
bb109:
  %t594 = load i1, ptr %l180, !tbaa !21
  %t597 = xor i1 %t594, true
  br i1 %t597, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s18
  %t599 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t601 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t599)
  store i32 %t601, ptr %l187
  %t602 = icmp ne i32 %t601, 0
  br i1 %t602, label %bb113, label %ok.603
ok.603:
  br label %bb112
bb111:
  br label %bb123
bb112:
  br label %bb117
bb113:
  %t604 = load i32, ptr %l187, !tbaa !23
  %t605 = ashr i32 %t604, 16
  %t607 = icmp eq i32 %t605, 1
  br i1 %t607, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  %t609 = load i32, ptr %l187, !tbaa !23
  %t610 = lshr i32 %t609, 16
  %t611 = and i32 %t609, 65535
  %t612 = icmp eq i32 %t610, 1
  %t613 = select i1 %t612, i32 0, i32 0
  %t614 = icmp eq i32 %t609, 0
  %t615 = shl i32 %t613, 16
  %t616 = or i32 %t615, %t611
  %t617 = select i1 %t614, i32 0, i32 %t616
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t619 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t617, 0
  store { i32, { i64, ptr } } %t619, ptr %rv
  br label %ret
bb116:
  call void @__olang_ert_req_clear()
  br label %bb117
bb117:
  %t620 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t621 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t622 = mul i64 6, 16
  %t623 = call ptr @__olang_scope_alloc_zeroed(ptr %s18, i64 %t622)
  %t624 = insertvalue { i64, ptr } undef, i64 6, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  store { i64, ptr } %t625, ptr %l193, !tbaa !27
  %t626 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !27
  %t628 = getelementptr { i64, ptr }, ptr %t627, i64 0
  store { i64, ptr } { i64 3, ptr @.d48 }, ptr %t628, !tbaa !37
  %t629 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = getelementptr { i64, ptr }, ptr %t630, i64 1
  store { i64, ptr } { i64 5, ptr @.d49 }, ptr %t631, !tbaa !37
  %t632 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !27
  %t634 = getelementptr { i64, ptr }, ptr %t633, i64 2
  store { i64, ptr } { i64 2, ptr @.d50 }, ptr %t634, !tbaa !37
  %t635 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t636 = load ptr, ptr %t635, !tbaa !27
  %t637 = getelementptr { i64, ptr }, ptr %t636, i64 3
  store { i64, ptr } { i64 2, ptr @.d51 }, ptr %t637, !tbaa !37
  %t639 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t640 = load ptr, ptr %t639, !tbaa !27
  %t641 = getelementptr { i64, ptr }, ptr %t640, i64 4
  store { i64, ptr } %t620, ptr %t641, !tbaa !37
  %t643 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t644 = load ptr, ptr %t643, !tbaa !27
  %t645 = getelementptr { i64, ptr }, ptr %t644, i64 5
  store { i64, ptr } %t621, ptr %t645, !tbaa !37
  %t646 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t647 = call i1 @compiler_2ffetch_2egit(ptr %s18, { i64, ptr } %t646)
  store i1 %t647, ptr %l194
  br label %bb118
bb118:
  %t648 = load i1, ptr %l194, !tbaa !21
  br i1 %t648, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s20
  %t649 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t650 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t651 = mul i64 6, 16
  %t652 = call ptr @__olang_scope_alloc_zeroed(ptr %s20, i64 %t651)
  %t653 = insertvalue { i64, ptr } undef, i64 6, 0
  %t654 = insertvalue { i64, ptr } %t653, ptr %t652, 1
  store { i64, ptr } %t654, ptr %l197, !tbaa !27
  %t655 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t656 = load ptr, ptr %t655, !tbaa !27
  %t657 = getelementptr { i64, ptr }, ptr %t656, i64 0
  store { i64, ptr } { i64 3, ptr @.d52 }, ptr %t657, !tbaa !37
  %t658 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !27
  %t660 = getelementptr { i64, ptr }, ptr %t659, i64 1
  store { i64, ptr } { i64 2, ptr @.d53 }, ptr %t660, !tbaa !37
  %t662 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t663 = load ptr, ptr %t662, !tbaa !27
  %t664 = getelementptr { i64, ptr }, ptr %t663, i64 2
  store { i64, ptr } %t649, ptr %t664, !tbaa !37
  %t665 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t666 = load ptr, ptr %t665, !tbaa !27
  %t667 = getelementptr { i64, ptr }, ptr %t666, i64 3
  store { i64, ptr } { i64 8, ptr @.d54 }, ptr %t667, !tbaa !37
  %t668 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !27
  %t670 = getelementptr { i64, ptr }, ptr %t669, i64 4
  store { i64, ptr } { i64 2, ptr @.d55 }, ptr %t670, !tbaa !37
  %t672 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t673 = load ptr, ptr %t672, !tbaa !27
  %t674 = getelementptr { i64, ptr }, ptr %t673, i64 5
  store { i64, ptr } %t650, ptr %t674, !tbaa !37
  %t675 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t676 = call i1 @compiler_2ffetch_2egit(ptr %s20, { i64, ptr } %t675)
  store i1 %t676, ptr %l198
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s20)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s18)
  br label %bb123
bb123:
  %t677 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t679 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s15, { i64, ptr } %t677)
  store { i64, ptr } %t679, ptr %l200
  br label %bb124
bb124:
  %t680 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t681 = extractvalue { i64, ptr } %t680, 0
  %t682 = extractvalue { i64, ptr } %t680, 1
  %t683 = mul i64 %t681, 1
  %t684 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t683)
  call void @llvm.memcpy.p0.p0.i64(ptr %t684, ptr %t682, i64 %t683, i1 false)
  %t685 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t684, 1
  %t687 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t690 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s0, { i64, ptr } %t686, { i64, ptr } %t687)
  store i1 %t690, ptr %l203
  br label %bb125
bb125:
  %t691 = load i1, ptr %l203, !tbaa !21
  %t692 = xor i1 %t691, true
  br i1 %t692, label %bb126, label %bb127
bb126:
  %t694 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t696 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t694)
  store i32 %t696, ptr %l206
  %t697 = icmp ne i32 %t696, 0
  br i1 %t697, label %bb129, label %ok.698
ok.698:
  br label %bb128
bb127:
  br label %bb134
bb128:
  br label %bb133
bb129:
  %t699 = load i32, ptr %l206, !tbaa !23
  %t700 = ashr i32 %t699, 16
  %t702 = icmp eq i32 %t700, 1
  br i1 %t702, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  %t704 = load i32, ptr %l206, !tbaa !23
  %t705 = lshr i32 %t704, 16
  %t706 = and i32 %t704, 65535
  %t707 = icmp eq i32 %t705, 1
  %t708 = select i1 %t707, i32 0, i32 0
  %t709 = icmp eq i32 %t704, 0
  %t710 = shl i32 %t708, 16
  %t711 = or i32 %t710, %t706
  %t712 = select i1 %t709, i32 0, i32 %t711
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t714 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t712, 0
  store { i32, { i64, ptr } } %t714, ptr %rv
  br label %ret
bb132:
  call void @__olang_ert_req_clear()
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t716 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65539, 0
  store { i32, { i64, ptr } } %t716, ptr %rv
  br label %ret
bb134:
  %t717 = load ptr, ptr %lp17
  %t718 = load { i64, ptr }, ptr %t717, !tbaa !27
  %t720 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t718)
  store i1 %t720, ptr %l212
  br label %bb135
bb135:
  %t721 = load i1, ptr %l212, !tbaa !21
  %t722 = xor i1 %t721, true
  br i1 %t722, label %bb136, label %bb137
bb136:
  %t724 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t725 = load ptr, ptr %lp17
  %t726 = load { i64, ptr }, ptr %t725, !tbaa !27
  %t729 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t724, { i64, ptr } %t726)
  store i32 %t729, ptr %l216
  %t730 = icmp ne i32 %t729, 0
  br i1 %t730, label %bb139, label %ok.731
ok.731:
  br label %bb138
bb137:
  br label %bb150
bb138:
  br label %bb149
bb139:
  %t732 = load i32, ptr %l216, !tbaa !23
  %t733 = ashr i32 %t732, 16
  %t735 = icmp eq i32 %t733, 1
  br i1 %t735, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  %t737 = load i32, ptr %l216, !tbaa !23
  %t738 = lshr i32 %t737, 16
  %t739 = and i32 %t737, 65535
  %t740 = icmp eq i32 %t738, 1
  %t741 = select i1 %t740, i32 0, i32 0
  %t742 = icmp eq i32 %t737, 0
  %t743 = shl i32 %t741, 16
  %t744 = or i32 %t743, %t739
  %t745 = select i1 %t742, i32 0, i32 %t744
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t747 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t745, 0
  store { i32, { i64, ptr } } %t747, ptr %rv
  br label %ret
bb142:
  call void @__olang_ert_req_clear()
  %t748 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t750 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t748)
  store i32 %t750, ptr %l221
  %t751 = icmp ne i32 %t750, 0
  br i1 %t751, label %bb144, label %ok.752
ok.752:
  br label %bb143
bb143:
  br label %bb148
bb144:
  %t753 = load i32, ptr %l221, !tbaa !23
  %t754 = ashr i32 %t753, 16
  %t756 = icmp eq i32 %t754, 1
  br i1 %t756, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  %t758 = load i32, ptr %l221, !tbaa !23
  %t759 = lshr i32 %t758, 16
  %t760 = and i32 %t758, 65535
  %t761 = icmp eq i32 %t759, 1
  %t762 = select i1 %t761, i32 0, i32 0
  %t763 = icmp eq i32 %t758, 0
  %t764 = shl i32 %t762, 16
  %t765 = or i32 %t764, %t760
  %t766 = select i1 %t763, i32 0, i32 %t765
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t768 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t766, 0
  store { i32, { i64, ptr } } %t768, ptr %rv
  br label %ret
bb147:
  call void @__olang_ert_req_clear()
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t770 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65539, 0
  store { i32, { i64, ptr } } %t770, ptr %rv
  br label %ret
bb149:
  br label %bb150
bb150:
  %t771 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t773 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t771)
  store i32 %t773, ptr %l227
  %t774 = icmp ne i32 %t773, 0
  br i1 %t774, label %bb152, label %ok.775
ok.775:
  br label %bb151
bb151:
  br label %bb156
bb152:
  %t776 = load i32, ptr %l227, !tbaa !23
  %t777 = ashr i32 %t776, 16
  %t779 = icmp eq i32 %t777, 1
  br i1 %t779, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  %t781 = load i32, ptr %l227, !tbaa !23
  %t782 = lshr i32 %t781, 16
  %t783 = and i32 %t781, 65535
  %t784 = icmp eq i32 %t782, 1
  %t785 = select i1 %t784, i32 0, i32 0
  %t786 = icmp eq i32 %t781, 0
  %t787 = shl i32 %t785, 16
  %t788 = or i32 %t787, %t783
  %t789 = select i1 %t786, i32 0, i32 %t788
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t791 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t789, 0
  store { i32, { i64, ptr } } %t791, ptr %rv
  br label %ret
bb155:
  call void @__olang_ert_req_clear()
  br label %bb156
bb156:
  %t792 = load ptr, ptr %lp17
  %t793 = load { i64, ptr }, ptr %t792, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t795 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t793, 1
  store { i32, { i64, ptr } } %t795, ptr %rv
  br label %ret
bb157:
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t797 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t798 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t799 = extractvalue { i64, ptr } { i64 16, ptr @.d56 }, 1
  %t800 = extractvalue { i64, ptr } { i64 16, ptr @.d56 }, 0
  %t802 = extractvalue { i64, ptr } %t797, 1
  %t803 = extractvalue { i64, ptr } %t797, 0
  %t804 = add i64 %t800, %t803
  %t805 = extractvalue { i64, ptr } { i64 6, ptr @.d57 }, 1
  %t806 = extractvalue { i64, ptr } { i64 6, ptr @.d57 }, 0
  %t807 = add i64 %t804, %t806
  %t809 = extractvalue { i64, ptr } %t798, 1
  %t810 = extractvalue { i64, ptr } %t798, 0
  %t811 = add i64 %t807, %t810
  %t812 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t811)
  call void @olang_textcopy(ptr %t812, ptr %t799, i64 %t800)
  %t813 = getelementptr i8, ptr %t812, i64 %t800
  call void @olang_textcopy(ptr %t813, ptr %t802, i64 %t803)
  %t814 = getelementptr i8, ptr %t813, i64 %t803
  call void @olang_textcopy(ptr %t814, ptr %t805, i64 %t806)
  %t815 = getelementptr i8, ptr %t814, i64 %t806
  call void @olang_textcopy(ptr %t815, ptr %t809, i64 %t810)
  %t816 = insertvalue { i64, ptr } undef, i64 %t811, 0
  %t817 = insertvalue { i64, ptr } %t816, ptr %t812, 1
  %t819 = extractvalue { i64, ptr } %t817, 0
  %t820 = extractvalue { i64, ptr } %t817, 1
  %t821 = mul i64 %t819, 1
  %t822 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t821)
  call void @llvm.memcpy.p0.p0.i64(ptr %t822, ptr %t820, i64 %t821, i1 false)
  %t823 = insertvalue { i64, ptr } undef, i64 %t819, 0
  %t824 = insertvalue { i64, ptr } %t823, ptr %t822, 1
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s0, ptr %t796, { i64, ptr } %t824)
  br label %bb158
bb158:
  %t827 = load i64, ptr %l4, !tbaa !24
  %t828 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t830 = extractvalue { i64, ptr } %t828, 0
  %t833 = icmp slt i64 %t827, %t830
  br i1 %t833, label %bb159, label %bb160
bb159:
  %t835 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t836 = extractvalue { i64, ptr } { i64 9, ptr @.d58 }, 1
  %t837 = extractvalue { i64, ptr } { i64 9, ptr @.d58 }, 0
  %t839 = extractvalue { i64, ptr } %t835, 1
  %t840 = extractvalue { i64, ptr } %t835, 0
  %t841 = add i64 %t837, %t840
  %t842 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t841)
  call void @olang_textcopy(ptr %t842, ptr %t836, i64 %t837)
  %t843 = getelementptr i8, ptr %t842, i64 %t837
  call void @olang_textcopy(ptr %t843, ptr %t839, i64 %t840)
  %t844 = insertvalue { i64, ptr } undef, i64 %t841, 0
  %t845 = insertvalue { i64, ptr } %t844, ptr %t842, 1
  %t847 = extractvalue { i64, ptr } %t845, 0
  %t848 = extractvalue { i64, ptr } %t845, 1
  %t849 = mul i64 %t847, 1
  %t850 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t849)
  call void @llvm.memcpy.p0.p0.i64(ptr %t850, ptr %t848, i64 %t849, i1 false)
  %t851 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t852 = insertvalue { i64, ptr } %t851, ptr %t850, 1
  store { i64, ptr } %t852, ptr %l241, !tbaa !27
  br label %bb161
bb160:
  store { i64, ptr } { i64 7, ptr @.d59 }, ptr %l241, !tbaa !27
  br label %bb161
bb161:
  %t854 = load { i64, ptr }, ptr %l241, !tbaa !27
  store { i64, ptr } %t854, ptr %l19, !tbaa !27
  %t855 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t857 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t855)
  store i32 %t857, ptr %l246
  %t858 = icmp ne i32 %t857, 0
  br i1 %t858, label %bb163, label %ok.859
ok.859:
  br label %bb162
bb162:
  br label %bb167
bb163:
  %t860 = load i32, ptr %l246, !tbaa !23
  %t861 = ashr i32 %t860, 16
  %t863 = icmp eq i32 %t861, 1
  br i1 %t863, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  %t865 = load i32, ptr %l246, !tbaa !23
  %t866 = lshr i32 %t865, 16
  %t867 = and i32 %t865, 65535
  %t868 = icmp eq i32 %t866, 1
  %t869 = select i1 %t868, i32 0, i32 0
  %t870 = icmp eq i32 %t865, 0
  %t871 = shl i32 %t869, 16
  %t872 = or i32 %t871, %t867
  %t873 = select i1 %t870, i32 0, i32 %t872
  call void @__olang_scope_close(ptr %s0)
  %t875 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t873, 0
  store { i32, { i64, ptr } } %t875, ptr %rv
  br label %ret
bb166:
  call void @__olang_ert_req_clear()
  br label %bb167
bb167:
  store { i64, ptr } { i64 0, ptr @.d60 }, ptr %l250, !tbaa !27
  %t876 = load { i64, ptr }, ptr %l250, !tbaa !27
  store { i64, ptr } %t876, ptr %l251, !tbaa !27
  %t877 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t878 = extractvalue { i64, ptr } %t877, 0
  store i64 %t878, ptr %l252, !tbaa !24
  %t879 = load i64, ptr %l252, !tbaa !24
  %t880 = mul i64 %t879, 1
  %t881 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t880)
  %t882 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t883 = insertvalue { i64, ptr } %t882, ptr %t881, 1
  store { i64, ptr } %t883, ptr %l253, !tbaa !27
  %t884 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t885 = load ptr, ptr %t884, !tbaa !27
  %t886 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t887 = load ptr, ptr %t886, !tbaa !27
  %t888 = load i64, ptr %l252, !tbaa !24
  %t889 = mul i64 %t888, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t885, ptr %t887, i64 %t889, i1 false)
  %t890 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t890, ptr %l20, !tbaa !27
  %t891 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t892 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t893 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t894 = mul i64 9, 16
  %t895 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t894)
  %t896 = insertvalue { i64, ptr } undef, i64 9, 0
  %t897 = insertvalue { i64, ptr } %t896, ptr %t895, 1
  store { i64, ptr } %t897, ptr %l257, !tbaa !27
  %t898 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t899 = load ptr, ptr %t898, !tbaa !27
  %t900 = getelementptr { i64, ptr }, ptr %t899, i64 0
  store { i64, ptr } { i64 3, ptr @.d61 }, ptr %t900, !tbaa !37
  %t901 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t902 = load ptr, ptr %t901, !tbaa !27
  %t903 = getelementptr { i64, ptr }, ptr %t902, i64 1
  store { i64, ptr } { i64 5, ptr @.d62 }, ptr %t903, !tbaa !37
  %t904 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t905 = load ptr, ptr %t904, !tbaa !27
  %t906 = getelementptr { i64, ptr }, ptr %t905, i64 2
  store { i64, ptr } { i64 7, ptr @.d63 }, ptr %t906, !tbaa !37
  %t907 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t908 = load ptr, ptr %t907, !tbaa !27
  %t909 = getelementptr { i64, ptr }, ptr %t908, i64 3
  store { i64, ptr } { i64 7, ptr @.d64 }, ptr %t909, !tbaa !37
  %t910 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t911 = load ptr, ptr %t910, !tbaa !27
  %t912 = getelementptr { i64, ptr }, ptr %t911, i64 4
  store { i64, ptr } { i64 1, ptr @.d65 }, ptr %t912, !tbaa !37
  %t914 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t915 = load ptr, ptr %t914, !tbaa !27
  %t916 = getelementptr { i64, ptr }, ptr %t915, i64 5
  store { i64, ptr } %t891, ptr %t916, !tbaa !37
  %t917 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t918 = load ptr, ptr %t917, !tbaa !27
  %t919 = getelementptr { i64, ptr }, ptr %t918, i64 6
  store { i64, ptr } { i64 2, ptr @.d66 }, ptr %t919, !tbaa !37
  %t921 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t922 = load ptr, ptr %t921, !tbaa !27
  %t923 = getelementptr { i64, ptr }, ptr %t922, i64 7
  store { i64, ptr } %t892, ptr %t923, !tbaa !37
  %t925 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t926 = load ptr, ptr %t925, !tbaa !27
  %t927 = getelementptr { i64, ptr }, ptr %t926, i64 8
  store { i64, ptr } %t893, ptr %t927, !tbaa !37
  %t928 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t929 = call i1 @compiler_2ffetch_2egit(ptr %s0, { i64, ptr } %t928)
  store i1 %t929, ptr %l258
  br label %bb168
bb168:
  %t930 = load i1, ptr %l258, !tbaa !21
  br i1 %t930, label %bb169, label %bb170
bb169:
  %t931 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t933 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s0, { i64, ptr } %t931)
  store { i64, ptr } %t933, ptr %l260
  br label %bb171
bb170:
  br label %bb175
bb171:
  %t934 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t935 = extractvalue { i64, ptr } %t934, 0
  %t936 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 0
  store i64 %t937, ptr %l262, !tbaa !24
  %t939 = load i64, ptr %l262, !tbaa !24
  %t940 = icmp eq i64 %t935, %t939
  br i1 %t940, label %bb172, label %bb173
bb172:
  %t942 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t943 = load ptr, ptr %t942, !tbaa !27
  %t944 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t945 = load ptr, ptr %t944, !tbaa !27
  %t946 = load i64, ptr %l262, !tbaa !24
  %t947 = mul i64 %t946, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t943, ptr %t945, i64 %t947, i1 false)
  br label %bb174
bb173:
  %t948 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t948, ptr %l20, !tbaa !27
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t949 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t951 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t949, { i64, ptr } { i64 0, ptr @.d67 })
  store i1 %t951, ptr %l265
  br label %bb176
bb176:
  %t952 = load i1, ptr %l265, !tbaa !21
  br i1 %t952, label %bb177, label %bb178
bb177:
  %t953 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t955 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t953)
  store i32 %t955, ptr %l267
  %t956 = icmp ne i32 %t955, 0
  br i1 %t956, label %bb180, label %ok.957
ok.957:
  br label %bb179
bb178:
  br label %bb185
bb179:
  br label %bb184
bb180:
  %t958 = load i32, ptr %l267, !tbaa !23
  %t959 = ashr i32 %t958, 16
  %t961 = icmp eq i32 %t959, 1
  br i1 %t961, label %bb181, label %bb182
bb181:
  br label %bb183
bb182:
  %t963 = load i32, ptr %l267, !tbaa !23
  %t964 = lshr i32 %t963, 16
  %t965 = and i32 %t963, 65535
  %t966 = icmp eq i32 %t964, 1
  %t967 = select i1 %t966, i32 0, i32 0
  %t968 = icmp eq i32 %t963, 0
  %t969 = shl i32 %t967, 16
  %t970 = or i32 %t969, %t965
  %t971 = select i1 %t968, i32 0, i32 %t970
  call void @__olang_scope_close(ptr %s0)
  %t973 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t971, 0
  store { i32, { i64, ptr } } %t973, ptr %rv
  br label %ret
bb183:
  call void @__olang_ert_req_clear()
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s0)
  %t975 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t975, ptr %rv
  br label %ret
bb185:
  %t976 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t977 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t979 = extractvalue { i64, ptr } %t976, 1
  %t980 = extractvalue { i64, ptr } %t976, 0
  %t981 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t982 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t983 = add i64 %t980, %t982
  %t985 = extractvalue { i64, ptr } %t977, 1
  %t986 = extractvalue { i64, ptr } %t977, 0
  %t987 = add i64 %t983, %t986
  %t988 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t987)
  call void @olang_textcopy(ptr %t988, ptr %t979, i64 %t980)
  %t989 = getelementptr i8, ptr %t988, i64 %t980
  call void @olang_textcopy(ptr %t989, ptr %t981, i64 %t982)
  %t990 = getelementptr i8, ptr %t989, i64 %t982
  call void @olang_textcopy(ptr %t990, ptr %t985, i64 %t986)
  %t991 = insertvalue { i64, ptr } undef, i64 %t987, 0
  %t992 = insertvalue { i64, ptr } %t991, ptr %t988, 1
  %t993 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t993, ptr %lp21
  %t995 = load ptr, ptr %lp21
  store { i64, ptr } %t992, ptr %t995, !tbaa !27
  %t996 = load ptr, ptr %lp21
  %t997 = load { i64, ptr }, ptr %t996, !tbaa !27
  %t999 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t997)
  store i1 %t999, ptr %l276
  br label %bb186
bb186:
  %t1000 = load i1, ptr %l276, !tbaa !21
  br i1 %t1000, label %bb187, label %bb188
bb187:
  %t1001 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t1003 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t1001)
  store i32 %t1003, ptr %l278
  %t1004 = icmp ne i32 %t1003, 0
  br i1 %t1004, label %bb190, label %ok.1005
ok.1005:
  br label %bb189
bb188:
  %t1006 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t1007 = load ptr, ptr %lp21
  %t1008 = load { i64, ptr }, ptr %t1007, !tbaa !27
  %t1011 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t1006, { i64, ptr } %t1008)
  store i32 %t1011, ptr %l284
  %t1012 = icmp ne i32 %t1011, 0
  br i1 %t1012, label %bb196, label %ok.1013
ok.1013:
  br label %bb195
bb189:
  br label %bb194
bb190:
  %t1014 = load i32, ptr %l278, !tbaa !23
  %t1015 = ashr i32 %t1014, 16
  %t1017 = icmp eq i32 %t1015, 1
  br i1 %t1017, label %bb191, label %bb192
bb191:
  br label %bb193
bb192:
  %t1019 = load i32, ptr %l278, !tbaa !23
  %t1020 = lshr i32 %t1019, 16
  %t1021 = and i32 %t1019, 65535
  %t1022 = icmp eq i32 %t1020, 1
  %t1023 = select i1 %t1022, i32 0, i32 0
  %t1024 = icmp eq i32 %t1019, 0
  %t1025 = shl i32 %t1023, 16
  %t1026 = or i32 %t1025, %t1021
  %t1027 = select i1 %t1024, i32 0, i32 %t1026
  call void @__olang_scope_close(ptr %s0)
  %t1029 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t1027, 0
  store { i32, { i64, ptr } } %t1029, ptr %rv
  br label %ret
bb193:
  call void @__olang_ert_req_clear()
  br label %bb194
bb194:
  br label %bb207
bb195:
  br label %bb206
bb196:
  %t1030 = load i32, ptr %l284, !tbaa !23
  %t1031 = ashr i32 %t1030, 16
  %t1033 = icmp eq i32 %t1031, 1
  br i1 %t1033, label %bb197, label %bb198
bb197:
  br label %bb199
bb198:
  %t1035 = load i32, ptr %l284, !tbaa !23
  %t1036 = lshr i32 %t1035, 16
  %t1037 = and i32 %t1035, 65535
  %t1038 = icmp eq i32 %t1036, 1
  %t1039 = select i1 %t1038, i32 0, i32 0
  %t1040 = icmp eq i32 %t1035, 0
  %t1041 = shl i32 %t1039, 16
  %t1042 = or i32 %t1041, %t1037
  %t1043 = select i1 %t1040, i32 0, i32 %t1042
  call void @__olang_scope_close(ptr %s0)
  %t1045 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t1043, 0
  store { i32, { i64, ptr } } %t1045, ptr %rv
  br label %ret
bb199:
  call void @__olang_ert_req_clear()
  %t1046 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t1048 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t1046)
  store i32 %t1048, ptr %l289
  %t1049 = icmp ne i32 %t1048, 0
  br i1 %t1049, label %bb201, label %ok.1050
ok.1050:
  br label %bb200
bb200:
  br label %bb205
bb201:
  %t1051 = load i32, ptr %l289, !tbaa !23
  %t1052 = ashr i32 %t1051, 16
  %t1054 = icmp eq i32 %t1052, 1
  br i1 %t1054, label %bb202, label %bb203
bb202:
  br label %bb204
bb203:
  %t1056 = load i32, ptr %l289, !tbaa !23
  %t1057 = lshr i32 %t1056, 16
  %t1058 = and i32 %t1056, 65535
  %t1059 = icmp eq i32 %t1057, 1
  %t1060 = select i1 %t1059, i32 0, i32 0
  %t1061 = icmp eq i32 %t1056, 0
  %t1062 = shl i32 %t1060, 16
  %t1063 = or i32 %t1062, %t1058
  %t1064 = select i1 %t1061, i32 0, i32 %t1063
  call void @__olang_scope_close(ptr %s0)
  %t1066 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t1064, 0
  store { i32, { i64, ptr } } %t1066, ptr %rv
  br label %ret
bb204:
  call void @__olang_ert_req_clear()
  br label %bb205
bb205:
  call void @__olang_scope_close(ptr %s0)
  %t1068 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t1068, ptr %rv
  br label %ret
bb206:
  br label %bb207
bb207:
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1070 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1071 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %s0, ptr %s0, ptr %t1069, { i64, ptr } %t1070, { i64, ptr } %t1071)
  br label %bb208
bb208:
  %t1075 = load ptr, ptr %l0, !tbaa !29
  %t1077 = getelementptr %"compiler/fetch:Fetcher", ptr %t1075, i32 0, i32 3
  %t1078 = load i1, ptr %t1077, !tbaa !21
  br i1 %t1078, label %bb209, label %bb210
bb209:
  store %olang.scope zeroinitializer, ptr %s39
  %t1080 = load ptr, ptr %l0, !tbaa !29
  %t1081 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1084 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %s0, ptr %t1080, { i64, ptr } %t1081, i1 true)
  store i1 %t1084, ptr %l301
  br label %bb211
bb210:
  br label %bb256
bb211:
  %t1085 = load i1, ptr %l14, !tbaa !21
  br i1 %t1085, label %bb212, label %bb213
bb212:
  %t1087 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1089 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t1087, { i64, ptr } { i64 0, ptr @.d69 })
  store i1 %t1089, ptr %l305
  br label %bb214
bb213:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb215
bb214:
  %t1090 = load i1, ptr %l305, !tbaa !21
  store i1 %t1090, ptr %l303, !tbaa !21
  br label %bb215
bb215:
  %t1091 = load i1, ptr %l303, !tbaa !21
  br i1 %t1091, label %bb216, label %bb217
bb216:
  store %olang.scope zeroinitializer, ptr %s40
  %t1092 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1092, ptr %l306, !tbaa !29
  %t1093 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1093, ptr %l307, !tbaa !27
  %t1094 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1095 = extractvalue { i64, ptr } %t1094, 0
  store i64 %t1095, ptr %l308, !tbaa !24
  %t1096 = icmp sge i64 0, 0
  br i1 %t1096, label %bb218, label %bb219
bb217:
  %t1098 = load i1, ptr %l14, !tbaa !21
  br i1 %t1098, label %bb225, label %bb226
bb218:
  %t1100 = icmp sle i64 0, 12
  br i1 %t1100, label %bb220, label %bb221
bb219:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb220:
  %t1102 = load i64, ptr %l308, !tbaa !24
  %t1103 = icmp sle i64 12, %t1102
  br i1 %t1103, label %bb222, label %bb223
bb221:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb222:
  %t1105 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1106 = load ptr, ptr %t1105, !tbaa !27
  %t1107 = getelementptr i8, ptr %t1106, i64 0
  %t1108 = sub i64 12, 0
  %t1109 = insertvalue { i64, ptr } undef, i64 %t1108, 0
  %t1110 = insertvalue { i64, ptr } %t1109, ptr %t1107, 1
  %t1111 = extractvalue { i64, ptr } { i64 15, ptr @.d70 }, 1
  %t1112 = extractvalue { i64, ptr } { i64 15, ptr @.d70 }, 0
  %t1113 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t1114 = extractvalue { i64, ptr } %t1113, 1
  %t1115 = extractvalue { i64, ptr } %t1113, 0
  %t1116 = add i64 %t1112, %t1115
  %t1117 = extractvalue { i64, ptr } { i64 4, ptr @.d71 }, 1
  %t1118 = extractvalue { i64, ptr } { i64 4, ptr @.d71 }, 0
  %t1119 = add i64 %t1116, %t1118
  %t1121 = extractvalue { i64, ptr } %t1110, 1
  %t1122 = extractvalue { i64, ptr } %t1110, 0
  %t1123 = add i64 %t1119, %t1122
  %t1124 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1123)
  call void @olang_textcopy(ptr %t1124, ptr %t1111, i64 %t1112)
  %t1125 = getelementptr i8, ptr %t1124, i64 %t1112
  call void @olang_textcopy(ptr %t1125, ptr %t1114, i64 %t1115)
  %t1126 = getelementptr i8, ptr %t1125, i64 %t1115
  call void @olang_textcopy(ptr %t1126, ptr %t1117, i64 %t1118)
  %t1127 = getelementptr i8, ptr %t1126, i64 %t1118
  call void @olang_textcopy(ptr %t1127, ptr %t1121, i64 %t1122)
  %t1128 = insertvalue { i64, ptr } undef, i64 %t1123, 0
  %t1129 = insertvalue { i64, ptr } %t1128, ptr %t1124, 1
  %t1131 = extractvalue { i64, ptr } %t1129, 0
  %t1132 = extractvalue { i64, ptr } %t1129, 1
  %t1133 = mul i64 %t1131, 1
  %t1134 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1134, ptr %t1132, i64 %t1133, i1 false)
  %t1135 = insertvalue { i64, ptr } undef, i64 %t1131, 0
  %t1136 = insertvalue { i64, ptr } %t1135, ptr %t1134, 1
  %t1137 = load ptr, ptr %l306, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s40, ptr %t1137, { i64, ptr } %t1136)
  br label %bb224
bb223:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb224:
  call void @__olang_scope_close(ptr %s40)
  br label %bb255
bb225:
  %t1139 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1140 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1139, { i64, ptr } %t1140)
  store i1 %t1143, ptr %l319
  br label %bb227
bb226:
  store i1 false, ptr %l316, !tbaa !21
  br label %bb228
bb227:
  %t1144 = load i1, ptr %l319, !tbaa !21
  %t1145 = xor i1 %t1144, true
  store i1 %t1145, ptr %l316, !tbaa !21
  br label %bb228
bb228:
  %t1147 = load i1, ptr %l316, !tbaa !21
  br i1 %t1147, label %bb229, label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s43
  %t1148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1148, ptr %l321, !tbaa !29
  %t1149 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1149, ptr %l322, !tbaa !27
  %t1150 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1151 = extractvalue { i64, ptr } %t1150, 0
  store i64 %t1151, ptr %l323, !tbaa !24
  %t1152 = icmp sge i64 0, 0
  br i1 %t1152, label %bb231, label %bb232
bb230:
  %t1154 = load i1, ptr %l14, !tbaa !21
  br i1 %t1154, label %bb244, label %bb245
bb231:
  %t1156 = icmp sle i64 0, 12
  br i1 %t1156, label %bb233, label %bb234
bb232:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb233:
  %t1158 = load i64, ptr %l323, !tbaa !24
  %t1159 = icmp sle i64 12, %t1158
  br i1 %t1159, label %bb235, label %bb236
bb234:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb235:
  %t1161 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1162 = load ptr, ptr %t1161, !tbaa !27
  %t1163 = getelementptr i8, ptr %t1162, i64 0
  %t1164 = sub i64 12, 0
  %t1165 = insertvalue { i64, ptr } undef, i64 %t1164, 0
  %t1166 = insertvalue { i64, ptr } %t1165, ptr %t1163, 1
  store { i64, ptr } %t1166, ptr %l327, !tbaa !27
  %t1167 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1168 = extractvalue { i64, ptr } %t1167, 0
  store i64 %t1168, ptr %l328, !tbaa !24
  %t1169 = icmp sge i64 0, 0
  br i1 %t1169, label %bb237, label %bb238
bb236:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb237:
  %t1171 = icmp sle i64 0, 12
  br i1 %t1171, label %bb239, label %bb240
bb238:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb239:
  %t1173 = load i64, ptr %l328, !tbaa !24
  %t1174 = icmp sle i64 12, %t1173
  br i1 %t1174, label %bb241, label %bb242
bb240:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb241:
  %t1176 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t1177 = load ptr, ptr %t1176, !tbaa !27
  %t1178 = getelementptr i8, ptr %t1177, i64 0
  %t1179 = sub i64 12, 0
  %t1180 = insertvalue { i64, ptr } undef, i64 %t1179, 0
  %t1181 = insertvalue { i64, ptr } %t1180, ptr %t1178, 1
  %t1182 = extractvalue { i64, ptr } { i64 15, ptr @.d72 }, 1
  %t1183 = extractvalue { i64, ptr } { i64 15, ptr @.d72 }, 0
  %t1184 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t1185 = extractvalue { i64, ptr } %t1184, 1
  %t1186 = extractvalue { i64, ptr } %t1184, 0
  %t1187 = add i64 %t1183, %t1186
  %t1188 = extractvalue { i64, ptr } { i64 4, ptr @.d73 }, 1
  %t1189 = extractvalue { i64, ptr } { i64 4, ptr @.d73 }, 0
  %t1190 = add i64 %t1187, %t1189
  %t1191 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t1192 = extractvalue { i64, ptr } %t1191, 1
  %t1193 = extractvalue { i64, ptr } %t1191, 0
  %t1194 = add i64 %t1190, %t1193
  %t1195 = extractvalue { i64, ptr } { i64 6, ptr @.d74 }, 1
  %t1196 = extractvalue { i64, ptr } { i64 6, ptr @.d74 }, 0
  %t1197 = add i64 %t1194, %t1196
  %t1199 = extractvalue { i64, ptr } %t1181, 1
  %t1200 = extractvalue { i64, ptr } %t1181, 0
  %t1201 = add i64 %t1197, %t1200
  %t1202 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 1
  %t1203 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 0
  %t1204 = add i64 %t1201, %t1203
  %t1205 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1204)
  call void @olang_textcopy(ptr %t1205, ptr %t1182, i64 %t1183)
  %t1206 = getelementptr i8, ptr %t1205, i64 %t1183
  call void @olang_textcopy(ptr %t1206, ptr %t1185, i64 %t1186)
  %t1207 = getelementptr i8, ptr %t1206, i64 %t1186
  call void @olang_textcopy(ptr %t1207, ptr %t1188, i64 %t1189)
  %t1208 = getelementptr i8, ptr %t1207, i64 %t1189
  call void @olang_textcopy(ptr %t1208, ptr %t1192, i64 %t1193)
  %t1209 = getelementptr i8, ptr %t1208, i64 %t1193
  call void @olang_textcopy(ptr %t1209, ptr %t1195, i64 %t1196)
  %t1210 = getelementptr i8, ptr %t1209, i64 %t1196
  call void @olang_textcopy(ptr %t1210, ptr %t1199, i64 %t1200)
  %t1211 = getelementptr i8, ptr %t1210, i64 %t1200
  call void @olang_textcopy(ptr %t1211, ptr %t1202, i64 %t1203)
  %t1212 = insertvalue { i64, ptr } undef, i64 %t1204, 0
  %t1213 = insertvalue { i64, ptr } %t1212, ptr %t1205, 1
  %t1215 = extractvalue { i64, ptr } %t1213, 0
  %t1216 = extractvalue { i64, ptr } %t1213, 1
  %t1217 = mul i64 %t1215, 1
  %t1218 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1218, ptr %t1216, i64 %t1217, i1 false)
  %t1219 = insertvalue { i64, ptr } undef, i64 %t1215, 0
  %t1220 = insertvalue { i64, ptr } %t1219, ptr %t1218, 1
  %t1221 = load ptr, ptr %l321, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s43, ptr %t1221, { i64, ptr } %t1220)
  br label %bb243
bb242:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb243:
  call void @__olang_scope_close(ptr %s43)
  br label %bb254
bb244:
  store %olang.scope zeroinitializer, ptr %s46
  %t1223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1223, ptr %l336, !tbaa !29
  %t1224 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1224, ptr %l337, !tbaa !27
  %t1225 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1226 = extractvalue { i64, ptr } %t1225, 0
  store i64 %t1226, ptr %l338, !tbaa !24
  %t1227 = icmp sge i64 0, 0
  br i1 %t1227, label %bb246, label %bb247
bb245:
  br label %bb253
bb246:
  %t1229 = icmp sle i64 0, 12
  br i1 %t1229, label %bb248, label %bb249
bb247:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb248:
  %t1231 = load i64, ptr %l338, !tbaa !24
  %t1232 = icmp sle i64 12, %t1231
  br i1 %t1232, label %bb250, label %bb251
bb249:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb250:
  %t1234 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1235 = load ptr, ptr %t1234, !tbaa !27
  %t1236 = getelementptr i8, ptr %t1235, i64 0
  %t1237 = sub i64 12, 0
  %t1238 = insertvalue { i64, ptr } undef, i64 %t1237, 0
  %t1239 = insertvalue { i64, ptr } %t1238, ptr %t1236, 1
  %t1240 = extractvalue { i64, ptr } { i64 7, ptr @.d76 }, 1
  %t1241 = extractvalue { i64, ptr } { i64 7, ptr @.d76 }, 0
  %t1242 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t1243 = extractvalue { i64, ptr } %t1242, 1
  %t1244 = extractvalue { i64, ptr } %t1242, 0
  %t1245 = add i64 %t1241, %t1244
  %t1246 = extractvalue { i64, ptr } { i64 15, ptr @.d77 }, 1
  %t1247 = extractvalue { i64, ptr } { i64 15, ptr @.d77 }, 0
  %t1248 = add i64 %t1245, %t1247
  %t1250 = extractvalue { i64, ptr } %t1239, 1
  %t1251 = extractvalue { i64, ptr } %t1239, 0
  %t1252 = add i64 %t1248, %t1251
  %t1253 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1252)
  call void @olang_textcopy(ptr %t1253, ptr %t1240, i64 %t1241)
  %t1254 = getelementptr i8, ptr %t1253, i64 %t1241
  call void @olang_textcopy(ptr %t1254, ptr %t1243, i64 %t1244)
  %t1255 = getelementptr i8, ptr %t1254, i64 %t1244
  call void @olang_textcopy(ptr %t1255, ptr %t1246, i64 %t1247)
  %t1256 = getelementptr i8, ptr %t1255, i64 %t1247
  call void @olang_textcopy(ptr %t1256, ptr %t1250, i64 %t1251)
  %t1257 = insertvalue { i64, ptr } undef, i64 %t1252, 0
  %t1258 = insertvalue { i64, ptr } %t1257, ptr %t1253, 1
  %t1260 = extractvalue { i64, ptr } %t1258, 0
  %t1261 = extractvalue { i64, ptr } %t1258, 1
  %t1262 = mul i64 %t1260, 1
  %t1263 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1263, ptr %t1261, i64 %t1262, i1 false)
  %t1264 = insertvalue { i64, ptr } undef, i64 %t1260, 0
  %t1265 = insertvalue { i64, ptr } %t1264, ptr %t1263, 1
  %t1266 = load ptr, ptr %l336, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s46, ptr %t1266, { i64, ptr } %t1265)
  br label %bb252
bb251:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb252:
  call void @__olang_scope_close(ptr %s46)
  br label %bb253
bb253:
  br label %bb254
bb254:
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s39)
  br label %bb256
bb256:
  %t1268 = load ptr, ptr %lp21
  %t1269 = load { i64, ptr }, ptr %t1268, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t1271 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t1269, 1
  store { i32, { i64, ptr } } %t1271, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %l45 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l18, !tbaa !24
  store i64 %t35, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l15, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l39
  br label %bb13
bb13:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %a1)
  store i1 %t65, ptr %l41
  br label %bb14
bb14:
  %t66 = load i1, ptr %l41, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/fetch:Fetcher", ptr %t67, i32 0, i32 7
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l45
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t74 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t75 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t74, 1
  store { i32, { i64, ptr } } %t75, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  %t81 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l22 = alloca %"std/prelude/text:LineIter"
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca i1
  %l57 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/fetch:Fetcher", ptr %t6, i32 0, i32 5
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fetch:Fetcher", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %t12)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l18
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l17
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t20 = load i32, ptr %l18, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_53ffa6078a05df97_cedcb09c0479edcb)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t28 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t25)
  store %"std/prelude/text:LineIter" %t28, ptr %l22
  br label %bb10
bb10:
  %t29 = load %"std/prelude/text:LineIter", ptr %l22
  store %"std/prelude/text:LineIter" %t29, ptr %l2
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %l2)
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l26
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb13, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l25
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t36, ptr %l23, !tbaa !27
  br label %bb17
bb13:
  %t37 = load i32, ptr %l26, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_6b88478e5ba0e6f6_911b45007093a98a)
  unreachable
bb16:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb17:
  %t42 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t43, { i64, ptr } { i64 1, ptr @.d78 })
  store i1 %t45, ptr %l30
  br label %bb18
bb18:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb20:
  br label %bb21
bb21:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t47)
  store { i64, ptr } %t49, ptr %l32
  br label %bb22
bb22:
  %t50 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t51 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s4, { i64, ptr } %t50, { i64, ptr } { i64 1, ptr @.d79 })
  store { i64, ptr } %t51, ptr %l33
  br label %bb23
bb23:
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d80 }, ptr %l34, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t53, ptr %l35, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l36, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l37, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l36, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t67, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d81 }, ptr %l38, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l40, !tbaa !24
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l41, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t82, ptr %l6, !tbaa !27
  store { i64, ptr } %t52, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l9, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t97, ptr %l49, !tbaa !27
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %t101, i64 %t98
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !37
  store { i64, ptr } %t103, ptr %l10, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t105, { i64, ptr } { i64 0, ptr @.d82 })
  store i1 %t107, ptr %l53
  br label %bb28
bb28:
  %t108 = load i1, ptr %l53, !tbaa !21
  br i1 %t108, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb30:
  br label %bb31
bb31:
  %t109 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s7, { i64, ptr } %t109, { i64, ptr } { i64 0, ptr @.d83 })
  store i1 %t111, ptr %l55
  br label %bb32
bb32:
  %t112 = load i1, ptr %l55, !tbaa !21
  br i1 %t112, label %bb33, label %bb34
bb33:
  %t113 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = extractvalue { i64, ptr } %t113, 0
  %t117 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t115, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l57, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l59, !tbaa !24
  %t125 = load i64, ptr %l59, !tbaa !24
  %t126 = icmp eq i64 %t121, %t125
  br i1 %t126, label %bb35, label %bb36
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t128 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s11, { i64, ptr } %t128, { i64, ptr } { i64 0, ptr @.d84 })
  store i1 %t130, ptr %l62
  br label %bb38
bb35:
  %t131 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l59, !tbaa !24
  %t136 = mul i64 %t135, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t132, ptr %t134, i64 %t136, i1 false)
  br label %bb37
bb36:
  %t137 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t137, ptr %l5, !tbaa !27
  br label %bb37
bb37:
  br label %bb45
bb38:
  %t138 = load i1, ptr %l62, !tbaa !21
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t139 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = extractvalue { i64, ptr } %t139, 0
  %t143 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t141, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l64, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l66, !tbaa !24
  %t151 = load i64, ptr %l66, !tbaa !24
  %t152 = icmp eq i64 %t147, %t151
  br i1 %t152, label %bb41, label %bb42
bb40:
  br label %bb44
bb41:
  %t154 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l66, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  br label %bb43
bb42:
  %t160 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t160, ptr %l6, !tbaa !27
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s11)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t161 = load i64, ptr %l8, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l8, !tbaa !24
  br label %bb24
bb47:
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t167 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t165, { i64, ptr } { i64 0, ptr @.d85 })
  store i1 %t167, ptr %l71
  br label %bb48
bb48:
  %t168 = load i1, ptr %l71, !tbaa !21
  br i1 %t168, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb50:
  br label %bb51
bb51:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/fetch:Fetcher", ptr %t169, i32 0, i32 6
  %t172 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 1
  %t175 = extractvalue { i64, ptr } %t172, 0
  %t176 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t174, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t171, { i64, ptr } %t185)
  br label %bb52
bb52:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/fetch:Fetcher", ptr %t188, i32 0, i32 7
  %t191 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = extractvalue { i64, ptr } %t191, 0
  %t195 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t193, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = extractvalue { i64, ptr } %t197, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t190, { i64, ptr } %t204)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  br label %bb11
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca i1
  %l61 = alloca i1
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l88 = alloca i64
  %l97 = alloca i64
  %l100 = alloca i64
  %l125 = alloca %"std/prelude/text:StringBuilder"
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l157 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %t235 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l25
  br label %bb2
bb2:
  %t8 = load i64, ptr %l25, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l32, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l32, !tbaa !24
  store i64 %t35, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %l9, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l53
  br label %bb13
bb13:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t62)
  store i1 %t65, ptr %l55
  br label %bb14
bb14:
  %t66 = load i1, ptr %l55, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load i64, ptr %l9, !tbaa !24
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/fetch:Fetcher", ptr %t77, i32 0, i32 7
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store { i64, ptr } %t83, ptr %l65
  br label %bb22
bb21:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb24
bb22:
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t85, { i64, ptr } %t84)
  store i1 %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load i1, ptr %l67, !tbaa !21
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = icmp sge i64 %t90, 0
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/fetch:Fetcher", ptr %t94, i32 0, i32 7
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = extractvalue { i64, ptr } %t98, 0
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t100, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v0, ptr %t96, i64 %t97, { i64, ptr } %t111)
  br label %bb30
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/fetch:Fetcher", ptr %t115, i32 0, i32 6
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t117, { i64, ptr } %t131)
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/fetch:Fetcher", ptr %t134, i32 0, i32 7
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t139, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t136, { i64, ptr } %t150)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/fetch:Fetcher", ptr %t153, i32 0, i32 6
  %t157 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t155)
  store i64 %t157, ptr %l88
  br label %bb34
bb34:
  %t158 = load i64, ptr %l88, !tbaa !24
  %t159 = icmp sge i64 %t158, 0
  br i1 %t159, label %bb35, label %bb36
bb35:
  %t161 = load i64, ptr %l88, !tbaa !24
  %t162 = icmp sle i64 %t161, 1152921504606846975
  br i1 %t162, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ba721b6722bc57b1_efdace1c8e747995)
  unreachable
bb37:
  %t164 = load i64, ptr %l88, !tbaa !24
  %t165 = mul i64 %t164, 8
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  store i64 %t172, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_ba721b6722bc57b1_efdace1c8e747995)
  unreachable
bb39:
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb44
bb41:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t185 = load i64, ptr %l11, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l13, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l13, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l100, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb43
bb43:
  %t200 = load i64, ptr %l100, !tbaa !24
  store i64 %t200, ptr %l97, !tbaa !24
  br label %bb44
bb44:
  %t201 = load i64, ptr %l97, !tbaa !24
  store i64 %t201, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s12
  %t202 = load i64, ptr %l15, !tbaa !24
  %t203 = load i64, ptr %l14, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s12)
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t210 = load i64, ptr %l11, !tbaa !24
  %t211 = load i64, ptr %l15, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l16, !tbaa !24
  %t220 = load i64, ptr %l16, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i64, ptr %t225, i64 %t220
  store i64 %t221, ptr %t226, !tbaa !34
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb49:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l15, !tbaa !24
  br label %bb45
bb50:
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t234 = ptrtoint ptr %t233 to i64
  %t236 = getelementptr { ptr, ptr }, ptr %t235, i32 0, i32 0
  store ptr %t232, ptr %t236, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t238 = getelementptr { ptr, ptr }, ptr %t235, i32 0, i32 1
  store ptr %v0, ptr %t238, !tbaa !28
  %t239 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_86, 0
  %t240 = insertvalue { ptr, ptr } %t239, ptr %t235, 1
  %t243 = extractvalue { ptr, ptr } %t240, 0
  %t244 = extractvalue { ptr, ptr } %t240, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t231, ptr %t243, ptr %t244)
  br label %bb51
bb51:
  %t245 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t245, ptr %l125
  br label %bb52
bb52:
  %t246 = load %"std/prelude/text:StringBuilder", ptr %l125
  store %"std/prelude/text:StringBuilder" %t246, ptr %l17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 100, ptr @.d87 })
  br label %bb53
bb53:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 77, ptr @.d88 })
  br label %bb54
bb54:
  %t249 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t249, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l20, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s15
  %t255 = load i64, ptr %l19, !tbaa !24
  %t256 = load i64, ptr %l20, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s15)
  br label %bb66
bb57:
  br label %bb58
bb58:
  %t263 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t263, ptr %l135, !tbaa !27
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i64, ptr %t267, i64 %t264
  %t269 = load i64, ptr %t268, !tbaa !34
  store i64 %t269, ptr %l21, !tbaa !24
  store ptr %l17, ptr %l138, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/fetch:Fetcher", ptr %t271, i32 0, i32 6
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t273, i64 %t274)
  store { i64, ptr } %t277, ptr %l142
  br label %bb59
bb59:
  %t278 = load ptr, ptr %l138, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l142, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t278, { i64, ptr } %t279)
  br label %bb60
bb60:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l17, i8 32)
  br label %bb61
bb61:
  store ptr %l17, ptr %l144, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/fetch:Fetcher", ptr %t281, i32 0, i32 7
  %t284 = load i64, ptr %l21, !tbaa !24
  %t287 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t283, i64 %t284)
  store { i64, ptr } %t287, ptr %l148
  br label %bb62
bb62:
  %t288 = load ptr, ptr %l144, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l148, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t288, { i64, ptr } %t289)
  br label %bb63
bb63:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l17, i8 10)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s15)
  br label %bb65
bb65:
  %t291 = load i64, ptr %l19, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l19, !tbaa !24
  br label %bb55
bb66:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/fetch:Fetcher", ptr %t295, i32 0, i32 0
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, ptr } %t298, ptr %l153, !tbaa !27
  %t300 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l17)
  store { i64, ptr } %t300, ptr %l155
  br label %bb67
bb67:
  %t301 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t304 = call i32 @std_2fos_2eWriteFile(ptr %v0, ptr %s0, { i64, ptr } %t302, { i64, ptr } %t301)
  store i32 %t304, ptr %l157
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb69, label %ok.306
ok.306:
  br label %bb68
bb68:
  br label %bb73
bb69:
  %t307 = load i32, ptr %l157, !tbaa !23
  %t308 = ashr i32 %t307, 16
  %t310 = icmp eq i32 %t308, 1
  br i1 %t310, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_88b806f24688508b_997ec4238546bef7)
  unreachable
bb72:
  call void @__olang_ert_req_clear()
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l11 = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 9
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = extractvalue { i64, ptr } %t10, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t3, { i64, ptr } %t17)
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/fetch:Fetcher", ptr %t20, i32 0, i32 4
  %t23 = load i1, ptr %t22, !tbaa !21
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = call i32 @std_2fio_2ePrintErrln(ptr %v1, { i64, ptr } %t27)
  store i32 %t29, ptr %l11
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  br label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb9
bb5:
  %t32 = load i32, ptr %l11, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_123b76add1f6a034_48d214a7cc9ba878)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l24 = alloca { i64, ptr }
  %l29 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l15
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l14
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ee93546c87f9d64c_79e6a6f44e92448)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t39, { i64, ptr } %t42)
  store i1 %t45, ptr %l29
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l7, !tbaa !24
  br label %bb8
bb17:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t52, %t53
  store i64 %t56, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  br i1 %a2, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/fetch:Fetcher", ptr %t60, i32 0, i32 8
  %t63 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t62, { i64, ptr } %t76)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2egit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:Output"
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr @.d89 }, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t4 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t3, i1 true, { i64, ptr } { i64 0, ptr @.d90 })
  %t5 = extractvalue { i32, %"std/os:Output" } %t4, 1
  %t6 = extractvalue { i32, %"std/os:Output" } %t4, 0
  store i32 %t6, ptr %l6
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store %"std/os:Output" %t5, ptr %l5
  br label %bb1
bb1:
  %t9 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t9, ptr %l2
  br label %bb6
bb2:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_456a27cc34a1957d_6cd35c881f48b5d9)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t16 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t16, ptr %l1
  %t17 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = icmp eq i32 %t18, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ehead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca %"std/os:Output"
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"std/os:Output"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/os:Output"
  %l11 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t10 = mul i64 5, 16
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 5, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %t15, i64 0
  store { i64, ptr } { i64 3, ptr @.d91 }, ptr %t16, !tbaa !37
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %t18, i64 1
  store { i64, ptr } { i64 2, ptr @.d92 }, ptr %t19, !tbaa !37
  %t21 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %t22, i64 2
  store { i64, ptr } %t7, ptr %t23, !tbaa !37
  %t24 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %t25, i64 3
  store { i64, ptr } { i64 9, ptr @.d93 }, ptr %t26, !tbaa !37
  %t27 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 4
  store { i64, ptr } { i64 4, ptr @.d94 }, ptr %t29, !tbaa !37
  store { i64, ptr } { i64 0, ptr @.d95 }, ptr %l9, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t30, { i64, ptr } %t31, i1 true, { i64, ptr } { i64 0, ptr @.d96 })
  %t33 = extractvalue { i32, %"std/os:Output" } %t32, 1
  %t34 = extractvalue { i32, %"std/os:Output" } %t32, 0
  store i32 %t34, ptr %l11
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb2, label %ok.36
ok.36:
  store %"std/os:Output" %t33, ptr %l10
  br label %bb1
bb1:
  %t37 = load %"std/os:Output", ptr %l10
  store %"std/os:Output" %t37, ptr %l6
  br label %bb6
bb2:
  %t38 = load i32, ptr %l11, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9013815812f03cb5_c1602845c5aedee9)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d97 }, ptr %l14, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t43, ptr %l15, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l16, !tbaa !24
  %t46 = load i64, ptr %l16, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l16, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t57, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
bb6:
  %t59 = load %"std/os:Output", ptr %l6
  store %"std/os:Output" %t59, ptr %l2
  %t60 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t63 = icmp ne i32 %t61, 0
  br i1 %t63, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr @.d98 }, ptr %l20, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t65, ptr %l21, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l22, !tbaa !24
  %t68 = load i64, ptr %l22, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l23, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l22, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t79, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t81 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t82)
  store { i64, ptr } %t84, ptr %l25
  br label %bb10
bb10:
  %t85 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t85, ptr %l3, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t86)
  store i1 %t88, ptr %l27
  br label %bb11
bb11:
  %t89 = load i1, ptr %l27, !tbaa !21
  br i1 %t89, label %bb12, label %bb13
bb12:
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = extractvalue { i64, ptr } %t90, 0
  %t94 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t92, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l28, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr @.d99 }, ptr %l31, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t98, ptr %l28, !tbaa !27
  br label %bb14
bb14:
  %t100 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l33, !tbaa !24
  %t102 = load i64, ptr %l33, !tbaa !24
  %t103 = mul i64 %t102, 1
  %t104 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l34, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l33, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  %t113 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t113, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t114 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2emakeRepo(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l9 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l21 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr @.d100 }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d100 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t19)
  store i32 %t21, ptr %l9
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb2, label %ok.23
ok.23:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t24 = load i32, ptr %l9, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c9ab87d2c1341871_fd16dd2dcdcd2995)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d101 }, ptr %l12, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t29, ptr %l13, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l14, !tbaa !24
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l15, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l14, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t43, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb6:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = extractvalue { i64, ptr } %t45, 0
  %t49 = extractvalue { i64, ptr } { i64 10, ptr @.d102 }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr @.d102 }, 0
  %t51 = add i64 %t48, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t47, i64 %t48)
  %t53 = getelementptr i8, ptr %t52, i64 %t48
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t67 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t62, { i64, ptr } %a2)
  store i32 %t67, ptr %l21
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb8, label %ok.69
ok.69:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t70 = load i32, ptr %l21, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  br i1 %t73, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c6873aa714579460_b40d85e54622baa4)
  unreachable
bb11:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d103 }, ptr %l24, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t75, ptr %l25, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l26, !tbaa !24
  %t78 = load i64, ptr %l26, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l27, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l26, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t89, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
bb12:
  %t91 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t91, { i64, ptr } { i64 3, ptr @.d104 })
  store i1 %t93, ptr %l29
  br label %bb13
bb13:
  %t94 = load i1, ptr %l29, !tbaa !21
  br i1 %t94, label %bb14, label %bb15
bb14:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t95, { i64, ptr } { i64 9, ptr @.d105 })
  store i1 %t97, ptr %l32
  br label %bb16
bb15:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb17
bb16:
  %t98 = load i1, ptr %l32, !tbaa !21
  store i1 %t98, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t99 = load i1, ptr %l30, !tbaa !21
  br i1 %t99, label %bb18, label %bb19
bb18:
  %t100 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t102 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 11, ptr @.d106 })
  store i1 %t102, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb21
bb20:
  %t103 = load i1, ptr %l35, !tbaa !21
  store i1 %t103, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l33, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t109 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v3, { i64, ptr } %t107)
  store { i64, ptr } %t109, ptr %l39
  br label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr @.d107 }, ptr %l40, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t110, ptr %l37, !tbaa !27
  br label %bb25
bb24:
  %t112 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t112, ptr %l37, !tbaa !27
  br label %bb25
bb25:
  %t113 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l42, !tbaa !24
  %t115 = load i64, ptr %l42, !tbaa !24
  %t116 = mul i64 %t115, 1
  %t117 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l43, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l42, !tbaa !24
  %t125 = mul i64 %t124, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t126, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffetch_2esh(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/os:Output"
  %l3 = alloca %"std/os:Output"
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"std/os:Output"
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr @.d108 }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %a1, { i64, ptr } %t4, i1 true, { i64, ptr } %a0)
  %t7 = extractvalue { i32, %"std/os:Output" } %t6, 1
  %t8 = extractvalue { i32, %"std/os:Output" } %t6, 0
  store i32 %t8, ptr %l8
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  store %"std/os:Output" %t7, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"std/os:Output", ptr %l7
  store %"std/os:Output" %t11, ptr %l3
  br label %bb6
bb2:
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5d76ed62925a0d26_8e596c5fa04ecd8a)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t18 = load %"std/os:Output", ptr %l3
  store %"std/os:Output" %t18, ptr %l2
  %t19 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = icmp eq i32 %t20, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/fetch:Fetcher"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store { i64, ptr } %a1, ptr %l6, !tbaa !27
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  store i1 %a3, ptr %l8, !tbaa !21
  store i1 %a4, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l20
  br label %bb1
bb1:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l11
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l21
  br label %bb2
bb2:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l12
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t17)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l22
  br label %bb3
bb3:
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l13
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t20)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t24 = insertvalue %"compiler/fetch:Fetcher" undef, { i64, ptr } %t23, 0
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t26 = insertvalue %"compiler/fetch:Fetcher" %t24, { i64, ptr } %t25, 1
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t28 = insertvalue %"compiler/fetch:Fetcher" %t26, { i64, ptr } %t27, 2
  %t29 = load i1, ptr %l8, !tbaa !21
  %t30 = insertvalue %"compiler/fetch:Fetcher" %t28, i1 %t29, 3
  %t31 = load i1, ptr %l9, !tbaa !21
  %t32 = insertvalue %"compiler/fetch:Fetcher" %t30, i1 %t31, 4
  %t33 = load i1, ptr %l10, !tbaa !21
  %t34 = insertvalue %"compiler/fetch:Fetcher" %t32, i1 %t33, 5
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t36 = insertvalue %"compiler/fetch:Fetcher" %t34, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, 6
  %t37 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t38 = insertvalue %"compiler/fetch:Fetcher" %t36, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, 7
  %t39 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t40 = insertvalue %"compiler/fetch:Fetcher" %t38, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, 8
  %t42 = insertvalue %"compiler/fetch:Fetcher" %t40, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, 9
  store %"compiler/fetch:Fetcher" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/fetch:Fetcher", ptr %rv
  ret %"compiler/fetch:Fetcher" %rr
}

@.d0 = private constant [11 x i8] c"OLANG_CACHE"
declare void @__olang_ert_req_clear()
@.d1 = private constant [0 x i8] c""
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant [0 x i8] c""
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant [4 x i8] c"HOME"
@.d4 = private constant [1 x i8] c"."
@.d5 = private constant [13 x i8] c"/.cache/olang"
@.d6 = private constant [14 x i8] c"OLANG_GIT_BASE"
@.d7 = private constant [0 x i8] c""
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [8 x i8] c"https://"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant [2 x i8] c".."
@.d11 = private constant [16 x i8] c"/example.com/me/"
@.d12 = private constant [10 x i8] c"/lib.olang"
declare void @__olang_check_failed(ptr)
@.d13 = private constant [0 x i8] c""
@.d14 = private constant [12 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr @.d109 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 11, ptr @.d111 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 14, ptr @.d112 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 20, ptr @.d113 }, { i64, ptr } { i64 6, ptr @.d114 }, { i64, ptr } { i64 2, ptr @.d115 }, { i64, ptr } { i64 2, ptr @.d116 }, { i64, ptr } { i64 2, ptr @.d117 }, { i64, ptr } { i64 1, ptr @.d118 }]
@.d15 = private constant [0 x i8] c""
@.d16 = private constant [1 x i8] c"/"
@.d17 = private constant [1 x i8] c"/"
@.d18 = private constant [1 x i8] c"/"
@.d19 = private constant [1 x i8] c"/"
@.d20 = private constant [1 x i8] c"/"
@.d21 = private constant [1 x i8] c"/"
@.d22 = private constant [1 x i8] c"/"
@.d23 = private constant [0 x i8] c""
@.d24 = private constant [0 x i8] c""
@.d25 = private constant [0 x i8] c""
@.d26 = private constant [1 x i8] c"/"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d27 = private constant [7 x i8] c".fetch-"
@.d28 = private constant [16 x i8] c"olang: fetching "
@.d29 = private constant [6 x i8] c" into "
@.d30 = private constant [4 x i8] c" at "
@.d31 = private constant [20 x i8] c", as olang.lock says"
@.d32 = private constant [1 x i8] c"/"
@.d33 = private constant [3 x i8] c"git"
@.d34 = private constant [4 x i8] c"init"
@.d35 = private constant [2 x i8] c"-q"
@.d36 = private constant [3 x i8] c"git"
@.d37 = private constant [2 x i8] c"-C"
@.d38 = private constant [5 x i8] c"fetch"
@.d39 = private constant [2 x i8] c"-q"
@.d40 = private constant [7 x i8] c"--depth"
@.d41 = private constant [1 x i8] c"1"
@.d42 = private constant [2 x i8] c"--"
@.d43 = private constant [3 x i8] c"git"
@.d44 = private constant [2 x i8] c"-C"
@.d45 = private constant [8 x i8] c"checkout"
@.d46 = private constant [2 x i8] c"-q"
@.d47 = private constant [10 x i8] c"FETCH_HEAD"
@.d48 = private constant [3 x i8] c"git"
@.d49 = private constant [5 x i8] c"clone"
@.d50 = private constant [2 x i8] c"-q"
@.d51 = private constant [2 x i8] c"--"
@.d52 = private constant [3 x i8] c"git"
@.d53 = private constant [2 x i8] c"-C"
@.d54 = private constant [8 x i8] c"checkout"
@.d55 = private constant [2 x i8] c"-q"
@.d56 = private constant [16 x i8] c"olang: fetching "
@.d57 = private constant [6 x i8] c" into "
@.d58 = private constant [9 x i8] c"--branch="
@.d59 = private constant [7 x i8] c"--quiet"
@.d60 = private constant [0 x i8] c""
@.d61 = private constant [3 x i8] c"git"
@.d62 = private constant [5 x i8] c"clone"
@.d63 = private constant [7 x i8] c"--quiet"
@.d64 = private constant [7 x i8] c"--depth"
@.d65 = private constant [1 x i8] c"1"
@.d66 = private constant [2 x i8] c"--"
@.d67 = private constant [0 x i8] c""
@.d68 = private constant [1 x i8] c"/"
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [15 x i8] c"olang: updated "
@.d71 = private constant [4 x i8] c" to "
@.d72 = private constant [15 x i8] c"olang: updated "
@.d73 = private constant [4 x i8] c" to "
@.d74 = private constant [6 x i8] c" (was "
@.d75 = private constant [1 x i8] c")"
@.d76 = private constant [7 x i8] c"olang: "
@.d77 = private constant [15 x i8] c" is already at "
@.d78 = private constant [1 x i8] c"#"
@.d79 = private constant [1 x i8] c" "
@.d80 = private constant [0 x i8] c""
@.d81 = private constant [0 x i8] c""
@.d82 = private constant [0 x i8] c""
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [0 x i8] c""
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_86(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 6
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %vc0, ptr %vc0, ptr %t3, i64 %a0)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/fetch:Fetcher", ptr %t8, i32 0, i32 6
  %t14 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %vc0, ptr %vc0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t15, { i64, ptr } %t16)
  store i1 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d87 = private constant [100 x i8] c"# olang.lock - the commit each remote repository is built from (M23b). Delete a line to update that\0A"
@.d88 = private constant [77 x i8] c"# repository, or build with -u to update every one the build reaches (M23c).\0A"
@.d89 = private constant [0 x i8] c""
@.d90 = private constant [0 x i8] c""
@.d91 = private constant [3 x i8] c"git"
@.d92 = private constant [2 x i8] c"-C"
@.d93 = private constant [9 x i8] c"rev-parse"
@.d94 = private constant [4 x i8] c"HEAD"
@.d95 = private constant [0 x i8] c""
@.d96 = private constant [0 x i8] c""
@.d97 = private constant [0 x i8] c""
@.d98 = private constant [0 x i8] c""
@.d99 = private constant [0 x i8] c""
@.d100 = private constant [16 x i8] c"/example.com/me/"
@.d101 = private constant [0 x i8] c""
@.d102 = private constant [10 x i8] c"/lib.olang"
@.d103 = private constant [0 x i8] c""
@.d104 = private constant [3 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr @.d109 }, { i64, ptr } { i64 4, ptr @.d119 }, { i64, ptr } { i64 2, ptr @.d115 }]
@.d105 = private constant [9 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr @.d109 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 11, ptr @.d111 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 14, ptr @.d112 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 20, ptr @.d113 }, { i64, ptr } { i64 3, ptr @.d120 }, { i64, ptr } { i64 1, ptr @.d121 }]
@.d106 = private constant [11 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr @.d109 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 11, ptr @.d111 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 14, ptr @.d112 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 20, ptr @.d113 }, { i64, ptr } { i64 6, ptr @.d114 }, { i64, ptr } { i64 2, ptr @.d115 }, { i64, ptr } { i64 2, ptr @.d117 }, { i64, ptr } { i64 1, ptr @.d122 }]
@.d107 = private constant [0 x i8] c""
@.d108 = private constant [0 x i8] c""
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d109 = private unnamed_addr constant [3 x i8] c"git"
@.d110 = private unnamed_addr constant [2 x i8] c"-c"
@.d111 = private unnamed_addr constant [11 x i8] c"user.name=t"
@.d112 = private unnamed_addr constant [14 x i8] c"user.email=t@t"
@.d113 = private unnamed_addr constant [20 x i8] c"commit.gpgsign=false"
@.d114 = private unnamed_addr constant [6 x i8] c"commit"
@.d115 = private unnamed_addr constant [2 x i8] c"-q"
@.d116 = private unnamed_addr constant [2 x i8] c"-a"
@.d117 = private unnamed_addr constant [2 x i8] c"-m"
@.d118 = private unnamed_addr constant [1 x i8] c"y"
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d119 = private unnamed_addr constant [4 x i8] c"init"
@.d120 = private unnamed_addr constant [3 x i8] c"add"
@.d121 = private unnamed_addr constant [1 x i8] c"."
@.d122 = private unnamed_addr constant [1 x i8] c"x"
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d3373a347b8bef1c_6787ad888ff53eb8 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2 = external constant [0 x i8]
@olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f = external constant [0 x i8]
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_45f2c25416d44418_72b8f662ae75c904 = external constant [0 x i8]
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_461a8d3078b45b75_287f37f9c7026b71 = external constant [0 x i8]
@olang_loc_64bbdb9c4083d73a_45ec4fce431b420e = external constant [0 x i8]
@olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_53ffa6078a05df97_cedcb09c0479edcb = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_6b88478e5ba0e6f6_911b45007093a98a = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_ba721b6722bc57b1_efdace1c8e747995 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_88b806f24688508b_997ec4238546bef7 = external constant [0 x i8]
declare i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0)
@olang_loc_123b76add1f6a034_48d214a7cc9ba878 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ee93546c87f9d64c_79e6a6f44e92448 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_456a27cc34a1957d_6cd35c881f48b5d9 = external constant [0 x i8]
@olang_loc_9013815812f03cb5_c1602845c5aedee9 = external constant [0 x i8]
@olang_loc_c9ab87d2c1341871_fd16dd2dcdcd2995 = external constant [0 x i8]
@olang_loc_c6873aa714579460_b40d85e54622baa4 = external constant [0 x i8]
@olang_loc_5d76ed62925a0d26_8e596c5fa04ecd8a = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
