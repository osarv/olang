; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
define dso_local { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d0, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t31 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) })
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l15
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35, !prof !99
ok.35:
  store { i64, ptr } %t32, ptr %l14
  br label %bb9
bb9:
  %t36 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t36, ptr %l13, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l13, !tbaa !27
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = extractvalue { i64, ptr } %t46, 0
  %t51 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = getelementptr i8, ptr %t54, i64 %t50
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t19, ptr %l8
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l10, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l15, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l15, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffetch_2eIsCommit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp ne i64 %t3, 40
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 64
  store i1 %t11, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l4, !tbaa !22
  %t37 = load i8, ptr %l4, !tbaa !22
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t37)
  store i1 %t39, ptr %l24
  br label %bb11
bb11:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb17
bb13:
  %t41 = load i8, ptr %l4, !tbaa !22
  %t43 = icmp uge i8 %t41, 97
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load i8, ptr %l4, !tbaa !22
  %t47 = icmp ule i8 %t45, 102
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l28, !tbaa !21
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t50 = load i1, ptr %l25, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb18, label %bb19
bb18:
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l2, !tbaa !24
  br label %bb7
bb22:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2eNamePart(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp eq i8 %t11, 46
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 0
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = icmp eq i8 %t20, 45
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t29 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } %t28)
  store i1 %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load i1, ptr %l20, !tbaa !21
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t33, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb15, label %bb16
bb15:
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i8, ptr %t51, i64 %t48
  %t53 = load i8, ptr %t52, !tbaa !32
  store i8 %t53, ptr %l4, !tbaa !22
  %t55 = load i8, ptr %l4, !tbaa !22
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t55)
  store i1 %t57, ptr %l33
  br label %bb18
bb18:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb22
bb20:
  %t59 = load i8, ptr %l4, !tbaa !22
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t59)
  store i1 %t61, ptr %l36
  br label %bb21
bb21:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb25
bb24:
  %t64 = load i8, ptr %l4, !tbaa !22
  %t66 = icmp eq i8 %t64, 46
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb28
bb27:
  %t69 = load i8, ptr %l4, !tbaa !22
  %t71 = icmp eq i8 %t69, 95
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb30:
  %t74 = load i8, ptr %l4, !tbaa !22
  %t76 = icmp eq i8 %t74, 45
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t78 = load i1, ptr %l43, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l2, !tbaa !24
  br label %bb14
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ecommitAgain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t41 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t36, { i64, ptr } %a2)
  store i32 %t41, ptr %l13
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb2, label %ok.43, !prof !99
ok.43:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t44 = load i32, ptr %l13, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  store i1 %t47, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %l17, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l18, !tbaa !24
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l19, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l18, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t62, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
bb4:
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t66 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t64, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x { i64, ptr }] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t66, ptr %l21
  br label %bb5
bb5:
  %t67 = load i1, ptr %l21, !tbaa !21
  br i1 %t67, label %bb6, label %bb7
bb6:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t72 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v3, { i64, ptr } %t70)
  store { i64, ptr } %t72, ptr %l25
  br label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t73, ptr %l23, !tbaa !27
  br label %bb9
bb8:
  %t75 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t75, ptr %l23, !tbaa !27
  br label %bb9
bb9:
  %t76 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l28, !tbaa !24
  %t78 = load i64, ptr %l28, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l29, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l28, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t89, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %lp15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %lp17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %lp21 = alloca ptr
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l79 = alloca i1
  %l81 = alloca i1
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l128 = alloca i64
  %l131 = alloca i1
  %l133 = alloca i1
  %l141 = alloca i1
  %l144 = alloca i32
  %l146 = alloca i1
  %l148 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i32
  %l153 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l170 = alloca { i64, ptr }
  %l171 = alloca i1
  %l172 = alloca i1
  %l176 = alloca { i64, ptr }
  %l177 = alloca i1
  %l178 = alloca i1
  %l180 = alloca { i64, ptr }
  %l181 = alloca i1
  %l185 = alloca i32
  %l187 = alloca i1
  %l190 = alloca { i64, ptr }
  %l191 = alloca i1
  %l194 = alloca { i64, ptr }
  %l195 = alloca i1
  %l197 = alloca { i64, ptr }
  %l200 = alloca i1
  %l203 = alloca i32
  %l205 = alloca i1
  %l208 = alloca i1
  %l212 = alloca i32
  %l214 = alloca i1
  %l216 = alloca i32
  %l218 = alloca i1
  %l221 = alloca i32
  %l223 = alloca i1
  %l234 = alloca { i64, ptr }
  %l239 = alloca i32
  %l241 = alloca i1
  %l242 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l244 = alloca i64
  %l245 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l250 = alloca i1
  %l252 = alloca { i64, ptr }
  %l254 = alloca i64
  %l257 = alloca i1
  %l259 = alloca i32
  %l261 = alloca i1
  %l267 = alloca i1
  %l269 = alloca i32
  %l271 = alloca i1
  %l274 = alloca i32
  %l276 = alloca i1
  %l278 = alloca i32
  %l280 = alloca i1
  %l289 = alloca i1
  %l291 = alloca i1
  %l293 = alloca i1
  %l294 = alloca ptr
  %l295 = alloca { i64, ptr }
  %l296 = alloca i64
  %l304 = alloca i1
  %l307 = alloca i1
  %l309 = alloca ptr
  %l310 = alloca { i64, ptr }
  %l311 = alloca i64
  %l315 = alloca { i64, ptr }
  %l316 = alloca i64
  %l324 = alloca ptr
  %l325 = alloca { i64, ptr }
  %l326 = alloca i64
  %s0 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v3, { i64, ptr } %t1, i8 64)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l26
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i64 %t5, ptr %l25
  br label %bb1
bb1:
  %t9 = load i64, ptr %l25, !tbaa !24
  store i64 %t9, ptr %l22, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l22, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l22, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l29, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l30, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l30, !tbaa !24
  %t22 = icmp sle i64 0, %t21
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb7:
  %t24 = load i64, ptr %l30, !tbaa !24
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  br i1 %t26, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l30, !tbaa !24
  %t31 = getelementptr i8, ptr %t29, i64 0
  %t32 = sub i64 %t30, 0
  %t33 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t36, %t39
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb11:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l41, !tbaa !27
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l43, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t48, 0
  store i64 %t51, ptr %l46, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l47, !tbaa !24
  %t54 = load i64, ptr %l43, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb12:
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t57, ptr %l52, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l54, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t61, 0
  store i64 %t64, ptr %l57, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l58, !tbaa !24
  %t67 = load i64, ptr %l54, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb19, label %bb20
bb13:
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = load i64, ptr %l46, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb15:
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l43, !tbaa !24
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l40, !tbaa !27
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb19:
  %t87 = load i64, ptr %l54, !tbaa !24
  %t88 = load i64, ptr %l57, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb21:
  %t91 = load i64, ptr %l57, !tbaa !24
  %t92 = load i64, ptr %l58, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb23:
  %t95 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l54, !tbaa !24
  %t98 = load i64, ptr %l57, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l40, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb25:
  %t104 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t104, ptr %l6, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2ffetch_2eNamePart(ptr %v1, { i64, ptr } %t105)
  store i1 %t107, ptr %l64
  br label %bb26
bb26:
  %t108 = load i1, ptr %l64, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t113 = call i1 @compiler_2ffetch_2eNamePart(ptr %v2, { i64, ptr } %t111)
  store i1 %t113, ptr %l68
  br label %bb29
bb29:
  %t114 = load i1, ptr %l68, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t117 = load i1, ptr %l66, !tbaa !21
  br i1 %t117, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb34
bb32:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t120 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t118)
  store i1 %t120, ptr %l72
  br label %bb33
bb33:
  %t121 = load i1, ptr %l72, !tbaa !21
  %t122 = xor i1 %t121, true
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb41
bb36:
  %t125 = load i64, ptr %l4, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t131 = icmp slt i64 %t125, %t128
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t133 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t135 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t133)
  store i1 %t135, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t136 = load i1, ptr %l81, !tbaa !21
  %t137 = xor i1 %t136, true
  store i1 %t137, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t139 = load i1, ptr %l79, !tbaa !21
  store i1 %t139, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t140 = load i1, ptr %l74, !tbaa !21
  br i1 %t140, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/fetch:Fetcher", ptr %t143, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l7, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t148, 1
  %t153 = extractvalue { i64, ptr } %t148, 0
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t149, 1
  %t159 = extractvalue { i64, ptr } %t149, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t165 = extractvalue { i64, ptr } %t150, 1
  %t166 = extractvalue { i64, ptr } %t150, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t152, i64 %t153)
  %t169 = getelementptr i8, ptr %t168, i64 %t153
  call void @olang_textcopy(ptr %t169, ptr %t154, i64 %t155)
  %t170 = getelementptr i8, ptr %t169, i64 %t155
  call void @olang_textcopy(ptr %t170, ptr %t158, i64 %t159)
  %t171 = getelementptr i8, ptr %t170, i64 %t159
  call void @olang_textcopy(ptr %t171, ptr %t161, i64 %t162)
  %t172 = getelementptr i8, ptr %t171, i64 %t162
  call void @olang_textcopy(ptr %t172, ptr %t165, i64 %t166)
  %t173 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t168, 1
  store { i64, ptr } %t174, ptr %l8, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/fetch:Fetcher", ptr %t176, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t179, 1
  %t185 = extractvalue { i64, ptr } %t179, 0
  %t187 = extractvalue { i64, ptr } %t180, 1
  %t188 = extractvalue { i64, ptr } %t180, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t194 = extractvalue { i64, ptr } %t181, 1
  %t195 = extractvalue { i64, ptr } %t181, 0
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t201 = extractvalue { i64, ptr } %t182, 1
  %t202 = extractvalue { i64, ptr } %t182, 0
  %t203 = add i64 %t199, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t184, i64 %t185)
  %t205 = getelementptr i8, ptr %t204, i64 %t185
  call void @olang_textcopy(ptr %t205, ptr %t187, i64 %t188)
  %t206 = getelementptr i8, ptr %t205, i64 %t188
  call void @olang_textcopy(ptr %t206, ptr %t190, i64 %t191)
  %t207 = getelementptr i8, ptr %t206, i64 %t191
  call void @olang_textcopy(ptr %t207, ptr %t194, i64 %t195)
  %t208 = getelementptr i8, ptr %t207, i64 %t195
  call void @olang_textcopy(ptr %t208, ptr %t197, i64 %t198)
  %t209 = getelementptr i8, ptr %t208, i64 %t198
  call void @olang_textcopy(ptr %t209, ptr %t201, i64 %t202)
  %t210 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t204, 1
  store { i64, ptr } %t211, ptr %l9, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t213, 1
  %t219 = extractvalue { i64, ptr } %t213, 0
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t222 = add i64 %t219, %t221
  %t224 = extractvalue { i64, ptr } %t214, 1
  %t225 = extractvalue { i64, ptr } %t214, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t231 = extractvalue { i64, ptr } %t215, 1
  %t232 = extractvalue { i64, ptr } %t215, 0
  %t233 = add i64 %t229, %t232
  %t234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t236 = add i64 %t233, %t235
  %t238 = extractvalue { i64, ptr } %t216, 1
  %t239 = extractvalue { i64, ptr } %t216, 0
  %t240 = add i64 %t236, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t218, i64 %t219)
  %t242 = getelementptr i8, ptr %t241, i64 %t219
  call void @olang_textcopy(ptr %t242, ptr %t220, i64 %t221)
  %t243 = getelementptr i8, ptr %t242, i64 %t221
  call void @olang_textcopy(ptr %t243, ptr %t224, i64 %t225)
  %t244 = getelementptr i8, ptr %t243, i64 %t225
  call void @olang_textcopy(ptr %t244, ptr %t227, i64 %t228)
  %t245 = getelementptr i8, ptr %t244, i64 %t228
  call void @olang_textcopy(ptr %t245, ptr %t231, i64 %t232)
  %t246 = getelementptr i8, ptr %t245, i64 %t232
  call void @olang_textcopy(ptr %t246, ptr %t234, i64 %t235)
  %t247 = getelementptr i8, ptr %t246, i64 %t235
  call void @olang_textcopy(ptr %t247, ptr %t238, i64 %t239)
  %t248 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t241, 1
  store { i64, ptr } %t249, ptr %l10, !tbaa !27
  store i1 true, ptr %l11, !tbaa !21
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t255 = call { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %s0, ptr %t251, { i64, ptr } %t252)
  %t256 = extractvalue { i32, { i64, ptr } } %t255, 1
  %t257 = extractvalue { i32, { i64, ptr } } %t255, 0
  store i32 %t257, ptr %l105
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb46, label %ok.259, !prof !99
ok.259:
  store { i64, ptr } %t256, ptr %l104
  br label %bb45
bb45:
  %t260 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t260, ptr %l101, !tbaa !27
  br label %bb48
bb46:
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l11, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l101, !tbaa !27
  br label %bb48
bb48:
  %t261 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t262, i64 %t263)
  %t265 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  store { i64, ptr } %t266, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l107, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t268, ptr %l108, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l109, !tbaa !24
  %t271 = load i64, ptr %l109, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l110, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l109, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t282, ptr %l13, !tbaa !27
  store i1 false, ptr %l14, !tbaa !21
  %t283 = load i1, ptr %l11, !tbaa !21
  br i1 %t283, label %bb49, label %bb50
bb49:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/fetch:Fetcher", ptr %t285, i32 0, i32 3
  %t288 = load i1, ptr %t287, !tbaa !21
  store i1 %t288, ptr %l112, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb51
bb51:
  %t290 = load i1, ptr %l112, !tbaa !21
  br i1 %t290, label %bb52, label %bb53
bb52:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t295 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %s0, ptr %t291, { i64, ptr } %t292, i1 false)
  store i1 %t295, ptr %l118
  br label %bb54
bb53:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb55
bb54:
  %t296 = load i1, ptr %l118, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l115, !tbaa !21
  br label %bb55
bb55:
  %t299 = load i1, ptr %l115, !tbaa !21
  br i1 %t299, label %bb56, label %bb57
bb56:
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t300)
  store i1 %t302, ptr %l121
  br label %bb58
bb57:
  br label %bb65
bb58:
  %t303 = load i1, ptr %l121, !tbaa !21
  br i1 %t303, label %bb59, label %bb60
bb59:
  %t304 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 1
  %t307 = extractvalue { i64, ptr } %t304, 0
  %t308 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t306, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l122, !tbaa !27
  br label %bb61
bb60:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l125, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t312, ptr %l122, !tbaa !27
  br label %bb61
bb61:
  %t314 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 0
  %t316 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l128, !tbaa !24
  %t319 = load i64, ptr %l128, !tbaa !24
  %t320 = icmp eq i64 %t315, %t319
  br i1 %t320, label %bb62, label %bb63
bb62:
  %t322 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = load i64, ptr %l128, !tbaa !24
  %t327 = mul i64 %t326, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t323, ptr %t325, i64 %t327, i1 false)
  br label %bb64
bb63:
  %t328 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t328, ptr %l13, !tbaa !27
  br label %bb64
bb64:
  store i1 true, ptr %l14, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  br label %bb65
bb65:
  %t329 = load i1, ptr %l11, !tbaa !21
  br i1 %t329, label %bb66, label %bb67
bb66:
  %t331 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t333 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t331)
  store i1 %t333, ptr %l133
  br label %bb68
bb67:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb69
bb68:
  %t334 = load i1, ptr %l133, !tbaa !21
  %t335 = xor i1 %t334, true
  store i1 %t335, ptr %l131, !tbaa !21
  br label %bb69
bb69:
  %t337 = load i1, ptr %l131, !tbaa !21
  br i1 %t337, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t339 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65537, 0
  store { i32, { i64, ptr } } %t339, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t340 = load i1, ptr %l11, !tbaa !21
  br i1 %t340, label %bb73, label %bb74
bb73:
  %t342 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t342, 1
  %t346 = extractvalue { i64, ptr } %t342, 0
  %t347 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t349 = add i64 %t346, %t348
  %t351 = extractvalue { i64, ptr } %t343, 1
  %t352 = extractvalue { i64, ptr } %t343, 0
  %t353 = add i64 %t349, %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t353)
  call void @olang_textcopy(ptr %t354, ptr %t345, i64 %t346)
  %t355 = getelementptr i8, ptr %t354, i64 %t346
  call void @olang_textcopy(ptr %t355, ptr %t347, i64 %t348)
  %t356 = getelementptr i8, ptr %t355, i64 %t348
  call void @olang_textcopy(ptr %t356, ptr %t351, i64 %t352)
  %t357 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t354, 1
  %t359 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t359, ptr %lp15
  %t361 = load ptr, ptr %lp15
  store { i64, ptr } %t358, ptr %t361, !tbaa !27
  %t362 = load ptr, ptr %lp15
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  %t365 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t363)
  store i1 %t365, ptr %l141
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t366 = load i1, ptr %l141, !tbaa !21
  br i1 %t366, label %bb76, label %bb77
bb76:
  %t367 = load ptr, ptr %lp15
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t370 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t368, 1
  store { i32, { i64, ptr } } %t370, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t371 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t373 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t371)
  store i32 %t373, ptr %l144
  %t374 = icmp ne i32 %t373, 0
  br i1 %t374, label %bb81, label %ok.375, !prof !99
ok.375:
  br label %bb80
bb80:
  br label %bb83
bb81:
  %t376 = load i32, ptr %l144, !tbaa !23
  %t377 = ashr i32 %t376, 16
  %t379 = icmp eq i32 %t377, 1
  store i1 %t379, ptr %l146, !tbaa !21
  br label %bb82
bb82:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t381 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t381, ptr %rv
  br label %ret
bb83:
  %t382 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t384 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t382, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d23, i32 0, i32 1) })
  %t385 = extractvalue { i32, { i64, ptr } } %t384, 1
  %t386 = extractvalue { i32, { i64, ptr } } %t384, 0
  store i32 %t386, ptr %l151
  %t387 = icmp ne i32 %t386, 0
  br i1 %t387, label %bb85, label %ok.388, !prof !99
ok.388:
  store { i64, ptr } %t385, ptr %l150
  br label %bb84
bb84:
  %t389 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t389, ptr %l148, !tbaa !27
  br label %bb87
bb85:
  %t390 = load i32, ptr %l151, !tbaa !23
  %t391 = ashr i32 %t390, 16
  %t393 = icmp eq i32 %t391, 1
  store i1 %t393, ptr %l153, !tbaa !21
  br label %bb86
bb86:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t395 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t395, ptr %rv
  br label %ret
bb87:
  %t396 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t396, ptr %l16, !tbaa !27
  %t397 = load i1, ptr %l11, !tbaa !21
  br i1 %t397, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s15
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l156, !tbaa !29
  %t400 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t400, ptr %l157, !tbaa !27
  %t401 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t401, ptr %l158, !tbaa !27
  %t402 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t402, 0
  store i64 %t403, ptr %l159, !tbaa !24
  %t404 = icmp sge i64 0, 0
  br i1 %t404, label %bb90, label %bb91
bb89:
  br label %bb143
bb90:
  %t406 = icmp sle i64 0, 12
  br i1 %t406, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb92:
  %t408 = load i64, ptr %l159, !tbaa !24
  %t409 = icmp sle i64 12, %t408
  br i1 %t409, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb94:
  %t411 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr i8, ptr %t412, i64 0
  %t414 = sub i64 12, 0
  %t415 = insertvalue { i64, ptr } undef, i64 %t414, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t413, 1
  %t417 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t419 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 1
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t422 = add i64 %t418, %t421
  %t423 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t424 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t425 = add i64 %t422, %t424
  %t426 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t426, 1
  %t428 = extractvalue { i64, ptr } %t426, 0
  %t429 = add i64 %t425, %t428
  %t430 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t431 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t432 = add i64 %t429, %t431
  %t434 = extractvalue { i64, ptr } %t416, 1
  %t435 = extractvalue { i64, ptr } %t416, 0
  %t436 = add i64 %t432, %t435
  %t437 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t439 = add i64 %t436, %t438
  %t440 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t439)
  call void @olang_textcopy(ptr %t440, ptr %t417, i64 %t418)
  %t441 = getelementptr i8, ptr %t440, i64 %t418
  call void @olang_textcopy(ptr %t441, ptr %t420, i64 %t421)
  %t442 = getelementptr i8, ptr %t441, i64 %t421
  call void @olang_textcopy(ptr %t442, ptr %t423, i64 %t424)
  %t443 = getelementptr i8, ptr %t442, i64 %t424
  call void @olang_textcopy(ptr %t443, ptr %t427, i64 %t428)
  %t444 = getelementptr i8, ptr %t443, i64 %t428
  call void @olang_textcopy(ptr %t444, ptr %t430, i64 %t431)
  %t445 = getelementptr i8, ptr %t444, i64 %t431
  call void @olang_textcopy(ptr %t445, ptr %t434, i64 %t435)
  %t446 = getelementptr i8, ptr %t445, i64 %t435
  call void @olang_textcopy(ptr %t446, ptr %t437, i64 %t438)
  %t447 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t448 = insertvalue { i64, ptr } %t447, ptr %t440, 1
  %t450 = extractvalue { i64, ptr } %t448, 0
  %t451 = extractvalue { i64, ptr } %t448, 1
  %t452 = mul i64 %t450, 1
  %t453 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t452)
  call void @llvm.memcpy.p0.p0.i64(ptr %t453, ptr %t451, i64 %t452, i1 false)
  %t454 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t453, 1
  %t456 = load ptr, ptr %l156, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s15, ptr %t456, { i64, ptr } %t455)
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb96:
  %t458 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t459 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t458, 1
  %t462 = extractvalue { i64, ptr } %t458, 0
  %t463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t465 = add i64 %t462, %t464
  %t467 = extractvalue { i64, ptr } %t459, 1
  %t468 = extractvalue { i64, ptr } %t459, 0
  %t469 = add i64 %t465, %t468
  %t470 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t469)
  call void @olang_textcopy(ptr %t470, ptr %t461, i64 %t462)
  %t471 = getelementptr i8, ptr %t470, i64 %t462
  call void @olang_textcopy(ptr %t471, ptr %t463, i64 %t464)
  %t472 = getelementptr i8, ptr %t471, i64 %t464
  call void @olang_textcopy(ptr %t472, ptr %t467, i64 %t468)
  %t473 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t470, 1
  %t475 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t475, ptr %lp17
  %t477 = load ptr, ptr %lp17
  store { i64, ptr } %t474, ptr %t477, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t479 = mul i64 4, 16
  %t480 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t479)
  %t481 = insertvalue { i64, ptr } undef, i64 4, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  store { i64, ptr } %t482, ptr %l170, !tbaa !27
  %t483 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t484 = load ptr, ptr %t483, !tbaa !27
  %t485 = getelementptr { i64, ptr }, ptr %t484, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %t485, !tbaa !37
  %t486 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t487 = load ptr, ptr %t486, !tbaa !27
  %t488 = getelementptr { i64, ptr }, ptr %t487, i64 1
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %t488, !tbaa !37
  %t489 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr { i64, ptr }, ptr %t490, i64 2
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t491, !tbaa !37
  %t493 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr { i64, ptr }, ptr %t494, i64 3
  store { i64, ptr } %t478, ptr %t495, !tbaa !37
  %t496 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t497 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t496)
  store i1 %t497, ptr %l171
  br label %bb97
bb97:
  %t498 = load i1, ptr %l171, !tbaa !21
  br i1 %t498, label %bb98, label %bb99
bb98:
  %t499 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t500 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t501 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t502 = mul i64 10, 16
  %t503 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t502)
  %t504 = insertvalue { i64, ptr } undef, i64 10, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t503, 1
  store { i64, ptr } %t505, ptr %l176, !tbaa !27
  %t506 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr { i64, ptr }, ptr %t507, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t508, !tbaa !37
  %t509 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !27
  %t511 = getelementptr { i64, ptr }, ptr %t510, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t511, !tbaa !37
  %t513 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = getelementptr { i64, ptr }, ptr %t514, i64 2
  store { i64, ptr } %t499, ptr %t515, !tbaa !37
  %t516 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t517 = load ptr, ptr %t516, !tbaa !27
  %t518 = getelementptr { i64, ptr }, ptr %t517, i64 3
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t518, !tbaa !37
  %t519 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr { i64, ptr }, ptr %t520, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t521, !tbaa !37
  %t522 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t523 = load ptr, ptr %t522, !tbaa !27
  %t524 = getelementptr { i64, ptr }, ptr %t523, i64 5
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t524, !tbaa !37
  %t525 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = getelementptr { i64, ptr }, ptr %t526, i64 6
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t527, !tbaa !37
  %t528 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !27
  %t530 = getelementptr { i64, ptr }, ptr %t529, i64 7
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t530, !tbaa !37
  %t532 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !27
  %t534 = getelementptr { i64, ptr }, ptr %t533, i64 8
  store { i64, ptr } %t500, ptr %t534, !tbaa !37
  %t536 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = getelementptr { i64, ptr }, ptr %t537, i64 9
  store { i64, ptr } %t501, ptr %t538, !tbaa !37
  %t539 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t540 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t539)
  store i1 %t540, ptr %l177
  br label %bb100
bb99:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb101
bb100:
  %t541 = load i1, ptr %l177, !tbaa !21
  store i1 %t541, ptr %l172, !tbaa !21
  br label %bb101
bb101:
  %t542 = load i1, ptr %l172, !tbaa !21
  br i1 %t542, label %bb102, label %bb103
bb102:
  %t543 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t544 = mul i64 6, 16
  %t545 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t544)
  %t546 = insertvalue { i64, ptr } undef, i64 6, 0
  %t547 = insertvalue { i64, ptr } %t546, ptr %t545, 1
  store { i64, ptr } %t547, ptr %l180, !tbaa !27
  %t548 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = getelementptr { i64, ptr }, ptr %t549, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t550, !tbaa !37
  %t551 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr { i64, ptr }, ptr %t552, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t553, !tbaa !37
  %t555 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr { i64, ptr }, ptr %t556, i64 2
  store { i64, ptr } %t543, ptr %t557, !tbaa !37
  %t558 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !27
  %t560 = getelementptr { i64, ptr }, ptr %t559, i64 3
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t560, !tbaa !37
  %t561 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = getelementptr { i64, ptr }, ptr %t562, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t563, !tbaa !37
  %t564 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = getelementptr { i64, ptr }, ptr %t565, i64 5
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t566, !tbaa !37
  %t567 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t568 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t567)
  store i1 %t568, ptr %l181
  br label %bb104
bb103:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb105
bb104:
  %t569 = load i1, ptr %l181, !tbaa !21
  store i1 %t569, ptr %l178, !tbaa !21
  br label %bb105
bb105:
  %t570 = load i1, ptr %l178, !tbaa !21
  %t573 = xor i1 %t570, true
  br i1 %t573, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s18
  %t575 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t577 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t575)
  store i32 %t577, ptr %l185
  %t578 = icmp ne i32 %t577, 0
  br i1 %t578, label %bb109, label %ok.579, !prof !99
ok.579:
  br label %bb108
bb107:
  br label %bb117
bb108:
  br label %bb111
bb109:
  %t580 = load i32, ptr %l185, !tbaa !23
  %t581 = ashr i32 %t580, 16
  %t583 = icmp eq i32 %t581, 1
  store i1 %t583, ptr %l187, !tbaa !21
  br label %bb110
bb110:
  call void @__olang_ert_req_clear()
  br label %bb111
bb111:
  %t584 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t585 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t586 = mul i64 6, 16
  %t587 = call ptr @__olang_scope_alloc_zeroed(ptr %s18, i64 %t586)
  %t588 = insertvalue { i64, ptr } undef, i64 6, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  store { i64, ptr } %t589, ptr %l190, !tbaa !27
  %t590 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr { i64, ptr }, ptr %t591, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t592, !tbaa !37
  %t593 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr { i64, ptr }, ptr %t594, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t595, !tbaa !37
  %t596 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !27
  %t598 = getelementptr { i64, ptr }, ptr %t597, i64 2
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %t598, !tbaa !37
  %t599 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = getelementptr { i64, ptr }, ptr %t600, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %t601, !tbaa !37
  %t603 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t604 = load ptr, ptr %t603, !tbaa !27
  %t605 = getelementptr { i64, ptr }, ptr %t604, i64 4
  store { i64, ptr } %t584, ptr %t605, !tbaa !37
  %t607 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = getelementptr { i64, ptr }, ptr %t608, i64 5
  store { i64, ptr } %t585, ptr %t609, !tbaa !37
  %t610 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t611 = call i1 @compiler_2ffetch_2egit(ptr %s18, { i64, ptr } %t610)
  store i1 %t611, ptr %l191
  br label %bb112
bb112:
  %t612 = load i1, ptr %l191, !tbaa !21
  br i1 %t612, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s20
  %t613 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t615 = mul i64 6, 16
  %t616 = call ptr @__olang_scope_alloc_zeroed(ptr %s20, i64 %t615)
  %t617 = insertvalue { i64, ptr } undef, i64 6, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t616, 1
  store { i64, ptr } %t618, ptr %l194, !tbaa !27
  %t619 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t620 = load ptr, ptr %t619, !tbaa !27
  %t621 = getelementptr { i64, ptr }, ptr %t620, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t621, !tbaa !37
  %t622 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t623 = load ptr, ptr %t622, !tbaa !27
  %t624 = getelementptr { i64, ptr }, ptr %t623, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t624, !tbaa !37
  %t626 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !27
  %t628 = getelementptr { i64, ptr }, ptr %t627, i64 2
  store { i64, ptr } %t613, ptr %t628, !tbaa !37
  %t629 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = getelementptr { i64, ptr }, ptr %t630, i64 3
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t631, !tbaa !37
  %t632 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !27
  %t634 = getelementptr { i64, ptr }, ptr %t633, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t634, !tbaa !37
  %t636 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t637 = load ptr, ptr %t636, !tbaa !27
  %t638 = getelementptr { i64, ptr }, ptr %t637, i64 5
  store { i64, ptr } %t614, ptr %t638, !tbaa !37
  %t639 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t640 = call i1 @compiler_2ffetch_2egit(ptr %s20, { i64, ptr } %t639)
  store i1 %t640, ptr %l195
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s20)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s18)
  br label %bb117
bb117:
  %t641 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t643 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s15, { i64, ptr } %t641)
  store { i64, ptr } %t643, ptr %l197
  br label %bb118
bb118:
  %t644 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t644, 0
  %t646 = extractvalue { i64, ptr } %t644, 1
  %t647 = mul i64 %t645, 1
  %t648 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t647)
  call void @llvm.memcpy.p0.p0.i64(ptr %t648, ptr %t646, i64 %t647, i1 false)
  %t649 = insertvalue { i64, ptr } undef, i64 %t645, 0
  %t650 = insertvalue { i64, ptr } %t649, ptr %t648, 1
  %t651 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t654 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s0, { i64, ptr } %t650, { i64, ptr } %t651)
  store i1 %t654, ptr %l200
  br label %bb119
bb119:
  %t655 = load i1, ptr %l200, !tbaa !21
  %t656 = xor i1 %t655, true
  br i1 %t656, label %bb120, label %bb121
bb120:
  %t658 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t660 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t658)
  store i32 %t660, ptr %l203
  %t661 = icmp ne i32 %t660, 0
  br i1 %t661, label %bb123, label %ok.662, !prof !99
ok.662:
  br label %bb122
bb121:
  br label %bb126
bb122:
  br label %bb125
bb123:
  %t663 = load i32, ptr %l203, !tbaa !23
  %t664 = ashr i32 %t663, 16
  %t666 = icmp eq i32 %t664, 1
  store i1 %t666, ptr %l205, !tbaa !21
  br label %bb124
bb124:
  call void @__olang_ert_req_clear()
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t668 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65539, 0
  store { i32, { i64, ptr } } %t668, ptr %rv
  br label %ret
bb126:
  %t669 = load ptr, ptr %lp17
  %t670 = load { i64, ptr }, ptr %t669, !tbaa !27
  %t672 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t670)
  store i1 %t672, ptr %l208
  br label %bb127
bb127:
  %t673 = load i1, ptr %l208, !tbaa !21
  %t674 = xor i1 %t673, true
  br i1 %t674, label %bb128, label %bb129
bb128:
  %t676 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t677 = load ptr, ptr %lp17
  %t678 = load { i64, ptr }, ptr %t677, !tbaa !27
  %t681 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t676, { i64, ptr } %t678)
  store i32 %t681, ptr %l212
  %t682 = icmp ne i32 %t681, 0
  br i1 %t682, label %bb131, label %ok.683, !prof !99
ok.683:
  br label %bb130
bb129:
  br label %bb138
bb130:
  br label %bb137
bb131:
  %t684 = load i32, ptr %l212, !tbaa !23
  %t685 = ashr i32 %t684, 16
  %t687 = icmp eq i32 %t685, 1
  store i1 %t687, ptr %l214, !tbaa !21
  br label %bb132
bb132:
  call void @__olang_ert_req_clear()
  %t688 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t690 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t688)
  store i32 %t690, ptr %l216
  %t691 = icmp ne i32 %t690, 0
  br i1 %t691, label %bb134, label %ok.692, !prof !99
ok.692:
  br label %bb133
bb133:
  br label %bb136
bb134:
  %t693 = load i32, ptr %l216, !tbaa !23
  %t694 = ashr i32 %t693, 16
  %t696 = icmp eq i32 %t694, 1
  store i1 %t696, ptr %l218, !tbaa !21
  br label %bb135
bb135:
  call void @__olang_ert_req_clear()
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t698 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65539, 0
  store { i32, { i64, ptr } } %t698, ptr %rv
  br label %ret
bb137:
  br label %bb138
bb138:
  %t699 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t701 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t699)
  store i32 %t701, ptr %l221
  %t702 = icmp ne i32 %t701, 0
  br i1 %t702, label %bb140, label %ok.703, !prof !99
ok.703:
  br label %bb139
bb139:
  br label %bb142
bb140:
  %t704 = load i32, ptr %l221, !tbaa !23
  %t705 = ashr i32 %t704, 16
  %t707 = icmp eq i32 %t705, 1
  store i1 %t707, ptr %l223, !tbaa !21
  br label %bb141
bb141:
  call void @__olang_ert_req_clear()
  br label %bb142
bb142:
  %t708 = load ptr, ptr %lp17
  %t709 = load { i64, ptr }, ptr %t708, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t711 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t709, 1
  store { i32, { i64, ptr } } %t711, ptr %rv
  br label %ret
bb143:
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t713 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t714 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t715 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t718 = extractvalue { i64, ptr } %t713, 1
  %t719 = extractvalue { i64, ptr } %t713, 0
  %t720 = add i64 %t716, %t719
  %t721 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t722 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t723 = add i64 %t720, %t722
  %t725 = extractvalue { i64, ptr } %t714, 1
  %t726 = extractvalue { i64, ptr } %t714, 0
  %t727 = add i64 %t723, %t726
  %t728 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t727)
  call void @olang_textcopy(ptr %t728, ptr %t715, i64 %t716)
  %t729 = getelementptr i8, ptr %t728, i64 %t716
  call void @olang_textcopy(ptr %t729, ptr %t718, i64 %t719)
  %t730 = getelementptr i8, ptr %t729, i64 %t719
  call void @olang_textcopy(ptr %t730, ptr %t721, i64 %t722)
  %t731 = getelementptr i8, ptr %t730, i64 %t722
  call void @olang_textcopy(ptr %t731, ptr %t725, i64 %t726)
  %t732 = insertvalue { i64, ptr } undef, i64 %t727, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t728, 1
  %t735 = extractvalue { i64, ptr } %t733, 0
  %t736 = extractvalue { i64, ptr } %t733, 1
  %t737 = mul i64 %t735, 1
  %t738 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t737)
  call void @llvm.memcpy.p0.p0.i64(ptr %t738, ptr %t736, i64 %t737, i1 false)
  %t739 = insertvalue { i64, ptr } undef, i64 %t735, 0
  %t740 = insertvalue { i64, ptr } %t739, ptr %t738, 1
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s0, ptr %t712, { i64, ptr } %t740)
  br label %bb144
bb144:
  %t743 = load i64, ptr %l4, !tbaa !24
  %t744 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t746 = extractvalue { i64, ptr } %t744, 0
  %t749 = icmp slt i64 %t743, %t746
  br i1 %t749, label %bb145, label %bb146
bb145:
  %t751 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t752 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t753 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t755 = extractvalue { i64, ptr } %t751, 1
  %t756 = extractvalue { i64, ptr } %t751, 0
  %t757 = add i64 %t753, %t756
  %t758 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t757)
  call void @olang_textcopy(ptr %t758, ptr %t752, i64 %t753)
  %t759 = getelementptr i8, ptr %t758, i64 %t753
  call void @olang_textcopy(ptr %t759, ptr %t755, i64 %t756)
  %t760 = insertvalue { i64, ptr } undef, i64 %t757, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t758, 1
  %t763 = extractvalue { i64, ptr } %t761, 0
  %t764 = extractvalue { i64, ptr } %t761, 1
  %t765 = mul i64 %t763, 1
  %t766 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t765)
  call void @llvm.memcpy.p0.p0.i64(ptr %t766, ptr %t764, i64 %t765, i1 false)
  %t767 = insertvalue { i64, ptr } undef, i64 %t763, 0
  %t768 = insertvalue { i64, ptr } %t767, ptr %t766, 1
  store { i64, ptr } %t768, ptr %l234, !tbaa !27
  br label %bb147
bb146:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l234, !tbaa !27
  br label %bb147
bb147:
  %t770 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t770, ptr %l19, !tbaa !27
  %t771 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t773 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t771)
  store i32 %t773, ptr %l239
  %t774 = icmp ne i32 %t773, 0
  br i1 %t774, label %bb149, label %ok.775, !prof !99
ok.775:
  br label %bb148
bb148:
  br label %bb151
bb149:
  %t776 = load i32, ptr %l239, !tbaa !23
  %t777 = ashr i32 %t776, 16
  %t779 = icmp eq i32 %t777, 1
  store i1 %t779, ptr %l241, !tbaa !21
  br label %bb150
bb150:
  call void @__olang_ert_req_clear()
  br label %bb151
bb151:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l242, !tbaa !27
  %t780 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t780, ptr %l243, !tbaa !27
  %t781 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t782 = extractvalue { i64, ptr } %t781, 0
  store i64 %t782, ptr %l244, !tbaa !24
  %t783 = load i64, ptr %l244, !tbaa !24
  %t784 = mul i64 %t783, 1
  %t785 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t784)
  %t786 = insertvalue { i64, ptr } undef, i64 %t783, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t785, 1
  store { i64, ptr } %t787, ptr %l245, !tbaa !27
  %t788 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t789 = load ptr, ptr %t788, !tbaa !27
  %t790 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t791 = load ptr, ptr %t790, !tbaa !27
  %t792 = load i64, ptr %l244, !tbaa !24
  %t793 = mul i64 %t792, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t789, ptr %t791, i64 %t793, i1 false)
  %t794 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t794, ptr %l20, !tbaa !27
  %t795 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t796 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t797 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t798 = mul i64 9, 16
  %t799 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t798)
  %t800 = insertvalue { i64, ptr } undef, i64 9, 0
  %t801 = insertvalue { i64, ptr } %t800, ptr %t799, 1
  store { i64, ptr } %t801, ptr %l249, !tbaa !27
  %t802 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t803 = load ptr, ptr %t802, !tbaa !27
  %t804 = getelementptr { i64, ptr }, ptr %t803, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %t804, !tbaa !37
  %t805 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t806 = load ptr, ptr %t805, !tbaa !27
  %t807 = getelementptr { i64, ptr }, ptr %t806, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %t807, !tbaa !37
  %t808 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t809 = load ptr, ptr %t808, !tbaa !27
  %t810 = getelementptr { i64, ptr }, ptr %t809, i64 2
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %t810, !tbaa !37
  %t811 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t812 = load ptr, ptr %t811, !tbaa !27
  %t813 = getelementptr { i64, ptr }, ptr %t812, i64 3
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %t813, !tbaa !37
  %t814 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t815 = load ptr, ptr %t814, !tbaa !27
  %t816 = getelementptr { i64, ptr }, ptr %t815, i64 4
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %t816, !tbaa !37
  %t818 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t819 = load ptr, ptr %t818, !tbaa !27
  %t820 = getelementptr { i64, ptr }, ptr %t819, i64 5
  store { i64, ptr } %t795, ptr %t820, !tbaa !37
  %t821 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t822 = load ptr, ptr %t821, !tbaa !27
  %t823 = getelementptr { i64, ptr }, ptr %t822, i64 6
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %t823, !tbaa !37
  %t825 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t826 = load ptr, ptr %t825, !tbaa !27
  %t827 = getelementptr { i64, ptr }, ptr %t826, i64 7
  store { i64, ptr } %t796, ptr %t827, !tbaa !37
  %t829 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t830 = load ptr, ptr %t829, !tbaa !27
  %t831 = getelementptr { i64, ptr }, ptr %t830, i64 8
  store { i64, ptr } %t797, ptr %t831, !tbaa !37
  %t832 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t833 = call i1 @compiler_2ffetch_2egit(ptr %s0, { i64, ptr } %t832)
  store i1 %t833, ptr %l250
  br label %bb152
bb152:
  %t834 = load i1, ptr %l250, !tbaa !21
  br i1 %t834, label %bb153, label %bb154
bb153:
  %t835 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t837 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s0, { i64, ptr } %t835)
  store { i64, ptr } %t837, ptr %l252
  br label %bb155
bb154:
  br label %bb159
bb155:
  %t838 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t839 = extractvalue { i64, ptr } %t838, 0
  %t840 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t840, 0
  store i64 %t841, ptr %l254, !tbaa !24
  %t843 = load i64, ptr %l254, !tbaa !24
  %t844 = icmp eq i64 %t839, %t843
  br i1 %t844, label %bb156, label %bb157
bb156:
  %t846 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t847 = load ptr, ptr %t846, !tbaa !27
  %t848 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t849 = load ptr, ptr %t848, !tbaa !27
  %t850 = load i64, ptr %l254, !tbaa !24
  %t851 = mul i64 %t850, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t847, ptr %t849, i64 %t851, i1 false)
  br label %bb158
bb157:
  %t852 = load { i64, ptr }, ptr %l252, !tbaa !27
  store { i64, ptr } %t852, ptr %l20, !tbaa !27
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t853 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t855 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t853, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t855, ptr %l257
  br label %bb160
bb160:
  %t856 = load i1, ptr %l257, !tbaa !21
  br i1 %t856, label %bb161, label %bb162
bb161:
  %t857 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t859 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t857)
  store i32 %t859, ptr %l259
  %t860 = icmp ne i32 %t859, 0
  br i1 %t860, label %bb164, label %ok.861, !prof !99
ok.861:
  br label %bb163
bb162:
  br label %bb167
bb163:
  br label %bb166
bb164:
  %t862 = load i32, ptr %l259, !tbaa !23
  %t863 = ashr i32 %t862, 16
  %t865 = icmp eq i32 %t863, 1
  store i1 %t865, ptr %l261, !tbaa !21
  br label %bb165
bb165:
  call void @__olang_ert_req_clear()
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s0)
  %t867 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t867, ptr %rv
  br label %ret
bb167:
  %t868 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t869 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t871 = extractvalue { i64, ptr } %t868, 1
  %t872 = extractvalue { i64, ptr } %t868, 0
  %t873 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t874 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t875 = add i64 %t872, %t874
  %t877 = extractvalue { i64, ptr } %t869, 1
  %t878 = extractvalue { i64, ptr } %t869, 0
  %t879 = add i64 %t875, %t878
  %t880 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t879)
  call void @olang_textcopy(ptr %t880, ptr %t871, i64 %t872)
  %t881 = getelementptr i8, ptr %t880, i64 %t872
  call void @olang_textcopy(ptr %t881, ptr %t873, i64 %t874)
  %t882 = getelementptr i8, ptr %t881, i64 %t874
  call void @olang_textcopy(ptr %t882, ptr %t877, i64 %t878)
  %t883 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t884 = insertvalue { i64, ptr } %t883, ptr %t880, 1
  %t885 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t885, ptr %lp21
  %t887 = load ptr, ptr %lp21
  store { i64, ptr } %t884, ptr %t887, !tbaa !27
  %t888 = load ptr, ptr %lp21
  %t889 = load { i64, ptr }, ptr %t888, !tbaa !27
  %t891 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t889)
  store i1 %t891, ptr %l267
  br label %bb168
bb168:
  %t892 = load i1, ptr %l267, !tbaa !21
  br i1 %t892, label %bb169, label %bb170
bb169:
  %t893 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t895 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t893)
  store i32 %t895, ptr %l269
  %t896 = icmp ne i32 %t895, 0
  br i1 %t896, label %bb172, label %ok.897, !prof !99
ok.897:
  br label %bb171
bb170:
  %t898 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t899 = load ptr, ptr %lp21
  %t900 = load { i64, ptr }, ptr %t899, !tbaa !27
  %t903 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t898, { i64, ptr } %t900)
  store i32 %t903, ptr %l274
  %t904 = icmp ne i32 %t903, 0
  br i1 %t904, label %bb176, label %ok.905, !prof !99
ok.905:
  br label %bb175
bb171:
  br label %bb174
bb172:
  %t906 = load i32, ptr %l269, !tbaa !23
  %t907 = ashr i32 %t906, 16
  %t909 = icmp eq i32 %t907, 1
  store i1 %t909, ptr %l271, !tbaa !21
  br label %bb173
bb173:
  call void @__olang_ert_req_clear()
  br label %bb174
bb174:
  br label %bb183
bb175:
  br label %bb182
bb176:
  %t910 = load i32, ptr %l274, !tbaa !23
  %t911 = ashr i32 %t910, 16
  %t913 = icmp eq i32 %t911, 1
  store i1 %t913, ptr %l276, !tbaa !21
  br label %bb177
bb177:
  call void @__olang_ert_req_clear()
  %t914 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t916 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t914)
  store i32 %t916, ptr %l278
  %t917 = icmp ne i32 %t916, 0
  br i1 %t917, label %bb179, label %ok.918, !prof !99
ok.918:
  br label %bb178
bb178:
  br label %bb181
bb179:
  %t919 = load i32, ptr %l278, !tbaa !23
  %t920 = ashr i32 %t919, 16
  %t922 = icmp eq i32 %t920, 1
  store i1 %t922, ptr %l280, !tbaa !21
  br label %bb180
bb180:
  call void @__olang_ert_req_clear()
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s0)
  %t924 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t924, ptr %rv
  br label %ret
bb182:
  br label %bb183
bb183:
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t926 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t927 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %s0, ptr %s0, ptr %t925, { i64, ptr } %t926, { i64, ptr } %t927)
  br label %bb184
bb184:
  %t931 = load ptr, ptr %l0, !tbaa !29
  %t933 = getelementptr %"compiler/fetch:Fetcher", ptr %t931, i32 0, i32 3
  %t934 = load i1, ptr %t933, !tbaa !21
  br i1 %t934, label %bb185, label %bb186
bb185:
  store %olang.scope zeroinitializer, ptr %s39
  %t936 = load ptr, ptr %l0, !tbaa !29
  %t937 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t940 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %s0, ptr %t936, { i64, ptr } %t937, i1 true)
  store i1 %t940, ptr %l289
  br label %bb187
bb186:
  br label %bb232
bb187:
  %t941 = load i1, ptr %l14, !tbaa !21
  br i1 %t941, label %bb188, label %bb189
bb188:
  %t943 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t945 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t943, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t945, ptr %l293
  br label %bb190
bb189:
  store i1 false, ptr %l291, !tbaa !21
  br label %bb191
bb190:
  %t946 = load i1, ptr %l293, !tbaa !21
  store i1 %t946, ptr %l291, !tbaa !21
  br label %bb191
bb191:
  %t947 = load i1, ptr %l291, !tbaa !21
  br i1 %t947, label %bb192, label %bb193
bb192:
  store %olang.scope zeroinitializer, ptr %s40
  %t948 = load ptr, ptr %l0, !tbaa !29
  store ptr %t948, ptr %l294, !tbaa !29
  %t949 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t949, ptr %l295, !tbaa !27
  %t950 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t951 = extractvalue { i64, ptr } %t950, 0
  store i64 %t951, ptr %l296, !tbaa !24
  %t952 = icmp sge i64 0, 0
  br i1 %t952, label %bb194, label %bb195
bb193:
  %t954 = load i1, ptr %l14, !tbaa !21
  br i1 %t954, label %bb201, label %bb202
bb194:
  %t956 = icmp sle i64 0, 12
  br i1 %t956, label %bb196, label %bb197
bb195:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb196:
  %t958 = load i64, ptr %l296, !tbaa !24
  %t959 = icmp sle i64 12, %t958
  br i1 %t959, label %bb198, label %bb199
bb197:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb198:
  %t961 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t962 = load ptr, ptr %t961, !tbaa !27
  %t963 = getelementptr i8, ptr %t962, i64 0
  %t964 = sub i64 12, 0
  %t965 = insertvalue { i64, ptr } undef, i64 %t964, 0
  %t966 = insertvalue { i64, ptr } %t965, ptr %t963, 1
  %t967 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t968 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t969 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t970 = extractvalue { i64, ptr } %t969, 1
  %t971 = extractvalue { i64, ptr } %t969, 0
  %t972 = add i64 %t968, %t971
  %t973 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t974 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t975 = add i64 %t972, %t974
  %t977 = extractvalue { i64, ptr } %t966, 1
  %t978 = extractvalue { i64, ptr } %t966, 0
  %t979 = add i64 %t975, %t978
  %t980 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t979)
  call void @olang_textcopy(ptr %t980, ptr %t967, i64 %t968)
  %t981 = getelementptr i8, ptr %t980, i64 %t968
  call void @olang_textcopy(ptr %t981, ptr %t970, i64 %t971)
  %t982 = getelementptr i8, ptr %t981, i64 %t971
  call void @olang_textcopy(ptr %t982, ptr %t973, i64 %t974)
  %t983 = getelementptr i8, ptr %t982, i64 %t974
  call void @olang_textcopy(ptr %t983, ptr %t977, i64 %t978)
  %t984 = insertvalue { i64, ptr } undef, i64 %t979, 0
  %t985 = insertvalue { i64, ptr } %t984, ptr %t980, 1
  %t987 = extractvalue { i64, ptr } %t985, 0
  %t988 = extractvalue { i64, ptr } %t985, 1
  %t989 = mul i64 %t987, 1
  %t990 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t989)
  call void @llvm.memcpy.p0.p0.i64(ptr %t990, ptr %t988, i64 %t989, i1 false)
  %t991 = insertvalue { i64, ptr } undef, i64 %t987, 0
  %t992 = insertvalue { i64, ptr } %t991, ptr %t990, 1
  %t993 = load ptr, ptr %l294, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s40, ptr %t993, { i64, ptr } %t992)
  br label %bb200
bb199:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb200:
  call void @__olang_scope_close(ptr %s40)
  br label %bb231
bb201:
  %t995 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t996 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t999 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t995, { i64, ptr } %t996)
  store i1 %t999, ptr %l307
  br label %bb203
bb202:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb204
bb203:
  %t1000 = load i1, ptr %l307, !tbaa !21
  %t1001 = xor i1 %t1000, true
  store i1 %t1001, ptr %l304, !tbaa !21
  br label %bb204
bb204:
  %t1003 = load i1, ptr %l304, !tbaa !21
  br i1 %t1003, label %bb205, label %bb206
bb205:
  store %olang.scope zeroinitializer, ptr %s43
  %t1004 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1004, ptr %l309, !tbaa !29
  %t1005 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1005, ptr %l310, !tbaa !27
  %t1006 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1007 = extractvalue { i64, ptr } %t1006, 0
  store i64 %t1007, ptr %l311, !tbaa !24
  %t1008 = icmp sge i64 0, 0
  br i1 %t1008, label %bb207, label %bb208
bb206:
  %t1010 = load i1, ptr %l14, !tbaa !21
  br i1 %t1010, label %bb220, label %bb221
bb207:
  %t1012 = icmp sle i64 0, 12
  br i1 %t1012, label %bb209, label %bb210
bb208:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb209:
  %t1014 = load i64, ptr %l311, !tbaa !24
  %t1015 = icmp sle i64 12, %t1014
  br i1 %t1015, label %bb211, label %bb212
bb210:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb211:
  %t1017 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1018 = load ptr, ptr %t1017, !tbaa !27
  %t1019 = getelementptr i8, ptr %t1018, i64 0
  %t1020 = sub i64 12, 0
  %t1021 = insertvalue { i64, ptr } undef, i64 %t1020, 0
  %t1022 = insertvalue { i64, ptr } %t1021, ptr %t1019, 1
  store { i64, ptr } %t1022, ptr %l315, !tbaa !27
  %t1023 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1024 = extractvalue { i64, ptr } %t1023, 0
  store i64 %t1024, ptr %l316, !tbaa !24
  %t1025 = icmp sge i64 0, 0
  br i1 %t1025, label %bb213, label %bb214
bb212:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb213:
  %t1027 = icmp sle i64 0, 12
  br i1 %t1027, label %bb215, label %bb216
bb214:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb215:
  %t1029 = load i64, ptr %l316, !tbaa !24
  %t1030 = icmp sle i64 12, %t1029
  br i1 %t1030, label %bb217, label %bb218
bb216:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb217:
  %t1032 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t1033 = load ptr, ptr %t1032, !tbaa !27
  %t1034 = getelementptr i8, ptr %t1033, i64 0
  %t1035 = sub i64 12, 0
  %t1036 = insertvalue { i64, ptr } undef, i64 %t1035, 0
  %t1037 = insertvalue { i64, ptr } %t1036, ptr %t1034, 1
  %t1038 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t1039 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t1040 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t1041 = extractvalue { i64, ptr } %t1040, 1
  %t1042 = extractvalue { i64, ptr } %t1040, 0
  %t1043 = add i64 %t1039, %t1042
  %t1044 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t1045 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t1046 = add i64 %t1043, %t1045
  %t1047 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t1048 = extractvalue { i64, ptr } %t1047, 1
  %t1049 = extractvalue { i64, ptr } %t1047, 0
  %t1050 = add i64 %t1046, %t1049
  %t1051 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t1052 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t1053 = add i64 %t1050, %t1052
  %t1055 = extractvalue { i64, ptr } %t1037, 1
  %t1056 = extractvalue { i64, ptr } %t1037, 0
  %t1057 = add i64 %t1053, %t1056
  %t1058 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t1059 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t1060 = add i64 %t1057, %t1059
  %t1061 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1060)
  call void @olang_textcopy(ptr %t1061, ptr %t1038, i64 %t1039)
  %t1062 = getelementptr i8, ptr %t1061, i64 %t1039
  call void @olang_textcopy(ptr %t1062, ptr %t1041, i64 %t1042)
  %t1063 = getelementptr i8, ptr %t1062, i64 %t1042
  call void @olang_textcopy(ptr %t1063, ptr %t1044, i64 %t1045)
  %t1064 = getelementptr i8, ptr %t1063, i64 %t1045
  call void @olang_textcopy(ptr %t1064, ptr %t1048, i64 %t1049)
  %t1065 = getelementptr i8, ptr %t1064, i64 %t1049
  call void @olang_textcopy(ptr %t1065, ptr %t1051, i64 %t1052)
  %t1066 = getelementptr i8, ptr %t1065, i64 %t1052
  call void @olang_textcopy(ptr %t1066, ptr %t1055, i64 %t1056)
  %t1067 = getelementptr i8, ptr %t1066, i64 %t1056
  call void @olang_textcopy(ptr %t1067, ptr %t1058, i64 %t1059)
  %t1068 = insertvalue { i64, ptr } undef, i64 %t1060, 0
  %t1069 = insertvalue { i64, ptr } %t1068, ptr %t1061, 1
  %t1071 = extractvalue { i64, ptr } %t1069, 0
  %t1072 = extractvalue { i64, ptr } %t1069, 1
  %t1073 = mul i64 %t1071, 1
  %t1074 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1073)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1074, ptr %t1072, i64 %t1073, i1 false)
  %t1075 = insertvalue { i64, ptr } undef, i64 %t1071, 0
  %t1076 = insertvalue { i64, ptr } %t1075, ptr %t1074, 1
  %t1077 = load ptr, ptr %l309, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s43, ptr %t1077, { i64, ptr } %t1076)
  br label %bb219
bb218:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb219:
  call void @__olang_scope_close(ptr %s43)
  br label %bb230
bb220:
  store %olang.scope zeroinitializer, ptr %s46
  %t1079 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1079, ptr %l324, !tbaa !29
  %t1080 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1080, ptr %l325, !tbaa !27
  %t1081 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1082 = extractvalue { i64, ptr } %t1081, 0
  store i64 %t1082, ptr %l326, !tbaa !24
  %t1083 = icmp sge i64 0, 0
  br i1 %t1083, label %bb222, label %bb223
bb221:
  br label %bb229
bb222:
  %t1085 = icmp sle i64 0, 12
  br i1 %t1085, label %bb224, label %bb225
bb223:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb224:
  %t1087 = load i64, ptr %l326, !tbaa !24
  %t1088 = icmp sle i64 12, %t1087
  br i1 %t1088, label %bb226, label %bb227
bb225:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb226:
  %t1090 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1091 = load ptr, ptr %t1090, !tbaa !27
  %t1092 = getelementptr i8, ptr %t1091, i64 0
  %t1093 = sub i64 12, 0
  %t1094 = insertvalue { i64, ptr } undef, i64 %t1093, 0
  %t1095 = insertvalue { i64, ptr } %t1094, ptr %t1092, 1
  %t1096 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t1097 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t1098 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t1099 = extractvalue { i64, ptr } %t1098, 1
  %t1100 = extractvalue { i64, ptr } %t1098, 0
  %t1101 = add i64 %t1097, %t1100
  %t1102 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t1103 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t1104 = add i64 %t1101, %t1103
  %t1106 = extractvalue { i64, ptr } %t1095, 1
  %t1107 = extractvalue { i64, ptr } %t1095, 0
  %t1108 = add i64 %t1104, %t1107
  %t1109 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1108)
  call void @olang_textcopy(ptr %t1109, ptr %t1096, i64 %t1097)
  %t1110 = getelementptr i8, ptr %t1109, i64 %t1097
  call void @olang_textcopy(ptr %t1110, ptr %t1099, i64 %t1100)
  %t1111 = getelementptr i8, ptr %t1110, i64 %t1100
  call void @olang_textcopy(ptr %t1111, ptr %t1102, i64 %t1103)
  %t1112 = getelementptr i8, ptr %t1111, i64 %t1103
  call void @olang_textcopy(ptr %t1112, ptr %t1106, i64 %t1107)
  %t1113 = insertvalue { i64, ptr } undef, i64 %t1108, 0
  %t1114 = insertvalue { i64, ptr } %t1113, ptr %t1109, 1
  %t1116 = extractvalue { i64, ptr } %t1114, 0
  %t1117 = extractvalue { i64, ptr } %t1114, 1
  %t1118 = mul i64 %t1116, 1
  %t1119 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1119, ptr %t1117, i64 %t1118, i1 false)
  %t1120 = insertvalue { i64, ptr } undef, i64 %t1116, 0
  %t1121 = insertvalue { i64, ptr } %t1120, ptr %t1119, 1
  %t1122 = load ptr, ptr %l324, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s46, ptr %t1122, { i64, ptr } %t1121)
  br label %bb228
bb227:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb228:
  call void @__olang_scope_close(ptr %s46)
  br label %bb229
bb229:
  br label %bb230
bb230:
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s39)
  br label %bb232
bb232:
  %t1124 = load ptr, ptr %lp21
  %t1125 = load { i64, ptr }, ptr %t1124, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t1127 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t1125, 1
  store { i32, { i64, ptr } } %t1127, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %l45 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l18, !tbaa !24
  store i64 %t35, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l15, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l39
  br label %bb13
bb13:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %a1)
  store i1 %t65, ptr %l41
  br label %bb14
bb14:
  %t66 = load i1, ptr %l41, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/fetch:Fetcher", ptr %t67, i32 0, i32 7
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l45
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t74 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t75 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t74, 1
  store { i32, { i64, ptr } } %t75, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  %t81 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l22 = alloca %"std/prelude/text:LineIter"
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i1
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca i1
  %l57 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/fetch:Fetcher", ptr %t6, i32 0, i32 5
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fetch:Fetcher", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %t12)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l18
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18, !prof !99
ok.18:
  store { i64, ptr } %t15, ptr %l17
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  br label %bb7
bb5:
  %t20 = load i32, ptr %l18, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t27 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t24)
  store %"std/prelude/text:LineIter" %t27, ptr %l22
  br label %bb8
bb8:
  %t28 = load %"std/prelude/text:LineIter", ptr %l22
  store %"std/prelude/text:LineIter" %t28, ptr %l2
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t30 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %l2)
  %t31 = extractvalue { i32, { i64, ptr } } %t30, 1
  %t32 = extractvalue { i32, { i64, ptr } } %t30, 0
  store i32 %t32, ptr %l26
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb11, label %ok.34, !prof !99
ok.34:
  store { i64, ptr } %t31, ptr %l25
  br label %bb10
bb10:
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t35, ptr %l23, !tbaa !27
  br label %bb13
bb11:
  %t36 = load i32, ptr %l26, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb13:
  %t40 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t43, ptr %l30
  br label %bb14
bb14:
  %t44 = load i1, ptr %l30, !tbaa !21
  br i1 %t44, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb16:
  br label %bb17
bb17:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t45)
  store { i64, ptr } %t47, ptr %l32
  br label %bb18
bb18:
  %t48 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t49 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s4, { i64, ptr } %t48, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store { i64, ptr } %t49, ptr %l33
  br label %bb19
bb19:
  %t50 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l36, !tbaa !24
  %t54 = load i64, ptr %l36, !tbaa !24
  %t55 = mul i64 %t54, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l36, !tbaa !24
  %t64 = mul i64 %t63, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t60, ptr %t62, i64 %t64, i1 false)
  %t65 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t65, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t66, ptr %l39, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l40, !tbaa !24
  %t69 = load i64, ptr %l40, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l41, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l40, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t80, ptr %l6, !tbaa !27
  store { i64, ptr } %t50, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb22:
  br label %bb23
bb23:
  %t95 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t95, ptr %l49, !tbaa !27
  %t96 = load i64, ptr %l8, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %t99, i64 %t96
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !37
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t105, ptr %l53
  br label %bb24
bb24:
  %t106 = load i1, ptr %l53, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s7, { i64, ptr } %t107, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t109, ptr %l55
  br label %bb28
bb28:
  %t110 = load i1, ptr %l55, !tbaa !21
  br i1 %t110, label %bb29, label %bb30
bb29:
  %t111 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = extractvalue { i64, ptr } %t111, 0
  %t115 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t113, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l57, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  store i64 %t121, ptr %l59, !tbaa !24
  %t123 = load i64, ptr %l59, !tbaa !24
  %t124 = icmp eq i64 %t119, %t123
  br i1 %t124, label %bb31, label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s11
  %t126 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s11, { i64, ptr } %t126, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t128, ptr %l62
  br label %bb34
bb31:
  %t129 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l59, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  br label %bb33
bb32:
  %t135 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t135, ptr %l5, !tbaa !27
  br label %bb33
bb33:
  br label %bb41
bb34:
  %t136 = load i1, ptr %l62, !tbaa !21
  br i1 %t136, label %bb35, label %bb36
bb35:
  %t137 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t139, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l64, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l66, !tbaa !24
  %t149 = load i64, ptr %l66, !tbaa !24
  %t150 = icmp eq i64 %t145, %t149
  br i1 %t150, label %bb37, label %bb38
bb36:
  br label %bb40
bb37:
  %t152 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l66, !tbaa !24
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  br label %bb39
bb38:
  %t158 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t158, ptr %l6, !tbaa !27
  br label %bb39
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s11)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  %t159 = load i64, ptr %l8, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l8, !tbaa !24
  br label %bb20
bb43:
  %t163 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t163, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t165, ptr %l71
  br label %bb44
bb44:
  %t166 = load i1, ptr %l71, !tbaa !21
  br i1 %t166, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/fetch:Fetcher", ptr %t167, i32 0, i32 6
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = extractvalue { i64, ptr } %t170, 0
  %t174 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t172, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t169, { i64, ptr } %t183)
  br label %bb48
bb48:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/fetch:Fetcher", ptr %t186, i32 0, i32 7
  %t189 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 1
  %t192 = extractvalue { i64, ptr } %t189, 0
  %t193 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t191, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t188, { i64, ptr } %t202)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb50:
  br label %bb9
bb51:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca i1
  %l61 = alloca i1
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l88 = alloca i64
  %l97 = alloca i64
  %l100 = alloca i64
  %l125 = alloca %"std/prelude/text:StringBuilder"
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l157 = alloca i32
  %l159 = alloca i1
  %s0 = alloca %olang.scope
  %t235 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l25
  br label %bb2
bb2:
  %t8 = load i64, ptr %l25, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l32, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l32, !tbaa !24
  store i64 %t35, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %l9, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l53
  br label %bb13
bb13:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t62)
  store i1 %t65, ptr %l55
  br label %bb14
bb14:
  %t66 = load i1, ptr %l55, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load i64, ptr %l9, !tbaa !24
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/fetch:Fetcher", ptr %t77, i32 0, i32 7
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store { i64, ptr } %t83, ptr %l65
  br label %bb22
bb21:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb24
bb22:
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t85, { i64, ptr } %t84)
  store i1 %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load i1, ptr %l67, !tbaa !21
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = icmp sge i64 %t90, 0
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/fetch:Fetcher", ptr %t94, i32 0, i32 7
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = extractvalue { i64, ptr } %t98, 0
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t100, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v0, ptr %t96, i64 %t97, { i64, ptr } %t111)
  br label %bb30
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/fetch:Fetcher", ptr %t115, i32 0, i32 6
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t117, { i64, ptr } %t131)
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/fetch:Fetcher", ptr %t134, i32 0, i32 7
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t139, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t136, { i64, ptr } %t150)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/fetch:Fetcher", ptr %t153, i32 0, i32 6
  %t157 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t155)
  store i64 %t157, ptr %l88
  br label %bb34
bb34:
  %t158 = load i64, ptr %l88, !tbaa !24
  %t159 = icmp sge i64 %t158, 0
  br i1 %t159, label %bb35, label %bb36
bb35:
  %t161 = load i64, ptr %l88, !tbaa !24
  %t162 = icmp sle i64 %t161, 1152921504606846975
  br i1 %t162, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ba721b6722bc57b1_efdace1c8e747995)
  unreachable
bb37:
  %t164 = load i64, ptr %l88, !tbaa !24
  %t165 = mul i64 %t164, 8
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  store i64 %t172, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_ba721b6722bc57b1_efdace1c8e747995)
  unreachable
bb39:
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb44
bb41:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t185 = load i64, ptr %l11, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l13, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l13, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l100, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb43
bb43:
  %t200 = load i64, ptr %l100, !tbaa !24
  store i64 %t200, ptr %l97, !tbaa !24
  br label %bb44
bb44:
  %t201 = load i64, ptr %l97, !tbaa !24
  store i64 %t201, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb45
bb45:
  %t202 = load i64, ptr %l15, !tbaa !24
  %t203 = load i64, ptr %l14, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb46, label %bb47
bb46:
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t210 = load i64, ptr %l11, !tbaa !24
  %t211 = load i64, ptr %l15, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l16, !tbaa !24
  %t220 = load i64, ptr %l16, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i64, ptr %t225, i64 %t220
  store i64 %t221, ptr %t226, !tbaa !34
  br label %bb49
bb49:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l15, !tbaa !24
  br label %bb45
bb50:
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t234 = ptrtoint ptr %t233 to i64
  %t236 = getelementptr { ptr, ptr }, ptr %t235, i32 0, i32 0
  store ptr %t232, ptr %t236, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t238 = getelementptr { ptr, ptr }, ptr %t235, i32 0, i32 1
  store ptr %v0, ptr %t238, !tbaa !28
  %t239 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_82, 0
  %t240 = insertvalue { ptr, ptr } %t239, ptr %t235, 1
  %t243 = extractvalue { ptr, ptr } %t240, 0
  %t244 = extractvalue { ptr, ptr } %t240, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t231, ptr %t243, ptr %t244)
  br label %bb51
bb51:
  %t245 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t245, ptr %l125
  br label %bb52
bb52:
  %t246 = load %"std/prelude/text:StringBuilder", ptr %l125
  store %"std/prelude/text:StringBuilder" %t246, ptr %l17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb53
bb53:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb54
bb54:
  %t249 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t249, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l20, !tbaa !24
  br label %bb55
bb55:
  %t255 = load i64, ptr %l19, !tbaa !24
  %t256 = load i64, ptr %l20, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb56, label %bb57
bb56:
  br label %bb66
bb57:
  br label %bb58
bb58:
  %t263 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t263, ptr %l135, !tbaa !27
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i64, ptr %t267, i64 %t264
  %t269 = load i64, ptr %t268, !tbaa !34
  store i64 %t269, ptr %l21, !tbaa !24
  store ptr %l17, ptr %l138, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/fetch:Fetcher", ptr %t271, i32 0, i32 6
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t273, i64 %t274)
  store { i64, ptr } %t277, ptr %l142
  br label %bb59
bb59:
  %t278 = load ptr, ptr %l138, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l142, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t278, { i64, ptr } %t279)
  br label %bb60
bb60:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l17, i8 32)
  br label %bb61
bb61:
  store ptr %l17, ptr %l144, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/fetch:Fetcher", ptr %t281, i32 0, i32 7
  %t284 = load i64, ptr %l21, !tbaa !24
  %t287 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t283, i64 %t284)
  store { i64, ptr } %t287, ptr %l148
  br label %bb62
bb62:
  %t288 = load ptr, ptr %l144, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l148, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t288, { i64, ptr } %t289)
  br label %bb63
bb63:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l17, i8 10)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t291 = load i64, ptr %l19, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l19, !tbaa !24
  br label %bb55
bb66:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/fetch:Fetcher", ptr %t295, i32 0, i32 0
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, ptr } %t298, ptr %l153, !tbaa !27
  %t300 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l17)
  store { i64, ptr } %t300, ptr %l155
  br label %bb67
bb67:
  %t301 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t304 = call i32 @std_2fos_2eWriteFile(ptr %v0, ptr %s0, { i64, ptr } %t302, { i64, ptr } %t301)
  store i32 %t304, ptr %l157
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb69, label %ok.306, !prof !99
ok.306:
  br label %bb68
bb68:
  br label %bb71
bb69:
  %t307 = load i32, ptr %l157, !tbaa !23
  %t308 = ashr i32 %t307, 16
  %t310 = icmp eq i32 %t308, 1
  store i1 %t310, ptr %l159, !tbaa !21
  br label %bb70
bb70:
  call void @__olang_ert_req_clear()
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 9
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = extractvalue { i64, ptr } %t10, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t3, { i64, ptr } %t17)
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/fetch:Fetcher", ptr %t20, i32 0, i32 4
  %t23 = load i1, ptr %t22, !tbaa !21
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = call i32 @std_2fio_2ePrintErrln(ptr %v1, { i64, ptr } %t27)
  store i32 %t29, ptr %l11
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31, !prof !99
ok.31:
  br label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb7
bb5:
  %t32 = load i32, ptr %l11, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  br label %bb7
bb7:
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t20, { i64, ptr } %t22)
  store i1 %t25, ptr %l18
  br label %bb7
bb7:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb1
bb12:
  br i1 %a2, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/fetch:Fetcher", ptr %t34, i32 0, i32 8
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = extractvalue { i64, ptr } %t37, 0
  %t41 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t39, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t36, { i64, ptr } %t50)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2egit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:Output"
  %l6 = alloca i32
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t4 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t3, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) })
  %t5 = extractvalue { i32, %"std/os:Output" } %t4, 1
  %t6 = extractvalue { i32, %"std/os:Output" } %t4, 0
  store i32 %t6, ptr %l6
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store %"std/os:Output" %t5, ptr %l5
  br label %bb1
bb1:
  %t9 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t9, ptr %l2
  br label %bb4
bb2:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t15 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t15, ptr %l1
  %t16 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp eq i32 %t17, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ehead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca %"std/os:Output"
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"std/os:Output"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/os:Output"
  %l11 = alloca i32
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t10 = mul i64 5, 16
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 5, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %t15, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %t16, !tbaa !37
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %t18, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %t19, !tbaa !37
  %t21 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %t22, i64 2
  store { i64, ptr } %t7, ptr %t23, !tbaa !37
  %t24 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %t25, i64 3
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %t26, !tbaa !37
  %t27 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 4
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %t29, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t30, { i64, ptr } %t31, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) })
  %t33 = extractvalue { i32, %"std/os:Output" } %t32, 1
  %t34 = extractvalue { i32, %"std/os:Output" } %t32, 0
  store i32 %t34, ptr %l11
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb2, label %ok.36, !prof !99
ok.36:
  store %"std/os:Output" %t33, ptr %l10
  br label %bb1
bb1:
  %t37 = load %"std/os:Output", ptr %l10
  store %"std/os:Output" %t37, ptr %l6
  br label %bb4
bb2:
  %t38 = load i32, ptr %l11, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t42, ptr %l15, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l16, !tbaa !24
  %t45 = load i64, ptr %l16, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l17, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l16, !tbaa !24
  %t55 = mul i64 %t54, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t56, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
bb4:
  %t58 = load %"std/os:Output", ptr %l6
  store %"std/os:Output" %t58, ptr %l2
  %t59 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = icmp ne i32 %t60, 0
  br i1 %t62, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t64, ptr %l21, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l22, !tbaa !24
  %t67 = load i64, ptr %l22, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l23, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l22, !tbaa !24
  %t77 = mul i64 %t76, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %t75, i64 %t77, i1 false)
  %t78 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t78, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t79 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t80 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t81)
  store { i64, ptr } %t83, ptr %l25
  br label %bb8
bb8:
  %t84 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t84, ptr %l3, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t85)
  store i1 %t87, ptr %l27
  br label %bb9
bb9:
  %t88 = load i1, ptr %l27, !tbaa !21
  br i1 %t88, label %bb10, label %bb11
bb10:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l28, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t97, ptr %l28, !tbaa !27
  br label %bb12
bb12:
  %t99 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l33, !tbaa !24
  %t101 = load i64, ptr %l33, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l34, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l33, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t112, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t113 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t113, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2emakeRepo(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l21 = alloca i32
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t19)
  store i32 %t21, ptr %l9
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb2, label %ok.23, !prof !99
ok.23:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t24 = load i32, ptr %l9, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l13, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l14, !tbaa !24
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = mul i64 %t31, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t32)
  %t34 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l15, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l14, !tbaa !24
  %t41 = mul i64 %t40, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t37, ptr %t39, i64 %t41, i1 false)
  %t42 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t42, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t43 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb4:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t46, i64 %t47)
  %t52 = getelementptr i8, ptr %t51, i64 %t47
  call void @olang_textcopy(ptr %t52, ptr %t48, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t66 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t61, { i64, ptr } %a2)
  store i32 %t66, ptr %l21
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb6, label %ok.68, !prof !99
ok.68:
  br label %bb5
bb5:
  br label %bb8
bb6:
  %t69 = load i32, ptr %l21, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  store i1 %t72, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t73, ptr %l25, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l26, !tbaa !24
  %t76 = load i64, ptr %l26, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l27, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l26, !tbaa !24
  %t86 = mul i64 %t85, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %t84, i64 %t86, i1 false)
  %t87 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t87, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t88 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t88, ptr %rv
  br label %ret
bb8:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t91 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t89, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x { i64, ptr }] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t91, ptr %l29
  br label %bb9
bb9:
  %t92 = load i1, ptr %l29, !tbaa !21
  br i1 %t92, label %bb10, label %bb11
bb10:
  %t93 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t95 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t93, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x { i64, ptr }] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t95, ptr %l32
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb13
bb12:
  %t96 = load i1, ptr %l32, !tbaa !21
  store i1 %t96, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t97 = load i1, ptr %l30, !tbaa !21
  br i1 %t97, label %bb14, label %bb15
bb14:
  %t98 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t100 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t98, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x { i64, ptr }] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t100, ptr %l35
  br label %bb16
bb15:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb16:
  %t101 = load i1, ptr %l35, !tbaa !21
  store i1 %t101, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t102 = load i1, ptr %l33, !tbaa !21
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t105 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t107 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v3, { i64, ptr } %t105)
  store { i64, ptr } %t107, ptr %l39
  br label %bb20
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t108, ptr %l37, !tbaa !27
  br label %bb21
bb20:
  %t110 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t110, ptr %l37, !tbaa !27
  br label %bb21
bb21:
  %t111 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l42, !tbaa !24
  %t113 = load i64, ptr %l42, !tbaa !24
  %t114 = mul i64 %t113, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l43, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l42, !tbaa !24
  %t123 = mul i64 %t122, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %t121, i64 %t123, i1 false)
  %t124 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t124, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t125 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffetch_2esh(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/os:Output"
  %l3 = alloca %"std/os:Output"
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"std/os:Output"
  %l8 = alloca i32
  %l10 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %a1, { i64, ptr } %t4, i1 true, { i64, ptr } %a0)
  %t7 = extractvalue { i32, %"std/os:Output" } %t6, 1
  %t8 = extractvalue { i32, %"std/os:Output" } %t6, 0
  store i32 %t8, ptr %l8
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store %"std/os:Output" %t7, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"std/os:Output", ptr %l7
  store %"std/os:Output" %t11, ptr %l3
  br label %bb4
bb2:
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t17 = load %"std/os:Output", ptr %l3
  store %"std/os:Output" %t17, ptr %l2
  %t18 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = icmp eq i32 %t19, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/fetch:Fetcher"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store { i64, ptr } %a1, ptr %l6, !tbaa !27
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  store i1 %a3, ptr %l8, !tbaa !21
  store i1 %a4, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l20
  br label %bb1
bb1:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l11
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l21
  br label %bb2
bb2:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l12
  %t15 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l22
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l13
  %t17 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l23
  br label %bb4
bb4:
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t20 = insertvalue %"compiler/fetch:Fetcher" undef, { i64, ptr } %t19, 0
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = insertvalue %"compiler/fetch:Fetcher" %t20, { i64, ptr } %t21, 1
  %t23 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t24 = insertvalue %"compiler/fetch:Fetcher" %t22, { i64, ptr } %t23, 2
  %t25 = load i1, ptr %l8, !tbaa !21
  %t26 = insertvalue %"compiler/fetch:Fetcher" %t24, i1 %t25, 3
  %t27 = load i1, ptr %l9, !tbaa !21
  %t28 = insertvalue %"compiler/fetch:Fetcher" %t26, i1 %t27, 4
  %t29 = load i1, ptr %l10, !tbaa !21
  %t30 = insertvalue %"compiler/fetch:Fetcher" %t28, i1 %t29, 5
  %t31 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t32 = insertvalue %"compiler/fetch:Fetcher" %t30, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, 6
  %t33 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t34 = insertvalue %"compiler/fetch:Fetcher" %t32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, 7
  %t35 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t36 = insertvalue %"compiler/fetch:Fetcher" %t34, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, 8
  %t38 = insertvalue %"compiler/fetch:Fetcher" %t36, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, 9
  store %"compiler/fetch:Fetcher" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/fetch:Fetcher", ptr %rv
  ret %"compiler/fetch:Fetcher" %rr
}

@.d0 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_CACHE" }>, align 8
declare void @__olang_ert_req_clear()
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HOME" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d5 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"/.cache/olang" }>, align 8
@.d6 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_GIT_BASE" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"https://" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@.d11 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"/example.com/me/" }>, align 8
@.d12 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"/lib.olang" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [12 x { i64, ptr }] }> <{ i64 0, [12 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d103, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d105, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d108, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d110, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d111, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }] }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d23 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".fetch-" }>, align 8
@.d24 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang: fetching " }>, align 8
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" into " }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d27 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", as olang.lock says" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"init" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d34 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fetch" }>, align 8
@.d35 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d36 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--depth" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"--" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d41 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"checkout" }>, align 8
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d43 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"FETCH_HEAD" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"clone" }>, align 8
@.d46 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"--" }>, align 8
@.d48 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d49 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d50 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"checkout" }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d52 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang: fetching " }>, align 8
@.d53 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" into " }>, align 8
@.d54 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--branch=" }>, align 8
@.d55 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--quiet" }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"clone" }>, align 8
@.d59 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--quiet" }>, align 8
@.d60 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--depth" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d62 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"--" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang: updated " }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d68 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang: updated " }>, align 8
@.d69 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d70 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" (was " }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d72 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d73 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is already at " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_82(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 6
  %t7 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t3, i64 %a0)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/fetch:Fetcher", ptr %t8, i32 0, i32 6
  %t14 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t15, { i64, ptr } %t16)
  store i1 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d83 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c"# olang.lock - the commit each remote repository is built from (M23b). Delete a line to update that\0A" }>, align 8
@.d84 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"# repository, or build with -u to update every one the build reaches (M23c).\0A" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d88 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d89 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"rev-parse" }>, align 8
@.d90 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HEAD" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"/example.com/me/" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"/lib.olang" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [3 x { i64, ptr }] }> <{ i64 0, [3 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d103, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) }] }>, align 8
@.d99 = private constant <{ i64, [9 x { i64, ptr }] }> <{ i64 0, [9 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d103, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d105, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d114, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }] }>, align 8
@.d100 = private constant <{ i64, [11 x { i64, ptr }] }> <{ i64 0, [11 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d103, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d105, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d108, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d111, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }] }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d103 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d104 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d105 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"user.name=t" }>, align 8
@.d106 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"user.email=t@t" }>, align 8
@.d107 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"commit.gpgsign=false" }>, align 8
@.d108 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"commit" }>, align 8
@.d109 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d110 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-a" }>, align 8
@.d111 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-m" }>, align 8
@.d112 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"y" }>, align 8
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d113 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"init" }>, align 8
@.d114 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"add" }>, align 8
@.d115 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d116 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2 = external constant [0 x i8]
@olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f = external constant [0 x i8]
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_45f2c25416d44418_72b8f662ae75c904 = external constant [0 x i8]
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_461a8d3078b45b75_287f37f9c7026b71 = external constant [0 x i8]
@olang_loc_64bbdb9c4083d73a_45ec4fce431b420e = external constant [0 x i8]
@olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_ba721b6722bc57b1_efdace1c8e747995 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
