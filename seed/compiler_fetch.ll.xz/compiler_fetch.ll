; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
define dso_local { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr @.d0 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d1 }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr @.d2 })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t31 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr @.d3 })
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l15
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l14
  br label %bb9
bb9:
  %t36 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t36, ptr %l13, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  store { i64, ptr } { i64 1, ptr @.d4 }, ptr %l16, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l13, !tbaa !27
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = extractvalue { i64, ptr } %t46, 0
  %t51 = extractvalue { i64, ptr } { i64 13, ptr @.d5 }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr @.d5 }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = getelementptr i8, ptr %t54, i64 %t50
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d6 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d7 }, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr @.d8 })
  store i1 %t19, ptr %l8
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr @.d9 }, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l10, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l15, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l15, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffetch_2eIsCommit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp ne i64 %t3, 40
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 64
  store i1 %t11, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l4, !tbaa !22
  %t37 = load i8, ptr %l4, !tbaa !22
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t37)
  store i1 %t39, ptr %l24
  br label %bb11
bb11:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb17
bb13:
  %t41 = load i8, ptr %l4, !tbaa !22
  %t43 = icmp uge i8 %t41, 97
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load i8, ptr %l4, !tbaa !22
  %t47 = icmp ule i8 %t45, 102
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l28, !tbaa !21
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t50 = load i1, ptr %l25, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l2, !tbaa !24
  br label %bb7
bb22:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2eNamePart(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp eq i8 %t11, 46
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 0
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = icmp eq i8 %t20, 45
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 2, ptr @.d10 }, ptr %l19, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t29 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } %t28)
  store i1 %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load i1, ptr %l20, !tbaa !21
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t33, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i8, ptr %t51, i64 %t48
  %t53 = load i8, ptr %t52, !tbaa !32
  store i8 %t53, ptr %l4, !tbaa !22
  %t55 = load i8, ptr %l4, !tbaa !22
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t55)
  store i1 %t57, ptr %l33
  br label %bb18
bb18:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb22
bb20:
  %t59 = load i8, ptr %l4, !tbaa !22
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t59)
  store i1 %t61, ptr %l36
  br label %bb21
bb21:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb25
bb24:
  %t64 = load i8, ptr %l4, !tbaa !22
  %t66 = icmp eq i8 %t64, 46
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb28
bb27:
  %t69 = load i8, ptr %l4, !tbaa !22
  %t71 = icmp eq i8 %t69, 95
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb30:
  %t74 = load i8, ptr %l4, !tbaa !22
  %t76 = icmp eq i8 %t74, 45
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t78 = load i1, ptr %l43, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l2, !tbaa !24
  br label %bb14
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ecommitAgain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr @.d11 }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d11 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d12 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d12 }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t41 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t36, { i64, ptr } %a2)
  store i32 %t41, ptr %l13
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb2, label %ok.43
ok.43:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t44 = load i32, ptr %l13, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  br i1 %t47, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_d3373a347b8bef1c_6787ad888ff53eb8)
  unreachable
bb5:
  store { i64, ptr } { i64 0, ptr @.d13 }, ptr %l16, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t49, ptr %l17, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l18, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l18, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t63, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t64 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
bb6:
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 12, ptr @.d14 })
  store i1 %t67, ptr %l21
  br label %bb7
bb7:
  %t68 = load i1, ptr %l21, !tbaa !21
  br i1 %t68, label %bb8, label %bb9
bb8:
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v3, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l25
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr @.d15 }, ptr %l26, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t74, ptr %l23, !tbaa !27
  br label %bb11
bb10:
  %t76 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t76, ptr %l23, !tbaa !27
  br label %bb11
bb11:
  %t77 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l28, !tbaa !24
  %t79 = load i64, ptr %l28, !tbaa !24
  %t80 = mul i64 %t79, 1
  %t81 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l29, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l28, !tbaa !24
  %t89 = mul i64 %t88, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %t87, i64 %t89, i1 false)
  %t90 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t90, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t91 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %lp15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %lp17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %lp21 = alloca ptr
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l79 = alloca i1
  %l81 = alloca i1
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l128 = alloca i64
  %l131 = alloca i1
  %l133 = alloca i1
  %l141 = alloca i1
  %l144 = alloca i32
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l161 = alloca i64
  %l175 = alloca i1
  %l176 = alloca i1
  %l180 = alloca [10 x { i64, ptr }]
  %l183 = alloca i1
  %l184 = alloca i1
  %l189 = alloca i1
  %l193 = alloca i32
  %l202 = alloca i1
  %l208 = alloca i1
  %l210 = alloca { i64, ptr }
  %l213 = alloca i1
  %l216 = alloca i32
  %l222 = alloca i1
  %l226 = alloca i32
  %l231 = alloca i32
  %l237 = alloca i32
  %l251 = alloca { i64, ptr }
  %l256 = alloca i32
  %l260 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l262 = alloca i64
  %l263 = alloca { i64, ptr }
  %l267 = alloca [9 x { i64, ptr }]
  %l270 = alloca i1
  %l272 = alloca { i64, ptr }
  %l274 = alloca i64
  %l277 = alloca i1
  %l279 = alloca i32
  %l288 = alloca i1
  %l290 = alloca i32
  %l296 = alloca i32
  %l301 = alloca i32
  %l313 = alloca i1
  %l315 = alloca i1
  %l317 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l320 = alloca i64
  %l328 = alloca i1
  %l331 = alloca i1
  %l333 = alloca ptr
  %l334 = alloca { i64, ptr }
  %l335 = alloca i64
  %l339 = alloca { i64, ptr }
  %l340 = alloca i64
  %l348 = alloca ptr
  %l349 = alloca { i64, ptr }
  %l350 = alloca i64
  %s0 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v3, { i64, ptr } %t1, i8 64)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l26
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i64 %t5, ptr %l25
  br label %bb1
bb1:
  %t9 = load i64, ptr %l25, !tbaa !24
  store i64 %t9, ptr %l22, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l22, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l22, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l29, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l30, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l30, !tbaa !24
  %t22 = icmp sle i64 0, %t21
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb7:
  %t24 = load i64, ptr %l30, !tbaa !24
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  br i1 %t26, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l30, !tbaa !24
  %t31 = getelementptr i8, ptr %t29, i64 0
  %t32 = sub i64 %t30, 0
  %t33 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t36, %t39
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb11:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l41, !tbaa !27
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l43, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t48, 0
  store i64 %t51, ptr %l46, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l47, !tbaa !24
  %t54 = load i64, ptr %l43, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb12:
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t57, ptr %l52, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l54, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t61, 0
  store i64 %t64, ptr %l57, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l58, !tbaa !24
  %t67 = load i64, ptr %l54, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb19, label %bb20
bb13:
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = load i64, ptr %l46, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb15:
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l43, !tbaa !24
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l40, !tbaa !27
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb19:
  %t87 = load i64, ptr %l54, !tbaa !24
  %t88 = load i64, ptr %l57, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb21:
  %t91 = load i64, ptr %l57, !tbaa !24
  %t92 = load i64, ptr %l58, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb23:
  %t95 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l54, !tbaa !24
  %t98 = load i64, ptr %l57, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l40, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb25:
  %t104 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t104, ptr %l6, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2ffetch_2eNamePart(ptr %v1, { i64, ptr } %t105)
  store i1 %t107, ptr %l64
  br label %bb26
bb26:
  %t108 = load i1, ptr %l64, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t113 = call i1 @compiler_2ffetch_2eNamePart(ptr %v2, { i64, ptr } %t111)
  store i1 %t113, ptr %l68
  br label %bb29
bb29:
  %t114 = load i1, ptr %l68, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t117 = load i1, ptr %l66, !tbaa !21
  br i1 %t117, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb34
bb32:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t120 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t118)
  store i1 %t120, ptr %l72
  br label %bb33
bb33:
  %t121 = load i1, ptr %l72, !tbaa !21
  %t122 = xor i1 %t121, true
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb41
bb36:
  %t125 = load i64, ptr %l4, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t131 = icmp slt i64 %t125, %t128
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t133 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t135 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t133)
  store i1 %t135, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t136 = load i1, ptr %l81, !tbaa !21
  %t137 = xor i1 %t136, true
  store i1 %t137, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t139 = load i1, ptr %l79, !tbaa !21
  store i1 %t139, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t140 = load i1, ptr %l74, !tbaa !21
  br i1 %t140, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/fetch:Fetcher", ptr %t143, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l7, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t148, 1
  %t153 = extractvalue { i64, ptr } %t148, 0
  %t154 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t149, 1
  %t159 = extractvalue { i64, ptr } %t149, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t163 = add i64 %t160, %t162
  %t165 = extractvalue { i64, ptr } %t150, 1
  %t166 = extractvalue { i64, ptr } %t150, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t152, i64 %t153)
  %t169 = getelementptr i8, ptr %t168, i64 %t153
  call void @olang_textcopy(ptr %t169, ptr %t154, i64 %t155)
  %t170 = getelementptr i8, ptr %t169, i64 %t155
  call void @olang_textcopy(ptr %t170, ptr %t158, i64 %t159)
  %t171 = getelementptr i8, ptr %t170, i64 %t159
  call void @olang_textcopy(ptr %t171, ptr %t161, i64 %t162)
  %t172 = getelementptr i8, ptr %t171, i64 %t162
  call void @olang_textcopy(ptr %t172, ptr %t165, i64 %t166)
  %t173 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t168, 1
  store { i64, ptr } %t174, ptr %l8, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/fetch:Fetcher", ptr %t176, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t179, 1
  %t185 = extractvalue { i64, ptr } %t179, 0
  %t187 = extractvalue { i64, ptr } %t180, 1
  %t188 = extractvalue { i64, ptr } %t180, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t192 = add i64 %t189, %t191
  %t194 = extractvalue { i64, ptr } %t181, 1
  %t195 = extractvalue { i64, ptr } %t181, 0
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t198 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  %t199 = add i64 %t196, %t198
  %t201 = extractvalue { i64, ptr } %t182, 1
  %t202 = extractvalue { i64, ptr } %t182, 0
  %t203 = add i64 %t199, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t184, i64 %t185)
  %t205 = getelementptr i8, ptr %t204, i64 %t185
  call void @olang_textcopy(ptr %t205, ptr %t187, i64 %t188)
  %t206 = getelementptr i8, ptr %t205, i64 %t188
  call void @olang_textcopy(ptr %t206, ptr %t190, i64 %t191)
  %t207 = getelementptr i8, ptr %t206, i64 %t191
  call void @olang_textcopy(ptr %t207, ptr %t194, i64 %t195)
  %t208 = getelementptr i8, ptr %t207, i64 %t195
  call void @olang_textcopy(ptr %t208, ptr %t197, i64 %t198)
  %t209 = getelementptr i8, ptr %t208, i64 %t198
  call void @olang_textcopy(ptr %t209, ptr %t201, i64 %t202)
  %t210 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t204, 1
  store { i64, ptr } %t211, ptr %l9, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t213, 1
  %t219 = extractvalue { i64, ptr } %t213, 0
  %t220 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t222 = add i64 %t219, %t221
  %t224 = extractvalue { i64, ptr } %t214, 1
  %t225 = extractvalue { i64, ptr } %t214, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 0
  %t229 = add i64 %t226, %t228
  %t231 = extractvalue { i64, ptr } %t215, 1
  %t232 = extractvalue { i64, ptr } %t215, 0
  %t233 = add i64 %t229, %t232
  %t234 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t235 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t236 = add i64 %t233, %t235
  %t238 = extractvalue { i64, ptr } %t216, 1
  %t239 = extractvalue { i64, ptr } %t216, 0
  %t240 = add i64 %t236, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t218, i64 %t219)
  %t242 = getelementptr i8, ptr %t241, i64 %t219
  call void @olang_textcopy(ptr %t242, ptr %t220, i64 %t221)
  %t243 = getelementptr i8, ptr %t242, i64 %t221
  call void @olang_textcopy(ptr %t243, ptr %t224, i64 %t225)
  %t244 = getelementptr i8, ptr %t243, i64 %t225
  call void @olang_textcopy(ptr %t244, ptr %t227, i64 %t228)
  %t245 = getelementptr i8, ptr %t244, i64 %t228
  call void @olang_textcopy(ptr %t245, ptr %t231, i64 %t232)
  %t246 = getelementptr i8, ptr %t245, i64 %t232
  call void @olang_textcopy(ptr %t246, ptr %t234, i64 %t235)
  %t247 = getelementptr i8, ptr %t246, i64 %t235
  call void @olang_textcopy(ptr %t247, ptr %t238, i64 %t239)
  %t248 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t241, 1
  store { i64, ptr } %t249, ptr %l10, !tbaa !27
  store i1 true, ptr %l11, !tbaa !21
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t255 = call { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %s0, ptr %t251, { i64, ptr } %t252)
  %t256 = extractvalue { i32, { i64, ptr } } %t255, 1
  %t257 = extractvalue { i32, { i64, ptr } } %t255, 0
  store i32 %t257, ptr %l105
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb46, label %ok.259
ok.259:
  store { i64, ptr } %t256, ptr %l104
  br label %bb45
bb45:
  %t260 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t260, ptr %l101, !tbaa !27
  br label %bb48
bb46:
  br label %bb47
bb47:
  store i1 false, ptr %l11, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d23 }, ptr %l101, !tbaa !27
  br label %bb48
bb48:
  %t261 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t262, i64 %t263)
  %t265 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  store { i64, ptr } %t266, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d24 }, ptr %l107, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t268, ptr %l108, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l109, !tbaa !24
  %t271 = load i64, ptr %l109, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l110, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l109, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t282, ptr %l13, !tbaa !27
  store i1 false, ptr %l14, !tbaa !21
  %t283 = load i1, ptr %l11, !tbaa !21
  br i1 %t283, label %bb49, label %bb50
bb49:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/fetch:Fetcher", ptr %t285, i32 0, i32 3
  %t288 = load i1, ptr %t287, !tbaa !21
  store i1 %t288, ptr %l112, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb51
bb51:
  %t290 = load i1, ptr %l112, !tbaa !21
  br i1 %t290, label %bb52, label %bb53
bb52:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t295 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %s0, ptr %t291, { i64, ptr } %t292, i1 false)
  store i1 %t295, ptr %l118
  br label %bb54
bb53:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb55
bb54:
  %t296 = load i1, ptr %l118, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l115, !tbaa !21
  br label %bb55
bb55:
  %t299 = load i1, ptr %l115, !tbaa !21
  br i1 %t299, label %bb56, label %bb57
bb56:
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t300)
  store i1 %t302, ptr %l121
  br label %bb58
bb57:
  br label %bb65
bb58:
  %t303 = load i1, ptr %l121, !tbaa !21
  br i1 %t303, label %bb59, label %bb60
bb59:
  %t304 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 1
  %t307 = extractvalue { i64, ptr } %t304, 0
  %t308 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t306, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l122, !tbaa !27
  br label %bb61
bb60:
  store { i64, ptr } { i64 0, ptr @.d25 }, ptr %l125, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t312, ptr %l122, !tbaa !27
  br label %bb61
bb61:
  %t314 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 0
  %t316 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l128, !tbaa !24
  %t319 = load i64, ptr %l128, !tbaa !24
  %t320 = icmp eq i64 %t315, %t319
  br i1 %t320, label %bb62, label %bb63
bb62:
  %t322 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = load i64, ptr %l128, !tbaa !24
  %t327 = mul i64 %t326, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t323, ptr %t325, i64 %t327, i1 false)
  br label %bb64
bb63:
  %t328 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t328, ptr %l13, !tbaa !27
  br label %bb64
bb64:
  store i1 true, ptr %l14, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  br label %bb65
bb65:
  %t329 = load i1, ptr %l11, !tbaa !21
  br i1 %t329, label %bb66, label %bb67
bb66:
  %t331 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t333 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t331)
  store i1 %t333, ptr %l133
  br label %bb68
bb67:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb69
bb68:
  %t334 = load i1, ptr %l133, !tbaa !21
  %t335 = xor i1 %t334, true
  store i1 %t335, ptr %l131, !tbaa !21
  br label %bb69
bb69:
  %t337 = load i1, ptr %l131, !tbaa !21
  br i1 %t337, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t339 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65537, 0
  store { i32, { i64, ptr } } %t339, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t340 = load i1, ptr %l11, !tbaa !21
  br i1 %t340, label %bb73, label %bb74
bb73:
  %t342 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t342, 1
  %t346 = extractvalue { i64, ptr } %t342, 0
  %t347 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t348 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t349 = add i64 %t346, %t348
  %t351 = extractvalue { i64, ptr } %t343, 1
  %t352 = extractvalue { i64, ptr } %t343, 0
  %t353 = add i64 %t349, %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t353)
  call void @olang_textcopy(ptr %t354, ptr %t345, i64 %t346)
  %t355 = getelementptr i8, ptr %t354, i64 %t346
  call void @olang_textcopy(ptr %t355, ptr %t347, i64 %t348)
  %t356 = getelementptr i8, ptr %t355, i64 %t348
  call void @olang_textcopy(ptr %t356, ptr %t351, i64 %t352)
  %t357 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t354, 1
  %t359 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t359, ptr %lp15
  %t361 = load ptr, ptr %lp15
  store { i64, ptr } %t358, ptr %t361, !tbaa !27
  %t362 = load ptr, ptr %lp15
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  %t365 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t363)
  store i1 %t365, ptr %l141
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t366 = load i1, ptr %l141, !tbaa !21
  br i1 %t366, label %bb76, label %bb77
bb76:
  %t367 = load ptr, ptr %lp15
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t370 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t368, 1
  store { i32, { i64, ptr } } %t370, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t371 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t373 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t371)
  store i32 %t373, ptr %l144
  %t374 = icmp ne i32 %t373, 0
  br i1 %t374, label %bb81, label %ok.375
ok.375:
  br label %bb80
bb80:
  br label %bb85
bb81:
  %t376 = load i32, ptr %l144, !tbaa !23
  %t377 = ashr i32 %t376, 16
  %t379 = icmp eq i32 %t377, 1
  br i1 %t379, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  %t381 = load i32, ptr %l144, !tbaa !23
  %t382 = lshr i32 %t381, 16
  %t383 = and i32 %t381, 65535
  %t384 = icmp eq i32 %t382, 1
  %t385 = select i1 %t384, i32 0, i32 0
  %t386 = icmp eq i32 %t381, 0
  %t387 = shl i32 %t385, 16
  %t388 = or i32 %t387, %t383
  %t389 = select i1 %t386, i32 0, i32 %t388
  call void @__olang_scope_close(ptr %s0)
  %t391 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t389, 0
  store { i32, { i64, ptr } } %t391, ptr %rv
  br label %ret
bb84:
  call void @__olang_scope_close(ptr %s0)
  %t393 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t393, ptr %rv
  br label %ret
bb85:
  %t394 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t396 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t394, { i64, ptr } { i64 7, ptr @.d27 })
  %t397 = extractvalue { i32, { i64, ptr } } %t396, 1
  %t398 = extractvalue { i32, { i64, ptr } } %t396, 0
  store i32 %t398, ptr %l152
  %t399 = icmp ne i32 %t398, 0
  br i1 %t399, label %bb87, label %ok.400
ok.400:
  store { i64, ptr } %t397, ptr %l151
  br label %bb86
bb86:
  %t401 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t401, ptr %l149, !tbaa !27
  br label %bb91
bb87:
  %t402 = load i32, ptr %l152, !tbaa !23
  %t403 = ashr i32 %t402, 16
  %t405 = icmp eq i32 %t403, 1
  br i1 %t405, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  %t407 = load i32, ptr %l152, !tbaa !23
  %t408 = lshr i32 %t407, 16
  %t409 = and i32 %t407, 65535
  %t410 = icmp eq i32 %t408, 1
  %t411 = select i1 %t410, i32 0, i32 0
  %t412 = icmp eq i32 %t407, 0
  %t413 = shl i32 %t411, 16
  %t414 = or i32 %t413, %t409
  %t415 = select i1 %t412, i32 0, i32 %t414
  call void @__olang_scope_close(ptr %s0)
  %t417 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t415, 0
  store { i32, { i64, ptr } } %t417, ptr %rv
  br label %ret
bb90:
  call void @__olang_scope_close(ptr %s0)
  %t419 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t419, ptr %rv
  br label %ret
bb91:
  %t420 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t420, ptr %l16, !tbaa !27
  %t421 = load i1, ptr %l11, !tbaa !21
  br i1 %t421, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s15
  %t423 = load ptr, ptr %l0, !tbaa !29
  store ptr %t423, ptr %l158, !tbaa !29
  %t424 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t424, ptr %l159, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t425, ptr %l160, !tbaa !27
  %t426 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t426, 0
  store i64 %t427, ptr %l161, !tbaa !24
  %t428 = icmp sge i64 0, 0
  br i1 %t428, label %bb94, label %bb95
bb93:
  br label %bb157
bb94:
  %t430 = icmp sle i64 0, 12
  br i1 %t430, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb96:
  %t432 = load i64, ptr %l161, !tbaa !24
  %t433 = icmp sle i64 12, %t432
  br i1 %t433, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb98:
  %t435 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr i8, ptr %t436, i64 0
  %t438 = sub i64 12, 0
  %t439 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t437, 1
  %t441 = extractvalue { i64, ptr } { i64 16, ptr @.d28 }, 1
  %t442 = extractvalue { i64, ptr } { i64 16, ptr @.d28 }, 0
  %t443 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t443, 1
  %t445 = extractvalue { i64, ptr } %t443, 0
  %t446 = add i64 %t442, %t445
  %t447 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 1
  %t448 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 0
  %t449 = add i64 %t446, %t448
  %t450 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 1
  %t452 = extractvalue { i64, ptr } %t450, 0
  %t453 = add i64 %t449, %t452
  %t454 = extractvalue { i64, ptr } { i64 4, ptr @.d30 }, 1
  %t455 = extractvalue { i64, ptr } { i64 4, ptr @.d30 }, 0
  %t456 = add i64 %t453, %t455
  %t458 = extractvalue { i64, ptr } %t440, 1
  %t459 = extractvalue { i64, ptr } %t440, 0
  %t460 = add i64 %t456, %t459
  %t461 = extractvalue { i64, ptr } { i64 20, ptr @.d31 }, 1
  %t462 = extractvalue { i64, ptr } { i64 20, ptr @.d31 }, 0
  %t463 = add i64 %t460, %t462
  %t464 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t463)
  call void @olang_textcopy(ptr %t464, ptr %t441, i64 %t442)
  %t465 = getelementptr i8, ptr %t464, i64 %t442
  call void @olang_textcopy(ptr %t465, ptr %t444, i64 %t445)
  %t466 = getelementptr i8, ptr %t465, i64 %t445
  call void @olang_textcopy(ptr %t466, ptr %t447, i64 %t448)
  %t467 = getelementptr i8, ptr %t466, i64 %t448
  call void @olang_textcopy(ptr %t467, ptr %t451, i64 %t452)
  %t468 = getelementptr i8, ptr %t467, i64 %t452
  call void @olang_textcopy(ptr %t468, ptr %t454, i64 %t455)
  %t469 = getelementptr i8, ptr %t468, i64 %t455
  call void @olang_textcopy(ptr %t469, ptr %t458, i64 %t459)
  %t470 = getelementptr i8, ptr %t469, i64 %t459
  call void @olang_textcopy(ptr %t470, ptr %t461, i64 %t462)
  %t471 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t464, 1
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t475 = extractvalue { i64, ptr } %t472, 1
  %t476 = mul i64 %t474, 1
  %t477 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t476)
  call void @llvm.memcpy.p0.p0.i64(ptr %t477, ptr %t475, i64 %t476, i1 false)
  %t478 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t477, 1
  %t480 = load ptr, ptr %l158, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s15, ptr %t480, { i64, ptr } %t479)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb100:
  %t482 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t483 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t482, 1
  %t486 = extractvalue { i64, ptr } %t482, 0
  %t487 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t488 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  %t489 = add i64 %t486, %t488
  %t491 = extractvalue { i64, ptr } %t483, 1
  %t492 = extractvalue { i64, ptr } %t483, 0
  %t493 = add i64 %t489, %t492
  %t494 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t493)
  call void @olang_textcopy(ptr %t494, ptr %t485, i64 %t486)
  %t495 = getelementptr i8, ptr %t494, i64 %t486
  call void @olang_textcopy(ptr %t495, ptr %t487, i64 %t488)
  %t496 = getelementptr i8, ptr %t495, i64 %t488
  call void @olang_textcopy(ptr %t496, ptr %t491, i64 %t492)
  %t497 = insertvalue { i64, ptr } undef, i64 %t493, 0
  %t498 = insertvalue { i64, ptr } %t497, ptr %t494, 1
  %t499 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t499, ptr %lp17
  %t501 = load ptr, ptr %lp17
  store { i64, ptr } %t498, ptr %t501, !tbaa !27
  %t502 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t503 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d33 }, 0
  %t504 = insertvalue [4 x { i64, ptr }] %t503, { i64, ptr } { i64 4, ptr @.d34 }, 1
  %t505 = insertvalue [4 x { i64, ptr }] %t504, { i64, ptr } { i64 2, ptr @.d35 }, 2
  %t507 = insertvalue [4 x { i64, ptr }] %t505, { i64, ptr } %t502, 3
  %t509 = load ptr, ptr @__olang_prog_scope
  %t510 = call ptr @__olang_scope_alloc(ptr %t509, i64 64)
  store [4 x { i64, ptr }] %t507, ptr %t510
  %t511 = insertvalue { i64, ptr } undef, i64 4, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = extractvalue { i64, ptr } %t512, 1
  %t516 = mul i64 %t514, 16
  %t517 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t516)
  call void @llvm.memcpy.p0.p0.i64(ptr %t517, ptr %t515, i64 %t516, i1 false)
  %t518 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t517, 1
  %t521 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t519)
  store i1 %t521, ptr %l175
  br label %bb101
bb101:
  %t522 = load i1, ptr %l175, !tbaa !21
  br i1 %t522, label %bb102, label %bb103
bb102:
  %t523 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t524 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t525 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t526 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr @.d36 }, ptr %t526, !tbaa !37
  %t527 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 1
  store { i64, ptr } { i64 2, ptr @.d37 }, ptr %t527, !tbaa !37
  %t528 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 2
  store { i64, ptr } %t523, ptr %t528, !tbaa !37
  %t530 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 3
  store { i64, ptr } { i64 5, ptr @.d38 }, ptr %t530, !tbaa !37
  %t531 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr @.d39 }, ptr %t531, !tbaa !37
  %t532 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 5
  store { i64, ptr } { i64 7, ptr @.d40 }, ptr %t532, !tbaa !37
  %t533 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 6
  store { i64, ptr } { i64 1, ptr @.d41 }, ptr %t533, !tbaa !37
  %t534 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr @.d42 }, ptr %t534, !tbaa !37
  %t535 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 8
  store { i64, ptr } %t524, ptr %t535, !tbaa !37
  %t537 = getelementptr [10 x { i64, ptr }], ptr %l180, i64 0, i64 9
  store { i64, ptr } %t525, ptr %t537, !tbaa !37
  %t539 = load [10 x { i64, ptr }], ptr %l180
  %t540 = load ptr, ptr @__olang_prog_scope
  %t541 = call ptr @__olang_scope_alloc(ptr %t540, i64 160)
  store [10 x { i64, ptr }] %t539, ptr %t541
  %t542 = insertvalue { i64, ptr } undef, i64 10, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t541, 1
  %t545 = extractvalue { i64, ptr } %t543, 0
  %t546 = extractvalue { i64, ptr } %t543, 1
  %t547 = mul i64 %t545, 16
  %t548 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t547)
  call void @llvm.memcpy.p0.p0.i64(ptr %t548, ptr %t546, i64 %t547, i1 false)
  %t549 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t548, 1
  %t552 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t550)
  store i1 %t552, ptr %l183
  br label %bb104
bb103:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb105
bb104:
  %t553 = load i1, ptr %l183, !tbaa !21
  store i1 %t553, ptr %l176, !tbaa !21
  br label %bb105
bb105:
  %t554 = load i1, ptr %l176, !tbaa !21
  br i1 %t554, label %bb106, label %bb107
bb106:
  %t555 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t556 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d43 }, 0
  %t557 = insertvalue [6 x { i64, ptr }] %t556, { i64, ptr } { i64 2, ptr @.d44 }, 1
  %t559 = insertvalue [6 x { i64, ptr }] %t557, { i64, ptr } %t555, 2
  %t560 = insertvalue [6 x { i64, ptr }] %t559, { i64, ptr } { i64 8, ptr @.d45 }, 3
  %t561 = insertvalue [6 x { i64, ptr }] %t560, { i64, ptr } { i64 2, ptr @.d46 }, 4
  %t562 = insertvalue [6 x { i64, ptr }] %t561, { i64, ptr } { i64 10, ptr @.d47 }, 5
  %t564 = load ptr, ptr @__olang_prog_scope
  %t565 = call ptr @__olang_scope_alloc(ptr %t564, i64 96)
  store [6 x { i64, ptr }] %t562, ptr %t565
  %t566 = insertvalue { i64, ptr } undef, i64 6, 0
  %t567 = insertvalue { i64, ptr } %t566, ptr %t565, 1
  %t569 = extractvalue { i64, ptr } %t567, 0
  %t570 = extractvalue { i64, ptr } %t567, 1
  %t571 = mul i64 %t569, 16
  %t572 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t571)
  call void @llvm.memcpy.p0.p0.i64(ptr %t572, ptr %t570, i64 %t571, i1 false)
  %t573 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t572, 1
  %t576 = call i1 @compiler_2ffetch_2egit(ptr %s15, { i64, ptr } %t574)
  store i1 %t576, ptr %l189
  br label %bb108
bb107:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb109
bb108:
  %t577 = load i1, ptr %l189, !tbaa !21
  store i1 %t577, ptr %l184, !tbaa !21
  br label %bb109
bb109:
  %t578 = load i1, ptr %l184, !tbaa !21
  %t581 = xor i1 %t578, true
  br i1 %t581, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s18
  %t583 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t585 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t583)
  store i32 %t585, ptr %l193
  %t586 = icmp ne i32 %t585, 0
  br i1 %t586, label %bb113, label %ok.587
ok.587:
  br label %bb112
bb111:
  br label %bb123
bb112:
  br label %bb117
bb113:
  %t588 = load i32, ptr %l193, !tbaa !23
  %t589 = ashr i32 %t588, 16
  %t591 = icmp eq i32 %t589, 1
  br i1 %t591, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  %t593 = load i32, ptr %l193, !tbaa !23
  %t594 = lshr i32 %t593, 16
  %t595 = and i32 %t593, 65535
  %t596 = icmp eq i32 %t594, 1
  %t597 = select i1 %t596, i32 0, i32 0
  %t598 = icmp eq i32 %t593, 0
  %t599 = shl i32 %t597, 16
  %t600 = or i32 %t599, %t595
  %t601 = select i1 %t598, i32 0, i32 %t600
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t603 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t601, 0
  store { i32, { i64, ptr } } %t603, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t604 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t605 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t606 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d48 }, 0
  %t607 = insertvalue [6 x { i64, ptr }] %t606, { i64, ptr } { i64 5, ptr @.d49 }, 1
  %t608 = insertvalue [6 x { i64, ptr }] %t607, { i64, ptr } { i64 2, ptr @.d50 }, 2
  %t609 = insertvalue [6 x { i64, ptr }] %t608, { i64, ptr } { i64 2, ptr @.d51 }, 3
  %t611 = insertvalue [6 x { i64, ptr }] %t609, { i64, ptr } %t604, 4
  %t613 = insertvalue [6 x { i64, ptr }] %t611, { i64, ptr } %t605, 5
  %t615 = load ptr, ptr @__olang_prog_scope
  %t616 = call ptr @__olang_scope_alloc(ptr %t615, i64 96)
  store [6 x { i64, ptr }] %t613, ptr %t616
  %t617 = insertvalue { i64, ptr } undef, i64 6, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t616, 1
  %t620 = extractvalue { i64, ptr } %t618, 0
  %t621 = extractvalue { i64, ptr } %t618, 1
  %t622 = mul i64 %t620, 16
  %t623 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t622)
  call void @llvm.memcpy.p0.p0.i64(ptr %t623, ptr %t621, i64 %t622, i1 false)
  %t624 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  %t627 = call i1 @compiler_2ffetch_2egit(ptr %s18, { i64, ptr } %t625)
  store i1 %t627, ptr %l202
  br label %bb118
bb118:
  %t628 = load i1, ptr %l202, !tbaa !21
  br i1 %t628, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s20
  %t629 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t630 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t631 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d52 }, 0
  %t632 = insertvalue [6 x { i64, ptr }] %t631, { i64, ptr } { i64 2, ptr @.d53 }, 1
  %t634 = insertvalue [6 x { i64, ptr }] %t632, { i64, ptr } %t629, 2
  %t635 = insertvalue [6 x { i64, ptr }] %t634, { i64, ptr } { i64 8, ptr @.d54 }, 3
  %t636 = insertvalue [6 x { i64, ptr }] %t635, { i64, ptr } { i64 2, ptr @.d55 }, 4
  %t638 = insertvalue [6 x { i64, ptr }] %t636, { i64, ptr } %t630, 5
  %t640 = load ptr, ptr @__olang_prog_scope
  %t641 = call ptr @__olang_scope_alloc(ptr %t640, i64 96)
  store [6 x { i64, ptr }] %t638, ptr %t641
  %t642 = insertvalue { i64, ptr } undef, i64 6, 0
  %t643 = insertvalue { i64, ptr } %t642, ptr %t641, 1
  %t645 = extractvalue { i64, ptr } %t643, 0
  %t646 = extractvalue { i64, ptr } %t643, 1
  %t647 = mul i64 %t645, 16
  %t648 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t647)
  call void @llvm.memcpy.p0.p0.i64(ptr %t648, ptr %t646, i64 %t647, i1 false)
  %t649 = insertvalue { i64, ptr } undef, i64 %t645, 0
  %t650 = insertvalue { i64, ptr } %t649, ptr %t648, 1
  %t652 = call i1 @compiler_2ffetch_2egit(ptr %s20, { i64, ptr } %t650)
  store i1 %t652, ptr %l208
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s20)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s18)
  br label %bb123
bb123:
  %t653 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t655 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s15, { i64, ptr } %t653)
  store { i64, ptr } %t655, ptr %l210
  br label %bb124
bb124:
  %t656 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t657 = extractvalue { i64, ptr } %t656, 0
  %t658 = extractvalue { i64, ptr } %t656, 1
  %t659 = mul i64 %t657, 1
  %t660 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t659)
  call void @llvm.memcpy.p0.p0.i64(ptr %t660, ptr %t658, i64 %t659, i1 false)
  %t661 = insertvalue { i64, ptr } undef, i64 %t657, 0
  %t662 = insertvalue { i64, ptr } %t661, ptr %t660, 1
  %t663 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t666 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s0, { i64, ptr } %t662, { i64, ptr } %t663)
  store i1 %t666, ptr %l213
  br label %bb125
bb125:
  %t667 = load i1, ptr %l213, !tbaa !21
  %t668 = xor i1 %t667, true
  br i1 %t668, label %bb126, label %bb127
bb126:
  %t670 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t672 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t670)
  store i32 %t672, ptr %l216
  %t673 = icmp ne i32 %t672, 0
  br i1 %t673, label %bb129, label %ok.674
ok.674:
  br label %bb128
bb127:
  br label %bb134
bb128:
  br label %bb133
bb129:
  %t675 = load i32, ptr %l216, !tbaa !23
  %t676 = ashr i32 %t675, 16
  %t678 = icmp eq i32 %t676, 1
  br i1 %t678, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  %t680 = load i32, ptr %l216, !tbaa !23
  %t681 = lshr i32 %t680, 16
  %t682 = and i32 %t680, 65535
  %t683 = icmp eq i32 %t681, 1
  %t684 = select i1 %t683, i32 0, i32 0
  %t685 = icmp eq i32 %t680, 0
  %t686 = shl i32 %t684, 16
  %t687 = or i32 %t686, %t682
  %t688 = select i1 %t685, i32 0, i32 %t687
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t690 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t688, 0
  store { i32, { i64, ptr } } %t690, ptr %rv
  br label %ret
bb132:
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t692 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65539, 0
  store { i32, { i64, ptr } } %t692, ptr %rv
  br label %ret
bb134:
  %t693 = load ptr, ptr %lp17
  %t694 = load { i64, ptr }, ptr %t693, !tbaa !27
  %t696 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t694)
  store i1 %t696, ptr %l222
  br label %bb135
bb135:
  %t697 = load i1, ptr %l222, !tbaa !21
  %t698 = xor i1 %t697, true
  br i1 %t698, label %bb136, label %bb137
bb136:
  %t700 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t701 = load ptr, ptr %lp17
  %t702 = load { i64, ptr }, ptr %t701, !tbaa !27
  %t705 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t700, { i64, ptr } %t702)
  store i32 %t705, ptr %l226
  %t706 = icmp ne i32 %t705, 0
  br i1 %t706, label %bb139, label %ok.707
ok.707:
  br label %bb138
bb137:
  br label %bb150
bb138:
  br label %bb149
bb139:
  %t708 = load i32, ptr %l226, !tbaa !23
  %t709 = ashr i32 %t708, 16
  %t711 = icmp eq i32 %t709, 1
  br i1 %t711, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  %t713 = load i32, ptr %l226, !tbaa !23
  %t714 = lshr i32 %t713, 16
  %t715 = and i32 %t713, 65535
  %t716 = icmp eq i32 %t714, 1
  %t717 = select i1 %t716, i32 0, i32 0
  %t718 = icmp eq i32 %t713, 0
  %t719 = shl i32 %t717, 16
  %t720 = or i32 %t719, %t715
  %t721 = select i1 %t718, i32 0, i32 %t720
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t723 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t721, 0
  store { i32, { i64, ptr } } %t723, ptr %rv
  br label %ret
bb142:
  %t724 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t726 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t724)
  store i32 %t726, ptr %l231
  %t727 = icmp ne i32 %t726, 0
  br i1 %t727, label %bb144, label %ok.728
ok.728:
  br label %bb143
bb143:
  br label %bb148
bb144:
  %t729 = load i32, ptr %l231, !tbaa !23
  %t730 = ashr i32 %t729, 16
  %t732 = icmp eq i32 %t730, 1
  br i1 %t732, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  %t734 = load i32, ptr %l231, !tbaa !23
  %t735 = lshr i32 %t734, 16
  %t736 = and i32 %t734, 65535
  %t737 = icmp eq i32 %t735, 1
  %t738 = select i1 %t737, i32 0, i32 0
  %t739 = icmp eq i32 %t734, 0
  %t740 = shl i32 %t738, 16
  %t741 = or i32 %t740, %t736
  %t742 = select i1 %t739, i32 0, i32 %t741
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t744 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t742, 0
  store { i32, { i64, ptr } } %t744, ptr %rv
  br label %ret
bb147:
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t746 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65539, 0
  store { i32, { i64, ptr } } %t746, ptr %rv
  br label %ret
bb149:
  br label %bb150
bb150:
  %t747 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t749 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t747)
  store i32 %t749, ptr %l237
  %t750 = icmp ne i32 %t749, 0
  br i1 %t750, label %bb152, label %ok.751
ok.751:
  br label %bb151
bb151:
  br label %bb156
bb152:
  %t752 = load i32, ptr %l237, !tbaa !23
  %t753 = ashr i32 %t752, 16
  %t755 = icmp eq i32 %t753, 1
  br i1 %t755, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  %t757 = load i32, ptr %l237, !tbaa !23
  %t758 = lshr i32 %t757, 16
  %t759 = and i32 %t757, 65535
  %t760 = icmp eq i32 %t758, 1
  %t761 = select i1 %t760, i32 0, i32 0
  %t762 = icmp eq i32 %t757, 0
  %t763 = shl i32 %t761, 16
  %t764 = or i32 %t763, %t759
  %t765 = select i1 %t762, i32 0, i32 %t764
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t767 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t765, 0
  store { i32, { i64, ptr } } %t767, ptr %rv
  br label %ret
bb155:
  br label %bb156
bb156:
  %t768 = load ptr, ptr %lp17
  %t769 = load { i64, ptr }, ptr %t768, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t771 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t769, 1
  store { i32, { i64, ptr } } %t771, ptr %rv
  br label %ret
bb157:
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t773 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t774 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t775 = extractvalue { i64, ptr } { i64 16, ptr @.d56 }, 1
  %t776 = extractvalue { i64, ptr } { i64 16, ptr @.d56 }, 0
  %t778 = extractvalue { i64, ptr } %t773, 1
  %t779 = extractvalue { i64, ptr } %t773, 0
  %t780 = add i64 %t776, %t779
  %t781 = extractvalue { i64, ptr } { i64 6, ptr @.d57 }, 1
  %t782 = extractvalue { i64, ptr } { i64 6, ptr @.d57 }, 0
  %t783 = add i64 %t780, %t782
  %t785 = extractvalue { i64, ptr } %t774, 1
  %t786 = extractvalue { i64, ptr } %t774, 0
  %t787 = add i64 %t783, %t786
  %t788 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t787)
  call void @olang_textcopy(ptr %t788, ptr %t775, i64 %t776)
  %t789 = getelementptr i8, ptr %t788, i64 %t776
  call void @olang_textcopy(ptr %t789, ptr %t778, i64 %t779)
  %t790 = getelementptr i8, ptr %t789, i64 %t779
  call void @olang_textcopy(ptr %t790, ptr %t781, i64 %t782)
  %t791 = getelementptr i8, ptr %t790, i64 %t782
  call void @olang_textcopy(ptr %t791, ptr %t785, i64 %t786)
  %t792 = insertvalue { i64, ptr } undef, i64 %t787, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t788, 1
  %t795 = extractvalue { i64, ptr } %t793, 0
  %t796 = extractvalue { i64, ptr } %t793, 1
  %t797 = mul i64 %t795, 1
  %t798 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t797)
  call void @llvm.memcpy.p0.p0.i64(ptr %t798, ptr %t796, i64 %t797, i1 false)
  %t799 = insertvalue { i64, ptr } undef, i64 %t795, 0
  %t800 = insertvalue { i64, ptr } %t799, ptr %t798, 1
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s0, ptr %t772, { i64, ptr } %t800)
  br label %bb158
bb158:
  %t803 = load i64, ptr %l4, !tbaa !24
  %t804 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t806 = extractvalue { i64, ptr } %t804, 0
  %t809 = icmp slt i64 %t803, %t806
  br i1 %t809, label %bb159, label %bb160
bb159:
  %t811 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t812 = extractvalue { i64, ptr } { i64 9, ptr @.d58 }, 1
  %t813 = extractvalue { i64, ptr } { i64 9, ptr @.d58 }, 0
  %t815 = extractvalue { i64, ptr } %t811, 1
  %t816 = extractvalue { i64, ptr } %t811, 0
  %t817 = add i64 %t813, %t816
  %t818 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t817)
  call void @olang_textcopy(ptr %t818, ptr %t812, i64 %t813)
  %t819 = getelementptr i8, ptr %t818, i64 %t813
  call void @olang_textcopy(ptr %t819, ptr %t815, i64 %t816)
  %t820 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t818, 1
  %t823 = extractvalue { i64, ptr } %t821, 0
  %t824 = extractvalue { i64, ptr } %t821, 1
  %t825 = mul i64 %t823, 1
  %t826 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t825)
  call void @llvm.memcpy.p0.p0.i64(ptr %t826, ptr %t824, i64 %t825, i1 false)
  %t827 = insertvalue { i64, ptr } undef, i64 %t823, 0
  %t828 = insertvalue { i64, ptr } %t827, ptr %t826, 1
  store { i64, ptr } %t828, ptr %l251, !tbaa !27
  br label %bb161
bb160:
  store { i64, ptr } { i64 7, ptr @.d59 }, ptr %l251, !tbaa !27
  br label %bb161
bb161:
  %t830 = load { i64, ptr }, ptr %l251, !tbaa !27
  store { i64, ptr } %t830, ptr %l19, !tbaa !27
  %t831 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t833 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t831)
  store i32 %t833, ptr %l256
  %t834 = icmp ne i32 %t833, 0
  br i1 %t834, label %bb163, label %ok.835
ok.835:
  br label %bb162
bb162:
  br label %bb167
bb163:
  %t836 = load i32, ptr %l256, !tbaa !23
  %t837 = ashr i32 %t836, 16
  %t839 = icmp eq i32 %t837, 1
  br i1 %t839, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  %t841 = load i32, ptr %l256, !tbaa !23
  %t842 = lshr i32 %t841, 16
  %t843 = and i32 %t841, 65535
  %t844 = icmp eq i32 %t842, 1
  %t845 = select i1 %t844, i32 0, i32 0
  %t846 = icmp eq i32 %t841, 0
  %t847 = shl i32 %t845, 16
  %t848 = or i32 %t847, %t843
  %t849 = select i1 %t846, i32 0, i32 %t848
  call void @__olang_scope_close(ptr %s0)
  %t851 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t849, 0
  store { i32, { i64, ptr } } %t851, ptr %rv
  br label %ret
bb166:
  br label %bb167
bb167:
  store { i64, ptr } { i64 0, ptr @.d60 }, ptr %l260, !tbaa !27
  %t852 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t852, ptr %l261, !tbaa !27
  %t853 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t854 = extractvalue { i64, ptr } %t853, 0
  store i64 %t854, ptr %l262, !tbaa !24
  %t855 = load i64, ptr %l262, !tbaa !24
  %t856 = mul i64 %t855, 1
  %t857 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t856)
  %t858 = insertvalue { i64, ptr } undef, i64 %t855, 0
  %t859 = insertvalue { i64, ptr } %t858, ptr %t857, 1
  store { i64, ptr } %t859, ptr %l263, !tbaa !27
  %t860 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t861 = load ptr, ptr %t860, !tbaa !27
  %t862 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t863 = load ptr, ptr %t862, !tbaa !27
  %t864 = load i64, ptr %l262, !tbaa !24
  %t865 = mul i64 %t864, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t861, ptr %t863, i64 %t865, i1 false)
  %t866 = load { i64, ptr }, ptr %l263, !tbaa !27
  store { i64, ptr } %t866, ptr %l20, !tbaa !27
  %t867 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t868 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t869 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t870 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr @.d61 }, ptr %t870, !tbaa !37
  %t871 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 1
  store { i64, ptr } { i64 5, ptr @.d62 }, ptr %t871, !tbaa !37
  %t872 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 2
  store { i64, ptr } { i64 7, ptr @.d63 }, ptr %t872, !tbaa !37
  %t873 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 3
  store { i64, ptr } { i64 7, ptr @.d64 }, ptr %t873, !tbaa !37
  %t874 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 4
  store { i64, ptr } { i64 1, ptr @.d65 }, ptr %t874, !tbaa !37
  %t875 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 5
  store { i64, ptr } %t867, ptr %t875, !tbaa !37
  %t877 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 6
  store { i64, ptr } { i64 2, ptr @.d66 }, ptr %t877, !tbaa !37
  %t878 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 7
  store { i64, ptr } %t868, ptr %t878, !tbaa !37
  %t880 = getelementptr [9 x { i64, ptr }], ptr %l267, i64 0, i64 8
  store { i64, ptr } %t869, ptr %t880, !tbaa !37
  %t882 = load [9 x { i64, ptr }], ptr %l267
  %t883 = load ptr, ptr @__olang_prog_scope
  %t884 = call ptr @__olang_scope_alloc(ptr %t883, i64 144)
  store [9 x { i64, ptr }] %t882, ptr %t884
  %t885 = insertvalue { i64, ptr } undef, i64 9, 0
  %t886 = insertvalue { i64, ptr } %t885, ptr %t884, 1
  %t888 = extractvalue { i64, ptr } %t886, 0
  %t889 = extractvalue { i64, ptr } %t886, 1
  %t890 = mul i64 %t888, 16
  %t891 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t890)
  call void @llvm.memcpy.p0.p0.i64(ptr %t891, ptr %t889, i64 %t890, i1 false)
  %t892 = insertvalue { i64, ptr } undef, i64 %t888, 0
  %t893 = insertvalue { i64, ptr } %t892, ptr %t891, 1
  %t895 = call i1 @compiler_2ffetch_2egit(ptr %s0, { i64, ptr } %t893)
  store i1 %t895, ptr %l270
  br label %bb168
bb168:
  %t896 = load i1, ptr %l270, !tbaa !21
  br i1 %t896, label %bb169, label %bb170
bb169:
  %t897 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t899 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s0, { i64, ptr } %t897)
  store { i64, ptr } %t899, ptr %l272
  br label %bb171
bb170:
  br label %bb175
bb171:
  %t900 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t901 = extractvalue { i64, ptr } %t900, 0
  %t902 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t903 = extractvalue { i64, ptr } %t902, 0
  store i64 %t903, ptr %l274, !tbaa !24
  %t905 = load i64, ptr %l274, !tbaa !24
  %t906 = icmp eq i64 %t901, %t905
  br i1 %t906, label %bb172, label %bb173
bb172:
  %t908 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t909 = load ptr, ptr %t908, !tbaa !27
  %t910 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t911 = load ptr, ptr %t910, !tbaa !27
  %t912 = load i64, ptr %l274, !tbaa !24
  %t913 = mul i64 %t912, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t909, ptr %t911, i64 %t913, i1 false)
  br label %bb174
bb173:
  %t914 = load { i64, ptr }, ptr %l272, !tbaa !27
  store { i64, ptr } %t914, ptr %l20, !tbaa !27
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t915 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t917 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t915, { i64, ptr } { i64 0, ptr @.d67 })
  store i1 %t917, ptr %l277
  br label %bb176
bb176:
  %t918 = load i1, ptr %l277, !tbaa !21
  br i1 %t918, label %bb177, label %bb178
bb177:
  %t919 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t921 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t919)
  store i32 %t921, ptr %l279
  %t922 = icmp ne i32 %t921, 0
  br i1 %t922, label %bb180, label %ok.923
ok.923:
  br label %bb179
bb178:
  br label %bb185
bb179:
  br label %bb184
bb180:
  %t924 = load i32, ptr %l279, !tbaa !23
  %t925 = ashr i32 %t924, 16
  %t927 = icmp eq i32 %t925, 1
  br i1 %t927, label %bb181, label %bb182
bb181:
  br label %bb183
bb182:
  %t929 = load i32, ptr %l279, !tbaa !23
  %t930 = lshr i32 %t929, 16
  %t931 = and i32 %t929, 65535
  %t932 = icmp eq i32 %t930, 1
  %t933 = select i1 %t932, i32 0, i32 0
  %t934 = icmp eq i32 %t929, 0
  %t935 = shl i32 %t933, 16
  %t936 = or i32 %t935, %t931
  %t937 = select i1 %t934, i32 0, i32 %t936
  call void @__olang_scope_close(ptr %s0)
  %t939 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t937, 0
  store { i32, { i64, ptr } } %t939, ptr %rv
  br label %ret
bb183:
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s0)
  %t941 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t941, ptr %rv
  br label %ret
bb185:
  %t942 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t943 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t945 = extractvalue { i64, ptr } %t942, 1
  %t946 = extractvalue { i64, ptr } %t942, 0
  %t947 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t948 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t949 = add i64 %t946, %t948
  %t951 = extractvalue { i64, ptr } %t943, 1
  %t952 = extractvalue { i64, ptr } %t943, 0
  %t953 = add i64 %t949, %t952
  %t954 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t953)
  call void @olang_textcopy(ptr %t954, ptr %t945, i64 %t946)
  %t955 = getelementptr i8, ptr %t954, i64 %t946
  call void @olang_textcopy(ptr %t955, ptr %t947, i64 %t948)
  %t956 = getelementptr i8, ptr %t955, i64 %t948
  call void @olang_textcopy(ptr %t956, ptr %t951, i64 %t952)
  %t957 = insertvalue { i64, ptr } undef, i64 %t953, 0
  %t958 = insertvalue { i64, ptr } %t957, ptr %t954, 1
  %t959 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t959, ptr %lp21
  %t961 = load ptr, ptr %lp21
  store { i64, ptr } %t958, ptr %t961, !tbaa !27
  %t962 = load ptr, ptr %lp21
  %t963 = load { i64, ptr }, ptr %t962, !tbaa !27
  %t965 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t963)
  store i1 %t965, ptr %l288
  br label %bb186
bb186:
  %t966 = load i1, ptr %l288, !tbaa !21
  br i1 %t966, label %bb187, label %bb188
bb187:
  %t967 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t969 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t967)
  store i32 %t969, ptr %l290
  %t970 = icmp ne i32 %t969, 0
  br i1 %t970, label %bb190, label %ok.971
ok.971:
  br label %bb189
bb188:
  %t972 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t973 = load ptr, ptr %lp21
  %t974 = load { i64, ptr }, ptr %t973, !tbaa !27
  %t977 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t972, { i64, ptr } %t974)
  store i32 %t977, ptr %l296
  %t978 = icmp ne i32 %t977, 0
  br i1 %t978, label %bb196, label %ok.979
ok.979:
  br label %bb195
bb189:
  br label %bb194
bb190:
  %t980 = load i32, ptr %l290, !tbaa !23
  %t981 = ashr i32 %t980, 16
  %t983 = icmp eq i32 %t981, 1
  br i1 %t983, label %bb191, label %bb192
bb191:
  br label %bb193
bb192:
  %t985 = load i32, ptr %l290, !tbaa !23
  %t986 = lshr i32 %t985, 16
  %t987 = and i32 %t985, 65535
  %t988 = icmp eq i32 %t986, 1
  %t989 = select i1 %t988, i32 0, i32 0
  %t990 = icmp eq i32 %t985, 0
  %t991 = shl i32 %t989, 16
  %t992 = or i32 %t991, %t987
  %t993 = select i1 %t990, i32 0, i32 %t992
  call void @__olang_scope_close(ptr %s0)
  %t995 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t993, 0
  store { i32, { i64, ptr } } %t995, ptr %rv
  br label %ret
bb193:
  br label %bb194
bb194:
  br label %bb207
bb195:
  br label %bb206
bb196:
  %t996 = load i32, ptr %l296, !tbaa !23
  %t997 = ashr i32 %t996, 16
  %t999 = icmp eq i32 %t997, 1
  br i1 %t999, label %bb197, label %bb198
bb197:
  br label %bb199
bb198:
  %t1001 = load i32, ptr %l296, !tbaa !23
  %t1002 = lshr i32 %t1001, 16
  %t1003 = and i32 %t1001, 65535
  %t1004 = icmp eq i32 %t1002, 1
  %t1005 = select i1 %t1004, i32 0, i32 0
  %t1006 = icmp eq i32 %t1001, 0
  %t1007 = shl i32 %t1005, 16
  %t1008 = or i32 %t1007, %t1003
  %t1009 = select i1 %t1006, i32 0, i32 %t1008
  call void @__olang_scope_close(ptr %s0)
  %t1011 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t1009, 0
  store { i32, { i64, ptr } } %t1011, ptr %rv
  br label %ret
bb199:
  %t1012 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t1014 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t1012)
  store i32 %t1014, ptr %l301
  %t1015 = icmp ne i32 %t1014, 0
  br i1 %t1015, label %bb201, label %ok.1016
ok.1016:
  br label %bb200
bb200:
  br label %bb205
bb201:
  %t1017 = load i32, ptr %l301, !tbaa !23
  %t1018 = ashr i32 %t1017, 16
  %t1020 = icmp eq i32 %t1018, 1
  br i1 %t1020, label %bb202, label %bb203
bb202:
  br label %bb204
bb203:
  %t1022 = load i32, ptr %l301, !tbaa !23
  %t1023 = lshr i32 %t1022, 16
  %t1024 = and i32 %t1022, 65535
  %t1025 = icmp eq i32 %t1023, 1
  %t1026 = select i1 %t1025, i32 0, i32 0
  %t1027 = icmp eq i32 %t1022, 0
  %t1028 = shl i32 %t1026, 16
  %t1029 = or i32 %t1028, %t1024
  %t1030 = select i1 %t1027, i32 0, i32 %t1029
  call void @__olang_scope_close(ptr %s0)
  %t1032 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t1030, 0
  store { i32, { i64, ptr } } %t1032, ptr %rv
  br label %ret
bb204:
  br label %bb205
bb205:
  call void @__olang_scope_close(ptr %s0)
  %t1034 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t1034, ptr %rv
  br label %ret
bb206:
  br label %bb207
bb207:
  %t1035 = load ptr, ptr %l0, !tbaa !29
  %t1036 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1037 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %s0, ptr %s0, ptr %t1035, { i64, ptr } %t1036, { i64, ptr } %t1037)
  br label %bb208
bb208:
  %t1041 = load ptr, ptr %l0, !tbaa !29
  %t1043 = getelementptr %"compiler/fetch:Fetcher", ptr %t1041, i32 0, i32 3
  %t1044 = load i1, ptr %t1043, !tbaa !21
  br i1 %t1044, label %bb209, label %bb210
bb209:
  store %olang.scope zeroinitializer, ptr %s39
  %t1046 = load ptr, ptr %l0, !tbaa !29
  %t1047 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1050 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %s0, ptr %t1046, { i64, ptr } %t1047, i1 true)
  store i1 %t1050, ptr %l313
  br label %bb211
bb210:
  br label %bb256
bb211:
  %t1051 = load i1, ptr %l14, !tbaa !21
  br i1 %t1051, label %bb212, label %bb213
bb212:
  %t1053 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1055 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t1053, { i64, ptr } { i64 0, ptr @.d69 })
  store i1 %t1055, ptr %l317
  br label %bb214
bb213:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb215
bb214:
  %t1056 = load i1, ptr %l317, !tbaa !21
  store i1 %t1056, ptr %l315, !tbaa !21
  br label %bb215
bb215:
  %t1057 = load i1, ptr %l315, !tbaa !21
  br i1 %t1057, label %bb216, label %bb217
bb216:
  store %olang.scope zeroinitializer, ptr %s40
  %t1058 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1058, ptr %l318, !tbaa !29
  %t1059 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1059, ptr %l319, !tbaa !27
  %t1060 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1061 = extractvalue { i64, ptr } %t1060, 0
  store i64 %t1061, ptr %l320, !tbaa !24
  %t1062 = icmp sge i64 0, 0
  br i1 %t1062, label %bb218, label %bb219
bb217:
  %t1064 = load i1, ptr %l14, !tbaa !21
  br i1 %t1064, label %bb225, label %bb226
bb218:
  %t1066 = icmp sle i64 0, 12
  br i1 %t1066, label %bb220, label %bb221
bb219:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb220:
  %t1068 = load i64, ptr %l320, !tbaa !24
  %t1069 = icmp sle i64 12, %t1068
  br i1 %t1069, label %bb222, label %bb223
bb221:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb222:
  %t1071 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1072 = load ptr, ptr %t1071, !tbaa !27
  %t1073 = getelementptr i8, ptr %t1072, i64 0
  %t1074 = sub i64 12, 0
  %t1075 = insertvalue { i64, ptr } undef, i64 %t1074, 0
  %t1076 = insertvalue { i64, ptr } %t1075, ptr %t1073, 1
  %t1077 = extractvalue { i64, ptr } { i64 15, ptr @.d70 }, 1
  %t1078 = extractvalue { i64, ptr } { i64 15, ptr @.d70 }, 0
  %t1079 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t1080 = extractvalue { i64, ptr } %t1079, 1
  %t1081 = extractvalue { i64, ptr } %t1079, 0
  %t1082 = add i64 %t1078, %t1081
  %t1083 = extractvalue { i64, ptr } { i64 4, ptr @.d71 }, 1
  %t1084 = extractvalue { i64, ptr } { i64 4, ptr @.d71 }, 0
  %t1085 = add i64 %t1082, %t1084
  %t1087 = extractvalue { i64, ptr } %t1076, 1
  %t1088 = extractvalue { i64, ptr } %t1076, 0
  %t1089 = add i64 %t1085, %t1088
  %t1090 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1089)
  call void @olang_textcopy(ptr %t1090, ptr %t1077, i64 %t1078)
  %t1091 = getelementptr i8, ptr %t1090, i64 %t1078
  call void @olang_textcopy(ptr %t1091, ptr %t1080, i64 %t1081)
  %t1092 = getelementptr i8, ptr %t1091, i64 %t1081
  call void @olang_textcopy(ptr %t1092, ptr %t1083, i64 %t1084)
  %t1093 = getelementptr i8, ptr %t1092, i64 %t1084
  call void @olang_textcopy(ptr %t1093, ptr %t1087, i64 %t1088)
  %t1094 = insertvalue { i64, ptr } undef, i64 %t1089, 0
  %t1095 = insertvalue { i64, ptr } %t1094, ptr %t1090, 1
  %t1097 = extractvalue { i64, ptr } %t1095, 0
  %t1098 = extractvalue { i64, ptr } %t1095, 1
  %t1099 = mul i64 %t1097, 1
  %t1100 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1099)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1100, ptr %t1098, i64 %t1099, i1 false)
  %t1101 = insertvalue { i64, ptr } undef, i64 %t1097, 0
  %t1102 = insertvalue { i64, ptr } %t1101, ptr %t1100, 1
  %t1103 = load ptr, ptr %l318, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s40, ptr %t1103, { i64, ptr } %t1102)
  br label %bb224
bb223:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb224:
  call void @__olang_scope_close(ptr %s40)
  br label %bb255
bb225:
  %t1105 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1106 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1105, { i64, ptr } %t1106)
  store i1 %t1109, ptr %l331
  br label %bb227
bb226:
  store i1 false, ptr %l328, !tbaa !21
  br label %bb228
bb227:
  %t1110 = load i1, ptr %l331, !tbaa !21
  %t1111 = xor i1 %t1110, true
  store i1 %t1111, ptr %l328, !tbaa !21
  br label %bb228
bb228:
  %t1113 = load i1, ptr %l328, !tbaa !21
  br i1 %t1113, label %bb229, label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s43
  %t1114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1114, ptr %l333, !tbaa !29
  %t1115 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1115, ptr %l334, !tbaa !27
  %t1116 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1117 = extractvalue { i64, ptr } %t1116, 0
  store i64 %t1117, ptr %l335, !tbaa !24
  %t1118 = icmp sge i64 0, 0
  br i1 %t1118, label %bb231, label %bb232
bb230:
  %t1120 = load i1, ptr %l14, !tbaa !21
  br i1 %t1120, label %bb244, label %bb245
bb231:
  %t1122 = icmp sle i64 0, 12
  br i1 %t1122, label %bb233, label %bb234
bb232:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb233:
  %t1124 = load i64, ptr %l335, !tbaa !24
  %t1125 = icmp sle i64 12, %t1124
  br i1 %t1125, label %bb235, label %bb236
bb234:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb235:
  %t1127 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1128 = load ptr, ptr %t1127, !tbaa !27
  %t1129 = getelementptr i8, ptr %t1128, i64 0
  %t1130 = sub i64 12, 0
  %t1131 = insertvalue { i64, ptr } undef, i64 %t1130, 0
  %t1132 = insertvalue { i64, ptr } %t1131, ptr %t1129, 1
  store { i64, ptr } %t1132, ptr %l339, !tbaa !27
  %t1133 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1134 = extractvalue { i64, ptr } %t1133, 0
  store i64 %t1134, ptr %l340, !tbaa !24
  %t1135 = icmp sge i64 0, 0
  br i1 %t1135, label %bb237, label %bb238
bb236:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb237:
  %t1137 = icmp sle i64 0, 12
  br i1 %t1137, label %bb239, label %bb240
bb238:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb239:
  %t1139 = load i64, ptr %l340, !tbaa !24
  %t1140 = icmp sle i64 12, %t1139
  br i1 %t1140, label %bb241, label %bb242
bb240:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb241:
  %t1142 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t1143 = load ptr, ptr %t1142, !tbaa !27
  %t1144 = getelementptr i8, ptr %t1143, i64 0
  %t1145 = sub i64 12, 0
  %t1146 = insertvalue { i64, ptr } undef, i64 %t1145, 0
  %t1147 = insertvalue { i64, ptr } %t1146, ptr %t1144, 1
  %t1148 = extractvalue { i64, ptr } { i64 15, ptr @.d72 }, 1
  %t1149 = extractvalue { i64, ptr } { i64 15, ptr @.d72 }, 0
  %t1150 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t1151 = extractvalue { i64, ptr } %t1150, 1
  %t1152 = extractvalue { i64, ptr } %t1150, 0
  %t1153 = add i64 %t1149, %t1152
  %t1154 = extractvalue { i64, ptr } { i64 4, ptr @.d73 }, 1
  %t1155 = extractvalue { i64, ptr } { i64 4, ptr @.d73 }, 0
  %t1156 = add i64 %t1153, %t1155
  %t1157 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t1158 = extractvalue { i64, ptr } %t1157, 1
  %t1159 = extractvalue { i64, ptr } %t1157, 0
  %t1160 = add i64 %t1156, %t1159
  %t1161 = extractvalue { i64, ptr } { i64 6, ptr @.d74 }, 1
  %t1162 = extractvalue { i64, ptr } { i64 6, ptr @.d74 }, 0
  %t1163 = add i64 %t1160, %t1162
  %t1165 = extractvalue { i64, ptr } %t1147, 1
  %t1166 = extractvalue { i64, ptr } %t1147, 0
  %t1167 = add i64 %t1163, %t1166
  %t1168 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 1
  %t1169 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 0
  %t1170 = add i64 %t1167, %t1169
  %t1171 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1170)
  call void @olang_textcopy(ptr %t1171, ptr %t1148, i64 %t1149)
  %t1172 = getelementptr i8, ptr %t1171, i64 %t1149
  call void @olang_textcopy(ptr %t1172, ptr %t1151, i64 %t1152)
  %t1173 = getelementptr i8, ptr %t1172, i64 %t1152
  call void @olang_textcopy(ptr %t1173, ptr %t1154, i64 %t1155)
  %t1174 = getelementptr i8, ptr %t1173, i64 %t1155
  call void @olang_textcopy(ptr %t1174, ptr %t1158, i64 %t1159)
  %t1175 = getelementptr i8, ptr %t1174, i64 %t1159
  call void @olang_textcopy(ptr %t1175, ptr %t1161, i64 %t1162)
  %t1176 = getelementptr i8, ptr %t1175, i64 %t1162
  call void @olang_textcopy(ptr %t1176, ptr %t1165, i64 %t1166)
  %t1177 = getelementptr i8, ptr %t1176, i64 %t1166
  call void @olang_textcopy(ptr %t1177, ptr %t1168, i64 %t1169)
  %t1178 = insertvalue { i64, ptr } undef, i64 %t1170, 0
  %t1179 = insertvalue { i64, ptr } %t1178, ptr %t1171, 1
  %t1181 = extractvalue { i64, ptr } %t1179, 0
  %t1182 = extractvalue { i64, ptr } %t1179, 1
  %t1183 = mul i64 %t1181, 1
  %t1184 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1184, ptr %t1182, i64 %t1183, i1 false)
  %t1185 = insertvalue { i64, ptr } undef, i64 %t1181, 0
  %t1186 = insertvalue { i64, ptr } %t1185, ptr %t1184, 1
  %t1187 = load ptr, ptr %l333, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s43, ptr %t1187, { i64, ptr } %t1186)
  br label %bb243
bb242:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb243:
  call void @__olang_scope_close(ptr %s43)
  br label %bb254
bb244:
  store %olang.scope zeroinitializer, ptr %s46
  %t1189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1189, ptr %l348, !tbaa !29
  %t1190 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1190, ptr %l349, !tbaa !27
  %t1191 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1192 = extractvalue { i64, ptr } %t1191, 0
  store i64 %t1192, ptr %l350, !tbaa !24
  %t1193 = icmp sge i64 0, 0
  br i1 %t1193, label %bb246, label %bb247
bb245:
  br label %bb253
bb246:
  %t1195 = icmp sle i64 0, 12
  br i1 %t1195, label %bb248, label %bb249
bb247:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb248:
  %t1197 = load i64, ptr %l350, !tbaa !24
  %t1198 = icmp sle i64 12, %t1197
  br i1 %t1198, label %bb250, label %bb251
bb249:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb250:
  %t1200 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t1201 = load ptr, ptr %t1200, !tbaa !27
  %t1202 = getelementptr i8, ptr %t1201, i64 0
  %t1203 = sub i64 12, 0
  %t1204 = insertvalue { i64, ptr } undef, i64 %t1203, 0
  %t1205 = insertvalue { i64, ptr } %t1204, ptr %t1202, 1
  %t1206 = extractvalue { i64, ptr } { i64 7, ptr @.d76 }, 1
  %t1207 = extractvalue { i64, ptr } { i64 7, ptr @.d76 }, 0
  %t1208 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t1209 = extractvalue { i64, ptr } %t1208, 1
  %t1210 = extractvalue { i64, ptr } %t1208, 0
  %t1211 = add i64 %t1207, %t1210
  %t1212 = extractvalue { i64, ptr } { i64 15, ptr @.d77 }, 1
  %t1213 = extractvalue { i64, ptr } { i64 15, ptr @.d77 }, 0
  %t1214 = add i64 %t1211, %t1213
  %t1216 = extractvalue { i64, ptr } %t1205, 1
  %t1217 = extractvalue { i64, ptr } %t1205, 0
  %t1218 = add i64 %t1214, %t1217
  %t1219 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1218)
  call void @olang_textcopy(ptr %t1219, ptr %t1206, i64 %t1207)
  %t1220 = getelementptr i8, ptr %t1219, i64 %t1207
  call void @olang_textcopy(ptr %t1220, ptr %t1209, i64 %t1210)
  %t1221 = getelementptr i8, ptr %t1220, i64 %t1210
  call void @olang_textcopy(ptr %t1221, ptr %t1212, i64 %t1213)
  %t1222 = getelementptr i8, ptr %t1221, i64 %t1213
  call void @olang_textcopy(ptr %t1222, ptr %t1216, i64 %t1217)
  %t1223 = insertvalue { i64, ptr } undef, i64 %t1218, 0
  %t1224 = insertvalue { i64, ptr } %t1223, ptr %t1219, 1
  %t1226 = extractvalue { i64, ptr } %t1224, 0
  %t1227 = extractvalue { i64, ptr } %t1224, 1
  %t1228 = mul i64 %t1226, 1
  %t1229 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1229, ptr %t1227, i64 %t1228, i1 false)
  %t1230 = insertvalue { i64, ptr } undef, i64 %t1226, 0
  %t1231 = insertvalue { i64, ptr } %t1230, ptr %t1229, 1
  %t1232 = load ptr, ptr %l348, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %s46, ptr %t1232, { i64, ptr } %t1231)
  br label %bb252
bb251:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb252:
  call void @__olang_scope_close(ptr %s46)
  br label %bb253
bb253:
  br label %bb254
bb254:
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s39)
  br label %bb256
bb256:
  %t1234 = load ptr, ptr %lp21
  %t1235 = load { i64, ptr }, ptr %t1234, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t1237 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t1235, 1
  store { i32, { i64, ptr } } %t1237, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %l45 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l18, !tbaa !24
  store i64 %t35, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l15, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l39
  br label %bb13
bb13:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %a1)
  store i1 %t65, ptr %l41
  br label %bb14
bb14:
  %t66 = load i1, ptr %l41, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/fetch:Fetcher", ptr %t67, i32 0, i32 7
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l45
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t74 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t75 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t74, 1
  store { i32, { i64, ptr } } %t75, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  %t81 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l22 = alloca %"std/prelude/text:LineIter"
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca i1
  %l57 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/fetch:Fetcher", ptr %t6, i32 0, i32 5
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fetch:Fetcher", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %t12)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l18
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l17
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t20 = load i32, ptr %l18, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_53ffa6078a05df97_cedcb09c0479edcb)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t28 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t25)
  store %"std/prelude/text:LineIter" %t28, ptr %l22
  br label %bb10
bb10:
  %t29 = load %"std/prelude/text:LineIter", ptr %l22
  store %"std/prelude/text:LineIter" %t29, ptr %l2
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %l2)
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l26
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb13, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l25
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t36, ptr %l23, !tbaa !27
  br label %bb17
bb13:
  %t37 = load i32, ptr %l26, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_6b88478e5ba0e6f6_911b45007093a98a)
  unreachable
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb17:
  %t42 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t43, { i64, ptr } { i64 1, ptr @.d78 })
  store i1 %t45, ptr %l30
  br label %bb18
bb18:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb20:
  br label %bb21
bb21:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t47)
  store { i64, ptr } %t49, ptr %l32
  br label %bb22
bb22:
  %t50 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t51 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s4, { i64, ptr } %t50, { i64, ptr } { i64 1, ptr @.d79 })
  store { i64, ptr } %t51, ptr %l33
  br label %bb23
bb23:
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d80 }, ptr %l34, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t53, ptr %l35, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l36, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l37, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l36, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t67, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d81 }, ptr %l38, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l40, !tbaa !24
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l41, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t82, ptr %l6, !tbaa !27
  store { i64, ptr } %t52, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l9, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t97, ptr %l49, !tbaa !27
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %t101, i64 %t98
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !37
  store { i64, ptr } %t103, ptr %l10, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t105, { i64, ptr } { i64 0, ptr @.d82 })
  store i1 %t107, ptr %l53
  br label %bb28
bb28:
  %t108 = load i1, ptr %l53, !tbaa !21
  br i1 %t108, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb30:
  br label %bb31
bb31:
  %t109 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s7, { i64, ptr } %t109, { i64, ptr } { i64 0, ptr @.d83 })
  store i1 %t111, ptr %l55
  br label %bb32
bb32:
  %t112 = load i1, ptr %l55, !tbaa !21
  br i1 %t112, label %bb33, label %bb34
bb33:
  %t113 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = extractvalue { i64, ptr } %t113, 0
  %t117 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t115, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l57, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l59, !tbaa !24
  %t125 = load i64, ptr %l59, !tbaa !24
  %t126 = icmp eq i64 %t121, %t125
  br i1 %t126, label %bb35, label %bb36
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t128 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s11, { i64, ptr } %t128, { i64, ptr } { i64 0, ptr @.d84 })
  store i1 %t130, ptr %l62
  br label %bb38
bb35:
  %t131 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l59, !tbaa !24
  %t136 = mul i64 %t135, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t132, ptr %t134, i64 %t136, i1 false)
  br label %bb37
bb36:
  %t137 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t137, ptr %l5, !tbaa !27
  br label %bb37
bb37:
  br label %bb45
bb38:
  %t138 = load i1, ptr %l62, !tbaa !21
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t139 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = extractvalue { i64, ptr } %t139, 0
  %t143 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t141, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l64, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l66, !tbaa !24
  %t151 = load i64, ptr %l66, !tbaa !24
  %t152 = icmp eq i64 %t147, %t151
  br i1 %t152, label %bb41, label %bb42
bb40:
  br label %bb44
bb41:
  %t154 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l66, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  br label %bb43
bb42:
  %t160 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t160, ptr %l6, !tbaa !27
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s11)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t161 = load i64, ptr %l8, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l8, !tbaa !24
  br label %bb24
bb47:
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t167 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t165, { i64, ptr } { i64 0, ptr @.d85 })
  store i1 %t167, ptr %l71
  br label %bb48
bb48:
  %t168 = load i1, ptr %l71, !tbaa !21
  br i1 %t168, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb50:
  br label %bb51
bb51:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/fetch:Fetcher", ptr %t169, i32 0, i32 6
  %t172 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 1
  %t175 = extractvalue { i64, ptr } %t172, 0
  %t176 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t174, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t171, { i64, ptr } %t185)
  br label %bb52
bb52:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/fetch:Fetcher", ptr %t188, i32 0, i32 7
  %t191 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = extractvalue { i64, ptr } %t191, 0
  %t195 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t193, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = extractvalue { i64, ptr } %t197, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t190, { i64, ptr } %t204)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  br label %bb11
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca i1
  %l61 = alloca i1
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l88 = alloca i64
  %l97 = alloca i64
  %l100 = alloca i64
  %l125 = alloca %"std/prelude/text:StringBuilder"
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l157 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %t235 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l25
  br label %bb2
bb2:
  %t8 = load i64, ptr %l25, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l32, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l32, !tbaa !24
  store i64 %t35, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %l9, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l53
  br label %bb13
bb13:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t62)
  store i1 %t65, ptr %l55
  br label %bb14
bb14:
  %t66 = load i1, ptr %l55, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load i64, ptr %l9, !tbaa !24
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/fetch:Fetcher", ptr %t77, i32 0, i32 7
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store { i64, ptr } %t83, ptr %l65
  br label %bb22
bb21:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb24
bb22:
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t85, { i64, ptr } %t84)
  store i1 %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load i1, ptr %l67, !tbaa !21
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = icmp sge i64 %t90, 0
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/fetch:Fetcher", ptr %t94, i32 0, i32 7
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = extractvalue { i64, ptr } %t98, 0
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t100, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v0, ptr %t96, i64 %t97, { i64, ptr } %t111)
  br label %bb30
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/fetch:Fetcher", ptr %t115, i32 0, i32 6
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t117, { i64, ptr } %t131)
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/fetch:Fetcher", ptr %t134, i32 0, i32 7
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t139, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t136, { i64, ptr } %t150)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/fetch:Fetcher", ptr %t153, i32 0, i32 6
  %t157 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t155)
  store i64 %t157, ptr %l88
  br label %bb34
bb34:
  %t158 = load i64, ptr %l88, !tbaa !24
  %t159 = icmp sge i64 %t158, 0
  br i1 %t159, label %bb35, label %bb36
bb35:
  %t161 = load i64, ptr %l88, !tbaa !24
  %t162 = icmp sle i64 %t161, 1152921504606846975
  br i1 %t162, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ba721b6722bc57b1_efdace1c8e747995)
  unreachable
bb37:
  %t164 = load i64, ptr %l88, !tbaa !24
  %t165 = mul i64 %t164, 8
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  store i64 %t172, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_ba721b6722bc57b1_efdace1c8e747995)
  unreachable
bb39:
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb44
bb41:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t185 = load i64, ptr %l11, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l13, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l13, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l100, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb43
bb43:
  %t200 = load i64, ptr %l100, !tbaa !24
  store i64 %t200, ptr %l97, !tbaa !24
  br label %bb44
bb44:
  %t201 = load i64, ptr %l97, !tbaa !24
  store i64 %t201, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s12
  %t202 = load i64, ptr %l15, !tbaa !24
  %t203 = load i64, ptr %l14, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s12)
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t210 = load i64, ptr %l11, !tbaa !24
  %t211 = load i64, ptr %l15, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l16, !tbaa !24
  %t220 = load i64, ptr %l16, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i64, ptr %t225, i64 %t220
  store i64 %t221, ptr %t226, !tbaa !34
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb49:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l15, !tbaa !24
  br label %bb45
bb50:
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t234 = ptrtoint ptr %t233 to i64
  %t236 = getelementptr { ptr, ptr }, ptr %t235, i32 0, i32 0
  store ptr %t232, ptr %t236, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t238 = getelementptr { ptr, ptr }, ptr %t235, i32 0, i32 1
  store ptr %v0, ptr %t238, !tbaa !28
  %t239 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_86, 0
  %t240 = insertvalue { ptr, ptr } %t239, ptr %t235, 1
  %t243 = extractvalue { ptr, ptr } %t240, 0
  %t244 = extractvalue { ptr, ptr } %t240, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %s0, ptr %s0, { i64, ptr } %t231, ptr %t243, ptr %t244)
  br label %bb51
bb51:
  %t245 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t245, ptr %l125
  br label %bb52
bb52:
  %t246 = load %"std/prelude/text:StringBuilder", ptr %l125
  store %"std/prelude/text:StringBuilder" %t246, ptr %l17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 100, ptr @.d87 })
  br label %bb53
bb53:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 77, ptr @.d88 })
  br label %bb54
bb54:
  %t249 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t249, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l20, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s15
  %t255 = load i64, ptr %l19, !tbaa !24
  %t256 = load i64, ptr %l20, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s15)
  br label %bb66
bb57:
  br label %bb58
bb58:
  %t263 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t263, ptr %l135, !tbaa !27
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i64, ptr %t267, i64 %t264
  %t269 = load i64, ptr %t268, !tbaa !34
  store i64 %t269, ptr %l21, !tbaa !24
  store ptr %l17, ptr %l138, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/fetch:Fetcher", ptr %t271, i32 0, i32 6
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t273, i64 %t274)
  store { i64, ptr } %t277, ptr %l142
  br label %bb59
bb59:
  %t278 = load ptr, ptr %l138, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l142, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t278, { i64, ptr } %t279)
  br label %bb60
bb60:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l17, i8 32)
  br label %bb61
bb61:
  store ptr %l17, ptr %l144, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/fetch:Fetcher", ptr %t281, i32 0, i32 7
  %t284 = load i64, ptr %l21, !tbaa !24
  %t287 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t283, i64 %t284)
  store { i64, ptr } %t287, ptr %l148
  br label %bb62
bb62:
  %t288 = load ptr, ptr %l144, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l148, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t288, { i64, ptr } %t289)
  br label %bb63
bb63:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l17, i8 10)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s15)
  br label %bb65
bb65:
  %t291 = load i64, ptr %l19, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l19, !tbaa !24
  br label %bb55
bb66:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/fetch:Fetcher", ptr %t295, i32 0, i32 0
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, ptr } %t298, ptr %l153, !tbaa !27
  %t300 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l17)
  store { i64, ptr } %t300, ptr %l155
  br label %bb67
bb67:
  %t301 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t304 = call i32 @std_2fos_2eWriteFile(ptr %v0, ptr %s0, { i64, ptr } %t302, { i64, ptr } %t301)
  store i32 %t304, ptr %l157
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb69, label %ok.306
ok.306:
  br label %bb68
bb68:
  br label %bb73
bb69:
  %t307 = load i32, ptr %l157, !tbaa !23
  %t308 = ashr i32 %t307, 16
  %t310 = icmp eq i32 %t308, 1
  br i1 %t310, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_88b806f24688508b_997ec4238546bef7)
  unreachable
bb72:
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l11 = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 9
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = extractvalue { i64, ptr } %t10, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t3, { i64, ptr } %t17)
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/fetch:Fetcher", ptr %t20, i32 0, i32 4
  %t23 = load i1, ptr %t22, !tbaa !21
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = call i32 @std_2fio_2ePrintErrln(ptr %v1, { i64, ptr } %t27)
  store i32 %t29, ptr %l11
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  br label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb9
bb5:
  %t32 = load i32, ptr %l11, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_123b76add1f6a034_48d214a7cc9ba878)
  unreachable
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l24 = alloca { i64, ptr }
  %l29 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l15
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l14
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ee93546c87f9d64c_79e6a6f44e92448)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t39, { i64, ptr } %t42)
  store i1 %t45, ptr %l29
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l7, !tbaa !24
  br label %bb8
bb17:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t52, %t53
  store i64 %t56, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  br i1 %a2, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/fetch:Fetcher", ptr %t60, i32 0, i32 8
  %t63 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t62, { i64, ptr } %t76)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2egit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:Output"
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr @.d89 }, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t4 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t3, i1 true, { i64, ptr } { i64 0, ptr @.d90 })
  %t5 = extractvalue { i32, %"std/os:Output" } %t4, 1
  %t6 = extractvalue { i32, %"std/os:Output" } %t4, 0
  store i32 %t6, ptr %l6
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store %"std/os:Output" %t5, ptr %l5
  br label %bb1
bb1:
  %t9 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t9, ptr %l2
  br label %bb6
bb2:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_456a27cc34a1957d_6cd35c881f48b5d9)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t16 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t16, ptr %l1
  %t17 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = icmp eq i32 %t18, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ehead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca %"std/os:Output"
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"std/os:Output"
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/os:Output"
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t10 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d91 }, 0
  %t11 = insertvalue [5 x { i64, ptr }] %t10, { i64, ptr } { i64 2, ptr @.d92 }, 1
  %t13 = insertvalue [5 x { i64, ptr }] %t11, { i64, ptr } %t7, 2
  %t14 = insertvalue [5 x { i64, ptr }] %t13, { i64, ptr } { i64 9, ptr @.d93 }, 3
  %t15 = insertvalue [5 x { i64, ptr }] %t14, { i64, ptr } { i64 4, ptr @.d94 }, 4
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call ptr @__olang_scope_alloc(ptr %t17, i64 80)
  store [5 x { i64, ptr }] %t15, ptr %t18
  %t19 = insertvalue { i64, ptr } undef, i64 5, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 16
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } { i64 0, ptr @.d95 }, ptr %l11, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t30 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t27, { i64, ptr } %t29, i1 true, { i64, ptr } { i64 0, ptr @.d96 })
  %t31 = extractvalue { i32, %"std/os:Output" } %t30, 1
  %t32 = extractvalue { i32, %"std/os:Output" } %t30, 0
  store i32 %t32, ptr %l13
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb2, label %ok.34
ok.34:
  store %"std/os:Output" %t31, ptr %l12
  br label %bb1
bb1:
  %t35 = load %"std/os:Output", ptr %l12
  store %"std/os:Output" %t35, ptr %l6
  br label %bb6
bb2:
  %t36 = load i32, ptr %l13, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9013815812f03cb5_c1602845c5aedee9)
  unreachable
bb5:
  store { i64, ptr } { i64 0, ptr @.d97 }, ptr %l16, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t41, ptr %l17, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l18, !tbaa !24
  %t45 = mul i64 %t44, 1
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l19, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = mul i64 %t53, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t55, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb6:
  %t57 = load %"std/os:Output", ptr %l6
  store %"std/os:Output" %t57, ptr %l2
  %t58 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = icmp ne i32 %t59, 0
  br i1 %t61, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr @.d98 }, ptr %l22, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t63, ptr %l23, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l24, !tbaa !24
  %t66 = load i64, ptr %l24, !tbaa !24
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l25, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l24, !tbaa !24
  %t76 = mul i64 %t75, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t77, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t78 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t79 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 1
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t80)
  store { i64, ptr } %t82, ptr %l27
  br label %bb10
bb10:
  %t83 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t83, ptr %l3, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t84)
  store i1 %t86, ptr %l29
  br label %bb11
bb11:
  %t87 = load i1, ptr %l29, !tbaa !21
  br i1 %t87, label %bb12, label %bb13
bb12:
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t90, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l30, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr @.d99 }, ptr %l33, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t96, ptr %l30, !tbaa !27
  br label %bb14
bb14:
  %t98 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l35, !tbaa !24
  %t100 = load i64, ptr %l35, !tbaa !24
  %t101 = mul i64 %t100, 1
  %t102 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l36, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l35, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t111, ptr %l30, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t112 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t112, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2emakeRepo(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l9 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l21 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr @.d100 }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d100 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t19)
  store i32 %t21, ptr %l9
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb2, label %ok.23
ok.23:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t24 = load i32, ptr %l9, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c9ab87d2c1341871_fd16dd2dcdcd2995)
  unreachable
bb5:
  store { i64, ptr } { i64 0, ptr @.d101 }, ptr %l12, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t29, ptr %l13, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l14, !tbaa !24
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l15, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l14, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t43, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb6:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = extractvalue { i64, ptr } %t45, 0
  %t49 = extractvalue { i64, ptr } { i64 10, ptr @.d102 }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr @.d102 }, 0
  %t51 = add i64 %t48, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t47, i64 %t48)
  %t53 = getelementptr i8, ptr %t52, i64 %t48
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t67 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t62, { i64, ptr } %a2)
  store i32 %t67, ptr %l21
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb8, label %ok.69
ok.69:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t70 = load i32, ptr %l21, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  br i1 %t73, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c6873aa714579460_b40d85e54622baa4)
  unreachable
bb11:
  store { i64, ptr } { i64 0, ptr @.d103 }, ptr %l24, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t75, ptr %l25, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l26, !tbaa !24
  %t78 = load i64, ptr %l26, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l27, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l26, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t89, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
bb12:
  %t91 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t91, { i64, ptr } { i64 3, ptr @.d104 })
  store i1 %t93, ptr %l29
  br label %bb13
bb13:
  %t94 = load i1, ptr %l29, !tbaa !21
  br i1 %t94, label %bb14, label %bb15
bb14:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t95, { i64, ptr } { i64 9, ptr @.d105 })
  store i1 %t97, ptr %l32
  br label %bb16
bb15:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb17
bb16:
  %t98 = load i1, ptr %l32, !tbaa !21
  store i1 %t98, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t99 = load i1, ptr %l30, !tbaa !21
  br i1 %t99, label %bb18, label %bb19
bb18:
  %t100 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t102 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 11, ptr @.d106 })
  store i1 %t102, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb21
bb20:
  %t103 = load i1, ptr %l35, !tbaa !21
  store i1 %t103, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l33, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t109 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v3, { i64, ptr } %t107)
  store { i64, ptr } %t109, ptr %l39
  br label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr @.d107 }, ptr %l40, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t110, ptr %l37, !tbaa !27
  br label %bb25
bb24:
  %t112 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t112, ptr %l37, !tbaa !27
  br label %bb25
bb25:
  %t113 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l42, !tbaa !24
  %t115 = load i64, ptr %l42, !tbaa !24
  %t116 = mul i64 %t115, 1
  %t117 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l43, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l42, !tbaa !24
  %t125 = mul i64 %t124, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t126, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffetch_2esh(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/os:Output"
  %l3 = alloca %"std/os:Output"
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"std/os:Output"
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr @.d108 }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %a1, { i64, ptr } %t4, i1 true, { i64, ptr } %a0)
  %t7 = extractvalue { i32, %"std/os:Output" } %t6, 1
  %t8 = extractvalue { i32, %"std/os:Output" } %t6, 0
  store i32 %t8, ptr %l8
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  store %"std/os:Output" %t7, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"std/os:Output", ptr %l7
  store %"std/os:Output" %t11, ptr %l3
  br label %bb6
bb2:
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5d76ed62925a0d26_8e596c5fa04ecd8a)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t18 = load %"std/os:Output", ptr %l3
  store %"std/os:Output" %t18, ptr %l2
  %t19 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = icmp eq i32 %t20, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/fetch:Fetcher"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store { i64, ptr } %a1, ptr %l6, !tbaa !27
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  store i1 %a3, ptr %l8, !tbaa !21
  store i1 %a4, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l20
  br label %bb1
bb1:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l11
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l21
  br label %bb2
bb2:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l12
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t17)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l22
  br label %bb3
bb3:
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l13
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t20)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t24 = insertvalue %"compiler/fetch:Fetcher" undef, { i64, ptr } %t23, 0
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t26 = insertvalue %"compiler/fetch:Fetcher" %t24, { i64, ptr } %t25, 1
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t28 = insertvalue %"compiler/fetch:Fetcher" %t26, { i64, ptr } %t27, 2
  %t29 = load i1, ptr %l8, !tbaa !21
  %t30 = insertvalue %"compiler/fetch:Fetcher" %t28, i1 %t29, 3
  %t31 = load i1, ptr %l9, !tbaa !21
  %t32 = insertvalue %"compiler/fetch:Fetcher" %t30, i1 %t31, 4
  %t33 = load i1, ptr %l10, !tbaa !21
  %t34 = insertvalue %"compiler/fetch:Fetcher" %t32, i1 %t33, 5
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t36 = insertvalue %"compiler/fetch:Fetcher" %t34, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, 6
  %t37 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t38 = insertvalue %"compiler/fetch:Fetcher" %t36, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, 7
  %t39 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t40 = insertvalue %"compiler/fetch:Fetcher" %t38, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, 8
  %t42 = insertvalue %"compiler/fetch:Fetcher" %t40, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, 9
  store %"compiler/fetch:Fetcher" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/fetch:Fetcher", ptr %rv
  ret %"compiler/fetch:Fetcher" %rr
}

@.d0 = private constant [11 x i8] c"OLANG_CACHE"
@.d1 = private constant [0 x i8] c""
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant [0 x i8] c""
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant [4 x i8] c"HOME"
@.d4 = private constant [1 x i8] c"."
@.d5 = private constant [13 x i8] c"/.cache/olang"
@.d6 = private constant [14 x i8] c"OLANG_GIT_BASE"
@.d7 = private constant [0 x i8] c""
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [8 x i8] c"https://"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant [2 x i8] c".."
@.d11 = private constant [16 x i8] c"/example.com/me/"
@.d12 = private constant [10 x i8] c"/lib.olang"
declare void @__olang_check_failed(ptr)
@.d13 = private constant [0 x i8] c""
@.d14 = private constant [12 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr @.d109 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 11, ptr @.d111 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 14, ptr @.d112 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 20, ptr @.d113 }, { i64, ptr } { i64 6, ptr @.d114 }, { i64, ptr } { i64 2, ptr @.d115 }, { i64, ptr } { i64 2, ptr @.d116 }, { i64, ptr } { i64 2, ptr @.d117 }, { i64, ptr } { i64 1, ptr @.d118 }]
@.d15 = private constant [0 x i8] c""
@.d16 = private constant [1 x i8] c"/"
@.d17 = private constant [1 x i8] c"/"
@.d18 = private constant [1 x i8] c"/"
@.d19 = private constant [1 x i8] c"/"
@.d20 = private constant [1 x i8] c"/"
@.d21 = private constant [1 x i8] c"/"
@.d22 = private constant [1 x i8] c"/"
@.d23 = private constant [0 x i8] c""
@.d24 = private constant [0 x i8] c""
@.d25 = private constant [0 x i8] c""
@.d26 = private constant [1 x i8] c"/"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d27 = private constant [7 x i8] c".fetch-"
@.d28 = private constant [16 x i8] c"olang: fetching "
@.d29 = private constant [6 x i8] c" into "
@.d30 = private constant [4 x i8] c" at "
@.d31 = private constant [20 x i8] c", as olang.lock says"
@.d32 = private constant [1 x i8] c"/"
@.d33 = private constant [3 x i8] c"git"
@.d34 = private constant [4 x i8] c"init"
@.d35 = private constant [2 x i8] c"-q"
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d36 = private constant [3 x i8] c"git"
@.d37 = private constant [2 x i8] c"-C"
@.d38 = private constant [5 x i8] c"fetch"
@.d39 = private constant [2 x i8] c"-q"
@.d40 = private constant [7 x i8] c"--depth"
@.d41 = private constant [1 x i8] c"1"
@.d42 = private constant [2 x i8] c"--"
@.d43 = private constant [3 x i8] c"git"
@.d44 = private constant [2 x i8] c"-C"
@.d45 = private constant [8 x i8] c"checkout"
@.d46 = private constant [2 x i8] c"-q"
@.d47 = private constant [10 x i8] c"FETCH_HEAD"
@.d48 = private constant [3 x i8] c"git"
@.d49 = private constant [5 x i8] c"clone"
@.d50 = private constant [2 x i8] c"-q"
@.d51 = private constant [2 x i8] c"--"
@.d52 = private constant [3 x i8] c"git"
@.d53 = private constant [2 x i8] c"-C"
@.d54 = private constant [8 x i8] c"checkout"
@.d55 = private constant [2 x i8] c"-q"
@.d56 = private constant [16 x i8] c"olang: fetching "
@.d57 = private constant [6 x i8] c" into "
@.d58 = private constant [9 x i8] c"--branch="
@.d59 = private constant [7 x i8] c"--quiet"
@.d60 = private constant [0 x i8] c""
@.d61 = private constant [3 x i8] c"git"
@.d62 = private constant [5 x i8] c"clone"
@.d63 = private constant [7 x i8] c"--quiet"
@.d64 = private constant [7 x i8] c"--depth"
@.d65 = private constant [1 x i8] c"1"
@.d66 = private constant [2 x i8] c"--"
@.d67 = private constant [0 x i8] c""
@.d68 = private constant [1 x i8] c"/"
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [15 x i8] c"olang: updated "
@.d71 = private constant [4 x i8] c" to "
@.d72 = private constant [15 x i8] c"olang: updated "
@.d73 = private constant [4 x i8] c" to "
@.d74 = private constant [6 x i8] c" (was "
@.d75 = private constant [1 x i8] c")"
@.d76 = private constant [7 x i8] c"olang: "
@.d77 = private constant [15 x i8] c" is already at "
@.d78 = private constant [1 x i8] c"#"
@.d79 = private constant [1 x i8] c" "
@.d80 = private constant [0 x i8] c""
@.d81 = private constant [0 x i8] c""
@.d82 = private constant [0 x i8] c""
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [0 x i8] c""
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_86(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 6
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %vc0, ptr %vc0, ptr %t3, i64 %a0)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/fetch:Fetcher", ptr %t8, i32 0, i32 6
  %t14 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %vc0, ptr %vc0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t15, { i64, ptr } %t16)
  store i1 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d87 = private constant [100 x i8] c"# olang.lock - the commit each remote repository is built from (M23b). Delete a line to update that\0A"
@.d88 = private constant [77 x i8] c"# repository, or build with -u to update every one the build reaches (M23c).\0A"
@.d89 = private constant [0 x i8] c""
@.d90 = private constant [0 x i8] c""
@.d91 = private constant [3 x i8] c"git"
@.d92 = private constant [2 x i8] c"-C"
@.d93 = private constant [9 x i8] c"rev-parse"
@.d94 = private constant [4 x i8] c"HEAD"
@.d95 = private constant [0 x i8] c""
@.d96 = private constant [0 x i8] c""
@.d97 = private constant [0 x i8] c""
@.d98 = private constant [0 x i8] c""
@.d99 = private constant [0 x i8] c""
@.d100 = private constant [16 x i8] c"/example.com/me/"
@.d101 = private constant [0 x i8] c""
@.d102 = private constant [10 x i8] c"/lib.olang"
@.d103 = private constant [0 x i8] c""
@.d104 = private constant [3 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr @.d109 }, { i64, ptr } { i64 4, ptr @.d119 }, { i64, ptr } { i64 2, ptr @.d115 }]
@.d105 = private constant [9 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr @.d109 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 11, ptr @.d111 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 14, ptr @.d112 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 20, ptr @.d113 }, { i64, ptr } { i64 3, ptr @.d120 }, { i64, ptr } { i64 1, ptr @.d121 }]
@.d106 = private constant [11 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr @.d109 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 11, ptr @.d111 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 14, ptr @.d112 }, { i64, ptr } { i64 2, ptr @.d110 }, { i64, ptr } { i64 20, ptr @.d113 }, { i64, ptr } { i64 6, ptr @.d114 }, { i64, ptr } { i64 2, ptr @.d115 }, { i64, ptr } { i64 2, ptr @.d117 }, { i64, ptr } { i64 1, ptr @.d122 }]
@.d107 = private constant [0 x i8] c""
@.d108 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d109 = private unnamed_addr constant [3 x i8] c"git"
@.d110 = private unnamed_addr constant [2 x i8] c"-c"
@.d111 = private unnamed_addr constant [11 x i8] c"user.name=t"
@.d112 = private unnamed_addr constant [14 x i8] c"user.email=t@t"
@.d113 = private unnamed_addr constant [20 x i8] c"commit.gpgsign=false"
@.d114 = private unnamed_addr constant [6 x i8] c"commit"
@.d115 = private unnamed_addr constant [2 x i8] c"-q"
@.d116 = private unnamed_addr constant [2 x i8] c"-a"
@.d117 = private unnamed_addr constant [2 x i8] c"-m"
@.d118 = private unnamed_addr constant [1 x i8] c"y"
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d119 = private unnamed_addr constant [4 x i8] c"init"
@.d120 = private unnamed_addr constant [3 x i8] c"add"
@.d121 = private unnamed_addr constant [1 x i8] c"."
@.d122 = private unnamed_addr constant [1 x i8] c"x"
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d3373a347b8bef1c_6787ad888ff53eb8 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2 = external constant [0 x i8]
@olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f = external constant [0 x i8]
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_45f2c25416d44418_72b8f662ae75c904 = external constant [0 x i8]
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_461a8d3078b45b75_287f37f9c7026b71 = external constant [0 x i8]
@olang_loc_64bbdb9c4083d73a_45ec4fce431b420e = external constant [0 x i8]
@olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_53ffa6078a05df97_cedcb09c0479edcb = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_6b88478e5ba0e6f6_911b45007093a98a = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_ba721b6722bc57b1_efdace1c8e747995 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_88b806f24688508b_997ec4238546bef7 = external constant [0 x i8]
declare i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0)
@olang_loc_123b76add1f6a034_48d214a7cc9ba878 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ee93546c87f9d64c_79e6a6f44e92448 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_456a27cc34a1957d_6cd35c881f48b5d9 = external constant [0 x i8]
@olang_loc_9013815812f03cb5_c1602845c5aedee9 = external constant [0 x i8]
@olang_loc_c9ab87d2c1341871_fd16dd2dcdcd2995 = external constant [0 x i8]
@olang_loc_c6873aa714579460_b40d85e54622baa4 = external constant [0 x i8]
@olang_loc_5d76ed62925a0d26_8e596c5fa04ecd8a = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
