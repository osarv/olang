; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/types:data" = type { i32, i64, i64, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:decl" = type { i64, i32, i32, i32, i64 }
%"compiler/types:body" = type { i32, i32, i32, i1, i1 }
@G_2ecompiler_2ftypes_2eBigAggregate = constant <{ [8 x i8] }> <{ [8 x i8] c"\80\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eBoolT = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eFromTypeVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eLaidOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eLayingOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoLayout = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNotLaidOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullT = constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eOwnScope = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eOwning = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eResultVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eRoleCtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eRoleDtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eRoleFn = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eUnknownT = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eWritable = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eprimBits = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ftypes_2eprimLlvm = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k1, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k2, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k7, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k11, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k12, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k13, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k14, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k15 }>, align 64
@G_2ecompiler_2ftypes_2eprimLlvm.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k2 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\76\6F\69\64" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k3 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\31" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k8 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k12 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\68\61\6C\66" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k13 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\62\66\6C\6F\61\74" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k14 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6C\6F\61\74" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k15 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\64\6F\75\62\6C\65" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k2, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k7, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k12, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k13, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k14, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k15 }>, align 64
@G_2ecompiler_2ftypes_2eprimNames.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k3 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\6F\6F\6C" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\49\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k8 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\55\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\46\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k14 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k15 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\36\34" }>, align 8
define dso_local void @compiler_2ftypes_2eBigAggregate_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 128, ptr @G_2ecompiler_2ftypes_2eBigAggregate, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eBoolT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eClosingVar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -2, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eDefaultErrT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eFromTypeVar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -2, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eLaidOut_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eLayingOut_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ftypes_2eLayingOut, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNewTable(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca %"compiler/types:Table"
  %l8 = alloca ptr
  %l12 = alloca ptr
  %l16 = alloca ptr
  %l38 = alloca [18 x i32]
  %l49 = alloca ptr
  %l51 = alloca %"compiler/types:data"
  %l52 = alloca i32
  %l55 = alloca %"compiler/types:Table"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t2 = alloca %"compiler/types:Table", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftypes_3aTable_2ector(ptr %t2, ptr %v0, ptr %v1, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t2, i64 256, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 256, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l7, i64 256, i1 false)
  %t6 = load ptr, ptr %lp1
  %t7 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 5
  store ptr %t7, ptr %l8, !tbaa !29
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = icmp sle i64 0, 2305843009213693951
  br i1 %t10, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb4:
  %t12 = mul i64 0, 4
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t16 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v1, ptr %v1, ptr %t16, { i64, ptr } %t15)
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb6:
  %t18 = load ptr, ptr %lp1
  %t19 = getelementptr %"compiler/types:Table", ptr %t18, i32 0, i32 26
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb9:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t28, { i64, ptr } %t27)
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb11:
  %t30 = load ptr, ptr %lp1
  %t31 = getelementptr %"compiler/types:Table", ptr %t30, i32 0, i32 28
  store ptr %t31, ptr %l16, !tbaa !29
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb12, label %bb13
bb12:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb14:
  %t36 = mul i64 0, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t40 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t40, { i64, ptr } %t39)
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb16:
  store %olang.scope zeroinitializer, ptr %s1
  %t60 = getelementptr [18 x i32], ptr %l38, i64 0, i64 0
  store i32 0, ptr %t60
  %t61 = getelementptr [18 x i32], ptr %l38, i64 0, i64 1
  store i32 1, ptr %t61
  %t62 = getelementptr [18 x i32], ptr %l38, i64 0, i64 2
  store i32 2, ptr %t62
  %t63 = getelementptr [18 x i32], ptr %l38, i64 0, i64 3
  store i32 3, ptr %t63
  %t64 = getelementptr [18 x i32], ptr %l38, i64 0, i64 4
  store i32 4, ptr %t64
  %t65 = getelementptr [18 x i32], ptr %l38, i64 0, i64 5
  store i32 5, ptr %t65
  %t66 = getelementptr [18 x i32], ptr %l38, i64 0, i64 6
  store i32 6, ptr %t66
  %t67 = getelementptr [18 x i32], ptr %l38, i64 0, i64 7
  store i32 7, ptr %t67
  %t68 = getelementptr [18 x i32], ptr %l38, i64 0, i64 8
  store i32 8, ptr %t68
  %t69 = getelementptr [18 x i32], ptr %l38, i64 0, i64 9
  store i32 9, ptr %t69
  %t70 = getelementptr [18 x i32], ptr %l38, i64 0, i64 10
  store i32 10, ptr %t70
  %t71 = getelementptr [18 x i32], ptr %l38, i64 0, i64 11
  store i32 11, ptr %t71
  %t72 = getelementptr [18 x i32], ptr %l38, i64 0, i64 12
  store i32 12, ptr %t72
  %t73 = getelementptr [18 x i32], ptr %l38, i64 0, i64 13
  store i32 13, ptr %t73
  %t74 = getelementptr [18 x i32], ptr %l38, i64 0, i64 14
  store i32 14, ptr %t74
  %t75 = getelementptr [18 x i32], ptr %l38, i64 0, i64 15
  store i32 15, ptr %t75
  %t76 = getelementptr [18 x i32], ptr %l38, i64 0, i64 16
  store i32 16, ptr %t76
  %t77 = getelementptr [18 x i32], ptr %l38, i64 0, i64 17
  store i32 17, ptr %t77
  %t78 = load [18 x i32], ptr %l38
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 72, i64 8)
  store [18 x i32] %t78, ptr %t79
  store ptr %t79, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t81 = load ptr, ptr %l2
  store i64 18, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t84 = load i64, ptr %l3, !tbaa !24
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l2
  %t93 = load i64, ptr %l3, !tbaa !24
  %t96 = getelementptr [18 x i32], ptr %t92, i64 0, i64 %t93
  %t97 = load i32, ptr %t96
  %t99 = load ptr, ptr %lp1
  store ptr %t99, ptr %l49, !tbaa !29
  %t102 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s2, i32 %t97, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t102, ptr %l51
  br label %bb21
bb21:
  %t103 = load ptr, ptr %l49, !tbaa !29
  %t104 = load %"compiler/types:data", ptr %l51
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v1, ptr %t103, %"compiler/types:data" %t104, i32 1)
  store i32 %t105, ptr %l52
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t106 = load i64, ptr %l3, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l3, !tbaa !24
  br label %bb17
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t110 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t110, i64 256, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l55, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNoLayout_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ftypes_2eNoLayout, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNoreturnT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 17, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNotLaidOut_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ftypes_2eNotLaidOut, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNullT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 15, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eOwnScope_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eOwning_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eReadOnly_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eResultVar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleCtor_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleDtor_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ftypes_2eRoleDtor, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleFn_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, i64 }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l5, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l6, !tbaa !22
  %t27 = load i8, ptr %l6, !tbaa !22
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t27)
  store i1 %t29, ptr %l24
  br label %bb6
bb6:
  %t30 = load i1, ptr %l24, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb8:
  %t31 = load i8, ptr %l6, !tbaa !22
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t31)
  store i1 %t33, ptr %l27
  br label %bb9
bb9:
  %t34 = load i1, ptr %l27, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  store i1 %t37, ptr %l28, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l28, !tbaa !21
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load i8, ptr %l6, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t41)
  br label %bb16
bb15:
  %t44 = load i8, ptr %l6, !tbaa !22
  %t46 = icmp eq i8 %t44, 95
  br i1 %t46, label %bb17, label %bb18
bb16:
  br label %bb24
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr @.d3 })
  br label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb20:
  store ptr %l1, ptr %l37, !tbaa !29
  %t50 = load i8, ptr %l6, !tbaa !22
  %t53 = call { i64, ptr } @compiler_2ftypes_2ehex2(ptr %s6, i8 %t50)
  store { i64, ptr } %t53, ptr %l40
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t61 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t61, { i64, ptr } %t60)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb2
bb26:
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t68, ptr %l45
  br label %bb27
bb27:
  %t69 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t69, ptr %l7, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t74 = icmp sle i64 %t72, 120
  br i1 %t74, label %bb28, label %bb29
bb28:
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t76, ptr %l50, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l51, !tbaa !24
  %t80 = load i64, ptr %l51, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l52, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l51, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t91, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t93 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %t93)
  store { i64, i64 } %t95, ptr %l54
  br label %bb31
bb31:
  %t96 = load { i64, i64 }, ptr %l54
  store { i64, i64 } %t96, ptr %l8
  %t97 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t98 = load i64, ptr %t97, !tbaa !65
  store i64 %t98, ptr %l9, !tbaa !65
  %t100 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !65
  store i64 %t101, ptr %l10, !tbaa !65
  %t103 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t103, ptr %l57, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l58, !tbaa !24
  %t106 = icmp sge i64 0, 0
  br i1 %t106, label %bb32, label %bb33
bb32:
  %t108 = icmp sle i64 0, 88
  br i1 %t108, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb34:
  %t110 = load i64, ptr %l58, !tbaa !24
  %t111 = icmp sle i64 88, %t110
  br i1 %t111, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb36:
  %t113 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 0
  %t116 = sub i64 88, 0
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  store { i64, ptr } %t118, ptr %l62, !tbaa !27
  %t119 = load i64, ptr %l9, !tbaa !65
  %t121 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t119)
  store { i64, ptr } %t121, ptr %l64
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb38:
  %t122 = load i64, ptr %l10, !tbaa !65
  %t124 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t122)
  store { i64, ptr } %t124, ptr %l66
  br label %bb39
bb39:
  %t125 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } { i64 2, ptr @.d5 }, 1
  %t129 = extractvalue { i64, ptr } { i64 2, ptr @.d5 }, 0
  %t130 = add i64 %t127, %t129
  %t131 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t126, i64 %t127)
  %t140 = getelementptr i8, ptr %t139, i64 %t127
  call void @olang_textcopy(ptr %t140, ptr %t128, i64 %t129)
  %t141 = getelementptr i8, ptr %t140, i64 %t129
  call void @olang_textcopy(ptr %t141, ptr %t132, i64 %t133)
  %t142 = getelementptr i8, ptr %t141, i64 %t133
  call void @olang_textcopy(ptr %t142, ptr %t136, i64 %t137)
  %t143 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t139, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eUnknownT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %v0, i64 %a0) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l2, !tbaa !65
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !65
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t8, i64 %t9)
  store { i64, ptr } %t10, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c6)
  unreachable
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eVoidT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eWritable_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i64
  %l13 = alloca ptr
  %l19 = alloca %"compiler/types:decl"
  %l21 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l6, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/types:Table", ptr %t10, i32 0, i32 13
  store ptr %t12, ptr %l13, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = load i32, ptr %l2, !tbaa !23
  %t23 = call %"compiler/types:decl" @compiler_2ftypes_3adecl_2ector(ptr %s0, i64 %t13, i32 %t14, i32 %a3, i32 %a4, i64 %a5)
  store %"compiler/types:decl" %t23, ptr %l19
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load %"compiler/types:decl", ptr %l19
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t24, %"compiler/types:decl" %t25)
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/types:Table", ptr %t26, i32 0, i32 15
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/types:Table", ptr %t29, i32 0, i32 14
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t31, i64 %t32)
  store { i64, ptr } %t35, ptr %l25
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/types:Table", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l29
  br label %bb5
bb5:
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 0
  %t49 = add i64 %t46, %t48
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t47, i64 %t48)
  %t56 = getelementptr i8, ptr %t55, i64 %t48
  call void @olang_textcopy(ptr %t56, ptr %t51, i64 %t52)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load i32, ptr %l6, !tbaa !23
  %t67 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v0, ptr %t67, { i64, ptr } %t65, i32 %t66)
  br label %bb6
bb6:
  %t70 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 14
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = extractvalue { i64, ptr } %t10, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t3, { i64, ptr } %t17)
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 14
  %t24 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l9
  br label %bb2
bb2:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = sub i64 %t25, 1
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 20
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i32
  %l29 = alloca %"std/prelude/text:StringBuilder"
  %l37 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l63 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l102 = alloca i64
  %l110 = alloca ptr
  %l122 = alloca i1
  %l126 = alloca i1
  %l130 = alloca { i64, ptr }
  %l134 = alloca i64
  %l143 = alloca i64
  %l146 = alloca i64
  %l164 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l178 = alloca %"compiler/types:data"
  %l181 = alloca i32
  %l183 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l28
  br label %bb1
bb1:
  %t6 = load i32, ptr %l28, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l29
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l29
  store %"std/prelude/text:StringBuilder" %t8, ptr %l5
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l8, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t23, ptr %l37, !tbaa !27
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  %t34 = sext i32 %t29 to i64
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t34)
  %t41 = getelementptr i8, ptr %t39, i64 %t35
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t50)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb3
bb9:
  %t57 = load i32, ptr %l4, !tbaa !23
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 0
  %t62 = sext i32 %t57 to i64
  %t63 = call i64 @__olang_fmt_i64(ptr null, i64 %t62)
  %t64 = add i64 %t60, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t59, i64 %t60)
  %t66 = getelementptr i8, ptr %t65, i64 %t60
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t62)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t76)
  br label %bb10
bb10:
  %t80 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t80, ptr %l53
  br label %bb11
bb11:
  %t81 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t81, ptr %l10, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/types:Table", ptr %t82, i32 0, i32 10
  %t85 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t88 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s0, ptr %t84, { i64, ptr } %t85)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l59
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb13, label %ok.92
ok.92:
  store i64 %t89, ptr %l58
  br label %bb12
bb12:
  %t93 = load i64, ptr %l58, !tbaa !24
  store i64 %t93, ptr %l54, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb15
bb15:
  %t94 = load i64, ptr %l54, !tbaa !24
  store i64 %t94, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb16, label %bb17
bb16:
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l63, !tbaa !24
  %t102 = load i64, ptr %l63, !tbaa !24
  %t103 = icmp sge i64 %t102, 0
  br i1 %t103, label %bb18, label %bb19
bb17:
  br label %bb43
bb18:
  %t105 = load i64, ptr %l63, !tbaa !24
  %t106 = icmp sle i64 %t105, 2305843009213693951
  br i1 %t106, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb20:
  %t108 = load i64, ptr %l63, !tbaa !24
  %t109 = mul i64 %t108, 4
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t118 = load i64, ptr %l14, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb22:
  %t124 = load i64, ptr %l15, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb27
bb24:
  %t128 = load i64, ptr %l14, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l15, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l15, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l75, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb26
bb26:
  %t144 = load i64, ptr %l75, !tbaa !24
  store i64 %t144, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t145 = load i64, ptr %l72, !tbaa !24
  store i64 %t145, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t146 = load i64, ptr %l17, !tbaa !24
  %t147 = load i64, ptr %l16, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l17, !tbaa !24
  %t156 = load i64, ptr %l15, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l18, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t164, ptr %l93, !tbaa !27
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t166, ptr %l95, !tbaa !27
  %t167 = load i64, ptr %l18, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i32, ptr %t170, i64 %t167
  %t172 = load i32, ptr %t171, !tbaa !33
  %t175 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i32, ptr %t176, i64 %t165
  store i32 %t172, ptr %t177, !tbaa !33
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb32:
  %t178 = load i64, ptr %l17, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l17, !tbaa !24
  br label %bb28
bb33:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/types:Table", ptr %t182, i32 0, i32 7
  %t186 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H9437066785f0bdbcfc17884fffb14a92(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l102
  br label %bb34
bb34:
  %t187 = load i64, ptr %l102, !tbaa !24
  store i64 %t187, ptr %l11, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/types:Table", ptr %t188, i32 0, i32 7
  %t191 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v0, ptr %t190, { i64, ptr } %t191)
  br label %bb35
bb35:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/types:Table", ptr %t194, i32 0, i32 8
  %t197 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t196, i32 %t197)
  br label %bb36
bb36:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/types:Table", ptr %t200, i32 0, i32 9
  store ptr %t202, ptr %l110, !tbaa !29
  %t203 = icmp sge i64 0, 0
  br i1 %t203, label %bb37, label %bb38
bb37:
  %t205 = icmp sle i64 0, 2305843009213693951
  br i1 %t205, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb39:
  %t207 = mul i64 0, 4
  %t208 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 0, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t211 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v0, ptr %t211, { i64, ptr } %t210)
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb41:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/types:Table", ptr %t213, i32 0, i32 10
  %t216 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t216, 1
  %t219 = extractvalue { i64, ptr } %t216, 0
  %t220 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t219)
  call void @olang_textcopy(ptr %t220, ptr %t218, i64 %t219)
  %t221 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = extractvalue { i64, ptr } %t222, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t230 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t215, { i64, ptr } %t229, i64 %t230)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t234 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t237 = extractvalue { i64, ptr } zeroinitializer, 0
  %t238 = icmp eq i64 %t236, %t237
  %t239 = extractvalue { i64, ptr } %t234, 1
  %t240 = extractvalue { i64, ptr } zeroinitializer, 1
  %t241 = icmp eq ptr %t239, %t240
  %t242 = and i1 %t238, %t241
  %t243 = xor i1 %t242, true
  br i1 %t243, label %bb44, label %bb45
bb44:
  %t245 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t249 = icmp sgt i64 %t247, 0
  store i1 %t249, ptr %l122, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb46
bb46:
  %t251 = load i1, ptr %l122, !tbaa !21
  br i1 %t251, label %bb47, label %bb48
bb47:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/types:Table", ptr %t252, i32 0, i32 9
  %t255 = load i64, ptr %l11, !tbaa !24
  %t258 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %s0, ptr %t254, i64 %t255)
  store { i64, ptr } %t258, ptr %l130
  br label %bb49
bb48:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb50
bb49:
  %t259 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  %t262 = icmp eq i64 %t260, 0
  store i1 %t262, ptr %l126, !tbaa !21
  br label %bb50
bb50:
  %t264 = load i1, ptr %l126, !tbaa !21
  br i1 %t264, label %bb51, label %bb52
bb51:
  %t265 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  store i64 %t267, ptr %l134, !tbaa !24
  %t268 = load i64, ptr %l134, !tbaa !24
  %t269 = icmp sge i64 %t268, 0
  br i1 %t269, label %bb53, label %bb54
bb52:
  br label %bb70
bb53:
  %t271 = load i64, ptr %l134, !tbaa !24
  %t272 = icmp sle i64 %t271, 2305843009213693951
  br i1 %t272, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb55:
  %t274 = load i64, ptr %l134, !tbaa !24
  %t275 = mul i64 %t274, 4
  %t276 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t275)
  %t277 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  store i64 %t282, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t284 = load i64, ptr %l21, !tbaa !24
  %t285 = load i64, ptr %l20, !tbaa !24
  %t288 = icmp sgt i64 %t284, %t285
  br i1 %t288, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb57:
  %t290 = load i64, ptr %l22, !tbaa !24
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb62
bb59:
  %t294 = load i64, ptr %l21, !tbaa !24
  %t295 = load i64, ptr %l20, !tbaa !24
  %t298 = sub i64 %t294, %t295
  %t299 = load i64, ptr %l22, !tbaa !24
  %t302 = add i64 %t298, %t299
  %t304 = sub i64 %t302, 1
  %t305 = load i64, ptr %l22, !tbaa !24
  %t308 = sdiv i64 %t304, %t305
  store i64 %t308, ptr %l146, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb61
bb61:
  %t310 = load i64, ptr %l146, !tbaa !24
  store i64 %t310, ptr %l143, !tbaa !24
  br label %bb62
bb62:
  %t311 = load i64, ptr %l143, !tbaa !24
  store i64 %t311, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t312 = load i64, ptr %l24, !tbaa !24
  %t313 = load i64, ptr %l23, !tbaa !24
  %t316 = icmp slt i64 %t312, %t313
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb65:
  br label %bb66
bb66:
  %t320 = load i64, ptr %l20, !tbaa !24
  %t321 = load i64, ptr %l24, !tbaa !24
  %t322 = load i64, ptr %l22, !tbaa !24
  %t325 = mul i64 %t321, %t322
  %t328 = add i64 %t320, %t325
  store i64 %t328, ptr %l25, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t330, ptr %l164, !tbaa !27
  %t331 = load i64, ptr %l25, !tbaa !24
  %t332 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t332, ptr %l166, !tbaa !27
  %t333 = load i64, ptr %l25, !tbaa !24
  %t335 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr i32, ptr %t336, i64 %t333
  %t338 = load i32, ptr %t337, !tbaa !33
  %t341 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i32, ptr %t342, i64 %t331
  store i32 %t338, ptr %t343, !tbaa !33
  call void @__olang_scope_close(ptr %s13)
  br label %bb67
bb67:
  %t344 = load i64, ptr %l24, !tbaa !24
  %t346 = add i64 %t344, 1
  store i64 %t346, ptr %l24, !tbaa !24
  br label %bb63
bb68:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/types:Table", ptr %t348, i32 0, i32 9
  %t351 = load i64, ptr %l11, !tbaa !24
  %t352 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hcaffdb9d24c80e421d58a725793b74fc(ptr %v0, ptr %v0, ptr %t350, i64 %t351, { i64, ptr } %t352)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l175, !tbaa !29
  %t357 = load i64, ptr %l11, !tbaa !24
  %t360 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 24, i64 %t357, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t360, ptr %l178
  br label %bb71
bb71:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l4, !tbaa !23
  %t365 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t361, i32 %t362)
  store i32 %t365, ptr %l181
  br label %bb72
bb72:
  %t366 = load i32, ptr %l181, !tbaa !23
  %t367 = add i32 %t366, 1
  %t368 = load ptr, ptr %l175, !tbaa !29
  %t369 = load %"compiler/types:data", ptr %l178
  %t371 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t368, %"compiler/types:data" %t369, i32 %t367)
  store i32 %t371, ptr %l183
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t372 = load i32, ptr %l183, !tbaa !23
  store i32 %t372, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l10 = alloca %"compiler/types:data"
  %l13 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca i32
  %l30 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load i32, ptr %l2, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t11 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 19, i64 %t4, i64 %t7, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = add i32 %t17, 1
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load %"compiler/types:data", ptr %l10
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t19, %"compiler/types:data" %t20, i32 %t18)
  store i32 %t22, ptr %l15
  br label %bb3
bb3:
  %t23 = load i32, ptr %l15, !tbaa !23
  store i32 %t23, ptr %l3, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l18
  br label %bb4
bb4:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load i32, ptr %l18, !tbaa !23
  %t32 = icmp ne i32 %t30, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/types:Table", ptr %t34, i32 0, i32 25
  store ptr %t36, ptr %l22, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t39 = sext i32 %t37 to i64
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l28
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t46 = load i32, ptr %l2, !tbaa !23
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i32, ptr %l28, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t47, i32 %t48, i32 %t46)
  store i32 %t50, ptr %l30
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load i64, ptr %l24, !tbaa !24
  %t53 = load i32, ptr %l30, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t51, i64 %t52, i32 %t53)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t54 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 2
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sle i32 %t1, 14
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr [15 x i64], ptr @G_2ecompiler_2ftypes_2eprimBits, i64 0, i64 %t7
  %t10 = load i64, ptr %t9, !tbaa !34
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eByAddress(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l23 = alloca i32
  %l25 = alloca i1
  %l30 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i32, ptr %l9
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3
  %t15 = trunc i64 22 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load i32, ptr %l3
  %t20 = trunc i64 23 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb25
bb8:
  %t23 = load i32, ptr %l3
  %t25 = trunc i64 18 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l20
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l21
  br label %bb13
bb13:
  store i32 0, ptr %l23
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %l21, ptr %l23)
  store i1 %t39, ptr %l25
  br label %bb14
bb14:
  %t40 = load i1, ptr %l25, !tbaa !21
  store i1 %t40, ptr %l10, !tbaa !21
  br label %bb25
bb15:
  %t41 = load i32, ptr %l3
  %t43 = trunc i64 19 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l30
  br label %bb19
bb19:
  %t51 = load i32, ptr %l30, !tbaa !23
  %t52 = icmp ne i32 %t51, 0
  store i1 %t52, ptr %l10, !tbaa !21
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb25:
  %t54 = load i1, ptr %l10, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 3
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 3
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t9, ptr %lp2
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = load ptr, ptr %lp2
  store { i64, ptr } %t10, ptr %t11, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/types:Table", ptr %t12, i32 0, i32 3
  store i1 false, ptr %t14, !tbaa !21
  %t15 = load ptr, ptr %lp2
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 17
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } zeroinitializer, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l8 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i64
  %l34 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i32
  %l47 = alloca i1
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i1
  %l81 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca i1
  %l88 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  %t15 = load i32, ptr %l3
  %t17 = trunc i64 25 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  %t20 = load i32, ptr %l3
  %t22 = trunc i64 27 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  %t25 = load i32, ptr %l3
  %t27 = trunc i64 15 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb78
bb11:
  %t30 = load i32, ptr %l3
  %t32 = trunc i64 18 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t35 = load i32, ptr %l3
  %t37 = trunc i64 22 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t40 = load i32, ptr %l3
  %t42 = trunc i64 23 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l24
  store i32 18, ptr %l26
  %t50 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l24, ptr %l26)
  store i1 %t50, ptr %l28
  br label %bb19
bb19:
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb20, label %bb21
bb20:
  %t52 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb22
bb21:
  %t55 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l29, !tbaa !24
  br label %bb22
bb22:
  %t58 = load i64, ptr %l29, !tbaa !24
  %t59 = trunc i64 %t58 to i32
  %t61 = load ptr, ptr %l23, !tbaa !29
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t61, i32 %t59)
  store i1 %t63, ptr %l34
  br label %bb23
bb23:
  %t64 = load i1, ptr %l34, !tbaa !21
  store i1 %t64, ptr %l8, !tbaa !21
  br label %bb78
bb24:
  %t65 = load i32, ptr %l3
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb39
bb27:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l1, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l40
  br label %bb28
bb28:
  %t76 = load ptr, ptr %l37, !tbaa !29
  %t77 = load i32, ptr %l40, !tbaa !23
  %t78 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t78, ptr %l41
  br label %bb29
bb29:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb30, label %bb31
bb30:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l45
  br label %bb32
bb31:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb38
bb32:
  %t85 = load i32, ptr %l45, !tbaa !23
  %t86 = icmp eq i32 %t85, 0
  br i1 %t86, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb37
bb34:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l48, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l51
  br label %bb35
bb35:
  %t94 = load ptr, ptr %l48, !tbaa !29
  %t95 = load i32, ptr %l51, !tbaa !23
  %t96 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t96, ptr %l52
  br label %bb36
bb36:
  %t97 = load i1, ptr %l52, !tbaa !21
  store i1 %t97, ptr %l47, !tbaa !21
  br label %bb37
bb37:
  %t98 = load i1, ptr %l47, !tbaa !21
  store i1 %t98, ptr %l42, !tbaa !21
  br label %bb38
bb38:
  %t99 = load i1, ptr %l42, !tbaa !21
  store i1 %t99, ptr %l8, !tbaa !21
  br label %bb78
bb39:
  %t100 = load i32, ptr %l3
  %t102 = trunc i64 20 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l58
  br label %bb43
bb43:
  %t111 = load ptr, ptr %l55, !tbaa !29
  %t112 = load i32, ptr %l58, !tbaa !23
  %t113 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t113, ptr %l59
  br label %bb44
bb44:
  %t114 = load i1, ptr %l59, !tbaa !21
  store i1 %t114, ptr %l8, !tbaa !21
  br label %bb78
bb45:
  %t115 = load i32, ptr %l3
  %t117 = trunc i64 21 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb61
bb48:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l62, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l1, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l65
  br label %bb49
bb49:
  %t126 = load ptr, ptr %l62, !tbaa !29
  %t127 = load i32, ptr %l65, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l66
  br label %bb50
bb50:
  %t129 = load i1, ptr %l66, !tbaa !21
  br i1 %t129, label %bb51, label %bb52
bb51:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l68, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l71
  br label %bb53
bb52:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb55
bb53:
  %t136 = load ptr, ptr %l68, !tbaa !29
  %t137 = load i32, ptr %l71, !tbaa !23
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t138, ptr %l72
  br label %bb54
bb54:
  %t139 = load i1, ptr %l72, !tbaa !21
  store i1 %t139, ptr %l67, !tbaa !21
  br label %bb55
bb55:
  %t140 = load i1, ptr %l67, !tbaa !21
  br i1 %t140, label %bb56, label %bb57
bb56:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l74, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l77
  br label %bb58
bb57:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb60
bb58:
  %t147 = load ptr, ptr %l74, !tbaa !29
  %t148 = load i32, ptr %l77, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t147, i32 %t148)
  store i1 %t149, ptr %l78
  br label %bb59
bb59:
  %t150 = load i1, ptr %l78, !tbaa !21
  store i1 %t150, ptr %l73, !tbaa !21
  br label %bb60
bb60:
  %t151 = load i1, ptr %l73, !tbaa !21
  store i1 %t151, ptr %l8, !tbaa !21
  br label %bb78
bb61:
  %t152 = load i32, ptr %l3
  %t154 = trunc i64 24 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l1, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l84
  br label %bb65
bb65:
  %t163 = load ptr, ptr %l81, !tbaa !29
  %t164 = load i32, ptr %l84, !tbaa !23
  %t165 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t165, ptr %l85
  br label %bb66
bb66:
  %t166 = load i1, ptr %l85, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb78
bb67:
  %t167 = load i32, ptr %l3
  %t169 = trunc i64 26 to i32
  %t170 = icmp eq i32 %t167, %t169
  br i1 %t170, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb73
bb70:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l88, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l91
  br label %bb71
bb71:
  %t178 = load ptr, ptr %l88, !tbaa !29
  %t179 = load i32, ptr %l91, !tbaa !23
  %t180 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t178, i32 %t179)
  store i1 %t180, ptr %l92
  br label %bb72
bb72:
  %t181 = load i1, ptr %l92, !tbaa !21
  store i1 %t181, ptr %l8, !tbaa !21
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb78:
  %t182 = load i1, ptr %l8, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i64
  %l19 = alloca { i64, i64 }
  %l20 = alloca { i64, i64 }
  %l21 = alloca i32
  %l22 = alloca { i64, i64 }
  %l23 = alloca { i64, i64 }
  %l26 = alloca i32
  %l27 = alloca i64
  %l31 = alloca %"compiler/types:data"
  %l66 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i1
  %l95 = alloca i32
  %l99 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca i32
  %l105 = alloca i32
  %l107 = alloca i1
  %l112 = alloca i32
  %l115 = alloca i64
  %l116 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca i64
  %l124 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca i32
  %l135 = alloca i32
  %l136 = alloca { i64, i64 }
  %l141 = alloca ptr
  %l142 = alloca i32
  %l145 = alloca i32
  %l146 = alloca { i64, i64 }
  %l153 = alloca i1
  %l156 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i32
  %l163 = alloca ptr
  %l164 = alloca i32
  %l167 = alloca i32
  %l168 = alloca { i64, i64 }
  %l173 = alloca ptr
  %l174 = alloca i32
  %l177 = alloca i32
  %l178 = alloca { i64, i64 }
  %l189 = alloca i32
  %l192 = alloca i64
  %l198 = alloca i64
  %l201 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l31
  store %"compiler/types:data" %t6, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l5
  %t10 = load i32, ptr %l5
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  %t15 = load i32, ptr %l5
  %t17 = trunc i64 17 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb135
bb7:
  %t20 = load i32, ptr %l5
  %t22 = trunc i64 2 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb8, label %bb9
bb8:
  br label %bb34
bb9:
  %t25 = load i32, ptr %l5
  %t27 = trunc i64 3 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb34
bb11:
  %t30 = load i32, ptr %l5
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb34
bb13:
  %t35 = load i32, ptr %l5
  %t37 = trunc i64 5 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb14, label %bb15
bb14:
  br label %bb34
bb15:
  %t40 = load i32, ptr %l5
  %t42 = trunc i64 6 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb34
bb17:
  %t45 = load i32, ptr %l5
  %t47 = trunc i64 7 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb18, label %bb19
bb18:
  br label %bb34
bb19:
  %t50 = load i32, ptr %l5
  %t52 = trunc i64 8 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb20, label %bb21
bb20:
  br label %bb34
bb21:
  %t55 = load i32, ptr %l5
  %t57 = trunc i64 9 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb34
bb23:
  %t60 = load i32, ptr %l5
  %t62 = trunc i64 10 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb24, label %bb25
bb24:
  br label %bb34
bb25:
  %t65 = load i32, ptr %l5
  %t67 = trunc i64 11 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  %t70 = load i32, ptr %l5
  %t72 = trunc i64 12 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  %t75 = load i32, ptr %l5
  %t77 = trunc i64 13 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t80 = load i32, ptr %l5
  %t82 = trunc i64 14 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = icmp ne i32 %t85, %t86
  br i1 %t89, label %bb35, label %bb36
bb35:
  %t91 = load i32, ptr %l1, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t95 = getelementptr [15 x i64], ptr @G_2ecompiler_2ftypes_2eprimBits, i64 0, i64 %t93
  %t96 = load i64, ptr %t95, !tbaa !34
  %t98 = sdiv i64 %t96, 8
  store i64 %t98, ptr %l66, !tbaa !24
  br label %bb37
bb36:
  store i64 1, ptr %l66, !tbaa !24
  br label %bb37
bb37:
  %t100 = load i64, ptr %l66, !tbaa !24
  store i64 %t100, ptr %l3, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb135
bb38:
  %t103 = load i32, ptr %l5
  %t105 = trunc i64 16 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb135
bb42:
  %t112 = load i32, ptr %l5
  %t114 = trunc i64 21 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb135
bb46:
  %t121 = load i32, ptr %l5
  %t123 = trunc i64 20 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb55
bb49:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l82, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l85
  br label %bb50
bb50:
  %t132 = load ptr, ptr %l82, !tbaa !29
  %t133 = load i32, ptr %l85, !tbaa !23
  %t134 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t132, i32 %t133)
  store i1 %t134, ptr %l86
  br label %bb51
bb51:
  %t135 = load i1, ptr %l86, !tbaa !21
  br i1 %t135, label %bb52, label %bb53
bb52:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb54
bb53:
  store i64 8, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb54
bb54:
  br label %bb135
bb55:
  %t144 = load i32, ptr %l5
  %t146 = trunc i64 19 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb74
bb58:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l95
  br label %bb59
bb59:
  %t154 = load i32, ptr %l95, !tbaa !23
  %t155 = icmp eq i32 %t154, 0
  br i1 %t155, label %bb60, label %bb61
bb60:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb73
bb61:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l99, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l1, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l102
  br label %bb62
bb62:
  %t167 = load ptr, ptr %l99, !tbaa !29
  %t168 = load i32, ptr %l102, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t169, ptr %l103
  br label %bb63
bb63:
  store i32 26, ptr %l105
  %t172 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l103, ptr %l105)
  store i1 %t172, ptr %l107
  br label %bb64
bb64:
  %t173 = load i1, ptr %l107, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb65, label %bb66
bb65:
  store i1 false, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l1, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l112
  br label %bb68
bb68:
  %t182 = load i32, ptr %l112, !tbaa !23
  store i32 %t182, ptr %l16, !tbaa !23
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l16, !tbaa !23
  %t187 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t183, i32 %t184)
  store i64 %t187, ptr %l115
  br label %bb69
bb69:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l116, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l1, !tbaa !23
  %t193 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t189, i32 %t190)
  store i32 %t193, ptr %l119
  br label %bb70
bb70:
  %t194 = load ptr, ptr %l116, !tbaa !29
  %t195 = load i32, ptr %l119, !tbaa !23
  %t196 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t194, i32 %t195)
  store i64 %t196, ptr %l120
  br label %bb71
bb71:
  %t197 = load i64, ptr %l115, !tbaa !24
  %t198 = load i64, ptr %l120, !tbaa !24
  %t199 = mul i64 %t197, %t198
  store i64 %t199, ptr %l17, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l16, !tbaa !23
  %t205 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t201, i32 %t202)
  store i64 %t205, ptr %l124
  br label %bb72
bb72:
  %t206 = load i64, ptr %l124, !tbaa !24
  %t207 = load i64, ptr %l17, !tbaa !24
  store i64 %t207, ptr %l3, !tbaa !24
  store i64 %t206, ptr %l4, !tbaa !24
  br label %bb73
bb73:
  br label %bb135
bb74:
  %t211 = load i32, ptr %l5
  %t213 = trunc i64 22 to i32
  %t214 = icmp eq i32 %t211, %t213
  br i1 %t214, label %bb75, label %bb76
bb75:
  br label %bb79
bb76:
  %t216 = load i32, ptr %l5
  %t218 = trunc i64 23 to i32
  %t219 = icmp eq i32 %t216, %t218
  br i1 %t219, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l131, !tbaa !29
  %t222 = load i32, ptr %l1, !tbaa !23
  store i32 %t222, ptr %l132, !tbaa !23
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l1, !tbaa !23
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t227, ptr %l135
  br label %bb80
bb80:
  %t228 = load ptr, ptr %l131, !tbaa !29
  %t229 = load i32, ptr %l132, !tbaa !23
  %t230 = load i32, ptr %l135, !tbaa !23
  %t231 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t228, i32 %t229, i32 %t230)
  store { i64, i64 } %t231, ptr %l136
  br label %bb81
bb81:
  %t232 = load { i64, i64 }, ptr %l136
  store { i64, i64 } %t232, ptr %l19
  %t233 = getelementptr { i64, i64 }, ptr %l19, i32 0, i32 0
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l3, !tbaa !24
  %t236 = getelementptr { i64, i64 }, ptr %l19, i32 0, i32 1
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l4, !tbaa !24
  br label %bb135
bb82:
  %t239 = load i32, ptr %l5
  %t241 = trunc i64 24 to i32
  %t242 = icmp eq i32 %t239, %t241
  br i1 %t242, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l141, !tbaa !29
  %t245 = load i32, ptr %l1, !tbaa !23
  store i32 %t245, ptr %l142, !tbaa !23
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i32, ptr %l1, !tbaa !23
  %t250 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t246, i32 %t247)
  store i32 %t250, ptr %l145
  br label %bb86
bb86:
  %t251 = load ptr, ptr %l141, !tbaa !29
  %t252 = load i32, ptr %l142, !tbaa !23
  %t253 = load i32, ptr %l145, !tbaa !23
  %t254 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t251, i32 %t252, i32 %t253)
  store { i64, i64 } %t254, ptr %l146
  br label %bb87
bb87:
  %t255 = load { i64, i64 }, ptr %l146
  store { i64, i64 } %t255, ptr %l20
  %t256 = getelementptr { i64, i64 }, ptr %l20, i32 0, i32 0
  %t257 = load i64, ptr %t256, !tbaa !24
  store i64 %t257, ptr %l3, !tbaa !24
  %t259 = getelementptr { i64, i64 }, ptr %l20, i32 0, i32 1
  %t260 = load i64, ptr %t259, !tbaa !24
  store i64 %t260, ptr %l4, !tbaa !24
  br label %bb135
bb88:
  %t262 = load i32, ptr %l5
  %t264 = trunc i64 18 to i32
  %t265 = icmp eq i32 %t262, %t264
  br i1 %t265, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb130
bb91:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l1, !tbaa !23
  %t271 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t267, i32 %t268)
  store i1 %t271, ptr %l153
  br label %bb92
bb92:
  %t272 = load i1, ptr %l153, !tbaa !21
  %t273 = xor i1 %t272, true
  br i1 %t273, label %bb93, label %bb94
bb93:
  store i1 false, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l156, !tbaa !29
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i32, ptr %l1, !tbaa !23
  %t281 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t277, i32 %t278)
  store i32 %t281, ptr %l159
  br label %bb96
bb96:
  %t282 = load ptr, ptr %l156, !tbaa !29
  %t283 = load i32, ptr %l159, !tbaa !23
  %t284 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t282, i32 %t283)
  store i32 %t284, ptr %l160
  br label %bb97
bb97:
  %t285 = load i32, ptr %l160
  store i32 %t285, ptr %l21
  %t286 = load i32, ptr %l21
  %t288 = trunc i64 0 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l163, !tbaa !29
  %t292 = load i32, ptr %l1, !tbaa !23
  store i32 %t292, ptr %l164, !tbaa !23
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i32, ptr %l1, !tbaa !23
  %t297 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t293, i32 %t294)
  store i32 %t297, ptr %l167
  br label %bb101
bb101:
  %t298 = load ptr, ptr %l163, !tbaa !29
  %t299 = load i32, ptr %l164, !tbaa !23
  %t300 = load i32, ptr %l167, !tbaa !23
  %t301 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t298, i32 %t299, i32 %t300)
  store { i64, i64 } %t301, ptr %l168
  br label %bb102
bb102:
  %t302 = load { i64, i64 }, ptr %l168
  store { i64, i64 } %t302, ptr %l22
  %t303 = getelementptr { i64, i64 }, ptr %l22, i32 0, i32 0
  %t304 = load i64, ptr %t303, !tbaa !24
  store i64 %t304, ptr %l3, !tbaa !24
  %t306 = getelementptr { i64, i64 }, ptr %l22, i32 0, i32 1
  %t307 = load i64, ptr %t306, !tbaa !24
  store i64 %t307, ptr %l4, !tbaa !24
  br label %bb129
bb103:
  %t309 = load i32, ptr %l21
  %t311 = trunc i64 1 to i32
  %t312 = icmp eq i32 %t309, %t311
  br i1 %t312, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb109
bb106:
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l173, !tbaa !29
  %t315 = load i32, ptr %l1, !tbaa !23
  store i32 %t315, ptr %l174, !tbaa !23
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l1, !tbaa !23
  %t320 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t316, i32 %t317)
  store i32 %t320, ptr %l177
  br label %bb107
bb107:
  %t321 = load ptr, ptr %l173, !tbaa !29
  %t322 = load i32, ptr %l174, !tbaa !23
  %t323 = load i32, ptr %l177, !tbaa !23
  %t324 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t321, i32 %t322, i32 %t323)
  store { i64, i64 } %t324, ptr %l178
  br label %bb108
bb108:
  %t325 = load { i64, i64 }, ptr %l178
  store { i64, i64 } %t325, ptr %l23
  %t326 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 0
  %t327 = load i64, ptr %t326, !tbaa !24
  store i64 %t327, ptr %l3, !tbaa !24
  %t329 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 1
  %t330 = load i64, ptr %t329, !tbaa !24
  store i64 %t330, ptr %l4, !tbaa !24
  br label %bb129
bb109:
  %t332 = load i32, ptr %l21
  %t334 = trunc i64 2 to i32
  %t335 = icmp eq i32 %t332, %t334
  br i1 %t335, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb129
bb113:
  %t341 = load i32, ptr %l21
  %t343 = trunc i64 4 to i32
  %t344 = icmp eq i32 %t341, %t343
  br i1 %t344, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb124
bb116:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i32, ptr %l1, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t346, i32 %t347)
  store i32 %t350, ptr %l189
  br label %bb117
bb117:
  %t351 = load i32, ptr %l189, !tbaa !23
  store i32 %t351, ptr %l26, !tbaa !23
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i32, ptr %l26, !tbaa !23
  %t356 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t352, i32 %t353)
  store i64 %t356, ptr %l192
  br label %bb118
bb118:
  %t357 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t358 = load i64, ptr %l192, !tbaa !24
  %t360 = icmp ne i64 %t358, %t357
  br i1 %t360, label %bb119, label %bb120
bb119:
  store i1 false, ptr %rv
  br label %ret
bb120:
  br label %bb121
bb121:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load i32, ptr %l26, !tbaa !23
  %t367 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t363, i32 %t364)
  store i64 %t367, ptr %l198
  br label %bb122
bb122:
  %t368 = load i64, ptr %l198, !tbaa !24
  store i64 %t368, ptr %l27, !tbaa !24
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i32, ptr %l26, !tbaa !23
  %t373 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t369, i32 %t370)
  store i64 %t373, ptr %l201
  br label %bb123
bb123:
  %t374 = load i64, ptr %l201, !tbaa !24
  %t375 = load i64, ptr %l27, !tbaa !24
  store i64 %t375, ptr %l3, !tbaa !24
  store i64 %t374, ptr %l4, !tbaa !24
  br label %bb129
bb124:
  %t379 = load i32, ptr %l21
  %t381 = trunc i64 3 to i32
  %t382 = icmp eq i32 %t379, %t381
  br i1 %t382, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  store i1 false, ptr %rv
  br label %ret
bb128:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb129:
  br label %bb135
bb130:
  br i1 true, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb134
bb133:
  store i1 false, ptr %rv
  br label %ret
bb134:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb135:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/types:Table", ptr %t386, i32 0, i32 19
  %t389 = load i32, ptr %l1, !tbaa !23
  %t391 = sext i32 %t389 to i64
  %t392 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t388, i64 %t391, i64 %t392)
  br label %bb136
bb136:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/types:Table", ptr %t396, i32 0, i32 20
  %t399 = load i32, ptr %l1, !tbaa !23
  %t401 = sext i32 %t399 to i64
  %t402 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t398, i64 %t401, i64 %t402)
  br label %bb137
bb137:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  %t4 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 26, i64 %t4, i64 %a2, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l8
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t10, %"compiler/types:data" %t11, i32 1)
  store i32 %t12, ptr %l9
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l29 = alloca %"compiler/types:data"
  %l30 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 12
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/types:Table", ptr %t18, i32 0, i32 11
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l13
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t23 = load i64, ptr %l13, !tbaa !24
  store i64 %t23, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/types:Table", ptr %t24, i32 0, i32 11
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t29, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t26, { i64, ptr } %t40)
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/types:Table", ptr %t43, i32 0, i32 12
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/types:Table", ptr %t46, i32 0, i32 11
  %t49 = load i64, ptr %l2, !tbaa !24
  %t52 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load ptr, ptr %l20, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t55, i64 %t53)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l26, !tbaa !29
  %t58 = load i64, ptr %l2, !tbaa !24
  %t61 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 27, i64 %t58, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t61, ptr %l29
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l26, !tbaa !29
  %t63 = load %"compiler/types:data", ptr %l29
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t62, %"compiler/types:data" %t63, i32 1)
  store i32 %t64, ptr %l30
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i32, ptr %l30, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 2
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 3
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDepth(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = sext i32 %t6 to i64
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 3
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i32
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca i32
  %l84 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i32
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l117 = alloca i32
  %l118 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l21
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l2
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l24
  br label %bb2
bb2:
  %t9 = load i32, ptr %l24
  store i32 %t9, ptr %l3
  %t10 = load i32, ptr %l3
  %t12 = trunc i64 18 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb44
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l27, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l30
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l27, !tbaa !29
  %t22 = load i32, ptr %l30, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l31
  br label %bb7
bb7:
  %t24 = load i32, ptr %l31
  store i32 %t24, ptr %l4
  %t25 = load i32, ptr %l4
  %t27 = trunc i64 0 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l34, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l37
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l34, !tbaa !29
  %t37 = load i32, ptr %l37, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t38, ptr %l38
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t39, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t52, ptr %l45, !tbaa !27
  %t53 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 %t53
  %t58 = load i32, ptr %t57, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t58)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t63 = load i64, ptr %l6, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l6, !tbaa !24
  br label %bb13
bb19:
  br label %bb43
bb20:
  %t67 = load i32, ptr %l4
  %t69 = trunc i64 1 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb36
bb23:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l54, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l57
  br label %bb24
bb24:
  %t78 = load ptr, ptr %l54, !tbaa !29
  %t79 = load i32, ptr %l57, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l58
  br label %bb25
bb25:
  %t81 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t81, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t94, ptr %l65, !tbaa !27
  %t95 = load i64, ptr %l10, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  store i32 %t100, ptr %l12, !tbaa !23
  %t102 = load i32, ptr %l12, !tbaa !23
  %t104 = icmp ne i32 %t102, 0
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t106)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  %t109 = load i64, ptr %l10, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l10, !tbaa !24
  br label %bb26
bb35:
  br label %bb43
bb36:
  %t113 = load i32, ptr %l4
  %t115 = trunc i64 4 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb42
bb39:
  store ptr %l2, ptr %l76, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l1, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l79
  br label %bb40
bb40:
  %t123 = load ptr, ptr %l76, !tbaa !29
  %t124 = load i32, ptr %l79, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t123, i32 %t124)
  br label %bb41
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb86
bb44:
  %t125 = load i32, ptr %l3
  %t127 = trunc i64 19 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb54
bb47:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l84
  br label %bb48
bb48:
  %t135 = load i32, ptr %l84, !tbaa !23
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb49, label %bb50
bb49:
  store ptr %l2, ptr %l86, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l1, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l89
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t143 = load ptr, ptr %l86, !tbaa !29
  %t144 = load i32, ptr %l89, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t143, i32 %t144)
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb86
bb54:
  %t145 = load i32, ptr %l3
  %t147 = trunc i64 22 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  %t150 = load i32, ptr %l3
  %t152 = trunc i64 23 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb69
bb59:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l94, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l1, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l97
  br label %bb60
bb60:
  %t161 = load ptr, ptr %l94, !tbaa !29
  %t162 = load i32, ptr %l97, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t161, i32 %t162)
  store { i64, ptr } %t163, ptr %l98
  br label %bb61
bb61:
  %t164 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t164, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l15, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s17
  %t169 = load i64, ptr %l14, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s17)
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t177, ptr %l105, !tbaa !27
  %t178 = load i64, ptr %l14, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 %t178
  %t183 = load i32, ptr %t182, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t183)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s17)
  br label %bb67
bb67:
  %t188 = load i64, ptr %l14, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l14, !tbaa !24
  br label %bb62
bb68:
  br label %bb86
bb69:
  %t192 = load i32, ptr %l3
  %t194 = trunc i64 24 to i32
  %t195 = icmp eq i32 %t192, %t194
  br i1 %t195, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb85
bb72:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l114, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i32, ptr %l1, !tbaa !23
  %t202 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t198, i32 %t199)
  store i32 %t202, ptr %l117
  br label %bb73
bb73:
  %t203 = load ptr, ptr %l114, !tbaa !29
  %t204 = load i32, ptr %l117, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t203, i32 %t204)
  store { i64, ptr } %t205, ptr %l118
  br label %bb74
bb74:
  %t206 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t206, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  store i64 %t209, ptr %l19, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s21
  %t211 = load i64, ptr %l18, !tbaa !24
  %t212 = load i64, ptr %l19, !tbaa !24
  %t215 = icmp slt i64 %t211, %t212
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s21)
  br label %bb84
bb77:
  br label %bb78
bb78:
  %t219 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t219, ptr %l125, !tbaa !27
  %t220 = load i64, ptr %l18, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i32, ptr %t223, i64 %t220
  %t225 = load i32, ptr %t224, !tbaa !33
  store i32 %t225, ptr %l20, !tbaa !23
  %t227 = load i32, ptr %l20, !tbaa !23
  %t229 = icmp ne i32 %t227, 0
  br i1 %t229, label %bb79, label %bb80
bb79:
  %t231 = load i32, ptr %l20, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t231)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s21)
  br label %bb83
bb83:
  %t234 = load i64, ptr %l18, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l18, !tbaa !24
  br label %bb75
bb84:
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t239 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t239, ptr %l135
  br label %bb87
bb87:
  %t240 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t240, ptr %l136, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l137, !tbaa !24
  %t243 = load i64, ptr %l137, !tbaa !24
  %t244 = mul i64 %t243, 4
  %t245 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l138, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l137, !tbaa !24
  %t253 = mul i64 %t252, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t254, ptr %l136, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t255 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t255, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store i32 28, ptr %l6
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l4, ptr %l6)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t10, i32 %t11)
  store i64 %t14, ptr %l12
  br label %bb5
bb4:
  %t15 = sub i64 0, 1
  store i64 %t15, ptr %l9, !tbaa !65
  br label %bb6
bb5:
  %t17 = load i64, ptr %l12, !tbaa !24
  store i64 %t17, ptr %l9, !tbaa !65
  br label %bb6
bb6:
  %t19 = load i64, ptr %l9, !tbaa !65
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i32
  %l12 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store i32 28, ptr %l6
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l4, ptr %l6)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t10, i32 %t11)
  store i64 %t14, ptr %l12
  br label %bb5
bb4:
  %t15 = load i32, ptr %l1, !tbaa !23
  store i32 %t15, ptr %l9, !tbaa !23
  br label %bb6
bb5:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = trunc i64 %t17 to i32
  store i32 %t18, ptr %l9, !tbaa !23
  br label %bb6
bb6:
  %t21 = load i32, ptr %l9, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  %t4 = sext i32 %a1 to i64
  %t10 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 28, i64 %t4, i64 %a2, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load %"compiler/types:data", ptr %l9
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t11, %"compiler/types:data" %t12, i32 1)
  store i32 %t13, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i32, ptr %l10, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFindDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 15
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H25f20ec7bc3952e7f71d4b5fc38b1e45(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  store i32 %t12, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, i32 } zeroinitializer, i32 %t21, 0
  store { i32, i32 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load i32, ptr %l2, !tbaa !23
  %t25 = insertvalue { i32, i32 } zeroinitializer, i32 %t24, 1
  store { i32, i32 } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l32 = alloca %"compiler/types:data"
  %l35 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i32
  %l44 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l56 = alloca ptr
  %l58 = alloca i64
  %l63 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i32, ptr %l12, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = load i32, ptr %l15, !tbaa !23
  %t15 = icmp sgt i32 %t13, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l20
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t22 = load i32, ptr %l20, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t27 = load i32, ptr %l2, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t30 = load i32, ptr %l3, !tbaa !23
  %t32 = sext i32 %t30 to i64
  %t33 = load i32, ptr %l4, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load i64, ptr %l5, !tbaa !24
  %t43 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 21, i64 %t26, i64 %t29, i64 %t32, i64 %t35, i64 %t36)
  store %"compiler/types:data" %t43, ptr %l32
  br label %bb7
bb7:
  %t44 = load i32, ptr %l6, !tbaa !23
  %t46 = add i32 %t44, 1
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load %"compiler/types:data", ptr %l32
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t47, %"compiler/types:data" %t48, i32 %t46)
  store i32 %t50, ptr %l35
  br label %bb8
bb8:
  %t51 = load i32, ptr %l35, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l38
  br label %bb9
bb9:
  %t57 = load i32, ptr %l38, !tbaa !23
  store i32 %t57, ptr %l8, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l41
  br label %bb10
bb10:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %l9, !tbaa !23
  %t64 = load i32, ptr %l4, !tbaa !23
  %t66 = icmp ne i32 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb13
bb12:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = icmp ne i64 %t68, 0
  store i1 %t70, ptr %l44, !tbaa !21
  br label %bb13
bb13:
  %t72 = load i1, ptr %l44, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i32, ptr %l8, !tbaa !23
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = icmp ne i32 %t73, %t74
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb19
bb18:
  %t80 = load i32, ptr %l9, !tbaa !23
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = icmp ne i32 %t80, %t81
  store i1 %t84, ptr %l51, !tbaa !21
  br label %bb19
bb19:
  %t86 = load i1, ptr %l51, !tbaa !21
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/types:Table", ptr %t87, i32 0, i32 25
  store ptr %t89, ptr %l56, !tbaa !29
  %t90 = load i32, ptr %l7, !tbaa !23
  %t92 = sext i32 %t90 to i64
  store i64 %t92, ptr %l58, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t95 = load i32, ptr %l9, !tbaa !23
  %t96 = load i32, ptr %l3, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t93, i32 %t94, i32 %t95, i32 %t96, i32 0, i64 0)
  store i32 %t101, ptr %l63
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t102 = load ptr, ptr %l56, !tbaa !29
  %t103 = load i64, ptr %l58, !tbaa !24
  %t104 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t102, i64 %t103, i32 %t104)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t105 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  %t29 = icmp ne i32 %t25, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb2
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i32
  %l18 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i1
  %l28 = alloca i32
  %l30 = alloca i32
  %l32 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i32
  %l37 = alloca i32
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i32
  %l44 = alloca i32
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i32
  %l51 = alloca i32
  %l53 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i32
  %l58 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i32
  %l65 = alloca i32
  %l67 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l76 = alloca i8
  %l88 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca i32
  %l95 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca i1
  %l109 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i1
  %l116 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i32
  %l141 = alloca i8
  %l143 = alloca i8
  %l144 = alloca ptr
  %l147 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  store i32 %t7, ptr %l10
  store i32 20, ptr %l12
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l10, ptr %l12)
  store i1 %t10, ptr %l14
  br label %bb2
bb2:
  %t11 = load i1, ptr %l14, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t12 = load i32, ptr %l2
  store i32 %t12, ptr %l16
  store i32 21, ptr %l18
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l16, ptr %l18)
  store i1 %t15, ptr %l20
  br label %bb5
bb5:
  %t16 = load i1, ptr %l20, !tbaa !21
  store i1 %t16, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l15, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb8:
  %t18 = load i32, ptr %l2
  store i32 %t18, ptr %l22
  store i32 25, ptr %l24
  %t21 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l22, ptr %l24)
  store i1 %t21, ptr %l26
  br label %bb9
bb9:
  %t22 = load i1, ptr %l26, !tbaa !21
  store i1 %t22, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t25 = load i32, ptr %l2
  store i32 %t25, ptr %l28
  store i32 18, ptr %l30
  %t28 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l28, ptr %l30)
  store i1 %t28, ptr %l32
  br label %bb14
bb14:
  %t29 = load i1, ptr %l32, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load i32, ptr %l2
  store i32 %t32, ptr %l35
  store i32 19, ptr %l37
  %t35 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l35, ptr %l37)
  store i1 %t35, ptr %l39
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i1, ptr %l39, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t39 = load i1, ptr %l34, !tbaa !21
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t40 = load i32, ptr %l2
  store i32 %t40, ptr %l42
  store i32 22, ptr %l44
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l42, ptr %l44)
  store i1 %t43, ptr %l46
  br label %bb21
bb20:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t44 = load i1, ptr %l46, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t47 = load i1, ptr %l41, !tbaa !21
  br i1 %t47, label %bb23, label %bb24
bb23:
  %t48 = load i32, ptr %l2
  store i32 %t48, ptr %l49
  store i32 23, ptr %l51
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l49, ptr %l51)
  store i1 %t51, ptr %l53
  br label %bb25
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb26
bb25:
  %t52 = load i1, ptr %l53, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  %t55 = load i1, ptr %l48, !tbaa !21
  br i1 %t55, label %bb27, label %bb28
bb27:
  %t56 = load i32, ptr %l2
  store i32 %t56, ptr %l56
  store i32 24, ptr %l58
  %t59 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l56, ptr %l58)
  store i1 %t59, ptr %l60
  br label %bb29
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb30
bb29:
  %t60 = load i1, ptr %l60, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l55, !tbaa !21
  br label %bb30
bb30:
  %t63 = load i1, ptr %l55, !tbaa !21
  br i1 %t63, label %bb31, label %bb32
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t65 = load i32, ptr %l2
  store i32 %t65, ptr %l63
  store i32 18, ptr %l65
  %t68 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l63, ptr %l65)
  store i1 %t68, ptr %l67
  br label %bb34
bb34:
  %t69 = load i1, ptr %l67, !tbaa !21
  br i1 %t69, label %bb35, label %bb36
bb35:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t74, ptr %l71
  br label %bb37
bb36:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb38
bb37:
  %t75 = load i1, ptr %l71, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %l68, !tbaa !21
  br label %bb38
bb38:
  %t78 = load i1, ptr %l68, !tbaa !21
  br i1 %t78, label %bb39, label %bb40
bb39:
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i8 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsState(ptr %v0, ptr %t80, i32 %t81)
  store i8 %t84, ptr %l76
  br label %bb42
bb42:
  %t85 = load i8, ptr %l76, !tbaa !22
  store i8 %t85, ptr %l3, !tbaa !22
  %t86 = load i8, ptr %l3, !tbaa !22
  %t88 = icmp ne i8 %t86, 0
  br i1 %t88, label %bb43, label %bb44
bb43:
  %t90 = load i8, ptr %l3, !tbaa !22
  %t92 = icmp eq i8 %t90, 3
  store i1 %t92, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %t94, i32 %t95, i8 1)
  br label %bb46
bb46:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/types:Table", ptr %t98, i32 0, i32 31
  %t101 = load i1, ptr %t100, !tbaa !21
  store i1 %t101, ptr %l4, !tbaa !21
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/types:Table", ptr %t103, i32 0, i32 31
  store i1 false, ptr %t105, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  %t106 = load i32, ptr %l2
  %t108 = trunc i64 18 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb71
bb49:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l88, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l1, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l91
  br label %bb50
bb50:
  %t117 = load ptr, ptr %l88, !tbaa !29
  %t118 = load i32, ptr %l91, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t117, i32 %t118)
  store i32 %t119, ptr %l92
  br label %bb51
bb51:
  %t120 = load i32, ptr %l92
  store i32 %t120, ptr %l6
  %t121 = load i32, ptr %l6
  %t123 = trunc i64 0 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l95, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l98
  br label %bb55
bb55:
  %t132 = load ptr, ptr %l95, !tbaa !29
  %t133 = load i32, ptr %l98, !tbaa !23
  %t134 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t132, i32 %t133, i1 false)
  store i1 %t134, ptr %l99
  br label %bb56
bb56:
  %t135 = load i1, ptr %l99, !tbaa !21
  store i1 %t135, ptr %l5, !tbaa !21
  br label %bb70
bb57:
  %t136 = load i32, ptr %l6
  %t138 = trunc i64 1 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l102, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l105
  br label %bb61
bb61:
  %t147 = load ptr, ptr %l102, !tbaa !29
  %t148 = load i32, ptr %l105, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t147, i32 %t148, i1 true)
  store i1 %t149, ptr %l106
  br label %bb62
bb62:
  %t150 = load i1, ptr %l106, !tbaa !21
  store i1 %t150, ptr %l5, !tbaa !21
  br label %bb70
bb63:
  %t151 = load i32, ptr %l6
  %t153 = trunc i64 4 to i32
  %t154 = icmp eq i32 %t151, %t153
  br i1 %t154, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l109, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l1, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l112
  br label %bb67
bb67:
  %t162 = load ptr, ptr %l109, !tbaa !29
  %t163 = load i32, ptr %l112, !tbaa !23
  %t164 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t162, i32 %t163)
  store i1 %t164, ptr %l113
  br label %bb68
bb68:
  %t165 = load i1, ptr %l113, !tbaa !21
  store i1 %t165, ptr %l5, !tbaa !21
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %bb92
bb71:
  %t166 = load i32, ptr %l2
  %t168 = trunc i64 19 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb77
bb74:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l116, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l1, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l119
  br label %bb75
bb75:
  %t177 = load ptr, ptr %l116, !tbaa !29
  %t178 = load i32, ptr %l119, !tbaa !23
  %t179 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t177, i32 %t178)
  store i1 %t179, ptr %l120
  br label %bb76
bb76:
  %t180 = load i1, ptr %l120, !tbaa !21
  store i1 %t180, ptr %l5, !tbaa !21
  br label %bb92
bb77:
  %t181 = load i32, ptr %l2
  %t183 = trunc i64 22 to i32
  %t184 = icmp eq i32 %t181, %t183
  br i1 %t184, label %bb78, label %bb79
bb78:
  br label %bb82
bb79:
  %t186 = load i32, ptr %l2
  %t188 = trunc i64 23 to i32
  %t189 = icmp eq i32 %t186, %t188
  br i1 %t189, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l125, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l128
  br label %bb83
bb83:
  %t197 = load ptr, ptr %l125, !tbaa !29
  %t198 = load i32, ptr %l128, !tbaa !23
  %t199 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t197, i32 %t198, i1 false)
  store i1 %t199, ptr %l129
  br label %bb84
bb84:
  %t200 = load i1, ptr %l129, !tbaa !21
  store i1 %t200, ptr %l5, !tbaa !21
  br label %bb92
bb85:
  %t201 = load i32, ptr %l2
  %t203 = trunc i64 24 to i32
  %t204 = icmp eq i32 %t201, %t203
  br i1 %t204, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l132, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l1, !tbaa !23
  %t211 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t207, i32 %t208)
  store i32 %t211, ptr %l135
  br label %bb89
bb89:
  %t212 = load ptr, ptr %l132, !tbaa !29
  %t213 = load i32, ptr %l135, !tbaa !23
  %t214 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t212, i32 %t213, i1 true)
  store i1 %t214, ptr %l136
  br label %bb90
bb90:
  %t215 = load i1, ptr %l136, !tbaa !21
  store i1 %t215, ptr %l5, !tbaa !21
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l137, !tbaa !29
  %t217 = load i32, ptr %l1, !tbaa !23
  store i32 %t217, ptr %l138, !tbaa !23
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/types:Table", ptr %t218, i32 0, i32 31
  %t221 = load i1, ptr %t220, !tbaa !21
  br i1 %t221, label %bb93, label %bb94
bb93:
  store i8 0, ptr %l141, !tbaa !22
  br label %bb98
bb94:
  %t223 = load i1, ptr %l5, !tbaa !21
  br i1 %t223, label %bb95, label %bb96
bb95:
  store i8 3, ptr %l143, !tbaa !22
  br label %bb97
bb96:
  store i8 2, ptr %l143, !tbaa !22
  br label %bb97
bb97:
  %t225 = load i8, ptr %l143, !tbaa !22
  store i8 %t225, ptr %l141, !tbaa !22
  br label %bb98
bb98:
  %t226 = load ptr, ptr %l137, !tbaa !29
  %t227 = load i32, ptr %l138, !tbaa !23
  %t228 = load i8, ptr %l141, !tbaa !22
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %t226, i32 %t227, i8 %t228)
  br label %bb99
bb99:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l144, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/types:Table", ptr %t230, i32 0, i32 31
  %t233 = load i1, ptr %t232, !tbaa !21
  br i1 %t233, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb102
bb101:
  %t235 = load i1, ptr %l4, !tbaa !21
  store i1 %t235, ptr %l147, !tbaa !21
  br label %bb102
bb102:
  %t237 = load i1, ptr %l147, !tbaa !21
  %t238 = load ptr, ptr %l144, !tbaa !29
  %t239 = getelementptr %"compiler/types:Table", ptr %t238, i32 0, i32 31
  store i1 %t237, ptr %t239, !tbaa !21
  %t240 = load i1, ptr %l5, !tbaa !21
  store i1 %t240, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 11
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 14
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 3
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 10
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 3
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 14
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store i32 20, ptr %l6
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l4, ptr %l6)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 7
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 10
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 5
  %t6 = sext i32 %a1 to i64
  %t9 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store { i64, ptr } %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 0
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 18
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l24 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l63 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/types:Table", ptr %t8, i32 0, i32 6
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  %t15 = extractvalue { i32, i32 } %t14, 1
  %t16 = extractvalue { i32, i32 } %t14, 0
  store i32 %t16, ptr %l19
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18
ok.18:
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t19 = load i32, ptr %l18, !tbaa !23
  store i32 %t19, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i32 -1, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t20 = load i32, ptr %l14, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  %t21 = load i32, ptr %l2, !tbaa !23
  %t23 = icmp sge i32 %t21, 0
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load i32, ptr %l2, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp sle i64 %t33, 2305843009213693951
  br i1 %t34, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb13:
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = mul i64 %t36, 4
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb15:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb20
bb17:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l36, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb19
bb19:
  %t72 = load i64, ptr %l36, !tbaa !24
  store i64 %t72, ptr %l33, !tbaa !24
  br label %bb20
bb20:
  %t73 = load i64, ptr %l33, !tbaa !24
  store i64 %t73, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t94, ptr %l56, !tbaa !27
  %t95 = load i64, ptr %l9, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t103 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i32, ptr %t104, i64 %t93
  store i32 %t100, ptr %t105, !tbaa !33
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb21
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/types:Table", ptr %t110, i32 0, i32 5
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_H503e6d35c0db63145eb2ca8ce5f41f51(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l63
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  %t116 = trunc i64 %t115 to i32
  store i32 %t116, ptr %l2, !tbaa !23
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/types:Table", ptr %t119, i32 0, i32 5
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v0, ptr %v0, ptr %t121, { i64, ptr } %t122)
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/types:Table", ptr %t125, i32 0, i32 6
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v0, ptr %t127, { i64, ptr } %t128, i32 %t129)
  br label %bb29
bb29:
  %t133 = load i32, ptr %l2, !tbaa !23
  store i32 %t133, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = insertvalue [1 x i32] undef, i32 %a1, 0
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call ptr @__olang_scope_alloc(ptr %t6, i64 4)
  store [1 x i32] %t4, ptr %t7
  %t8 = insertvalue { i64, ptr } undef, i64 1, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = mul i64 %t11, 4
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } %t16)
  store i32 %t19, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l7, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/types:Table", ptr %t5, i32 0, i32 24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store { i64, ptr } %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr @.d18 })
  store i1 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l14
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/types:Table", ptr %t25, i32 0, i32 24
  store ptr %t27, ptr %l16, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l20
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t41 = load ptr, ptr %l16, !tbaa !29
  %t42 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v0, ptr %t41, i64 %t42, { i64, ptr } %t40)
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/types:Table", ptr %t44, i32 0, i32 24
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t46, i64 %t47)
  store { i64, ptr } %t50, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l13 = alloca %"compiler/types:data"
  %l16 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t10 = sext i32 %a1 to i64
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t17 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 18, i64 %t10, i64 %t13, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t17, ptr %l13
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l16
  br label %bb3
bb3:
  %t23 = load i32, ptr %l16, !tbaa !23
  %t24 = add i32 %t23, 1
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load %"compiler/types:data", ptr %l13
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t25, %"compiler/types:data" %t26, i32 %t24)
  store i32 %t28, ptr %l18
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l18, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca %"compiler/types:data"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store i32 21, ptr %l6
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l4, ptr %l6)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t10, i32 %t11)
  store %"compiler/types:data" %t14, ptr %l12
  br label %bb5
bb4:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb6
bb5:
  %t15 = getelementptr %"compiler/types:data", ptr %l12, i32 0, i32 5
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t18 = load i64, ptr %l9, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca %"compiler/types:data"
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store i32 21, ptr %l6
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l4, ptr %l6)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/types:Table", ptr %t10, i32 0, i32 28
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t13, i32 %t14)
  store %"compiler/types:data" %t17, ptr %l14
  br label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/types:Table", ptr %t18, i32 0, i32 28
  %t22 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t20, i64 0)
  store { i64, ptr } %t22, ptr %l19
  br label %bb7
bb5:
  %t23 = getelementptr %"compiler/types:data", ptr %l14, i32 0, i32 5
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t27 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t25, i64 %t24)
  store { i64, ptr } %t27, ptr %l16
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l9, !tbaa !27
  br label %bb8
bb7:
  %t29 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  br label %bb8
bb8:
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l25 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca i64
  %l60 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldList(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i32, ptr %l14, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l17, !tbaa !24
  %t14 = load i64, ptr %l17, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  br i1 %t18, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb5:
  %t20 = load i64, ptr %l17, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t25, ptr %lp3
  %t27 = load ptr, ptr %lp3
  store { i64, ptr } %t24, ptr %t27, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/types:Table", ptr %t28, i32 0, i32 21
  %t31 = load i32, ptr %l1, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t33)
  store i64 %t36, ptr %l25
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb7:
  %t37 = load i64, ptr %l25, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t38, 0
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %lp3
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i64 0, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l2, !tbaa !24
  store i64 %t45, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb16
bb13:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = sub i64 %t57, %t58
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = add i64 %t61, %t62
  %t67 = sub i64 %t65, 1
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = sdiv i64 %t67, %t68
  store i64 %t71, ptr %l36, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb15
bb15:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t74 = load i64, ptr %l33, !tbaa !24
  store i64 %t74, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t83 = load i64, ptr %l5, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = mul i64 %t84, %t85
  %t91 = add i64 %t83, %t88
  store i64 %t91, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  store i64 %t93, ptr %l54, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/types:Table", ptr %t94, i32 0, i32 22
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t104 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t96, i64 %t101)
  store i64 %t104, ptr %l60
  br label %bb21
bb21:
  %t105 = load i64, ptr %l60, !tbaa !24
  %t106 = load ptr, ptr %lp3
  %t107 = load i64, ptr %l54, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i64, ptr %t109, i64 %t107
  store i64 %t105, ptr %t110, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t111 = load i64, ptr %l9, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l9, !tbaa !24
  br label %bb17
bb23:
  %t115 = load ptr, ptr %lp3
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamIsConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l7 = alloca %"compiler/types:decl"
  %l9 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l7, i32 0, i32 4
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %a2, ptr %l9, !tbaa !24
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = ashr i64 %t11, %t15
  %t18 = and i64 %t16, 1
  %t20 = icmp eq i64 %t18, 1
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i32
  %l63 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l15, !tbaa !24
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = icmp sle i64 %t14, 1152921504606846975
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c20)
  unreachable
bb6:
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = mul i64 %t17, 8
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c20)
  unreachable
bb8:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb13
bb10:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l27, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb12
bb12:
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l24, !tbaa !24
  br label %bb13
bb13:
  %t54 = load i64, ptr %l24, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l45, !tbaa !27
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l47, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i64, ptr %t79, i64 %t76
  %t81 = load i64, ptr %t80, !tbaa !34
  %t84 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t74
  store i64 %t81, ptr %t86, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb14
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/types:Table", ptr %t91, i32 0, i32 29
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t97 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t93, { i64, ptr } %t94)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l57
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb21, label %ok.101
ok.101:
  store i64 %t98, ptr %l56
  br label %bb20
bb20:
  %t102 = load i64, ptr %l56, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t103 = load i64, ptr %l52, !tbaa !24
  store i64 %t103, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = icmp sge i64 %t104, 0
  br i1 %t106, label %bb24, label %bb25
bb24:
  %t108 = load i64, ptr %l9, !tbaa !24
  store i64 %t108, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/types:Table", ptr %t110, i32 0, i32 28
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l63
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  store i64 %t115, ptr %l9, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/types:Table", ptr %t116, i32 0, i32 28
  %t119 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t118, { i64, ptr } %t119)
  br label %bb28
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/types:Table", ptr %t122, i32 0, i32 29
  %t125 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t126 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t124, { i64, ptr } %t125, i64 %t126)
  br label %bb29
bb29:
  %t130 = load i64, ptr %l9, !tbaa !24
  store i64 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l28 = alloca i32
  %l30 = alloca i32
  %l32 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 %t26
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l24
  br label %bb8
bb8:
  %t38 = load i1, ptr %l24, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 109)
  br label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l28
  br label %bb12
bb11:
  br label %bb19
bb12:
  store i32 21, ptr %l30
  %t47 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l28, ptr %l30)
  store i1 %t47, ptr %l32
  br label %bb13
bb13:
  %t48 = load i1, ptr %l32, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 115)
  br label %bb16
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 118)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb4
bb21:
  %t56 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t56, ptr %l38
  br label %bb22
bb22:
  %t57 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t57, ptr %l39, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l40, !tbaa !24
  %t60 = load i64, ptr %l40, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l41, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l40, !tbaa !24
  %t70 = mul i64 %t69, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t71, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 23
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 25
  %t6 = sext i32 %a1 to i64
  %t9 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3, i64 %t6)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca i32
  %l40 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca i32
  %l80 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i1 true, ptr %l3, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  store i32 %t27, ptr %l7, !tbaa !23
  %t29 = load i1, ptr %l3, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l32
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i32, ptr %l7, !tbaa !23
  %t37 = load i32, ptr %l32, !tbaa !23
  %t39 = icmp eq i32 %t37, %t36
  store i1 %t39, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l29, !tbaa !21
  store i1 %t41, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb2
bb11:
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t48, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l40, !tbaa !24
  %t53 = load i64, ptr %l40, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load i64, ptr %l40, !tbaa !24
  %t57 = icmp sle i64 %t56, 2305843009213693951
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb17:
  %t59 = load i64, ptr %l40, !tbaa !24
  %t60 = mul i64 %t59, 4
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb19:
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb24
bb21:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l11, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l52, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t95 = load i64, ptr %l52, !tbaa !24
  store i64 %t95, ptr %l49, !tbaa !24
  br label %bb24
bb24:
  %t96 = load i64, ptr %l49, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  store i64 %t115, ptr %l70, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t117, ptr %l72, !tbaa !27
  %t118 = load i64, ptr %l14, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i32, ptr %t121, i64 %t118
  %t123 = load i32, ptr %t122, !tbaa !33
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t116, i32 %t123)
  store i32 %t126, ptr %l75
  br label %bb29
bb29:
  %t127 = load i32, ptr %l75, !tbaa !23
  %t128 = load i64, ptr %l70, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t128
  store i32 %t127, ptr %t131, !tbaa !33
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l13, !tbaa !24
  br label %bb25
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t136, { i64, ptr } %t137)
  store i32 %t140, ptr %l80
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l80, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l35 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l2, !tbaa !24
  store i64 15, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimNames, i64 0, i64 %t47
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !37
  %t52 = load ptr, ptr @__olang_prog_scope
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t52, ptr %v1, { i64, ptr } %t50, { i64, ptr } %a1)
  store i1 %t55, ptr %l35
  br label %bb11
bb11:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb12, label %bb13
bb12:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = trunc i64 %t57 to i32
  call void @__olang_scope_close(ptr %s2)
  store i32 %t59, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb7
bb16:
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l11 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 23, i64 %t4, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = add i32 %t13, 1
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l8
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t14)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 25
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t43, i64 %t44, i32 %t45)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l12 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load i64, ptr %l2, !tbaa !24
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 20, i64 %t4, i64 %t5, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = add i32 %t15, 1
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load %"compiler/types:data", ptr %l9
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t17, %"compiler/types:data" %t18, i32 %t16)
  store i32 %t20, ptr %l14
  br label %bb3
bb3:
  %t21 = load i32, ptr %l14, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb4
bb4:
  %t27 = load i32, ptr %l1, !tbaa !23
  %t28 = load i32, ptr %l17, !tbaa !23
  %t30 = icmp ne i32 %t28, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 25
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l27
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i32, ptr %l27, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t45, i32 %t46, i64 %t44)
  store i32 %t48, ptr %l29
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = load i32, ptr %l29, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t49, i64 %t50, i32 %t51)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t52 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l18 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l2, !tbaa !23
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l6
  br label %bb2
bb2:
  store i32 18, ptr %l8
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l6, ptr %l8)
  store i1 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l12, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l15
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb6:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t20, ptr %l16
  br label %bb7
bb7:
  store i32 4, ptr %l18
  %t23 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %l16, ptr %l18)
  store i1 %t23, ptr %l20
  br label %bb8
bb8:
  %t24 = load i1, ptr %l20, !tbaa !21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t25 = load i1, ptr %l11, !tbaa !21
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l24
  br label %bb12
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t31 = load i1, ptr %l24, !tbaa !21
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l21, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l28
  br label %bb17
bb17:
  %t40 = load i32, ptr %l28, !tbaa !23
  store i32 %t40, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb18:
  br label %bb1
bb19:
  %t41 = load i32, ptr %l2, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 26
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 1
  %t26 = load i64, ptr %t25, !tbaa !34
  %t28 = add i64 2, %t26
  %t32 = add i64 %t28, %a2
  %t34 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i64, ptr %t35, i64 %t32
  %t37 = load i64, ptr %t36, !tbaa !34
  store i64 %t37, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t39, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t41 = load i64, ptr %l14, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i1
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l64 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i32, ptr %l13, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t15 = icmp sle i64 0, 2305843009213693951
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb6:
  %t17 = mul i64 0, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l22
  br label %bb9
bb9:
  store i32 22, ptr %l24
  %t29 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l22, ptr %l24)
  store i1 %t29, ptr %l26
  br label %bb10
bb10:
  %t30 = load i1, ptr %l26, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l27, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l30
  br label %bb13
bb12:
  br label %bb31
bb13:
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = load i32, ptr %l30, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l31
  br label %bb14
bb14:
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l33, !tbaa !24
  %t44 = load i64, ptr %l33, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load i64, ptr %l33, !tbaa !24
  %t48 = icmp sle i64 %t47, 2305843009213693951
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb17:
  %t50 = load i64, ptr %l33, !tbaa !24
  %t51 = mul i64 %t50, 4
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t55, ptr %lp4
  %t57 = load ptr, ptr %lp4
  store { i64, ptr } %t54, ptr %t57, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb19:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb24
bb21:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l45, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l45, !tbaa !24
  store i64 %t88, ptr %l42, !tbaa !24
  br label %bb24
bb24:
  %t89 = load i64, ptr %l42, !tbaa !24
  store i64 %t89, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t98 = load i64, ptr %l5, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %l64, !tbaa !27
  %t110 = load i64, ptr %l10, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  %t117 = load ptr, ptr %lp4
  %t119 = getelementptr { i64, ptr }, ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t108
  store i32 %t115, ptr %t121, !tbaa !33
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb29:
  %t122 = load i64, ptr %l9, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  %t126 = load ptr, ptr %lp4
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
bb31:
  %t129 = load i32, ptr %l2, !tbaa !23
  %t131 = insertvalue [1 x i32] undef, i32 %t129, 0
  %t133 = load ptr, ptr @__olang_prog_scope
  %t134 = call ptr @__olang_scope_alloc(ptr %t133, i64 4)
  store [1 x i32] %t131, ptr %t134
  %t135 = insertvalue { i64, ptr } undef, i64 1, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t13, i32 %t14)
  store { i64, ptr } %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t19 = icmp sgt i64 %t17, 0
  store i1 %t19, ptr %l3, !tbaa !21
  %t21 = load i32, ptr %l2, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t25 = icmp ne i32 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l20
  br label %bb6
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l20, !tbaa !21
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load i1, ptr %l3, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  store { i64, ptr } { i64 3, ptr @.d24 }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr @.d25 }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l27, !tbaa !24
  %t42 = load i64, ptr %l27, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t53, ptr %l22, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
bb13:
  %t55 = load i1, ptr %l3, !tbaa !21
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l33
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t64 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb17:
  %t71 = load i32, ptr %l2, !tbaa !23
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t75 = icmp eq i32 %t71, %t72
  br i1 %t75, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 3, ptr @.d26 }, ptr %l38, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l40, !tbaa !24
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l41, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l40, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t91, ptr %l39, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l44
  br label %bb21
bb21:
  %t98 = extractvalue { i64, ptr } { i64 7, ptr @.d27 }, 1
  %t99 = extractvalue { i64, ptr } { i64 7, ptr @.d27 }, 0
  %t100 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 2, ptr @.d28 }, 1
  %t105 = extractvalue { i64, ptr } { i64 2, ptr @.d28 }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = getelementptr i8, ptr %t108, i64 %t102
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 26
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 0
  %t25 = load i64, ptr %t24, !tbaa !34
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb5
bb4:
  %t27 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t27, ptr %l13, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l13, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t6, i32 %a2)
  store i32 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i1
  %l69 = alloca { i64, ptr }
  %l72 = alloca i1
  %l82 = alloca { i64, ptr }
  %l88 = alloca i64
  %l91 = alloca i64
  %l112 = alloca i64
  %l116 = alloca i1
  %l120 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i1
  %l129 = alloca i1
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleDtor, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  %t15 = insertvalue [1 x i64] undef, i64 %t13, 0
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call ptr @__olang_scope_alloc(ptr %t17, i64 8)
  store [1 x i64] %t15, ptr %t18
  %t19 = insertvalue { i64, ptr } undef, i64 1, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr @__olang_prog_scope
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l29
  br label %bb5
bb5:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l3
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l30, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l33
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l30, !tbaa !29
  %t32 = load i32, ptr %l33, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l34
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb13
bb10:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l43, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb12
bb12:
  %t65 = load i64, ptr %l43, !tbaa !24
  store i64 %t65, ptr %l40, !tbaa !24
  br label %bb13
bb13:
  %t66 = load i64, ptr %l40, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t87 = load i64, ptr %l10, !tbaa !24
  %t91 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t85, i32 %t86, i64 %t87)
  store i64 %t91, ptr %l64
  br label %bb18
bb18:
  %t92 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t93 = load i64, ptr %l64, !tbaa !24
  %t95 = icmp eq i64 %t93, %t92
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t98, ptr %l69, !tbaa !27
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 %t99
  %t104 = load i32, ptr %t103, !tbaa !33
  %t107 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t97, i32 %t104)
  store i1 %t107, ptr %l72
  br label %bb21
bb20:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb22
bb21:
  %t108 = load i1, ptr %l72, !tbaa !21
  store i1 %t108, ptr %l67, !tbaa !21
  br label %bb22
bb22:
  %t109 = load i1, ptr %l67, !tbaa !21
  br i1 %t109, label %bb23, label %bb24
bb23:
  %t110 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t110)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t113 = load i64, ptr %l9, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l9, !tbaa !24
  br label %bb14
bb28:
  %t117 = load i64, ptr %l2, !tbaa !24
  %t118 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t121 = icmp eq i64 %t117, %t118
  store i1 %t121, ptr %l11, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l1, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t123, i32 %t124)
  store { i64, ptr } %t127, ptr %l82
  br label %bb29
bb29:
  %t128 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t128, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  store i64 %t131, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t133 = load i64, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t137 = icmp sgt i64 %t133, %t134
  br i1 %t137, label %bb30, label %bb31
bb30:
  %t139 = load i64, ptr %l15, !tbaa !24
  %t141 = icmp sgt i64 %t139, 0
  br i1 %t141, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb35
bb32:
  %t143 = load i64, ptr %l14, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  %t147 = sub i64 %t143, %t144
  %t148 = load i64, ptr %l15, !tbaa !24
  %t151 = add i64 %t147, %t148
  %t153 = sub i64 %t151, 1
  %t154 = load i64, ptr %l15, !tbaa !24
  %t157 = sdiv i64 %t153, %t154
  store i64 %t157, ptr %l91, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb34
bb34:
  %t159 = load i64, ptr %l91, !tbaa !24
  store i64 %t159, ptr %l88, !tbaa !24
  br label %bb35
bb35:
  %t160 = load i64, ptr %l88, !tbaa !24
  store i64 %t160, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t161 = load i64, ptr %l17, !tbaa !24
  %t162 = load i64, ptr %l16, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb38:
  br label %bb39
bb39:
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = load i64, ptr %l17, !tbaa !24
  %t171 = load i64, ptr %l15, !tbaa !24
  %t174 = mul i64 %t170, %t171
  %t177 = add i64 %t169, %t174
  store i64 %t177, ptr %l18, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l1, !tbaa !23
  %t181 = load i64, ptr %l18, !tbaa !24
  %t185 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t179, i32 %t180, i64 %t181)
  store i64 %t185, ptr %l112
  br label %bb40
bb40:
  %t186 = load i64, ptr %l112, !tbaa !24
  store i64 %t186, ptr %l19, !tbaa !24
  %t187 = load i64, ptr %l19, !tbaa !24
  %t188 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t191 = icmp eq i64 %t187, %t188
  br i1 %t191, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb43
bb42:
  %t193 = load i64, ptr %l19, !tbaa !24
  %t194 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t197 = icmp eq i64 %t193, %t194
  store i1 %t197, ptr %l116, !tbaa !21
  br label %bb43
bb43:
  %t199 = load i1, ptr %l116, !tbaa !21
  br i1 %t199, label %bb44, label %bb45
bb44:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i64, ptr %l18, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i32, ptr %t204, i64 %t201
  %t206 = load i32, ptr %t205, !tbaa !33
  %t209 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t200, i32 %t206)
  store i1 %t209, ptr %l124
  br label %bb46
bb45:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb51
bb46:
  %t210 = load i1, ptr %l124, !tbaa !21
  br i1 %t210, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb50
bb48:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i64, ptr %l18, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i32, ptr %t215, i64 %t212
  %t217 = load i32, ptr %t216, !tbaa !33
  %t220 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t211, i32 %t217)
  store i1 %t220, ptr %l129
  br label %bb49
bb49:
  %t221 = load i1, ptr %l129, !tbaa !21
  store i1 %t221, ptr %l125, !tbaa !21
  br label %bb50
bb50:
  %t222 = load i1, ptr %l125, !tbaa !21
  store i1 %t222, ptr %l120, !tbaa !21
  br label %bb51
bb51:
  %t223 = load i1, ptr %l120, !tbaa !21
  br i1 %t223, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb54
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  %t224 = load i64, ptr %l17, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l17, !tbaa !24
  br label %bb36
bb56:
  %t228 = load i1, ptr %l11, !tbaa !21
  br i1 %t228, label %bb57, label %bb58
bb57:
  %t230 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t230)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t234 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t234, ptr %l136
  br label %bb61
bb61:
  %t235 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t235, ptr %l137, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  store i64 %t237, ptr %l138, !tbaa !24
  %t238 = load i64, ptr %l138, !tbaa !24
  %t239 = mul i64 %t238, 8
  %t240 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t239)
  %t241 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l139, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = load i64, ptr %l138, !tbaa !24
  %t248 = mul i64 %t247, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t244, ptr %t246, i64 %t248, i1 false)
  %t249 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t249, ptr %l137, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t250 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t250, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l56 = alloca { i64, ptr }
  %l60 = alloca i1
  %l73 = alloca i64
  %l80 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l89 = alloca i64
  %l92 = alloca i64
  %l110 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l123 = alloca i64
  %l126 = alloca i64
  %l144 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l155 = alloca i32
  %l159 = alloca i32
  %l160 = alloca i32
  %l166 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  store i1 %t5, ptr %l4, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l39, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i64, ptr %t25, i64 %t22
  %t27 = load i64, ptr %t26, !tbaa !34
  store i64 %t27, ptr %l8, !tbaa !24
  %t29 = load i1, ptr %l4, !tbaa !21
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  store i1 %t35, ptr %l43, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb7
bb7:
  %t37 = load i1, ptr %l43, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb1
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l56, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t57
  %t62 = load i64, ptr %t61, !tbaa !34
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = load i1, ptr %l4, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load i64, ptr %l12, !tbaa !24
  %t67 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t70 = icmp eq i64 %t66, %t67
  store i1 %t70, ptr %l60, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l60, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t73 = load i64, ptr %l10, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l10, !tbaa !24
  br label %bb10
bb18:
  %t77 = load i1, ptr %l4, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  store i32 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = add i64 2, %t82
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = add i64 %t84, %t87
  store i64 %t90, ptr %l73, !tbaa !24
  %t91 = load i64, ptr %l73, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = icmp sle i64 %t94, 1152921504606846975
  br i1 %t95, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb24:
  %t97 = load i64, ptr %l73, !tbaa !24
  %t98 = mul i64 %t97, 8
  %t99 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l13, !tbaa !27
  %t103 = load i64, ptr %l1, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t109 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t109, ptr %l80, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i64, ptr %t113, i64 0
  store i64 %t103, ptr %t114, !tbaa !34
  %t115 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t115, ptr %l82, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i64, ptr %t119, i64 1
  store i64 %t107, ptr %t120, !tbaa !34
  store i64 0, ptr %l16, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  store i64 %t123, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t125 = load i64, ptr %l17, !tbaa !24
  %t126 = load i64, ptr %l16, !tbaa !24
  %t129 = icmp sgt i64 %t125, %t126
  br i1 %t129, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb26:
  %t131 = load i64, ptr %l18, !tbaa !24
  %t133 = icmp sgt i64 %t131, 0
  br i1 %t133, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb31
bb28:
  %t135 = load i64, ptr %l17, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = sub i64 %t135, %t136
  %t140 = load i64, ptr %l18, !tbaa !24
  %t143 = add i64 %t139, %t140
  %t145 = sub i64 %t143, 1
  %t146 = load i64, ptr %l18, !tbaa !24
  %t149 = sdiv i64 %t145, %t146
  store i64 %t149, ptr %l92, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb30
bb30:
  %t151 = load i64, ptr %l92, !tbaa !24
  store i64 %t151, ptr %l89, !tbaa !24
  br label %bb31
bb31:
  %t152 = load i64, ptr %l89, !tbaa !24
  store i64 %t152, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t153 = load i64, ptr %l20, !tbaa !24
  %t154 = load i64, ptr %l19, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t161 = load i64, ptr %l16, !tbaa !24
  %t162 = load i64, ptr %l20, !tbaa !24
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = mul i64 %t162, %t163
  %t169 = add i64 %t161, %t166
  store i64 %t169, ptr %l21, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t171, ptr %l110, !tbaa !27
  %t172 = load i64, ptr %l21, !tbaa !24
  %t174 = add i64 2, %t172
  %t175 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t175, ptr %l113, !tbaa !27
  %t176 = load i64, ptr %l21, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i64, ptr %t179, i64 %t176
  %t181 = load i64, ptr %t180, !tbaa !34
  %t184 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t174
  store i64 %t181, ptr %t186, !tbaa !34
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  %t187 = load i64, ptr %l20, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l20, !tbaa !24
  br label %bb32
bb37:
  store i64 0, ptr %l22, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  store i64 %t193, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t195 = load i64, ptr %l23, !tbaa !24
  %t196 = load i64, ptr %l22, !tbaa !24
  %t199 = icmp sgt i64 %t195, %t196
  br i1 %t199, label %bb38, label %bb39
bb38:
  %t201 = load i64, ptr %l24, !tbaa !24
  %t203 = icmp sgt i64 %t201, 0
  br i1 %t203, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb43
bb40:
  %t205 = load i64, ptr %l23, !tbaa !24
  %t206 = load i64, ptr %l22, !tbaa !24
  %t209 = sub i64 %t205, %t206
  %t210 = load i64, ptr %l24, !tbaa !24
  %t213 = add i64 %t209, %t210
  %t215 = sub i64 %t213, 1
  %t216 = load i64, ptr %l24, !tbaa !24
  %t219 = sdiv i64 %t215, %t216
  store i64 %t219, ptr %l126, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb42
bb42:
  %t221 = load i64, ptr %l126, !tbaa !24
  store i64 %t221, ptr %l123, !tbaa !24
  br label %bb43
bb43:
  %t222 = load i64, ptr %l123, !tbaa !24
  store i64 %t222, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s12
  %t223 = load i64, ptr %l26, !tbaa !24
  %t224 = load i64, ptr %l25, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t231 = load i64, ptr %l22, !tbaa !24
  %t232 = load i64, ptr %l26, !tbaa !24
  %t233 = load i64, ptr %l24, !tbaa !24
  %t236 = mul i64 %t232, %t233
  %t239 = add i64 %t231, %t236
  store i64 %t239, ptr %l27, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t241, ptr %l144, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t246 = add i64 2, %t244
  %t247 = load i64, ptr %l27, !tbaa !24
  %t250 = add i64 %t246, %t247
  %t251 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t251, ptr %l150, !tbaa !27
  %t252 = load i64, ptr %l27, !tbaa !24
  %t254 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr i64, ptr %t255, i64 %t252
  %t257 = load i64, ptr %t256, !tbaa !34
  %t260 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr i64, ptr %t261, i64 %t250
  store i64 %t257, ptr %t262, !tbaa !34
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb48:
  %t263 = load i64, ptr %l26, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l26, !tbaa !24
  br label %bb44
bb49:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/types:Table", ptr %t267, i32 0, i32 27
  %t270 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t273 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v0, ptr %t269, { i64, ptr } %t270)
  %t274 = extractvalue { i32, i32 } %t273, 1
  %t275 = extractvalue { i32, i32 } %t273, 0
  store i32 %t275, ptr %l160
  %t276 = icmp ne i32 %t275, 0
  br i1 %t276, label %bb51, label %ok.277
ok.277:
  store i32 %t274, ptr %l159
  br label %bb50
bb50:
  %t278 = load i32, ptr %l159, !tbaa !23
  store i32 %t278, ptr %l155, !tbaa !23
  br label %bb53
bb51:
  br label %bb52
bb52:
  store i32 -1, ptr %l155, !tbaa !23
  br label %bb53
bb53:
  %t279 = load i32, ptr %l155, !tbaa !23
  store i32 %t279, ptr %l28, !tbaa !23
  %t280 = load i32, ptr %l28, !tbaa !23
  %t282 = icmp sge i32 %t280, 0
  br i1 %t282, label %bb54, label %bb55
bb54:
  %t284 = load i32, ptr %l28, !tbaa !23
  store i32 %t284, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/types:Table", ptr %t286, i32 0, i32 26
  %t290 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l166
  br label %bb57
bb57:
  %t291 = load i64, ptr %l166, !tbaa !24
  %t292 = trunc i64 %t291 to i32
  store i32 %t292, ptr %l28, !tbaa !23
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/types:Table", ptr %t295, i32 0, i32 26
  %t298 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t297, { i64, ptr } %t298)
  br label %bb58
bb58:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/types:Table", ptr %t301, i32 0, i32 27
  %t304 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t305 = load i32, ptr %l28, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v0, ptr %t303, { i64, ptr } %t304, i32 %t305)
  br label %bb59
bb59:
  %t309 = load i32, ptr %l28, !tbaa !23
  store i32 %t309, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i1
  %l36 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca i1
  %l47 = alloca i32
  %l52 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca i1
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l133 = alloca i64
  %l136 = alloca i64
  %l161 = alloca i64
  %l165 = alloca i64
  %l169 = alloca i1
  %l173 = alloca i1
  %l177 = alloca i1
  %l181 = alloca i1
  %l192 = alloca i1
  %l200 = alloca ptr
  %l203 = alloca i32
  %l206 = alloca i32
  %l207 = alloca i1
  %l210 = alloca ptr
  %l213 = alloca i32
  %l216 = alloca i32
  %l217 = alloca i1
  %l220 = alloca ptr
  %l223 = alloca i32
  %l224 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l228 = alloca i32
  %l229 = alloca { i64, ptr }
  %l235 = alloca i64
  %l238 = alloca i64
  %l260 = alloca i1
  %l262 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l268 = alloca i1
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb6
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l36
  br label %bb3
bb3:
  store ptr %l36, ptr %l37, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l40
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l37, !tbaa !29
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t17, ptr %l40)
  store i1 %t19, ptr %l42
  br label %bb5
bb5:
  %t20 = load i1, ptr %l42, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l33, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l33, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l47
  br label %bb10
bb10:
  %t30 = load i32, ptr %l47
  store i32 %t30, ptr %l3
  %t31 = load i32, ptr %l3
  %t33 = trunc i64 21 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb85
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t36, i32 %t37)
  store i64 %t40, ptr %l52
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l55
  br label %bb15
bb15:
  %t46 = load i64, ptr %l52, !tbaa !24
  %t47 = load i64, ptr %l55, !tbaa !24
  %t48 = icmp ne i64 %t46, %t47
  br i1 %t48, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l58, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l61
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l58, !tbaa !29
  %t58 = load i32, ptr %l61, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t57, i32 %t58)
  store { i64, ptr } %t59, ptr %l62
  br label %bb20
bb20:
  %t60 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l63, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l66
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l63, !tbaa !29
  %t68 = load i32, ptr %l66, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t69, ptr %l67
  br label %bb22
bb22:
  %t70 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t70, ptr %l5, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t79 = icmp ne i64 %t73, %t76
  br i1 %t79, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb31
bb28:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l82, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb30
bb30:
  %t112 = load i64, ptr %l82, !tbaa !24
  store i64 %t112, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t113 = load i64, ptr %l79, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb34:
  br label %bb35
bb35:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t134 = load i64, ptr %l11, !tbaa !24
  %t138 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t132, i32 %t133, i64 %t134)
  store i64 %t138, ptr %l103
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l2, !tbaa !23
  %t141 = load i64, ptr %l11, !tbaa !24
  %t145 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t139, i32 %t140, i64 %t141)
  store i64 %t145, ptr %l107
  br label %bb37
bb37:
  %t146 = load i64, ptr %l103, !tbaa !24
  %t147 = load i64, ptr %l107, !tbaa !24
  %t148 = icmp ne i64 %t146, %t147
  br i1 %t148, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb41
bb39:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t151, ptr %l111, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i32, ptr %t155, i64 %t152
  %t157 = load i32, ptr %t156, !tbaa !33
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t158, ptr %l114, !tbaa !27
  %t159 = load i64, ptr %l11, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t150, i32 %t157, i32 %t164)
  store i1 %t168, ptr %l117
  br label %bb40
bb40:
  %t169 = load i1, ptr %l117, !tbaa !21
  %t170 = xor i1 %t169, true
  store i1 %t170, ptr %l109, !tbaa !21
  br label %bb41
bb41:
  %t172 = load i1, ptr %l109, !tbaa !21
  br i1 %t172, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb45:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb32
bb46:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l1, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t178, i32 %t179)
  store { i64, ptr } %t182, ptr %l124
  br label %bb47
bb47:
  %t183 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t183, ptr %l12, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t184, i32 %t185)
  store { i64, ptr } %t188, ptr %l127
  br label %bb48
bb48:
  %t189 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t189, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l15, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb49, label %bb50
bb49:
  %t200 = load i64, ptr %l16, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb54
bb51:
  %t204 = load i64, ptr %l15, !tbaa !24
  %t205 = load i64, ptr %l14, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l16, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l16, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l136, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb53
bb53:
  %t220 = load i64, ptr %l136, !tbaa !24
  store i64 %t220, ptr %l133, !tbaa !24
  br label %bb54
bb54:
  %t221 = load i64, ptr %l133, !tbaa !24
  store i64 %t221, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load i64, ptr %l17, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb57:
  br label %bb58
bb58:
  %t230 = load i64, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l18, !tbaa !24
  %t232 = load i64, ptr %l16, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  store i64 %t238, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l19, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t246 = icmp sge i64 %t240, %t243
  br i1 %t246, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb60:
  br label %bb61
bb61:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  %t250 = load i64, ptr %l19, !tbaa !24
  %t254 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t248, i32 %t249, i64 %t250)
  store i64 %t254, ptr %l161
  br label %bb62
bb62:
  %t255 = load i64, ptr %l161, !tbaa !24
  store i64 %t255, ptr %l20, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i32, ptr %l2, !tbaa !23
  %t258 = load i64, ptr %l19, !tbaa !24
  %t262 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t256, i32 %t257, i64 %t258)
  store i64 %t262, ptr %l165
  br label %bb63
bb63:
  %t263 = load i64, ptr %l165, !tbaa !24
  store i64 %t263, ptr %l21, !tbaa !24
  %t264 = load i64, ptr %l20, !tbaa !24
  %t265 = load i64, ptr %l21, !tbaa !24
  %t268 = icmp ne i64 %t264, %t265
  br i1 %t268, label %bb64, label %bb65
bb64:
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t274 = icmp eq i64 %t270, %t271
  br i1 %t274, label %bb66, label %bb67
bb65:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb75
bb66:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb68
bb67:
  %t276 = load i64, ptr %l20, !tbaa !24
  %t277 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t280 = icmp eq i64 %t276, %t277
  store i1 %t280, ptr %l173, !tbaa !21
  br label %bb68
bb68:
  %t282 = load i1, ptr %l173, !tbaa !21
  br i1 %t282, label %bb69, label %bb70
bb69:
  %t283 = load i64, ptr %l21, !tbaa !24
  %t284 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t287 = icmp eq i64 %t283, %t284
  br i1 %t287, label %bb71, label %bb72
bb70:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb74
bb71:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb73
bb72:
  %t289 = load i64, ptr %l21, !tbaa !24
  %t290 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t293 = icmp eq i64 %t289, %t290
  store i1 %t293, ptr %l181, !tbaa !21
  br label %bb73
bb73:
  %t295 = load i1, ptr %l181, !tbaa !21
  store i1 %t295, ptr %l177, !tbaa !21
  br label %bb74
bb74:
  %t296 = load i1, ptr %l177, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l169, !tbaa !21
  br label %bb75
bb75:
  %t299 = load i1, ptr %l169, !tbaa !21
  br i1 %t299, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i64, ptr %l19, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i32, ptr %t305, i64 %t302
  %t307 = load i32, ptr %t306, !tbaa !33
  %t308 = load i64, ptr %l19, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i32, ptr %t311, i64 %t308
  %t313 = load i32, ptr %t312, !tbaa !33
  %t317 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t301, i32 %t307, i32 %t313)
  store i1 %t317, ptr %l192
  br label %bb79
bb79:
  %t318 = load i1, ptr %l192, !tbaa !21
  %t319 = xor i1 %t318, true
  br i1 %t319, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb83
bb83:
  %t322 = load i64, ptr %l18, !tbaa !24
  %t324 = add i64 %t322, 1
  store i64 %t324, ptr %l18, !tbaa !24
  br label %bb55
bb84:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb85:
  %t327 = load i32, ptr %l3
  %t329 = trunc i64 19 to i32
  %t330 = icmp eq i32 %t327, %t329
  br i1 %t330, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l200, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l1, !tbaa !23
  %t337 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t337, ptr %l203
  br label %bb89
bb89:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l2, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t338, i32 %t339)
  store i32 %t342, ptr %l206
  br label %bb90
bb90:
  %t343 = load ptr, ptr %l200, !tbaa !29
  %t344 = load i32, ptr %l203, !tbaa !23
  %t345 = load i32, ptr %l206, !tbaa !23
  %t346 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t343, i32 %t344, i32 %t345)
  store i1 %t346, ptr %l207
  br label %bb91
bb91:
  %t347 = load i1, ptr %l207, !tbaa !21
  store i1 %t347, ptr %rv
  br label %ret
bb92:
  %t348 = load i32, ptr %l3
  %t350 = trunc i64 20 to i32
  %t351 = icmp eq i32 %t348, %t350
  br i1 %t351, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l210, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l1, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l213
  br label %bb96
bb96:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l2, !tbaa !23
  %t363 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t359, i32 %t360)
  store i32 %t363, ptr %l216
  br label %bb97
bb97:
  %t364 = load ptr, ptr %l210, !tbaa !29
  %t365 = load i32, ptr %l213, !tbaa !23
  %t366 = load i32, ptr %l216, !tbaa !23
  %t367 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t364, i32 %t365, i32 %t366)
  store i1 %t367, ptr %l217
  br label %bb98
bb98:
  %t368 = load i1, ptr %l217, !tbaa !21
  store i1 %t368, ptr %rv
  br label %ret
bb99:
  %t369 = load i32, ptr %l3
  %t371 = trunc i64 22 to i32
  %t372 = icmp eq i32 %t369, %t371
  br i1 %t372, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb126
bb102:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l220, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i32, ptr %l1, !tbaa !23
  %t379 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t375, i32 %t376)
  store i32 %t379, ptr %l223
  br label %bb103
bb103:
  %t380 = load ptr, ptr %l220, !tbaa !29
  %t381 = load i32, ptr %l223, !tbaa !23
  %t382 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t380, i32 %t381)
  store { i64, ptr } %t382, ptr %l224
  br label %bb104
bb104:
  %t383 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t383, ptr %l22, !tbaa !27
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l225, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i32, ptr %l2, !tbaa !23
  %t389 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t389, ptr %l228
  br label %bb105
bb105:
  %t390 = load ptr, ptr %l225, !tbaa !29
  %t391 = load i32, ptr %l228, !tbaa !23
  %t392 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t390, i32 %t391)
  store { i64, ptr } %t392, ptr %l229
  br label %bb106
bb106:
  %t393 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t393, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t394 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t394, 0
  store i64 %t396, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t398 = load i64, ptr %l25, !tbaa !24
  %t399 = load i64, ptr %l24, !tbaa !24
  %t402 = icmp sgt i64 %t398, %t399
  br i1 %t402, label %bb107, label %bb108
bb107:
  %t404 = load i64, ptr %l26, !tbaa !24
  %t406 = icmp sgt i64 %t404, 0
  br i1 %t406, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb112
bb109:
  %t408 = load i64, ptr %l25, !tbaa !24
  %t409 = load i64, ptr %l24, !tbaa !24
  %t412 = sub i64 %t408, %t409
  %t413 = load i64, ptr %l26, !tbaa !24
  %t416 = add i64 %t412, %t413
  %t418 = sub i64 %t416, 1
  %t419 = load i64, ptr %l26, !tbaa !24
  %t422 = sdiv i64 %t418, %t419
  store i64 %t422, ptr %l238, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb111
bb111:
  %t424 = load i64, ptr %l238, !tbaa !24
  store i64 %t424, ptr %l235, !tbaa !24
  br label %bb112
bb112:
  %t425 = load i64, ptr %l235, !tbaa !24
  store i64 %t425, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s19
  %t426 = load i64, ptr %l28, !tbaa !24
  %t427 = load i64, ptr %l27, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s19)
  br label %bb125
bb115:
  br label %bb116
bb116:
  %t434 = load i64, ptr %l24, !tbaa !24
  %t435 = load i64, ptr %l28, !tbaa !24
  %t436 = load i64, ptr %l26, !tbaa !24
  %t439 = mul i64 %t435, %t436
  %t442 = add i64 %t434, %t439
  store i64 %t442, ptr %l29, !tbaa !24
  %t444 = load i64, ptr %l29, !tbaa !24
  %t445 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t450 = icmp slt i64 %t444, %t447
  br i1 %t450, label %bb117, label %bb118
bb117:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t453, ptr %l262, !tbaa !27
  %t454 = load i64, ptr %l29, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i32, ptr %t457, i64 %t454
  %t459 = load i32, ptr %t458, !tbaa !33
  %t460 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t460, ptr %l265, !tbaa !27
  %t461 = load i64, ptr %l29, !tbaa !24
  %t463 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr i32, ptr %t464, i64 %t461
  %t466 = load i32, ptr %t465, !tbaa !33
  %t470 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t452, i32 %t459, i32 %t466)
  store i1 %t470, ptr %l268
  br label %bb119
bb118:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb120
bb119:
  %t471 = load i1, ptr %l268, !tbaa !21
  %t472 = xor i1 %t471, true
  store i1 %t472, ptr %l260, !tbaa !21
  br label %bb120
bb120:
  %t474 = load i1, ptr %l260, !tbaa !21
  br i1 %t474, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s19)
  store i1 false, ptr %rv
  br label %ret
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s19)
  br label %bb124
bb124:
  %t476 = load i64, ptr %l28, !tbaa !24
  %t478 = add i64 %t476, 1
  store i64 %t478, ptr %l28, !tbaa !24
  br label %bb113
bb125:
  store i1 true, ptr %rv
  br label %ret
bb126:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 4
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = trunc i64 %t7 to i32
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEmptyBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l3, !tbaa !29
  store i32 %a1, ptr %l4, !tbaa !23
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t7 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t5, i1 false, i1 true)
  store %"compiler/types:body" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = load %"compiler/types:body", ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t8, i32 %t9, %"compiler/types:body" %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEnumBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb5:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l24, !tbaa !24
  store i64 %t46, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l21, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l44, !tbaa !27
  %t69 = load i64, ptr %l10, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t69
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t67
  store i32 %t74, ptr %t79, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb11
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/types:Table", ptr %t84, i32 0, i32 17
  %t87 = load i32, ptr %l1, !tbaa !23
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v0, ptr %t86, i32 %t87, { i64, ptr } %t88)
  br label %bb17
bb17:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/types:Table", ptr %t92, i32 0, i32 16
  store ptr %t94, ptr %l54, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  store i32 %t95, ptr %l55, !tbaa !23
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t100 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 %a3, i32 %t97, i1 false, i1 true)
  store %"compiler/types:body" %t100, ptr %l58
  br label %bb18
bb18:
  %t101 = load ptr, ptr %l54, !tbaa !29
  %t102 = load i32, ptr %l55, !tbaa !23
  %t103 = load %"compiler/types:body", ptr %l58
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t101, i32 %t102, %"compiler/types:body" %t103)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 18
  %t6 = sext i32 %a1 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6, i64 %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetOverBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i32
  %l7 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l4, !tbaa !29
  store i32 %a1, ptr %l5, !tbaa !23
  %t7 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %a2, i1 false, i1 true)
  store %"compiler/types:body" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = load %"compiler/types:body", ptr %l7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t8, i32 %t9, %"compiler/types:body" %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l5 = alloca ptr
  %l6 = alloca i32
  %l10 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l5, !tbaa !29
  store i32 %a1, ptr %l6, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 %a2, i32 0, i32 %t6, i1 %a3, i1 true)
  store %"compiler/types:body" %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = load %"compiler/types:body", ptr %l10
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t12, i32 %t13, %"compiler/types:body" %t14)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t9, i64 %t10)
  store i32 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i32, ptr %l7, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 7
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 26
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t24 = add i64 2, %a2
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i64, ptr %t27, i64 %t24
  %t29 = load i64, ptr %t28, !tbaa !34
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  %t31 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t33 = load i64, ptr %l14, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 19
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l5, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 3, ptr @.d31 }, ptr %l9, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l11, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l13, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l16
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l13, !tbaa !29
  %t38 = load i32, ptr %l16, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l17
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l11 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 22, i64 %t4, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = add i32 %t13, 1
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l8
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t14)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 25
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t43, i64 %t44, i32 %t45)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i32
  %l42 = alloca i64
  %l43 = alloca i32
  %l44 = alloca i32
  %l46 = alloca i32
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i32
  %l61 = alloca i32
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i32
  %l70 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  store i32 %t7, ptr %l6
  store i32 21, ptr %l8
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l6, ptr %l8)
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l12, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l15
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t19 = load ptr, ptr %l12, !tbaa !29
  %t20 = load i32, ptr %l15, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t21, ptr %l16
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l20
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i32, ptr %l20, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l21
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l24
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l11, !tbaa !29
  %t42 = load i32, ptr %l16, !tbaa !23
  %t43 = load i32, ptr %l21, !tbaa !23
  %t44 = load i32, ptr %l24, !tbaa !23
  %t45 = load i32, ptr %l27, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t41, i32 %t42, i32 %t43, i32 %t44, i32 %t45, i64 0)
  store i32 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load i32, ptr %l28, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb12:
  %t48 = load i32, ptr %l2
  store i32 %t48, ptr %l29
  store i32 20, ptr %l31
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l29, ptr %l31)
  store i1 %t51, ptr %l33
  br label %bb13
bb13:
  %t52 = load i1, ptr %l33, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l35, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l38
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t62, ptr %l39
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t63, i32 %t64)
  store i64 %t67, ptr %l42
  br label %bb18
bb18:
  %t68 = load ptr, ptr %l34, !tbaa !29
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t68, i32 %t69, i64 %t70)
  store i32 %t71, ptr %l43
  br label %bb19
bb19:
  %t72 = load i32, ptr %l43, !tbaa !23
  store i32 %t72, ptr %rv
  br label %ret
bb20:
  %t73 = load i32, ptr %l2
  store i32 %t73, ptr %l44
  store i32 19, ptr %l46
  %t76 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l44, ptr %l46)
  store i1 %t76, ptr %l48
  br label %bb21
bb21:
  %t77 = load i1, ptr %l48, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l49, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l50, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l53
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t85 = load ptr, ptr %l50, !tbaa !29
  %t86 = load i32, ptr %l53, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t87, ptr %l54
  br label %bb25
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l1, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l57
  br label %bb26
bb26:
  %t93 = load ptr, ptr %l49, !tbaa !29
  %t94 = load i32, ptr %l54, !tbaa !23
  %t95 = load i32, ptr %l57, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t93, i32 %t94, i32 %t95)
  store i32 %t96, ptr %l58
  br label %bb27
bb27:
  %t97 = load i32, ptr %l58, !tbaa !23
  store i32 %t97, ptr %rv
  br label %ret
bb28:
  %t98 = load i32, ptr %l2
  store i32 %t98, ptr %l59
  store i32 22, ptr %l61
  %t101 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l59, ptr %l61)
  store i1 %t101, ptr %l63
  br label %bb29
bb29:
  %t102 = load i1, ptr %l63, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l64, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l65, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l1, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l68
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t110 = load ptr, ptr %l65, !tbaa !29
  %t111 = load i32, ptr %l68, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t112, ptr %l69
  br label %bb33
bb33:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i32, ptr %l69, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t115, ptr %l70
  br label %bb34
bb34:
  %t116 = load i32, ptr %l70, !tbaa !23
  store i32 %t116, ptr %rv
  br label %ret
bb35:
  %t117 = load i32, ptr %l1, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 25, i64 %a1, i64 %a2, i64 %a3, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l9
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t10, %"compiler/types:data" %t11, i32 1)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l10, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eByAddress(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i64, ptr @G_2ecompiler_2ftypes_2eBigAggregate, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t13, %t12
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  store i32 21, ptr %l7
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l5, ptr %l7)
  store i1 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t12 = load i32, ptr %l1, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l18
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l24
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l12, !tbaa !29
  %t37 = load i32, ptr %l15, !tbaa !23
  %t38 = load i32, ptr %l18, !tbaa !23
  %t39 = load i32, ptr %l21, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t36, i32 %t37, i32 %t38, i32 %t39, i32 %t40, i64 %a2)
  store i32 %t42, ptr %l26
  br label %bb10
bb10:
  %t43 = load i32, ptr %l26, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr @.d32 })
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l14
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb6:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l23, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr @.d33 })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  store ptr %l2, ptr %l44, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t66, ptr %l46, !tbaa !27
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i32, ptr %t70, i64 %t67
  %t72 = load i32, ptr %t71, !tbaa !33
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t65, i32 %t72)
  store { i64, ptr } %t75, ptr %l49
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t76, { i64, ptr } %t77)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb10
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr @.d34 })
  br label %bb22
bb22:
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t84, ptr %l54
  br label %bb23
bb23:
  %t85 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t85, ptr %l55, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l56, !tbaa !24
  %t88 = load i64, ptr %l56, !tbaa !24
  %t89 = mul i64 %t88, 1
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l57, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l56, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  %t99 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp eq i32 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 12, ptr @.d35 }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l10, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l13
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l10, !tbaa !29
  %t32 = load i32, ptr %l13, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t33, ptr %l14
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l18
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l15, !tbaa !29
  %t41 = load i32, ptr %l18, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l19
  br label %bb8
bb8:
  %t43 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t47 = add i64 %t44, %t46
  %t48 = extractvalue { i64, ptr } { i64 3, ptr @.d37 }, 1
  %t49 = extractvalue { i64, ptr } { i64 3, ptr @.d37 }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 1, ptr @.d38 }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d38 }, 0
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t43, i64 %t44)
  %t59 = getelementptr i8, ptr %t58, i64 %t44
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t45)
  %t61 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t61, ptr %t48, i64 %t49)
  %t62 = getelementptr i8, ptr %t61, i64 %t49
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = getelementptr i8, ptr %t62, i64 %t53
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t58, 1
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:data"
  %rv = alloca %"compiler/types:data"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 1
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:data" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:data" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"compiler/types:body"
  %l6 = alloca %"compiler/types:body"
  %l7 = alloca i32
  %l9 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/types:body"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  %t7 = call { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, %"compiler/types:body" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/types:body" } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store %"compiler/types:body" %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load %"compiler/types:body", ptr %l6
  store %"compiler/types:body" %t12, ptr %l2
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t13, i1 false, i1 false)
  store %"compiler/types:body" %t15, ptr %l9
  br label %bb4
bb4:
  %t16 = load %"compiler/types:body", ptr %l9
  store %"compiler/types:body" %t16, ptr %l2
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/types:body", ptr %l2
  store %"compiler/types:body" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:body", ptr %rv
  ret %"compiler/types:body" %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:data"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i32
  %l48 = alloca %"compiler/types:data"
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca i64
  %l103 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l115 = alloca i32
  %l116 = alloca ptr
  %l118 = alloca ptr
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca { i64, ptr }
  %l145 = alloca i64
  %l148 = alloca i64
  %l171 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l181 = alloca ptr
  %l184 = alloca i32
  %l187 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l194 = alloca i32
  %l200 = alloca i64
  %l211 = alloca ptr
  %l212 = alloca ptr
  %l215 = alloca i32
  %l220 = alloca ptr
  %l221 = alloca ptr
  %l224 = alloca i32
  %l228 = alloca i32
  %l234 = alloca i32
  %l236 = alloca i32
  %l238 = alloca i1
  %l239 = alloca ptr
  %l241 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l250 = alloca i32
  %l251 = alloca { i64, ptr }
  %l259 = alloca i1
  %l260 = alloca { i64, ptr }
  %l270 = alloca i64
  %l273 = alloca i64
  %l291 = alloca ptr
  %l294 = alloca { i64, ptr }
  %l297 = alloca { i64, ptr }
  %l304 = alloca i1
  %l311 = alloca { i64, ptr }
  %l317 = alloca i64
  %l320 = alloca i64
  %l341 = alloca ptr
  %l344 = alloca { i64, ptr }
  %l349 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l365 = alloca i64
  %l368 = alloca i64
  %l390 = alloca { i64, ptr }
  %l401 = alloca ptr
  %l402 = alloca ptr
  %l405 = alloca i32
  %l410 = alloca ptr
  %l411 = alloca ptr
  %l414 = alloca i32
  %l421 = alloca { i64, ptr }
  %l422 = alloca ptr
  %l425 = alloca i32
  %l426 = alloca { i64, ptr }
  %l432 = alloca i64
  %l435 = alloca i64
  %l456 = alloca ptr
  %l459 = alloca { i64, ptr }
  %l462 = alloca { i64, ptr }
  %l463 = alloca { i64, ptr }
  %l468 = alloca ptr
  %l469 = alloca ptr
  %l471 = alloca { i64, ptr }
  %l474 = alloca i32
  %l490 = alloca i32
  %l494 = alloca ptr
  %l497 = alloca { i64, ptr }
  %l500 = alloca i1
  %l501 = alloca i1
  %l504 = alloca ptr
  %l506 = alloca { i64, ptr }
  %l514 = alloca ptr
  %l517 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s54 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l48
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l48
  store %"compiler/types:data" %t6, ptr %l3
  %t7 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4
  %t10 = load i32, ptr %l4
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t15, { i64, ptr } { i64 1, ptr @.d39 })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb316
bb6:
  %t17 = load i32, ptr %l4
  %t19 = trunc i64 15 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t22, { i64, ptr } { i64 4, ptr @.d40 })
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb316
bb11:
  %t24 = load i32, ptr %l4
  %t26 = trunc i64 16 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t29, { i64, ptr } { i64 7, ptr @.d41 })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb316
bb16:
  %t31 = load i32, ptr %l4
  %t33 = trunc i64 17 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t36, { i64, ptr } { i64 8, ptr @.d42 })
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb316
bb21:
  %t38 = load i32, ptr %l4
  %t40 = trunc i64 28 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l64, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l65, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l68
  br label %bb25
bb25:
  %t50 = load ptr, ptr %l64, !tbaa !29
  %t51 = load ptr, ptr %l65, !tbaa !29
  %t52 = load i32, ptr %l68, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t50, ptr %t51, i32 %t52)
  br label %bb26
bb26:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l69, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t54, i32 %t55)
  store i64 %t58, ptr %l72
  br label %bb27
bb27:
  %t59 = extractvalue { i64, ptr } { i64 2, ptr @.d43 }, 1
  %t60 = extractvalue { i64, ptr } { i64 2, ptr @.d43 }, 0
  %t61 = load i64, ptr %l72, !tbaa !65
  %t62 = call i64 @__olang_fmt_u64(ptr null, i64 %t61)
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = getelementptr i8, ptr %t64, i64 %t60
  %t66 = call i64 @__olang_fmt_u64(ptr %t65, i64 %t61)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t76, { i64, ptr } %t75)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb316
bb29:
  %t78 = load i32, ptr %l4
  %t80 = trunc i64 1 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  br label %bb58
bb31:
  %t83 = load i32, ptr %l4
  %t85 = trunc i64 2 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb32, label %bb33
bb32:
  br label %bb58
bb33:
  %t88 = load i32, ptr %l4
  %t90 = trunc i64 3 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb34, label %bb35
bb34:
  br label %bb58
bb35:
  %t93 = load i32, ptr %l4
  %t95 = trunc i64 4 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb36, label %bb37
bb36:
  br label %bb58
bb37:
  %t98 = load i32, ptr %l4
  %t100 = trunc i64 5 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  %t103 = load i32, ptr %l4
  %t105 = trunc i64 6 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb40, label %bb41
bb40:
  br label %bb58
bb41:
  %t108 = load i32, ptr %l4
  %t110 = trunc i64 7 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb42, label %bb43
bb42:
  br label %bb58
bb43:
  %t113 = load i32, ptr %l4
  %t115 = trunc i64 8 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb44, label %bb45
bb44:
  br label %bb58
bb45:
  %t118 = load i32, ptr %l4
  %t120 = trunc i64 9 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb46, label %bb47
bb46:
  br label %bb58
bb47:
  %t123 = load i32, ptr %l4
  %t125 = trunc i64 10 to i32
  %t126 = icmp eq i32 %t123, %t125
  br i1 %t126, label %bb48, label %bb49
bb48:
  br label %bb58
bb49:
  %t128 = load i32, ptr %l4
  %t130 = trunc i64 11 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  %t133 = load i32, ptr %l4
  %t135 = trunc i64 12 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb52, label %bb53
bb52:
  br label %bb58
bb53:
  %t138 = load i32, ptr %l4
  %t140 = trunc i64 13 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  %t143 = load i32, ptr %l4
  %t145 = trunc i64 14 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l103, !tbaa !29
  %t149 = load i32, ptr %l2, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 4, ptr @.d44 }, ptr %l107, !tbaa !27
  br label %bb61
bb60:
  %t155 = load i32, ptr %l2, !tbaa !23
  %t157 = sext i32 %t155 to i64
  %t159 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimNames, i64 0, i64 %t157
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !37
  store { i64, ptr } %t160, ptr %l107, !tbaa !27
  br label %bb61
bb61:
  %t162 = load ptr, ptr @__olang_prog_scope
  %t163 = load ptr, ptr %l103, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l107, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %t162, ptr %t163, { i64, ptr } %t164)
  br label %bb62
bb62:
  br label %bb316
bb63:
  %t165 = load i32, ptr %l4
  %t167 = trunc i64 18 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb99
bb66:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l2, !tbaa !23
  %t174 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t174, ptr %l115
  br label %bb67
bb67:
  %t175 = load i32, ptr %l115, !tbaa !23
  store i32 %t175, ptr %l5, !tbaa !23
  %t176 = load ptr, ptr %l1, !tbaa !29
  store ptr %t176, ptr %l116, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/types:Table", ptr %t177, i32 0, i32 14
  store ptr %t179, ptr %l118, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i32, ptr %l5, !tbaa !23
  %t184 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t180, i32 %t181)
  store i64 %t184, ptr %l121
  br label %bb68
bb68:
  %t185 = load ptr, ptr %l118, !tbaa !29
  %t186 = load i64, ptr %l121, !tbaa !24
  %t187 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t185, i64 %t186)
  store { i64, ptr } %t187, ptr %l122
  br label %bb69
bb69:
  %t188 = load ptr, ptr %l116, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l122, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t188, { i64, ptr } %t189)
  br label %bb70
bb70:
  %t190 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t190, i8 58)
  br label %bb71
bb71:
  %t192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t192, ptr %l124, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/types:Table", ptr %t193, i32 0, i32 0
  %t196 = load ptr, ptr %t195, !tbaa !29
  store ptr %t196, ptr %l126, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l5, !tbaa !23
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t197, i32 %t198)
  store i32 %t201, ptr %l129
  br label %bb72
bb72:
  %t202 = load ptr, ptr %l126, !tbaa !29
  %t203 = load i32, ptr %l129, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t202, i32 %t203)
  store { i64, ptr } %t204, ptr %l130
  br label %bb73
bb73:
  %t205 = load ptr, ptr %l124, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l130, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t205, { i64, ptr } %t206)
  br label %bb74
bb74:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l131, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i32, ptr %l2, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l134
  br label %bb75
bb75:
  %t213 = load ptr, ptr %l131, !tbaa !29
  %t214 = load i32, ptr %l134, !tbaa !23
  %t215 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t213, i32 %t214)
  store { i64, ptr } %t215, ptr %l135
  br label %bb76
bb76:
  %t216 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t216, ptr %l6, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb77, label %bb78
bb77:
  %t223 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t223, i8 60)
  br label %bb79
bb78:
  br label %bb98
bb79:
  store i64 0, ptr %l7, !tbaa !24
  %t225 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t225, 0
  store i64 %t227, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t229 = load i64, ptr %l8, !tbaa !24
  %t230 = load i64, ptr %l7, !tbaa !24
  %t233 = icmp sgt i64 %t229, %t230
  br i1 %t233, label %bb80, label %bb81
bb80:
  %t235 = load i64, ptr %l9, !tbaa !24
  %t237 = icmp sgt i64 %t235, 0
  br i1 %t237, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb85
bb82:
  %t239 = load i64, ptr %l8, !tbaa !24
  %t240 = load i64, ptr %l7, !tbaa !24
  %t243 = sub i64 %t239, %t240
  %t244 = load i64, ptr %l9, !tbaa !24
  %t247 = add i64 %t243, %t244
  %t249 = sub i64 %t247, 1
  %t250 = load i64, ptr %l9, !tbaa !24
  %t253 = sdiv i64 %t249, %t250
  store i64 %t253, ptr %l148, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb84
bb84:
  %t255 = load i64, ptr %l148, !tbaa !24
  store i64 %t255, ptr %l145, !tbaa !24
  br label %bb85
bb85:
  %t256 = load i64, ptr %l145, !tbaa !24
  store i64 %t256, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s11
  %t257 = load i64, ptr %l11, !tbaa !24
  %t258 = load i64, ptr %l10, !tbaa !24
  %t261 = icmp slt i64 %t257, %t258
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s11)
  br label %bb96
bb88:
  br label %bb89
bb89:
  %t265 = load i64, ptr %l7, !tbaa !24
  %t266 = load i64, ptr %l11, !tbaa !24
  %t267 = load i64, ptr %l9, !tbaa !24
  %t270 = mul i64 %t266, %t267
  %t273 = add i64 %t265, %t270
  store i64 %t273, ptr %l12, !tbaa !24
  %t275 = load i64, ptr %l12, !tbaa !24
  %t277 = icmp sgt i64 %t275, 0
  br i1 %t277, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s12
  %t279 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s12, ptr %t279, { i64, ptr } { i64 2, ptr @.d45 })
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb93:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l1, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t283, ptr %l171, !tbaa !27
  %t284 = load i64, ptr %l12, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr i32, ptr %t287, i64 %t284
  %t289 = load i32, ptr %t288, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t281, ptr %t282, i32 %t289)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb95:
  %t293 = load i64, ptr %l11, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l11, !tbaa !24
  br label %bb86
bb96:
  %t297 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t297, i8 62)
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb316
bb99:
  %t299 = load i32, ptr %l4
  %t301 = trunc i64 19 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb114
bb102:
  store %olang.scope zeroinitializer, ptr %s14
  %t304 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s14, ptr %t304, { i64, ptr } { i64 6, ptr @.d46 })
  br label %bb103
bb103:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l180, !tbaa !29
  %t307 = load ptr, ptr %l1, !tbaa !29
  store ptr %t307, ptr %l181, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i32, ptr %l2, !tbaa !23
  %t312 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t308, i32 %t309)
  store i32 %t312, ptr %l184
  br label %bb104
bb104:
  %t313 = load ptr, ptr %l180, !tbaa !29
  %t314 = load ptr, ptr %l181, !tbaa !29
  %t315 = load i32, ptr %l184, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t313, ptr %t314, i32 %t315)
  br label %bb105
bb105:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l2, !tbaa !23
  %t320 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t316, i32 %t317)
  store i32 %t320, ptr %l187
  br label %bb106
bb106:
  %t321 = load i32, ptr %l187, !tbaa !23
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s15
  %t324 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t324, { i64, ptr } { i64 2, ptr @.d47 })
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l190, !tbaa !29
  %t327 = load ptr, ptr %l1, !tbaa !29
  store ptr %t327, ptr %l191, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i32, ptr %l2, !tbaa !23
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t332, ptr %l194
  br label %bb110
bb110:
  %t333 = load ptr, ptr %l190, !tbaa !29
  %t334 = load ptr, ptr %l191, !tbaa !29
  %t335 = load i32, ptr %l194, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t333, ptr %t334, i32 %t335)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s15)
  br label %bb112
bb112:
  %t336 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t336, i8 62)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s14)
  br label %bb316
bb114:
  %t338 = load i32, ptr %l4
  %t340 = trunc i64 20 to i32
  %t341 = icmp eq i32 %t338, %t340
  br i1 %t341, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb130
bb117:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l2, !tbaa !23
  %t347 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t343, i32 %t344)
  store i64 %t347, ptr %l200
  br label %bb118
bb118:
  %t348 = load i64, ptr %l200, !tbaa !24
  store i64 %t348, ptr %l13, !tbaa !24
  %t349 = load i64, ptr %l13, !tbaa !24
  %t350 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t353 = and i64 %t349, %t350
  %t355 = icmp ne i64 %t353, 0
  br i1 %t355, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s17
  %t357 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s17, ptr %t357, { i64, ptr } { i64 4, ptr @.d48 })
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s17)
  br label %bb122
bb122:
  %t359 = load i64, ptr %l13, !tbaa !24
  %t360 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t363 = and i64 %t359, %t360
  %t365 = icmp ne i64 %t363, 0
  br i1 %t365, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s18
  %t367 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s18, ptr %t367, { i64, ptr } { i64 4, ptr @.d49 })
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s18)
  br label %bb126
bb126:
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l211, !tbaa !29
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l212, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l2, !tbaa !23
  %t375 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l215
  br label %bb127
bb127:
  %t376 = load ptr, ptr %l211, !tbaa !29
  %t377 = load ptr, ptr %l212, !tbaa !29
  %t378 = load i32, ptr %l215, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t376, ptr %t377, i32 %t378)
  br label %bb128
bb128:
  %t379 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t379, i8 38)
  br label %bb129
bb129:
  br label %bb316
bb130:
  %t381 = load i32, ptr %l4
  %t383 = trunc i64 21 to i32
  %t384 = icmp eq i32 %t381, %t383
  br i1 %t384, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb232
bb133:
  store %olang.scope zeroinitializer, ptr %s19
  %t386 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t386, { i64, ptr } { i64 3, ptr @.d50 })
  br label %bb134
bb134:
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l220, !tbaa !29
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l221, !tbaa !29
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i32, ptr %l2, !tbaa !23
  %t394 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t390, i32 %t391)
  store i32 %t394, ptr %l224
  br label %bb135
bb135:
  %t395 = load ptr, ptr %l220, !tbaa !29
  %t396 = load ptr, ptr %l221, !tbaa !29
  %t397 = load i32, ptr %l224, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t395, ptr %t396, i32 %t397)
  br label %bb136
bb136:
  %t398 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t398, i8 41)
  br label %bb137
bb137:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i32, ptr %l2, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t400, i32 %t401)
  store i32 %t404, ptr %l228
  br label %bb138
bb138:
  %t405 = load i32, ptr %l228, !tbaa !23
  store i32 %t405, ptr %l14, !tbaa !23
  %t406 = load i32, ptr %l14, !tbaa !23
  %t407 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t410 = icmp ne i32 %t406, %t407
  br i1 %t410, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s20
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load i32, ptr %l14, !tbaa !23
  %t416 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t412, i32 %t413)
  store i32 %t416, ptr %l234
  br label %bb141
bb140:
  br label %bb152
bb141:
  store i32 21, ptr %l236
  %t419 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l234, ptr %l236)
  store i1 %t419, ptr %l238
  br label %bb142
bb142:
  %t420 = load i1, ptr %l238, !tbaa !21
  store i1 %t420, ptr %l15, !tbaa !21
  %t421 = load ptr, ptr %l1, !tbaa !29
  store ptr %t421, ptr %l239, !tbaa !29
  %t422 = load i1, ptr %l15, !tbaa !21
  br i1 %t422, label %bb143, label %bb144
bb143:
  store { i64, ptr } { i64 2, ptr @.d51 }, ptr %l241, !tbaa !27
  br label %bb145
bb144:
  store { i64, ptr } { i64 1, ptr @.d52 }, ptr %l241, !tbaa !27
  br label %bb145
bb145:
  %t424 = load ptr, ptr %l239, !tbaa !29
  %t425 = load { i64, ptr }, ptr %l241, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s20, ptr %t424, { i64, ptr } %t425)
  br label %bb146
bb146:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t428 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t426, ptr %t427, i32 %t428)
  br label %bb147
bb147:
  %t432 = load i1, ptr %l15, !tbaa !21
  br i1 %t432, label %bb148, label %bb149
bb148:
  %t434 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t434, i8 41)
  br label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s20)
  br label %bb152
bb152:
  %t436 = load ptr, ptr %l0, !tbaa !29
  store ptr %t436, ptr %l247, !tbaa !29
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t438 = load i32, ptr %l2, !tbaa !23
  %t441 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t437, i32 %t438)
  store i32 %t441, ptr %l250
  br label %bb153
bb153:
  %t442 = load ptr, ptr %l247, !tbaa !29
  %t443 = load i32, ptr %l250, !tbaa !23
  %t444 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t442, i32 %t443)
  store { i64, ptr } %t444, ptr %l251
  br label %bb154
bb154:
  %t445 = load { i64, ptr }, ptr %l251, !tbaa !27
  store { i64, ptr } %t445, ptr %l16, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t446, 0
  %t450 = icmp sgt i64 %t448, 0
  br i1 %t450, label %bb155, label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s22
  %t452 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s22, ptr %t452, { i64, ptr } { i64 2, ptr @.d53 })
  br label %bb157
bb156:
  br label %bb181
bb157:
  %t454 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t458 = icmp eq i64 %t456, 1
  br i1 %t458, label %bb158, label %bb159
bb158:
  %t460 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t460, ptr %l260, !tbaa !27
  %t461 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !27
  %t463 = getelementptr i32, ptr %t462, i64 0
  %t464 = load i32, ptr %t463, !tbaa !33
  %t465 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t468 = icmp eq i32 %t464, %t465
  store i1 %t468, ptr %l259, !tbaa !21
  br label %bb160
bb159:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb160
bb160:
  %t470 = load i1, ptr %l259, !tbaa !21
  %t471 = xor i1 %t470, true
  br i1 %t471, label %bb161, label %bb162
bb161:
  store i64 0, ptr %l17, !tbaa !24
  %t473 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t473, 0
  store i64 %t475, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t477 = load i64, ptr %l18, !tbaa !24
  %t478 = load i64, ptr %l17, !tbaa !24
  %t481 = icmp sgt i64 %t477, %t478
  br i1 %t481, label %bb163, label %bb164
bb162:
  br label %bb180
bb163:
  %t483 = load i64, ptr %l19, !tbaa !24
  %t485 = icmp sgt i64 %t483, 0
  br i1 %t485, label %bb165, label %bb166
bb164:
  store i64 0, ptr %l270, !tbaa !24
  br label %bb168
bb165:
  %t487 = load i64, ptr %l18, !tbaa !24
  %t488 = load i64, ptr %l17, !tbaa !24
  %t491 = sub i64 %t487, %t488
  %t492 = load i64, ptr %l19, !tbaa !24
  %t495 = add i64 %t491, %t492
  %t497 = sub i64 %t495, 1
  %t498 = load i64, ptr %l19, !tbaa !24
  %t501 = sdiv i64 %t497, %t498
  store i64 %t501, ptr %l273, !tbaa !24
  br label %bb167
bb166:
  store i64 0, ptr %l273, !tbaa !24
  br label %bb167
bb167:
  %t503 = load i64, ptr %l273, !tbaa !24
  store i64 %t503, ptr %l270, !tbaa !24
  br label %bb168
bb168:
  %t504 = load i64, ptr %l270, !tbaa !24
  store i64 %t504, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb169
bb169:
  store %olang.scope zeroinitializer, ptr %s25
  %t505 = load i64, ptr %l21, !tbaa !24
  %t506 = load i64, ptr %l20, !tbaa !24
  %t509 = icmp slt i64 %t505, %t506
  %t511 = xor i1 %t509, true
  br i1 %t511, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s25)
  br label %bb179
bb171:
  br label %bb172
bb172:
  %t513 = load i64, ptr %l17, !tbaa !24
  %t514 = load i64, ptr %l21, !tbaa !24
  %t515 = load i64, ptr %l19, !tbaa !24
  %t518 = mul i64 %t514, %t515
  %t521 = add i64 %t513, %t518
  store i64 %t521, ptr %l22, !tbaa !24
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l291, !tbaa !29
  %t524 = load i64, ptr %l22, !tbaa !24
  %t526 = icmp sgt i64 %t524, 0
  br i1 %t526, label %bb173, label %bb174
bb173:
  store { i64, ptr } { i64 3, ptr @.d54 }, ptr %l294, !tbaa !27
  br label %bb175
bb174:
  store { i64, ptr } { i64 1, ptr @.d55 }, ptr %l294, !tbaa !27
  br label %bb175
bb175:
  %t528 = load ptr, ptr %l291, !tbaa !29
  %t529 = load { i64, ptr }, ptr %l294, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s25, ptr %t528, { i64, ptr } %t529)
  br label %bb176
bb176:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t532 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t532, ptr %l297, !tbaa !27
  %t533 = load i64, ptr %l22, !tbaa !24
  %t535 = getelementptr { i64, ptr }, ptr %l297, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = getelementptr i32, ptr %t536, i64 %t533
  %t538 = load i32, ptr %t537, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t530, ptr %t531, i32 %t538)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s25)
  br label %bb178
bb178:
  %t542 = load i64, ptr %l21, !tbaa !24
  %t544 = add i64 %t542, 1
  store i64 %t544, ptr %l21, !tbaa !24
  br label %bb169
bb179:
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s22)
  br label %bb181
bb181:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t548 = getelementptr %"compiler/types:Table", ptr %t546, i32 0, i32 3
  %t549 = load i1, ptr %t548, !tbaa !21
  br i1 %t549, label %bb182, label %bb183
bb182:
  %t551 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t552 = load i64, ptr %t551, !tbaa !24
  %t554 = icmp ne i64 %t552, 0
  store i1 %t554, ptr %l304, !tbaa !21
  br label %bb184
bb183:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb184
bb184:
  %t556 = load i1, ptr %l304, !tbaa !21
  br i1 %t556, label %bb185, label %bb186
bb185:
  %t557 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t557, i8 123)
  br label %bb187
bb186:
  br label %bb208
bb187:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/types:Table", ptr %t559, i32 0, i32 28
  %t562 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t563 = load i64, ptr %t562, !tbaa !24
  %t566 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t561, i64 %t563)
  store { i64, ptr } %t566, ptr %l311
  br label %bb188
bb188:
  %t567 = load { i64, ptr }, ptr %l311, !tbaa !27
  store { i64, ptr } %t567, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t568 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t568, 0
  store i64 %t570, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t572 = load i64, ptr %l25, !tbaa !24
  %t573 = load i64, ptr %l24, !tbaa !24
  %t576 = icmp sgt i64 %t572, %t573
  br i1 %t576, label %bb189, label %bb190
bb189:
  %t578 = load i64, ptr %l26, !tbaa !24
  %t580 = icmp sgt i64 %t578, 0
  br i1 %t580, label %bb191, label %bb192
bb190:
  store i64 0, ptr %l317, !tbaa !24
  br label %bb194
bb191:
  %t582 = load i64, ptr %l25, !tbaa !24
  %t583 = load i64, ptr %l24, !tbaa !24
  %t586 = sub i64 %t582, %t583
  %t587 = load i64, ptr %l26, !tbaa !24
  %t590 = add i64 %t586, %t587
  %t592 = sub i64 %t590, 1
  %t593 = load i64, ptr %l26, !tbaa !24
  %t596 = sdiv i64 %t592, %t593
  store i64 %t596, ptr %l320, !tbaa !24
  br label %bb193
bb192:
  store i64 0, ptr %l320, !tbaa !24
  br label %bb193
bb193:
  %t598 = load i64, ptr %l320, !tbaa !24
  store i64 %t598, ptr %l317, !tbaa !24
  br label %bb194
bb194:
  %t599 = load i64, ptr %l317, !tbaa !24
  store i64 %t599, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb195
bb195:
  store %olang.scope zeroinitializer, ptr %s29
  %t600 = load i64, ptr %l28, !tbaa !24
  %t601 = load i64, ptr %l27, !tbaa !24
  %t604 = icmp slt i64 %t600, %t601
  %t606 = xor i1 %t604, true
  br i1 %t606, label %bb196, label %bb197
bb196:
  call void @__olang_scope_close(ptr %s29)
  br label %bb206
bb197:
  br label %bb198
bb198:
  %t608 = load i64, ptr %l24, !tbaa !24
  %t609 = load i64, ptr %l28, !tbaa !24
  %t610 = load i64, ptr %l26, !tbaa !24
  %t613 = mul i64 %t609, %t610
  %t616 = add i64 %t608, %t613
  store i64 %t616, ptr %l29, !tbaa !24
  %t618 = load i64, ptr %l29, !tbaa !24
  %t620 = icmp sgt i64 %t618, 0
  br i1 %t620, label %bb199, label %bb200
bb199:
  %t622 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t622, i8 44)
  br label %bb201
bb200:
  br label %bb202
bb201:
  br label %bb202
bb202:
  %t624 = load ptr, ptr %l1, !tbaa !29
  store ptr %t624, ptr %l341, !tbaa !29
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/types:Table", ptr %t625, i32 0, i32 0
  %t628 = load ptr, ptr %t627, !tbaa !29
  %t629 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t629, ptr %l344, !tbaa !27
  %t630 = load i64, ptr %l29, !tbaa !24
  %t632 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !27
  %t634 = getelementptr i64, ptr %t633, i64 %t630
  %t635 = load i64, ptr %t634, !tbaa !34
  %t637 = trunc i64 %t635 to i32
  %t641 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t628, i32 %t637)
  store { i64, ptr } %t641, ptr %l349
  br label %bb203
bb203:
  %t642 = load ptr, ptr %l341, !tbaa !29
  %t643 = load { i64, ptr }, ptr %l349, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t642, { i64, ptr } %t643)
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s29)
  br label %bb205
bb205:
  %t644 = load i64, ptr %l28, !tbaa !24
  %t646 = add i64 %t644, 1
  store i64 %t646, ptr %l28, !tbaa !24
  br label %bb195
bb206:
  %t648 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t648, i8 125)
  br label %bb207
bb207:
  br label %bb208
bb208:
  %t650 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t651 = load i64, ptr %t650, !tbaa !24
  %t653 = icmp ne i64 %t651, 0
  br i1 %t653, label %bb209, label %bb210
bb209:
  store %olang.scope zeroinitializer, ptr %s32
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t657 = getelementptr %"compiler/types:Table", ptr %t655, i32 0, i32 26
  %t658 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t659 = load i64, ptr %t658, !tbaa !24
  %t662 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t657, i64 %t659)
  store { i64, ptr } %t662, ptr %l358
  br label %bb211
bb210:
  br label %bb231
bb211:
  %t663 = load { i64, ptr }, ptr %l358, !tbaa !27
  store { i64, ptr } %t663, ptr %l30, !tbaa !27
  %t664 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s32, ptr %t664, { i64, ptr } { i64 3, ptr @.d56 })
  br label %bb212
bb212:
  store i64 0, ptr %l31, !tbaa !24
  %t666 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t668 = extractvalue { i64, ptr } %t666, 0
  store i64 %t668, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t670 = load i64, ptr %l32, !tbaa !24
  %t671 = load i64, ptr %l31, !tbaa !24
  %t674 = icmp sgt i64 %t670, %t671
  br i1 %t674, label %bb213, label %bb214
bb213:
  %t676 = load i64, ptr %l33, !tbaa !24
  %t678 = icmp sgt i64 %t676, 0
  br i1 %t678, label %bb215, label %bb216
bb214:
  store i64 0, ptr %l365, !tbaa !24
  br label %bb218
bb215:
  %t680 = load i64, ptr %l32, !tbaa !24
  %t681 = load i64, ptr %l31, !tbaa !24
  %t684 = sub i64 %t680, %t681
  %t685 = load i64, ptr %l33, !tbaa !24
  %t688 = add i64 %t684, %t685
  %t690 = sub i64 %t688, 1
  %t691 = load i64, ptr %l33, !tbaa !24
  %t694 = sdiv i64 %t690, %t691
  store i64 %t694, ptr %l368, !tbaa !24
  br label %bb217
bb216:
  store i64 0, ptr %l368, !tbaa !24
  br label %bb217
bb217:
  %t696 = load i64, ptr %l368, !tbaa !24
  store i64 %t696, ptr %l365, !tbaa !24
  br label %bb218
bb218:
  %t697 = load i64, ptr %l365, !tbaa !24
  store i64 %t697, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb219
bb219:
  store %olang.scope zeroinitializer, ptr %s34
  %t698 = load i64, ptr %l35, !tbaa !24
  %t699 = load i64, ptr %l34, !tbaa !24
  %t702 = icmp slt i64 %t698, %t699
  %t704 = xor i1 %t702, true
  br i1 %t704, label %bb220, label %bb221
bb220:
  call void @__olang_scope_close(ptr %s34)
  br label %bb229
bb221:
  br label %bb222
bb222:
  %t706 = load i64, ptr %l31, !tbaa !24
  %t707 = load i64, ptr %l35, !tbaa !24
  %t708 = load i64, ptr %l33, !tbaa !24
  %t711 = mul i64 %t707, %t708
  %t714 = add i64 %t706, %t711
  store i64 %t714, ptr %l36, !tbaa !24
  %t716 = load i64, ptr %l36, !tbaa !24
  %t718 = icmp sgt i64 %t716, 0
  br i1 %t718, label %bb223, label %bb224
bb223:
  %t720 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t720, i8 44)
  br label %bb225
bb224:
  br label %bb226
bb225:
  br label %bb226
bb226:
  %t722 = load ptr, ptr %l1, !tbaa !29
  %t723 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t723, ptr %l390, !tbaa !27
  %t724 = load i64, ptr %l36, !tbaa !24
  %t726 = getelementptr { i64, ptr }, ptr %l390, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !27
  %t728 = getelementptr i64, ptr %t727, i64 %t724
  %t729 = load i64, ptr %t728, !tbaa !34
  %t731 = call i64 @__olang_fmt_i64(ptr null, i64 %t729)
  %t732 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t731)
  %t733 = call i64 @__olang_fmt_i64(ptr %t732, i64 %t729)
  %t734 = insertvalue { i64, ptr } undef, i64 %t731, 0
  %t735 = insertvalue { i64, ptr } %t734, ptr %t732, 1
  %t737 = extractvalue { i64, ptr } %t735, 0
  %t738 = extractvalue { i64, ptr } %t735, 1
  %t739 = mul i64 %t737, 1
  %t740 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t739)
  call void @llvm.memcpy.p0.p0.i64(ptr %t740, ptr %t738, i64 %t739, i1 false)
  %t741 = insertvalue { i64, ptr } undef, i64 %t737, 0
  %t742 = insertvalue { i64, ptr } %t741, ptr %t740, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s34, ptr %t722, { i64, ptr } %t742)
  br label %bb227
bb227:
  call void @__olang_scope_close(ptr %s34)
  br label %bb228
bb228:
  %t745 = load i64, ptr %l35, !tbaa !24
  %t747 = add i64 %t745, 1
  store i64 %t747, ptr %l35, !tbaa !24
  br label %bb219
bb229:
  %t749 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t749, i8 93)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s32)
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s19)
  br label %bb316
bb232:
  %t751 = load i32, ptr %l4
  %t753 = trunc i64 22 to i32
  %t754 = icmp eq i32 %t751, %t753
  br i1 %t754, label %bb233, label %bb234
bb233:
  br label %bb235
bb234:
  br label %bb240
bb235:
  %t756 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t756, i8 40)
  br label %bb236
bb236:
  %t758 = load ptr, ptr %l0, !tbaa !29
  store ptr %t758, ptr %l401, !tbaa !29
  %t759 = load ptr, ptr %l1, !tbaa !29
  store ptr %t759, ptr %l402, !tbaa !29
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t761 = load i32, ptr %l2, !tbaa !23
  %t764 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t760, i32 %t761)
  store i32 %t764, ptr %l405
  br label %bb237
bb237:
  %t765 = load ptr, ptr %l401, !tbaa !29
  %t766 = load ptr, ptr %l402, !tbaa !29
  %t767 = load i32, ptr %l405, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t765, ptr %t766, i32 %t767)
  br label %bb238
bb238:
  %t768 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t768, i8 41)
  br label %bb239
bb239:
  br label %bb316
bb240:
  %t770 = load i32, ptr %l4
  %t772 = trunc i64 23 to i32
  %t773 = icmp eq i32 %t770, %t772
  br i1 %t773, label %bb241, label %bb242
bb241:
  br label %bb243
bb242:
  br label %bb248
bb243:
  store %olang.scope zeroinitializer, ptr %s39
  %t775 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s39, ptr %t775, { i64, ptr } { i64 7, ptr @.d57 })
  br label %bb244
bb244:
  %t777 = load ptr, ptr %l0, !tbaa !29
  store ptr %t777, ptr %l410, !tbaa !29
  %t778 = load ptr, ptr %l1, !tbaa !29
  store ptr %t778, ptr %l411, !tbaa !29
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t780 = load i32, ptr %l2, !tbaa !23
  %t783 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t779, i32 %t780)
  store i32 %t783, ptr %l414
  br label %bb245
bb245:
  %t784 = load ptr, ptr %l410, !tbaa !29
  %t785 = load ptr, ptr %l411, !tbaa !29
  %t786 = load i32, ptr %l414, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t784, ptr %t785, i32 %t786)
  br label %bb246
bb246:
  %t787 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t787, i8 41)
  br label %bb247
bb247:
  call void @__olang_scope_close(ptr %s39)
  br label %bb316
bb248:
  %t789 = load i32, ptr %l4
  %t791 = trunc i64 24 to i32
  %t792 = icmp eq i32 %t789, %t791
  br i1 %t792, label %bb249, label %bb250
bb249:
  br label %bb251
bb250:
  br label %bb282
bb251:
  store %olang.scope zeroinitializer, ptr %s40
  %t794 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t794, { i64, ptr } { i64 5, ptr @.d58 })
  br label %bb252
bb252:
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t797 = load i32, ptr %l2, !tbaa !23
  %t800 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %t796, i32 %t797)
  store { i64, ptr } %t800, ptr %l421
  br label %bb253
bb253:
  %t801 = load { i64, ptr }, ptr %l421, !tbaa !27
  store { i64, ptr } %t801, ptr %l37, !tbaa !27
  %t802 = load ptr, ptr %l0, !tbaa !29
  store ptr %t802, ptr %l422, !tbaa !29
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load i32, ptr %l2, !tbaa !23
  %t807 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t803, i32 %t804)
  store i32 %t807, ptr %l425
  br label %bb254
bb254:
  %t808 = load ptr, ptr %l422, !tbaa !29
  %t809 = load i32, ptr %l425, !tbaa !23
  %t810 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t808, i32 %t809)
  store { i64, ptr } %t810, ptr %l426
  br label %bb255
bb255:
  %t811 = load { i64, ptr }, ptr %l426, !tbaa !27
  store { i64, ptr } %t811, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t812 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t814 = extractvalue { i64, ptr } %t812, 0
  store i64 %t814, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t816 = load i64, ptr %l40, !tbaa !24
  %t817 = load i64, ptr %l39, !tbaa !24
  %t820 = icmp sgt i64 %t816, %t817
  br i1 %t820, label %bb256, label %bb257
bb256:
  %t822 = load i64, ptr %l41, !tbaa !24
  %t824 = icmp sgt i64 %t822, 0
  br i1 %t824, label %bb258, label %bb259
bb257:
  store i64 0, ptr %l432, !tbaa !24
  br label %bb261
bb258:
  %t826 = load i64, ptr %l40, !tbaa !24
  %t827 = load i64, ptr %l39, !tbaa !24
  %t830 = sub i64 %t826, %t827
  %t831 = load i64, ptr %l41, !tbaa !24
  %t834 = add i64 %t830, %t831
  %t836 = sub i64 %t834, 1
  %t837 = load i64, ptr %l41, !tbaa !24
  %t840 = sdiv i64 %t836, %t837
  store i64 %t840, ptr %l435, !tbaa !24
  br label %bb260
bb259:
  store i64 0, ptr %l435, !tbaa !24
  br label %bb260
bb260:
  %t842 = load i64, ptr %l435, !tbaa !24
  store i64 %t842, ptr %l432, !tbaa !24
  br label %bb261
bb261:
  %t843 = load i64, ptr %l432, !tbaa !24
  store i64 %t843, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb262
bb262:
  store %olang.scope zeroinitializer, ptr %s42
  %t844 = load i64, ptr %l43, !tbaa !24
  %t845 = load i64, ptr %l42, !tbaa !24
  %t848 = icmp slt i64 %t844, %t845
  %t850 = xor i1 %t848, true
  br i1 %t850, label %bb263, label %bb264
bb263:
  call void @__olang_scope_close(ptr %s42)
  br label %bb280
bb264:
  br label %bb265
bb265:
  %t852 = load i64, ptr %l39, !tbaa !24
  %t853 = load i64, ptr %l43, !tbaa !24
  %t854 = load i64, ptr %l41, !tbaa !24
  %t857 = mul i64 %t853, %t854
  %t860 = add i64 %t852, %t857
  store i64 %t860, ptr %l44, !tbaa !24
  %t862 = load i64, ptr %l44, !tbaa !24
  %t864 = icmp sgt i64 %t862, 0
  br i1 %t864, label %bb266, label %bb267
bb266:
  %t866 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t866, i8 32)
  br label %bb268
bb267:
  br label %bb269
bb268:
  br label %bb269
bb269:
  %t868 = load ptr, ptr %l1, !tbaa !29
  store ptr %t868, ptr %l456, !tbaa !29
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t871 = getelementptr %"compiler/types:Table", ptr %t869, i32 0, i32 0
  %t872 = load ptr, ptr %t871, !tbaa !29
  %t873 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t873, ptr %l459, !tbaa !27
  %t874 = load i64, ptr %l44, !tbaa !24
  %t876 = getelementptr { i64, ptr }, ptr %l459, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !27
  %t878 = getelementptr i32, ptr %t877, i64 %t874
  %t879 = load i32, ptr %t878, !tbaa !33
  %t882 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t872, i32 %t879)
  store { i64, ptr } %t882, ptr %l462
  br label %bb270
bb270:
  %t883 = load ptr, ptr %l456, !tbaa !29
  %t884 = load { i64, ptr }, ptr %l462, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t883, { i64, ptr } %t884)
  br label %bb271
bb271:
  %t885 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t885, ptr %l463, !tbaa !27
  %t886 = load i64, ptr %l44, !tbaa !24
  %t888 = getelementptr { i64, ptr }, ptr %l463, i32 0, i32 1
  %t889 = load ptr, ptr %t888, !tbaa !27
  %t890 = getelementptr i32, ptr %t889, i64 %t886
  %t891 = load i32, ptr %t890, !tbaa !33
  %t893 = icmp ne i32 %t891, 0
  br i1 %t893, label %bb272, label %bb273
bb272:
  %t895 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t895, i8 40)
  br label %bb274
bb273:
  br label %bb278
bb274:
  %t897 = load ptr, ptr %l0, !tbaa !29
  store ptr %t897, ptr %l468, !tbaa !29
  %t898 = load ptr, ptr %l1, !tbaa !29
  store ptr %t898, ptr %l469, !tbaa !29
  %t899 = load ptr, ptr %l0, !tbaa !29
  %t900 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t900, ptr %l471, !tbaa !27
  %t901 = load i64, ptr %l44, !tbaa !24
  %t903 = getelementptr { i64, ptr }, ptr %l471, i32 0, i32 1
  %t904 = load ptr, ptr %t903, !tbaa !27
  %t905 = getelementptr i32, ptr %t904, i64 %t901
  %t906 = load i32, ptr %t905, !tbaa !33
  %t909 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t899, i32 %t906)
  store i32 %t909, ptr %l474
  br label %bb275
bb275:
  %t910 = load ptr, ptr %l468, !tbaa !29
  %t911 = load ptr, ptr %l469, !tbaa !29
  %t912 = load i32, ptr %l474, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t910, ptr %t911, i32 %t912)
  br label %bb276
bb276:
  %t913 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t913, i8 41)
  br label %bb277
bb277:
  br label %bb278
bb278:
  call void @__olang_scope_close(ptr %s42)
  br label %bb279
bb279:
  %t915 = load i64, ptr %l43, !tbaa !24
  %t917 = add i64 %t915, 1
  store i64 %t917, ptr %l43, !tbaa !24
  br label %bb262
bb280:
  %t919 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t919, i8 125)
  br label %bb281
bb281:
  call void @__olang_scope_close(ptr %s40)
  br label %bb316
bb282:
  %t921 = load i32, ptr %l4
  %t923 = trunc i64 25 to i32
  %t924 = icmp eq i32 %t921, %t923
  br i1 %t924, label %bb283, label %bb284
bb283:
  br label %bb285
bb284:
  br label %bb287
bb285:
  store %olang.scope zeroinitializer, ptr %s46
  %t926 = load ptr, ptr %l1, !tbaa !29
  %t927 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 1
  %t928 = load i64, ptr %t927, !tbaa !24
  %t929 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t930 = load i64, ptr %t929, !tbaa !24
  %t931 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 1
  %t932 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 0
  %t934 = call i64 @__olang_fmt_i64(ptr null, i64 %t928)
  %t935 = add i64 %t932, %t934
  %t936 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t937 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t938 = add i64 %t935, %t937
  %t940 = call i64 @__olang_fmt_i64(ptr null, i64 %t930)
  %t941 = add i64 %t938, %t940
  %t942 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 1
  %t943 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 0
  %t944 = add i64 %t941, %t943
  %t945 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t944)
  call void @olang_textcopy(ptr %t945, ptr %t931, i64 %t932)
  %t946 = getelementptr i8, ptr %t945, i64 %t932
  %t947 = call i64 @__olang_fmt_i64(ptr %t946, i64 %t928)
  %t948 = getelementptr i8, ptr %t946, i64 %t934
  call void @olang_textcopy(ptr %t948, ptr %t936, i64 %t937)
  %t949 = getelementptr i8, ptr %t948, i64 %t937
  %t950 = call i64 @__olang_fmt_i64(ptr %t949, i64 %t930)
  %t951 = getelementptr i8, ptr %t949, i64 %t940
  call void @olang_textcopy(ptr %t951, ptr %t942, i64 %t943)
  %t952 = insertvalue { i64, ptr } undef, i64 %t944, 0
  %t953 = insertvalue { i64, ptr } %t952, ptr %t945, 1
  %t955 = extractvalue { i64, ptr } %t953, 0
  %t956 = extractvalue { i64, ptr } %t953, 1
  %t957 = mul i64 %t955, 1
  %t958 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t957)
  call void @llvm.memcpy.p0.p0.i64(ptr %t958, ptr %t956, i64 %t957, i1 false)
  %t959 = insertvalue { i64, ptr } undef, i64 %t955, 0
  %t960 = insertvalue { i64, ptr } %t959, ptr %t958, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s46, ptr %t926, { i64, ptr } %t960)
  br label %bb286
bb286:
  call void @__olang_scope_close(ptr %s46)
  br label %bb316
bb287:
  %t963 = load i32, ptr %l4
  %t965 = trunc i64 26 to i32
  %t966 = icmp eq i32 %t963, %t965
  br i1 %t966, label %bb288, label %bb289
bb288:
  br label %bb290
bb289:
  br label %bb309
bb290:
  %t968 = load ptr, ptr %l0, !tbaa !29
  %t969 = load i32, ptr %l2, !tbaa !23
  %t972 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t968, i32 %t969)
  store i32 %t972, ptr %l490
  br label %bb291
bb291:
  %t973 = load i32, ptr %l490, !tbaa !23
  store i32 %t973, ptr %l45, !tbaa !23
  %t974 = load i32, ptr %l45, !tbaa !23
  %t975 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t978 = icmp eq i32 %t974, %t975
  br i1 %t978, label %bb292, label %bb293
bb292:
  store %olang.scope zeroinitializer, ptr %s49
  %t980 = load ptr, ptr %l1, !tbaa !29
  store ptr %t980, ptr %l494, !tbaa !29
  %t981 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t982 = load i64, ptr %t981, !tbaa !24
  %t984 = icmp ne i64 %t982, 0
  br i1 %t984, label %bb294, label %bb295
bb293:
  %t986 = load ptr, ptr %l0, !tbaa !29
  %t987 = load i32, ptr %l45, !tbaa !23
  %t990 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t986, i32 %t987)
  store i1 %t990, ptr %l500
  br label %bb298
bb294:
  store { i64, ptr } { i64 4, ptr @.d62 }, ptr %l497, !tbaa !27
  br label %bb296
bb295:
  store { i64, ptr } { i64 5, ptr @.d63 }, ptr %l497, !tbaa !27
  br label %bb296
bb296:
  %t991 = load ptr, ptr %l494, !tbaa !29
  %t992 = load { i64, ptr }, ptr %l497, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s49, ptr %t991, { i64, ptr } %t992)
  br label %bb297
bb297:
  call void @__olang_scope_close(ptr %s49)
  br label %bb308
bb298:
  %t993 = load i1, ptr %l500, !tbaa !21
  br i1 %t993, label %bb299, label %bb300
bb299:
  %t994 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t995 = load i64, ptr %t994, !tbaa !24
  %t997 = icmp slt i64 %t995, 0
  store i1 %t997, ptr %l501, !tbaa !21
  br label %bb301
bb300:
  store i1 false, ptr %l501, !tbaa !21
  br label %bb301
bb301:
  %t999 = load i1, ptr %l501, !tbaa !21
  br i1 %t999, label %bb302, label %bb303
bb302:
  store %olang.scope zeroinitializer, ptr %s51
  %t1000 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1000, ptr %l504, !tbaa !29
  %t1001 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1002 = load i64, ptr %t1001, !tbaa !24
  %t1004 = call { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %s51, i64 %t1002)
  store { i64, ptr } %t1004, ptr %l506
  br label %bb304
bb303:
  store %olang.scope zeroinitializer, ptr %s52
  %t1005 = load ptr, ptr %l1, !tbaa !29
  %t1006 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1007 = load i64, ptr %t1006, !tbaa !24
  %t1009 = call i64 @__olang_fmt_i64(ptr null, i64 %t1007)
  %t1010 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1009)
  %t1011 = call i64 @__olang_fmt_i64(ptr %t1010, i64 %t1007)
  %t1012 = insertvalue { i64, ptr } undef, i64 %t1009, 0
  %t1013 = insertvalue { i64, ptr } %t1012, ptr %t1010, 1
  %t1015 = extractvalue { i64, ptr } %t1013, 0
  %t1016 = extractvalue { i64, ptr } %t1013, 1
  %t1017 = mul i64 %t1015, 1
  %t1018 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1017)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1018, ptr %t1016, i64 %t1017, i1 false)
  %t1019 = insertvalue { i64, ptr } undef, i64 %t1015, 0
  %t1020 = insertvalue { i64, ptr } %t1019, ptr %t1018, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s52, ptr %t1005, { i64, ptr } %t1020)
  br label %bb306
bb304:
  %t1023 = load { i64, ptr }, ptr %l506, !tbaa !27
  %t1024 = extractvalue { i64, ptr } %t1023, 0
  %t1025 = extractvalue { i64, ptr } %t1023, 1
  %t1026 = mul i64 %t1024, 1
  %t1027 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1026)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1027, ptr %t1025, i64 %t1026, i1 false)
  %t1028 = insertvalue { i64, ptr } undef, i64 %t1024, 0
  %t1029 = insertvalue { i64, ptr } %t1028, ptr %t1027, 1
  %t1030 = load ptr, ptr %l504, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s51, ptr %t1030, { i64, ptr } %t1029)
  br label %bb305
bb305:
  call void @__olang_scope_close(ptr %s51)
  br label %bb307
bb306:
  call void @__olang_scope_close(ptr %s52)
  br label %bb307
bb307:
  br label %bb308
bb308:
  br label %bb316
bb309:
  %t1032 = load i32, ptr %l4
  %t1034 = trunc i64 27 to i32
  %t1035 = icmp eq i32 %t1032, %t1034
  br i1 %t1035, label %bb310, label %bb311
bb310:
  br label %bb312
bb311:
  br label %bb315
bb312:
  store %olang.scope zeroinitializer, ptr %s54
  %t1037 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1037, ptr %l514, !tbaa !29
  %t1038 = load ptr, ptr %l0, !tbaa !29
  %t1039 = load i32, ptr %l2, !tbaa !23
  %t1042 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %t1038, i32 %t1039)
  store { i64, ptr } %t1042, ptr %l517
  br label %bb313
bb313:
  %t1043 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 1
  %t1044 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 0
  %t1045 = load { i64, ptr }, ptr %l517, !tbaa !27
  %t1046 = extractvalue { i64, ptr } %t1045, 1
  %t1047 = extractvalue { i64, ptr } %t1045, 0
  %t1048 = add i64 %t1044, %t1047
  %t1049 = extractvalue { i64, ptr } { i64 1, ptr @.d65 }, 1
  %t1050 = extractvalue { i64, ptr } { i64 1, ptr @.d65 }, 0
  %t1051 = add i64 %t1048, %t1050
  %t1052 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1051)
  call void @olang_textcopy(ptr %t1052, ptr %t1043, i64 %t1044)
  %t1053 = getelementptr i8, ptr %t1052, i64 %t1044
  call void @olang_textcopy(ptr %t1053, ptr %t1046, i64 %t1047)
  %t1054 = getelementptr i8, ptr %t1053, i64 %t1047
  call void @olang_textcopy(ptr %t1054, ptr %t1049, i64 %t1050)
  %t1055 = insertvalue { i64, ptr } undef, i64 %t1051, 0
  %t1056 = insertvalue { i64, ptr } %t1055, ptr %t1052, 1
  %t1058 = extractvalue { i64, ptr } %t1056, 0
  %t1059 = extractvalue { i64, ptr } %t1056, 1
  %t1060 = mul i64 %t1058, 1
  %t1061 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1060)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1061, ptr %t1059, i64 %t1060, i1 false)
  %t1062 = insertvalue { i64, ptr } undef, i64 %t1058, 0
  %t1063 = insertvalue { i64, ptr } %t1062, ptr %t1061, 1
  %t1064 = load ptr, ptr %l514, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s54, ptr %t1064, { i64, ptr } %t1063)
  br label %bb314
bb314:
  call void @__olang_scope_close(ptr %s54)
  br label %bb316
bb315:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb316:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l5, !tbaa !23
  %t27 = load i32, ptr %l5, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i32
  %l28 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 5
  %t6 = sext i32 %a1 to i64
  %t9 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store { i64, ptr } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l18, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  store i32 %t29, ptr %l6, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load i32, ptr %l2, !tbaa !23
  %t37 = load i32, ptr %l23, !tbaa !23
  %t39 = icmp sgt i32 %t37, %t36
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l28
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t46 = load i32, ptr %l28, !tbaa !23
  store i32 %t46, ptr %l2, !tbaa !23
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb2
bb12:
  %t51 = load i32, ptr %l2, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 4
  %t6 = sext i32 %a1 to i64
  %t9 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t3, i64 %t6)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 3, ptr @.d67 }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l12
  br label %bb5
bb5:
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = sdiv i64 %t30, 8
  %t32 = extractvalue { i64, ptr } { i64 8, ptr @.d68 }, 1
  %t33 = extractvalue { i64, ptr } { i64 8, ptr @.d68 }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d69 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d69 }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t32, i64 %t33)
  %t41 = getelementptr i8, ptr %t40, i64 %t33
  %t42 = call i64 @__olang_fmt_i64(ptr %t41, i64 %t31)
  %t43 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l18 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 18 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load i32, ptr %l11, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  br label %bb18
bb6:
  %t18 = load i32, ptr %l2
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t23 = load i32, ptr %l2
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l18
  br label %bb12
bb12:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i32 0, ptr %l6, !tbaa !23
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb18:
  %t34 = load i32, ptr %l6, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i8 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsState(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i8
  %l14 = alloca i8
  %rv = alloca i8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 30
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/types:Table", ptr %t15, i32 0, i32 30
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t17, i64 %t18)
  store i8 %t21, ptr %l14
  br label %bb4
bb3:
  store i8 0, ptr %l10, !tbaa !22
  br label %bb5
bb4:
  %t22 = load i8, ptr %l14, !tbaa !22
  store i8 %t22, ptr %l10, !tbaa !22
  br label %bb5
bb5:
  %t23 = load i8, ptr %l10, !tbaa !22
  store i8 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l15 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/types:data" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 2
  %t4 = load %"compiler/types:data", ptr %l1
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %t3, %"compiler/types:data" %t4)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i32, ptr %l8, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i32 -1, ptr %l4, !tbaa !23
  br label %bb4
bb4:
  %t13 = load i32, ptr %l4, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t16 = icmp sge i32 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i32, ptr %l3, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 1
  %t24 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = trunc i64 %t25 to i32
  store i32 %t26, ptr %l3, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/types:Table", ptr %t29, i32 0, i32 1
  %t32 = load %"compiler/types:data", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t31, %"compiler/types:data" %t32)
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/types:Table", ptr %t35, i32 0, i32 2
  %t38 = load %"compiler/types:data", ptr %l1
  %t39 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %t37, %"compiler/types:data" %t38, i32 %t39)
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/types:Table", ptr %t43, i32 0, i32 4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t45, i32 %a2)
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/types:Table", ptr %t49, i32 0, i32 18
  %t52 = load i64, ptr @G_2ecompiler_2ftypes_2eNotLaidOut, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t51, i64 %t52)
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/types:Table", ptr %t55, i32 0, i32 19
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t57, i64 0)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t59, i32 0, i32 20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t61, i64 1)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/types:Table", ptr %t63, i32 0, i32 21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 -1)
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/types:Table", ptr %t67, i32 0, i32 23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t69, i64 -1)
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t73, { i64, ptr } { i64 0, ptr @.d71 })
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/types:Table", ptr %t75, i32 0, i32 25
  %t78 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t77, i32 %t78)
  br label %bb18
bb18:
  %t81 = load i32, ptr %l3, !tbaa !23
  store i32 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca i64
  %l44 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %a2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t61, { i64, ptr } { i64 2, ptr @.d72 })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t65, ptr %l44, !tbaa !27
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 %t66
  %t71 = load i32, ptr %t70, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t71)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb8
bb18:
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l11 = alloca i1
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca i64
  %l36 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = insertvalue { i64, i64 } undef, i64 4, 0
  %t10 = insertvalue { i64, i64 } %t9, i64 4, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l16
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t31
  %t36 = load i32, ptr %t35, !tbaa !33
  store i32 %t36, ptr %l7, !tbaa !23
  %t38 = load i32, ptr %l7, !tbaa !23
  %t40 = icmp ne i32 %t38, 0
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l7, !tbaa !23
  %t46 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l31, !tbaa !24
  %t50 = icmp sgt i64 %t48, %t47
  store i1 %t50, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l7, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t57, ptr %l36
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t58 = load i64, ptr %l36, !tbaa !24
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb6
bb19:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 7
  %t67 = sdiv i64 %t65, 8
  %t69 = mul i64 %t67, 8
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 23
  %t76 = sext i32 %a1 to i64
  %t77 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t76, i64 %t77)
  br label %bb20
bb20:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t83 = add i64 8, %t81
  %t85 = insertvalue { i64, i64 } undef, i64 %t83, 0
  %t86 = insertvalue { i64, i64 } %t85, i64 8, 1
  store { i64, i64 } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l31 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 21
  store ptr %t3, ptr %l11, !tbaa !29
  %t6 = sext i32 %a1 to i64
  store i64 %t6, ptr %l13, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/types:Table", ptr %t7, i32 0, i32 22
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13, i64 %t14)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t15, i32 %a2)
  store { i64, ptr } %t19, ptr %l19
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  store i32 %t39, ptr %l8, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l8, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l31
  br label %bb8
bb8:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load i64, ptr %l9, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = mul i64 %t65, %t66
  store i64 %t69, ptr %l3, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 22
  %t74 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t73, i64 %t74)
  br label %bb12
bb12:
  %t77 = load i64, ptr %l3, !tbaa !24
  store i64 %t77, ptr %l47, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l8, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l50
  br label %bb13
bb13:
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = add i64 %t83, %t84
  store i64 %t85, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l6, !tbaa !24
  br label %bb4
bb15:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t92 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l4, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t106 = load i64, ptr %l4, !tbaa !24
  %t108 = insertvalue { i64, i64 } undef, i64 %t105, 0
  %t110 = insertvalue { i64, i64 } %t108, i64 %t106, 1
  store { i64, i64 } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l26 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l6, !tbaa !23
  %t29 = icmp eq i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t33 = xor i1 %a2, true
  br i1 %t33, label %bb8, label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l26
  br label %bb11
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/types:Table", ptr %t40, i32 0, i32 31
  store i1 true, ptr %t42, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb2
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7
  store i32 %t10, ptr %l2
  %t11 = load i32, ptr %l2
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2estructName(ptr %v0, ptr %v1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  br label %bb27
bb7:
  %t22 = load i32, ptr %l2
  %t24 = trunc i64 1 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l18
  br label %bb11
bb11:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l8, !tbaa !27
  br label %bb27
bb12:
  %t33 = load i32, ptr %l2
  %t35 = trunc i64 2 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr @.d73 }, ptr %l21, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  br label %bb27
bb16:
  %t40 = load i32, ptr %l2
  %t42 = trunc i64 4 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l25, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l28
  br label %bb20
bb20:
  %t51 = load ptr, ptr %l25, !tbaa !29
  %t52 = load i32, ptr %l28, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t51, i32 %t52)
  store { i64, ptr } %t53, ptr %l29
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l8, !tbaa !27
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 1, ptr @.d74 }, ptr %l31, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l8, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c75)
  unreachable
bb27:
  %t63 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l33, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l34, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l33, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t76, ptr %l8, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  store i32 19, ptr %l10
  %t14 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l8, ptr %l10)
  store i1 %t14, ptr %l12
  br label %bb3
bb3:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t21 = load i32, ptr %l16, !tbaa !23
  %t22 = icmp eq i32 %t21, 0
  store i1 %t22, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %a0, i32 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/types:Table", ptr %t5, i32 0, i32 30
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sle i64 %t11, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t19, i8 0)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb1
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/types:Table", ptr %t21, i32 0, i32 30
  %t24 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %t23, i64 %t24, i8 %a2)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l8 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  %t15 = load i32, ptr %l3
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  %t20 = load i32, ptr %l3
  %t22 = trunc i64 3 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb30
bb7:
  %t25 = load i32, ptr %l3
  %t27 = trunc i64 4 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb30
bb9:
  %t30 = load i32, ptr %l3
  %t32 = trunc i64 5 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %bb30
bb11:
  %t35 = load i32, ptr %l3
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb12, label %bb13
bb12:
  br label %bb30
bb13:
  %t40 = load i32, ptr %l3
  %t42 = trunc i64 7 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb30
bb15:
  %t45 = load i32, ptr %l3
  %t47 = trunc i64 8 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb16, label %bb17
bb16:
  br label %bb30
bb17:
  %t50 = load i32, ptr %l3
  %t52 = trunc i64 9 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb18, label %bb19
bb18:
  br label %bb30
bb19:
  %t55 = load i32, ptr %l3
  %t57 = trunc i64 10 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb20, label %bb21
bb20:
  br label %bb30
bb21:
  %t60 = load i32, ptr %l3
  %t62 = trunc i64 11 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  %t65 = load i32, ptr %l3
  %t67 = trunc i64 12 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  %t70 = load i32, ptr %l3
  %t72 = trunc i64 13 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t75 = load i32, ptr %l3
  %t77 = trunc i64 14 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t80 = load i32, ptr %l1, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t84 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimLlvm, i64 0, i64 %t82
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !37
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t87, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l8, !tbaa !27
  br label %bb80
bb31:
  %t93 = load i32, ptr %l3
  %t95 = trunc i64 16 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr @.d76 }, ptr %l43, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t98, ptr %l8, !tbaa !27
  br label %bb80
bb35:
  %t100 = load i32, ptr %l3
  %t102 = trunc i64 17 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr @.d77 }, ptr %l47, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l8, !tbaa !27
  br label %bb80
bb39:
  %t107 = load i32, ptr %l3
  %t109 = trunc i64 21 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store { i64, ptr } { i64 12, ptr @.d78 }, ptr %l51, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t112, ptr %l8, !tbaa !27
  br label %bb80
bb43:
  %t114 = load i32, ptr %l3
  %t116 = trunc i64 20 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb52
bb46:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l55, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l1, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l58
  br label %bb47
bb47:
  %t125 = load ptr, ptr %l55, !tbaa !29
  %t126 = load i32, ptr %l58, !tbaa !23
  %t127 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t127, ptr %l59
  br label %bb48
bb48:
  %t128 = load i1, ptr %l59, !tbaa !21
  br i1 %t128, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 12, ptr @.d79 }, ptr %l61, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t129, ptr %l60, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 3, ptr @.d80 }, ptr %l63, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t131, ptr %l60, !tbaa !27
  br label %bb51
bb51:
  %t133 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t133, ptr %l8, !tbaa !27
  br label %bb80
bb52:
  %t134 = load i32, ptr %l3
  %t136 = trunc i64 19 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l1, !tbaa !23
  %t143 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %t139, i32 %t140)
  store { i64, ptr } %t143, ptr %l69
  br label %bb56
bb56:
  %t144 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  br label %bb80
bb57:
  %t145 = load i32, ptr %l3
  %t147 = trunc i64 22 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb58, label %bb59
bb58:
  br label %bb62
bb59:
  %t150 = load i32, ptr %l3
  %t152 = trunc i64 23 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l74, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l1, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l77
  br label %bb63
bb63:
  %t161 = load ptr, ptr %l74, !tbaa !29
  %t162 = load i32, ptr %l77, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %t161, i32 %t162)
  store { i64, ptr } %t163, ptr %l78
  br label %bb64
bb64:
  %t164 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t164, ptr %l8, !tbaa !27
  br label %bb80
bb65:
  %t165 = load i32, ptr %l3
  %t167 = trunc i64 24 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l1, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t170, i32 %t171)
  store { i64, ptr } %t174, ptr %l83
  br label %bb69
bb69:
  %t175 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t175, ptr %l8, !tbaa !27
  br label %bb80
bb70:
  %t176 = load i32, ptr %l3
  %t178 = trunc i64 18 to i32
  %t179 = icmp eq i32 %t176, %t178
  br i1 %t179, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l1, !tbaa !23
  %t185 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %t181, i32 %t182)
  store { i64, ptr } %t185, ptr %l88
  br label %bb74
bb74:
  %t186 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t186, ptr %l8, !tbaa !27
  br label %bb80
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  store { i64, ptr } { i64 1, ptr @.d81 }, ptr %l89, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t187, ptr %l8, !tbaa !27
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb80:
  %t189 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l91, !tbaa !24
  %t191 = load i64, ptr %l91, !tbaa !24
  %t192 = mul i64 %t191, 1
  %t193 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l92, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l91, !tbaa !24
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  %t202 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t202, ptr %l8, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t203, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2estructName(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i32
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, i64 }
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  %t13 = icmp eq i32 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d83 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d83 }, 0
  %t19 = extractvalue { i64, ptr } %t15, 1
  %t20 = extractvalue { i64, ptr } %t15, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 0
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t16, i64 %t17)
  %t26 = getelementptr i8, ptr %t25, i64 %t17
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = getelementptr i8, ptr %t26, i64 %t20
  call void @olang_textcopy(ptr %t27, ptr %t22, i64 %t23)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t25, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr @.d85 })
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l19
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37
ok.37:
  store i64 %t34, ptr %l18
  br label %bb6
bb6:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l16, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l16, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l16, !tbaa !24
  store i64 %t43, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %s0, ptr %t44, i32 %t45)
  store { i64, ptr } %t48, ptr %l24
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t57 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %s0, { i64, ptr } %t55)
  store { i64, i64 } %t57, ptr %l26
  br label %bb11
bb11:
  %t58 = load { i64, i64 }, ptr %l26
  store { i64, i64 } %t58, ptr %l4
  %t59 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 0
  %t60 = load i64, ptr %t59, !tbaa !65
  store i64 %t60, ptr %l5, !tbaa !65
  %t62 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !65
  store i64 %t63, ptr %l6, !tbaa !65
  %t65 = load i64, ptr %l3, !tbaa !24
  store i64 %t65, ptr %l29, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l30, !tbaa !24
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load i64, ptr %l29, !tbaa !24
  %t71 = icmp sle i64 0, %t70
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c86)
  unreachable
bb14:
  %t73 = load i64, ptr %l29, !tbaa !24
  %t74 = load i64, ptr %l30, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c86)
  unreachable
bb16:
  %t77 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l29, !tbaa !24
  %t80 = getelementptr i8, ptr %t78, i64 0
  %t81 = sub i64 %t79, 0
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  store { i64, ptr } %t83, ptr %l34, !tbaa !27
  %t84 = load i64, ptr %l5, !tbaa !65
  %t86 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t84)
  store { i64, ptr } %t86, ptr %l36
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @.c86)
  unreachable
bb18:
  %t87 = load i64, ptr %l6, !tbaa !65
  %t89 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t87)
  store { i64, ptr } %t89, ptr %l38
  br label %bb19
bb19:
  %t90 = extractvalue { i64, ptr } { i64 2, ptr @.d87 }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr @.d87 }, 0
  %t92 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 0
  %t98 = add i64 %t95, %t97
  %t99 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = add i64 %t98, %t101
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 1, ptr @.d89 }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr @.d89 }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t90, i64 %t91)
  %t111 = getelementptr i8, ptr %t110, i64 %t91
  call void @olang_textcopy(ptr %t111, ptr %t93, i64 %t94)
  %t112 = getelementptr i8, ptr %t111, i64 %t94
  call void @olang_textcopy(ptr %t112, ptr %t96, i64 %t97)
  %t113 = getelementptr i8, ptr %t112, i64 %t97
  call void @olang_textcopy(ptr %t113, ptr %t100, i64 %t101)
  %t114 = getelementptr i8, ptr %t113, i64 %t101
  call void @olang_textcopy(ptr %t114, ptr %t104, i64 %t105)
  %t115 = getelementptr i8, ptr %t114, i64 %t105
  call void @olang_textcopy(ptr %t115, ptr %t107, i64 %t108)
  %t116 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t110, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l52 = alloca i1
  %l55 = alloca { i64, ptr }
  %l62 = alloca i32
  %l66 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sle i64 %t13, 2305843009213693951
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c90)
  unreachable
bb4:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = mul i64 %t16, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store i1 true, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c90)
  unreachable
bb6:
  %t32 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l27, !tbaa !24
  store i64 %t52, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l24, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l45, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t74, ptr %l47, !tbaa !27
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t75
  %t80 = load i32, ptr %t79, !tbaa !33
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t73, i32 %t80)
  store i32 %t83, ptr %l50
  br label %bb16
bb16:
  %t84 = load i32, ptr %l50, !tbaa !23
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i32, ptr %t87, i64 %t85
  store i32 %t84, ptr %t88, !tbaa !33
  %t89 = load i1, ptr %l4, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t91 = load i64, ptr %l10, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t91
  %t96 = load i32, ptr %t95, !tbaa !33
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  %t106 = icmp eq i32 %t96, %t103
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb19
bb19:
  %t108 = load i1, ptr %l52, !tbaa !21
  store i1 %t108, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t109 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  %t113 = load i1, ptr %l4, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t115 = load i32, ptr %l1, !tbaa !23
  store i32 %t115, ptr %l62, !tbaa !23
  br label %bb25
bb23:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t117, { i64, ptr } %t118)
  store i32 %t121, ptr %l66
  br label %bb24
bb24:
  %t122 = load i32, ptr %l66, !tbaa !23
  store i32 %t122, ptr %l62, !tbaa !23
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i32, ptr %l62, !tbaa !23
  store i32 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store i64 -3750763034362895579, ptr %l1, !tbaa !65
  store i64 7809847782465536322, ptr %l2, !tbaa !65
  store i64 1099511628211, ptr %l3, !tbaa !65
  store { i64, ptr } %a0, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l7, !tbaa !22
  %t23 = load i64, ptr %l1, !tbaa !65
  %t24 = load i8, ptr %l7, !tbaa !22
  %t27 = zext i8 %t24 to i64
  %t30 = xor i64 %t23, %t27
  %t31 = load i64, ptr %l3, !tbaa !65
  %t34 = mul i64 %t30, %t31
  store i64 %t34, ptr %l1, !tbaa !65
  %t36 = load i64, ptr %l2, !tbaa !65
  %t37 = load i8, ptr %l7, !tbaa !22
  %t40 = zext i8 %t37 to i64
  %t43 = xor i64 %t36, %t40
  %t44 = load i64, ptr %l3, !tbaa !65
  %t47 = mul i64 %t43, %t44
  store i64 %t47, ptr %l2, !tbaa !65
  %t49 = load i64, ptr %l2, !tbaa !65
  %t50 = load i64, ptr %l2, !tbaa !65
  %t52 = lshr i64 %t50, 29
  %t55 = xor i64 %t49, %t52
  store i64 %t55, ptr %l2, !tbaa !65
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb1
bb6:
  %t61 = load i64, ptr %l1, !tbaa !65
  %t62 = load i64, ptr %l2, !tbaa !65
  %t64 = insertvalue { i64, i64 } undef, i64 %t61, 0
  %t66 = insertvalue { i64, i64 } %t64, i64 %t62, 1
  store { i64, i64 } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex16(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l1, !tbaa !65
  %t2 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t3 = extractvalue { i32, i64 } %t2, 1
  %t4 = extractvalue { i32, i64 } %t2, 0
  store i32 %t4, ptr %l3
  %t5 = icmp ne i32 %t4, 0
  br i1 %t5, label %bb2, label %ok.6
ok.6:
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  %t7 = load i64, ptr %l1, !tbaa !65
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t7, i64 %t8)
  store { i64, ptr } %t9, ptr %l4
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb3:
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  %t18 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t16, i64 16, i8 48)
  store { i64, ptr } %t18, ptr %l6
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex2(ptr %v0, i8 %a0) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = zext i8 %a0 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c92)
  unreachable
bb3:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t18, i64 2, i8 48)
  store { i64, ptr } %t20, ptr %l7
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eprimBits_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [15 x i64] undef, i64 0, 0
  %t2 = insertvalue [15 x i64] %t1, i64 0, 1
  %t3 = insertvalue [15 x i64] %t2, i64 1, 2
  %t4 = insertvalue [15 x i64] %t3, i64 8, 3
  %t5 = insertvalue [15 x i64] %t4, i64 16, 4
  %t6 = insertvalue [15 x i64] %t5, i64 32, 5
  %t7 = insertvalue [15 x i64] %t6, i64 64, 6
  %t8 = insertvalue [15 x i64] %t7, i64 8, 7
  %t9 = insertvalue [15 x i64] %t8, i64 16, 8
  %t10 = insertvalue [15 x i64] %t9, i64 32, 9
  %t11 = insertvalue [15 x i64] %t10, i64 64, 10
  %t12 = insertvalue [15 x i64] %t11, i64 16, 11
  %t13 = insertvalue [15 x i64] %t12, i64 16, 12
  %t14 = insertvalue [15 x i64] %t13, i64 32, 13
  %t15 = insertvalue [15 x i64] %t14, i64 64, 14
  store [15 x i64] %t15, ptr @G_2ecompiler_2ftypes_2eprimBits
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eprimLlvm_2einit() #0 {
entry:
  %l0 = alloca [15 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr @.d93 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 4, ptr @.d94 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 2, ptr @.d95 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr @.d96 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr @.d97 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr @.d98 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr @.d99 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr @.d100 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr @.d101 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr @.d102 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr @.d103 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 4, ptr @.d104 }, ptr %t12, !tbaa !37
  %t13 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 6, ptr @.d105 }, ptr %t13, !tbaa !37
  %t14 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 5, ptr @.d106 }, ptr %t14, !tbaa !37
  %t15 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 6, ptr @.d107 }, ptr %t15, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ftypes_2eprimLlvm, ptr %l0, i64 240, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eprimNames_2einit() #0 {
entry:
  %l0 = alloca [15 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr @.d108 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 0, ptr @.d109 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 4, ptr @.d110 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr @.d111 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr @.d112 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr @.d113 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr @.d114 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr @.d115 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr @.d116 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr @.d117 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr @.d118 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr @.d119 }, ptr %t12, !tbaa !37
  %t13 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr @.d120 }, ptr %t13, !tbaa !37
  %t14 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 3, ptr @.d121 }, ptr %t14, !tbaa !37
  %t15 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 3, ptr @.d122 }, ptr %t15, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ftypes_2eprimNames, ptr %l0, i64 240, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_3aTable_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca %"compiler/types:Table"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l34
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %t6)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l35
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l36
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l5
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e(ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l37
  br label %bb4
bb4:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l6
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeI_He375cb5a1de17a5d01c6b8903f9691e1(ptr %t15)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l38
  br label %bb5
bb5:
  %t17 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l7
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l39
  br label %bb6
bb6:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l8
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e(ptr %t21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l40
  br label %bb7
bb7:
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l9
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l41
  br label %bb8
bb8:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l10
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t27)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l42
  br label %bb9
bb9:
  %t29 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l11
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l43
  br label %bb10
bb10:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l12
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t33)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l44
  br label %bb11
bb11:
  %t35 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l13
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e(ptr %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l45
  br label %bb12
bb12:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l14
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l46
  br label %bb13
bb13:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l15
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He0d7a5bfd18ae956abf945564c24098c(ptr %t42)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l47
  br label %bb14
bb14:
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l16
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %t45)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l48
  br label %bb15
bb15:
  %t47 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l17
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20A_Hcfba385079b3349cc13047539d410cc3(ptr %t48)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l49
  br label %bb16
bb16:
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l18
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t51)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l50
  br label %bb17
bb17:
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l19
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l51
  br label %bb18
bb18:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l20
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t57)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l52
  br label %bb19
bb19:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l21
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t60)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l53
  br label %bb20
bb20:
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l22
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t63)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l54
  br label %bb21
bb21:
  %t65 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l23
  %t66 = load ptr, ptr @__olang_prog_scope
  %t67 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t66)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l55
  br label %bb22
bb22:
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l24
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t69)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l56
  br label %bb23
bb23:
  %t71 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l25
  %t72 = load ptr, ptr @__olang_prog_scope
  %t73 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t72)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l57
  br label %bb24
bb24:
  %t74 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l26
  %t75 = load ptr, ptr @__olang_prog_scope
  %t76 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t75)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l58
  br label %bb25
bb25:
  %t77 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l27
  %t78 = load ptr, ptr @__olang_prog_scope
  %t79 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %t78)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l59
  br label %bb26
bb26:
  %t80 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l28
  %t81 = load ptr, ptr @__olang_prog_scope
  %t82 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t81)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l60
  br label %bb27
bb27:
  %t83 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l29
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %t84)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l61
  br label %bb28
bb28:
  %t86 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l30
  %t87 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l62
  br label %bb29
bb29:
  %t88 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  %t89 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 0
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %t89, !tbaa !29
  %t91 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 1
  %t92 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %t91
  %t93 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 2
  %t94 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %t93
  %t95 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 3
  %t96 = load i1, ptr %l4, !tbaa !21
  store i1 %t96, ptr %t95, !tbaa !21
  %t97 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 4
  %t98 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %t97
  %t99 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 5
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t99
  %t101 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 6
  %t102 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %t101
  %t103 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 7
  %t104 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %t103
  %t105 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 8
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %t105
  %t107 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 9
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %t107
  %t109 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 10
  %t110 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t109
  %t111 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 11
  %t112 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %t111
  %t113 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 12
  %t114 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %t113
  %t115 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 13
  %t116 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t115
  %t117 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 14
  %t118 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %t117
  %t119 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 15
  %t120 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %t119
  %t121 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 16
  %t122 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %t121
  %t123 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 17
  %t124 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t123
  %t125 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 18
  %t126 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %t125
  %t127 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 19
  %t128 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %t127
  %t129 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 20
  %t130 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t130, ptr %t129
  %t131 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 21
  %t132 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %t131
  %t133 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 22
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %t133
  %t135 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 23
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %t135
  %t137 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 24
  %t138 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %t137
  %t139 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 25
  %t140 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %t139
  %t141 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 26
  %t142 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %t141
  %t143 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 27
  %t144 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t143
  %t145 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 28
  %t146 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %t145
  %t147 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 29
  %t148 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %t147
  %t149 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 30
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %t149
  %t151 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 31
  store i1 false, ptr %t151, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l63, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/types:body"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/types:body" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/types:body" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/types:body" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/types:body" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/types:body" %t18, i1 %a4, 4
  store %"compiler/types:body" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:body", ptr %rv
  ret %"compiler/types:body" %rr
}

define dso_local %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5) #0 {
entry:
  %rv = alloca %"compiler/types:data"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/types:data" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/types:data" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/types:data" %t16, i64 %a2, 2
  %t20 = insertvalue %"compiler/types:data" %t18, i64 %a3, 3
  %t22 = insertvalue %"compiler/types:data" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/types:data" %t22, i64 %a5, 5
  store %"compiler/types:data" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local %"compiler/types:decl" @compiler_2ftypes_3adecl_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/types:decl"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/types:decl" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/types:decl" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/types:decl" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/types:decl" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/types:decl" %t18, i64 %a4, 4
  store %"compiler/types:decl" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:decl", ptr %rv
  ret %"compiler/types:decl" %rr
}

define dso_local void @olang_2einit_2ecompiler_2ftypes() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftypes_2eReadOnly_2einit()
  br label %bb1
bb1:
  call void @compiler_2ftypes_2eWritable_2einit()
  br label %bb2
bb2:
  call void @compiler_2ftypes_2eOwning_2einit()
  br label %bb3
bb3:
  call void @compiler_2ftypes_2eRoleFn_2einit()
  br label %bb4
bb4:
  call void @compiler_2ftypes_2eRoleCtor_2einit()
  br label %bb5
bb5:
  call void @compiler_2ftypes_2eRoleDtor_2einit()
  br label %bb6
bb6:
  call void @compiler_2ftypes_2eOwnScope_2einit()
  br label %bb7
bb7:
  call void @compiler_2ftypes_2eFromTypeVar_2einit()
  br label %bb8
bb8:
  call void @compiler_2ftypes_2eResultVar_2einit()
  br label %bb9
bb9:
  call void @compiler_2ftypes_2eClosingVar_2einit()
  br label %bb10
bb10:
  call void @compiler_2ftypes_2eNotLaidOut_2einit()
  br label %bb11
bb11:
  call void @compiler_2ftypes_2eLayingOut_2einit()
  br label %bb12
bb12:
  call void @compiler_2ftypes_2eLaidOut_2einit()
  br label %bb13
bb13:
  call void @compiler_2ftypes_2eNoLayout_2einit()
  br label %bb14
bb14:
  call void @compiler_2ftypes_2eUnknownT_2einit()
  br label %bb15
bb15:
  call void @compiler_2ftypes_2eVoidT_2einit()
  br label %bb16
bb16:
  call void @compiler_2ftypes_2eBoolT_2einit()
  br label %bb17
bb17:
  call void @compiler_2ftypes_2eNullT_2einit()
  br label %bb18
bb18:
  call void @compiler_2ftypes_2eDefaultErrT_2einit()
  br label %bb19
bb19:
  call void @compiler_2ftypes_2eNoreturnT_2einit()
  br label %bb20
bb20:
  call void @compiler_2ftypes_2eprimNames_2einit()
  br label %bb21
bb21:
  call void @compiler_2ftypes_2eprimLlvm_2einit()
  br label %bb22
bb22:
  call void @compiler_2ftypes_2eprimBits_2einit()
  br label %bb23
bb23:
  call void @compiler_2ftypes_2eBigAggregate_2einit()
  br label %bb24
bb24:
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:188: array length out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.c1 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:189: array length out of range\0A\00"
@.c2 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:190: array length out of range\0A\00"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant [2 x i8] c"__"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.c4 = private unnamed_addr constant [54 x i8] c"compiler/types.olang:1217: slice bounds out of range\0A\00"
@.d5 = private constant [2 x i8] c"_H"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.c6 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:331: reached unreachable code\0A\00"
@.d7 = private constant [1 x i8] c":"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d8 = private constant [1 x i8] c","
@.d9 = private constant [1 x i8] c":"
@.c10 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:381: array length out of range\0A\00"
@.c11 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:386: array length out of range\0A\00"
@.c12 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:390: array length out of range\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c13 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:913: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c14 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:470: reached unreachable code\0A\00"
@.c15 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:858: reached unreachable code\0A\00"
@.c16 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:824: reached unreachable code\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c17 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:263: array length out of range\0A\00"
@.d18 = private constant [0 x i8] c""
@.c19 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:758: array length out of range\0A\00"
@.c20 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:309: array length out of range\0A\00"
@.c21 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:548: array length out of range\0A\00"
@.c22 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:530: array length out of range\0A\00"
@.c23 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:533: array length out of range\0A\00"
@.d24 = private constant [3 x i8] c"i32"
@.d25 = private constant [4 x i8] c"void"
@.d26 = private constant [3 x i8] c"i32"
@.d27 = private constant [7 x i8] c"{ i32, "
@.d28 = private constant [2 x i8] c" }"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c29 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:499: array length out of range\0A\00"
@.c30 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:719: array length out of range\0A\00"
@.d31 = private constant [3 x i8] c"{ }"
@.d32 = private constant [2 x i8] c"{ "
@.d33 = private constant [2 x i8] c", "
@.d34 = private constant [2 x i8] c" }"
@.d35 = private constant [12 x i8] c"{ i64, ptr }"
@.d36 = private constant [1 x i8] c"["
@.d37 = private constant [3 x i8] c" x "
@.d38 = private constant [1 x i8] c"]"
@.d39 = private constant [1 x i8] c"?"
@.d40 = private constant [4 x i8] c"null"
@.d41 = private constant [7 x i8] c"default"
@.d42 = private constant [8 x i8] c"noreturn"
@.d43 = private constant [2 x i8] c".#"
declare i64 @__olang_fmt_u64(ptr, i64)
@.d44 = private constant [4 x i8] c"void"
@.d45 = private constant [2 x i8] c", "
@.d46 = private constant [6 x i8] c"Array<"
@.d47 = private constant [2 x i8] c", "
@.d48 = private constant [4 x i8] c"own "
@.d49 = private constant [4 x i8] c"mut "
@.d50 = private constant [3 x i8] c"fn("
@.d51 = private constant [2 x i8] c" ("
@.d52 = private constant [1 x i8] c" "
@.d53 = private constant [2 x i8] c" ?"
@.d54 = private constant [3 x i8] c" + "
@.d55 = private constant [1 x i8] c" "
@.d56 = private constant [3 x i8] c" ~["
@.d57 = private constant [7 x i8] c"struct("
@.d58 = private constant [5 x i8] c"enum{"
@.d59 = private constant [1 x i8] c"<"
@.d60 = private constant [1 x i8] c"."
@.d61 = private constant [1 x i8] c">"
@.d62 = private constant [4 x i8] c"true"
@.d63 = private constant [5 x i8] c"false"
@.d64 = private constant [1 x i8] c"<"
@.d65 = private constant [1 x i8] c">"
@.c66 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:1062: reached unreachable code\0A\00"
@.d67 = private constant [3 x i8] c"i32"
@.d68 = private constant [8 x i8] c"{ i64, ["
@.d69 = private constant [9 x i8] c" x i64] }"
@.c70 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:769: reached unreachable code\0A\00"
@.d71 = private constant [0 x i8] c""
@.d72 = private constant [2 x i8] c", "
@.d73 = private constant [3 x i8] c"i32"
@.d74 = private constant [1 x i8] c"?"
@.c75 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:964: reached unreachable code\0A\00"
@.d76 = private constant [3 x i8] c"i32"
@.d77 = private constant [4 x i8] c"void"
@.d78 = private constant [12 x i8] c"{ ptr, ptr }"
@.d79 = private constant [12 x i8] c"{ i64, ptr }"
@.d80 = private constant [3 x i8] c"ptr"
@.d81 = private constant [1 x i8] c"?"
@.c82 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:938: reached unreachable code\0A\00"
@.d83 = private constant [2 x i8] c"%\22"
@.d84 = private constant [1 x i8] c"\22"
@.d85 = private constant [1 x i8] c"<"
@.c86 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:982: slice bounds out of range\0A\00"
@.d87 = private constant [2 x i8] c"%\22"
@.d88 = private constant [1 x i8] c"."
@.d89 = private constant [1 x i8] c"\22"
@.c90 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:346: array length out of range\0A\00"
@.c91 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:1222: reached unreachable code\0A\00"
@.c92 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:1220: reached unreachable code\0A\00"
@.d93 = private constant [0 x i8] c""
@.d94 = private constant [4 x i8] c"void"
@.d95 = private constant [2 x i8] c"i1"
@.d96 = private constant [2 x i8] c"i8"
@.d97 = private constant [3 x i8] c"i16"
@.d98 = private constant [3 x i8] c"i32"
@.d99 = private constant [3 x i8] c"i64"
@.d100 = private constant [2 x i8] c"i8"
@.d101 = private constant [3 x i8] c"i16"
@.d102 = private constant [3 x i8] c"i32"
@.d103 = private constant [3 x i8] c"i64"
@.d104 = private constant [4 x i8] c"half"
@.d105 = private constant [6 x i8] c"bfloat"
@.d106 = private constant [5 x i8] c"float"
@.d107 = private constant [6 x i8] c"double"
@.d108 = private constant [0 x i8] c""
@.d109 = private constant [0 x i8] c""
@.d110 = private constant [4 x i8] c"Bool"
@.d111 = private constant [2 x i8] c"I8"
@.d112 = private constant [3 x i8] c"I16"
@.d113 = private constant [3 x i8] c"I32"
@.d114 = private constant [3 x i8] c"I64"
@.d115 = private constant [2 x i8] c"U8"
@.d116 = private constant [3 x i8] c"U16"
@.d117 = private constant [3 x i8] c"U32"
@.d118 = private constant [3 x i8] c"U64"
@.d119 = private constant [3 x i8] c"F16"
@.d120 = private constant [4 x i8] c"BF16"
@.d121 = private constant [3 x i8] c"F32"
@.d122 = private constant [3 x i8] c"F64"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeI_He375cb5a1de17a5d01c6b8903f9691e1(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He0d7a5bfd18ae956abf945564c24098c(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20A_Hcfba385079b3349cc13047539d410cc3(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, %"compiler/types:decl" %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H9437066785f0bdbcfc17884fffb14a92(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hcaffdb9d24c80e421d58a725793b74fc(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H25f20ec7bc3952e7f71d4b5fc38b1e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_H503e6d35c0db63145eb2ca8ce5f41f51(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %a0, i32 %a1, %"compiler/types:body" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/types:data" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %a0, %"compiler/types:data" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, %"compiler/types:data" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
