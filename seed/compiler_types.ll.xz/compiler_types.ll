; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/types:data" = type { i32, i64, i64, i64, i64, i64, i64 }
%"compiler/types:DtorWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:decl" = type { i64, i32, i32, i32 }
%"compiler/types:body" = type { i32, i32, i32, i1, i1 }
%"compiler/types:codeWalk" = type { ptr, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
@G_2ecompiler_2ftypes_2eAnySlotBase = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eBigAggregate = constant <{ [8 x i8] }> <{ [8 x i8] c"\80\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eBoolT = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eFromTypeVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eLaidOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eLayingOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoLayout = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNotLaidOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullT = constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eOwnScope = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eResultVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eRoleCtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eRoleDtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eRoleFn = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eSpread = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eUnknownT = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eWritable = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eprimBits = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ftypes_2eprimLlvm = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k1, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k2, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k7, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k11, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k12, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k13, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k14, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k15 }>, align 64
@G_2ecompiler_2ftypes_2eprimLlvm.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k2 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\76\6F\69\64" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k3 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\31" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k8 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k12 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\68\61\6C\66" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k13 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\62\66\6C\6F\61\74" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k14 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6C\6F\61\74" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k15 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\64\6F\75\62\6C\65" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k2, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k7, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k12, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k13, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k14, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k15 }>, align 64
@G_2ecompiler_2ftypes_2eprimNames.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k3 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\6F\6F\6C" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\49\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k8 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\55\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\46\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k14 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k15 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\36\34" }>, align 8
define dso_local { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i8
  %lp6 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l82 = alloca i64
  %l89 = alloca i1
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i1
  %l106 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  store i1 false, ptr %l2, !tbaa !21
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = icmp eq i64 %t5, 122
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l12, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l13, !tbaa !24
  %t12 = icmp sge i64 88, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb10
bb3:
  %t14 = icmp sle i64 88, 90
  br i1 %t14, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c38cb1fa51df222a_dffb1d180717405e)
  unreachable
bb5:
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = icmp sle i64 90, %t16
  br i1 %t17, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c38cb1fa51df222a_dffb1d180717405e)
  unreachable
bb7:
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 88
  %t22 = sub i64 90, 88
  %t23 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t26, ptr %l18
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c38cb1fa51df222a_dffb1d180717405e)
  unreachable
bb9:
  %t27 = load i1, ptr %l18, !tbaa !21
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l11, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l20, !tbaa !24
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb13, label %bb14
bb12:
  br label %bb19
bb13:
  %t34 = icmp sle i64 0, 88
  br i1 %t34, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_84fae12c7c668807_3becc0cabb21395b)
  unreachable
bb15:
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = icmp sle i64 88, %t36
  br i1 %t37, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_84fae12c7c668807_3becc0cabb21395b)
  unreachable
bb17:
  %t39 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 0
  %t42 = sub i64 88, 0
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  store { i64, ptr } %t44, ptr %l1, !tbaa !27
  store i1 true, ptr %l2, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_84fae12c7c668807_3becc0cabb21395b)
  unreachable
bb19:
  %t46 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t46, ptr %l25
  br label %bb20
bb20:
  %t47 = load %"std/prelude/text:StringBuilder", ptr %l25
  store %"std/prelude/text:StringBuilder" %t47, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t54 = icmp slt i64 %t48, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb22, label %bb23
bb22:
  br label %bb57
bb23:
  br label %bb24
bb24:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  store i8 %t64, ptr %l5, !tbaa !22
  %t66 = load i8, ptr %l5, !tbaa !22
  %t68 = icmp ne i8 %t66, 95
  br i1 %t68, label %bb25, label %bb26
bb25:
  %t70 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 %t70)
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l4, !tbaa !24
  br label %bb56
bb28:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t79 = add i64 %t77, 1
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t85 = icmp slt i64 %t79, %t82
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t87, ptr %l46, !tbaa !27
  %t88 = load i64, ptr %l4, !tbaa !24
  %t90 = add i64 %t88, 1
  %t92 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i8, ptr %t93, i64 %t90
  %t95 = load i8, ptr %t94, !tbaa !32
  %t97 = icmp eq i8 %t95, 95
  store i1 %t97, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t99 = load i1, ptr %l45, !tbaa !21
  br i1 %t99, label %bb32, label %bb33
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 95)
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = add i64 %t101, 2
  store i64 %t103, ptr %l4, !tbaa !24
  br label %bb56
bb35:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t107 = add i64 %t105, 2
  %t108 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t113 = icmp slt i64 %t107, %t110
  br i1 %t113, label %bb36, label %bb37
bb36:
  %t115 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t115, ptr %l60, !tbaa !27
  %t116 = load i64, ptr %l4, !tbaa !24
  %t118 = add i64 %t116, 1
  %t120 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i8, ptr %t121, i64 %t118
  %t123 = load i8, ptr %t122, !tbaa !32
  %t125 = call i1 @compiler_2ftypes_2esymbolHexDigit(i8 %t123)
  store i1 %t125, ptr %l64
  br label %bb38
bb37:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb39
bb38:
  %t126 = load i1, ptr %l64, !tbaa !21
  store i1 %t126, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t127 = load i1, ptr %l59, !tbaa !21
  br i1 %t127, label %bb40, label %bb41
bb40:
  %t128 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t128, ptr %l66, !tbaa !27
  %t129 = load i64, ptr %l4, !tbaa !24
  %t131 = add i64 %t129, 2
  %t133 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i8, ptr %t134, i64 %t131
  %t136 = load i8, ptr %t135, !tbaa !32
  %t138 = call i1 @compiler_2ftypes_2esymbolHexDigit(i8 %t136)
  store i1 %t138, ptr %l70
  br label %bb42
bb41:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb43
bb42:
  %t139 = load i1, ptr %l70, !tbaa !21
  store i1 %t139, ptr %l65, !tbaa !21
  br label %bb43
bb43:
  %t140 = load i1, ptr %l65, !tbaa !21
  br i1 %t140, label %bb44, label %bb45
bb44:
  store ptr %l3, ptr %l71, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t141, ptr %l72, !tbaa !27
  %t142 = load i64, ptr %l4, !tbaa !24
  %t144 = add i64 %t142, 1
  %t146 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = call i64 @compiler_2ftypes_2esymbolHexValue(i8 %t149)
  store i64 %t151, ptr %l76
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t152 = load i64, ptr %l76, !tbaa !24
  %t153 = mul i64 %t152, 16
  store i64 %t153, ptr %l77, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t154, ptr %l78, !tbaa !27
  %t155 = load i64, ptr %l4, !tbaa !24
  %t157 = add i64 %t155, 2
  %t159 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t164 = call i64 @compiler_2ftypes_2esymbolHexValue(i8 %t162)
  store i64 %t164, ptr %l82
  br label %bb47
bb47:
  %t165 = load i64, ptr %l77, !tbaa !24
  %t166 = load i64, ptr %l82, !tbaa !24
  %t167 = add i64 %t165, %t166
  %t169 = trunc i64 %t167 to i8
  %t171 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t171, i8 %t169)
  br label %bb48
bb48:
  %t173 = load i64, ptr %l4, !tbaa !24
  %t175 = add i64 %t173, 3
  store i64 %t175, ptr %l4, !tbaa !24
  br label %bb56
bb49:
  %t177 = load i1, ptr %l2, !tbaa !21
  br i1 %t177, label %bb50, label %bb51
bb50:
  %t179 = load i64, ptr %l4, !tbaa !24
  %t181 = add i64 %t179, 2
  %t182 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t187 = icmp sge i64 %t181, %t184
  store i1 %t187, ptr %l89, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb52
bb52:
  %t189 = load i1, ptr %l89, !tbaa !21
  br i1 %t189, label %bb53, label %bb54
bb53:
  br label %bb57
bb54:
  br label %bb55
bb55:
  %t190 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = extractvalue { i64, ptr } %t190, 0
  %t194 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t193)
  call void @olang_textcopy(ptr %t194, ptr %t192, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t196, ptr %rv
  br label %ret
bb56:
  br label %bb21
bb57:
  %t199 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t199, ptr %l98
  br label %bb58
bb58:
  %t200 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t200, ptr %lp6
  %t201 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t202 = load ptr, ptr %lp6
  store { i64, ptr } %t201, ptr %t202, !tbaa !27
  %t203 = load ptr, ptr %lp6
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t207 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t204, { i64, ptr } %t206)
  store i1 %t207, ptr %l101
  br label %bb59
bb59:
  %t208 = load i1, ptr %l101, !tbaa !21
  %t209 = xor i1 %t208, true
  br i1 %t209, label %bb60, label %bb61
bb60:
  %t211 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 1
  %t214 = extractvalue { i64, ptr } %t211, 0
  %t215 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t213, i64 %t214)
  %t216 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t217, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t219 = load i1, ptr %l2, !tbaa !21
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %lp6
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = extractvalue { i64, ptr } %t222, 0
  %t226 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t229 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t228)
  call void @olang_textcopy(ptr %t229, ptr %t224, i64 %t225)
  %t230 = getelementptr i8, ptr %t229, i64 %t225
  call void @olang_textcopy(ptr %t230, ptr %t226, i64 %t227)
  %t231 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  store { i64, ptr } %t232, ptr %l106, !tbaa !27
  br label %bb65
bb64:
  %t234 = load ptr, ptr %lp6
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  store { i64, ptr } %t235, ptr %l106, !tbaa !27
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t237 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t237, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2eIntBytes(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sle i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb12
bb2:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = icmp sle i64 %t5, 16
  br i1 %t7, label %bb3, label %bb4
bb3:
  store i64 2, ptr %l6, !tbaa !24
  br label %bb11
bb4:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = icmp sle i64 %t9, 32
  br i1 %t11, label %bb5, label %bb6
bb5:
  store i64 4, ptr %l9, !tbaa !24
  br label %bb10
bb6:
  %t13 = load i64, ptr %l0, !tbaa !24
  %t15 = icmp sle i64 %t13, 64
  br i1 %t15, label %bb7, label %bb8
bb7:
  store i64 8, ptr %l12, !tbaa !24
  br label %bb9
bb8:
  store i64 16, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  %t17 = load i64, ptr %l12, !tbaa !24
  store i64 %t17, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  %t18 = load i64, ptr %l9, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t19 = load i64, ptr %l6, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb12
bb12:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2eIntWidth(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca { i64, ptr }
  %l57 = alloca i1
  %l62 = alloca { i64, ptr }
  %l73 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp slt i64 %t3, 2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 4
  store i1 %t11, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb9
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l16, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 0
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = icmp ne i8 %t18, 73
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i8, ptr %t24, i64 0
  %t26 = load i8, ptr %t25, !tbaa !32
  %t28 = icmp ne i8 %t26, 85
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l19, !tbaa !21
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t32, ptr %l24, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i8, ptr %t34, i64 1
  %t36 = load i8, ptr %t35, !tbaa !32
  %t38 = icmp eq i8 %t36, 48
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i64 0, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 0, ptr %l1, !tbaa !24
  store i64 1, ptr %l2, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb21
bb18:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l4, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l36, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb20
bb20:
  %t72 = load i64, ptr %l36, !tbaa !24
  store i64 %t72, ptr %l33, !tbaa !24
  br label %bb21
bb21:
  %t73 = load i64, ptr %l33, !tbaa !24
  store i64 %t73, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb22:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  br label %bb25
bb25:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l4, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l7, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i8, ptr %t96, i64 %t93
  %t98 = load i8, ptr %t97, !tbaa !32
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t98)
  store i1 %t100, ptr %l57
  br label %bb26
bb26:
  %t101 = load i1, ptr %l57, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  store i64 0, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t105 = load i64, ptr %l1, !tbaa !24
  %t107 = mul i64 %t105, 10
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t108, ptr %l62, !tbaa !27
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 %t109
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = zext i8 %t114 to i64
  %t119 = add i64 %t107, %t116
  %t120 = zext i8 48 to i64
  %t123 = sub i64 %t119, %t120
  store i64 %t123, ptr %l1, !tbaa !24
  br label %bb30
bb30:
  %t125 = load i64, ptr %l6, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l6, !tbaa !24
  br label %bb22
bb31:
  %t129 = load i64, ptr %l1, !tbaa !24
  %t131 = icmp slt i64 %t129, 1
  br i1 %t131, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb34
bb33:
  %t133 = load i64, ptr %l1, !tbaa !24
  %t135 = icmp sgt i64 %t133, 128
  store i1 %t135, ptr %l73, !tbaa !21
  br label %bb34
bb34:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb35, label %bb36
bb35:
  store i64 0, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t139 = load i64, ptr %l1, !tbaa !24
  store i64 %t139, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2eIsIntName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2ftypes_2eIntWidth(ptr %v0, { i64, ptr } %a0)
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t4, 0
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftypes_2eNewTable(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l20 = alloca %"compiler/types:Table"
  %l21 = alloca ptr
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l51 = alloca [18 x i32]
  %l62 = alloca ptr
  %l64 = alloca %"compiler/types:data"
  %l65 = alloca i32
  %l73 = alloca i64
  %l76 = alloca i64
  %l97 = alloca i64
  %l100 = alloca i64
  %l121 = alloca i64
  %l124 = alloca ptr
  %l128 = alloca i32
  %l130 = alloca ptr
  %l135 = alloca %"compiler/types:data"
  %l136 = alloca i32
  %l141 = alloca %"compiler/types:Table"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t2 = alloca %"compiler/types:Table", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftypes_3aTable_2ector(ptr %t2, ptr %v0, ptr %v1, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t2, i64 1776, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 1776, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l20, i64 1776, i1 false)
  %t6 = load ptr, ptr %lp1
  %t7 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 5
  store ptr %t7, ptr %l21, !tbaa !29
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = icmp sle i64 0, 2305843009213693951
  br i1 %t10, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_350cf97603b2facf_69b011185289b33)
  unreachable
bb4:
  %t12 = mul i64 0, 4
  %t13 = insertvalue { i64, ptr } undef, i64 0, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t15 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H5d6217f1de626e258ec0008385e9bf9b(ptr %v1, ptr %v1, ptr %t15, { i64, ptr } %t14)
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_350cf97603b2facf_69b011185289b33)
  unreachable
bb6:
  %t17 = load ptr, ptr %lp1
  %t18 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 28
  store ptr %t18, ptr %l25, !tbaa !29
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t21 = icmp sle i64 0, 1152921504606846975
  br i1 %t21, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_8b13046bbc59237a_a5831af19cea45fe)
  unreachable
bb9:
  %t23 = mul i64 0, 8
  %t24 = insertvalue { i64, ptr } undef, i64 0, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t26 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t26, { i64, ptr } %t25)
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8b13046bbc59237a_a5831af19cea45fe)
  unreachable
bb11:
  %t28 = load ptr, ptr %lp1
  %t29 = getelementptr %"compiler/types:Table", ptr %t28, i32 0, i32 30
  store ptr %t29, ptr %l29, !tbaa !29
  %t30 = icmp sge i64 0, 0
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t32 = icmp sle i64 0, 1152921504606846975
  br i1 %t32, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4622f22b1b9e72f9_4c12a3b980ae2b3d)
  unreachable
bb14:
  %t34 = mul i64 0, 8
  %t35 = insertvalue { i64, ptr } undef, i64 0, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t37 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t37, { i64, ptr } %t36)
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4622f22b1b9e72f9_4c12a3b980ae2b3d)
  unreachable
bb16:
  store %olang.scope zeroinitializer, ptr %s1
  %t57 = getelementptr [18 x i32], ptr %l51, i64 0, i64 0
  store i32 0, ptr %t57
  %t58 = getelementptr [18 x i32], ptr %l51, i64 0, i64 1
  store i32 1, ptr %t58
  %t59 = getelementptr [18 x i32], ptr %l51, i64 0, i64 2
  store i32 2, ptr %t59
  %t60 = getelementptr [18 x i32], ptr %l51, i64 0, i64 3
  store i32 3, ptr %t60
  %t61 = getelementptr [18 x i32], ptr %l51, i64 0, i64 4
  store i32 4, ptr %t61
  %t62 = getelementptr [18 x i32], ptr %l51, i64 0, i64 5
  store i32 5, ptr %t62
  %t63 = getelementptr [18 x i32], ptr %l51, i64 0, i64 6
  store i32 6, ptr %t63
  %t64 = getelementptr [18 x i32], ptr %l51, i64 0, i64 7
  store i32 7, ptr %t64
  %t65 = getelementptr [18 x i32], ptr %l51, i64 0, i64 8
  store i32 8, ptr %t65
  %t66 = getelementptr [18 x i32], ptr %l51, i64 0, i64 9
  store i32 9, ptr %t66
  %t67 = getelementptr [18 x i32], ptr %l51, i64 0, i64 10
  store i32 10, ptr %t67
  %t68 = getelementptr [18 x i32], ptr %l51, i64 0, i64 11
  store i32 11, ptr %t68
  %t69 = getelementptr [18 x i32], ptr %l51, i64 0, i64 12
  store i32 12, ptr %t69
  %t70 = getelementptr [18 x i32], ptr %l51, i64 0, i64 13
  store i32 13, ptr %t70
  %t71 = getelementptr [18 x i32], ptr %l51, i64 0, i64 14
  store i32 14, ptr %t71
  %t72 = getelementptr [18 x i32], ptr %l51, i64 0, i64 15
  store i32 15, ptr %t72
  %t73 = getelementptr [18 x i32], ptr %l51, i64 0, i64 16
  store i32 16, ptr %t73
  %t74 = getelementptr [18 x i32], ptr %l51, i64 0, i64 17
  store i32 17, ptr %t74
  %t75 = load [18 x i32], ptr %l51
  %t76 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 72, i64 8)
  store [18 x i32] %t75, ptr %t76
  store ptr %t76, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t78 = load ptr, ptr %l2
  store i64 18, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t81 = load i64, ptr %l3, !tbaa !24
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t89 = load ptr, ptr %l2
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = getelementptr [18 x i32], ptr %t89, i64 0, i64 %t90
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 33}
  %t96 = load ptr, ptr %lp1
  store ptr %t96, ptr %l62, !tbaa !29
  %t99 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s2, i32 %t94, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t99, ptr %l64
  br label %bb21
bb21:
  %t100 = load ptr, ptr %l62, !tbaa !29
  %t101 = load %"compiler/types:data", ptr %l64
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v1, ptr %t100, %"compiler/types:data" %t101, i32 1)
  store i32 %t102, ptr %l65
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l3, !tbaa !24
  br label %bb17
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t107 = load ptr, ptr %lp1
  %t108 = getelementptr %"compiler/types:Table", ptr %t107, i32 0, i32 34
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t108, i32 %t109)
  br label %bb25
bb25:
  store i64 0, ptr %l6, !tbaa !24
  store i64 2, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t118 = load i64, ptr %l8, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb31
bb28:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t123 = load i64, ptr %l6, !tbaa !24
  %t126 = sub i64 %t122, %t123
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t132 = sub i64 %t130, 1
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = sdiv i64 %t132, %t133
  store i64 %t136, ptr %l76, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb30
bb30:
  %t138 = load i64, ptr %l76, !tbaa !24
  store i64 %t138, ptr %l73, !tbaa !24
  br label %bb31
bb31:
  %t139 = load i64, ptr %l73, !tbaa !24
  store i64 %t139, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  %t140 = load i64, ptr %l10, !tbaa !24
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb33, label %bb34
bb33:
  br label %bb56
bb34:
  br label %bb35
bb35:
  %t148 = load i64, ptr %l6, !tbaa !24
  %t149 = load i64, ptr %l10, !tbaa !24
  %t150 = load i64, ptr %l8, !tbaa !24
  %t153 = mul i64 %t149, %t150
  %t156 = add i64 %t148, %t153
  store i64 %t156, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  store i64 129, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t159 = load i64, ptr %l12, !tbaa !24
  %t162 = icmp sgt i64 %t158, %t159
  br i1 %t162, label %bb36, label %bb37
bb36:
  %t164 = load i64, ptr %l14, !tbaa !24
  %t166 = icmp sgt i64 %t164, 0
  br i1 %t166, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb41
bb38:
  %t168 = load i64, ptr %l13, !tbaa !24
  %t169 = load i64, ptr %l12, !tbaa !24
  %t172 = sub i64 %t168, %t169
  %t173 = load i64, ptr %l14, !tbaa !24
  %t176 = add i64 %t172, %t173
  %t178 = sub i64 %t176, 1
  %t179 = load i64, ptr %l14, !tbaa !24
  %t182 = sdiv i64 %t178, %t179
  store i64 %t182, ptr %l100, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb40
bb40:
  %t184 = load i64, ptr %l100, !tbaa !24
  store i64 %t184, ptr %l97, !tbaa !24
  br label %bb41
bb41:
  %t185 = load i64, ptr %l97, !tbaa !24
  store i64 %t185, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t186 = load i64, ptr %l16, !tbaa !24
  %t187 = load i64, ptr %l15, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb44:
  br label %bb45
bb45:
  %t194 = load i64, ptr %l12, !tbaa !24
  %t195 = load i64, ptr %l16, !tbaa !24
  %t196 = load i64, ptr %l14, !tbaa !24
  %t199 = mul i64 %t195, %t196
  %t202 = add i64 %t194, %t199
  store i64 %t202, ptr %l17, !tbaa !24
  %t204 = load i64, ptr %l17, !tbaa !24
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = icmp eq i64 %t205, 1
  %t210 = call i64 @compiler_2ftypes_2eprimIndex(i64 %t204, i1 %t207)
  store i64 %t210, ptr %l121
  br label %bb46
bb46:
  %t211 = load i64, ptr %l121, !tbaa !24
  %t212 = trunc i64 %t211 to i32
  store i32 %t212, ptr %l18, !tbaa !23
  %t215 = load ptr, ptr %lp1
  %t216 = getelementptr %"compiler/types:Table", ptr %t215, i32 0, i32 34
  store ptr %t216, ptr %l124, !tbaa !29
  %t217 = load i32, ptr %l18, !tbaa !23
  %t218 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t221 = icmp ne i32 %t217, %t218
  br i1 %t221, label %bb47, label %bb48
bb47:
  %t223 = load i32, ptr %l18, !tbaa !23
  store i32 %t223, ptr %l128, !tbaa !23
  br label %bb51
bb48:
  %t225 = load ptr, ptr %lp1
  store ptr %t225, ptr %l130, !tbaa !29
  %t226 = load i64, ptr %l17, !tbaa !24
  %t227 = load i64, ptr %l11, !tbaa !24
  %t229 = sub i64 1, %t227
  %t233 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s7, i32 31, i64 %t226, i64 %t229, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t233, ptr %l135
  br label %bb49
bb49:
  %t234 = load ptr, ptr %l130, !tbaa !29
  %t235 = load %"compiler/types:data", ptr %l135
  %t236 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v1, ptr %t234, %"compiler/types:data" %t235, i32 1)
  store i32 %t236, ptr %l136
  br label %bb50
bb50:
  %t237 = load i32, ptr %l136, !tbaa !23
  store i32 %t237, ptr %l128, !tbaa !23
  br label %bb51
bb51:
  %t238 = load ptr, ptr %l124, !tbaa !29
  %t239 = load i32, ptr %l128, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t238, i32 %t239)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb53:
  %t240 = load i64, ptr %l16, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l16, !tbaa !24
  br label %bb42
bb54:
  br label %bb55
bb55:
  %t244 = load i64, ptr %l10, !tbaa !24
  %t246 = add i64 %t244, 1
  store i64 %t246, ptr %l10, !tbaa !24
  br label %bb32
bb56:
  %t248 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %l141, ptr %t248, i64 1776, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l141, i64 1776, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %lp7 = alloca ptr
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l51 = alloca { i64, i64 }
  %l54 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l5, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l6, !tbaa !22
  %t27 = load i8, ptr %l6, !tbaa !22
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t27)
  store i1 %t29, ptr %l24
  br label %bb6
bb6:
  %t30 = load i1, ptr %l24, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb8:
  %t31 = load i8, ptr %l6, !tbaa !22
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t31)
  store i1 %t33, ptr %l27
  br label %bb9
bb9:
  %t34 = load i1, ptr %l27, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  store i1 %t37, ptr %l28, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l28, !tbaa !21
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load i8, ptr %l6, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t41)
  br label %bb16
bb15:
  %t44 = load i8, ptr %l6, !tbaa !22
  %t46 = icmp eq i8 %t44, 95
  br i1 %t46, label %bb17, label %bb18
bb16:
  br label %bb24
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb20:
  store ptr %l1, ptr %l37, !tbaa !29
  %t50 = load i8, ptr %l6, !tbaa !22
  %t53 = call { i64, ptr } @compiler_2ftypes_2ehex2(ptr %s6, i8 %t50)
  store { i64, ptr } %t53, ptr %l40
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t61 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t61, { i64, ptr } %t60)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb2
bb26:
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t68, ptr %l45
  br label %bb27
bb27:
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t69, ptr %lp7
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = load ptr, ptr %lp7
  store { i64, ptr } %t70, ptr %t71, !tbaa !27
  %t72 = load ptr, ptr %lp7
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t77 = icmp sle i64 %t75, 120
  br i1 %t77, label %bb28, label %bb29
bb28:
  %t79 = load ptr, ptr %lp7
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t82 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %t82)
  store { i64, i64 } %t84, ptr %l51
  br label %bb31
bb31:
  %t85 = load { i64, i64 }, ptr %l51
  store { i64, i64 } %t85, ptr %l8
  %t86 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t87 = load i64, ptr %t86, !tbaa !65
  store i64 %t87, ptr %l9, !tbaa !65
  %t89 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !65
  store i64 %t90, ptr %l10, !tbaa !65
  %t92 = load ptr, ptr %lp7
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l54, !tbaa !24
  %t95 = icmp sge i64 0, 0
  br i1 %t95, label %bb32, label %bb33
bb32:
  %t97 = icmp sle i64 0, 88
  br i1 %t97, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb34:
  %t99 = load i64, ptr %l54, !tbaa !24
  %t100 = icmp sle i64 88, %t99
  br i1 %t100, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb36:
  %t102 = load ptr, ptr %lp7
  %t103 = getelementptr { i64, ptr }, ptr %t102, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i8, ptr %t104, i64 0
  %t106 = sub i64 88, 0
  %t107 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  store { i64, ptr } %t108, ptr %l58, !tbaa !27
  %t109 = load i64, ptr %l9, !tbaa !65
  %t111 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t109)
  store { i64, ptr } %t111, ptr %l60
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb38:
  %t112 = load i64, ptr %l10, !tbaa !65
  %t114 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t112)
  store { i64, ptr } %t114, ptr %l62
  br label %bb39
bb39:
  %t115 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = add i64 %t124, %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t116, i64 %t117)
  %t130 = getelementptr i8, ptr %t129, i64 %t117
  call void @olang_textcopy(ptr %t130, ptr %t118, i64 %t119)
  %t131 = getelementptr i8, ptr %t130, i64 %t119
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = getelementptr i8, ptr %t131, i64 %t123
  call void @olang_textcopy(ptr %t132, ptr %t126, i64 %t127)
  %t133 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t129, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t134, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %v0, i64 %a0) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l2, !tbaa !65
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !65
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t8, i64 %t9)
  store { i64, ptr } %t10, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_30e02956f84eec46_91b8152c5eb3aca)
  unreachable
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %l10 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca { i64, ptr }
  %l82 = alloca i1
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:DtorWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t8, ptr %t6, i32 %a1)
  store i32 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i32, ptr %l10, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/types:DtorWalk", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/types:DtorWalk", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %t23, i32 %t24)
  %t28 = extractvalue { i32, i1 } %t27, 1
  %t29 = extractvalue { i32, i1 } %t27, 0
  store i32 %t29, ptr %l20
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store i1 %t28, ptr %l19
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l15, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/types:DtorWalk", ptr %t34, i32 0, i32 1
  %t37 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t36, i32 %t37, i1 false)
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t42 = load ptr, ptr @__olang_prog_scope
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t42, ptr %t40, i32 %t41)
  store i32 %t45, ptr %l26
  br label %bb11
bb11:
  %t46 = load i32, ptr %l26, !range !{i32 0, i32 33}
  store i32 %t46, ptr %l4
  %t47 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t49 = trunc i64 20 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load i32, ptr %l3, !tbaa !23
  %t55 = load ptr, ptr @__olang_prog_scope
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t55, ptr %t53, i32 %t54)
  store i32 %t58, ptr %l33
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = load i32, ptr %l33, !tbaa !23
  %t61 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t61, ptr %l34
  br label %bb16
bb16:
  %t62 = load i1, ptr %l34, !tbaa !21
  store i1 %t62, ptr %l27, !tbaa !21
  br label %bb64
bb17:
  %t63 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t65 = trunc i64 29 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t68 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t70 = trunc i64 25 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb64
bb23:
  %t73 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t75 = trunc i64 19 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t81 = load ptr, ptr @__olang_prog_scope
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t81, ptr %t79, i32 %t80)
  store i32 %t84, ptr %l44
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l41, !tbaa !29
  %t86 = load i32, ptr %l44, !tbaa !23
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t87, ptr %l45
  br label %bb28
bb28:
  %t88 = load i1, ptr %l45, !tbaa !21
  store i1 %t88, ptr %l27, !tbaa !21
  br label %bb64
bb29:
  %t89 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t91 = trunc i64 22 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t94 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t96 = trunc i64 23 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l50, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  store ptr %t100, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t102 = load i32, ptr %l3, !tbaa !23
  %t103 = load ptr, ptr @__olang_prog_scope
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t103, ptr %t101, i32 %t102)
  store i32 %t106, ptr %l54
  br label %bb35
bb35:
  %t107 = load ptr, ptr @__olang_prog_scope
  %t108 = load ptr, ptr %l51, !tbaa !29
  %t109 = load i32, ptr %l54, !tbaa !23
  %t110 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t107, ptr %s5, ptr %t108, i32 %t109)
  store { i64, ptr } %t110, ptr %l55
  br label %bb36
bb36:
  %t111 = load ptr, ptr %l50, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t113 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2esome(ptr %v0, ptr %s5, ptr %t111, { i64, ptr } %t112)
  store i1 %t113, ptr %l56
  br label %bb37
bb37:
  %t114 = load i1, ptr %l56, !tbaa !21
  store i1 %t114, ptr %l27, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb64
bb38:
  %t115 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t117 = trunc i64 18 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb59
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t121 = load i32, ptr %l3, !tbaa !23
  %t122 = load ptr, ptr @__olang_prog_scope
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t122, ptr %t120, i32 %t121)
  store i1 %t125, ptr %l61
  br label %bb42
bb42:
  %t126 = load i1, ptr %l61, !tbaa !21
  %t127 = xor i1 %t126, true
  br i1 %t127, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb46
bb44:
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load i32, ptr %l3, !tbaa !23
  %t131 = load ptr, ptr @__olang_prog_scope
  %t134 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %t131, ptr %t129, i32 %t130)
  store i1 %t134, ptr %l66
  br label %bb45
bb45:
  %t135 = load i1, ptr %l66, !tbaa !21
  store i1 %t135, ptr %l63, !tbaa !21
  br label %bb46
bb46:
  %t136 = load i1, ptr %l63, !tbaa !21
  br i1 %t136, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb52
bb48:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l68, !tbaa !29
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l69, !tbaa !29
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t140 = load i32, ptr %l3, !tbaa !23
  %t141 = load ptr, ptr @__olang_prog_scope
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %t141, ptr %t139, i32 %t140)
  store i32 %t144, ptr %l72
  br label %bb49
bb49:
  %t145 = load ptr, ptr @__olang_prog_scope
  %t146 = load ptr, ptr %l69, !tbaa !29
  %t147 = load i32, ptr %l72, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t145, ptr %s6, ptr %t146, i32 %t147)
  store { i64, ptr } %t148, ptr %l73
  br label %bb50
bb50:
  %t149 = load ptr, ptr %l68, !tbaa !29
  %t150 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t151 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2esome(ptr %v0, ptr %s6, ptr %t149, { i64, ptr } %t150)
  store i1 %t151, ptr %l74
  br label %bb51
bb51:
  %t152 = load i1, ptr %l74, !tbaa !21
  store i1 %t152, ptr %l67, !tbaa !21
  br label %bb52
bb52:
  %t153 = load i1, ptr %l67, !tbaa !21
  br i1 %t153, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb58
bb54:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l76, !tbaa !29
  %t155 = load ptr, ptr %l2, !tbaa !29
  store ptr %t155, ptr %l77, !tbaa !29
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t157 = load i32, ptr %l3, !tbaa !23
  %t158 = load ptr, ptr @__olang_prog_scope
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %t158, ptr %t156, i32 %t157)
  store i32 %t161, ptr %l80
  br label %bb55
bb55:
  %t162 = load ptr, ptr @__olang_prog_scope
  %t163 = load ptr, ptr %l77, !tbaa !29
  %t164 = load i32, ptr %l80, !tbaa !23
  %t165 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t162, ptr %s6, ptr %t163, i32 %t164)
  store { i64, ptr } %t165, ptr %l81
  br label %bb56
bb56:
  %t166 = load ptr, ptr %l76, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2esome(ptr %v0, ptr %s6, ptr %t166, { i64, ptr } %t167)
  store i1 %t168, ptr %l82
  br label %bb57
bb57:
  %t169 = load i1, ptr %l82, !tbaa !21
  store i1 %t169, ptr %l75, !tbaa !21
  br label %bb58
bb58:
  %t170 = load i1, ptr %l75, !tbaa !21
  store i1 %t170, ptr %l27, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_5cbd31595b499a54_61b0a2a5664e21e0)
  unreachable
bb64:
  %t171 = load i1, ptr %l27, !tbaa !21
  store i1 %t171, ptr %l5, !tbaa !21
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/types:DtorWalk", ptr %t172, i32 0, i32 1
  %t175 = load i32, ptr %l3, !tbaa !23
  %t176 = load i1, ptr %l5, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t174, i32 %t175, i1 %t176)
  br label %bb65
bb65:
  %t180 = load i1, ptr %l5, !tbaa !21
  store i1 %t180, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2esome(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %a0, i32 %t28)
  store i1 %t31, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i64
  %l12 = alloca ptr
  %l17 = alloca %"compiler/types:decl"
  %l19 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/types:Table", ptr %t10, i32 0, i32 13
  store ptr %t12, ptr %l12, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = load i32, ptr %l2, !tbaa !23
  %t21 = call %"compiler/types:decl" @compiler_2ftypes_3adecl_2ector(ptr %s0, i64 %t13, i32 %t14, i32 %a3, i32 %a4)
  store %"compiler/types:decl" %t21, ptr %l17
  br label %bb2
bb2:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = load %"compiler/types:decl", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t22, %"compiler/types:decl" %t23)
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/types:Table", ptr %t24, i32 0, i32 15
  store ptr %t26, ptr %l19, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/types:Table", ptr %t27, i32 0, i32 14
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t29, i64 %t30)
  store { i64, ptr } %t33, ptr %l23
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/types:Table", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t39 = load ptr, ptr @__olang_prog_scope
  %t42 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t39, ptr %s0, ptr %t37, i32 %t38)
  store { i64, ptr } %t42, ptr %l27
  br label %bb5
bb5:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  call void @olang_textcopy(ptr %t54, ptr %t46, i64 %t47)
  %t55 = getelementptr i8, ptr %t54, i64 %t47
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t65 = load i32, ptr %l5, !tbaa !23
  %t66 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v0, ptr %t66, { i64, ptr } %t64, i32 %t65)
  br label %bb6
bb6:
  %t69 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 14
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = extractvalue { i64, ptr } %t10, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t3, { i64, ptr } %t17)
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 14
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l9
  br label %bb2
bb2:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = sub i64 %t25, 1
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 22
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a0, ptr %l4, !tbaa !29
  store i32 %a1, ptr %l5, !tbaa !23
  %t7 = icmp sge i64 0, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = icmp sle i64 0, 1152921504606846975
  br i1 %t9, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_4cf414dd239e444f_4f727e94fd163263)
  unreachable
bb4:
  %t11 = mul i64 0, 8
  %t12 = insertvalue { i64, ptr } undef, i64 0, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t14 = load ptr, ptr %lp2
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i32, ptr %l5, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eanchorsInto(ptr %v0, ptr %s0, ptr %v1, ptr %t15, i32 %t16, { i64, ptr } %t13, ptr %t14, i64 0)
  store i32 %t19, ptr %l10
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb7, label %ok.21, !prof !99
ok.21:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4cf414dd239e444f_4f727e94fd163263)
  unreachable
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l11
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %rv
  br label %ret
bb10:
  %t24 = load ptr, ptr %lp2
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v1, ptr %t24)
  store i64 %t26, ptr %l13
  br label %bb11
bb11:
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = icmp eq i64 %t27, 0
  br i1 %t28, label %bb12, label %bb13
bb12:
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l15
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %rv
  br label %ret
bb15:
  %t32 = load ptr, ptr %lp2
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t32
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i32
  %l29 = alloca %"std/prelude/text:StringBuilder"
  %l37 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l63 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l102 = alloca i64
  %l110 = alloca ptr
  %l123 = alloca i1
  %l127 = alloca { i64, ptr }
  %l131 = alloca i64
  %l140 = alloca i64
  %l143 = alloca i64
  %l161 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l175 = alloca %"compiler/types:data"
  %l178 = alloca i32
  %l180 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l28
  br label %bb1
bb1:
  %t6 = load i32, ptr %l28, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l29
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l29
  store %"std/prelude/text:StringBuilder" %t8, ptr %l5
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l8, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t23, ptr %l37, !tbaa !27
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  %t34 = sext i32 %t29 to i64
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t34)
  %t41 = getelementptr i8, ptr %t39, i64 %t35
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t50)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb3
bb9:
  %t57 = load i32, ptr %l4, !tbaa !23
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t62 = sext i32 %t57 to i64
  %t63 = call i64 @__olang_fmt_i64(ptr null, i64 %t62)
  %t64 = add i64 %t60, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t59, i64 %t60)
  %t66 = getelementptr i8, ptr %t65, i64 %t60
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t62)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t76)
  br label %bb10
bb10:
  %t80 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t80, ptr %l53
  br label %bb11
bb11:
  %t81 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t81, ptr %l10, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/types:Table", ptr %t82, i32 0, i32 10
  %t85 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t88 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s0, ptr %t84, { i64, ptr } %t85)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l59
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb13, label %ok.92, !prof !99
ok.92:
  store i64 %t89, ptr %l58
  br label %bb12
bb12:
  %t93 = load i64, ptr %l58, !tbaa !24
  store i64 %t93, ptr %l54, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb15
bb15:
  %t94 = load i64, ptr %l54, !tbaa !24
  store i64 %t94, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb16, label %bb17
bb16:
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l63, !tbaa !24
  %t102 = load i64, ptr %l63, !tbaa !24
  %t103 = icmp sge i64 %t102, 0
  br i1 %t103, label %bb18, label %bb19
bb17:
  br label %bb43
bb18:
  %t105 = load i64, ptr %l63, !tbaa !24
  %t106 = icmp sle i64 %t105, 2305843009213693951
  br i1 %t106, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_363cc534119e1b58_f5bd72046473679c)
  unreachable
bb20:
  %t108 = load i64, ptr %l63, !tbaa !24
  %t109 = mul i64 %t108, 4
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t118 = load i64, ptr %l14, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_363cc534119e1b58_f5bd72046473679c)
  unreachable
bb22:
  %t124 = load i64, ptr %l15, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb27
bb24:
  %t128 = load i64, ptr %l14, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l15, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l15, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l75, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb26
bb26:
  %t144 = load i64, ptr %l75, !tbaa !24
  store i64 %t144, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t145 = load i64, ptr %l72, !tbaa !24
  store i64 %t145, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb28
bb28:
  %t146 = load i64, ptr %l17, !tbaa !24
  %t147 = load i64, ptr %l16, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l17, !tbaa !24
  %t156 = load i64, ptr %l15, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l18, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t164, ptr %l93, !tbaa !27
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t166, ptr %l95, !tbaa !27
  %t167 = load i64, ptr %l18, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i32, ptr %t170, i64 %t167
  %t172 = load i32, ptr %t171, !tbaa !33
  %t175 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i32, ptr %t176, i64 %t165
  store i32 %t172, ptr %t177, !tbaa !33
  br label %bb32
bb32:
  %t178 = load i64, ptr %l17, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l17, !tbaa !24
  br label %bb28
bb33:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/types:Table", ptr %t182, i32 0, i32 7
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H69e9af7ee32b7ff0c8685324094a29a4(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l102
  br label %bb34
bb34:
  %t187 = load i64, ptr %l102, !tbaa !24
  store i64 %t187, ptr %l11, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/types:Table", ptr %t188, i32 0, i32 7
  %t191 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H41a2935585cca595f0dd127aea20d09e(ptr %v0, ptr %v0, ptr %t190, { i64, ptr } %t191)
  br label %bb35
bb35:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/types:Table", ptr %t194, i32 0, i32 8
  %t197 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t196, i32 %t197)
  br label %bb36
bb36:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/types:Table", ptr %t200, i32 0, i32 9
  store ptr %t202, ptr %l110, !tbaa !29
  %t203 = icmp sge i64 0, 0
  br i1 %t203, label %bb37, label %bb38
bb37:
  %t205 = icmp sle i64 0, 2305843009213693951
  br i1 %t205, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969)
  unreachable
bb39:
  %t207 = mul i64 0, 4
  %t208 = insertvalue { i64, ptr } undef, i64 0, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t210 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H41a2935585cca595f0dd127aea20d09e(ptr %v0, ptr %v0, ptr %t210, { i64, ptr } %t209)
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969)
  unreachable
bb41:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/types:Table", ptr %t212, i32 0, i32 10
  %t215 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = extractvalue { i64, ptr } %t215, 0
  %t219 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t217, i64 %t218)
  %t220 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = extractvalue { i64, ptr } %t221, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t214, { i64, ptr } %t228, i64 %t229)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t233 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t237 = icmp sgt i64 %t235, 0
  br i1 %t237, label %bb44, label %bb45
bb44:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/types:Table", ptr %t239, i32 0, i32 9
  %t242 = load i64, ptr %l11, !tbaa !24
  %t245 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H37377f924b66ff741793959f79fef546(ptr %v0, ptr %s0, ptr %t241, i64 %t242)
  store { i64, ptr } %t245, ptr %l127
  br label %bb46
bb45:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb47
bb46:
  %t246 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 0
  %t249 = icmp eq i64 %t247, 0
  store i1 %t249, ptr %l123, !tbaa !21
  br label %bb47
bb47:
  %t251 = load i1, ptr %l123, !tbaa !21
  br i1 %t251, label %bb48, label %bb49
bb48:
  %t252 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t252, 0
  store i64 %t254, ptr %l131, !tbaa !24
  %t255 = load i64, ptr %l131, !tbaa !24
  %t256 = icmp sge i64 %t255, 0
  br i1 %t256, label %bb50, label %bb51
bb49:
  br label %bb67
bb50:
  %t258 = load i64, ptr %l131, !tbaa !24
  %t259 = icmp sle i64 %t258, 2305843009213693951
  br i1 %t259, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a)
  unreachable
bb52:
  %t261 = load i64, ptr %l131, !tbaa !24
  %t262 = mul i64 %t261, 4
  %t263 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t262)
  %t264 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t267 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 0
  store i64 %t269, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t271 = load i64, ptr %l21, !tbaa !24
  %t272 = load i64, ptr %l20, !tbaa !24
  %t275 = icmp sgt i64 %t271, %t272
  br i1 %t275, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a)
  unreachable
bb54:
  %t277 = load i64, ptr %l22, !tbaa !24
  %t279 = icmp sgt i64 %t277, 0
  br i1 %t279, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb59
bb56:
  %t281 = load i64, ptr %l21, !tbaa !24
  %t282 = load i64, ptr %l20, !tbaa !24
  %t285 = sub i64 %t281, %t282
  %t286 = load i64, ptr %l22, !tbaa !24
  %t289 = add i64 %t285, %t286
  %t291 = sub i64 %t289, 1
  %t292 = load i64, ptr %l22, !tbaa !24
  %t295 = sdiv i64 %t291, %t292
  store i64 %t295, ptr %l143, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb58
bb58:
  %t297 = load i64, ptr %l143, !tbaa !24
  store i64 %t297, ptr %l140, !tbaa !24
  br label %bb59
bb59:
  %t298 = load i64, ptr %l140, !tbaa !24
  store i64 %t298, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  %t299 = load i64, ptr %l24, !tbaa !24
  %t300 = load i64, ptr %l23, !tbaa !24
  %t303 = icmp slt i64 %t299, %t300
  %t305 = xor i1 %t303, true
  br i1 %t305, label %bb61, label %bb62
bb61:
  br label %bb65
bb62:
  br label %bb63
bb63:
  %t307 = load i64, ptr %l20, !tbaa !24
  %t308 = load i64, ptr %l24, !tbaa !24
  %t309 = load i64, ptr %l22, !tbaa !24
  %t312 = mul i64 %t308, %t309
  %t315 = add i64 %t307, %t312
  store i64 %t315, ptr %l25, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t317, ptr %l161, !tbaa !27
  %t318 = load i64, ptr %l25, !tbaa !24
  %t319 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t319, ptr %l163, !tbaa !27
  %t320 = load i64, ptr %l25, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr i32, ptr %t323, i64 %t320
  %t325 = load i32, ptr %t324, !tbaa !33
  %t328 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr i32, ptr %t329, i64 %t318
  store i32 %t325, ptr %t330, !tbaa !33
  br label %bb64
bb64:
  %t331 = load i64, ptr %l24, !tbaa !24
  %t333 = add i64 %t331, 1
  store i64 %t333, ptr %l24, !tbaa !24
  br label %bb60
bb65:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/types:Table", ptr %t335, i32 0, i32 9
  %t338 = load i64, ptr %l11, !tbaa !24
  %t339 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H6938bdf4910ae806791e4f0f97041ba1(ptr %v0, ptr %v0, ptr %t337, i64 %t338, { i64, ptr } %t339)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l172, !tbaa !29
  %t344 = load i64, ptr %l11, !tbaa !24
  %t347 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 24, i64 %t344, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t347, ptr %l175
  br label %bb68
bb68:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i32, ptr %l4, !tbaa !23
  %t352 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t348, i32 %t349)
  store i32 %t352, ptr %l178
  br label %bb69
bb69:
  %t353 = load i32, ptr %l178, !tbaa !23
  %t354 = add i32 %t353, 1
  %t355 = load ptr, ptr %l172, !tbaa !29
  %t356 = load %"compiler/types:data", ptr %l175
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t355, %"compiler/types:data" %t356, i32 %t354)
  store i32 %t358, ptr %l180
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t359 = load i32, ptr %l180, !tbaa !23
  store i32 %t359, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l6 = alloca %"compiler/types:data"
  %l9 = alloca i32
  %l11 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 29, i64 %t4, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = add i32 %t13, 1
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l6
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t14)
  store i32 %t18, ptr %l11
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i32, ptr %l11, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l11
  br label %bb4
bb3:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l8, !tbaa !23
  br label %bb5
bb4:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %l8, !tbaa !23
  br label %bb5
bb5:
  %t19 = load i32, ptr %l8, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t27 = trunc i64 29 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t30, i32 %t31)
  store i64 %t34, ptr %l21
  br label %bb9
bb8:
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t35, ptr %l18, !tbaa !23
  br label %bb10
bb9:
  %t37 = load i64, ptr %l21, !tbaa !24
  %t38 = trunc i64 %t37 to i32
  store i32 %t38, ptr %l18, !tbaa !23
  br label %bb10
bb10:
  %t41 = load i32, ptr %l18, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 36
  %t5 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i32
  %l14 = alloca ptr
  %l20 = alloca %"compiler/types:data"
  %l23 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l32 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp ne i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunLength(ptr %v0, ptr %t6)
  store i32 %t8, ptr %l9
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = icmp eq i32 %t9, %t10
  store i1 %t11, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l6, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t14, i32 %t15, i32 0)
  store i32 %t18, ptr %l13
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t24 = load i32, ptr %l2, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t30 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 19, i64 %t23, i64 %t26, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t30, ptr %l20
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l23
  br label %bb10
bb10:
  %t36 = load i32, ptr %l23, !tbaa !23
  %t37 = add i32 %t36, 1
  %t38 = load ptr, ptr %l14, !tbaa !29
  %t39 = load %"compiler/types:data", ptr %l20
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t38, %"compiler/types:data" %t39, i32 %t37)
  store i32 %t41, ptr %l25
  br label %bb11
bb11:
  %t42 = load i32, ptr %l25, !tbaa !23
  store i32 %t42, ptr %l3, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l1, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l28
  br label %bb12
bb12:
  %t48 = load i32, ptr %l1, !tbaa !23
  %t49 = load i32, ptr %l28, !tbaa !23
  %t51 = icmp ne i32 %t49, %t48
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/types:Table", ptr %t53, i32 0, i32 27
  store ptr %t55, ptr %l32, !tbaa !29
  %t56 = load i32, ptr %l3, !tbaa !23
  %t58 = sext i32 %t56 to i64
  store i64 %t58, ptr %l34, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l1, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l38
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t65 = load i32, ptr %l2, !tbaa !23
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = load i32, ptr %l38, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t66, i32 %t67, i32 %t65)
  store i32 %t69, ptr %l40
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = load i64, ptr %l34, !tbaa !24
  %t72 = load i32, ptr %l40, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t70, i64 %t71, i32 %t72)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t73 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t20, ptr %l13
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t26 = trunc i64 19 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l7, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 2
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i64
  %l15 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sle i32 %t1, 14
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr [15 x i64], ptr @G_2ecompiler_2ftypes_2eprimBits, i64 0, i64 %t7
  %t10 = load i64, ptr %t9, !tbaa !34
  store i64 %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t19 = trunc i64 31 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t22, i32 %t23)
  store i64 %t26, ptr %l15
  br label %bb7
bb6:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb7:
  %t27 = load i64, ptr %l15, !tbaa !24
  store i64 %t27, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t28 = load i64, ptr %l12, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eByAddress(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l28 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t15 = trunc i64 22 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t20 = trunc i64 23 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb24
bb8:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t25 = trunc i64 18 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l20
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l21
  br label %bb13
bb13:
  %t37 = load i32, ptr %l21, !range !{i32 0, i32 6}
  %t39 = trunc i64 0 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l10, !tbaa !21
  br label %bb24
bb14:
  %t42 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t44 = trunc i64 19 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l2, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l28
  br label %bb18
bb18:
  %t52 = load i32, ptr %l28, !tbaa !23
  %t53 = icmp ne i32 %t52, 0
  store i1 %t53, ptr %l10, !tbaa !21
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c5f0a3e3912a4ce3_83ad4b8f75c0f327)
  unreachable
bb24:
  %t55 = load i1, ptr %l10, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 3
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 3
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t9, ptr %lp2
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = load ptr, ptr %lp2
  store { i64, ptr } %t10, ptr %t11, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/types:Table", ptr %t12, i32 0, i32 3
  store i1 false, ptr %t14, !tbaa !21
  %t15 = load ptr, ptr %lp2
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 17
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v1, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = icmp sle i64 0, 2305843009213693951
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_b3c0df13ff143a95_992c52f0f53f0c49)
  unreachable
bb6:
  %t17 = mul i64 0, 4
  %t18 = insertvalue { i64, ptr } undef, i64 0, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t19, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b3c0df13ff143a95_992c52f0f53f0c49)
  unreachable
bb8:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l8 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i64
  %l31 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i32
  %l44 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i1
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca i1
  %l99 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  %t15 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t17 = trunc i64 25 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  %t20 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t22 = trunc i64 27 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  %t25 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t27 = trunc i64 15 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb89
bb11:
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t32 = trunc i64 18 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t35 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t37 = trunc i64 22 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t40 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t42 = trunc i64 23 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 33}
  %t49 = trunc i64 18 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb19, label %bb20
bb19:
  %t52 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l26, !tbaa !24
  br label %bb21
bb20:
  %t55 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l26, !tbaa !24
  br label %bb21
bb21:
  %t58 = load i64, ptr %l26, !tbaa !24
  %t59 = trunc i64 %t58 to i32
  %t61 = load ptr, ptr %l23, !tbaa !29
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t61, i32 %t59)
  store i1 %t63, ptr %l31
  br label %bb22
bb22:
  %t64 = load i1, ptr %l31, !tbaa !21
  store i1 %t64, ptr %l8, !tbaa !21
  br label %bb89
bb23:
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb38
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l34, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l1, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l37
  br label %bb27
bb27:
  %t76 = load ptr, ptr %l34, !tbaa !29
  %t77 = load i32, ptr %l37, !tbaa !23
  %t78 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t78, ptr %l38
  br label %bb28
bb28:
  %t79 = load i1, ptr %l38, !tbaa !21
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l42
  br label %bb31
bb30:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb37
bb31:
  %t85 = load i32, ptr %l42, !tbaa !23
  %t86 = icmp eq i32 %t85, 0
  br i1 %t86, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb36
bb33:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l45, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i32, ptr %l48, !tbaa !23
  %t96 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t96, ptr %l49
  br label %bb35
bb35:
  %t97 = load i1, ptr %l49, !tbaa !21
  store i1 %t97, ptr %l44, !tbaa !21
  br label %bb36
bb36:
  %t98 = load i1, ptr %l44, !tbaa !21
  store i1 %t98, ptr %l39, !tbaa !21
  br label %bb37
bb37:
  %t99 = load i1, ptr %l39, !tbaa !21
  store i1 %t99, ptr %l8, !tbaa !21
  br label %bb89
bb38:
  %t100 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t102 = trunc i64 20 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l52, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l55
  br label %bb42
bb42:
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load i32, ptr %l55, !tbaa !23
  %t113 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t113, ptr %l56
  br label %bb43
bb43:
  %t114 = load i1, ptr %l56, !tbaa !21
  store i1 %t114, ptr %l8, !tbaa !21
  br label %bb89
bb44:
  %t115 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t117 = trunc i64 21 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb60
bb47:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l59, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l1, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l62
  br label %bb48
bb48:
  %t126 = load ptr, ptr %l59, !tbaa !29
  %t127 = load i32, ptr %l62, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l63
  br label %bb49
bb49:
  %t129 = load i1, ptr %l63, !tbaa !21
  br i1 %t129, label %bb50, label %bb51
bb50:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l68
  br label %bb52
bb51:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb54
bb52:
  %t136 = load ptr, ptr %l65, !tbaa !29
  %t137 = load i32, ptr %l68, !tbaa !23
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t138, ptr %l69
  br label %bb53
bb53:
  %t139 = load i1, ptr %l69, !tbaa !21
  store i1 %t139, ptr %l64, !tbaa !21
  br label %bb54
bb54:
  %t140 = load i1, ptr %l64, !tbaa !21
  br i1 %t140, label %bb55, label %bb56
bb55:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l71, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l74
  br label %bb57
bb56:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb59
bb57:
  %t147 = load ptr, ptr %l71, !tbaa !29
  %t148 = load i32, ptr %l74, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t147, i32 %t148)
  store i1 %t149, ptr %l75
  br label %bb58
bb58:
  %t150 = load i1, ptr %l75, !tbaa !21
  store i1 %t150, ptr %l70, !tbaa !21
  br label %bb59
bb59:
  %t151 = load i1, ptr %l70, !tbaa !21
  store i1 %t151, ptr %l8, !tbaa !21
  br label %bb89
bb60:
  %t152 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t154 = trunc i64 24 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l78, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l1, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l81
  br label %bb64
bb64:
  %t163 = load ptr, ptr %l78, !tbaa !29
  %t164 = load i32, ptr %l81, !tbaa !23
  %t165 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t165, ptr %l82
  br label %bb65
bb65:
  %t166 = load i1, ptr %l82, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb89
bb66:
  %t167 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t169 = trunc i64 26 to i32
  %t170 = icmp eq i32 %t167, %t169
  br i1 %t170, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l85, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l88
  br label %bb70
bb70:
  %t178 = load ptr, ptr %l85, !tbaa !29
  %t179 = load i32, ptr %l88, !tbaa !23
  %t180 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t178, i32 %t179)
  store i1 %t180, ptr %l89
  br label %bb71
bb71:
  %t181 = load i1, ptr %l89, !tbaa !21
  store i1 %t181, ptr %l8, !tbaa !21
  br label %bb89
bb72:
  %t182 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t184 = trunc i64 29 to i32
  %t185 = icmp eq i32 %t182, %t184
  br i1 %t185, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l92, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l1, !tbaa !23
  %t192 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l95
  br label %bb76
bb76:
  %t193 = load ptr, ptr %l92, !tbaa !29
  %t194 = load i32, ptr %l95, !tbaa !23
  %t195 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t193, i32 %t194)
  store i1 %t195, ptr %l96
  br label %bb77
bb77:
  %t196 = load i1, ptr %l96, !tbaa !21
  store i1 %t196, ptr %l8, !tbaa !21
  br label %bb89
bb78:
  %t197 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t199 = trunc i64 30 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb84
bb81:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l99, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l1, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t207, ptr %l102
  br label %bb82
bb82:
  %t208 = load ptr, ptr %l99, !tbaa !29
  %t209 = load i32, ptr %l102, !tbaa !23
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t208, i32 %t209)
  store i1 %t210, ptr %l103
  br label %bb83
bb83:
  %t211 = load i1, ptr %l103, !tbaa !21
  store i1 %t211, ptr %l8, !tbaa !21
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_3a86b0904acb017a_fb1793104580b26e)
  unreachable
bb89:
  %t212 = load i1, ptr %l8, !tbaa !21
  store i1 %t212, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i64
  %l23 = alloca i32
  %l24 = alloca i64
  %l26 = alloca { i64, i64 }
  %l27 = alloca { i64, i64 }
  %l28 = alloca i32
  %l29 = alloca { i64, i64 }
  %l30 = alloca { i64, i64 }
  %l33 = alloca i32
  %l34 = alloca i64
  %l38 = alloca %"compiler/types:data"
  %l73 = alloca i64
  %l82 = alloca i64
  %l84 = alloca i64
  %l95 = alloca i32
  %l102 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l120 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca i1
  %l125 = alloca i1
  %l126 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca i32
  %l141 = alloca i32
  %l145 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca i32
  %l156 = alloca i32
  %l159 = alloca i64
  %l160 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i64
  %l168 = alloca i64
  %l175 = alloca ptr
  %l176 = alloca i32
  %l179 = alloca i32
  %l180 = alloca { i64, i64 }
  %l185 = alloca ptr
  %l186 = alloca i32
  %l189 = alloca i32
  %l190 = alloca { i64, i64 }
  %l197 = alloca i1
  %l200 = alloca ptr
  %l203 = alloca i32
  %l204 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca i32
  %l211 = alloca i32
  %l212 = alloca { i64, i64 }
  %l217 = alloca ptr
  %l218 = alloca i32
  %l221 = alloca i32
  %l222 = alloca { i64, i64 }
  %l233 = alloca i32
  %l236 = alloca i64
  %l242 = alloca i64
  %l245 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l38
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l38
  store %"compiler/types:data" %t6, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l5
  %t10 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  %t15 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t17 = trunc i64 17 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb161
bb7:
  %t20 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t22 = trunc i64 2 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb8, label %bb9
bb8:
  br label %bb34
bb9:
  %t25 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t27 = trunc i64 3 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb34
bb11:
  %t30 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb34
bb13:
  %t35 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t37 = trunc i64 5 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb14, label %bb15
bb14:
  br label %bb34
bb15:
  %t40 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t42 = trunc i64 6 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb34
bb17:
  %t45 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t47 = trunc i64 7 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb18, label %bb19
bb18:
  br label %bb34
bb19:
  %t50 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t52 = trunc i64 8 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb20, label %bb21
bb20:
  br label %bb34
bb21:
  %t55 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t57 = trunc i64 9 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb34
bb23:
  %t60 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t62 = trunc i64 10 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb24, label %bb25
bb24:
  br label %bb34
bb25:
  %t65 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t67 = trunc i64 11 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  %t70 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t72 = trunc i64 12 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  %t75 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t77 = trunc i64 13 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t80 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t82 = trunc i64 14 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = icmp ne i32 %t85, %t86
  br i1 %t89, label %bb35, label %bb36
bb35:
  %t91 = load i32, ptr %l1, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t95 = getelementptr [15 x i64], ptr @G_2ecompiler_2ftypes_2eprimBits, i64 0, i64 %t93
  %t96 = load i64, ptr %t95, !tbaa !34
  %t98 = sdiv i64 %t96, 8
  store i64 %t98, ptr %l73, !tbaa !24
  br label %bb37
bb36:
  store i64 1, ptr %l73, !tbaa !24
  br label %bb37
bb37:
  %t100 = load i64, ptr %l73, !tbaa !24
  store i64 %t100, ptr %l3, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb161
bb38:
  %t103 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t105 = trunc i64 31 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t108 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t111 = call i64 @compiler_2ftypes_2eIntBytes(i64 %t109)
  store i64 %t111, ptr %l82
  br label %bb42
bb42:
  %t112 = load i64, ptr %l82, !tbaa !24
  store i64 %t112, ptr %l6, !tbaa !24
  %t113 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = call i64 @compiler_2ftypes_2eIntBytes(i64 %t114)
  store i64 %t116, ptr %l84
  br label %bb43
bb43:
  %t117 = load i64, ptr %l84, !tbaa !24
  %t118 = load i64, ptr %l6, !tbaa !24
  store i64 %t118, ptr %l3, !tbaa !24
  store i64 %t117, ptr %l4, !tbaa !24
  br label %bb161
bb44:
  %t122 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t124 = trunc i64 16 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb161
bb48:
  %t131 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t133 = trunc i64 32 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb62
bb51:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t140, ptr %l95
  br label %bb52
bb52:
  %t141 = load i32, ptr %l95, !tbaa !23
  store i32 %t141, ptr %l10, !tbaa !23
  %t142 = load i32, ptr %l10, !tbaa !23
  %t144 = icmp eq i32 %t142, 5
  br i1 %t144, label %bb53, label %bb54
bb53:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb61
bb54:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l10, !tbaa !23
  %t154 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t150, i32 %t151)
  store i64 %t154, ptr %l102
  br label %bb55
bb55:
  %t155 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t156 = load i64, ptr %l102, !tbaa !24
  %t158 = icmp ne i64 %t156, %t155
  br i1 %t158, label %bb56, label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l10, !tbaa !23
  %t165 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t161, i32 %t162)
  store i64 %t165, ptr %l108
  br label %bb59
bb59:
  %t166 = load i64, ptr %l108, !tbaa !24
  store i64 %t166, ptr %l13, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l10, !tbaa !23
  %t171 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t167, i32 %t168)
  store i64 %t171, ptr %l111
  br label %bb60
bb60:
  %t172 = load i64, ptr %l111, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  store i64 %t173, ptr %l3, !tbaa !24
  store i64 %t172, ptr %l4, !tbaa !24
  br label %bb61
bb61:
  br label %bb161
bb62:
  %t177 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t179 = trunc i64 21 to i32
  %t180 = icmp eq i32 %t177, %t179
  br i1 %t180, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb161
bb66:
  %t186 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t188 = trunc i64 20 to i32
  %t189 = icmp eq i32 %t186, %t188
  br i1 %t189, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb80
bb69:
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l120, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l123
  br label %bb70
bb70:
  %t197 = load ptr, ptr %l120, !tbaa !29
  %t198 = load i32, ptr %l123, !tbaa !23
  %t199 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t197, i32 %t198)
  store i1 %t199, ptr %l124
  br label %bb71
bb71:
  %t200 = load i1, ptr %l124, !tbaa !21
  br i1 %t200, label %bb72, label %bb73
bb72:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb76
bb73:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l126, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l1, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l129
  br label %bb74
bb74:
  %t207 = load ptr, ptr %l126, !tbaa !29
  %t208 = load i32, ptr %l129, !tbaa !23
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t207, i32 %t208)
  store i32 %t209, ptr %l130
  br label %bb75
bb75:
  %t210 = load i32, ptr %l130, !range !{i32 0, i32 33}
  %t212 = trunc i64 29 to i32
  %t213 = icmp eq i32 %t210, %t212
  store i1 %t213, ptr %l125, !tbaa !21
  br label %bb76
bb76:
  %t215 = load i1, ptr %l125, !tbaa !21
  br i1 %t215, label %bb77, label %bb78
bb77:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb79
bb78:
  store i64 8, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb79
bb79:
  br label %bb161
bb80:
  %t224 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t226 = trunc i64 19 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb98
bb83:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i32, ptr %l1, !tbaa !23
  %t233 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t229, i32 %t230)
  store i32 %t233, ptr %l141
  br label %bb84
bb84:
  %t234 = load i32, ptr %l141, !tbaa !23
  %t235 = icmp eq i32 %t234, 0
  br i1 %t235, label %bb85, label %bb86
bb85:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb97
bb86:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l145, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l1, !tbaa !23
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t242, i32 %t243)
  store i32 %t246, ptr %l148
  br label %bb87
bb87:
  %t247 = load ptr, ptr %l145, !tbaa !29
  %t248 = load i32, ptr %l148, !tbaa !23
  %t249 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t247, i32 %t248)
  store i32 %t249, ptr %l149
  br label %bb88
bb88:
  %t250 = load i32, ptr %l149, !range !{i32 0, i32 33}
  %t252 = trunc i64 26 to i32
  %t253 = icmp eq i32 %t250, %t252
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb89, label %bb90
bb89:
  store i1 false, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l1, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t258, i32 %t259)
  store i32 %t262, ptr %l156
  br label %bb92
bb92:
  %t263 = load i32, ptr %l156, !tbaa !23
  store i32 %t263, ptr %l23, !tbaa !23
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l23, !tbaa !23
  %t268 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t264, i32 %t265)
  store i64 %t268, ptr %l159
  br label %bb93
bb93:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l160, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i32, ptr %l1, !tbaa !23
  %t274 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t270, i32 %t271)
  store i32 %t274, ptr %l163
  br label %bb94
bb94:
  %t275 = load ptr, ptr %l160, !tbaa !29
  %t276 = load i32, ptr %l163, !tbaa !23
  %t277 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t275, i32 %t276)
  store i64 %t277, ptr %l164
  br label %bb95
bb95:
  %t278 = load i64, ptr %l159, !tbaa !24
  %t279 = load i64, ptr %l164, !tbaa !24
  %t280 = mul i64 %t278, %t279
  store i64 %t280, ptr %l24, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l23, !tbaa !23
  %t286 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t282, i32 %t283)
  store i64 %t286, ptr %l168
  br label %bb96
bb96:
  %t287 = load i64, ptr %l168, !tbaa !24
  %t288 = load i64, ptr %l24, !tbaa !24
  store i64 %t288, ptr %l3, !tbaa !24
  store i64 %t287, ptr %l4, !tbaa !24
  br label %bb97
bb97:
  br label %bb161
bb98:
  %t292 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t294 = trunc i64 22 to i32
  %t295 = icmp eq i32 %t292, %t294
  br i1 %t295, label %bb99, label %bb100
bb99:
  br label %bb103
bb100:
  %t297 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t299 = trunc i64 23 to i32
  %t300 = icmp eq i32 %t297, %t299
  br i1 %t300, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l175, !tbaa !29
  %t303 = load i32, ptr %l1, !tbaa !23
  store i32 %t303, ptr %l176, !tbaa !23
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i32, ptr %l1, !tbaa !23
  %t308 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t304, i32 %t305)
  store i32 %t308, ptr %l179
  br label %bb104
bb104:
  %t309 = load ptr, ptr %l175, !tbaa !29
  %t310 = load i32, ptr %l176, !tbaa !23
  %t311 = load i32, ptr %l179, !tbaa !23
  %t312 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t309, i32 %t310, i32 %t311)
  store { i64, i64 } %t312, ptr %l180
  br label %bb105
bb105:
  %t313 = load { i64, i64 }, ptr %l180
  store { i64, i64 } %t313, ptr %l26
  %t314 = getelementptr { i64, i64 }, ptr %l26, i32 0, i32 0
  %t315 = load i64, ptr %t314, !tbaa !24
  store i64 %t315, ptr %l3, !tbaa !24
  %t317 = getelementptr { i64, i64 }, ptr %l26, i32 0, i32 1
  %t318 = load i64, ptr %t317, !tbaa !24
  store i64 %t318, ptr %l4, !tbaa !24
  br label %bb161
bb106:
  %t320 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t322 = trunc i64 24 to i32
  %t323 = icmp eq i32 %t320, %t322
  br i1 %t323, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l185, !tbaa !29
  %t326 = load i32, ptr %l1, !tbaa !23
  store i32 %t326, ptr %l186, !tbaa !23
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i32, ptr %l1, !tbaa !23
  %t331 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t327, i32 %t328)
  store i32 %t331, ptr %l189
  br label %bb110
bb110:
  %t332 = load ptr, ptr %l185, !tbaa !29
  %t333 = load i32, ptr %l186, !tbaa !23
  %t334 = load i32, ptr %l189, !tbaa !23
  %t335 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t332, i32 %t333, i32 %t334)
  store { i64, i64 } %t335, ptr %l190
  br label %bb111
bb111:
  %t336 = load { i64, i64 }, ptr %l190
  store { i64, i64 } %t336, ptr %l27
  %t337 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 0
  %t338 = load i64, ptr %t337, !tbaa !24
  store i64 %t338, ptr %l3, !tbaa !24
  %t340 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 1
  %t341 = load i64, ptr %t340, !tbaa !24
  store i64 %t341, ptr %l4, !tbaa !24
  br label %bb161
bb112:
  %t343 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t345 = trunc i64 18 to i32
  %t346 = icmp eq i32 %t343, %t345
  br i1 %t346, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb156
bb115:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i32, ptr %l1, !tbaa !23
  %t352 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t348, i32 %t349)
  store i1 %t352, ptr %l197
  br label %bb116
bb116:
  %t353 = load i1, ptr %l197, !tbaa !21
  %t354 = xor i1 %t353, true
  br i1 %t354, label %bb117, label %bb118
bb117:
  store i1 false, ptr %rv
  br label %ret
bb118:
  br label %bb119
bb119:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l200, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr %l1, !tbaa !23
  %t362 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t358, i32 %t359)
  store i32 %t362, ptr %l203
  br label %bb120
bb120:
  %t363 = load ptr, ptr %l200, !tbaa !29
  %t364 = load i32, ptr %l203, !tbaa !23
  %t365 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t363, i32 %t364)
  store i32 %t365, ptr %l204
  br label %bb121
bb121:
  %t366 = load i32, ptr %l204, !range !{i32 0, i32 6}
  store i32 %t366, ptr %l28
  %t367 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t369 = trunc i64 0 to i32
  %t370 = icmp eq i32 %t367, %t369
  br i1 %t370, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb127
bb124:
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l207, !tbaa !29
  %t373 = load i32, ptr %l1, !tbaa !23
  store i32 %t373, ptr %l208, !tbaa !23
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load i32, ptr %l1, !tbaa !23
  %t378 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t374, i32 %t375)
  store i32 %t378, ptr %l211
  br label %bb125
bb125:
  %t379 = load ptr, ptr %l207, !tbaa !29
  %t380 = load i32, ptr %l208, !tbaa !23
  %t381 = load i32, ptr %l211, !tbaa !23
  %t382 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t379, i32 %t380, i32 %t381)
  store { i64, i64 } %t382, ptr %l212
  br label %bb126
bb126:
  %t383 = load { i64, i64 }, ptr %l212
  store { i64, i64 } %t383, ptr %l29
  %t384 = getelementptr { i64, i64 }, ptr %l29, i32 0, i32 0
  %t385 = load i64, ptr %t384, !tbaa !24
  store i64 %t385, ptr %l3, !tbaa !24
  %t387 = getelementptr { i64, i64 }, ptr %l29, i32 0, i32 1
  %t388 = load i64, ptr %t387, !tbaa !24
  store i64 %t388, ptr %l4, !tbaa !24
  br label %bb155
bb127:
  %t390 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t392 = trunc i64 1 to i32
  %t393 = icmp eq i32 %t390, %t392
  br i1 %t393, label %bb128, label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb133
bb130:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l217, !tbaa !29
  %t396 = load i32, ptr %l1, !tbaa !23
  store i32 %t396, ptr %l218, !tbaa !23
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i32, ptr %l1, !tbaa !23
  %t401 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t397, i32 %t398)
  store i32 %t401, ptr %l221
  br label %bb131
bb131:
  %t402 = load ptr, ptr %l217, !tbaa !29
  %t403 = load i32, ptr %l218, !tbaa !23
  %t404 = load i32, ptr %l221, !tbaa !23
  %t405 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t402, i32 %t403, i32 %t404)
  store { i64, i64 } %t405, ptr %l222
  br label %bb132
bb132:
  %t406 = load { i64, i64 }, ptr %l222
  store { i64, i64 } %t406, ptr %l30
  %t407 = getelementptr { i64, i64 }, ptr %l30, i32 0, i32 0
  %t408 = load i64, ptr %t407, !tbaa !24
  store i64 %t408, ptr %l3, !tbaa !24
  %t410 = getelementptr { i64, i64 }, ptr %l30, i32 0, i32 1
  %t411 = load i64, ptr %t410, !tbaa !24
  store i64 %t411, ptr %l4, !tbaa !24
  br label %bb155
bb133:
  %t413 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t415 = trunc i64 2 to i32
  %t416 = icmp eq i32 %t413, %t415
  br i1 %t416, label %bb134, label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb137
bb136:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb155
bb137:
  %t422 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t424 = trunc i64 4 to i32
  %t425 = icmp eq i32 %t422, %t424
  br i1 %t425, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb148
bb140:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l1, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l233
  br label %bb141
bb141:
  %t432 = load i32, ptr %l233, !tbaa !23
  store i32 %t432, ptr %l33, !tbaa !23
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load i32, ptr %l33, !tbaa !23
  %t437 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t433, i32 %t434)
  store i64 %t437, ptr %l236
  br label %bb142
bb142:
  %t438 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t439 = load i64, ptr %l236, !tbaa !24
  %t441 = icmp ne i64 %t439, %t438
  br i1 %t441, label %bb143, label %bb144
bb143:
  store i1 false, ptr %rv
  br label %ret
bb144:
  br label %bb145
bb145:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr %l33, !tbaa !23
  %t448 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t444, i32 %t445)
  store i64 %t448, ptr %l242
  br label %bb146
bb146:
  %t449 = load i64, ptr %l242, !tbaa !24
  store i64 %t449, ptr %l34, !tbaa !24
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load i32, ptr %l33, !tbaa !23
  %t454 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t450, i32 %t451)
  store i64 %t454, ptr %l245
  br label %bb147
bb147:
  %t455 = load i64, ptr %l245, !tbaa !24
  %t456 = load i64, ptr %l34, !tbaa !24
  store i64 %t456, ptr %l3, !tbaa !24
  store i64 %t455, ptr %l4, !tbaa !24
  br label %bb155
bb148:
  %t460 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t462 = trunc i64 3 to i32
  %t463 = icmp eq i32 %t460, %t462
  br i1 %t463, label %bb149, label %bb150
bb149:
  br label %bb153
bb150:
  %t465 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t467 = trunc i64 5 to i32
  %t468 = icmp eq i32 %t465, %t467
  br i1 %t468, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb154
bb153:
  store i1 false, ptr %rv
  br label %ret
bb154:
  call void @__olang_check_failed(ptr @olang_loc_448c58e2e97e944f_f556e6dbd0c75243)
  unreachable
bb155:
  br label %bb161
bb156:
  br i1 true, label %bb157, label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb160
bb159:
  store i1 false, ptr %rv
  br label %ret
bb160:
  call void @__olang_check_failed(ptr @olang_loc_136e48f5d148640e_b95a40c005170ac2)
  unreachable
bb161:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/types:Table", ptr %t472, i32 0, i32 21
  %t475 = load i32, ptr %l1, !tbaa !23
  %t477 = sext i32 %t475 to i64
  %t478 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t474, i64 %t477, i64 %t478)
  br label %bb162
bb162:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/types:Table", ptr %t482, i32 0, i32 22
  %t485 = load i32, ptr %l1, !tbaa !23
  %t487 = sext i32 %t485 to i64
  %t488 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t484, i64 %t487, i64 %t488)
  br label %bb163
bb163:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  %t4 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 26, i64 %t4, i64 %a2, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l8
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t10, %"compiler/types:data" %t11, i32 1)
  store i32 %t12, ptr %l9
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l29 = alloca %"compiler/types:data"
  %l30 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 12
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/types:Table", ptr %t18, i32 0, i32 11
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l13
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t23 = load i64, ptr %l13, !tbaa !24
  store i64 %t23, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/types:Table", ptr %t24, i32 0, i32 11
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t29, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t26, { i64, ptr } %t40)
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/types:Table", ptr %t43, i32 0, i32 12
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/types:Table", ptr %t46, i32 0, i32 11
  %t49 = load i64, ptr %l2, !tbaa !24
  %t52 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load ptr, ptr %l20, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t55, i64 %t53)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l26, !tbaa !29
  %t58 = load i64, ptr %l2, !tbaa !24
  %t61 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 27, i64 %t58, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t61, ptr %l29
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l26, !tbaa !29
  %t63 = load %"compiler/types:data", ptr %l29
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t62, %"compiler/types:data" %t63, i32 1)
  store i32 %t64, ptr %l30
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i32, ptr %l30, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 2
  %t11 = load i32, ptr %t10, !range !{i32 0, i32 6}
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 3
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaredUnique(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 18 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 36
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb4:
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = sext i32 %t19 to i64
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t21, i64 %t20)
  store i1 %t23, ptr %l14
  br label %bb5
bb5:
  %t24 = load i1, ptr %l14, !tbaa !21
  store i1 %t24, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l7, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 18 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 35
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb4:
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = sext i32 %t19 to i64
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t21, i64 %t20)
  store i1 %t23, ptr %l14
  br label %bb5
bb5:
  %t24 = load i1, ptr %l14, !tbaa !21
  store i1 %t24, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l7, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDepth(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = sext i32 %t6 to i64
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edestructs(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDtorWritten(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 3
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l57 = alloca i32
  %l62 = alloca i32
  %l64 = alloca ptr
  %l67 = alloca i32
  %l72 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca { i64, ptr }
  %l102 = alloca i32
  %l104 = alloca ptr
  %l107 = alloca i32
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l16
  br label %bb2
bb2:
  %t8 = load i32, ptr %l16, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l3
  %t9 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t11 = trunc i64 18 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb39
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l19, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l22
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l19, !tbaa !29
  %t21 = load i32, ptr %l22, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l23
  br label %bb7
bb7:
  %t23 = load i32, ptr %l23, !range !{i32 0, i32 6}
  store i32 %t23, ptr %l4
  %t24 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t26 = trunc i64 0 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l26, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l29
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = load i32, ptr %l29, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t35, i32 %t36)
  store { i64, ptr } %t37, ptr %l30
  br label %bb12
bb12:
  %t38 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 %t52
  %t57 = load i32, ptr %t56, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t57)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb13
bb19:
  br label %bb38
bb20:
  %t66 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t68 = trunc i64 1 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l46, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l1, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l49
  br label %bb24
bb24:
  %t77 = load ptr, ptr %l46, !tbaa !29
  %t78 = load i32, ptr %l49, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l50
  br label %bb25
bb25:
  %t80 = load { i64, ptr }, ptr %l50, !tbaa !27
  call void @compiler_2ftypes_2epushPayloads(ptr %v0, ptr %s0, { i64, ptr } %t80, ptr %l2)
  br label %bb26
bb26:
  br label %bb38
bb27:
  %t82 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t84 = trunc i64 4 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  store ptr %l2, ptr %l54, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l1, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l57
  br label %bb31
bb31:
  %t92 = load ptr, ptr %l54, !tbaa !29
  %t93 = load i32, ptr %l57, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t92, i32 %t93)
  br label %bb32
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_cb508a25d2891980_42113325dd63632c)
  unreachable
bb38:
  br label %bb86
bb39:
  %t94 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t96 = trunc i64 19 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb49
bb42:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l1, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t99, i32 %t100)
  store i32 %t103, ptr %l62
  br label %bb43
bb43:
  %t104 = load i32, ptr %l62, !tbaa !23
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb44, label %bb45
bb44:
  store ptr %l2, ptr %l64, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l67
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t112 = load ptr, ptr %l64, !tbaa !29
  %t113 = load i32, ptr %l67, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t112, i32 %t113)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb86
bb49:
  %t114 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t116 = trunc i64 22 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb50, label %bb51
bb50:
  br label %bb54
bb51:
  %t119 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t121 = trunc i64 23 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb64
bb54:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l72, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l1, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l75
  br label %bb55
bb55:
  %t130 = load ptr, ptr %l72, !tbaa !29
  %t131 = load i32, ptr %l75, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t130, i32 %t131)
  store { i64, ptr } %t132, ptr %l76
  br label %bb56
bb56:
  %t133 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t133, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l11, !tbaa !24
  br label %bb57
bb57:
  %t138 = load i64, ptr %l10, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb58, label %bb59
bb58:
  br label %bb63
bb59:
  br label %bb60
bb60:
  %t146 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t146, ptr %l83, !tbaa !27
  %t147 = load i64, ptr %l10, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i32, ptr %t150, i64 %t147
  %t152 = load i32, ptr %t151, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t152)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t157 = load i64, ptr %l10, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l10, !tbaa !24
  br label %bb57
bb63:
  br label %bb86
bb64:
  %t161 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t163 = trunc i64 24 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb71
bb67:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l92, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l1, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l95
  br label %bb68
bb68:
  %t172 = load ptr, ptr %l92, !tbaa !29
  %t173 = load i32, ptr %l95, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t172, i32 %t173)
  store { i64, ptr } %t174, ptr %l96
  br label %bb69
bb69:
  %t175 = load { i64, ptr }, ptr %l96, !tbaa !27
  call void @compiler_2ftypes_2epushPayloads(ptr %v0, ptr %s0, { i64, ptr } %t175, ptr %l2)
  br label %bb70
bb70:
  br label %bb86
bb71:
  %t177 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t179 = trunc i64 32 to i32
  %t180 = icmp eq i32 %t177, %t179
  br i1 %t180, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb81
bb74:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l102
  br label %bb75
bb75:
  %t187 = load i32, ptr %l102, !tbaa !23
  %t188 = icmp ne i32 %t187, 5
  br i1 %t188, label %bb76, label %bb77
bb76:
  store ptr %l2, ptr %l104, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l1, !tbaa !23
  %t194 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l107
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t195 = load ptr, ptr %l104, !tbaa !29
  %t196 = load i32, ptr %l107, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t195, i32 %t196)
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_4d47e5476b23fa11_4ed9625d853ee5dd)
  unreachable
bb86:
  %t198 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t198, ptr %l109
  br label %bb87
bb87:
  %t199 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t199, ptr %l110, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  store i64 %t201, ptr %l111, !tbaa !24
  %t202 = load i64, ptr %l111, !tbaa !24
  %t203 = mul i64 %t202, 4
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  %t205 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l112, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l111, !tbaa !24
  %t212 = mul i64 %t211, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t208, ptr %t210, i64 %t212, i1 false)
  %t213 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t213, ptr %l110, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t214 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t214, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEnds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 18 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 37
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb4:
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = sext i32 %t19 to i64
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t21, i64 %t20)
  store i1 %t23, ptr %l14
  br label %bb5
bb5:
  %t24 = load i1, ptr %l14, !tbaa !21
  store i1 %t24, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l7, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 32 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 19
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H5a37a20f375ed653adc00b592f5745cf(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l7, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 28 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  %t16 = sub i64 0, 1
  store i64 %t16, ptr %l7, !tbaa !65
  br label %bb5
bb4:
  %t18 = load i64, ptr %l10, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !65
  br label %bb5
bb5:
  %t20 = load i64, ptr %l7, !tbaa !65
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 28 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = trunc i64 %t18 to i32
  store i32 %t19, ptr %l7, !tbaa !23
  br label %bb5
bb5:
  %t22 = load i32, ptr %l7, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrRepr(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 19
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H08d487c91a3409a786f6b7c534acefc5(ptr %v0, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  store i32 %t12, ptr %l2, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  br label %bb4
bb4:
  %t15 = load i32, ptr %l2, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSet(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca %"compiler/types:data"
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l2, !tbaa !29
  %t4 = sext i32 %a1 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 30, i64 %t4, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = load %"compiler/types:data", ptr %l6
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t8, %"compiler/types:data" %t9, i32 1)
  store i32 %t10, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 30 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  store i32 0, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = trunc i64 %t16 to i32
  store i32 %t17, ptr %l7, !tbaa !23
  br label %bb5
bb5:
  %t20 = load i32, ptr %l7, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrVal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca %"compiler/types:data"
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l2, !tbaa !29
  %t4 = sext i32 %a1 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 32, i64 %t4, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = load %"compiler/types:data", ptr %l6
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t8, %"compiler/types:data" %t9, i32 1)
  store i32 %t10, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 32 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  store i32 0, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = trunc i64 %t16 to i32
  store i32 %t17, ptr %l7, !tbaa !23
  br label %bb5
bb5:
  %t20 = load i32, ptr %l7, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 18
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H4ee179d696ae959fbb722da89c7f46de(ptr %v0, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  store i32 %t12, ptr %l2, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i32 -1, ptr %l2, !tbaa !23
  br label %bb4
bb4:
  %t13 = load i32, ptr %l2, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  %t4 = sext i32 %a1 to i64
  %t10 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 28, i64 %t4, i64 %a2, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load %"compiler/types:data", ptr %l9
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t11, %"compiler/types:data" %t12, i32 1)
  store i32 %t13, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i32, ptr %l10, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFindDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 15
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H25f20ec7bc3952e7f71d4b5fc38b1e45(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  store i32 %t12, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, i32 } zeroinitializer, i32 %t21, 0
  store { i32, i32 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load i32, ptr %l2, !tbaa !23
  %t25 = insertvalue { i32, i32 } zeroinitializer, i32 %t24, 1
  store { i32, i32 } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load i32, ptr %l12, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t27 = trunc i64 18 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb11
bb9:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i32, ptr %l22, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l23
  br label %bb10
bb10:
  %t39 = load i32, ptr %l23, !range !{i32 0, i32 6}
  %t41 = trunc i64 5 to i32
  %t42 = icmp eq i32 %t39, %t41
  store i1 %t42, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l18, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l23 = alloca i32
  %l25 = alloca i64
  %l31 = alloca ptr
  %l43 = alloca %"compiler/types:data"
  %l46 = alloca i32
  %l49 = alloca i32
  %l52 = alloca i32
  %l55 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %l67 = alloca ptr
  %l69 = alloca i64
  %l76 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  store i32 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i32, ptr %l15, !tbaa !23
  store i32 %t6, ptr %l8, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l18
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = load i32, ptr %l18, !tbaa !23
  %t15 = icmp sgt i32 %t13, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t22 = load i32, ptr %l23, !tbaa !23
  store i32 %t22, ptr %l8, !tbaa !23
  br label %bb6
bb6:
  %t23 = load i1, ptr %l6, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  store i64 %t25, ptr %l25, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t27 = load i32, ptr %l7, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t31 = shl i64 %t29, 8
  %t32 = load i64, ptr %l25, !tbaa !24
  %t34 = or i64 %t32, %t31
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l31, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t40 = load i32, ptr %l2, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = load i32, ptr %l3, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t46 = load i32, ptr %l4, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t49 = load i64, ptr %l5, !tbaa !24
  %t58 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 21, i64 %t39, i64 %t42, i64 %t45, i64 %t48, i64 %t49, i64 %t34)
  store %"compiler/types:data" %t58, ptr %l43
  br label %bb10
bb10:
  %t59 = load i32, ptr %l8, !tbaa !23
  %t61 = add i32 %t59, 1
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = load %"compiler/types:data", ptr %l43
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t62, %"compiler/types:data" %t63, i32 %t61)
  store i32 %t65, ptr %l46
  br label %bb11
bb11:
  %t66 = load i32, ptr %l46, !tbaa !23
  store i32 %t66, ptr %l10, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l49
  br label %bb12
bb12:
  %t72 = load i32, ptr %l49, !tbaa !23
  store i32 %t72, ptr %l11, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l2, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l52
  br label %bb13
bb13:
  %t78 = load i32, ptr %l52, !tbaa !23
  store i32 %t78, ptr %l12, !tbaa !23
  %t79 = load i32, ptr %l4, !tbaa !23
  %t81 = icmp ne i32 %t79, 0
  br i1 %t81, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb16
bb15:
  %t83 = load i64, ptr %l5, !tbaa !24
  %t85 = icmp ne i64 %t83, 0
  store i1 %t85, ptr %l55, !tbaa !21
  br label %bb16
bb16:
  %t87 = load i1, ptr %l55, !tbaa !21
  br i1 %t87, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb19
bb18:
  %t88 = load i32, ptr %l11, !tbaa !23
  %t89 = load i32, ptr %l1, !tbaa !23
  %t92 = icmp ne i32 %t88, %t89
  store i1 %t92, ptr %l58, !tbaa !21
  br label %bb19
bb19:
  %t94 = load i1, ptr %l58, !tbaa !21
  br i1 %t94, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb22
bb21:
  %t95 = load i32, ptr %l12, !tbaa !23
  %t96 = load i32, ptr %l2, !tbaa !23
  %t99 = icmp ne i32 %t95, %t96
  store i1 %t99, ptr %l62, !tbaa !21
  br label %bb22
bb22:
  %t101 = load i1, ptr %l62, !tbaa !21
  br i1 %t101, label %bb23, label %bb24
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/types:Table", ptr %t102, i32 0, i32 27
  store ptr %t104, ptr %l67, !tbaa !29
  %t105 = load i32, ptr %l10, !tbaa !23
  %t107 = sext i32 %t105 to i64
  store i64 %t107, ptr %l69, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l11, !tbaa !23
  %t110 = load i32, ptr %l12, !tbaa !23
  %t111 = load i32, ptr %l3, !tbaa !23
  %t112 = load i1, ptr %l6, !tbaa !21
  %t113 = load i32, ptr %l7, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t108, i32 %t109, i32 %t110, i32 %t111, i32 0, i64 0, i1 %t112, i32 %t113)
  store i32 %t120, ptr %l76
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t121 = load ptr, ptr %l67, !tbaa !29
  %t122 = load i64, ptr %l69, !tbaa !24
  %t123 = load i32, ptr %l76, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t121, i64 %t122, i32 %t123)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t124 = load i32, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t124, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l10 = alloca %"compiler/types:data"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t11, i32 %t12)
  store %"compiler/types:data" %t15, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t16 = getelementptr %"compiler/types:data", ptr %l10, i32 0, i32 6
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t21 = and i64 %t17, %t18
  %t23 = icmp ne i64 %t21, 0
  store i1 %t23, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l7, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca %"compiler/types:data"
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t11, i32 %t12)
  store %"compiler/types:data" %t15, ptr %l10
  br label %bb4
bb3:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t16, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  %t18 = getelementptr %"compiler/types:data", ptr %l10, i32 0, i32 6
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = ashr i64 %t19, 8
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l7, !tbaa !23
  br label %bb5
bb5:
  %t26 = load i32, ptr %l7, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  %t29 = icmp ne i32 %t25, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb2
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l9 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l53 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i8
  %l80 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i32
  %l87 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i1
  %l101 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i1
  %l108 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l117 = alloca i32
  %l118 = alloca i1
  %l121 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca i1
  %l128 = alloca ptr
  %l131 = alloca i32
  %l132 = alloca i1
  %l135 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i32
  %l144 = alloca i8
  %l146 = alloca i8
  %l147 = alloca ptr
  %l150 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t9 = trunc i64 32 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/types:Table", ptr %t12, i32 0, i32 19
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H5a37a20f375ed653adc00b592f5745cf(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l15
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l20
  br label %bb7
bb6:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i32, ptr %l20, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t28, ptr %l21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l21, !tbaa !21
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l24
  br label %bb11
bb11:
  %t36 = load i1, ptr %l24, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t38 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t40 = trunc i64 20 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb17
bb16:
  %t43 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t45 = trunc i64 21 to i32
  %t46 = icmp eq i32 %t43, %t45
  store i1 %t46, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t48 = load i1, ptr %l28, !tbaa !21
  br i1 %t48, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb20
bb19:
  %t49 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t51 = trunc i64 25 to i32
  %t52 = icmp eq i32 %t49, %t51
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb23
bb22:
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t57 = trunc i64 29 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t64 = trunc i64 18 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t69 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t71 = trunc i64 19 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  store i1 %t74, ptr %l41, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb30, label %bb31
bb30:
  %t77 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t79 = trunc i64 22 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb33, label %bb34
bb33:
  %t85 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t87 = trunc i64 23 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t92 = load i1, ptr %l49, !tbaa !21
  br i1 %t92, label %bb36, label %bb37
bb36:
  %t93 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t95 = trunc i64 24 to i32
  %t96 = icmp eq i32 %t93, %t95
  %t98 = xor i1 %t96, true
  store i1 %t98, ptr %l53, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb38
bb38:
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb39, label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t102 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb42, label %bb43
bb42:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l63
  br label %bb44
bb43:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb45
bb44:
  %t112 = load i1, ptr %l63, !tbaa !21
  %t113 = xor i1 %t112, true
  store i1 %t113, ptr %l60, !tbaa !21
  br label %bb45
bb45:
  %t115 = load i1, ptr %l60, !tbaa !21
  br i1 %t115, label %bb46, label %bb47
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l1, !tbaa !23
  %t121 = call i8 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsState(ptr %v0, ptr %t117, i32 %t118)
  store i8 %t121, ptr %l68
  br label %bb49
bb49:
  %t122 = load i8, ptr %l68, !tbaa !22
  store i8 %t122, ptr %l3, !tbaa !22
  %t123 = load i8, ptr %l3, !tbaa !22
  %t125 = icmp ne i8 %t123, 0
  br i1 %t125, label %bb50, label %bb51
bb50:
  %t127 = load i8, ptr %l3, !tbaa !22
  %t129 = icmp eq i8 %t127, 3
  store i1 %t129, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %t131, i32 %t132, i8 1)
  br label %bb53
bb53:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/types:Table", ptr %t135, i32 0, i32 33
  %t138 = load i1, ptr %t137, !tbaa !21
  store i1 %t138, ptr %l4, !tbaa !21
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/types:Table", ptr %t140, i32 0, i32 33
  store i1 false, ptr %t142, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  %t143 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t145 = trunc i64 18 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb82
bb56:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l80, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l83
  br label %bb57
bb57:
  %t154 = load ptr, ptr %l80, !tbaa !29
  %t155 = load i32, ptr %l83, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t156, ptr %l84
  br label %bb58
bb58:
  %t157 = load i32, ptr %l84, !range !{i32 0, i32 6}
  store i32 %t157, ptr %l6
  %t158 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t160 = trunc i64 0 to i32
  %t161 = icmp eq i32 %t158, %t160
  br i1 %t161, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l87, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l1, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t164, i32 %t165)
  store i32 %t168, ptr %l90
  br label %bb62
bb62:
  %t169 = load ptr, ptr %l87, !tbaa !29
  %t170 = load i32, ptr %l90, !tbaa !23
  %t171 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t169, i32 %t170, i1 false, i1 true)
  store i1 %t171, ptr %l91
  br label %bb63
bb63:
  %t172 = load i1, ptr %l91, !tbaa !21
  store i1 %t172, ptr %l5, !tbaa !21
  br label %bb81
bb64:
  %t173 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t175 = trunc i64 1 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l94, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l1, !tbaa !23
  %t183 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t179, i32 %t180)
  store i32 %t183, ptr %l97
  br label %bb68
bb68:
  %t184 = load ptr, ptr %l94, !tbaa !29
  %t185 = load i32, ptr %l97, !tbaa !23
  %t186 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t184, i32 %t185, i1 true, i1 true)
  store i1 %t186, ptr %l98
  br label %bb69
bb69:
  %t187 = load i1, ptr %l98, !tbaa !21
  store i1 %t187, ptr %l5, !tbaa !21
  br label %bb81
bb70:
  %t188 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t190 = trunc i64 4 to i32
  %t191 = icmp eq i32 %t188, %t190
  br i1 %t191, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb76
bb73:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l101, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l104
  br label %bb74
bb74:
  %t199 = load ptr, ptr %l101, !tbaa !29
  %t200 = load i32, ptr %l104, !tbaa !23
  %t201 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t199, i32 %t200)
  store i1 %t201, ptr %l105
  br label %bb75
bb75:
  %t202 = load i1, ptr %l105, !tbaa !21
  store i1 %t202, ptr %l5, !tbaa !21
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_d3e704bcd06f7d56_ed5a4209a5557c8a)
  unreachable
bb81:
  br label %bb116
bb82:
  %t203 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t205 = trunc i64 19 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb93
bb85:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l108, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l1, !tbaa !23
  %t213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t209, i32 %t210)
  store i32 %t213, ptr %l111
  br label %bb86
bb86:
  %t214 = load ptr, ptr %l108, !tbaa !29
  %t215 = load i32, ptr %l111, !tbaa !23
  %t216 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t214, i32 %t215)
  store i1 %t216, ptr %l112
  br label %bb87
bb87:
  %t217 = load i1, ptr %l112, !tbaa !21
  br i1 %t217, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb92
bb89:
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l114, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l1, !tbaa !23
  %t223 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t219, i32 %t220)
  store i32 %t223, ptr %l117
  br label %bb90
bb90:
  %t224 = load ptr, ptr %l114, !tbaa !29
  %t225 = load i32, ptr %l117, !tbaa !23
  %t226 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t224, i32 %t225)
  store i1 %t226, ptr %l118
  br label %bb91
bb91:
  %t227 = load i1, ptr %l118, !tbaa !21
  store i1 %t227, ptr %l113, !tbaa !21
  br label %bb92
bb92:
  %t228 = load i1, ptr %l113, !tbaa !21
  store i1 %t228, ptr %l5, !tbaa !21
  br label %bb116
bb93:
  %t229 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t231 = trunc i64 22 to i32
  %t232 = icmp eq i32 %t229, %t231
  br i1 %t232, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l121, !tbaa !29
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l1, !tbaa !23
  %t239 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t235, i32 %t236)
  store i32 %t239, ptr %l124
  br label %bb97
bb97:
  %t240 = load ptr, ptr %l121, !tbaa !29
  %t241 = load i32, ptr %l124, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t240, i32 %t241, i1 false, i1 false)
  store i1 %t242, ptr %l125
  br label %bb98
bb98:
  %t243 = load i1, ptr %l125, !tbaa !21
  store i1 %t243, ptr %l5, !tbaa !21
  br label %bb116
bb99:
  %t244 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t246 = trunc i64 23 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l128, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l1, !tbaa !23
  %t254 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t254, ptr %l131
  br label %bb103
bb103:
  %t255 = load ptr, ptr %l128, !tbaa !29
  %t256 = load i32, ptr %l131, !tbaa !23
  %t257 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t255, i32 %t256, i1 false, i1 true)
  store i1 %t257, ptr %l132
  br label %bb104
bb104:
  %t258 = load i1, ptr %l132, !tbaa !21
  store i1 %t258, ptr %l5, !tbaa !21
  br label %bb116
bb105:
  %t259 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t261 = trunc i64 24 to i32
  %t262 = icmp eq i32 %t259, %t261
  br i1 %t262, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb111
bb108:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l135, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load i32, ptr %l1, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l138
  br label %bb109
bb109:
  %t270 = load ptr, ptr %l135, !tbaa !29
  %t271 = load i32, ptr %l138, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t270, i32 %t271, i1 true, i1 true)
  store i1 %t272, ptr %l139
  br label %bb110
bb110:
  %t273 = load i1, ptr %l139, !tbaa !21
  store i1 %t273, ptr %l5, !tbaa !21
  br label %bb116
bb111:
  br i1 true, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_b4be3b7b6cfde177_2b1bada5393bc0cb)
  unreachable
bb116:
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l140, !tbaa !29
  %t275 = load i32, ptr %l1, !tbaa !23
  store i32 %t275, ptr %l141, !tbaa !23
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/types:Table", ptr %t276, i32 0, i32 33
  %t279 = load i1, ptr %t278, !tbaa !21
  br i1 %t279, label %bb117, label %bb118
bb117:
  store i8 0, ptr %l144, !tbaa !22
  br label %bb122
bb118:
  %t281 = load i1, ptr %l5, !tbaa !21
  br i1 %t281, label %bb119, label %bb120
bb119:
  store i8 3, ptr %l146, !tbaa !22
  br label %bb121
bb120:
  store i8 2, ptr %l146, !tbaa !22
  br label %bb121
bb121:
  %t283 = load i8, ptr %l146, !tbaa !22
  store i8 %t283, ptr %l144, !tbaa !22
  br label %bb122
bb122:
  %t284 = load ptr, ptr %l140, !tbaa !29
  %t285 = load i32, ptr %l141, !tbaa !23
  %t286 = load i8, ptr %l144, !tbaa !22
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %t284, i32 %t285, i8 %t286)
  br label %bb123
bb123:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l147, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/types:Table", ptr %t288, i32 0, i32 33
  %t291 = load i1, ptr %t290, !tbaa !21
  br i1 %t291, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb126
bb125:
  %t293 = load i1, ptr %l4, !tbaa !21
  store i1 %t293, ptr %l150, !tbaa !21
  br label %bb126
bb126:
  %t295 = load i1, ptr %l150, !tbaa !21
  %t296 = load ptr, ptr %l147, !tbaa !29
  %t297 = getelementptr %"compiler/types:Table", ptr %t296, i32 0, i32 33
  store i1 %t295, ptr %t297, !tbaa !21
  %t298 = load i1, ptr %l5, !tbaa !21
  store i1 %t298, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIntType(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 34
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 %a1, ptr %l5, !tbaa !24
  br i1 %a2, label %bb1, label %bb2
bb1:
  store i64 128, ptr %l7, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = add i64 %t7, %t8
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t10, i64 %t9)
  store i32 %t12, ptr %l9
  br label %bb4
bb4:
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb4:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load i32, ptr %l11, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t22 = trunc i64 29 to i32
  %t23 = icmp eq i32 %t20, %t22
  store i1 %t23, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l7, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 32 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 11
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 14
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l4 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i32
  %rv = alloca i1
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 3
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 10
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb7
bb5:
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb6
bb6:
  %t15 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t17 = trunc i64 31 to i32
  %t18 = icmp eq i32 %t15, %t17
  store i1 %t18, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l7, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i64
  %l14 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t19 = and i64 %t17, %t16
  %t21 = icmp ne i64 %t19, 0
  store i1 %t21, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l7, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l17
  br label %bb8
bb8:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l4 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i32
  %rv = alloca i1
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 3
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 14
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb7
bb5:
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb6
bb6:
  %t15 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t17 = trunc i64 31 to i32
  %t18 = icmp eq i32 %t15, %t17
  store i1 %t18, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l7, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i64, ptr @G_2ecompiler_2ftypes_2eSpread, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t19 = and i64 %t17, %t16
  %t21 = icmp ne i64 %t19, 0
  store i1 %t21, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l7, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i32
  %l13 = alloca i1
  %l16 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 7
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 10
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb11
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb6
bb6:
  %t15 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t17 = trunc i64 31 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t20, i32 %t21)
  store i64 %t24, ptr %l16
  br label %bb9
bb8:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb10
bb9:
  %t25 = load i64, ptr %l16, !tbaa !24
  %t26 = icmp eq i64 %t25, 0
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l13, !tbaa !21
  store i1 %t28, ptr %l7, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l7, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 5
  %t6 = sext i32 %a1 to i64
  %t9 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H61b120fbdcc010be1bedf2507e848f7c(ptr %v0, ptr %v1, ptr %t3, i64 %t6)
  store { i64, ptr } %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !range !{i32 0, i32 33}
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 20
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l24 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l63 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/types:Table", ptr %t8, i32 0, i32 6
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  %t15 = extractvalue { i32, i32 } %t14, 1
  %t16 = extractvalue { i32, i32 } %t14, 0
  store i32 %t16, ptr %l19
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18, !prof !99
ok.18:
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t19 = load i32, ptr %l18, !tbaa !23
  store i32 %t19, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i32 -1, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t20 = load i32, ptr %l14, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  %t21 = load i32, ptr %l2, !tbaa !23
  %t23 = icmp sge i32 %t21, 0
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load i32, ptr %l2, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp sle i64 %t33, 2305843009213693951
  br i1 %t34, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_aca21d9f8d110f21_d35bd7e73631d7ed)
  unreachable
bb13:
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = mul i64 %t36, 4
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_aca21d9f8d110f21_d35bd7e73631d7ed)
  unreachable
bb15:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb20
bb17:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l36, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb19
bb19:
  %t72 = load i64, ptr %l36, !tbaa !24
  store i64 %t72, ptr %l33, !tbaa !24
  br label %bb20
bb20:
  %t73 = load i64, ptr %l33, !tbaa !24
  store i64 %t73, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t94, ptr %l56, !tbaa !27
  %t95 = load i64, ptr %l9, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t103 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i32, ptr %t104, i64 %t93
  store i32 %t100, ptr %t105, !tbaa !33
  br label %bb25
bb25:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb21
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/types:Table", ptr %t110, i32 0, i32 5
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H2b3955a94f91e668ac3bcd9fa517bb83(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l63
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  %t116 = trunc i64 %t115 to i32
  store i32 %t116, ptr %l2, !tbaa !23
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/types:Table", ptr %t119, i32 0, i32 5
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H5d6217f1de626e258ec0008385e9bf9b(ptr %v0, ptr %v0, ptr %t121, { i64, ptr } %t122)
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/types:Table", ptr %t125, i32 0, i32 6
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v0, ptr %t127, { i64, ptr } %t128, i32 %t129)
  br label %bb29
bb29:
  %t133 = load i32, ptr %l2, !tbaa !23
  store i32 %t133, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = mul i64 1, 4
  %t4 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t3)
  %t5 = insertvalue { i64, ptr } undef, i64 1, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t4, 1
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i32, ptr %t9, i64 0
  store i32 %a1, ptr %t10, !tbaa !33
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } %t12)
  store i32 %t13, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i32, ptr %l5, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/types:Table", ptr %t5, i32 0, i32 26
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store { i64, ptr } %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 26
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l14
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/types:Table", ptr %t25, i32 0, i32 26
  store ptr %t27, ptr %l16, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l20
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t41 = load ptr, ptr %l16, !tbaa !29
  %t42 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v0, ptr %t41, i64 %t42, { i64, ptr } %t40)
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/types:Table", ptr %t44, i32 0, i32 26
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %t46, i64 %t47)
  store { i64, ptr } %t50, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkCopy(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 35
  %t6 = sext i32 %a1 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t6, i1 true)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkEnds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 37
  %t6 = sext i32 %a1 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t6, i1 true)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkUnique(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 36
  %t6 = sext i32 %a1 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t6, i1 true)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNameErrVal(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 18
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H830566a038befb7310211b752210e58f(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 18
  %t14 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H010f1f1ff4e5a3a6ef2d904187315b0d(ptr %v0, ptr %t13, i32 %t14, i32 %a2)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l13 = alloca %"compiler/types:data"
  %l16 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t10 = sext i32 %a1 to i64
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t17 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 18, i64 %t10, i64 %t13, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t17, ptr %l13
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l16
  br label %bb3
bb3:
  %t23 = load i32, ptr %l16, !tbaa !23
  %t24 = add i32 %t23, 1
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load %"compiler/types:data", ptr %l13
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t25, %"compiler/types:data" %t26, i32 %t24)
  store i32 %t28, ptr %l18
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l18, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i64
  %l10 = alloca %"compiler/types:data"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t11, i32 %t12)
  store %"compiler/types:data" %t15, ptr %l10
  br label %bb4
bb3:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb5
bb4:
  %t16 = getelementptr %"compiler/types:data", ptr %l10, i32 0, i32 5
  %t17 = load i64, ptr %t16, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t19 = load i64, ptr %l7, !tbaa !24
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l12 = alloca %"compiler/types:data"
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 30
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t14, i32 %t15)
  store %"compiler/types:data" %t18, ptr %l12
  br label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/types:Table", ptr %t19, i32 0, i32 30
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %t21, i64 0)
  store { i64, ptr } %t23, ptr %l17
  br label %bb6
bb4:
  %t24 = getelementptr %"compiler/types:data", ptr %l12, i32 0, i32 5
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load ptr, ptr %l9, !tbaa !29
  %t28 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %t26, i64 %t25)
  store { i64, ptr } %t28, ptr %l14
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t29, ptr %l7, !tbaa !27
  br label %bb7
bb6:
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t30, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eneedsDrop(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l9 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i64
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca i64
  %l42 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i32, ptr %l1, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l9
  br label %bb5
bb5:
  %t16 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t18 = trunc i64 21 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l15
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l18
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l21
  br label %bb10
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l27
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l12, !tbaa !29
  %t53 = load i32, ptr %l15, !tbaa !23
  %t54 = load i32, ptr %l18, !tbaa !23
  %t55 = load i32, ptr %l21, !tbaa !23
  %t56 = load i32, ptr %l24, !tbaa !23
  %t57 = load i64, ptr %l27, !tbaa !24
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t52, i32 %t53, i32 %t54, i32 %t55, i32 %t56, i64 %t57, i1 false, i32 %t58)
  store i32 %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load i32, ptr %l31, !tbaa !23
  store i32 %t60, ptr %rv
  br label %ret
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l1, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l35
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l38
  br label %bb17
bb17:
  %t72 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t74 = xor i64 %t72, -1
  %t75 = load i64, ptr %l38, !tbaa !24
  %t77 = and i64 %t75, %t74
  %t78 = load ptr, ptr %l32, !tbaa !29
  %t79 = load i32, ptr %l35, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t78, i32 %t79, i64 %t77)
  store i32 %t81, ptr %l42
  br label %bb18
bb18:
  %t82 = load i32, ptr %l42, !tbaa !23
  store i32 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l32 = alloca i64
  %l40 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l69 = alloca i64
  %l75 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t8 = trunc i64 32 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 19
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H5a37a20f375ed653adc00b592f5745cf(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l20
  br label %bb4
bb3:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l20, !tbaa !21
  store i1 %t18, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l21, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l21, !tbaa !29
  %t27 = load i32, ptr %l24, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l26, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldList(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l29
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = load i32, ptr %l29, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t36, i32 %t37)
  store { i64, ptr } %t38, ptr %l30
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  store i64 %t42, ptr %l32, !tbaa !24
  %t43 = load i64, ptr %l32, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = icmp sle i64 %t46, 1152921504606846975
  br i1 %t47, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_ecef2c1188620c25_f6c5d2506e285511)
  unreachable
bb15:
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = mul i64 %t49, 8
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t54, ptr %lp3
  %t56 = load ptr, ptr %lp3
  store { i64, ptr } %t53, ptr %t56, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/types:Table", ptr %t57, i32 0, i32 23
  %t60 = load i32, ptr %l1, !tbaa !23
  %t62 = sext i32 %t60 to i64
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t59, i64 %t62)
  store i64 %t65, ptr %l40
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_ecef2c1188620c25_f6c5d2506e285511)
  unreachable
bb17:
  %t66 = load i64, ptr %l40, !tbaa !24
  store i64 %t66, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = icmp slt i64 %t67, 0
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t71 = load ptr, ptr %lp3
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  store i64 0, ptr %l5, !tbaa !24
  %t74 = load i64, ptr %l2, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = icmp sgt i64 %t76, %t77
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp sgt i64 %t82, 0
  br i1 %t84, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb26
bb23:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t90 = sub i64 %t86, %t87
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = add i64 %t90, %t91
  %t96 = sub i64 %t94, 1
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = sdiv i64 %t96, %t97
  store i64 %t100, ptr %l51, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb25
bb25:
  %t102 = load i64, ptr %l51, !tbaa !24
  store i64 %t102, ptr %l48, !tbaa !24
  br label %bb26
bb26:
  %t103 = load i64, ptr %l48, !tbaa !24
  store i64 %t103, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb27:
  %t104 = load i64, ptr %l9, !tbaa !24
  %t105 = load i64, ptr %l8, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t112 = load i64, ptr %l5, !tbaa !24
  %t113 = load i64, ptr %l9, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = mul i64 %t113, %t114
  %t120 = add i64 %t112, %t117
  store i64 %t120, ptr %l10, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  store i64 %t122, ptr %l69, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/types:Table", ptr %t123, i32 0, i32 24
  %t126 = load i64, ptr %l4, !tbaa !24
  %t127 = load i64, ptr %l10, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t130)
  store i64 %t133, ptr %l75
  br label %bb31
bb31:
  %t134 = load i64, ptr %l75, !tbaa !24
  %t135 = load ptr, ptr %lp3
  %t136 = load i64, ptr %l69, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i64, ptr %t138, i64 %t136
  store i64 %t134, ptr %t139, !tbaa !34
  br label %bb32
bb32:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l9, !tbaa !24
  br label %bb27
bb33:
  %t144 = load ptr, ptr %lp3
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t145, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l8 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca i32
  %l44 = alloca i64
  %l47 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l8
  br label %bb5
bb5:
  %t14 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t16 = trunc i64 21 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l11, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l14
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l17
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l20
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t40, i32 %t41)
  store i64 %t44, ptr %l26
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l29
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l11, !tbaa !29
  %t51 = load i32, ptr %l14, !tbaa !23
  %t52 = load i32, ptr %l17, !tbaa !23
  %t53 = load i32, ptr %l20, !tbaa !23
  %t54 = load i32, ptr %l23, !tbaa !23
  %t55 = load i64, ptr %l26, !tbaa !24
  %t56 = load i32, ptr %l29, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t50, i32 %t51, i32 %t52, i32 %t53, i32 %t54, i64 %t55, i1 true, i32 %t56)
  store i32 %t57, ptr %l30
  br label %bb14
bb14:
  %t58 = load i32, ptr %l30, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l33
  br label %bb16
bb16:
  %t64 = load i32, ptr %l33, !range !{i32 0, i32 33}
  %t66 = trunc i64 20 to i32
  %t67 = icmp eq i32 %t64, %t66
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t71 = load i32, ptr %l1, !tbaa !23
  store i32 %t71, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l38, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l1, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l41
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t79, i32 %t80)
  store i64 %t83, ptr %l44
  br label %bb21
bb21:
  %t84 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t85 = load i64, ptr %l44, !tbaa !24
  %t87 = or i64 %t85, %t84
  %t88 = load ptr, ptr %l38, !tbaa !29
  %t89 = load i32, ptr %l41, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t88, i32 %t89, i64 %t87)
  store i32 %t91, ptr %l47
  br label %bb22
bb22:
  %t92 = load i32, ptr %l47, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t14 = trunc i64 19 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i32, ptr %l14, !tbaa !23
  %t23 = icmp eq i32 %t22, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l11, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eownsParts(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i32
  %l63 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l15, !tbaa !24
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = icmp sle i64 %t14, 1152921504606846975
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6b6356ebbaa556b4_537d1793e4121070)
  unreachable
bb6:
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = mul i64 %t17, 8
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6b6356ebbaa556b4_537d1793e4121070)
  unreachable
bb8:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb13
bb10:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l27, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb12
bb12:
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l24, !tbaa !24
  br label %bb13
bb13:
  %t54 = load i64, ptr %l24, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l45, !tbaa !27
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l47, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i64, ptr %t79, i64 %t76
  %t81 = load i64, ptr %t80, !tbaa !34
  %t84 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t74
  store i64 %t81, ptr %t86, !tbaa !34
  br label %bb18
bb18:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb14
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/types:Table", ptr %t91, i32 0, i32 31
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t97 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t93, { i64, ptr } %t94)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l57
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb21, label %ok.101, !prof !99
ok.101:
  store i64 %t98, ptr %l56
  br label %bb20
bb20:
  %t102 = load i64, ptr %l56, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t103 = load i64, ptr %l52, !tbaa !24
  store i64 %t103, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = icmp sge i64 %t104, 0
  br i1 %t106, label %bb24, label %bb25
bb24:
  %t108 = load i64, ptr %l9, !tbaa !24
  store i64 %t108, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/types:Table", ptr %t110, i32 0, i32 30
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l63
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  store i64 %t115, ptr %l9, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/types:Table", ptr %t116, i32 0, i32 30
  %t119 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t118, { i64, ptr } %t119)
  br label %bb28
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/types:Table", ptr %t122, i32 0, i32 31
  %t125 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t126 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t124, { i64, ptr } %t125, i64 %t126)
  br label %bb29
bb29:
  %t130 = load i64, ptr %l9, !tbaa !24
  store i64 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l28 = alloca i32
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb20
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 %t26
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l24
  br label %bb8
bb8:
  %t38 = load i1, ptr %l24, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 109)
  br label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l28
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t45 = load i32, ptr %l28, !range !{i32 0, i32 33}
  %t47 = trunc i64 21 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 115)
  br label %bb15
bb14:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 118)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb4
bb20:
  %t57 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t57, ptr %l36
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 25
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 27
  %t6 = sext i32 %a1 to i64
  %t9 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3, i64 %t6)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca i32
  %l40 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca i32
  %l80 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i1 true, ptr %l3, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  store i32 %t27, ptr %l7, !tbaa !23
  %t29 = load i1, ptr %l3, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l32
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i32, ptr %l7, !tbaa !23
  %t37 = load i32, ptr %l32, !tbaa !23
  %t39 = icmp eq i32 %t37, %t36
  store i1 %t39, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l29, !tbaa !21
  store i1 %t41, ptr %l3, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb2
bb11:
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t48, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l40, !tbaa !24
  %t53 = load i64, ptr %l40, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load i64, ptr %l40, !tbaa !24
  %t57 = icmp sle i64 %t56, 2305843009213693951
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f884bd4f1b6015d_20014de591249a11)
  unreachable
bb17:
  %t59 = load i64, ptr %l40, !tbaa !24
  %t60 = mul i64 %t59, 4
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f884bd4f1b6015d_20014de591249a11)
  unreachable
bb19:
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb24
bb21:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l11, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l52, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t95 = load i64, ptr %l52, !tbaa !24
  store i64 %t95, ptr %l49, !tbaa !24
  br label %bb24
bb24:
  %t96 = load i64, ptr %l49, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  store i64 %t115, ptr %l70, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t117, ptr %l72, !tbaa !27
  %t118 = load i64, ptr %l14, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i32, ptr %t121, i64 %t118
  %t123 = load i32, ptr %t122, !tbaa !33
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t116, i32 %t123)
  store i32 %t126, ptr %l75
  br label %bb29
bb29:
  %t127 = load i32, ptr %l75, !tbaa !23
  %t128 = load i64, ptr %l70, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t128
  store i32 %t127, ptr %t131, !tbaa !33
  br label %bb30
bb30:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l13, !tbaa !24
  br label %bb25
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t136, { i64, ptr } %t137)
  store i32 %t140, ptr %l80
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l80, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l36 = alloca i1
  %l43 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i32
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l2, !tbaa !24
  store i64 15, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l15, !tbaa !24
  store i64 %t27, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l12, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimNames, i64 0, i64 %t47
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !37
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t52 = load ptr, ptr @__olang_prog_scope
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t52, ptr %v1, { i64, ptr } %t50, { i64, ptr } %t51)
  store i1 %t55, ptr %l36
  br label %bb11
bb11:
  %t56 = load i1, ptr %l36, !tbaa !21
  br i1 %t56, label %bb12, label %bb13
bb12:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = trunc i64 %t57 to i32
  store i32 %t59, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb7
bb16:
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t68 = call i64 @compiler_2ftypes_2eIntWidth(ptr %v1, { i64, ptr } %t66)
  store i64 %t68, ptr %l43
  br label %bb17
bb17:
  %t69 = load i64, ptr %l43, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l48, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 0
  %t80 = load i8, ptr %t79, !tbaa !32
  %t82 = icmp eq i8 %t80, 85
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIntType(ptr %v0, ptr %a0, i64 %t75, i1 %t82)
  store i32 %t86, ptr %l51
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t87 = load i32, ptr %l51, !tbaa !23
  store i32 %t87, ptr %rv
  br label %ret
bb21:
  %t88 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesCode(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"compiler/types:codeWalk"
  %l4 = alloca %"compiler/types:codeWalk"
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/types:codeWalk" @compiler_2ftypes_3acodeWalk_2ector(ptr %v0, ptr %s0, ptr %a0, i1 false)
  store %"compiler/types:codeWalk" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/types:codeWalk", ptr %l4
  store %"compiler/types:codeWalk" %t4, ptr %l2
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %s0, ptr %l2, i32 %a1)
  store i1 %t8, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l7, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"compiler/types:codeWalk"
  %l4 = alloca %"compiler/types:codeWalk"
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/types:codeWalk" @compiler_2ftypes_3acodeWalk_2ector(ptr %v0, ptr %s0, ptr %a0, i1 true)
  store %"compiler/types:codeWalk" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/types:codeWalk", ptr %l4
  store %"compiler/types:codeWalk" %t4, ptr %l2
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %s0, ptr %l2, i32 %a1)
  store i1 %t8, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l7, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l11 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 23, i64 %t4, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = add i32 %t13, 1
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l8
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t14)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 27
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t43, i64 %t44, i32 %t45)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l12 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load i64, ptr %l2, !tbaa !24
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 20, i64 %t4, i64 %t5, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = add i32 %t15, 1
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load %"compiler/types:data", ptr %l9
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t17, %"compiler/types:data" %t18, i32 %t16)
  store i32 %t20, ptr %l14
  br label %bb3
bb3:
  %t21 = load i32, ptr %l14, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb4
bb4:
  %t27 = load i32, ptr %l1, !tbaa !23
  %t28 = load i32, ptr %l17, !tbaa !23
  %t30 = icmp ne i32 %t28, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 27
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l27
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i32, ptr %l27, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t45, i32 %t46, i64 %t44)
  store i32 %t48, ptr %l29
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = load i32, ptr %l29, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t49, i64 %t50, i32 %t51)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t52 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i32 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i32 %a2, ptr %l8, !tbaa !23
  store i32 %a3, ptr %l9, !tbaa !23
  store i32 %a4, ptr %l10, !tbaa !23
  store i32 %a5, ptr %l11, !tbaa !23
  store i64 %a6, ptr %l12, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l15
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l18
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t18 = load i32, ptr %l8, !tbaa !23
  %t19 = load i32, ptr %l9, !tbaa !23
  %t20 = load i32, ptr %l10, !tbaa !23
  %t21 = load i32, ptr %l11, !tbaa !23
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = load i32, ptr %l18, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t17, i32 %t18, i32 %t19, i32 %t20, i32 %t21, i64 %t22, i1 %t23, i32 %t24)
  store i32 %t25, ptr %l19
  br label %bb3
bb3:
  %t26 = load i32, ptr %l19, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t8 = trunc i64 32 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 19
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H08d487c91a3409a786f6b7c534acefc5(ptr %v0, ptr %t13, i32 %t14)
  %t18 = extractvalue { i32, i32 } %t17, 1
  %t19 = extractvalue { i32, i32 } %t17, 0
  store i32 %t19, ptr %l13
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb5, label %ok.21, !prof !99
ok.21:
  store i32 %t18, ptr %l12
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t22 = load i32, ptr %l12, !tbaa !23
  store i32 %t22, ptr %l8, !tbaa !23
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i32 5, ptr %l8, !tbaa !23
  br label %bb7
bb7:
  %t23 = load i32, ptr %l8, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb8:
  %t24 = load i32, ptr %l1, !tbaa !23
  store i32 %t24, ptr %l2, !tbaa !23
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l17
  br label %bb10
bb10:
  %t31 = load i32, ptr %l17, !range !{i32 0, i32 33}
  %t33 = trunc i64 18 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l21, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb13
bb12:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb15
bb13:
  %t42 = load ptr, ptr %l21, !tbaa !29
  %t43 = load i32, ptr %l24, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t44, ptr %l25
  br label %bb14
bb14:
  %t45 = load i32, ptr %l25, !range !{i32 0, i32 6}
  %t47 = trunc i64 4 to i32
  %t48 = icmp eq i32 %t45, %t47
  store i1 %t48, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t50 = load i1, ptr %l20, !tbaa !21
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l31
  br label %bb18
bb17:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb19
bb18:
  %t56 = load i1, ptr %l31, !tbaa !21
  store i1 %t56, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l28, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb23
bb23:
  %t65 = load i32, ptr %l35, !tbaa !23
  store i32 %t65, ptr %l2, !tbaa !23
  br label %bb24
bb24:
  br label %bb9
bb25:
  %t66 = load i32, ptr %l2, !tbaa !23
  store i32 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 28
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 1
  %t30 = load i64, ptr %t29, !tbaa !34
  %t32 = add i64 2, %t30
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t36, %t39
  store i1 %t42, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l17, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i64, ptr %t48, i64 1
  %t50 = load i64, ptr %t49, !tbaa !34
  %t52 = add i64 2, %t50
  %t53 = load i64, ptr %l2, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i64, ptr %t59, i64 %t56
  %t61 = load i64, ptr %t60, !tbaa !34
  store i64 %t61, ptr %l26, !tbaa !24
  br label %bb11
bb10:
  %t63 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t63, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l26, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i32
  %l22 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l62 = alloca { i64, ptr }
  %l69 = alloca [1 x i32]
  %l70 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i32, ptr %l13, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t15 = icmp sle i64 0, 2305843009213693951
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f7b42ec29d1607_26e89eedc9b3128b)
  unreachable
bb6:
  %t17 = mul i64 0, 4
  %t18 = insertvalue { i64, ptr } undef, i64 0, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f7b42ec29d1607_26e89eedc9b3128b)
  unreachable
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l22
  br label %bb9
bb9:
  %t26 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t28 = trunc i64 22 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l28
  br label %bb12
bb11:
  br label %bb30
bb12:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load i32, ptr %l28, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = load i64, ptr %l31, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = load i64, ptr %l31, !tbaa !24
  %t48 = icmp sle i64 %t47, 2305843009213693951
  br i1 %t48, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2df495a001b30f12_f15d21f3e8677f6)
  unreachable
bb16:
  %t50 = load i64, ptr %l31, !tbaa !24
  %t51 = mul i64 %t50, 4
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t55, ptr %lp4
  %t57 = load ptr, ptr %lp4
  store { i64, ptr } %t54, ptr %t57, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2df495a001b30f12_f15d21f3e8677f6)
  unreachable
bb18:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb23
bb20:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l43, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb22
bb22:
  %t88 = load i64, ptr %l43, !tbaa !24
  store i64 %t88, ptr %l40, !tbaa !24
  br label %bb23
bb23:
  %t89 = load i64, ptr %l40, !tbaa !24
  store i64 %t89, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb24
bb24:
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t98 = load i64, ptr %l5, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %l62, !tbaa !27
  %t110 = load i64, ptr %l10, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  %t117 = load ptr, ptr %lp4
  %t119 = getelementptr { i64, ptr }, ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t108
  store i32 %t115, ptr %t121, !tbaa !33
  br label %bb28
bb28:
  %t122 = load i64, ptr %l9, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l9, !tbaa !24
  br label %bb24
bb29:
  %t126 = load ptr, ptr %lp4
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
bb30:
  %t129 = load i32, ptr %l2, !tbaa !23
  %t131 = insertvalue [1 x i32] undef, i32 %t129, 0
  store [1 x i32] %t131, ptr %l69
  %t132 = mul i64 1, 4
  %t133 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 1, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l70, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = mul i64 1, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t137, ptr %l69, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t139, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t13, i32 %t14)
  store { i64, ptr } %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t19 = icmp sgt i64 %t17, 0
  store i1 %t19, ptr %l3, !tbaa !21
  %t21 = load i32, ptr %l2, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t25 = icmp ne i32 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l20
  br label %bb6
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l20, !tbaa !21
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load i1, ptr %l3, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l27, !tbaa !24
  %t42 = load i64, ptr %l27, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t53, ptr %l22, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
bb13:
  %t55 = load i1, ptr %l3, !tbaa !21
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s2, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l33
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t64 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb17:
  %t71 = load i32, ptr %l2, !tbaa !23
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t75 = icmp eq i32 %t71, %t72
  br i1 %t75, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l40, !tbaa !24
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l41, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l40, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t91, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s0, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l44
  br label %bb21
bb21:
  %t98 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t100 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = getelementptr i8, ptr %t108, i64 %t102
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 28
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 0
  %t25 = load i64, ptr %t24, !tbaa !34
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb5
bb4:
  %t27 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t27, ptr %l13, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l13, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunLength(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"compiler/types:data"
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 26, i64 0, i64 -1, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load %"compiler/types:data", ptr %l3
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t4, %"compiler/types:data" %t5, i32 1)
  store i32 %t6, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l4, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 35
  %t5 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunsCopy(ptr %v0, ptr %t9, i32 %a1, i64 0)
  store i1 %t13, ptr %l9
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l6, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t6, i32 %a2)
  store i32 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l27 = alloca [1 x i64]
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i1
  %l69 = alloca { i64, ptr }
  %l72 = alloca i1
  %l82 = alloca { i64, ptr }
  %l88 = alloca i64
  %l91 = alloca i64
  %l112 = alloca i64
  %l116 = alloca i1
  %l120 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i1
  %l129 = alloca i1
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleDtor, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  %t15 = insertvalue [1 x i64] undef, i64 %t13, 0
  store [1 x i64] %t15, ptr %l27
  %t16 = mul i64 1, 8
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 1, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l28, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = mul i64 1, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %l27, i64 %t22, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l29
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l3
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l30, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l33
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load i32, ptr %l33, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l34
  br label %bb7
bb7:
  %t35 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb13
bb10:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l43, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l43, !tbaa !24
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l40, !tbaa !24
  store i64 %t67, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l10, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l1, !tbaa !23
  %t88 = load i64, ptr %l10, !tbaa !24
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t86, i32 %t87, i64 %t88)
  store i64 %t92, ptr %l64
  br label %bb18
bb18:
  %t93 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t94 = load i64, ptr %l64, !tbaa !24
  %t96 = icmp eq i64 %t94, %t93
  br i1 %t96, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l69, !tbaa !27
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t98, i32 %t105)
  store i1 %t108, ptr %l72
  br label %bb21
bb20:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb22
bb21:
  %t109 = load i1, ptr %l72, !tbaa !21
  store i1 %t109, ptr %l67, !tbaa !21
  br label %bb22
bb22:
  %t110 = load i1, ptr %l67, !tbaa !21
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t111 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t111)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l9, !tbaa !24
  br label %bb14
bb28:
  %t118 = load i64, ptr %l2, !tbaa !24
  %t119 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  store i1 %t122, ptr %l11, !tbaa !21
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l1, !tbaa !23
  %t128 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t124, i32 %t125)
  store { i64, ptr } %t128, ptr %l82
  br label %bb29
bb29:
  %t129 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t129, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb30, label %bb31
bb30:
  %t140 = load i64, ptr %l15, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb35
bb32:
  %t144 = load i64, ptr %l14, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l15, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l91, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb34
bb34:
  %t160 = load i64, ptr %l91, !tbaa !24
  store i64 %t160, ptr %l88, !tbaa !24
  br label %bb35
bb35:
  %t161 = load i64, ptr %l88, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb36
bb36:
  %t162 = load i64, ptr %l17, !tbaa !24
  %t163 = load i64, ptr %l16, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb37, label %bb38
bb37:
  br label %bb56
bb38:
  br label %bb39
bb39:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t171 = load i64, ptr %l17, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l18, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i32, ptr %l1, !tbaa !23
  %t182 = load i64, ptr %l18, !tbaa !24
  %t186 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t180, i32 %t181, i64 %t182)
  store i64 %t186, ptr %l112
  br label %bb40
bb40:
  %t187 = load i64, ptr %l112, !tbaa !24
  store i64 %t187, ptr %l19, !tbaa !24
  %t188 = load i64, ptr %l19, !tbaa !24
  %t189 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t192 = icmp eq i64 %t188, %t189
  br i1 %t192, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb43
bb42:
  %t194 = load i64, ptr %l19, !tbaa !24
  %t195 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t198 = icmp eq i64 %t194, %t195
  store i1 %t198, ptr %l116, !tbaa !21
  br label %bb43
bb43:
  %t200 = load i1, ptr %l116, !tbaa !21
  br i1 %t200, label %bb44, label %bb45
bb44:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i64, ptr %l18, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t201, i32 %t207)
  store i1 %t210, ptr %l124
  br label %bb46
bb45:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb51
bb46:
  %t211 = load i1, ptr %l124, !tbaa !21
  br i1 %t211, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb50
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l18, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i32, ptr %t216, i64 %t213
  %t218 = load i32, ptr %t217, !tbaa !33
  %t221 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t212, i32 %t218)
  store i1 %t221, ptr %l129
  br label %bb49
bb49:
  %t222 = load i1, ptr %l129, !tbaa !21
  store i1 %t222, ptr %l125, !tbaa !21
  br label %bb50
bb50:
  %t223 = load i1, ptr %l125, !tbaa !21
  store i1 %t223, ptr %l120, !tbaa !21
  br label %bb51
bb51:
  %t224 = load i1, ptr %l120, !tbaa !21
  br i1 %t224, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t225 = load i64, ptr %l17, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l17, !tbaa !24
  br label %bb36
bb56:
  %t229 = load i1, ptr %l11, !tbaa !21
  br i1 %t229, label %bb57, label %bb58
bb57:
  %t231 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t231)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t235 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t235, ptr %l136
  br label %bb61
bb61:
  %t236 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t236, ptr %l137, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l138, !tbaa !24
  %t239 = load i64, ptr %l138, !tbaa !24
  %t240 = mul i64 %t239, 8
  %t241 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l139, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = load i64, ptr %l138, !tbaa !24
  %t249 = mul i64 %t248, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t245, ptr %t247, i64 %t249, i1 false)
  %t250 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t250, ptr %l137, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t251 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t251, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l56 = alloca { i64, ptr }
  %l60 = alloca i1
  %l73 = alloca i64
  %l80 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l89 = alloca i64
  %l92 = alloca i64
  %l110 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l123 = alloca i64
  %l126 = alloca i64
  %l144 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l155 = alloca i32
  %l159 = alloca i32
  %l160 = alloca i32
  %l166 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  store i1 %t5, ptr %l4, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l39, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i64, ptr %t25, i64 %t22
  %t27 = load i64, ptr %t26, !tbaa !34
  store i64 %t27, ptr %l8, !tbaa !24
  %t29 = load i1, ptr %l4, !tbaa !21
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  store i1 %t35, ptr %l43, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb7
bb7:
  %t37 = load i1, ptr %l43, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  br label %bb8
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb1
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l56, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t57
  %t62 = load i64, ptr %t61, !tbaa !34
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = load i1, ptr %l4, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load i64, ptr %l12, !tbaa !24
  %t67 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t70 = icmp eq i64 %t66, %t67
  store i1 %t70, ptr %l60, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l60, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  br label %bb17
bb17:
  %t73 = load i64, ptr %l10, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l10, !tbaa !24
  br label %bb10
bb18:
  %t77 = load i1, ptr %l4, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  store i32 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = add i64 2, %t82
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = add i64 %t84, %t87
  store i64 %t90, ptr %l73, !tbaa !24
  %t91 = load i64, ptr %l73, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = icmp sle i64 %t94, 1152921504606846975
  br i1 %t95, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_63e623ceae63df16_2a862fe3f0344bd2)
  unreachable
bb24:
  %t97 = load i64, ptr %l73, !tbaa !24
  %t98 = mul i64 %t97, 8
  %t99 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l13, !tbaa !27
  %t103 = load i64, ptr %l1, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t109 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t109, ptr %l80, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i64, ptr %t113, i64 0
  store i64 %t103, ptr %t114, !tbaa !34
  %t115 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t115, ptr %l82, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i64, ptr %t119, i64 1
  store i64 %t107, ptr %t120, !tbaa !34
  store i64 0, ptr %l16, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  store i64 %t123, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t125 = load i64, ptr %l17, !tbaa !24
  %t126 = load i64, ptr %l16, !tbaa !24
  %t129 = icmp sgt i64 %t125, %t126
  br i1 %t129, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_63e623ceae63df16_2a862fe3f0344bd2)
  unreachable
bb26:
  %t131 = load i64, ptr %l18, !tbaa !24
  %t133 = icmp sgt i64 %t131, 0
  br i1 %t133, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb31
bb28:
  %t135 = load i64, ptr %l17, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = sub i64 %t135, %t136
  %t140 = load i64, ptr %l18, !tbaa !24
  %t143 = add i64 %t139, %t140
  %t145 = sub i64 %t143, 1
  %t146 = load i64, ptr %l18, !tbaa !24
  %t149 = sdiv i64 %t145, %t146
  store i64 %t149, ptr %l92, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb30
bb30:
  %t151 = load i64, ptr %l92, !tbaa !24
  store i64 %t151, ptr %l89, !tbaa !24
  br label %bb31
bb31:
  %t152 = load i64, ptr %l89, !tbaa !24
  store i64 %t152, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb32
bb32:
  %t153 = load i64, ptr %l20, !tbaa !24
  %t154 = load i64, ptr %l19, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t161 = load i64, ptr %l16, !tbaa !24
  %t162 = load i64, ptr %l20, !tbaa !24
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = mul i64 %t162, %t163
  %t169 = add i64 %t161, %t166
  store i64 %t169, ptr %l21, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t171, ptr %l110, !tbaa !27
  %t172 = load i64, ptr %l21, !tbaa !24
  %t174 = add i64 2, %t172
  %t175 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t175, ptr %l113, !tbaa !27
  %t176 = load i64, ptr %l21, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i64, ptr %t179, i64 %t176
  %t181 = load i64, ptr %t180, !tbaa !34
  %t184 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t174
  store i64 %t181, ptr %t186, !tbaa !34
  br label %bb36
bb36:
  %t187 = load i64, ptr %l20, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l20, !tbaa !24
  br label %bb32
bb37:
  store i64 0, ptr %l22, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  store i64 %t193, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t195 = load i64, ptr %l23, !tbaa !24
  %t196 = load i64, ptr %l22, !tbaa !24
  %t199 = icmp sgt i64 %t195, %t196
  br i1 %t199, label %bb38, label %bb39
bb38:
  %t201 = load i64, ptr %l24, !tbaa !24
  %t203 = icmp sgt i64 %t201, 0
  br i1 %t203, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb43
bb40:
  %t205 = load i64, ptr %l23, !tbaa !24
  %t206 = load i64, ptr %l22, !tbaa !24
  %t209 = sub i64 %t205, %t206
  %t210 = load i64, ptr %l24, !tbaa !24
  %t213 = add i64 %t209, %t210
  %t215 = sub i64 %t213, 1
  %t216 = load i64, ptr %l24, !tbaa !24
  %t219 = sdiv i64 %t215, %t216
  store i64 %t219, ptr %l126, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb42
bb42:
  %t221 = load i64, ptr %l126, !tbaa !24
  store i64 %t221, ptr %l123, !tbaa !24
  br label %bb43
bb43:
  %t222 = load i64, ptr %l123, !tbaa !24
  store i64 %t222, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb44
bb44:
  %t223 = load i64, ptr %l26, !tbaa !24
  %t224 = load i64, ptr %l25, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t231 = load i64, ptr %l22, !tbaa !24
  %t232 = load i64, ptr %l26, !tbaa !24
  %t233 = load i64, ptr %l24, !tbaa !24
  %t236 = mul i64 %t232, %t233
  %t239 = add i64 %t231, %t236
  store i64 %t239, ptr %l27, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t241, ptr %l144, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t246 = add i64 2, %t244
  %t247 = load i64, ptr %l27, !tbaa !24
  %t250 = add i64 %t246, %t247
  %t251 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t251, ptr %l150, !tbaa !27
  %t252 = load i64, ptr %l27, !tbaa !24
  %t254 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr i64, ptr %t255, i64 %t252
  %t257 = load i64, ptr %t256, !tbaa !34
  %t260 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr i64, ptr %t261, i64 %t250
  store i64 %t257, ptr %t262, !tbaa !34
  br label %bb48
bb48:
  %t263 = load i64, ptr %l26, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l26, !tbaa !24
  br label %bb44
bb49:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/types:Table", ptr %t267, i32 0, i32 29
  %t270 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t273 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v0, ptr %t269, { i64, ptr } %t270)
  %t274 = extractvalue { i32, i32 } %t273, 1
  %t275 = extractvalue { i32, i32 } %t273, 0
  store i32 %t275, ptr %l160
  %t276 = icmp ne i32 %t275, 0
  br i1 %t276, label %bb51, label %ok.277, !prof !99
ok.277:
  store i32 %t274, ptr %l159
  br label %bb50
bb50:
  %t278 = load i32, ptr %l159, !tbaa !23
  store i32 %t278, ptr %l155, !tbaa !23
  br label %bb53
bb51:
  br label %bb52
bb52:
  store i32 -1, ptr %l155, !tbaa !23
  br label %bb53
bb53:
  %t279 = load i32, ptr %l155, !tbaa !23
  store i32 %t279, ptr %l28, !tbaa !23
  %t280 = load i32, ptr %l28, !tbaa !23
  %t282 = icmp sge i32 %t280, 0
  br i1 %t282, label %bb54, label %bb55
bb54:
  %t284 = load i32, ptr %l28, !tbaa !23
  store i32 %t284, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/types:Table", ptr %t286, i32 0, i32 28
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l166
  br label %bb57
bb57:
  %t291 = load i64, ptr %l166, !tbaa !24
  %t292 = trunc i64 %t291 to i32
  store i32 %t292, ptr %l28, !tbaa !23
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/types:Table", ptr %t295, i32 0, i32 28
  %t298 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t297, { i64, ptr } %t298)
  br label %bb58
bb58:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/types:Table", ptr %t301, i32 0, i32 29
  %t304 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t305 = load i32, ptr %l28, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v0, ptr %t303, { i64, ptr } %t304, i32 %t305)
  br label %bb59
bb59:
  %t309 = load i32, ptr %l28, !tbaa !23
  store i32 %t309, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i1
  %l36 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca i1
  %l47 = alloca i32
  %l52 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca i1
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l133 = alloca i64
  %l136 = alloca i64
  %l161 = alloca i64
  %l165 = alloca i64
  %l169 = alloca i1
  %l173 = alloca i1
  %l177 = alloca i1
  %l181 = alloca i1
  %l192 = alloca i1
  %l200 = alloca ptr
  %l203 = alloca i32
  %l206 = alloca i32
  %l207 = alloca i1
  %l210 = alloca ptr
  %l213 = alloca i32
  %l216 = alloca i32
  %l217 = alloca i1
  %l220 = alloca ptr
  %l223 = alloca i32
  %l224 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l228 = alloca i32
  %l229 = alloca { i64, ptr }
  %l235 = alloca i64
  %l238 = alloca i64
  %l260 = alloca i1
  %l262 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l268 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb6
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l36
  br label %bb3
bb3:
  store ptr %l36, ptr %l37, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l40
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l37, !tbaa !29
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t17, ptr %l40)
  store i1 %t19, ptr %l42
  br label %bb5
bb5:
  %t20 = load i1, ptr %l42, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l33, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l33, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l47
  br label %bb10
bb10:
  %t30 = load i32, ptr %l47, !range !{i32 0, i32 33}
  store i32 %t30, ptr %l3
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t33 = trunc i64 21 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb85
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t36, i32 %t37)
  store i64 %t40, ptr %l52
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l55
  br label %bb15
bb15:
  %t46 = load i64, ptr %l52, !tbaa !24
  %t47 = load i64, ptr %l55, !tbaa !24
  %t48 = icmp ne i64 %t46, %t47
  br i1 %t48, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l58, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l61
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l58, !tbaa !29
  %t58 = load i32, ptr %l61, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t57, i32 %t58)
  store { i64, ptr } %t59, ptr %l62
  br label %bb20
bb20:
  %t60 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l63, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l66
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l63, !tbaa !29
  %t68 = load i32, ptr %l66, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t69, ptr %l67
  br label %bb22
bb22:
  %t70 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t70, ptr %l5, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t79 = icmp ne i64 %t73, %t76
  br i1 %t79, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb31
bb28:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l82, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb30
bb30:
  %t112 = load i64, ptr %l82, !tbaa !24
  store i64 %t112, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t113 = load i64, ptr %l79, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb33, label %bb34
bb33:
  br label %bb46
bb34:
  br label %bb35
bb35:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t134 = load i64, ptr %l11, !tbaa !24
  %t138 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t132, i32 %t133, i64 %t134)
  store i64 %t138, ptr %l103
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l2, !tbaa !23
  %t141 = load i64, ptr %l11, !tbaa !24
  %t145 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t139, i32 %t140, i64 %t141)
  store i64 %t145, ptr %l107
  br label %bb37
bb37:
  %t146 = load i64, ptr %l103, !tbaa !24
  %t147 = load i64, ptr %l107, !tbaa !24
  %t148 = icmp ne i64 %t146, %t147
  br i1 %t148, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb41
bb39:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t151, ptr %l111, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i32, ptr %t155, i64 %t152
  %t157 = load i32, ptr %t156, !tbaa !33
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t158, ptr %l114, !tbaa !27
  %t159 = load i64, ptr %l11, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t150, i32 %t157, i32 %t164)
  store i1 %t168, ptr %l117
  br label %bb40
bb40:
  %t169 = load i1, ptr %l117, !tbaa !21
  %t170 = xor i1 %t169, true
  store i1 %t170, ptr %l109, !tbaa !21
  br label %bb41
bb41:
  %t172 = load i1, ptr %l109, !tbaa !21
  br i1 %t172, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb32
bb46:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l1, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t178, i32 %t179)
  store { i64, ptr } %t182, ptr %l124
  br label %bb47
bb47:
  %t183 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t183, ptr %l12, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t184, i32 %t185)
  store { i64, ptr } %t188, ptr %l127
  br label %bb48
bb48:
  %t189 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t189, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l15, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb49, label %bb50
bb49:
  %t200 = load i64, ptr %l16, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb54
bb51:
  %t204 = load i64, ptr %l15, !tbaa !24
  %t205 = load i64, ptr %l14, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l16, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l16, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l136, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb53
bb53:
  %t220 = load i64, ptr %l136, !tbaa !24
  store i64 %t220, ptr %l133, !tbaa !24
  br label %bb54
bb54:
  %t221 = load i64, ptr %l133, !tbaa !24
  store i64 %t221, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb55
bb55:
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load i64, ptr %l17, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb56, label %bb57
bb56:
  br label %bb84
bb57:
  br label %bb58
bb58:
  %t230 = load i64, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l18, !tbaa !24
  %t232 = load i64, ptr %l16, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  store i64 %t238, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l19, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t246 = icmp sge i64 %t240, %t243
  br i1 %t246, label %bb59, label %bb60
bb59:
  br label %bb84
bb60:
  br label %bb61
bb61:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  %t250 = load i64, ptr %l19, !tbaa !24
  %t254 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t248, i32 %t249, i64 %t250)
  store i64 %t254, ptr %l161
  br label %bb62
bb62:
  %t255 = load i64, ptr %l161, !tbaa !24
  store i64 %t255, ptr %l20, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i32, ptr %l2, !tbaa !23
  %t258 = load i64, ptr %l19, !tbaa !24
  %t262 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t256, i32 %t257, i64 %t258)
  store i64 %t262, ptr %l165
  br label %bb63
bb63:
  %t263 = load i64, ptr %l165, !tbaa !24
  store i64 %t263, ptr %l21, !tbaa !24
  %t264 = load i64, ptr %l20, !tbaa !24
  %t265 = load i64, ptr %l21, !tbaa !24
  %t268 = icmp ne i64 %t264, %t265
  br i1 %t268, label %bb64, label %bb65
bb64:
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t274 = icmp eq i64 %t270, %t271
  br i1 %t274, label %bb66, label %bb67
bb65:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb75
bb66:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb68
bb67:
  %t276 = load i64, ptr %l20, !tbaa !24
  %t277 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t280 = icmp eq i64 %t276, %t277
  store i1 %t280, ptr %l173, !tbaa !21
  br label %bb68
bb68:
  %t282 = load i1, ptr %l173, !tbaa !21
  br i1 %t282, label %bb69, label %bb70
bb69:
  %t283 = load i64, ptr %l21, !tbaa !24
  %t284 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t287 = icmp eq i64 %t283, %t284
  br i1 %t287, label %bb71, label %bb72
bb70:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb74
bb71:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb73
bb72:
  %t289 = load i64, ptr %l21, !tbaa !24
  %t290 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t293 = icmp eq i64 %t289, %t290
  store i1 %t293, ptr %l181, !tbaa !21
  br label %bb73
bb73:
  %t295 = load i1, ptr %l181, !tbaa !21
  store i1 %t295, ptr %l177, !tbaa !21
  br label %bb74
bb74:
  %t296 = load i1, ptr %l177, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l169, !tbaa !21
  br label %bb75
bb75:
  %t299 = load i1, ptr %l169, !tbaa !21
  br i1 %t299, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i64, ptr %l19, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i32, ptr %t305, i64 %t302
  %t307 = load i32, ptr %t306, !tbaa !33
  %t308 = load i64, ptr %l19, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i32, ptr %t311, i64 %t308
  %t313 = load i32, ptr %t312, !tbaa !33
  %t317 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t301, i32 %t307, i32 %t313)
  store i1 %t317, ptr %l192
  br label %bb79
bb79:
  %t318 = load i1, ptr %l192, !tbaa !21
  %t319 = xor i1 %t318, true
  br i1 %t319, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t322 = load i64, ptr %l18, !tbaa !24
  %t324 = add i64 %t322, 1
  store i64 %t324, ptr %l18, !tbaa !24
  br label %bb55
bb84:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb85:
  %t327 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t329 = trunc i64 19 to i32
  %t330 = icmp eq i32 %t327, %t329
  br i1 %t330, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l200, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l1, !tbaa !23
  %t337 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t337, ptr %l203
  br label %bb89
bb89:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l2, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t338, i32 %t339)
  store i32 %t342, ptr %l206
  br label %bb90
bb90:
  %t343 = load ptr, ptr %l200, !tbaa !29
  %t344 = load i32, ptr %l203, !tbaa !23
  %t345 = load i32, ptr %l206, !tbaa !23
  %t346 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t343, i32 %t344, i32 %t345)
  store i1 %t346, ptr %l207
  br label %bb91
bb91:
  %t347 = load i1, ptr %l207, !tbaa !21
  store i1 %t347, ptr %rv
  br label %ret
bb92:
  %t348 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t350 = trunc i64 20 to i32
  %t351 = icmp eq i32 %t348, %t350
  br i1 %t351, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l210, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l1, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l213
  br label %bb96
bb96:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l2, !tbaa !23
  %t363 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t359, i32 %t360)
  store i32 %t363, ptr %l216
  br label %bb97
bb97:
  %t364 = load ptr, ptr %l210, !tbaa !29
  %t365 = load i32, ptr %l213, !tbaa !23
  %t366 = load i32, ptr %l216, !tbaa !23
  %t367 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t364, i32 %t365, i32 %t366)
  store i1 %t367, ptr %l217
  br label %bb98
bb98:
  %t368 = load i1, ptr %l217, !tbaa !21
  store i1 %t368, ptr %rv
  br label %ret
bb99:
  %t369 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t371 = trunc i64 22 to i32
  %t372 = icmp eq i32 %t369, %t371
  br i1 %t372, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb126
bb102:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l220, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i32, ptr %l1, !tbaa !23
  %t379 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t375, i32 %t376)
  store i32 %t379, ptr %l223
  br label %bb103
bb103:
  %t380 = load ptr, ptr %l220, !tbaa !29
  %t381 = load i32, ptr %l223, !tbaa !23
  %t382 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t380, i32 %t381)
  store { i64, ptr } %t382, ptr %l224
  br label %bb104
bb104:
  %t383 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t383, ptr %l22, !tbaa !27
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l225, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i32, ptr %l2, !tbaa !23
  %t389 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t389, ptr %l228
  br label %bb105
bb105:
  %t390 = load ptr, ptr %l225, !tbaa !29
  %t391 = load i32, ptr %l228, !tbaa !23
  %t392 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t390, i32 %t391)
  store { i64, ptr } %t392, ptr %l229
  br label %bb106
bb106:
  %t393 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t393, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t394 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t394, 0
  store i64 %t396, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t398 = load i64, ptr %l25, !tbaa !24
  %t399 = load i64, ptr %l24, !tbaa !24
  %t402 = icmp sgt i64 %t398, %t399
  br i1 %t402, label %bb107, label %bb108
bb107:
  %t404 = load i64, ptr %l26, !tbaa !24
  %t406 = icmp sgt i64 %t404, 0
  br i1 %t406, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb112
bb109:
  %t408 = load i64, ptr %l25, !tbaa !24
  %t409 = load i64, ptr %l24, !tbaa !24
  %t412 = sub i64 %t408, %t409
  %t413 = load i64, ptr %l26, !tbaa !24
  %t416 = add i64 %t412, %t413
  %t418 = sub i64 %t416, 1
  %t419 = load i64, ptr %l26, !tbaa !24
  %t422 = sdiv i64 %t418, %t419
  store i64 %t422, ptr %l238, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb111
bb111:
  %t424 = load i64, ptr %l238, !tbaa !24
  store i64 %t424, ptr %l235, !tbaa !24
  br label %bb112
bb112:
  %t425 = load i64, ptr %l235, !tbaa !24
  store i64 %t425, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  %t426 = load i64, ptr %l28, !tbaa !24
  %t427 = load i64, ptr %l27, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb114, label %bb115
bb114:
  br label %bb125
bb115:
  br label %bb116
bb116:
  %t434 = load i64, ptr %l24, !tbaa !24
  %t435 = load i64, ptr %l28, !tbaa !24
  %t436 = load i64, ptr %l26, !tbaa !24
  %t439 = mul i64 %t435, %t436
  %t442 = add i64 %t434, %t439
  store i64 %t442, ptr %l29, !tbaa !24
  %t444 = load i64, ptr %l29, !tbaa !24
  %t445 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t450 = icmp slt i64 %t444, %t447
  br i1 %t450, label %bb117, label %bb118
bb117:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t453, ptr %l262, !tbaa !27
  %t454 = load i64, ptr %l29, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i32, ptr %t457, i64 %t454
  %t459 = load i32, ptr %t458, !tbaa !33
  %t460 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t460, ptr %l265, !tbaa !27
  %t461 = load i64, ptr %l29, !tbaa !24
  %t463 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr i32, ptr %t464, i64 %t461
  %t466 = load i32, ptr %t465, !tbaa !33
  %t470 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t452, i32 %t459, i32 %t466)
  store i1 %t470, ptr %l268
  br label %bb119
bb118:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb120
bb119:
  %t471 = load i1, ptr %l268, !tbaa !21
  %t472 = xor i1 %t471, true
  store i1 %t472, ptr %l260, !tbaa !21
  br label %bb120
bb120:
  %t474 = load i1, ptr %l260, !tbaa !21
  br i1 %t474, label %bb121, label %bb122
bb121:
  store i1 false, ptr %rv
  br label %ret
bb122:
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t476 = load i64, ptr %l28, !tbaa !24
  %t478 = add i64 %t476, 1
  store i64 %t478, ptr %l28, !tbaa !24
  br label %bb113
bb125:
  store i1 true, ptr %rv
  br label %ret
bb126:
  br i1 true, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  store i1 true, ptr %rv
  br label %ret
bb130:
  call void @__olang_check_failed(ptr @olang_loc_888c44700641ffaa_fbe810d9adf00e56)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 4
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = trunc i64 %t7 to i32
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEmptyBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l3, !tbaa !29
  store i32 %a1, ptr %l4, !tbaa !23
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t7 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t5, i1 false, i1 true)
  store %"compiler/types:body" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = load %"compiler/types:body", ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t8, i32 %t9, %"compiler/types:body" %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEnumBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_f7eaf3fe8a46d3da_9f187abb7d2da27e)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f7eaf3fe8a46d3da_9f187abb7d2da27e)
  unreachable
bb5:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l24, !tbaa !24
  store i64 %t46, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l21, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l44, !tbaa !27
  %t69 = load i64, ptr %l10, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t69
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t67
  store i32 %t74, ptr %t79, !tbaa !33
  br label %bb15
bb15:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb11
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/types:Table", ptr %t84, i32 0, i32 17
  %t87 = load i32, ptr %l1, !tbaa !23
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v0, ptr %t86, i32 %t87, { i64, ptr } %t88)
  br label %bb17
bb17:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/types:Table", ptr %t92, i32 0, i32 16
  store ptr %t94, ptr %l54, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  store i32 %t95, ptr %l55, !tbaa !23
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t100 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 %a3, i32 %t97, i1 false, i1 true)
  store %"compiler/types:body" %t100, ptr %l58
  br label %bb18
bb18:
  %t101 = load ptr, ptr %l54, !tbaa !29
  %t102 = load i32, ptr %l55, !tbaa !23
  %t103 = load %"compiler/types:body", ptr %l58
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t101, i32 %t102, %"compiler/types:body" %t103)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetErrRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Ha1b8741c5221fa161d1744b12cf57007(ptr %v0, ptr %t3, i32 %a1, i32 %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 20
  %t6 = sext i32 %a1 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6, i64 %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetOverBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i32
  %l7 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l4, !tbaa !29
  store i32 %a1, ptr %l5, !tbaa !23
  %t7 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %a2, i1 false, i1 true)
  store %"compiler/types:body" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = load %"compiler/types:body", ptr %l7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t8, i32 %t9, %"compiler/types:body" %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l5 = alloca ptr
  %l6 = alloca i32
  %l10 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l5, !tbaa !29
  store i32 %a1, ptr %l6, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 %a2, i32 0, i32 %t6, i1 %a3, i1 true)
  store %"compiler/types:body" %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = load %"compiler/types:body", ptr %l10
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t12, i32 %t13, %"compiler/types:body" %t14)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t9, i64 %t10)
  store i32 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i32, ptr %l7, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H37377f924b66ff741793959f79fef546(ptr %v0, ptr %v1, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 7
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H37377f924b66ff741793959f79fef546(ptr %v0, ptr %v1, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca i1
  %l17 = alloca i1
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 28
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = add i64 2, %t26
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t34 = icmp slt i64 %t28, %t31
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  %t40 = add i64 2, %t38
  %t42 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i64, ptr %t43, i64 %t40
  %t45 = load i64, ptr %t44, !tbaa !34
  store i64 %t45, ptr %l23, !tbaa !24
  br label %bb11
bb10:
  %t47 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t47, ptr %l23, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l23, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 21
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSpreadAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l16, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l19
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i32, ptr %l19, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t22, ptr %l20
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t54 = load i64, ptr %l29, !tbaa !24
  store i64 %t54, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t55 = load i64, ptr %l26, !tbaa !24
  store i64 %t55, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l8, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t75, ptr %l48, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i32, ptr %t79, i64 %t76
  %t81 = load i32, ptr %t80, !tbaa !33
  %t84 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %v0, ptr %t74, i32 %t81)
  store i1 %t84, ptr %l51
  br label %bb17
bb17:
  %t85 = load i1, ptr %l51, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  %t86 = load i64, ptr %l8, !tbaa !24
  store i64 %t86, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb13
bb22:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l5, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l11, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l13, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l16
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l13, !tbaa !29
  %t38 = load i32, ptr %l16, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l17
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l11 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 22, i64 %t4, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = add i32 %t13, 1
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l8
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t14)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 27
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t43, i64 %t44, i32 %t45)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i1
  %l6 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i32
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 36
  %t5 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/types:Table", ptr %t10, i32 0, i32 38
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t12, i64 %t15)
  store i1 %t18, ptr %l13
  br label %bb5
bb5:
  %t19 = load i1, ptr %l13, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 38
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t22, i64 %t25)
  %t29 = extractvalue { i32, i1 } %t28, 1
  %t30 = extractvalue { i32, i1 } %t28, 0
  store i32 %t30, ptr %l20
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb9, label %ok.32, !prof !99
ok.32:
  store i1 %t29, ptr %l19
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t33 = load i1, ptr %l19, !tbaa !21
  store i1 %t33, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  br label %bb10
bb10:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t34 = load i1, ptr %l14, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/types:Table", ptr %t35, i32 0, i32 33
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l2, !tbaa !21
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/types:Table", ptr %t40, i32 0, i32 33
  store i1 false, ptr %t42, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l1, !tbaa !23
  %t47 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %t43, i32 %t44, i64 0)
  store i1 %t47, ptr %l26
  br label %bb13
bb13:
  %t48 = load i1, ptr %l26, !tbaa !21
  store i1 %t48, ptr %l3, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/types:Table", ptr %t49, i32 0, i32 33
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/types:Table", ptr %t56, i32 0, i32 38
  %t59 = load i32, ptr %l1, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t62 = load i1, ptr %l3, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t58, i64 %t61, i1 %t62)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i1, ptr %l2, !tbaa !21
  %t70 = getelementptr %"compiler/types:Table", ptr %t66, i32 0, i32 33
  store i1 %t67, ptr %t70, !tbaa !21
  %t71 = load i1, ptr %l3, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUniqueSettled(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 38
  %t6 = sext i32 %a1 to i64
  %t9 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t6)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i64
  %l38 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 33}
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t9 = trunc i64 21 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  store i32 %t13, ptr %l9, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l13
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i32, ptr %l13, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l15, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l18
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t31, ptr %l19
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l22
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l8, !tbaa !29
  %t43 = load i32, ptr %l9, !tbaa !23
  %t44 = load i32, ptr %l14, !tbaa !23
  %t45 = load i32, ptr %l19, !tbaa !23
  %t46 = load i32, ptr %l22, !tbaa !23
  %t47 = load i32, ptr %l25, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefunc(ptr %v0, ptr %t42, i32 %t43, i32 %t44, i32 %t45, i32 %t46, i32 %t47, i64 0)
  store i32 %t48, ptr %l26
  br label %bb10
bb10:
  %t49 = load i32, ptr %l26, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb11:
  %t50 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t52 = trunc i64 20 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l29, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l33
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t62 = load ptr, ptr %l30, !tbaa !29
  %t63 = load i32, ptr %l33, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l34
  br label %bb15
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l37
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l29, !tbaa !29
  %t71 = load i32, ptr %l34, !tbaa !23
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t70, i32 %t71, i64 %t72)
  store i32 %t73, ptr %l38
  br label %bb17
bb17:
  %t74 = load i32, ptr %l38, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb18:
  %t75 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t77 = trunc i64 19 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l41, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l42, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l45
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = load i32, ptr %l45, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l46
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l1, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l49
  br label %bb23
bb23:
  %t95 = load ptr, ptr %l41, !tbaa !29
  %t96 = load i32, ptr %l46, !tbaa !23
  %t97 = load i32, ptr %l49, !tbaa !23
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t95, i32 %t96, i32 %t97)
  store i32 %t98, ptr %l50
  br label %bb24
bb24:
  %t99 = load i32, ptr %l50, !tbaa !23
  store i32 %t99, ptr %rv
  br label %ret
bb25:
  %t100 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t102 = trunc i64 22 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l53, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l54, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l57
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t112 = load ptr, ptr %l54, !tbaa !29
  %t113 = load i32, ptr %l57, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l58
  br label %bb29
bb29:
  %t115 = load ptr, ptr %l53, !tbaa !29
  %t116 = load i32, ptr %l58, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l59
  br label %bb30
bb30:
  %t118 = load i32, ptr %l59, !tbaa !23
  store i32 %t118, ptr %rv
  br label %ret
bb31:
  %t119 = load i32, ptr %l1, !tbaa !23
  store i32 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnspread(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i64
  %l17 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i32, ptr %l1, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr @G_2ecompiler_2ftypes_2eSpread, !tbaa !24
  %t24 = xor i64 %t22, -1
  %t25 = load i64, ptr %l13, !tbaa !24
  %t27 = and i64 %t25, %t24
  %t28 = load ptr, ptr %l7, !tbaa !29
  %t29 = load i32, ptr %l10, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t28, i32 %t29, i64 %t27)
  store i32 %t31, ptr %l17
  br label %bb7
bb7:
  %t32 = load i32, ptr %l17, !tbaa !23
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUntagged(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t9 = icmp eq i32 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr %l1, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l11
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l17
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l23
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l26
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t45 = load i32, ptr %l11, !tbaa !23
  %t46 = load i32, ptr %l14, !tbaa !23
  %t47 = load i32, ptr %l17, !tbaa !23
  %t48 = load i32, ptr %l20, !tbaa !23
  %t49 = load i64, ptr %l23, !tbaa !24
  %t50 = load i1, ptr %l26, !tbaa !21
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t44, i32 %t45, i32 %t46, i32 %t47, i32 %t48, i64 %t49, i1 %t50, i32 0)
  store i32 %t51, ptr %l27
  br label %bb11
bb11:
  %t52 = load i32, ptr %l27, !tbaa !23
  store i32 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 25, i64 %a1, i64 %a2, i64 %a3, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l9
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t10, %"compiler/types:data" %t11, i32 1)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l10, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eByAddress(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i64, ptr @G_2ecompiler_2ftypes_2eBigAggregate, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t13, %t12
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i32, ptr %l1, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l11, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l20
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l23
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l10, !tbaa !29
  %t39 = load i32, ptr %l11, !tbaa !23
  %t40 = load i32, ptr %l14, !tbaa !23
  %t41 = load i32, ptr %l17, !tbaa !23
  %t42 = load i32, ptr %l20, !tbaa !23
  %t43 = load i32, ptr %l23, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefunc(ptr %v0, ptr %t38, i32 %t39, i32 %t40, i32 %t41, i32 %t42, i32 %t43, i64 %a2)
  store i32 %t45, ptr %l25
  br label %bb9
bb9:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l14
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb6:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l23, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb11, label %bb12
bb11:
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  store ptr %l2, ptr %l44, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t66, ptr %l46, !tbaa !27
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i32, ptr %t70, i64 %t67
  %t72 = load i32, ptr %t71, !tbaa !33
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %v0, ptr %t65, i32 %t72)
  store { i64, ptr } %t75, ptr %l49
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t76, { i64, ptr } %t77)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb10
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb22
bb22:
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t84, ptr %l54
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eanchorsInto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l49 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l84 = alloca i64
  %l93 = alloca i64
  %l96 = alloca i64
  %l115 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca i1
  %l131 = alloca { i64, ptr }
  %l134 = alloca i1
  %l136 = alloca i1
  %l138 = alloca { i64, ptr }
  %l141 = alloca i1
  %l144 = alloca { i64, ptr }
  %l151 = alloca i32
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i32, ptr %l22, !tbaa !23
  store i32 %t6, ptr %l5, !tbaa !23
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 8
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l5, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l28
  br label %bb4
bb4:
  %t16 = load i32, ptr %l28, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  store i1 %t21, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l5, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l35
  br label %bb8
bb8:
  %t29 = load i1, ptr %l35, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l32, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb14
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l38, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l5, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l41
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l38, !tbaa !29
  %t40 = load i32, ptr %l41, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l42
  br label %bb13
bb13:
  %t42 = load i32, ptr %l42, !range !{i32 0, i32 6}
  %t44 = trunc i64 0 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l37, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l37, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i32 65536, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l5, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l49
  br label %bb18
bb18:
  %t56 = load i1, ptr %l49, !tbaa !21
  br i1 %t56, label %bb19, label %bb20
bb19:
  store i32 65536, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l51, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l54
  br label %bb22
bb22:
  %t64 = load ptr, ptr %l51, !tbaa !29
  %t65 = load i32, ptr %l54, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l55
  br label %bb23
bb23:
  %t67 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t67, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb29
bb26:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l64, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb28
bb28:
  %t98 = load i64, ptr %l64, !tbaa !24
  store i64 %t98, ptr %l61, !tbaa !24
  br label %bb29
bb29:
  %t99 = load i64, ptr %l61, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb67
bb32:
  br label %bb33
bb33:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t109 = load i64, ptr %l11, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l12, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l84, !tbaa !24
  %t123 = load i64, ptr %l84, !tbaa !24
  %t124 = icmp sge i64 %t123, 0
  br i1 %t124, label %bb34, label %bb35
bb34:
  %t126 = load i64, ptr %l84, !tbaa !24
  %t127 = icmp sle i64 %t126, 1152921504606846975
  br i1 %t127, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_ab5d312677a1c76d_705ca0c9b87dcf79)
  unreachable
bb36:
  %t129 = load i64, ptr %l84, !tbaa !24
  %t130 = mul i64 %t129, 8
  %t131 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t143 = icmp sgt i64 %t139, %t140
  br i1 %t143, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ab5d312677a1c76d_705ca0c9b87dcf79)
  unreachable
bb38:
  %t145 = load i64, ptr %l16, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb43
bb40:
  %t149 = load i64, ptr %l15, !tbaa !24
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = sub i64 %t149, %t150
  %t154 = load i64, ptr %l16, !tbaa !24
  %t157 = add i64 %t153, %t154
  %t159 = sub i64 %t157, 1
  %t160 = load i64, ptr %l16, !tbaa !24
  %t163 = sdiv i64 %t159, %t160
  store i64 %t163, ptr %l96, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb42
bb42:
  %t165 = load i64, ptr %l96, !tbaa !24
  store i64 %t165, ptr %l93, !tbaa !24
  br label %bb43
bb43:
  %t166 = load i64, ptr %l93, !tbaa !24
  store i64 %t166, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  %t167 = load i64, ptr %l18, !tbaa !24
  %t168 = load i64, ptr %l17, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t175 = load i64, ptr %l14, !tbaa !24
  %t176 = load i64, ptr %l18, !tbaa !24
  %t177 = load i64, ptr %l16, !tbaa !24
  %t180 = mul i64 %t176, %t177
  %t183 = add i64 %t175, %t180
  store i64 %t183, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l19, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t186, ptr %l115, !tbaa !27
  %t187 = load i64, ptr %l19, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i64, ptr %t190, i64 %t187
  %t192 = load i64, ptr %t191, !tbaa !34
  %t195 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i64, ptr %t196, i64 %t185
  store i64 %t192, ptr %t197, !tbaa !34
  br label %bb48
bb48:
  %t198 = load i64, ptr %l18, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l18, !tbaa !24
  br label %bb44
bb49:
  %t202 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = load i64, ptr %l12, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t204
  store i64 %t205, ptr %t210, !tbaa !34
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t212, ptr %l124, !tbaa !27
  %t213 = load i64, ptr %l12, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i32, ptr %t216, i64 %t213
  %t218 = load i32, ptr %t217, !tbaa !33
  %t221 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t211, i32 %t218)
  store i1 %t221, ptr %l127
  br label %bb50
bb50:
  %t222 = load i1, ptr %l127, !tbaa !21
  br i1 %t222, label %bb51, label %bb52
bb51:
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t224 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v2, ptr %t223, { i64, ptr } %t224)
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb54:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t228, ptr %l131, !tbaa !27
  %t229 = load i64, ptr %l12, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i32, ptr %t232, i64 %t229
  %t234 = load i32, ptr %t233, !tbaa !33
  %t237 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t227, i32 %t234)
  store i1 %t237, ptr %l134
  br label %bb55
bb55:
  %t238 = load i1, ptr %l134, !tbaa !21
  %t239 = xor i1 %t238, true
  br i1 %t239, label %bb56, label %bb57
bb56:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t242, ptr %l138, !tbaa !27
  %t243 = load i64, ptr %l12, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i32, ptr %t246, i64 %t243
  %t248 = load i32, ptr %t247, !tbaa !33
  %t251 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t241, i32 %t248)
  store i1 %t251, ptr %l141
  br label %bb58
bb57:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb59
bb58:
  %t252 = load i1, ptr %l141, !tbaa !21
  %t253 = xor i1 %t252, true
  store i1 %t253, ptr %l136, !tbaa !21
  br label %bb59
bb59:
  %t255 = load i1, ptr %l136, !tbaa !21
  br i1 %t255, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t257, ptr %l144, !tbaa !27
  %t258 = load i64, ptr %l12, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr i32, ptr %t261, i64 %t258
  %t263 = load i32, ptr %t262, !tbaa !33
  %t264 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t265 = load ptr, ptr %l3, !tbaa !29
  %t266 = load i64, ptr %l4, !tbaa !24
  %t268 = add i64 %t266, 1
  %t274 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eanchorsInto(ptr %v0, ptr %s4, ptr %v2, ptr %t256, i32 %t263, { i64, ptr } %t264, ptr %t265, i64 %t268)
  store i32 %t274, ptr %l151
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb64, label %ok.276, !prof !99
ok.276:
  br label %bb63
bb63:
  br label %bb65
bb64:
  %t277 = load i32, ptr %l151, !tbaa !23
  %t278 = lshr i32 %t277, 16
  %t279 = and i32 %t277, 65535
  %t280 = icmp eq i32 %t278, 1
  %t281 = select i1 %t280, i32 1, i32 0
  %t282 = icmp eq i32 %t277, 0
  %t283 = shl i32 %t281, 16
  %t284 = or i32 %t283, %t279
  %t285 = select i1 %t282, i32 0, i32 %t284
  call void @__olang_scope_close(ptr %s4)
  store i32 %t285, ptr %rv
  br label %ret
bb65:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb66:
  %t287 = load i64, ptr %l11, !tbaa !24
  %t289 = add i64 %t287, 1
  store i64 %t289, ptr %l11, !tbaa !24
  br label %bb30
bb67:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp eq i32 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l10, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l13
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l10, !tbaa !29
  %t32 = load i32, ptr %l13, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t33, ptr %l14
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l18
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l15, !tbaa !29
  %t41 = load i32, ptr %l18, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l19
  br label %bb8
bb8:
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t47 = add i64 %t44, %t46
  %t48 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t43, i64 %t44)
  %t59 = getelementptr i8, ptr %t58, i64 %t44
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t45)
  %t61 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t61, ptr %t48, i64 %t49)
  %t62 = getelementptr i8, ptr %t61, i64 %t49
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = getelementptr i8, ptr %t62, i64 %t53
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t58, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:data"
  %rv = alloca %"compiler/types:data"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 1
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:data" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:data" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"compiler/types:body"
  %l6 = alloca %"compiler/types:body"
  %l7 = alloca i32
  %l9 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/types:body"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  %t7 = call { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, %"compiler/types:body" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/types:body" } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store %"compiler/types:body" %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load %"compiler/types:body", ptr %l6
  store %"compiler/types:body" %t12, ptr %l2
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t13, i1 false, i1 false)
  store %"compiler/types:body" %t15, ptr %l9
  br label %bb4
bb4:
  %t16 = load %"compiler/types:body", ptr %l9
  store %"compiler/types:body" %t16, ptr %l2
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/types:body", ptr %l2
  store %"compiler/types:body" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:body", ptr %rv
  ret %"compiler/types:body" %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:data"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l43 = alloca %"compiler/types:data"
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca ptr
  %l67 = alloca i64
  %l98 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l119 = alloca i32
  %l120 = alloca ptr
  %l122 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l130 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %l144 = alloca i1
  %l146 = alloca { i64, ptr }
  %l150 = alloca i32
  %l153 = alloca i1
  %l155 = alloca { i64, ptr }
  %l159 = alloca i32
  %l170 = alloca i64
  %l173 = alloca i64
  %l193 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l198 = alloca i32
  %l201 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l217 = alloca i32
  %l220 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca ptr
  %l227 = alloca i32
  %l233 = alloca i64
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l244 = alloca i32
  %l245 = alloca i32
  %l251 = alloca ptr
  %l252 = alloca ptr
  %l255 = alloca i32
  %l256 = alloca ptr
  %l261 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l269 = alloca { i64, ptr }
  %l282 = alloca ptr
  %l283 = alloca ptr
  %l286 = alloca i32
  %l290 = alloca i32
  %l296 = alloca i32
  %l299 = alloca ptr
  %l301 = alloca { i64, ptr }
  %l307 = alloca ptr
  %l310 = alloca i32
  %l311 = alloca { i64, ptr }
  %l319 = alloca i1
  %l320 = alloca { i64, ptr }
  %l330 = alloca i1
  %l337 = alloca { i64, ptr }
  %l343 = alloca i64
  %l346 = alloca i64
  %l367 = alloca ptr
  %l370 = alloca { i64, ptr }
  %l375 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l391 = alloca i64
  %l394 = alloca i64
  %l416 = alloca { i64, ptr }
  %l427 = alloca ptr
  %l428 = alloca ptr
  %l431 = alloca i32
  %l436 = alloca ptr
  %l437 = alloca ptr
  %l440 = alloca i32
  %l447 = alloca { i64, ptr }
  %l448 = alloca ptr
  %l451 = alloca i32
  %l452 = alloca { i64, ptr }
  %l458 = alloca i64
  %l461 = alloca i64
  %l482 = alloca ptr
  %l485 = alloca { i64, ptr }
  %l488 = alloca { i64, ptr }
  %l489 = alloca { i64, ptr }
  %l494 = alloca ptr
  %l495 = alloca ptr
  %l497 = alloca { i64, ptr }
  %l500 = alloca i32
  %l516 = alloca i32
  %l520 = alloca ptr
  %l523 = alloca { i64, ptr }
  %l526 = alloca i1
  %l527 = alloca i1
  %l530 = alloca ptr
  %l532 = alloca { i64, ptr }
  %l540 = alloca ptr
  %l543 = alloca { i64, ptr }
  %l549 = alloca ptr
  %l550 = alloca ptr
  %l553 = alloca i32
  %l557 = alloca ptr
  %l558 = alloca ptr
  %l561 = alloca i32
  %l566 = alloca ptr
  %l567 = alloca ptr
  %l568 = alloca ptr
  %l571 = alloca i32
  %l572 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s58 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l43
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l43
  store %"compiler/types:data" %t6, ptr %l3
  %t7 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l4
  %t10 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t15, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb361
bb6:
  %t17 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t19 = trunc i64 15 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb361
bb11:
  %t24 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t26 = trunc i64 16 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t29, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb361
bb16:
  %t31 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t33 = trunc i64 17 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t36, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb361
bb21:
  %t38 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t40 = trunc i64 28 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l59, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l60, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l63
  br label %bb25
bb25:
  %t50 = load ptr, ptr %l59, !tbaa !29
  %t51 = load ptr, ptr %l60, !tbaa !29
  %t52 = load i32, ptr %l63, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t50, ptr %t51, i32 %t52)
  br label %bb26
bb26:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l64, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t54, i32 %t55)
  store i64 %t58, ptr %l67
  br label %bb27
bb27:
  %t59 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t61 = load i64, ptr %l67, !tbaa !65
  %t62 = call i64 @__olang_fmt_u64(ptr null, i64 %t61)
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = getelementptr i8, ptr %t64, i64 %t60
  %t66 = call i64 @__olang_fmt_u64(ptr %t65, i64 %t61)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t76, { i64, ptr } %t75)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb361
bb29:
  %t78 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t80 = trunc i64 1 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  br label %bb58
bb31:
  %t83 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t85 = trunc i64 2 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb32, label %bb33
bb32:
  br label %bb58
bb33:
  %t88 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t90 = trunc i64 3 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb34, label %bb35
bb34:
  br label %bb58
bb35:
  %t93 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t95 = trunc i64 4 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb36, label %bb37
bb36:
  br label %bb58
bb37:
  %t98 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t100 = trunc i64 5 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  %t103 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t105 = trunc i64 6 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb40, label %bb41
bb40:
  br label %bb58
bb41:
  %t108 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t110 = trunc i64 7 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb42, label %bb43
bb42:
  br label %bb58
bb43:
  %t113 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t115 = trunc i64 8 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb44, label %bb45
bb44:
  br label %bb58
bb45:
  %t118 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t120 = trunc i64 9 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb46, label %bb47
bb46:
  br label %bb58
bb47:
  %t123 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t125 = trunc i64 10 to i32
  %t126 = icmp eq i32 %t123, %t125
  br i1 %t126, label %bb48, label %bb49
bb48:
  br label %bb58
bb49:
  %t128 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t130 = trunc i64 11 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  %t133 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t135 = trunc i64 12 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb52, label %bb53
bb52:
  br label %bb58
bb53:
  %t138 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t140 = trunc i64 13 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  %t143 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t145 = trunc i64 14 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l98, !tbaa !29
  %t149 = load i32, ptr %l2, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l102, !tbaa !27
  br label %bb61
bb60:
  %t155 = load i32, ptr %l2, !tbaa !23
  %t157 = sext i32 %t155 to i64
  %t159 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimNames, i64 0, i64 %t157
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !37
  store { i64, ptr } %t160, ptr %l102, !tbaa !27
  br label %bb61
bb61:
  %t162 = load ptr, ptr @__olang_prog_scope
  %t163 = load ptr, ptr %l98, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l102, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %t162, ptr %t163, { i64, ptr } %t164)
  br label %bb62
bb62:
  br label %bb361
bb63:
  %t165 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t167 = trunc i64 31 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb71
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t170 = load ptr, ptr %l1, !tbaa !29
  store ptr %t170, ptr %l108, !tbaa !29
  %t171 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t172 = load i64, ptr %t171, !tbaa !24
  %t174 = icmp eq i64 %t172, 1
  br i1 %t174, label %bb67, label %bb68
bb67:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l111, !tbaa !27
  br label %bb69
bb68:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l111, !tbaa !27
  br label %bb69
bb69:
  %t176 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t182 = call i64 @__olang_fmt_i64(ptr null, i64 %t177)
  %t183 = add i64 %t180, %t182
  %t184 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t183)
  call void @olang_textcopy(ptr %t184, ptr %t179, i64 %t180)
  %t185 = getelementptr i8, ptr %t184, i64 %t180
  %t186 = call i64 @__olang_fmt_i64(ptr %t185, i64 %t177)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t184, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = extractvalue { i64, ptr } %t188, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  %t196 = load ptr, ptr %l108, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s8, ptr %t196, { i64, ptr } %t195)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s8)
  br label %bb361
bb71:
  %t198 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t200 = trunc i64 18 to i32
  %t201 = icmp eq i32 %t198, %t200
  br i1 %t201, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb122
bb74:
  store %olang.scope zeroinitializer, ptr %s10
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l2, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t207, ptr %l119
  br label %bb75
bb75:
  %t208 = load i32, ptr %l119, !tbaa !23
  store i32 %t208, ptr %l5, !tbaa !23
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l120, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/types:Table", ptr %t210, i32 0, i32 14
  store ptr %t212, ptr %l122, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i32, ptr %l5, !tbaa !23
  %t217 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t213, i32 %t214)
  store i64 %t217, ptr %l125
  br label %bb76
bb76:
  %t218 = load ptr, ptr %l122, !tbaa !29
  %t219 = load i64, ptr %l125, !tbaa !24
  %t220 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t218, i64 %t219)
  store { i64, ptr } %t220, ptr %l126
  br label %bb77
bb77:
  %t221 = load ptr, ptr %l120, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l126, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t221, { i64, ptr } %t222)
  br label %bb78
bb78:
  %t223 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t223, i8 58)
  br label %bb79
bb79:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l128, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/types:Table", ptr %t226, i32 0, i32 0
  %t229 = load ptr, ptr %t228, !tbaa !29
  store ptr %t229, ptr %l130, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l5, !tbaa !23
  %t234 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t230, i32 %t231)
  store i32 %t234, ptr %l133
  br label %bb80
bb80:
  %t235 = load ptr, ptr @__olang_prog_scope
  %t236 = load ptr, ptr %l130, !tbaa !29
  %t237 = load i32, ptr %l133, !tbaa !23
  %t238 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t235, ptr %s10, ptr %t236, i32 %t237)
  store { i64, ptr } %t238, ptr %l134
  br label %bb81
bb81:
  %t239 = load ptr, ptr %l128, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l134, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s10, ptr %t239, { i64, ptr } %t240)
  br label %bb82
bb82:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l135, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l2, !tbaa !23
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t242, i32 %t243)
  store i32 %t246, ptr %l138
  br label %bb83
bb83:
  %t247 = load ptr, ptr %l135, !tbaa !29
  %t248 = load i32, ptr %l138, !tbaa !23
  %t249 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t247, i32 %t248)
  store { i64, ptr } %t249, ptr %l139
  br label %bb84
bb84:
  %t250 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t250, ptr %l6, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l7, !tbaa !24
  %t255 = load i64, ptr %l7, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb85, label %bb86
bb85:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t260, ptr %l146, !tbaa !27
  %t261 = load i64, ptr %l7, !tbaa !24
  %t263 = sub i64 %t261, 1
  %t265 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr i32, ptr %t266, i64 %t263
  %t268 = load i32, ptr %t267, !tbaa !33
  %t271 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t259, i32 %t268)
  store i32 %t271, ptr %l150
  br label %bb87
bb86:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb88
bb87:
  %t272 = load i32, ptr %l150, !range !{i32 0, i32 33}
  %t274 = trunc i64 30 to i32
  %t275 = icmp eq i32 %t272, %t274
  store i1 %t275, ptr %l144, !tbaa !21
  br label %bb88
bb88:
  %t277 = load i1, ptr %l144, !tbaa !21
  br i1 %t277, label %bb89, label %bb90
bb89:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t279, ptr %l155, !tbaa !27
  %t280 = load i64, ptr %l7, !tbaa !24
  %t282 = sub i64 %t280, 1
  %t284 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i32, ptr %t285, i64 %t282
  %t287 = load i32, ptr %t286, !tbaa !33
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t278, i32 %t287)
  store i32 %t290, ptr %l159
  br label %bb91
bb90:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb92
bb91:
  %t291 = load i32, ptr %l159, !tbaa !23
  %t292 = icmp eq i32 %t291, 0
  store i1 %t292, ptr %l153, !tbaa !21
  br label %bb92
bb92:
  %t294 = load i1, ptr %l153, !tbaa !21
  br i1 %t294, label %bb93, label %bb94
bb93:
  %t295 = load i64, ptr %l7, !tbaa !24
  %t297 = sub i64 %t295, 1
  store i64 %t297, ptr %l7, !tbaa !24
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t299 = load i64, ptr %l7, !tbaa !24
  %t301 = icmp sgt i64 %t299, 0
  br i1 %t301, label %bb96, label %bb97
bb96:
  %t303 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t303, i8 60)
  br label %bb98
bb97:
  br label %bb121
bb98:
  store i64 0, ptr %l8, !tbaa !24
  %t305 = load i64, ptr %l7, !tbaa !24
  store i64 %t305, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t307 = load i64, ptr %l9, !tbaa !24
  %t308 = load i64, ptr %l8, !tbaa !24
  %t311 = icmp sgt i64 %t307, %t308
  br i1 %t311, label %bb99, label %bb100
bb99:
  %t313 = load i64, ptr %l10, !tbaa !24
  %t315 = icmp sgt i64 %t313, 0
  br i1 %t315, label %bb101, label %bb102
bb100:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb104
bb101:
  %t317 = load i64, ptr %l9, !tbaa !24
  %t318 = load i64, ptr %l8, !tbaa !24
  %t321 = sub i64 %t317, %t318
  %t322 = load i64, ptr %l10, !tbaa !24
  %t325 = add i64 %t321, %t322
  %t327 = sub i64 %t325, 1
  %t328 = load i64, ptr %l10, !tbaa !24
  %t331 = sdiv i64 %t327, %t328
  store i64 %t331, ptr %l173, !tbaa !24
  br label %bb103
bb102:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb103
bb103:
  %t333 = load i64, ptr %l173, !tbaa !24
  store i64 %t333, ptr %l170, !tbaa !24
  br label %bb104
bb104:
  %t334 = load i64, ptr %l170, !tbaa !24
  store i64 %t334, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb105
bb105:
  %t335 = load i64, ptr %l12, !tbaa !24
  %t336 = load i64, ptr %l11, !tbaa !24
  %t339 = icmp slt i64 %t335, %t336
  %t341 = xor i1 %t339, true
  br i1 %t341, label %bb106, label %bb107
bb106:
  br label %bb119
bb107:
  br label %bb108
bb108:
  %t343 = load i64, ptr %l8, !tbaa !24
  %t344 = load i64, ptr %l12, !tbaa !24
  %t345 = load i64, ptr %l10, !tbaa !24
  %t348 = mul i64 %t344, %t345
  %t351 = add i64 %t343, %t348
  store i64 %t351, ptr %l13, !tbaa !24
  %t353 = load i64, ptr %l13, !tbaa !24
  %t355 = icmp sgt i64 %t353, 0
  br i1 %t355, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s15
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l193, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t359, ptr %l195, !tbaa !27
  %t360 = load i64, ptr %l13, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t360
  %t365 = load i32, ptr %t364, !tbaa !33
  %t368 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t358, i32 %t365)
  store i32 %t368, ptr %l198
  br label %bb111
bb110:
  br label %bb116
bb111:
  %t369 = load i32, ptr %l198, !range !{i32 0, i32 33}
  %t371 = trunc i64 30 to i32
  %t372 = icmp eq i32 %t369, %t371
  br i1 %t372, label %bb112, label %bb113
bb112:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l201, !tbaa !27
  br label %bb114
bb113:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l201, !tbaa !27
  br label %bb114
bb114:
  %t374 = load ptr, ptr %l193, !tbaa !29
  %t375 = load { i64, ptr }, ptr %l201, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t374, { i64, ptr } %t375)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s15)
  br label %bb116
bb116:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t378 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t378, ptr %l204, !tbaa !27
  %t379 = load i64, ptr %l13, !tbaa !24
  %t381 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = getelementptr i32, ptr %t382, i64 %t379
  %t384 = load i32, ptr %t383, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t376, ptr %t377, i32 %t384)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t388 = load i64, ptr %l12, !tbaa !24
  %t390 = add i64 %t388, 1
  store i64 %t390, ptr %l12, !tbaa !24
  br label %bb105
bb119:
  %t392 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t392, i8 62)
  br label %bb120
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s10)
  br label %bb361
bb122:
  %t394 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t396 = trunc i64 19 to i32
  %t397 = icmp eq i32 %t394, %t396
  br i1 %t397, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb137
bb125:
  store %olang.scope zeroinitializer, ptr %s17
  %t399 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s17, ptr %t399, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb126
bb126:
  %t401 = load ptr, ptr %l0, !tbaa !29
  store ptr %t401, ptr %l213, !tbaa !29
  %t402 = load ptr, ptr %l1, !tbaa !29
  store ptr %t402, ptr %l214, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load i32, ptr %l2, !tbaa !23
  %t407 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t403, i32 %t404)
  store i32 %t407, ptr %l217
  br label %bb127
bb127:
  %t408 = load ptr, ptr %l213, !tbaa !29
  %t409 = load ptr, ptr %l214, !tbaa !29
  %t410 = load i32, ptr %l217, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t408, ptr %t409, i32 %t410)
  br label %bb128
bb128:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load i32, ptr %l2, !tbaa !23
  %t415 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t411, i32 %t412)
  store i32 %t415, ptr %l220
  br label %bb129
bb129:
  %t416 = load i32, ptr %l220, !tbaa !23
  %t417 = icmp ne i32 %t416, 0
  br i1 %t417, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s18
  %t419 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s18, ptr %t419, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t421 = load ptr, ptr %l0, !tbaa !29
  store ptr %t421, ptr %l223, !tbaa !29
  %t422 = load ptr, ptr %l1, !tbaa !29
  store ptr %t422, ptr %l224, !tbaa !29
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i32, ptr %l2, !tbaa !23
  %t427 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t423, i32 %t424)
  store i32 %t427, ptr %l227
  br label %bb133
bb133:
  %t428 = load ptr, ptr %l223, !tbaa !29
  %t429 = load ptr, ptr %l224, !tbaa !29
  %t430 = load i32, ptr %l227, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t428, ptr %t429, i32 %t430)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s18)
  br label %bb135
bb135:
  %t431 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t431, i8 62)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s17)
  br label %bb361
bb137:
  %t433 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t435 = trunc i64 20 to i32
  %t436 = icmp eq i32 %t433, %t435
  br i1 %t436, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb159
bb140:
  store %olang.scope zeroinitializer, ptr %s19
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load i32, ptr %l2, !tbaa !23
  %t442 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t438, i32 %t439)
  store i64 %t442, ptr %l233
  br label %bb141
bb141:
  %t443 = load i64, ptr %l233, !tbaa !24
  store i64 %t443, ptr %l14, !tbaa !24
  %t444 = load i64, ptr %l14, !tbaa !24
  %t445 = load i64, ptr @G_2ecompiler_2ftypes_2eSpread, !tbaa !24
  %t448 = and i64 %t444, %t445
  %t450 = icmp ne i64 %t448, 0
  br i1 %t450, label %bb142, label %bb143
bb142:
  store %olang.scope zeroinitializer, ptr %s20
  %t452 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s20, ptr %t452, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb144
bb143:
  br label %bb148
bb144:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l239, !tbaa !29
  %t455 = load ptr, ptr %l1, !tbaa !29
  store ptr %t455, ptr %l240, !tbaa !29
  %t456 = load ptr, ptr %l0, !tbaa !29
  store ptr %t456, ptr %l241, !tbaa !29
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load i32, ptr %l2, !tbaa !23
  %t461 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t457, i32 %t458)
  store i32 %t461, ptr %l244
  br label %bb145
bb145:
  %t462 = load ptr, ptr %l241, !tbaa !29
  %t463 = load i32, ptr %l244, !tbaa !23
  %t464 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t462, i32 %t463)
  store i32 %t464, ptr %l245
  br label %bb146
bb146:
  %t465 = load ptr, ptr %l239, !tbaa !29
  %t466 = load ptr, ptr %l240, !tbaa !29
  %t467 = load i32, ptr %l245, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t465, ptr %t466, i32 %t467)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %ret
bb148:
  %t468 = load i64, ptr %l14, !tbaa !24
  %t469 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t472 = and i64 %t468, %t469
  %t474 = icmp ne i64 %t472, 0
  br i1 %t474, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s21
  %t476 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s21, ptr %t476, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb151
bb150:
  br label %bb152
bb151:
  call void @__olang_scope_close(ptr %s21)
  br label %bb152
bb152:
  %t478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t478, ptr %l251, !tbaa !29
  %t479 = load ptr, ptr %l1, !tbaa !29
  store ptr %t479, ptr %l252, !tbaa !29
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load i32, ptr %l2, !tbaa !23
  %t484 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t480, i32 %t481)
  store i32 %t484, ptr %l255
  br label %bb153
bb153:
  %t485 = load ptr, ptr %l251, !tbaa !29
  %t486 = load ptr, ptr %l252, !tbaa !29
  %t487 = load i32, ptr %l255, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t485, ptr %t486, i32 %t487)
  br label %bb154
bb154:
  %t488 = load ptr, ptr %l1, !tbaa !29
  store ptr %t488, ptr %l256, !tbaa !29
  %t489 = load i64, ptr %l14, !tbaa !24
  %t490 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t493 = and i64 %t489, %t490
  %t495 = icmp ne i64 %t493, 0
  br i1 %t495, label %bb155, label %bb156
bb155:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l261, !tbaa !27
  br label %bb157
bb156:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l261, !tbaa !27
  br label %bb157
bb157:
  %t497 = load ptr, ptr %l256, !tbaa !29
  %t498 = load { i64, ptr }, ptr %l261, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t497, { i64, ptr } %t498)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s19)
  br label %bb361
bb159:
  %t499 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t501 = trunc i64 21 to i32
  %t502 = icmp eq i32 %t499, %t501
  br i1 %t502, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb254
bb162:
  store %olang.scope zeroinitializer, ptr %s22
  %t504 = load ptr, ptr %l1, !tbaa !29
  store ptr %t504, ptr %l264, !tbaa !29
  %t505 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 6
  %t506 = load i64, ptr %t505, !tbaa !24
  %t507 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t510 = and i64 %t506, %t507
  %t512 = icmp ne i64 %t510, 0
  br i1 %t512, label %bb163, label %bb164
bb163:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l269, !tbaa !27
  br label %bb165
bb164:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l269, !tbaa !27
  br label %bb165
bb165:
  %t514 = load ptr, ptr %l264, !tbaa !29
  %t515 = load { i64, ptr }, ptr %l269, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s22, ptr %t514, { i64, ptr } %t515)
  br label %bb166
bb166:
  %t516 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 6
  %t517 = load i64, ptr %t516, !tbaa !24
  %t519 = ashr i64 %t517, 8
  %t521 = icmp ne i64 %t519, 0
  br i1 %t521, label %bb167, label %bb168
bb167:
  %t523 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t523, i8 91)
  br label %bb169
bb168:
  br label %bb172
bb169:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load ptr, ptr %l1, !tbaa !29
  %t527 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 6
  %t528 = load i64, ptr %t527, !tbaa !24
  %t530 = ashr i64 %t528, 8
  %t532 = trunc i64 %t530 to i32
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t525, ptr %t526, i32 %t532)
  br label %bb170
bb170:
  %t537 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t537, i8 93)
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t539 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t539, i8 40)
  br label %bb173
bb173:
  %t541 = load ptr, ptr %l0, !tbaa !29
  store ptr %t541, ptr %l282, !tbaa !29
  %t542 = load ptr, ptr %l1, !tbaa !29
  store ptr %t542, ptr %l283, !tbaa !29
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load i32, ptr %l2, !tbaa !23
  %t547 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t543, i32 %t544)
  store i32 %t547, ptr %l286
  br label %bb174
bb174:
  %t548 = load ptr, ptr %l282, !tbaa !29
  %t549 = load ptr, ptr %l283, !tbaa !29
  %t550 = load i32, ptr %l286, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t548, ptr %t549, i32 %t550)
  br label %bb175
bb175:
  %t551 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t551, i8 41)
  br label %bb176
bb176:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load i32, ptr %l2, !tbaa !23
  %t557 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t553, i32 %t554)
  store i32 %t557, ptr %l290
  br label %bb177
bb177:
  %t558 = load i32, ptr %l290, !tbaa !23
  store i32 %t558, ptr %l15, !tbaa !23
  %t559 = load i32, ptr %l15, !tbaa !23
  %t560 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t563 = icmp ne i32 %t559, %t560
  br i1 %t563, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s24
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i32, ptr %l15, !tbaa !23
  %t569 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t565, i32 %t566)
  store i32 %t569, ptr %l296
  br label %bb180
bb179:
  br label %bb190
bb180:
  %t570 = load i32, ptr %l296, !range !{i32 0, i32 33}
  %t572 = trunc i64 21 to i32
  %t573 = icmp eq i32 %t570, %t572
  store i1 %t573, ptr %l16, !tbaa !21
  %t575 = load ptr, ptr %l1, !tbaa !29
  store ptr %t575, ptr %l299, !tbaa !29
  %t576 = load i1, ptr %l16, !tbaa !21
  br i1 %t576, label %bb181, label %bb182
bb181:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l301, !tbaa !27
  br label %bb183
bb182:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l301, !tbaa !27
  br label %bb183
bb183:
  %t578 = load ptr, ptr %l299, !tbaa !29
  %t579 = load { i64, ptr }, ptr %l301, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s24, ptr %t578, { i64, ptr } %t579)
  br label %bb184
bb184:
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t581 = load ptr, ptr %l1, !tbaa !29
  %t582 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t580, ptr %t581, i32 %t582)
  br label %bb185
bb185:
  %t586 = load i1, ptr %l16, !tbaa !21
  br i1 %t586, label %bb186, label %bb187
bb186:
  %t588 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t588, i8 41)
  br label %bb188
bb187:
  br label %bb189
bb188:
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s24)
  br label %bb190
bb190:
  %t590 = load ptr, ptr %l0, !tbaa !29
  store ptr %t590, ptr %l307, !tbaa !29
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load i32, ptr %l2, !tbaa !23
  %t595 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t591, i32 %t592)
  store i32 %t595, ptr %l310
  br label %bb191
bb191:
  %t596 = load ptr, ptr %l307, !tbaa !29
  %t597 = load i32, ptr %l310, !tbaa !23
  %t598 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t596, i32 %t597)
  store { i64, ptr } %t598, ptr %l311
  br label %bb192
bb192:
  %t599 = load { i64, ptr }, ptr %l311, !tbaa !27
  store { i64, ptr } %t599, ptr %l17, !tbaa !27
  %t600 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t602 = extractvalue { i64, ptr } %t600, 0
  %t604 = icmp sgt i64 %t602, 0
  br i1 %t604, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s26
  %t606 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s26, ptr %t606, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb195
bb194:
  br label %bb203
bb195:
  %t608 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t610 = extractvalue { i64, ptr } %t608, 0
  %t612 = icmp eq i64 %t610, 1
  br i1 %t612, label %bb196, label %bb197
bb196:
  %t614 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t614, ptr %l320, !tbaa !27
  %t615 = getelementptr { i64, ptr }, ptr %l320, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !27
  %t617 = getelementptr i32, ptr %t616, i64 0
  %t618 = load i32, ptr %t617, !tbaa !33
  %t619 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t622 = icmp eq i32 %t618, %t619
  store i1 %t622, ptr %l319, !tbaa !21
  br label %bb198
bb197:
  store i1 false, ptr %l319, !tbaa !21
  br label %bb198
bb198:
  %t624 = load i1, ptr %l319, !tbaa !21
  %t625 = xor i1 %t624, true
  br i1 %t625, label %bb199, label %bb200
bb199:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load ptr, ptr %l1, !tbaa !29
  %t629 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonErrs(ptr %v0, ptr %v1, ptr %v0, ptr %t627, ptr %t628, { i64, ptr } %t629)
  br label %bb201
bb200:
  br label %bb202
bb201:
  br label %bb202
bb202:
  call void @__olang_scope_close(ptr %s26)
  br label %bb203
bb203:
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t635 = getelementptr %"compiler/types:Table", ptr %t633, i32 0, i32 3
  %t636 = load i1, ptr %t635, !tbaa !21
  br i1 %t636, label %bb204, label %bb205
bb204:
  %t638 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t639 = load i64, ptr %t638, !tbaa !24
  %t641 = icmp ne i64 %t639, 0
  store i1 %t641, ptr %l330, !tbaa !21
  br label %bb206
bb205:
  store i1 false, ptr %l330, !tbaa !21
  br label %bb206
bb206:
  %t643 = load i1, ptr %l330, !tbaa !21
  br i1 %t643, label %bb207, label %bb208
bb207:
  %t644 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t644, i8 123)
  br label %bb209
bb208:
  br label %bb230
bb209:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/types:Table", ptr %t646, i32 0, i32 30
  %t649 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t650 = load i64, ptr %t649, !tbaa !24
  %t653 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t648, i64 %t650)
  store { i64, ptr } %t653, ptr %l337
  br label %bb210
bb210:
  %t654 = load { i64, ptr }, ptr %l337, !tbaa !27
  store { i64, ptr } %t654, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t655 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t657 = extractvalue { i64, ptr } %t655, 0
  store i64 %t657, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t659 = load i64, ptr %l20, !tbaa !24
  %t660 = load i64, ptr %l19, !tbaa !24
  %t663 = icmp sgt i64 %t659, %t660
  br i1 %t663, label %bb211, label %bb212
bb211:
  %t665 = load i64, ptr %l21, !tbaa !24
  %t667 = icmp sgt i64 %t665, 0
  br i1 %t667, label %bb213, label %bb214
bb212:
  store i64 0, ptr %l343, !tbaa !24
  br label %bb216
bb213:
  %t669 = load i64, ptr %l20, !tbaa !24
  %t670 = load i64, ptr %l19, !tbaa !24
  %t673 = sub i64 %t669, %t670
  %t674 = load i64, ptr %l21, !tbaa !24
  %t677 = add i64 %t673, %t674
  %t679 = sub i64 %t677, 1
  %t680 = load i64, ptr %l21, !tbaa !24
  %t683 = sdiv i64 %t679, %t680
  store i64 %t683, ptr %l346, !tbaa !24
  br label %bb215
bb214:
  store i64 0, ptr %l346, !tbaa !24
  br label %bb215
bb215:
  %t685 = load i64, ptr %l346, !tbaa !24
  store i64 %t685, ptr %l343, !tbaa !24
  br label %bb216
bb216:
  %t686 = load i64, ptr %l343, !tbaa !24
  store i64 %t686, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb217
bb217:
  store %olang.scope zeroinitializer, ptr %s30
  %t687 = load i64, ptr %l23, !tbaa !24
  %t688 = load i64, ptr %l22, !tbaa !24
  %t691 = icmp slt i64 %t687, %t688
  %t693 = xor i1 %t691, true
  br i1 %t693, label %bb218, label %bb219
bb218:
  call void @__olang_scope_close(ptr %s30)
  br label %bb228
bb219:
  br label %bb220
bb220:
  %t695 = load i64, ptr %l19, !tbaa !24
  %t696 = load i64, ptr %l23, !tbaa !24
  %t697 = load i64, ptr %l21, !tbaa !24
  %t700 = mul i64 %t696, %t697
  %t703 = add i64 %t695, %t700
  store i64 %t703, ptr %l24, !tbaa !24
  %t705 = load i64, ptr %l24, !tbaa !24
  %t707 = icmp sgt i64 %t705, 0
  br i1 %t707, label %bb221, label %bb222
bb221:
  %t709 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t709, i8 44)
  br label %bb223
bb222:
  br label %bb224
bb223:
  br label %bb224
bb224:
  %t711 = load ptr, ptr %l1, !tbaa !29
  store ptr %t711, ptr %l367, !tbaa !29
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/types:Table", ptr %t712, i32 0, i32 0
  %t715 = load ptr, ptr %t714, !tbaa !29
  %t716 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t716, ptr %l370, !tbaa !27
  %t717 = load i64, ptr %l24, !tbaa !24
  %t719 = getelementptr { i64, ptr }, ptr %l370, i32 0, i32 1
  %t720 = load ptr, ptr %t719, !tbaa !27
  %t721 = getelementptr i64, ptr %t720, i64 %t717
  %t722 = load i64, ptr %t721, !tbaa !34
  %t724 = trunc i64 %t722 to i32
  %t726 = load ptr, ptr @__olang_prog_scope
  %t729 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t726, ptr %s30, ptr %t715, i32 %t724)
  store { i64, ptr } %t729, ptr %l375
  br label %bb225
bb225:
  %t730 = load ptr, ptr %l367, !tbaa !29
  %t731 = load { i64, ptr }, ptr %l375, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s30, ptr %t730, { i64, ptr } %t731)
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s30)
  br label %bb227
bb227:
  %t732 = load i64, ptr %l23, !tbaa !24
  %t734 = add i64 %t732, 1
  store i64 %t734, ptr %l23, !tbaa !24
  br label %bb217
bb228:
  %t736 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t736, i8 125)
  br label %bb229
bb229:
  br label %bb230
bb230:
  %t738 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t739 = load i64, ptr %t738, !tbaa !24
  %t741 = icmp ne i64 %t739, 0
  br i1 %t741, label %bb231, label %bb232
bb231:
  store %olang.scope zeroinitializer, ptr %s33
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t745 = getelementptr %"compiler/types:Table", ptr %t743, i32 0, i32 28
  %t746 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t747 = load i64, ptr %t746, !tbaa !24
  %t750 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t745, i64 %t747)
  store { i64, ptr } %t750, ptr %l384
  br label %bb233
bb232:
  br label %bb253
bb233:
  %t751 = load { i64, ptr }, ptr %l384, !tbaa !27
  store { i64, ptr } %t751, ptr %l25, !tbaa !27
  %t752 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s33, ptr %t752, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb234
bb234:
  store i64 0, ptr %l26, !tbaa !24
  %t754 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t754, 0
  store i64 %t756, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t758 = load i64, ptr %l27, !tbaa !24
  %t759 = load i64, ptr %l26, !tbaa !24
  %t762 = icmp sgt i64 %t758, %t759
  br i1 %t762, label %bb235, label %bb236
bb235:
  %t764 = load i64, ptr %l28, !tbaa !24
  %t766 = icmp sgt i64 %t764, 0
  br i1 %t766, label %bb237, label %bb238
bb236:
  store i64 0, ptr %l391, !tbaa !24
  br label %bb240
bb237:
  %t768 = load i64, ptr %l27, !tbaa !24
  %t769 = load i64, ptr %l26, !tbaa !24
  %t772 = sub i64 %t768, %t769
  %t773 = load i64, ptr %l28, !tbaa !24
  %t776 = add i64 %t772, %t773
  %t778 = sub i64 %t776, 1
  %t779 = load i64, ptr %l28, !tbaa !24
  %t782 = sdiv i64 %t778, %t779
  store i64 %t782, ptr %l394, !tbaa !24
  br label %bb239
bb238:
  store i64 0, ptr %l394, !tbaa !24
  br label %bb239
bb239:
  %t784 = load i64, ptr %l394, !tbaa !24
  store i64 %t784, ptr %l391, !tbaa !24
  br label %bb240
bb240:
  %t785 = load i64, ptr %l391, !tbaa !24
  store i64 %t785, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb241
bb241:
  store %olang.scope zeroinitializer, ptr %s35
  %t786 = load i64, ptr %l30, !tbaa !24
  %t787 = load i64, ptr %l29, !tbaa !24
  %t790 = icmp slt i64 %t786, %t787
  %t792 = xor i1 %t790, true
  br i1 %t792, label %bb242, label %bb243
bb242:
  call void @__olang_scope_close(ptr %s35)
  br label %bb251
bb243:
  br label %bb244
bb244:
  %t794 = load i64, ptr %l26, !tbaa !24
  %t795 = load i64, ptr %l30, !tbaa !24
  %t796 = load i64, ptr %l28, !tbaa !24
  %t799 = mul i64 %t795, %t796
  %t802 = add i64 %t794, %t799
  store i64 %t802, ptr %l31, !tbaa !24
  %t804 = load i64, ptr %l31, !tbaa !24
  %t806 = icmp sgt i64 %t804, 0
  br i1 %t806, label %bb245, label %bb246
bb245:
  %t808 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t808, i8 44)
  br label %bb247
bb246:
  br label %bb248
bb247:
  br label %bb248
bb248:
  %t810 = load ptr, ptr %l1, !tbaa !29
  %t811 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t811, ptr %l416, !tbaa !27
  %t812 = load i64, ptr %l31, !tbaa !24
  %t814 = getelementptr { i64, ptr }, ptr %l416, i32 0, i32 1
  %t815 = load ptr, ptr %t814, !tbaa !27
  %t816 = getelementptr i64, ptr %t815, i64 %t812
  %t817 = load i64, ptr %t816, !tbaa !34
  %t819 = call i64 @__olang_fmt_i64(ptr null, i64 %t817)
  %t820 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t819)
  %t821 = call i64 @__olang_fmt_i64(ptr %t820, i64 %t817)
  %t822 = insertvalue { i64, ptr } undef, i64 %t819, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t820, 1
  %t825 = extractvalue { i64, ptr } %t823, 0
  %t826 = extractvalue { i64, ptr } %t823, 1
  %t827 = mul i64 %t825, 1
  %t828 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t827)
  call void @llvm.memcpy.p0.p0.i64(ptr %t828, ptr %t826, i64 %t827, i1 false)
  %t829 = insertvalue { i64, ptr } undef, i64 %t825, 0
  %t830 = insertvalue { i64, ptr } %t829, ptr %t828, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s35, ptr %t810, { i64, ptr } %t830)
  br label %bb249
bb249:
  call void @__olang_scope_close(ptr %s35)
  br label %bb250
bb250:
  %t833 = load i64, ptr %l30, !tbaa !24
  %t835 = add i64 %t833, 1
  store i64 %t835, ptr %l30, !tbaa !24
  br label %bb241
bb251:
  %t837 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t837, i8 93)
  br label %bb252
bb252:
  call void @__olang_scope_close(ptr %s33)
  br label %bb253
bb253:
  call void @__olang_scope_close(ptr %s22)
  br label %bb361
bb254:
  %t839 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t841 = trunc i64 22 to i32
  %t842 = icmp eq i32 %t839, %t841
  br i1 %t842, label %bb255, label %bb256
bb255:
  br label %bb257
bb256:
  br label %bb262
bb257:
  %t844 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t844, i8 40)
  br label %bb258
bb258:
  %t846 = load ptr, ptr %l0, !tbaa !29
  store ptr %t846, ptr %l427, !tbaa !29
  %t847 = load ptr, ptr %l1, !tbaa !29
  store ptr %t847, ptr %l428, !tbaa !29
  %t848 = load ptr, ptr %l0, !tbaa !29
  %t849 = load i32, ptr %l2, !tbaa !23
  %t852 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t848, i32 %t849)
  store i32 %t852, ptr %l431
  br label %bb259
bb259:
  %t853 = load ptr, ptr %l427, !tbaa !29
  %t854 = load ptr, ptr %l428, !tbaa !29
  %t855 = load i32, ptr %l431, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t853, ptr %t854, i32 %t855)
  br label %bb260
bb260:
  %t856 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t856, i8 41)
  br label %bb261
bb261:
  br label %bb361
bb262:
  %t858 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t860 = trunc i64 23 to i32
  %t861 = icmp eq i32 %t858, %t860
  br i1 %t861, label %bb263, label %bb264
bb263:
  br label %bb265
bb264:
  br label %bb270
bb265:
  store %olang.scope zeroinitializer, ptr %s40
  %t863 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t863, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb266
bb266:
  %t865 = load ptr, ptr %l0, !tbaa !29
  store ptr %t865, ptr %l436, !tbaa !29
  %t866 = load ptr, ptr %l1, !tbaa !29
  store ptr %t866, ptr %l437, !tbaa !29
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t868 = load i32, ptr %l2, !tbaa !23
  %t871 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t867, i32 %t868)
  store i32 %t871, ptr %l440
  br label %bb267
bb267:
  %t872 = load ptr, ptr %l436, !tbaa !29
  %t873 = load ptr, ptr %l437, !tbaa !29
  %t874 = load i32, ptr %l440, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t872, ptr %t873, i32 %t874)
  br label %bb268
bb268:
  %t875 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t875, i8 41)
  br label %bb269
bb269:
  call void @__olang_scope_close(ptr %s40)
  br label %bb361
bb270:
  %t877 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t879 = trunc i64 24 to i32
  %t880 = icmp eq i32 %t877, %t879
  br i1 %t880, label %bb271, label %bb272
bb271:
  br label %bb273
bb272:
  br label %bb304
bb273:
  store %olang.scope zeroinitializer, ptr %s41
  %t882 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s41, ptr %t882, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb274
bb274:
  %t884 = load ptr, ptr %l0, !tbaa !29
  %t885 = load i32, ptr %l2, !tbaa !23
  %t888 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v0, ptr %t884, i32 %t885)
  store { i64, ptr } %t888, ptr %l447
  br label %bb275
bb275:
  %t889 = load { i64, ptr }, ptr %l447, !tbaa !27
  store { i64, ptr } %t889, ptr %l32, !tbaa !27
  %t890 = load ptr, ptr %l0, !tbaa !29
  store ptr %t890, ptr %l448, !tbaa !29
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t892 = load i32, ptr %l2, !tbaa !23
  %t895 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t891, i32 %t892)
  store i32 %t895, ptr %l451
  br label %bb276
bb276:
  %t896 = load ptr, ptr %l448, !tbaa !29
  %t897 = load i32, ptr %l451, !tbaa !23
  %t898 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t896, i32 %t897)
  store { i64, ptr } %t898, ptr %l452
  br label %bb277
bb277:
  %t899 = load { i64, ptr }, ptr %l452, !tbaa !27
  store { i64, ptr } %t899, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t900 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t902 = extractvalue { i64, ptr } %t900, 0
  store i64 %t902, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t904 = load i64, ptr %l35, !tbaa !24
  %t905 = load i64, ptr %l34, !tbaa !24
  %t908 = icmp sgt i64 %t904, %t905
  br i1 %t908, label %bb278, label %bb279
bb278:
  %t910 = load i64, ptr %l36, !tbaa !24
  %t912 = icmp sgt i64 %t910, 0
  br i1 %t912, label %bb280, label %bb281
bb279:
  store i64 0, ptr %l458, !tbaa !24
  br label %bb283
bb280:
  %t914 = load i64, ptr %l35, !tbaa !24
  %t915 = load i64, ptr %l34, !tbaa !24
  %t918 = sub i64 %t914, %t915
  %t919 = load i64, ptr %l36, !tbaa !24
  %t922 = add i64 %t918, %t919
  %t924 = sub i64 %t922, 1
  %t925 = load i64, ptr %l36, !tbaa !24
  %t928 = sdiv i64 %t924, %t925
  store i64 %t928, ptr %l461, !tbaa !24
  br label %bb282
bb281:
  store i64 0, ptr %l461, !tbaa !24
  br label %bb282
bb282:
  %t930 = load i64, ptr %l461, !tbaa !24
  store i64 %t930, ptr %l458, !tbaa !24
  br label %bb283
bb283:
  %t931 = load i64, ptr %l458, !tbaa !24
  store i64 %t931, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb284
bb284:
  store %olang.scope zeroinitializer, ptr %s43
  %t932 = load i64, ptr %l38, !tbaa !24
  %t933 = load i64, ptr %l37, !tbaa !24
  %t936 = icmp slt i64 %t932, %t933
  %t938 = xor i1 %t936, true
  br i1 %t938, label %bb285, label %bb286
bb285:
  call void @__olang_scope_close(ptr %s43)
  br label %bb302
bb286:
  br label %bb287
bb287:
  %t940 = load i64, ptr %l34, !tbaa !24
  %t941 = load i64, ptr %l38, !tbaa !24
  %t942 = load i64, ptr %l36, !tbaa !24
  %t945 = mul i64 %t941, %t942
  %t948 = add i64 %t940, %t945
  store i64 %t948, ptr %l39, !tbaa !24
  %t950 = load i64, ptr %l39, !tbaa !24
  %t952 = icmp sgt i64 %t950, 0
  br i1 %t952, label %bb288, label %bb289
bb288:
  %t954 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t954, i8 32)
  br label %bb290
bb289:
  br label %bb291
bb290:
  br label %bb291
bb291:
  %t956 = load ptr, ptr %l1, !tbaa !29
  store ptr %t956, ptr %l482, !tbaa !29
  %t957 = load ptr, ptr %l0, !tbaa !29
  %t959 = getelementptr %"compiler/types:Table", ptr %t957, i32 0, i32 0
  %t960 = load ptr, ptr %t959, !tbaa !29
  %t961 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t961, ptr %l485, !tbaa !27
  %t962 = load i64, ptr %l39, !tbaa !24
  %t964 = getelementptr { i64, ptr }, ptr %l485, i32 0, i32 1
  %t965 = load ptr, ptr %t964, !tbaa !27
  %t966 = getelementptr i32, ptr %t965, i64 %t962
  %t967 = load i32, ptr %t966, !tbaa !33
  %t968 = load ptr, ptr @__olang_prog_scope
  %t971 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t968, ptr %s43, ptr %t960, i32 %t967)
  store { i64, ptr } %t971, ptr %l488
  br label %bb292
bb292:
  %t972 = load ptr, ptr %l482, !tbaa !29
  %t973 = load { i64, ptr }, ptr %l488, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s43, ptr %t972, { i64, ptr } %t973)
  br label %bb293
bb293:
  %t974 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t974, ptr %l489, !tbaa !27
  %t975 = load i64, ptr %l39, !tbaa !24
  %t977 = getelementptr { i64, ptr }, ptr %l489, i32 0, i32 1
  %t978 = load ptr, ptr %t977, !tbaa !27
  %t979 = getelementptr i32, ptr %t978, i64 %t975
  %t980 = load i32, ptr %t979, !tbaa !33
  %t982 = icmp ne i32 %t980, 0
  br i1 %t982, label %bb294, label %bb295
bb294:
  %t984 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t984, i8 40)
  br label %bb296
bb295:
  br label %bb300
bb296:
  %t986 = load ptr, ptr %l0, !tbaa !29
  store ptr %t986, ptr %l494, !tbaa !29
  %t987 = load ptr, ptr %l1, !tbaa !29
  store ptr %t987, ptr %l495, !tbaa !29
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t989, ptr %l497, !tbaa !27
  %t990 = load i64, ptr %l39, !tbaa !24
  %t992 = getelementptr { i64, ptr }, ptr %l497, i32 0, i32 1
  %t993 = load ptr, ptr %t992, !tbaa !27
  %t994 = getelementptr i32, ptr %t993, i64 %t990
  %t995 = load i32, ptr %t994, !tbaa !33
  %t998 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t988, i32 %t995)
  store i32 %t998, ptr %l500
  br label %bb297
bb297:
  %t999 = load ptr, ptr %l494, !tbaa !29
  %t1000 = load ptr, ptr %l495, !tbaa !29
  %t1001 = load i32, ptr %l500, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t999, ptr %t1000, i32 %t1001)
  br label %bb298
bb298:
  %t1002 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1002, i8 41)
  br label %bb299
bb299:
  br label %bb300
bb300:
  call void @__olang_scope_close(ptr %s43)
  br label %bb301
bb301:
  %t1004 = load i64, ptr %l38, !tbaa !24
  %t1006 = add i64 %t1004, 1
  store i64 %t1006, ptr %l38, !tbaa !24
  br label %bb284
bb302:
  %t1008 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1008, i8 125)
  br label %bb303
bb303:
  call void @__olang_scope_close(ptr %s41)
  br label %bb361
bb304:
  %t1010 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1012 = trunc i64 25 to i32
  %t1013 = icmp eq i32 %t1010, %t1012
  br i1 %t1013, label %bb305, label %bb306
bb305:
  br label %bb307
bb306:
  br label %bb309
bb307:
  store %olang.scope zeroinitializer, ptr %s47
  %t1015 = load ptr, ptr %l1, !tbaa !29
  %t1016 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 1
  %t1017 = load i64, ptr %t1016, !tbaa !24
  %t1018 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1019 = load i64, ptr %t1018, !tbaa !24
  %t1020 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t1021 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t1023 = call i64 @__olang_fmt_i64(ptr null, i64 %t1017)
  %t1024 = add i64 %t1021, %t1023
  %t1025 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t1026 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t1027 = add i64 %t1024, %t1026
  %t1029 = call i64 @__olang_fmt_i64(ptr null, i64 %t1019)
  %t1030 = add i64 %t1027, %t1029
  %t1031 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t1032 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t1033 = add i64 %t1030, %t1032
  %t1034 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1033)
  call void @olang_textcopy(ptr %t1034, ptr %t1020, i64 %t1021)
  %t1035 = getelementptr i8, ptr %t1034, i64 %t1021
  %t1036 = call i64 @__olang_fmt_i64(ptr %t1035, i64 %t1017)
  %t1037 = getelementptr i8, ptr %t1035, i64 %t1023
  call void @olang_textcopy(ptr %t1037, ptr %t1025, i64 %t1026)
  %t1038 = getelementptr i8, ptr %t1037, i64 %t1026
  %t1039 = call i64 @__olang_fmt_i64(ptr %t1038, i64 %t1019)
  %t1040 = getelementptr i8, ptr %t1038, i64 %t1029
  call void @olang_textcopy(ptr %t1040, ptr %t1031, i64 %t1032)
  %t1041 = insertvalue { i64, ptr } undef, i64 %t1033, 0
  %t1042 = insertvalue { i64, ptr } %t1041, ptr %t1034, 1
  %t1044 = extractvalue { i64, ptr } %t1042, 0
  %t1045 = extractvalue { i64, ptr } %t1042, 1
  %t1046 = mul i64 %t1044, 1
  %t1047 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1046)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1047, ptr %t1045, i64 %t1046, i1 false)
  %t1048 = insertvalue { i64, ptr } undef, i64 %t1044, 0
  %t1049 = insertvalue { i64, ptr } %t1048, ptr %t1047, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s47, ptr %t1015, { i64, ptr } %t1049)
  br label %bb308
bb308:
  call void @__olang_scope_close(ptr %s47)
  br label %bb361
bb309:
  %t1052 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1054 = trunc i64 26 to i32
  %t1055 = icmp eq i32 %t1052, %t1054
  br i1 %t1055, label %bb310, label %bb311
bb310:
  br label %bb312
bb311:
  br label %bb331
bb312:
  %t1057 = load ptr, ptr %l0, !tbaa !29
  %t1058 = load i32, ptr %l2, !tbaa !23
  %t1061 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t1057, i32 %t1058)
  store i32 %t1061, ptr %l516
  br label %bb313
bb313:
  %t1062 = load i32, ptr %l516, !tbaa !23
  store i32 %t1062, ptr %l40, !tbaa !23
  %t1063 = load i32, ptr %l40, !tbaa !23
  %t1064 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1067 = icmp eq i32 %t1063, %t1064
  br i1 %t1067, label %bb314, label %bb315
bb314:
  store %olang.scope zeroinitializer, ptr %s50
  %t1069 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1069, ptr %l520, !tbaa !29
  %t1070 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1071 = load i64, ptr %t1070, !tbaa !24
  %t1073 = icmp ne i64 %t1071, 0
  br i1 %t1073, label %bb316, label %bb317
bb315:
  %t1075 = load ptr, ptr %l0, !tbaa !29
  %t1076 = load i32, ptr %l40, !tbaa !23
  %t1079 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t1075, i32 %t1076)
  store i1 %t1079, ptr %l526
  br label %bb320
bb316:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l523, !tbaa !27
  br label %bb318
bb317:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l523, !tbaa !27
  br label %bb318
bb318:
  %t1080 = load ptr, ptr %l520, !tbaa !29
  %t1081 = load { i64, ptr }, ptr %l523, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s50, ptr %t1080, { i64, ptr } %t1081)
  br label %bb319
bb319:
  call void @__olang_scope_close(ptr %s50)
  br label %bb330
bb320:
  %t1082 = load i1, ptr %l526, !tbaa !21
  br i1 %t1082, label %bb321, label %bb322
bb321:
  %t1083 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1084 = load i64, ptr %t1083, !tbaa !24
  %t1086 = icmp slt i64 %t1084, 0
  store i1 %t1086, ptr %l527, !tbaa !21
  br label %bb323
bb322:
  store i1 false, ptr %l527, !tbaa !21
  br label %bb323
bb323:
  %t1088 = load i1, ptr %l527, !tbaa !21
  br i1 %t1088, label %bb324, label %bb325
bb324:
  store %olang.scope zeroinitializer, ptr %s52
  %t1089 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1089, ptr %l530, !tbaa !29
  %t1090 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1091 = load i64, ptr %t1090, !tbaa !24
  %t1093 = call { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %s52, i64 %t1091)
  store { i64, ptr } %t1093, ptr %l532
  br label %bb326
bb325:
  store %olang.scope zeroinitializer, ptr %s53
  %t1094 = load ptr, ptr %l1, !tbaa !29
  %t1095 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1096 = load i64, ptr %t1095, !tbaa !24
  %t1098 = call i64 @__olang_fmt_i64(ptr null, i64 %t1096)
  %t1099 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1098)
  %t1100 = call i64 @__olang_fmt_i64(ptr %t1099, i64 %t1096)
  %t1101 = insertvalue { i64, ptr } undef, i64 %t1098, 0
  %t1102 = insertvalue { i64, ptr } %t1101, ptr %t1099, 1
  %t1104 = extractvalue { i64, ptr } %t1102, 0
  %t1105 = extractvalue { i64, ptr } %t1102, 1
  %t1106 = mul i64 %t1104, 1
  %t1107 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1107, ptr %t1105, i64 %t1106, i1 false)
  %t1108 = insertvalue { i64, ptr } undef, i64 %t1104, 0
  %t1109 = insertvalue { i64, ptr } %t1108, ptr %t1107, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s53, ptr %t1094, { i64, ptr } %t1109)
  br label %bb328
bb326:
  %t1112 = load { i64, ptr }, ptr %l532, !tbaa !27
  %t1113 = extractvalue { i64, ptr } %t1112, 0
  %t1114 = extractvalue { i64, ptr } %t1112, 1
  %t1115 = mul i64 %t1113, 1
  %t1116 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1116, ptr %t1114, i64 %t1115, i1 false)
  %t1117 = insertvalue { i64, ptr } undef, i64 %t1113, 0
  %t1118 = insertvalue { i64, ptr } %t1117, ptr %t1116, 1
  %t1119 = load ptr, ptr %l530, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s52, ptr %t1119, { i64, ptr } %t1118)
  br label %bb327
bb327:
  call void @__olang_scope_close(ptr %s52)
  br label %bb329
bb328:
  call void @__olang_scope_close(ptr %s53)
  br label %bb329
bb329:
  br label %bb330
bb330:
  br label %bb361
bb331:
  %t1121 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1123 = trunc i64 27 to i32
  %t1124 = icmp eq i32 %t1121, %t1123
  br i1 %t1124, label %bb332, label %bb333
bb332:
  br label %bb334
bb333:
  br label %bb337
bb334:
  store %olang.scope zeroinitializer, ptr %s55
  %t1126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1126, ptr %l540, !tbaa !29
  %t1127 = load ptr, ptr %l0, !tbaa !29
  %t1128 = load i32, ptr %l2, !tbaa !23
  %t1131 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %s55, ptr %t1127, i32 %t1128)
  store { i64, ptr } %t1131, ptr %l543
  br label %bb335
bb335:
  %t1132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t1133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t1134 = load { i64, ptr }, ptr %l543, !tbaa !27
  %t1135 = extractvalue { i64, ptr } %t1134, 1
  %t1136 = extractvalue { i64, ptr } %t1134, 0
  %t1137 = add i64 %t1133, %t1136
  %t1138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t1139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t1140 = add i64 %t1137, %t1139
  %t1141 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1140)
  call void @olang_textcopy(ptr %t1141, ptr %t1132, i64 %t1133)
  %t1142 = getelementptr i8, ptr %t1141, i64 %t1133
  call void @olang_textcopy(ptr %t1142, ptr %t1135, i64 %t1136)
  %t1143 = getelementptr i8, ptr %t1142, i64 %t1136
  call void @olang_textcopy(ptr %t1143, ptr %t1138, i64 %t1139)
  %t1144 = insertvalue { i64, ptr } undef, i64 %t1140, 0
  %t1145 = insertvalue { i64, ptr } %t1144, ptr %t1141, 1
  %t1147 = extractvalue { i64, ptr } %t1145, 0
  %t1148 = extractvalue { i64, ptr } %t1145, 1
  %t1149 = mul i64 %t1147, 1
  %t1150 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1150, ptr %t1148, i64 %t1149, i1 false)
  %t1151 = insertvalue { i64, ptr } undef, i64 %t1147, 0
  %t1152 = insertvalue { i64, ptr } %t1151, ptr %t1150, 1
  %t1153 = load ptr, ptr %l540, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s55, ptr %t1153, { i64, ptr } %t1152)
  br label %bb336
bb336:
  call void @__olang_scope_close(ptr %s55)
  br label %bb361
bb337:
  %t1155 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1157 = trunc i64 29 to i32
  %t1158 = icmp eq i32 %t1155, %t1157
  br i1 %t1158, label %bb338, label %bb339
bb338:
  br label %bb340
bb339:
  br label %bb344
bb340:
  store %olang.scope zeroinitializer, ptr %s57
  %t1160 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s57, ptr %t1160, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb341
bb341:
  %t1162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1162, ptr %l549, !tbaa !29
  %t1163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1163, ptr %l550, !tbaa !29
  %t1164 = load ptr, ptr %l0, !tbaa !29
  %t1165 = load i32, ptr %l2, !tbaa !23
  %t1168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t1164, i32 %t1165)
  store i32 %t1168, ptr %l553
  br label %bb342
bb342:
  %t1169 = load ptr, ptr %l549, !tbaa !29
  %t1170 = load ptr, ptr %l550, !tbaa !29
  %t1171 = load i32, ptr %l553, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t1169, ptr %t1170, i32 %t1171)
  br label %bb343
bb343:
  call void @__olang_scope_close(ptr %s57)
  br label %bb361
bb344:
  %t1172 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1174 = trunc i64 32 to i32
  %t1175 = icmp eq i32 %t1172, %t1174
  br i1 %t1175, label %bb345, label %bb346
bb345:
  br label %bb347
bb346:
  br label %bb352
bb347:
  store %olang.scope zeroinitializer, ptr %s58
  %t1177 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s58, ptr %t1177, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb348
bb348:
  %t1179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1179, ptr %l557, !tbaa !29
  %t1180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1180, ptr %l558, !tbaa !29
  %t1181 = load ptr, ptr %l0, !tbaa !29
  %t1182 = load i32, ptr %l2, !tbaa !23
  %t1185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t1181, i32 %t1182)
  store i32 %t1185, ptr %l561
  br label %bb349
bb349:
  %t1186 = load ptr, ptr %l557, !tbaa !29
  %t1187 = load ptr, ptr %l558, !tbaa !29
  %t1188 = load i32, ptr %l561, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t1186, ptr %t1187, i32 %t1188)
  br label %bb350
bb350:
  %t1189 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1189, i8 125)
  br label %bb351
bb351:
  call void @__olang_scope_close(ptr %s58)
  br label %bb361
bb352:
  %t1191 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t1193 = trunc i64 30 to i32
  %t1194 = icmp eq i32 %t1191, %t1193
  br i1 %t1194, label %bb353, label %bb354
bb353:
  br label %bb355
bb354:
  br label %bb360
bb355:
  %t1196 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t1196, i8 63)
  br label %bb356
bb356:
  %t1198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1198, ptr %l566, !tbaa !29
  %t1199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1199, ptr %l567, !tbaa !29
  %t1200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1200, ptr %l568, !tbaa !29
  %t1201 = load ptr, ptr %l0, !tbaa !29
  %t1202 = load i32, ptr %l2, !tbaa !23
  %t1205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t1201, i32 %t1202)
  store i32 %t1205, ptr %l571
  br label %bb357
bb357:
  %t1206 = load ptr, ptr %l568, !tbaa !29
  %t1207 = load i32, ptr %l571, !tbaa !23
  %t1208 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1206, i32 %t1207)
  store { i64, ptr } %t1208, ptr %l572
  br label %bb358
bb358:
  %t1209 = load ptr, ptr %l566, !tbaa !29
  %t1210 = load ptr, ptr %l567, !tbaa !29
  %t1211 = load { i64, ptr }, ptr %l572, !tbaa !27
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonErrs(ptr %v0, ptr %v1, ptr %v0, ptr %t1209, ptr %t1210, { i64, ptr } %t1211)
  br label %bb359
bb359:
  br label %bb361
bb360:
  call void @__olang_check_failed(ptr @olang_loc_bd4ce41e1f7e504b_596b58263987420f)
  unreachable
bb361:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonErrs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l35, !tbaa !29
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t56, { i64, ptr } %t57)
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t60, ptr %l41, !tbaa !27
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %a0, ptr %t59, i32 %t66)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb7
bb17:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l5, !tbaa !23
  %t27 = load i32, ptr %l5, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i32
  %l28 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 5
  %t6 = sext i32 %a1 to i64
  %t9 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H61b120fbdcc010be1bedf2507e848f7c(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store { i64, ptr } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l18, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  store i32 %t29, ptr %l6, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load i32, ptr %l2, !tbaa !23
  %t37 = load i32, ptr %l23, !tbaa !23
  %t39 = icmp sgt i32 %t37, %t36
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l28
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t46 = load i32, ptr %l28, !tbaa !23
  store i32 %t46, ptr %l2, !tbaa !23
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb2
bb12:
  %t51 = load i32, ptr %l2, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 4
  %t6 = sext i32 %a1 to i64
  %t9 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t3, i64 %t6)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edestructs(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"compiler/types:body"
  %l6 = alloca %"compiler/types:body"
  %l9 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:body" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:body", ptr %l6
  store %"compiler/types:body" %t6, ptr %l3
  %t7 = getelementptr %"compiler/types:body", ptr %l3, i32 0, i32 3
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/types:Table", ptr %t12, i32 0, i32 37
  %t16 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = icmp eq i64 %t17, 0
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb10
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/types:Table", ptr %t21, i32 0, i32 37
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l19
  br label %bb8
bb8:
  %t29 = load i32, ptr %l19, !tbaa !23
  %t30 = sext i32 %t29 to i64
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t33 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t31, i64 %t30)
  store i1 %t33, ptr %l21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l21, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l14, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = getelementptr %"compiler/types:body", ptr %l3, i32 0, i32 3
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t47 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsDropping(ptr %v0, ptr %t41, i32 %t42, i64 %a2)
  store i1 %t47, ptr %l27
  br label %bb14
bb14:
  %t48 = load i1, ptr %l27, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l12
  br label %bb5
bb5:
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = sdiv i64 %t30, 8
  %t32 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t32, i64 %t33)
  %t41 = getelementptr i8, ptr %t40, i64 %t33
  %t42 = call i64 @__olang_fmt_i64(ptr %t41, i64 %t31)
  %t43 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l18 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 33}
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t9 = trunc i64 18 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load i32, ptr %l11, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  br label %bb28
bb6:
  %t18 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t23 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l18
  br label %bb12
bb12:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  br label %bb28
bb13:
  %t34 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t36 = trunc i64 32 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/types:Table", ptr %t39, i32 0, i32 19
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H5a37a20f375ed653adc00b592f5745cf(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l24
  br label %bb17
bb17:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb18, label %bb19
bb18:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l26, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l29
  br label %bb20
bb19:
  store i32 0, ptr %l25, !tbaa !23
  br label %bb22
bb20:
  %t53 = load ptr, ptr %l26, !tbaa !29
  %t54 = load i32, ptr %l29, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t55, ptr %l30
  br label %bb21
bb21:
  %t56 = load i32, ptr %l30, !tbaa !23
  store i32 %t56, ptr %l25, !tbaa !23
  br label %bb22
bb22:
  %t57 = load i32, ptr %l25, !tbaa !23
  store i32 %t57, ptr %l6, !tbaa !23
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i32 0, ptr %l6, !tbaa !23
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_94d95030786c6de_dc670b9e390cf1a)
  unreachable
bb28:
  %t58 = load i32, ptr %l6, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsDropping(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i32
  %l39 = alloca i32
  %l42 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i32
  %l49 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t2, i32 %a1)
  store i32 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = load i32, ptr %l11, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb29
bb5:
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  store i32 %t29, ptr %l6, !tbaa !23
  %t31 = load i32, ptr %l6, !tbaa !23
  %t33 = icmp eq i32 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb10
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l27
  br label %bb9
bb9:
  %t40 = load i1, ptr %l27, !tbaa !21
  store i1 %t40, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l24, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  br label %bb28
bb12:
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = add i64 %t44, 1
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eneedsDrop(ptr %v0, ptr %t42, i32 %t43, i64 %t46)
  store i1 %t50, ptr %l32
  br label %bb14
bb14:
  %t51 = load i1, ptr %l32, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l36
  br label %bb18
bb18:
  %t58 = load i32, ptr %l36, !tbaa !23
  store i32 %t58, ptr %l7, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l7, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l39
  br label %bb19
bb19:
  %t64 = load i32, ptr %l39, !range !{i32 0, i32 33}
  %t66 = trunc i64 19 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l43, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l7, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l46
  br label %bb22
bb21:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb24
bb22:
  %t75 = load i64, ptr %l2, !tbaa !24
  %t77 = add i64 %t75, 2
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = load i32, ptr %l46, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eneedsDrop(ptr %v0, ptr %t78, i32 %t79, i64 %t77)
  store i1 %t81, ptr %l49
  br label %bb23
bb23:
  %t82 = load i1, ptr %l49, !tbaa !21
  store i1 %t82, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t83 = load i1, ptr %l42, !tbaa !21
  br i1 %t83, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l4, !tbaa !24
  br label %bb3
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsState(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i8
  %l14 = alloca i8
  %rv = alloca i8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 32
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/types:Table", ptr %t15, i32 0, i32 32
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t17, i64 %t18)
  store i8 %t21, ptr %l14
  br label %bb4
bb3:
  store i8 0, ptr %l10, !tbaa !22
  br label %bb5
bb4:
  %t22 = load i8, ptr %l14, !tbaa !22
  store i8 %t22, ptr %l10, !tbaa !22
  br label %bb5
bb5:
  %t23 = load i8, ptr %l10, !tbaa !22
  store i8 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l15 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/types:data" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 2
  %t4 = load %"compiler/types:data", ptr %l1
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %t3, %"compiler/types:data" %t4)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i32, ptr %l8, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i32 -1, ptr %l4, !tbaa !23
  br label %bb4
bb4:
  %t13 = load i32, ptr %l4, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t16 = icmp sge i32 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i32, ptr %l3, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 1
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = trunc i64 %t25 to i32
  store i32 %t26, ptr %l3, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/types:Table", ptr %t29, i32 0, i32 1
  %t32 = load %"compiler/types:data", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t31, %"compiler/types:data" %t32)
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/types:Table", ptr %t35, i32 0, i32 2
  %t38 = load %"compiler/types:data", ptr %l1
  %t39 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %t37, %"compiler/types:data" %t38, i32 %t39)
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/types:Table", ptr %t43, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t45, i32 %a2)
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/types:Table", ptr %t49, i32 0, i32 20
  %t52 = load i64, ptr @G_2ecompiler_2ftypes_2eNotLaidOut, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t51, i64 %t52)
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/types:Table", ptr %t55, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t57, i64 0)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t59, i32 0, i32 22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t61, i64 1)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/types:Table", ptr %t63, i32 0, i32 23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 -1)
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/types:Table", ptr %t67, i32 0, i32 25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t69, i64 -1)
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/types:Table", ptr %t75, i32 0, i32 27
  %t78 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t77, i32 %t78)
  br label %bb18
bb18:
  %t81 = load i32, ptr %l3, !tbaa !23
  store i32 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca i64
  %l44 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t61, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t65, ptr %l44, !tbaa !27
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 %t66
  %t71 = load i32, ptr %t70, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t71)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb8
bb18:
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l11 = alloca i1
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca i64
  %l36 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = insertvalue { i64, i64 } undef, i64 4, 0
  %t10 = insertvalue { i64, i64 } %t9, i64 4, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l16
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t31
  %t36 = load i32, ptr %t35, !tbaa !33
  store i32 %t36, ptr %l7, !tbaa !23
  %t38 = load i32, ptr %l7, !tbaa !23
  %t40 = icmp ne i32 %t38, 0
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l7, !tbaa !23
  %t46 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l31, !tbaa !24
  %t50 = icmp sgt i64 %t48, %t47
  store i1 %t50, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l7, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t57, ptr %l36
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t58 = load i64, ptr %l36, !tbaa !24
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb6
bb19:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 7
  %t67 = sdiv i64 %t65, 8
  %t69 = mul i64 %t67, 8
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 25
  %t76 = sext i32 %a1 to i64
  %t77 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t76, i64 %t77)
  br label %bb20
bb20:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t83 = add i64 8, %t81
  %t85 = insertvalue { i64, i64 } undef, i64 %t83, 0
  %t86 = insertvalue { i64, i64 } %t85, i64 8, 1
  store { i64, i64 } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l31 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 23
  store ptr %t3, ptr %l11, !tbaa !29
  %t6 = sext i32 %a1 to i64
  store i64 %t6, ptr %l13, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/types:Table", ptr %t7, i32 0, i32 24
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13, i64 %t14)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t15, i32 %a2)
  store { i64, ptr } %t19, ptr %l19
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  store i32 %t39, ptr %l8, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l8, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l31
  br label %bb8
bb8:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load i64, ptr %l9, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = mul i64 %t65, %t66
  store i64 %t69, ptr %l3, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 24
  %t74 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t73, i64 %t74)
  br label %bb12
bb12:
  %t77 = load i64, ptr %l3, !tbaa !24
  store i64 %t77, ptr %l47, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l8, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l50
  br label %bb13
bb13:
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = add i64 %t83, %t84
  store i64 %t85, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l6, !tbaa !24
  br label %bb4
bb15:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t92 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l4, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t106 = load i64, ptr %l4, !tbaa !24
  %t108 = insertvalue { i64, i64 } undef, i64 %t105, 0
  %t110 = insertvalue { i64, i64 } %t108, i64 %t106, 1
  store { i64, i64 } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %a0, i32 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l17, !tbaa !27
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t29 = icmp eq i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t33 = xor i1 %a2, true
  br i1 %t33, label %bb8, label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l7, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l27
  br label %bb11
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/types:Table", ptr %t40, i32 0, i32 33
  store i1 true, ptr %t42, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb22
bb11:
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb18
bb13:
  br i1 %a3, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l7, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l33
  br label %bb16
bb15:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb17
bb16:
  %t51 = load i1, ptr %l33, !tbaa !21
  store i1 %t51, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l5, !tbaa !24
  br label %bb2
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l29 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l17, !tbaa !27
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t29 = icmp eq i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t33 = xor i1 %a3, true
  br i1 %t33, label %bb8, label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l7, !tbaa !23
  %t39 = add i64 %a2, 1
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %t35, i32 %t36, i64 %t39)
  store i1 %t43, ptr %l29
  br label %bb11
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb2
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !range !{i32 0, i32 6}
  store i32 %t10, ptr %l2
  %t11 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2estructName(ptr %v0, ptr %v1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  br label %bb27
bb7:
  %t22 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t24 = trunc i64 1 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l18
  br label %bb11
bb11:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l8, !tbaa !27
  br label %bb27
bb12:
  %t33 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t35 = trunc i64 2 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  br label %bb27
bb16:
  %t40 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t42 = trunc i64 4 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l25, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l28
  br label %bb20
bb20:
  %t51 = load ptr, ptr %l25, !tbaa !29
  %t52 = load i32, ptr %l28, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s4, ptr %t51, i32 %t52)
  store { i64, ptr } %t53, ptr %l29
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l8, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b0143a025c7cdb06_8f46c74feff323b2)
  unreachable
bb27:
  %t63 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l33, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l34, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l33, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t76, ptr %l8, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eneedsDrop(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l19 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca i1
  %l53 = alloca i32
  %l55 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca i32
  %l62 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca i1
  %l75 = alloca ptr
  %l78 = alloca i32
  %l80 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l14
  br label %bb5
bb5:
  %t17 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t20 = trunc i64 18 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb36
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l19
  br label %bb9
bb9:
  %t28 = load i1, ptr %l19, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l25
  br label %bb13
bb13:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l26
  br label %bb14
bb14:
  %t41 = load i32, ptr %l26, !range !{i32 0, i32 6}
  store i32 %t41, ptr %l5
  %t42 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t44 = trunc i64 0 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t49 = load i64, ptr %l2, !tbaa !24
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edestructs(ptr %v0, ptr %t47, i32 %t48, i64 %t49)
  store i1 %t53, ptr %l33
  br label %bb18
bb18:
  %t54 = load i1, ptr %l33, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb23
bb20:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l35, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l38
  br label %bb21
bb21:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t62 = load ptr, ptr %l35, !tbaa !29
  %t63 = load i32, ptr %l38, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsDrop(ptr %v0, ptr %t62, i32 %t63, i64 %t61)
  store i1 %t65, ptr %l40
  br label %bb22
bb22:
  %t66 = load i1, ptr %l40, !tbaa !21
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l34, !tbaa !21
  store i1 %t67, ptr %l27, !tbaa !21
  br label %bb35
bb24:
  %t68 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t70 = trunc i64 1 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l43, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l46
  br label %bb28
bb28:
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load ptr, ptr %l43, !tbaa !29
  %t81 = load i32, ptr %l46, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsDrop(ptr %v0, ptr %t80, i32 %t81, i64 %t79)
  store i1 %t83, ptr %l48
  br label %bb29
bb29:
  %t84 = load i1, ptr %l48, !tbaa !21
  store i1 %t84, ptr %l27, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_2cd53dd7f17e3306_fa38995b8825f762)
  unreachable
bb35:
  %t85 = load i1, ptr %l27, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
bb36:
  %t86 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t88 = trunc i64 19 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb46
bb39:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l3, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l53
  br label %bb40
bb40:
  %t96 = load i32, ptr %l53, !tbaa !23
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb41, label %bb42
bb41:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l56, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l3, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l59
  br label %bb43
bb42:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb45
bb43:
  %t105 = load i64, ptr %l2, !tbaa !24
  %t107 = add i64 %t105, 1
  %t108 = load ptr, ptr %l56, !tbaa !29
  %t109 = load i32, ptr %l59, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eneedsDrop(ptr %v0, ptr %t108, i32 %t109, i64 %t107)
  store i1 %t111, ptr %l62
  br label %bb44
bb44:
  %t112 = load i1, ptr %l62, !tbaa !21
  store i1 %t112, ptr %l55, !tbaa !21
  br label %bb45
bb45:
  %t113 = load i1, ptr %l55, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
bb46:
  %t114 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t116 = trunc i64 23 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb47, label %bb48
bb47:
  br label %bb51
bb48:
  %t119 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t121 = trunc i64 22 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l67, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l3, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l70
  br label %bb52
bb52:
  %t130 = load i64, ptr %l2, !tbaa !24
  %t131 = load ptr, ptr %l67, !tbaa !29
  %t132 = load i32, ptr %l70, !tbaa !23
  %t134 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsDrop(ptr %v0, ptr %t131, i32 %t132, i64 %t130)
  store i1 %t134, ptr %l72
  br label %bb53
bb53:
  %t135 = load i1, ptr %l72, !tbaa !21
  store i1 %t135, ptr %rv
  br label %ret
bb54:
  %t136 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t138 = trunc i64 24 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l75, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l3, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l78
  br label %bb58
bb58:
  %t147 = load i64, ptr %l2, !tbaa !24
  %t148 = load ptr, ptr %l75, !tbaa !29
  %t149 = load i32, ptr %l78, !tbaa !23
  %t151 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsDrop(ptr %v0, ptr %t148, i32 %t149, i64 %t147)
  store i1 %t151, ptr %l80
  br label %bb59
bb59:
  %t152 = load i1, ptr %l80, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store i1 false, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_e12a8b7b5dbe3de7_965cbd36c1b6d563)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eownsParts(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca i1
  %l40 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca i32
  %l54 = alloca i1
  %l58 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i32
  %l66 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca i1
  %l77 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l14
  br label %bb5
bb5:
  %t17 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb16
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l20
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = load i32, ptr %l20, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t31, ptr %l21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb15
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l23, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l26
  br label %bb13
bb13:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = add i64 %t39, 1
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load i32, ptr %l26, !tbaa !23
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eownsParts(ptr %v0, ptr %t42, i32 %t43, i64 %t41)
  store i1 %t45, ptr %l29
  br label %bb14
bb14:
  %t46 = load i1, ptr %l29, !tbaa !21
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l22, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb16:
  %t48 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t50 = trunc i64 23 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l35
  br label %bb20
bb20:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t61 = load i32, ptr %l35, !tbaa !23
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsOwn(ptr %v0, ptr %t60, i32 %t61, i64 %t59)
  store i1 %t63, ptr %l37
  br label %bb21
bb21:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
bb22:
  %t65 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t67 = trunc i64 24 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l40, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l43
  br label %bb26
bb26:
  %t76 = load i64, ptr %l2, !tbaa !24
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load i32, ptr %l43, !tbaa !23
  %t80 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsOwn(ptr %v0, ptr %t77, i32 %t78, i64 %t76)
  store i1 %t80, ptr %l45
  br label %bb27
bb27:
  %t81 = load i1, ptr %l45, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
bb28:
  %t82 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t84 = trunc i64 18 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb60
bb31:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/types:Table", ptr %t87, i32 0, i32 35
  store ptr %t89, ptr %l49, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l52
  br label %bb32
bb32:
  %t95 = load i32, ptr %l52, !tbaa !23
  %t96 = sext i32 %t95 to i64
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t99 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t97, i64 %t96)
  store i1 %t99, ptr %l54
  br label %bb33
bb33:
  %t100 = load i1, ptr %l54, !tbaa !21
  br i1 %t100, label %bb34, label %bb35
bb34:
  store i1 true, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t102, i32 %t103)
  store i1 %t106, ptr %l58
  br label %bb37
bb37:
  %t107 = load i1, ptr %l58, !tbaa !21
  %t108 = xor i1 %t107, true
  br i1 %t108, label %bb38, label %bb39
bb38:
  store i1 false, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l61, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l64
  br label %bb41
bb41:
  %t117 = load ptr, ptr %l61, !tbaa !29
  %t118 = load i32, ptr %l64, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t117, i32 %t118)
  store i32 %t119, ptr %l65
  br label %bb42
bb42:
  %t120 = load i32, ptr %l65, !range !{i32 0, i32 6}
  store i32 %t120, ptr %l5
  %t121 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t123 = trunc i64 0 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l69, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l3, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l72
  br label %bb46
bb46:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load ptr, ptr %l69, !tbaa !29
  %t134 = load i32, ptr %l72, !tbaa !23
  %t136 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsOwn(ptr %v0, ptr %t133, i32 %t134, i64 %t132)
  store i1 %t136, ptr %l74
  br label %bb47
bb47:
  %t137 = load i1, ptr %l74, !tbaa !21
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb59
bb48:
  %t138 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t140 = trunc i64 1 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l77, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l3, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l80
  br label %bb52
bb52:
  %t149 = load i64, ptr %l2, !tbaa !24
  %t150 = load ptr, ptr %l77, !tbaa !29
  %t151 = load i32, ptr %l80, !tbaa !23
  %t153 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsOwn(ptr %v0, ptr %t150, i32 %t151, i64 %t149)
  store i1 %t153, ptr %l82
  br label %bb53
bb53:
  %t154 = load i1, ptr %l82, !tbaa !21
  store i1 %t154, ptr %l66, !tbaa !21
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_34afd997c56f8665_d97bdd2c594f3b01)
  unreachable
bb59:
  %t155 = load i1, ptr %l66, !tbaa !21
  store i1 %t155, ptr %rv
  br label %ret
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store i1 false, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_dfad6825423c7f34_db691f90aea39770)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsDrop(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l6, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l24
  br label %bb8
bb7:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i1, ptr %l24, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  %t44 = add i64 %a2, 1
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eneedsDrop(ptr %v0, ptr %t40, i32 %t41, i64 %t44)
  store i1 %t48, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb13
bb12:
  %t49 = load i1, ptr %l31, !tbaa !21
  store i1 %t49, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l26, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb2
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsOwn(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l6, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l24
  br label %bb8
bb7:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb8:
  %t36 = load i1, ptr %l24, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb12
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = add i64 %a2, 1
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eownsParts(ptr %v0, ptr %t37, i32 %t38, i64 %t41)
  store i1 %t45, ptr %l30
  br label %bb11
bb11:
  %t46 = load i1, ptr %l30, !tbaa !21
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l25, !tbaa !21
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l4, !tbaa !24
  br label %bb2
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsRunCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l6, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l24
  br label %bb8
bb7:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i1, ptr %l24, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  %t44 = add i64 %a2, 1
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunsCopy(ptr %v0, ptr %t40, i32 %t41, i64 %t44)
  store i1 %t48, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb13
bb12:
  %t49 = load i1, ptr %l31, !tbaa !21
  store i1 %t49, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l26, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb2
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l27 = alloca i1
  %l29 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l17, !tbaa !27
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t29 = icmp eq i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t33 = xor i1 %a3, true
  br i1 %t33, label %bb8, label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l7, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l27
  br label %bb11
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/types:Table", ptr %t40, i32 0, i32 33
  store i1 true, ptr %t42, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb19
bb11:
  %t43 = load i1, ptr %l27, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l7, !tbaa !23
  %t50 = add i64 %a2, 1
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %t46, i32 %t47, i64 %t50)
  store i1 %t54, ptr %l34
  br label %bb14
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb15
bb14:
  %t55 = load i1, ptr %l34, !tbaa !21
  store i1 %t55, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l29, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb2
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t14 = trunc i64 19 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i32, ptr %l14, !tbaa !23
  %t23 = icmp eq i32 %t22, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l11, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunsCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l22 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca i32
  %l39 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i32
  %l47 = alloca i1
  %l52 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l60 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l68 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i32
  %l76 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l15
  br label %bb8
bb8:
  %t18 = load i32, ptr %l15, !tbaa !23
  store i32 %t18, ptr %l3, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l18
  br label %bb9
bb9:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l22
  br label %bb13
bb13:
  %t31 = load i32, ptr %l22, !range !{i32 0, i32 33}
  store i32 %t31, ptr %l4
  %t32 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t34 = trunc i64 19 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l25, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l28
  br label %bb17
bb17:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t43, 1
  %t46 = load ptr, ptr %l25, !tbaa !29
  %t47 = load i32, ptr %l28, !tbaa !23
  %t49 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunsCopy(ptr %v0, ptr %t46, i32 %t47, i64 %t45)
  store i1 %t49, ptr %l31
  br label %bb18
bb18:
  %t50 = load i1, ptr %l31, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb19:
  %t51 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t53 = trunc i64 23 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l37
  br label %bb23
bb23:
  %t62 = load i64, ptr %l2, !tbaa !24
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = load i32, ptr %l37, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsRunCopy(ptr %v0, ptr %t63, i32 %t64, i64 %t62)
  store i1 %t66, ptr %l39
  br label %bb24
bb24:
  %t67 = load i1, ptr %l39, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
bb25:
  %t68 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t70 = trunc i64 24 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l42, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l45
  br label %bb29
bb29:
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i32, ptr %l45, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsRunCopy(ptr %v0, ptr %t80, i32 %t81, i64 %t79)
  store i1 %t83, ptr %l47
  br label %bb30
bb30:
  %t84 = load i1, ptr %l47, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb31:
  %t85 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb58
bb34:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb35
bb35:
  %t95 = load i1, ptr %l52, !tbaa !21
  %t96 = xor i1 %t95, true
  br i1 %t96, label %bb36, label %bb37
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l55, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l3, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l58
  br label %bb39
bb39:
  %t105 = load ptr, ptr %l55, !tbaa !29
  %t106 = load i32, ptr %l58, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t107, ptr %l59
  br label %bb40
bb40:
  %t108 = load i32, ptr %l59, !range !{i32 0, i32 6}
  store i32 %t108, ptr %l5
  %t109 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t111 = trunc i64 0 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l63, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l66
  br label %bb44
bb44:
  %t120 = load i64, ptr %l2, !tbaa !24
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load i32, ptr %l66, !tbaa !23
  %t124 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsRunCopy(ptr %v0, ptr %t121, i32 %t122, i64 %t120)
  store i1 %t124, ptr %l68
  br label %bb45
bb45:
  %t125 = load i1, ptr %l68, !tbaa !21
  store i1 %t125, ptr %l60, !tbaa !21
  br label %bb57
bb46:
  %t126 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t128 = trunc i64 1 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l71, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l3, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l74
  br label %bb50
bb50:
  %t137 = load i64, ptr %l2, !tbaa !24
  %t138 = load ptr, ptr %l71, !tbaa !29
  %t139 = load i32, ptr %l74, !tbaa !23
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsRunCopy(ptr %v0, ptr %t138, i32 %t139, i64 %t137)
  store i1 %t141, ptr %l76
  br label %bb51
bb51:
  %t142 = load i1, ptr %l76, !tbaa !21
  store i1 %t142, ptr %l60, !tbaa !21
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_937d2117677220f7_4e71d8f6c64016c3)
  unreachable
bb57:
  %t143 = load i1, ptr %l60, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 false, ptr %rv
  br label %ret
bb62:
  call void @__olang_check_failed(ptr @olang_loc_b2a5ea58cae3bcd6_127532dafa8fcf42)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %a0, i32 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/types:Table", ptr %t5, i32 0, i32 32
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sle i64 %t11, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t19, i8 0)
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %bb1
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/types:Table", ptr %t21, i32 0, i32 32
  %t24 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %t23, i64 %t24, i8 %a2)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l31 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i32
  %l47 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l55 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca i32
  %l64 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l73 = alloca i1
  %l78 = alloca ptr
  %l81 = alloca i32
  %l83 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l10
  br label %bb4
bb4:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l14
  br label %bb8
bb8:
  %t18 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t18, ptr %l3
  %t19 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t21 = trunc i64 20 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb11
bb10:
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t26 = trunc i64 21 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb13:
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t32 = trunc i64 25 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb17
bb16:
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t38 = trunc i64 29 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l23, !tbaa !21
  br i1 %t41, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t45 = trunc i64 18 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb53
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l31
  br label %bb24
bb24:
  %t53 = load i1, ptr %l31, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l34, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l37
  br label %bb28
bb28:
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = load i32, ptr %l37, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t65, ptr %l38
  br label %bb29
bb29:
  %t66 = load i32, ptr %l38, !range !{i32 0, i32 6}
  store i32 %t66, ptr %l4
  %t67 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t69 = trunc i64 0 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l42, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l45
  br label %bb33
bb33:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = load i32, ptr %l45, !tbaa !23
  %t82 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %t79, i32 %t80, i64 %t78, i1 false)
  store i1 %t82, ptr %l47
  br label %bb34
bb34:
  %t83 = load i1, ptr %l47, !tbaa !21
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb52
bb35:
  %t84 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t86 = trunc i64 1 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l1, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l53
  br label %bb39
bb39:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load ptr, ptr %l50, !tbaa !29
  %t97 = load i32, ptr %l53, !tbaa !23
  %t99 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %t96, i32 %t97, i64 %t95, i1 true)
  store i1 %t99, ptr %l55
  br label %bb40
bb40:
  %t100 = load i1, ptr %l55, !tbaa !21
  store i1 %t100, ptr %l39, !tbaa !21
  br label %bb52
bb41:
  %t101 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t103 = trunc i64 4 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l58, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l61
  br label %bb45
bb45:
  %t112 = load i64, ptr %l2, !tbaa !24
  %t114 = add i64 %t112, 1
  %t115 = load ptr, ptr %l58, !tbaa !29
  %t116 = load i32, ptr %l61, !tbaa !23
  %t118 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %t115, i32 %t116, i64 %t114)
  store i1 %t118, ptr %l64
  br label %bb46
bb46:
  %t119 = load i1, ptr %l64, !tbaa !21
  store i1 %t119, ptr %l39, !tbaa !21
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_e8197a4e96a8cf74_6f7a0b4ee9272b70)
  unreachable
bb52:
  %t120 = load i1, ptr %l39, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
bb53:
  %t121 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t123 = trunc i64 19 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l67, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l70
  br label %bb57
bb57:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t134 = add i64 %t132, 1
  %t135 = load ptr, ptr %l67, !tbaa !29
  %t136 = load i32, ptr %l70, !tbaa !23
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %t135, i32 %t136, i64 %t134)
  store i1 %t138, ptr %l73
  br label %bb58
bb58:
  %t139 = load i1, ptr %l73, !tbaa !21
  store i1 %t139, ptr %rv
  br label %ret
bb59:
  %t140 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t142 = trunc i64 22 to i32
  %t143 = icmp eq i32 %t140, %t142
  br i1 %t143, label %bb60, label %bb61
bb60:
  br label %bb64
bb61:
  %t145 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t147 = trunc i64 23 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l78, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l1, !tbaa !23
  %t155 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t151, i32 %t152)
  store i32 %t155, ptr %l81
  br label %bb65
bb65:
  %t156 = load i64, ptr %l2, !tbaa !24
  %t157 = load ptr, ptr %l78, !tbaa !29
  %t158 = load i32, ptr %l81, !tbaa !23
  %t160 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %t157, i32 %t158, i64 %t156, i1 false)
  store i1 %t160, ptr %l83
  br label %bb66
bb66:
  %t161 = load i1, ptr %l83, !tbaa !21
  store i1 %t161, ptr %rv
  br label %ret
bb67:
  %t162 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t164 = trunc i64 24 to i32
  %t165 = icmp eq i32 %t162, %t164
  br i1 %t165, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb73
bb70:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l86, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l1, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t172, ptr %l89
  br label %bb71
bb71:
  %t173 = load i64, ptr %l2, !tbaa !24
  %t174 = load ptr, ptr %l86, !tbaa !29
  %t175 = load i32, ptr %l89, !tbaa !23
  %t177 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %t174, i32 %t175, i64 %t173, i1 true)
  store i1 %t177, ptr %l91
  br label %bb72
bb72:
  %t178 = load i1, ptr %l91, !tbaa !21
  store i1 %t178, ptr %rv
  br label %ret
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i1 false, ptr %rv
  br label %ret
bb77:
  call void @__olang_check_failed(ptr @olang_loc_e0765d015d87e9a5_6d8cc8ea93d2cf01)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l8 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l53 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  %t15 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  %t20 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t22 = trunc i64 3 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb30
bb7:
  %t25 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t27 = trunc i64 4 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb30
bb9:
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t32 = trunc i64 5 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %bb30
bb11:
  %t35 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb12, label %bb13
bb12:
  br label %bb30
bb13:
  %t40 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t42 = trunc i64 7 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb30
bb15:
  %t45 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t47 = trunc i64 8 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb16, label %bb17
bb16:
  br label %bb30
bb17:
  %t50 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t52 = trunc i64 9 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb18, label %bb19
bb18:
  br label %bb30
bb19:
  %t55 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t57 = trunc i64 10 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb20, label %bb21
bb20:
  br label %bb30
bb21:
  %t60 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t62 = trunc i64 11 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t67 = trunc i64 12 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  %t70 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t72 = trunc i64 13 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t75 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t77 = trunc i64 14 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t80 = load i32, ptr %l1, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t84 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimLlvm, i64 0, i64 %t82
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !37
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t87, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l8, !tbaa !27
  br label %bb99
bb31:
  %t93 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t95 = trunc i64 31 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t98 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t103 = call i64 @__olang_fmt_i64(ptr null, i64 %t99)
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t100, i64 %t101)
  %t106 = getelementptr i8, ptr %t105, i64 %t101
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t99)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t105, 1
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  br label %bb99
bb35:
  %t111 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t113 = trunc i64 16 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t116, ptr %l8, !tbaa !27
  br label %bb99
bb39:
  %t118 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t120 = trunc i64 32 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb49
bb42:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l1, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l53
  br label %bb43
bb43:
  %t128 = load i32, ptr %l53, !tbaa !23
  %t129 = icmp eq i32 %t128, 5
  br i1 %t129, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t131, ptr %l55, !tbaa !27
  br label %bb48
bb45:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l58, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l1, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t138, ptr %l61
  br label %bb46
bb46:
  %t139 = load ptr, ptr %l58, !tbaa !29
  %t140 = load i32, ptr %l61, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %v1, ptr %t139, i32 %t140)
  store { i64, ptr } %t141, ptr %l62
  br label %bb47
bb47:
  %t142 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t142, ptr %l55, !tbaa !27
  br label %bb48
bb48:
  %t144 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  br label %bb99
bb49:
  %t145 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t147 = trunc i64 17 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t150, ptr %l8, !tbaa !27
  br label %bb99
bb53:
  %t152 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t154 = trunc i64 21 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l70, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t157, ptr %l8, !tbaa !27
  br label %bb99
bb57:
  %t159 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t161 = trunc i64 20 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb71
bb60:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l74, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l1, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l77
  br label %bb61
bb61:
  %t170 = load ptr, ptr %l74, !tbaa !29
  %t171 = load i32, ptr %l77, !tbaa !23
  %t172 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t172, ptr %l78
  br label %bb62
bb62:
  %t173 = load i1, ptr %l78, !tbaa !21
  br i1 %t173, label %bb63, label %bb64
bb63:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t174, ptr %l79, !tbaa !27
  br label %bb70
bb64:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l82, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l1, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l85
  br label %bb65
bb65:
  %t182 = load ptr, ptr %l82, !tbaa !29
  %t183 = load i32, ptr %l85, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t184, ptr %l86
  br label %bb66
bb66:
  %t185 = load i32, ptr %l86, !range !{i32 0, i32 33}
  %t187 = trunc i64 29 to i32
  %t188 = icmp eq i32 %t185, %t187
  br i1 %t188, label %bb67, label %bb68
bb67:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l90, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t190, ptr %l89, !tbaa !27
  br label %bb69
bb68:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t192, ptr %l89, !tbaa !27
  br label %bb69
bb69:
  %t194 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t194, ptr %l79, !tbaa !27
  br label %bb70
bb70:
  %t195 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t195, ptr %l8, !tbaa !27
  br label %bb99
bb71:
  %t196 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t198 = trunc i64 19 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l1, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l98
  br label %bb75
bb75:
  %t206 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t206, ptr %l8, !tbaa !27
  br label %bb99
bb76:
  %t207 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t209 = trunc i64 22 to i32
  %t210 = icmp eq i32 %t207, %t209
  br i1 %t210, label %bb77, label %bb78
bb77:
  br label %bb81
bb78:
  %t212 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t214 = trunc i64 23 to i32
  %t215 = icmp eq i32 %t212, %t214
  br i1 %t215, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb84
bb81:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l103, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l1, !tbaa !23
  %t222 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t218, i32 %t219)
  store i32 %t222, ptr %l106
  br label %bb82
bb82:
  %t223 = load ptr, ptr %l103, !tbaa !29
  %t224 = load i32, ptr %l106, !tbaa !23
  %t225 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %t223, i32 %t224)
  store { i64, ptr } %t225, ptr %l107
  br label %bb83
bb83:
  %t226 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t226, ptr %l8, !tbaa !27
  br label %bb99
bb84:
  %t227 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t229 = trunc i64 24 to i32
  %t230 = icmp eq i32 %t227, %t229
  br i1 %t230, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l1, !tbaa !23
  %t236 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t232, i32 %t233)
  store { i64, ptr } %t236, ptr %l112
  br label %bb88
bb88:
  %t237 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t237, ptr %l8, !tbaa !27
  br label %bb99
bb89:
  %t238 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t240 = trunc i64 18 to i32
  %t241 = icmp eq i32 %t238, %t240
  br i1 %t241, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l1, !tbaa !23
  %t247 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %t243, i32 %t244)
  store { i64, ptr } %t247, ptr %l117
  br label %bb93
bb93:
  %t248 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t248, ptr %l8, !tbaa !27
  br label %bb99
bb94:
  br i1 true, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l118, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t249, ptr %l8, !tbaa !27
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_bbfcd5581dbe335b_bbf57adf6fe10b0f)
  unreachable
bb99:
  %t251 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l120, !tbaa !24
  %t253 = load i64, ptr %l120, !tbaa !24
  %t254 = mul i64 %t253, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t254)
  %t256 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  store { i64, ptr } %t257, ptr %l121, !tbaa !27
  %t258 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = load i64, ptr %l120, !tbaa !24
  %t263 = mul i64 %t262, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t259, ptr %t261, i64 %t263, i1 false)
  %t264 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t264, ptr %l8, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t265, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2estructName(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i32
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, i64 }
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  %t13 = icmp eq i32 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t19 = extractvalue { i64, ptr } %t15, 1
  %t20 = extractvalue { i64, ptr } %t15, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t16, i64 %t17)
  %t26 = getelementptr i8, ptr %t25, i64 %t17
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = getelementptr i8, ptr %t26, i64 %t20
  call void @olang_textcopy(ptr %t27, ptr %t22, i64 %t23)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t25, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l19
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37, !prof !99
ok.37:
  store i64 %t34, ptr %l18
  br label %bb6
bb6:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l16, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l16, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l16, !tbaa !24
  store i64 %t43, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %s0, ptr %t44, i32 %t45)
  store { i64, ptr } %t48, ptr %l24
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t57 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %s0, { i64, ptr } %t55)
  store { i64, i64 } %t57, ptr %l26
  br label %bb11
bb11:
  %t58 = load { i64, i64 }, ptr %l26
  store { i64, i64 } %t58, ptr %l4
  %t59 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 0
  %t60 = load i64, ptr %t59, !tbaa !65
  store i64 %t60, ptr %l5, !tbaa !65
  %t62 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !65
  store i64 %t63, ptr %l6, !tbaa !65
  %t65 = load i64, ptr %l3, !tbaa !24
  store i64 %t65, ptr %l29, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l30, !tbaa !24
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load i64, ptr %l29, !tbaa !24
  %t71 = icmp sle i64 0, %t70
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb14:
  %t73 = load i64, ptr %l29, !tbaa !24
  %t74 = load i64, ptr %l30, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb16:
  %t77 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l29, !tbaa !24
  %t80 = getelementptr i8, ptr %t78, i64 0
  %t81 = sub i64 %t79, 0
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  store { i64, ptr } %t83, ptr %l34, !tbaa !27
  %t84 = load i64, ptr %l5, !tbaa !65
  %t86 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t84)
  store { i64, ptr } %t86, ptr %l36
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb18:
  %t87 = load i64, ptr %l6, !tbaa !65
  %t89 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t87)
  store { i64, ptr } %t89, ptr %l38
  br label %bb19
bb19:
  %t90 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t92 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = add i64 %t98, %t101
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t90, i64 %t91)
  %t111 = getelementptr i8, ptr %t110, i64 %t91
  call void @olang_textcopy(ptr %t111, ptr %t93, i64 %t94)
  %t112 = getelementptr i8, ptr %t111, i64 %t94
  call void @olang_textcopy(ptr %t112, ptr %t96, i64 %t97)
  %t113 = getelementptr i8, ptr %t112, i64 %t97
  call void @olang_textcopy(ptr %t113, ptr %t100, i64 %t101)
  %t114 = getelementptr i8, ptr %t113, i64 %t101
  call void @olang_textcopy(ptr %t114, ptr %t104, i64 %t105)
  %t115 = getelementptr i8, ptr %t114, i64 %t105
  call void @olang_textcopy(ptr %t115, ptr %t107, i64 %t108)
  %t116 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t110, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l10 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l44 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca i32
  %l52 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i32
  %l65 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca i1
  %l77 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca i32
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l10
  br label %bb4
bb4:
  %t11 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/types:Table", ptr %t16, i32 0, i32 36
  store ptr %t18, ptr %l14, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l17
  br label %bb7
bb6:
  br label %bb45
bb7:
  %t24 = load i32, ptr %l17, !tbaa !23
  %t25 = sext i32 %t24 to i64
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t28 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t26, i64 %t25)
  store i1 %t28, ptr %l19
  br label %bb8
bb8:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb12
bb12:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l27
  br label %bb16
bb16:
  %t43 = load i1, ptr %l27, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb17, label %bb18
bb17:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/types:Table", ptr %t46, i32 0, i32 33
  store i1 true, ptr %t48, !tbaa !21
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l1, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l34
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = load i32, ptr %l34, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t58, ptr %l35
  br label %bb21
bb21:
  %t59 = load i32, ptr %l35, !range !{i32 0, i32 6}
  store i32 %t59, ptr %l3
  %t60 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t62 = trunc i64 0 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l39, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l42
  br label %bb25
bb25:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = load i32, ptr %l42, !tbaa !23
  %t75 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %t72, i32 %t73, i64 %t71, i1 false)
  store i1 %t75, ptr %l44
  br label %bb26
bb26:
  %t76 = load i1, ptr %l44, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb44
bb27:
  %t77 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t79 = trunc i64 1 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l50
  br label %bb31
bb31:
  %t88 = load i64, ptr %l2, !tbaa !24
  %t89 = load ptr, ptr %l47, !tbaa !29
  %t90 = load i32, ptr %l50, !tbaa !23
  %t92 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %t89, i32 %t90, i64 %t88, i1 true)
  store i1 %t92, ptr %l52
  br label %bb32
bb32:
  %t93 = load i1, ptr %l52, !tbaa !21
  store i1 %t93, ptr %l36, !tbaa !21
  br label %bb44
bb33:
  %t94 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t96 = trunc i64 4 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l55, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l1, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l58
  br label %bb37
bb37:
  %t105 = load i64, ptr %l2, !tbaa !24
  %t107 = add i64 %t105, 1
  %t108 = load ptr, ptr %l55, !tbaa !29
  %t109 = load i32, ptr %l58, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %t108, i32 %t109, i64 %t107)
  store i1 %t111, ptr %l61
  br label %bb38
bb38:
  %t112 = load i1, ptr %l61, !tbaa !21
  store i1 %t112, ptr %l36, !tbaa !21
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_983e1053235c526f_18c94ea801ade2a3)
  unreachable
bb44:
  %t113 = load i1, ptr %l36, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
bb45:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l64
  br label %bb46
bb46:
  %t119 = load i32, ptr %l64, !range !{i32 0, i32 33}
  store i32 %t119, ptr %l4
  %t120 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t122 = trunc i64 19 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l68, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t130, ptr %l71
  br label %bb50
bb50:
  %t131 = load i64, ptr %l2, !tbaa !24
  %t133 = add i64 %t131, 1
  %t134 = load ptr, ptr %l68, !tbaa !29
  %t135 = load i32, ptr %l71, !tbaa !23
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %t134, i32 %t135, i64 %t133)
  store i1 %t137, ptr %l74
  br label %bb51
bb51:
  %t138 = load i1, ptr %l74, !tbaa !21
  store i1 %t138, ptr %l65, !tbaa !21
  br label %bb69
bb52:
  %t139 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t141 = trunc i64 23 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l77, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l1, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l80
  br label %bb56
bb56:
  %t150 = load i64, ptr %l2, !tbaa !24
  %t151 = load ptr, ptr %l77, !tbaa !29
  %t152 = load i32, ptr %l80, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %t151, i32 %t152, i64 %t150, i1 false)
  store i1 %t154, ptr %l82
  br label %bb57
bb57:
  %t155 = load i1, ptr %l82, !tbaa !21
  store i1 %t155, ptr %l65, !tbaa !21
  br label %bb69
bb58:
  %t156 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t158 = trunc i64 24 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l85, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l1, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l88
  br label %bb62
bb62:
  %t167 = load i64, ptr %l2, !tbaa !24
  %t168 = load ptr, ptr %l85, !tbaa !29
  %t169 = load i32, ptr %l88, !tbaa !23
  %t171 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %t168, i32 %t169, i64 %t167, i1 true)
  store i1 %t171, ptr %l90
  br label %bb63
bb63:
  %t172 = load i1, ptr %l90, !tbaa !21
  store i1 %t172, ptr %l65, !tbaa !21
  br label %bb69
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_427e8c4f545bd5ae_655f412a6751c1a2)
  unreachable
bb69:
  %t173 = load i1, ptr %l65, !tbaa !21
  store i1 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l52 = alloca i1
  %l55 = alloca { i64, ptr }
  %l62 = alloca i32
  %l66 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sle i64 %t13, 2305843009213693951
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_ebf284414dbafd61_1a8e1f26a2703ea5)
  unreachable
bb4:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = mul i64 %t16, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store i1 true, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ebf284414dbafd61_1a8e1f26a2703ea5)
  unreachable
bb6:
  %t32 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l27, !tbaa !24
  store i64 %t52, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l24, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l45, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t74, ptr %l47, !tbaa !27
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t75
  %t80 = load i32, ptr %t79, !tbaa !33
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t73, i32 %t80)
  store i32 %t83, ptr %l50
  br label %bb16
bb16:
  %t84 = load i32, ptr %l50, !tbaa !23
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i32, ptr %t87, i64 %t85
  store i32 %t84, ptr %t88, !tbaa !33
  %t89 = load i1, ptr %l4, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t91 = load i64, ptr %l10, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t91
  %t96 = load i32, ptr %t95, !tbaa !33
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  %t106 = icmp eq i32 %t96, %t103
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb19
bb19:
  %t108 = load i1, ptr %l52, !tbaa !21
  store i1 %t108, ptr %l4, !tbaa !21
  br label %bb20
bb20:
  %t109 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  %t113 = load i1, ptr %l4, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t115 = load i32, ptr %l1, !tbaa !23
  store i32 %t115, ptr %l62, !tbaa !23
  br label %bb25
bb23:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t117, { i64, ptr } %t118)
  store i32 %t121, ptr %l66
  br label %bb24
bb24:
  %t122 = load i32, ptr %l66, !tbaa !23
  store i32 %t122, ptr %l62, !tbaa !23
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i32, ptr %l62, !tbaa !23
  store i32 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2enamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:codeWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t8, ptr %t6, i32 %t7)
  store i1 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load i1, ptr %l8, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t19 = load ptr, ptr @__olang_prog_scope
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t19, ptr %t17, i32 %t18)
  store i32 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %t23, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l15
  br label %bb6
bb6:
  %t27 = load i32, ptr %l15, !range !{i32 0, i32 6}
  store i32 %t27, ptr %l3
  %t28 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t30 = trunc i64 0 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l19, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  %t36 = load ptr, ptr @__olang_prog_scope
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %t36, ptr %t34, i32 %t35)
  store i32 %t39, ptr %l22
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i32, ptr %l22, !tbaa !23
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t42, ptr %l23
  br label %bb11
bb11:
  %t43 = load i1, ptr %l23, !tbaa !21
  store i1 %t43, ptr %l16, !tbaa !21
  br label %bb29
bb12:
  %t44 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t46 = trunc i64 1 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l26, !tbaa !29
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t52 = load ptr, ptr @__olang_prog_scope
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %t52, ptr %t50, i32 %t51)
  store i32 %t55, ptr %l29
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = load i32, ptr %l29, !tbaa !23
  %t58 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t58, ptr %l30
  br label %bb17
bb17:
  %t59 = load i1, ptr %l30, !tbaa !21
  store i1 %t59, ptr %l16, !tbaa !21
  br label %bb29
bb18:
  %t60 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t62 = trunc i64 4 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l33, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i32, ptr %l1, !tbaa !23
  %t68 = load ptr, ptr @__olang_prog_scope
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %t68, ptr %t66, i32 %t67)
  store i32 %t71, ptr %l36
  br label %bb22
bb22:
  %t72 = load ptr, ptr %l33, !tbaa !29
  %t73 = load i32, ptr %l36, !tbaa !23
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t74, ptr %l37
  br label %bb23
bb23:
  %t75 = load i1, ptr %l37, !tbaa !21
  store i1 %t75, ptr %l16, !tbaa !21
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_99f937c00427181_9a6d61fc7809e035)
  unreachable
bb29:
  %t76 = load i1, ptr %l16, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i64
  %l43 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i1
  %l53 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca i1
  %l78 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:codeWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %t8, ptr %t6, i32 %t7)
  store i1 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/types:codeWalk", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l13
  br label %bb4
bb4:
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t25 = load ptr, ptr @__olang_prog_scope
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t25, ptr %t23, i32 %t24)
  store i32 %t28, ptr %l17
  br label %bb9
bb9:
  %t29 = load i32, ptr %l17, !range !{i32 0, i32 33}
  store i32 %t29, ptr %l3
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t32 = trunc i64 21 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t35 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t37 = trunc i64 25 to i32
  %t38 = icmp eq i32 %t35, %t37
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb15
bb14:
  %t41 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t43 = trunc i64 29 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/types:codeWalk", ptr %t48, i32 0, i32 1
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t53 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t55 = trunc i64 20 to i32
  %t56 = icmp eq i32 %t53, %t55
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  %t61 = load ptr, ptr @__olang_prog_scope
  %t64 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t61, ptr %t59, i32 %t60)
  store i64 %t64, ptr %l35
  br label %bb24
bb23:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb25
bb24:
  %t65 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t66 = load i64, ptr %l35, !tbaa !24
  %t68 = and i64 %t66, %t65
  %t70 = icmp ne i64 %t68, 0
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l32, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/types:codeWalk", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t76, i32 %t77)
  br label %bb29
bb29:
  %t80 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t82 = trunc i64 20 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l46, !tbaa !29
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t87 = load i32, ptr %l1, !tbaa !23
  %t88 = load ptr, ptr @__olang_prog_scope
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t88, ptr %t86, i32 %t87)
  store i32 %t91, ptr %l49
  br label %bb33
bb33:
  %t92 = load ptr, ptr %l46, !tbaa !29
  %t93 = load i32, ptr %l49, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t94, ptr %l50
  br label %bb34
bb34:
  %t95 = load i1, ptr %l50, !tbaa !21
  store i1 %t95, ptr %l43, !tbaa !21
  br label %bb65
bb35:
  %t96 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t98 = trunc i64 19 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l53, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t103 = load i32, ptr %l1, !tbaa !23
  %t104 = load ptr, ptr @__olang_prog_scope
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t104, ptr %t102, i32 %t103)
  store i32 %t107, ptr %l56
  br label %bb39
bb39:
  %t108 = load ptr, ptr %l53, !tbaa !29
  %t109 = load i32, ptr %l56, !tbaa !23
  %t110 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %t108, i32 %t109)
  store i1 %t110, ptr %l57
  br label %bb40
bb40:
  %t111 = load i1, ptr %l57, !tbaa !21
  store i1 %t111, ptr %l43, !tbaa !21
  br label %bb65
bb41:
  %t112 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t114 = trunc i64 22 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  %t117 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t119 = trunc i64 23 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l62, !tbaa !29
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t124 = load i32, ptr %l1, !tbaa !23
  %t125 = load ptr, ptr @__olang_prog_scope
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t125, ptr %t123, i32 %t124)
  store i32 %t128, ptr %l65
  br label %bb47
bb47:
  %t129 = load ptr, ptr %l62, !tbaa !29
  %t130 = load i32, ptr %l65, !tbaa !23
  %t131 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t131, ptr %l66
  br label %bb48
bb48:
  %t132 = load i1, ptr %l66, !tbaa !21
  store i1 %t132, ptr %l43, !tbaa !21
  br label %bb65
bb49:
  %t133 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t135 = trunc i64 24 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l69, !tbaa !29
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t140 = load i32, ptr %l1, !tbaa !23
  %t141 = load ptr, ptr @__olang_prog_scope
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %t141, ptr %t139, i32 %t140)
  store i32 %t144, ptr %l72
  br label %bb53
bb53:
  %t145 = load ptr, ptr %l69, !tbaa !29
  %t146 = load i32, ptr %l72, !tbaa !23
  %t147 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t147, ptr %l73
  br label %bb54
bb54:
  %t148 = load i1, ptr %l73, !tbaa !21
  store i1 %t148, ptr %l43, !tbaa !21
  br label %bb65
bb55:
  %t149 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t151 = trunc i64 18 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l1, !tbaa !23
  %t158 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2enamed(ptr %v0, ptr %t154, i32 %t155)
  store i1 %t158, ptr %l78
  br label %bb59
bb59:
  %t159 = load i1, ptr %l78, !tbaa !21
  store i1 %t159, ptr %l43, !tbaa !21
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_60c82cde6ffdb5d3_c68082b86ff4ff17)
  unreachable
bb65:
  %t160 = load i1, ptr %l43, !tbaa !21
  store i1 %t160, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l24 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:codeWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr @__olang_prog_scope
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t6, ptr %s1, ptr %t4, i32 %a1)
  store { i64, ptr } %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  store i32 %t29, ptr %l5, !tbaa !23
  %t31 = load i32, ptr %l5, !tbaa !23
  %t33 = icmp ne i32 %t31, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l24
  br label %bb8
bb7:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb8:
  %t40 = load i1, ptr %l24, !tbaa !21
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l15 = alloca { i64, ptr }
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store i64 -3750763034362895579, ptr %l1, !tbaa !65
  store i64 7809847782465536322, ptr %l2, !tbaa !65
  store i64 1099511628211, ptr %l3, !tbaa !65
  store { i64, ptr } %a0, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l7, !tbaa !22
  %t23 = load i64, ptr %l1, !tbaa !65
  %t24 = load i8, ptr %l7, !tbaa !22
  %t27 = zext i8 %t24 to i64
  %t30 = xor i64 %t23, %t27
  %t31 = load i64, ptr %l3, !tbaa !65
  %t34 = mul i64 %t30, %t31
  store i64 %t34, ptr %l1, !tbaa !65
  %t36 = load i64, ptr %l2, !tbaa !65
  %t37 = load i8, ptr %l7, !tbaa !22
  %t40 = zext i8 %t37 to i64
  %t43 = xor i64 %t36, %t40
  %t44 = load i64, ptr %l3, !tbaa !65
  %t47 = mul i64 %t43, %t44
  store i64 %t47, ptr %l2, !tbaa !65
  %t49 = load i64, ptr %l2, !tbaa !65
  %t50 = load i64, ptr %l2, !tbaa !65
  %t52 = lshr i64 %t50, 29
  %t55 = xor i64 %t49, %t52
  store i64 %t55, ptr %l2, !tbaa !65
  br label %bb5
bb5:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb1
bb6:
  %t61 = load i64, ptr %l1, !tbaa !65
  %t62 = load i64, ptr %l2, !tbaa !65
  %t64 = insertvalue { i64, i64 } undef, i64 %t61, 0
  %t66 = insertvalue { i64, i64 } %t64, i64 %t62, 1
  store { i64, i64 } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex16(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l1, !tbaa !65
  %t2 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t3 = extractvalue { i32, i64 } %t2, 1
  %t4 = extractvalue { i32, i64 } %t2, 0
  store i32 %t4, ptr %l3
  %t5 = icmp ne i32 %t4, 0
  br i1 %t5, label %bb2, label %ok.6, !prof !99
ok.6:
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  %t7 = load i64, ptr %l1, !tbaa !65
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t7, i64 %t8)
  store { i64, ptr } %t9, ptr %l4
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9d78c5c339795d98_5bda6918f751e21c)
  unreachable
bb3:
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  %t18 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t16, i64 16, i8 48)
  store { i64, ptr } %t18, ptr %l6
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l8, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex2(ptr %v0, i8 %a0) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = zext i8 %a0 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a384a4bbbe0ebea1_23bacf7041e0bcc5)
  unreachable
bb3:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t18, i64 2, i8 48)
  store { i64, ptr } %t20, ptr %l7
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l8, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = mul i64 %t23, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l8, !tbaa !24
  %t33 = mul i64 %t32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t34 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2eprimIndex(i64 %a0, i1 %a1) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp eq i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb21
bb4:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = icmp eq i64 %t5, 16
  br i1 %t7, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb21
bb8:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = icmp eq i64 %t9, 32
  br i1 %t11, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 2, ptr %l3, !tbaa !24
  br label %bb21
bb12:
  %t13 = load i64, ptr %l0, !tbaa !24
  %t15 = icmp eq i64 %t13, 64
  br i1 %t15, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 3, ptr %l3, !tbaa !24
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_99e2f46192b0b63e_14d40f533c20e2f2)
  unreachable
bb21:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp slt i64 %t18, 0
  br i1 %t20, label %bb22, label %bb23
bb22:
  store i64 0, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = add i64 3, %t23
  store i64 %t25, ptr %l16, !tbaa !24
  br i1 %a1, label %bb25, label %bb26
bb25:
  store i64 4, ptr %l18, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = add i64 %t28, %t29
  store i64 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftypes_2epushPayloads(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %a1, i32 %t28)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2esymbolHexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 48
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 57
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp uge i8 %t10, 97
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load i8, ptr %l0, !tbaa !22
  %t16 = icmp ule i8 %t14, 102
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2esymbolHexValue(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i64
  %rv = alloca i64
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp ule i8 %t1, 57
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = sub i8 %t5, 48
  %t9 = zext i8 %t7 to i64
  store i64 %t9, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t11 = load i8, ptr %l0, !tbaa !22
  %t13 = sub i8 %t11, 97
  %t15 = zext i8 %t13 to i64
  %t17 = add i64 %t15, 10
  store i64 %t17, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/types:DtorWalk" @compiler_2ftypes_3aDtorWalk_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"compiler/types:DtorWalk"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = insertvalue %"compiler/types:DtorWalk" undef, ptr %t5, 0
  %t8 = insertvalue %"compiler/types:DtorWalk" %t6, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, 1
  store %"compiler/types:DtorWalk" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:DtorWalk", ptr %rv
  ret %"compiler/types:DtorWalk" %rr
}

define dso_local void @compiler_2ftypes_3aTable_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i1
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l55 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l56 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l57 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l58 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l74 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l75 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l76 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l77 = alloca %"compiler/types:Table"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l41
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l42
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l42
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l43
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l44
  br label %bb4
bb4:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l6
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeI_He375cb5a1de17a5d01c6b8903f9691e1(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l45
  br label %bb5
bb5:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %l7
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l46
  br label %bb6
bb6:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l8
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l47
  br label %bb7
bb7:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l9
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l48
  br label %bb8
bb8:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l10
  %t19 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t19, ptr %l49
  br label %bb9
bb9:
  %t20 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t20, ptr %l11
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l50
  br label %bb10
bb10:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l12
  %t23 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t23, ptr %l51
  br label %bb11
bb11:
  %t24 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l51
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t24, ptr %l13
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l52
  br label %bb12
bb12:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l14
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l53
  br label %bb13
bb13:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l15
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He0d7a5bfd18ae956abf945564c24098c(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l54
  br label %bb14
bb14:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %l16
  %t31 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t31, ptr %l55
  br label %bb15
bb15:
  %t32 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l55
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t32, ptr %l17
  %t33 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20A_Hcfba385079b3349cc13047539d410cc3(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t33, ptr %l56
  br label %bb16
bb16:
  %t34 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l18
  %t35 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aDeclId_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l57
  br label %bb17
bb17:
  %t36 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l57
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t36, ptr %l19
  %t37 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t37, ptr %l58
  br label %bb18
bb18:
  %t38 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t38, ptr %l20
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l59
  br label %bb19
bb19:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l21
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l60
  br label %bb20
bb20:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l22
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l61
  br label %bb21
bb21:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l23
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l62
  br label %bb22
bb22:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l24
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l63
  br label %bb23
bb23:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l25
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l64
  br label %bb24
bb24:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l26
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l65
  br label %bb25
bb25:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l27
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l66
  br label %bb26
bb26:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l28
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l67
  br label %bb27
bb27:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l29
  %t57 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t57, ptr %l68
  br label %bb28
bb28:
  %t58 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t58, ptr %l30
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l69
  br label %bb29
bb29:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l31
  %t61 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t61, ptr %l70
  br label %bb30
bb30:
  %t62 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l70
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t62, ptr %l32
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l71
  br label %bb31
bb31:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l33
  store i1 false, ptr %l34, !tbaa !21
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l72
  br label %bb32
bb32:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l35
  %t67 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t67, ptr %l73
  br label %bb33
bb33:
  %t68 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l73
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t68, ptr %l36
  %t69 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t69, ptr %l74
  br label %bb34
bb34:
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l74
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %l37
  %t71 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t71, ptr %l75
  br label %bb35
bb35:
  %t72 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t72, ptr %l38
  %t73 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t73, ptr %l76
  br label %bb36
bb36:
  %t74 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l76
  %t75 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 0
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %t75, !tbaa !29
  %t77 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 1
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t77
  %t79 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 2
  %t80 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t80, ptr %t79
  %t81 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 3
  %t82 = load i1, ptr %l4, !tbaa !21
  store i1 %t82, ptr %t81, !tbaa !21
  %t83 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 4
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %t83
  %t85 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 5
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %t85
  %t87 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 6
  %t88 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t88, ptr %t87
  %t89 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 7
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %t89
  %t91 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 8
  %t92 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %t91
  %t93 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 9
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %t93
  %t95 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 10
  %t96 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t96, ptr %t95
  %t97 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 11
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %t97
  %t99 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 12
  %t100 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t100, ptr %t99
  %t101 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 13
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %t101
  %t103 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 14
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %t103
  %t105 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 15
  %t106 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t106, ptr %t105
  %t107 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 16
  %t108 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t108, ptr %t107
  %t109 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 17
  %t110 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t110, ptr %t109
  %t111 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 18
  %t112 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t112, ptr %t111
  %t113 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 19
  %t114 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %t113
  %t115 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 20
  %t116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %t115
  %t117 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 21
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %t117
  %t119 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 22
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %t119
  %t121 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 23
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %t121
  %t123 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 24
  %t124 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %t123
  %t125 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 25
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %t125
  %t127 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 26
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %t127
  %t129 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 27
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %t129
  %t131 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 28
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %t131
  %t133 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 29
  %t134 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l30
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t134, ptr %t133
  %t135 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 30
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %t135
  %t137 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 31
  %t138 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t138, ptr %t137
  %t139 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 32
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %t139
  %t141 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 33
  %t142 = load i1, ptr %l34, !tbaa !21
  store i1 %t142, ptr %t141, !tbaa !21
  %t143 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 34
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %t143
  %t145 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 35
  %t146 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t146, ptr %t145
  %t147 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 36
  %t148 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t148, ptr %t147
  %t149 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 37
  %t150 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t150, ptr %t149
  %t151 = getelementptr %"compiler/types:Table", ptr %l77, i32 0, i32 38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t74, ptr %t151
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l77, i64 1776, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/types:body"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/types:body" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/types:body" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/types:body" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/types:body" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/types:body" %t18, i1 %a4, 4
  store %"compiler/types:body" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:body", ptr %rv
  ret %"compiler/types:body" %rr
}

define dso_local %"compiler/types:codeWalk" @compiler_2ftypes_3acodeWalk_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i1
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/types:codeWalk"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 %a1, ptr %l3, !tbaa !21
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = insertvalue %"compiler/types:codeWalk" undef, ptr %t7, 0
  %t9 = load i1, ptr %l3, !tbaa !21
  %t10 = insertvalue %"compiler/types:codeWalk" %t8, i1 %t9, 1
  %t12 = insertvalue %"compiler/types:codeWalk" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, 2
  store %"compiler/types:codeWalk" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:codeWalk", ptr %rv
  ret %"compiler/types:codeWalk" %rr
}

define dso_local %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %rv = alloca %"compiler/types:data"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/types:data" undef, i32 %a0, 0
  %t18 = insertvalue %"compiler/types:data" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/types:data" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/types:data" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/types:data" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/types:data" %t24, i64 %a5, 5
  %t28 = insertvalue %"compiler/types:data" %t26, i64 %a6, 6
  store %"compiler/types:data" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local %"compiler/types:decl" @compiler_2ftypes_3adecl_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/types:decl"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/types:decl" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/types:decl" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/types:decl" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/types:decl" %t14, i32 %a3, 3
  store %"compiler/types:decl" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:decl", ptr %rv
  ret %"compiler/types:decl" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"_H" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_empty_array = external constant [16 x i64]
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"__" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"_H" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"{ i32, " }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 33}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 33}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"{ }" }>, align 8
@.d15 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d18 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" x " }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d24 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"default" }>, align 8
@.d25 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"noreturn" }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".#" }>, align 8
declare i64 @__olang_fmt_u64(ptr, i64)
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn?" }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ?" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ~[" }>, align 8
@.d44 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct(" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"enum{" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d50 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d53 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"any " }>, align 8
@.d54 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error{" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" + " }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d57 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d58 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"{ i64, [" }>, align 8
@.d59 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x i64] }" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d62 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d65 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d66 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d68 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d69 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d70 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d71 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d73 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%\22" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%\22" }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeI_He375cb5a1de17a5d01c6b8903f9691e1(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He0d7a5bfd18ae956abf945564c24098c(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20A_Hcfba385079b3349cc13047539d410cc3(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aDeclId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_c38cb1fa51df222a_dffb1d180717405e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_84fae12c7c668807_3becc0cabb21395b = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_350cf97603b2facf_69b011185289b33 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H5d6217f1de626e258ec0008385e9bf9b(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_8b13046bbc59237a_a5831af19cea45fe = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4622f22b1b9e72f9_4c12a3b980ae2b3d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_30e02956f84eec46_91b8152c5eb3aca = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_5cbd31595b499a54_61b0a2a5664e21e0 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, %"compiler/types:decl" %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_4cf414dd239e444f_4f727e94fd163263 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_363cc534119e1b58_f5bd72046473679c = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H69e9af7ee32b7ff0c8685324094a29a4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H41a2935585cca595f0dd127aea20d09e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H37377f924b66ff741793959f79fef546(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H6938bdf4910ae806791e4f0f97041ba1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_c5f0a3e3912a4ce3_83ad4b8f75c0f327 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b3c0df13ff143a95_992c52f0f53f0c49 = external constant [0 x i8]
@olang_loc_3a86b0904acb017a_fb1793104580b26e = external constant [0 x i8]
@olang_loc_448c58e2e97e944f_f556e6dbd0c75243 = external constant [0 x i8]
@olang_loc_136e48f5d148640e_b95a40c005170ac2 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/types:decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_cb508a25d2891980_42113325dd63632c = external constant [0 x i8]
@olang_loc_4d47e5476b23fa11_4ed9625d853ee5dd = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H5a37a20f375ed653adc00b592f5745cf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H08d487c91a3409a786f6b7c534acefc5(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H4ee179d696ae959fbb722da89c7f46de(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H25f20ec7bc3952e7f71d4b5fc38b1e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d3e704bcd06f7d56_ed5a4209a5557c8a = external constant [0 x i8]
@olang_loc_b4be3b7b6cfde177_2b1bada5393bc0cb = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H61b120fbdcc010be1bedf2507e848f7c(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_aca21d9f8d110f21_d35bd7e73631d7ed = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H2b3955a94f91e668ac3bcd9fa517bb83(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H830566a038befb7310211b752210e58f(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H010f1f1ff4e5a3a6ef2d904187315b0d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ecef2c1188620c25_f6c5d2506e285511 = external constant [0 x i8]
@olang_loc_6b6356ebbaa556b4_537d1793e4121070 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_f884bd4f1b6015d_20014de591249a11 = external constant [0 x i8]
@olang_loc_f7b42ec29d1607_26e89eedc9b3128b = external constant [0 x i8]
@olang_loc_2df495a001b30f12_f15d21f3e8677f6 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_63e623ceae63df16_2a862fe3f0344bd2 = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_888c44700641ffaa_fbe810d9adf00e56 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %a0, i32 %a1, %"compiler/types:body" %a2)
@olang_loc_f7eaf3fe8a46d3da_9f187abb7d2da27e = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Ha1b8741c5221fa161d1744b12cf57007(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ab5d312677a1c76d_705ca0c9b87dcf79 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare %"compiler/types:data" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bd4ce41e1f7e504b_596b58263987420f = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_94d95030786c6de_dc670b9e390cf1a = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %a0, %"compiler/types:data" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, %"compiler/types:data" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_b0143a025c7cdb06_8f46c74feff323b2 = external constant [0 x i8]
@olang_loc_2cd53dd7f17e3306_fa38995b8825f762 = external constant [0 x i8]
@olang_loc_e12a8b7b5dbe3de7_965cbd36c1b6d563 = external constant [0 x i8]
@olang_loc_34afd997c56f8665_d97bdd2c594f3b01 = external constant [0 x i8]
@olang_loc_dfad6825423c7f34_db691f90aea39770 = external constant [0 x i8]
@olang_loc_937d2117677220f7_4e71d8f6c64016c3 = external constant [0 x i8]
@olang_loc_b2a5ea58cae3bcd6_127532dafa8fcf42 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
@olang_loc_e8197a4e96a8cf74_6f7a0b4ee9272b70 = external constant [0 x i8]
@olang_loc_e0765d015d87e9a5_6d8cc8ea93d2cf01 = external constant [0 x i8]
@olang_loc_bbfcd5581dbe335b_bbf57adf6fe10b0f = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077 = external constant [0 x i8]
@olang_loc_983e1053235c526f_18c94ea801ade2a3 = external constant [0 x i8]
@olang_loc_427e8c4f545bd5ae_655f412a6751c1a2 = external constant [0 x i8]
@olang_loc_ebf284414dbafd61_1a8e1f26a2703ea5 = external constant [0 x i8]
@olang_loc_99f937c00427181_9a6d61fc7809e035 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_60c82cde6ffdb5d3_c68082b86ff4ff17 = external constant [0 x i8]
@olang_loc_9d78c5c339795d98_5bda6918f751e21c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_a384a4bbbe0ebea1_23bacf7041e0bcc5 = external constant [0 x i8]
@olang_loc_99e2f46192b0b63e_14d40f533c20e2f2 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
