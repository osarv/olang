; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List<compiler/types:data>", %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>", %"std/prelude/list:List<I32>", %"std/prelude/list:List<Array<compiler/types:TypeId>&>", %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>", %"std/prelude/list:List<Array<compiler/source:NameId>&>", %"std/prelude/list:List<compiler/types:ListId>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<compiler/types:decl>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>", %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>", %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/types:TypeId>", %"std/prelude/list:List<Array<I64>&>", %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>", %"std/prelude/list:List<Array<I64>&>", %"std/prelude/map:Map<Array<I64>&, I64>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", i1 }
%"std/prelude/list:List<compiler/types:data>" = type { ptr }
%"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<I32>" = type { ptr }
%"std/prelude/list:List<Array<compiler/types:TypeId>&>" = type { ptr }
%"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" = type { ptr }
%"std/prelude/list:List<Array<compiler/source:NameId>&>" = type { ptr }
%"std/prelude/list:List<compiler/types:ListId>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, I64>" = type { ptr }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/prelude/list:List<compiler/types:decl>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" = type { ptr }
%"std/prelude/list:List<I64>" = type { ptr }
%"std/prelude/list:List<compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<Array<I64>&>" = type { ptr }
%"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" = type { ptr }
%"std/prelude/map:Map<Array<I64>&, I64>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, I64>" = type { ptr }
%"compiler/types:data" = type { i32, i64, i64, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"compiler/types:decl" = type { i64, i32, i32, i32, i64 }
%"compiler/types:body" = type { i32, i32, i32, i1, i1 }
@G_2ecompiler_2ftypes_2eBigAggregate = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eBoolT = global i32 zeroinitializer
@G_2ecompiler_2ftypes_2eClosingVar = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eDefaultErrT = global i32 zeroinitializer
@G_2ecompiler_2ftypes_2eFromTypeVar = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eLaidOut = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eLayingOut = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eNoLayout = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eNoreturnT = global i32 zeroinitializer
@G_2ecompiler_2ftypes_2eNotLaidOut = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eNullT = global i32 zeroinitializer
@G_2ecompiler_2ftypes_2eOwnScope = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eOwning = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eReadOnly = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eResultVar = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eRoleCtor = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eRoleDtor = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eRoleFn = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eUnknownT = global i32 zeroinitializer
@G_2ecompiler_2ftypes_2eVoidT = global i32 zeroinitializer
@G_2ecompiler_2ftypes_2eWritable = global i64 zeroinitializer
@G_2ecompiler_2ftypes_2eprimBits = global { i64, ptr } zeroinitializer
@G_2ecompiler_2ftypes_2eprimLlvm = global { i64, ptr } zeroinitializer
@G_2ecompiler_2ftypes_2eprimNames = global { i64, ptr } zeroinitializer
define dso_local void @compiler_2ftypes_2eBigAggregate_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 128, ptr @G_2ecompiler_2ftypes_2eBigAggregate, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eBoolT_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 2, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eClosingVar_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -2, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eDefaultErrT_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 16, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eFromTypeVar_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -2, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eLaidOut_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 2, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eLayingOut_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 1, ptr @G_2ecompiler_2ftypes_2eLayingOut, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNewTable(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/types:Table"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca [18 x i32]
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca %"compiler/types:data"
  %l55 = alloca i32
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca %"compiler/types:Table"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t2 = alloca %"compiler/types:Table", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t3 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftypes_3aTable_2ector(ptr %t2, ptr %v0, ptr %v1, ptr %t3)
  %t4 = load %"compiler/types:Table", ptr %t2
  store %"compiler/types:Table" %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 240, i64 8)
  store ptr %t5, ptr %lp1
  %t6 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l7, i64 240, i1 false)
  %t7 = load ptr, ptr %lp1
  %t8 = getelementptr %"compiler/types:Table", ptr %t7, i32 0, i32 4
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = icmp sge i64 0, 0
  store i1 %t9, ptr %l9, !tbaa !21
  %t10 = load i1, ptr %l9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = icmp sle i64 0, 2305843009213693951
  store i1 %t11, ptr %l10, !tbaa !21
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb4:
  %t13 = mul i64 0, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 4
  %t21 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l12, !tbaa !27
  %t24 = load ptr, ptr %l8, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v1, ptr %v1, ptr %t24, { i64, ptr } %t25)
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb6:
  %t26 = load ptr, ptr %lp1
  %t27 = getelementptr %"compiler/types:Table", ptr %t26, i32 0, i32 24
  store ptr %t27, ptr %l13, !tbaa !29
  %t28 = icmp sge i64 0, 0
  store i1 %t28, ptr %l14, !tbaa !21
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = icmp sle i64 0, 1152921504606846975
  store i1 %t30, ptr %l15, !tbaa !21
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb9:
  %t32 = mul i64 0, 8
  %t33 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t32)
  %t34 = insertvalue { i64, ptr } undef, i64 0, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l16, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 8
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l17, !tbaa !27
  %t43 = load ptr, ptr %l13, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t43, { i64, ptr } %t44)
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb11:
  %t45 = load ptr, ptr %lp1
  %t46 = getelementptr %"compiler/types:Table", ptr %t45, i32 0, i32 26
  store ptr %t46, ptr %l18, !tbaa !29
  %t47 = icmp sge i64 0, 0
  store i1 %t47, ptr %l19, !tbaa !21
  %t48 = load i1, ptr %l19, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t49 = icmp sle i64 0, 1152921504606846975
  store i1 %t49, ptr %l20, !tbaa !21
  %t50 = load i1, ptr %l20, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb14:
  %t51 = mul i64 0, 8
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 0, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l21, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = mul i64 %t56, 8
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l22, !tbaa !27
  %t62 = load ptr, ptr %l18, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t62, { i64, ptr } %t63)
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb16:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 0, ptr %l23
  store i32 1, ptr %l24
  store i32 2, ptr %l25
  store i32 3, ptr %l26
  store i32 4, ptr %l27
  store i32 5, ptr %l28
  store i32 6, ptr %l29
  store i32 7, ptr %l30
  store i32 8, ptr %l31
  store i32 9, ptr %l32
  store i32 10, ptr %l33
  store i32 11, ptr %l34
  store i32 12, ptr %l35
  store i32 13, ptr %l36
  store i32 14, ptr %l37
  store i32 15, ptr %l38
  store i32 16, ptr %l39
  store i32 17, ptr %l40
  %t64 = load i32, ptr %l23
  %t65 = load i32, ptr %l24
  %t66 = load i32, ptr %l25
  %t67 = load i32, ptr %l26
  %t68 = load i32, ptr %l27
  %t69 = load i32, ptr %l28
  %t70 = load i32, ptr %l29
  %t71 = load i32, ptr %l30
  %t72 = load i32, ptr %l31
  %t73 = load i32, ptr %l32
  %t74 = load i32, ptr %l33
  %t75 = load i32, ptr %l34
  %t76 = load i32, ptr %l35
  %t77 = load i32, ptr %l36
  %t78 = load i32, ptr %l37
  %t79 = load i32, ptr %l38
  %t80 = load i32, ptr %l39
  %t81 = load i32, ptr %l40
  %t82 = getelementptr [18 x i32], ptr %l41, i64 0, i64 0
  store i32 %t64, ptr %t82
  %t83 = getelementptr [18 x i32], ptr %l41, i64 0, i64 1
  store i32 %t65, ptr %t83
  %t84 = getelementptr [18 x i32], ptr %l41, i64 0, i64 2
  store i32 %t66, ptr %t84
  %t85 = getelementptr [18 x i32], ptr %l41, i64 0, i64 3
  store i32 %t67, ptr %t85
  %t86 = getelementptr [18 x i32], ptr %l41, i64 0, i64 4
  store i32 %t68, ptr %t86
  %t87 = getelementptr [18 x i32], ptr %l41, i64 0, i64 5
  store i32 %t69, ptr %t87
  %t88 = getelementptr [18 x i32], ptr %l41, i64 0, i64 6
  store i32 %t70, ptr %t88
  %t89 = getelementptr [18 x i32], ptr %l41, i64 0, i64 7
  store i32 %t71, ptr %t89
  %t90 = getelementptr [18 x i32], ptr %l41, i64 0, i64 8
  store i32 %t72, ptr %t90
  %t91 = getelementptr [18 x i32], ptr %l41, i64 0, i64 9
  store i32 %t73, ptr %t91
  %t92 = getelementptr [18 x i32], ptr %l41, i64 0, i64 10
  store i32 %t74, ptr %t92
  %t93 = getelementptr [18 x i32], ptr %l41, i64 0, i64 11
  store i32 %t75, ptr %t93
  %t94 = getelementptr [18 x i32], ptr %l41, i64 0, i64 12
  store i32 %t76, ptr %t94
  %t95 = getelementptr [18 x i32], ptr %l41, i64 0, i64 13
  store i32 %t77, ptr %t95
  %t96 = getelementptr [18 x i32], ptr %l41, i64 0, i64 14
  store i32 %t78, ptr %t96
  %t97 = getelementptr [18 x i32], ptr %l41, i64 0, i64 15
  store i32 %t79, ptr %t97
  %t98 = getelementptr [18 x i32], ptr %l41, i64 0, i64 16
  store i32 %t80, ptr %t98
  %t99 = getelementptr [18 x i32], ptr %l41, i64 0, i64 17
  store i32 %t81, ptr %t99
  %t100 = load [18 x i32], ptr %l41
  %t101 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 72, i64 8)
  store [18 x i32] %t100, ptr %t101
  store ptr %t101, ptr %l42
  %t102 = load ptr, ptr %l42
  store ptr %t102, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t103 = load ptr, ptr %l2
  store ptr %t103, ptr %l43
  %t104 = load ptr, ptr %l43
  store i64 18, ptr %l44, !tbaa !24
  %t105 = load i64, ptr %l44, !tbaa !24
  store i64 %t105, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t106 = load i64, ptr %l3, !tbaa !24
  store i64 %t106, ptr %l45, !tbaa !24
  %t107 = load i64, ptr %l4, !tbaa !24
  store i64 %t107, ptr %l46, !tbaa !24
  %t108 = load i64, ptr %l45, !tbaa !24
  %t109 = load i64, ptr %l46, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  store i1 %t110, ptr %l47, !tbaa !21
  %t111 = load i1, ptr %l47, !tbaa !21
  %t112 = xor i1 %t111, true
  store i1 %t112, ptr %l48, !tbaa !21
  %t113 = load i1, ptr %l48, !tbaa !21
  br i1 %t113, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t114 = load ptr, ptr %l2
  store ptr %t114, ptr %l49
  %t115 = load i64, ptr %l3, !tbaa !24
  store i64 %t115, ptr %l50, !tbaa !24
  %t116 = load ptr, ptr %l49
  %t117 = load i64, ptr %l50, !tbaa !24
  %t118 = getelementptr [18 x i32], ptr %t116, i64 0, i64 %t117
  %t119 = load i32, ptr %t118
  store i32 %t119, ptr %l51
  %t120 = load i32, ptr %l51
  store i32 %t120, ptr %l5
  %t121 = load ptr, ptr %lp1
  store ptr %t121, ptr %l52, !tbaa !29
  %t122 = load i32, ptr %l5
  store i32 %t122, ptr %l53
  %t123 = load i32, ptr %l53
  %t124 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s2, i32 %t123, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t124, ptr %l54
  br label %bb21
bb21:
  %t125 = load ptr, ptr %l52, !tbaa !29
  %t126 = load %"compiler/types:data", ptr %l54
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v1, ptr %t125, %"compiler/types:data" %t126, i32 1)
  store i32 %t127, ptr %l55
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t128 = load i64, ptr %l3, !tbaa !24
  store i64 %t128, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l56, !tbaa !24
  %t130 = add i64 %t129, 1
  store i64 %t130, ptr %l57, !tbaa !24
  %t131 = load i64, ptr %l57, !tbaa !24
  store i64 %t131, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t132 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t132, i64 240, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t133 = load %"compiler/types:Table", ptr %l58
  store %"compiler/types:Table" %t133, ptr %out
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNoLayout_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 3, ptr @G_2ecompiler_2ftypes_2eNoLayout, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNoreturnT_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 17, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNotLaidOut_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr @G_2ecompiler_2ftypes_2eNotLaidOut, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNullT_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 15, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eOwnScope_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eOwning_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 2, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eReadOnly_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eResultVar_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleCtor_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 1, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleDtor_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 2, ptr @G_2ecompiler_2ftypes_2eRoleDtor, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleFn_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i8
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i8
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i8
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i8
  %l34 = alloca i8
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, i64 }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l11, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l13, !tbaa !24
  %t8 = load i64, ptr %l13, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l14, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l15, !tbaa !24
  %t11 = load i64, ptr %l14, !tbaa !24
  %t12 = load i64, ptr %l15, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l16, !tbaa !21
  %t14 = load i1, ptr %l16, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l17, !tbaa !21
  %t16 = load i1, ptr %l17, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l18, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t19
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l20, !tbaa !22
  %t24 = load i8, ptr %l20, !tbaa !22
  store i8 %t24, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  store i8 %t25, ptr %l21, !tbaa !22
  %t26 = load i8, ptr %l21, !tbaa !22
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t26)
  store i1 %t27, ptr %l22
  br label %bb6
bb6:
  %t28 = load i1, ptr %l22, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t29 = load i8, ptr %l5, !tbaa !22
  store i8 %t29, ptr %l24, !tbaa !22
  %t30 = load i8, ptr %l24, !tbaa !22
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t30)
  store i1 %t31, ptr %l25
  br label %bb9
bb9:
  %t32 = load i1, ptr %l25, !tbaa !21
  store i1 %t32, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l1, ptr %l26, !tbaa !29
  %t34 = load i8, ptr %l5, !tbaa !22
  store i8 %t34, ptr %l27, !tbaa !22
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = load i8, ptr %l27, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t35, i8 %t36)
  br label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t37 = load i8, ptr %l5, !tbaa !22
  store i8 %t37, ptr %l28, !tbaa !22
  %t38 = load i8, ptr %l28, !tbaa !22
  %t39 = icmp eq i8 %t38, 95
  store i1 %t39, ptr %l29, !tbaa !21
  %t40 = load i1, ptr %l29, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l1, ptr %l30, !tbaa !29
  %t41 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t41, { i64, ptr } { i64 2, ptr @.d3 })
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l1, ptr %l31, !tbaa !29
  %t42 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t42, i8 95)
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb17:
  store ptr %l1, ptr %l32, !tbaa !29
  %t43 = load i8, ptr %l5, !tbaa !22
  store i8 %t43, ptr %l33, !tbaa !22
  %t44 = load i8, ptr %l33, !tbaa !22
  store i8 %t44, ptr %l34, !tbaa !22
  %t45 = load i8, ptr %l34, !tbaa !22
  %t46 = call { i64, ptr } @compiler_2ftypes_2ehex2(ptr %s6, i8 %t45)
  store { i64, ptr } %t46, ptr %l35
  br label %bb18
bb18:
  %t47 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l36, !tbaa !27
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t54, { i64, ptr } %t55)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t56 = load i64, ptr %l3, !tbaa !24
  store i64 %t56, ptr %l37, !tbaa !24
  %t57 = load i64, ptr %l37, !tbaa !24
  %t58 = add i64 %t57, 1
  store i64 %t58, ptr %l38, !tbaa !24
  %t59 = load i64, ptr %l38, !tbaa !24
  store i64 %t59, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb2
bb23:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l1, ptr %l39, !tbaa !29
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t60)
  store { i64, ptr } %t61, ptr %l40
  br label %bb24
bb24:
  %t62 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t62, ptr %l6, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t63, ptr %l41, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l42, !tbaa !24
  %t66 = load i64, ptr %l42, !tbaa !24
  %t67 = icmp sle i64 %t66, 120
  store i1 %t67, ptr %l43, !tbaa !21
  %t68 = load i1, ptr %l43, !tbaa !21
  br i1 %t68, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l44, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t70, ptr %l45, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l46, !tbaa !24
  %t73 = load i64, ptr %l46, !tbaa !24
  %t74 = mul i64 %t73, 1
  %t75 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l47, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l46, !tbaa !24
  %t83 = mul i64 %t82, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t79, ptr %t81, i64 %t83, i1 false)
  %t84 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t84, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t86 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t86, ptr %l48, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t88 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %t87)
  store { i64, i64 } %t88, ptr %l49
  br label %bb28
bb28:
  %t89 = load { i64, i64 }, ptr %l49
  store { i64, i64 } %t89, ptr %l7
  %t90 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !65
  store i64 %t91, ptr %l50, !tbaa !65
  %t92 = load i64, ptr %l50, !tbaa !65
  store i64 %t92, ptr %l8, !tbaa !65
  %t93 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !65
  store i64 %t94, ptr %l51, !tbaa !65
  %t95 = load i64, ptr %l51, !tbaa !65
  store i64 %t95, ptr %l9, !tbaa !65
  %t96 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t96, ptr %l52, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l53, !tbaa !24
  %t99 = icmp sge i64 0, 0
  store i1 %t99, ptr %l54, !tbaa !21
  %t100 = load i1, ptr %l54, !tbaa !21
  br i1 %t100, label %bb29, label %bb30
bb29:
  %t101 = icmp sle i64 0, 88
  store i1 %t101, ptr %l55, !tbaa !21
  %t102 = load i1, ptr %l55, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb31:
  %t103 = load i64, ptr %l53, !tbaa !24
  %t104 = icmp sle i64 88, %t103
  store i1 %t104, ptr %l56, !tbaa !21
  %t105 = load i1, ptr %l56, !tbaa !21
  br i1 %t105, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb33:
  %t106 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 0
  %t109 = sub i64 88, 0
  %t110 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  store { i64, ptr } %t111, ptr %l57, !tbaa !27
  %t112 = load i64, ptr %l8, !tbaa !65
  store i64 %t112, ptr %l58, !tbaa !65
  %t113 = load i64, ptr %l58, !tbaa !65
  %t114 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t113)
  store { i64, ptr } %t114, ptr %l59
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb35:
  %t115 = load i64, ptr %l9, !tbaa !65
  store i64 %t115, ptr %l60, !tbaa !65
  %t116 = load i64, ptr %l60, !tbaa !65
  %t117 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t116)
  store { i64, ptr } %t117, ptr %l61
  br label %bb36
bb36:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t118 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  call void @__olang_sb_put(ptr %s9, ptr %t119, i64 %t120)
  %t121 = extractvalue { i64, ptr } { i64 2, ptr @.d5 }, 1
  %t122 = extractvalue { i64, ptr } { i64 2, ptr @.d5 }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t121, i64 %t122)
  %t123 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  call void @__olang_sb_put(ptr %s9, ptr %t124, i64 %t125)
  %t126 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  call void @__olang_sb_put(ptr %s9, ptr %t127, i64 %t128)
  %t129 = load ptr, ptr %s9
  %t130 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t131 = load i64, ptr %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t129, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  store { i64, ptr } %t134, ptr %l62, !tbaa !27
  call void @__olang_sb_done(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t135 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t135, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eUnknownT_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !65
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !65
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t8, i64 %t9)
  store { i64, ptr } %t10, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c6)
  unreachable
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eVoidT_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 1, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eWritable_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 1, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:data"
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca %"compiler/types:decl"
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l33 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l10, !tbaa !23
  %t8 = load i32, ptr %l10, !tbaa !23
  store i32 %t8, ptr %l11, !tbaa !23
  %t9 = load i32, ptr %l11, !tbaa !23
  store i32 %t9, ptr %l6, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 11
  store ptr %t12, ptr %l13, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l14, !tbaa !24
  %t14 = load i32, ptr %l2, !tbaa !23
  store i32 %t14, ptr %l15, !tbaa !23
  %t15 = load i32, ptr %l3
  store i32 %t15, ptr %l16
  %t16 = load i32, ptr %l4, !tbaa !23
  store i32 %t16, ptr %l17, !tbaa !23
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %l18, !tbaa !24
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = load i32, ptr %l16
  %t21 = load i32, ptr %l17, !tbaa !23
  %t22 = load i64, ptr %l18, !tbaa !24
  %t23 = call %"compiler/types:decl" @compiler_2ftypes_3adecl_2ector(ptr %s0, i64 %t18, i32 %t19, i32 %t20, i32 %t21, i64 %t22)
  store %"compiler/types:decl" %t23, ptr %l19
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load %"compiler/types:decl", ptr %l19
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t24, %"compiler/types:decl" %t25)
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l20, !tbaa !29
  %t27 = load ptr, ptr %l20, !tbaa !29
  %t28 = getelementptr %"compiler/types:Table", ptr %t27, i32 0, i32 13
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = getelementptr %"compiler/types:Table", ptr %t30, i32 0, i32 12
  store ptr %t31, ptr %l23, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = load ptr, ptr %l23, !tbaa !29
  %t34 = load i64, ptr %l24, !tbaa !24
  %t35 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t33, i64 %t34)
  store { i64, ptr } %t35, ptr %l25
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l26, !tbaa !29
  %t37 = load ptr, ptr %l26, !tbaa !29
  %t38 = getelementptr %"compiler/types:Table", ptr %t37, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l27, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  store i32 %t40, ptr %l28, !tbaa !23
  %t41 = load ptr, ptr %l27, !tbaa !29
  %t42 = load i32, ptr %l28, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t41, i32 %t42)
  store { i64, ptr } %t43, ptr %l29
  br label %bb5
bb5:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  call void @__olang_sb_put(ptr %s1, ptr %t45, i64 %t46)
  %t47 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t47, i64 %t48)
  %t49 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  call void @__olang_sb_put(ptr %s1, ptr %t50, i64 %t51)
  %t52 = load ptr, ptr %s1
  %t53 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t54 = load i64, ptr %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t52, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t58 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  %t60 = extractvalue { i64, ptr } %t58, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l31, !tbaa !27
  %t65 = load i32, ptr %l6, !tbaa !23
  store i32 %t65, ptr %l32, !tbaa !23
  %t66 = load ptr, ptr %l21, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t68 = load i32, ptr %l32, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v0, ptr %t66, { i64, ptr } %t67, i32 %t68)
  br label %bb6
bb6:
  %t69 = load i32, ptr %l6, !tbaa !23
  store i32 %t69, ptr %l33, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t70 = load i32, ptr %l33, !tbaa !23
  store i32 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 12
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l7, !tbaa !29
  %t24 = load ptr, ptr %l7, !tbaa !29
  %t25 = getelementptr %"compiler/types:Table", ptr %t24, i32 0, i32 12
  store ptr %t25, ptr %l8, !tbaa !29
  %t26 = load ptr, ptr %l8, !tbaa !29
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t26)
  store i64 %t27, ptr %l9
  br label %bb2
bb2:
  %t28 = load i64, ptr %l9, !tbaa !24
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i64, ptr %l10, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 18
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i32
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i32
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i64
  %l111 = alloca %"compiler/types:data"
  %l112 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l19, !tbaa !23
  %t3 = load ptr, ptr %l18, !tbaa !29
  %t4 = load i32, ptr %l19, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i32, ptr %l20, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l21
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t8, ptr %l4
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l22, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t11, ptr %l23, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l24, !tbaa !24
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  store i64 %t15, ptr %l25, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  store i64 %t16, ptr %l26, !tbaa !24
  %t17 = load i64, ptr %l25, !tbaa !24
  %t18 = load i64, ptr %l26, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l27, !tbaa !21
  %t20 = load i1, ptr %l27, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l28, !tbaa !21
  %t22 = load i1, ptr %l28, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l29, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  store i64 %t24, ptr %l30, !tbaa !24
  %t25 = load i64, ptr %l30, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t25
  %t29 = load i32, ptr %t28, !tbaa !33
  store i32 %t29, ptr %l31, !tbaa !23
  %t30 = load i32, ptr %l31, !tbaa !23
  store i32 %t30, ptr %l8, !tbaa !23
  store ptr %l4, ptr %l32, !tbaa !29
  %t31 = load i32, ptr %l8, !tbaa !23
  store i32 %t31, ptr %l33, !tbaa !23
  %t32 = load i32, ptr %l33, !tbaa !23
  store i32 %t32, ptr %l34, !tbaa !23
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t33 = load i32, ptr %l34, !tbaa !23
  %t34 = sext i32 %t33 to i64
  %t35 = call ptr @__olang_sb_room(ptr %s3, i64 24)
  %t36 = call i64 @__olang_fmt_i64(ptr %t35, i64 %t34)
  call void @__olang_sb_add(ptr %s3, i64 %t36)
  %t37 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t37, i64 %t38)
  %t39 = load ptr, ptr %s3
  %t40 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t41 = load i64, ptr %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t39, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l35, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  %t45 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l36, !tbaa !27
  %t52 = load ptr, ptr %l32, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t52, { i64, ptr } %t53)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t54 = load i64, ptr %l6, !tbaa !24
  store i64 %t54, ptr %l37, !tbaa !24
  %t55 = load i64, ptr %l37, !tbaa !24
  %t56 = add i64 %t55, 1
  store i64 %t56, ptr %l38, !tbaa !24
  %t57 = load i64, ptr %l38, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb3
bb9:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l4, ptr %l39, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  store i32 %t58, ptr %l40, !tbaa !23
  %t59 = load i32, ptr %l40, !tbaa !23
  store i32 %t59, ptr %l41, !tbaa !23
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t60, i64 %t61)
  %t62 = load i32, ptr %l41, !tbaa !23
  %t63 = sext i32 %t62 to i64
  %t64 = call ptr @__olang_sb_room(ptr %s5, i64 24)
  %t65 = call i64 @__olang_fmt_i64(ptr %t64, i64 %t63)
  call void @__olang_sb_add(ptr %s5, i64 %t65)
  %t66 = load ptr, ptr %s5
  %t67 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t68 = load i64, ptr %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t66, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t72 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l43, !tbaa !27
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l43, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t79, { i64, ptr } %t80)
  br label %bb10
bb10:
  store ptr %l4, ptr %l44, !tbaa !29
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t82 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t81)
  store { i64, ptr } %t82, ptr %l45
  br label %bb11
bb11:
  %t83 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t83, ptr %l9, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l47, !tbaa !29
  %t85 = load ptr, ptr %l47, !tbaa !29
  %t86 = getelementptr %"compiler/types:Table", ptr %t85, i32 0, i32 8
  store ptr %t86, ptr %l48, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t87, ptr %l49, !tbaa !27
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s0, ptr %t88, { i64, ptr } %t89)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l51
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb13, label %ok.94
ok.94:
  store i64 %t91, ptr %l50
  br label %bb12
bb12:
  %t95 = load i64, ptr %l50, !tbaa !24
  store i64 %t95, ptr %l46, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l46, !tbaa !24
  br label %bb15
bb15:
  %t96 = load i64, ptr %l46, !tbaa !24
  store i64 %t96, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  store i64 %t97, ptr %l52, !tbaa !24
  %t98 = load i64, ptr %l52, !tbaa !24
  %t99 = icmp slt i64 %t98, 0
  store i1 %t99, ptr %l53, !tbaa !21
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t101 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t101, ptr %l54, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l55, !tbaa !24
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = icmp sge i64 %t104, 0
  store i1 %t105, ptr %l56, !tbaa !21
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb18, label %bb19
bb17:
  br label %bb38
bb18:
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = icmp sle i64 %t107, 2305843009213693951
  store i1 %t108, ptr %l57, !tbaa !21
  %t109 = load i1, ptr %l57, !tbaa !21
  br i1 %t109, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb20:
  %t110 = load i64, ptr %l55, !tbaa !24
  %t111 = mul i64 %t110, 4
  %t112 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l58, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = mul i64 %t116, 4
  %t119 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l59, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t122, ptr %l11, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s7
  store i64 0, ptr %l12, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t123, ptr %l60, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  store i64 %t125, ptr %l61, !tbaa !24
  %t126 = load i64, ptr %l61, !tbaa !24
  store i64 %t126, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  store i64 %t127, ptr %l62, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  store i64 %t128, ptr %l63, !tbaa !24
  %t129 = load i64, ptr %l62, !tbaa !24
  %t130 = load i64, ptr %l63, !tbaa !24
  %t131 = icmp sgt i64 %t129, %t130
  store i1 %t131, ptr %l64, !tbaa !21
  %t132 = load i1, ptr %l64, !tbaa !21
  br i1 %t132, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb22:
  %t133 = load i64, ptr %l14, !tbaa !24
  store i64 %t133, ptr %l66, !tbaa !24
  %t134 = load i64, ptr %l66, !tbaa !24
  %t135 = icmp sgt i64 %t134, 0
  store i1 %t135, ptr %l67, !tbaa !21
  %t136 = load i1, ptr %l67, !tbaa !21
  br i1 %t136, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb27
bb24:
  %t137 = load i64, ptr %l13, !tbaa !24
  store i64 %t137, ptr %l69, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  store i64 %t138, ptr %l70, !tbaa !24
  %t139 = load i64, ptr %l69, !tbaa !24
  %t140 = load i64, ptr %l70, !tbaa !24
  %t141 = sub i64 %t139, %t140
  store i64 %t141, ptr %l71, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  store i64 %t142, ptr %l72, !tbaa !24
  %t143 = load i64, ptr %l71, !tbaa !24
  %t144 = load i64, ptr %l72, !tbaa !24
  %t145 = add i64 %t143, %t144
  store i64 %t145, ptr %l73, !tbaa !24
  %t146 = load i64, ptr %l73, !tbaa !24
  %t147 = sub i64 %t146, 1
  store i64 %t147, ptr %l74, !tbaa !24
  %t148 = load i64, ptr %l14, !tbaa !24
  store i64 %t148, ptr %l75, !tbaa !24
  %t149 = load i64, ptr %l74, !tbaa !24
  %t150 = load i64, ptr %l75, !tbaa !24
  %t151 = sdiv i64 %t149, %t150
  store i64 %t151, ptr %l76, !tbaa !24
  %t152 = load i64, ptr %l76, !tbaa !24
  store i64 %t152, ptr %l68, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb26
bb26:
  %t153 = load i64, ptr %l68, !tbaa !24
  store i64 %t153, ptr %l65, !tbaa !24
  br label %bb27
bb27:
  %t154 = load i64, ptr %l65, !tbaa !24
  store i64 %t154, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t155 = load i64, ptr %l16, !tbaa !24
  store i64 %t155, ptr %l77, !tbaa !24
  %t156 = load i64, ptr %l15, !tbaa !24
  store i64 %t156, ptr %l78, !tbaa !24
  %t157 = load i64, ptr %l77, !tbaa !24
  %t158 = load i64, ptr %l78, !tbaa !24
  %t159 = icmp slt i64 %t157, %t158
  store i1 %t159, ptr %l79, !tbaa !21
  %t160 = load i1, ptr %l79, !tbaa !21
  %t161 = xor i1 %t160, true
  store i1 %t161, ptr %l80, !tbaa !21
  %t162 = load i1, ptr %l80, !tbaa !21
  br i1 %t162, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t163 = load i64, ptr %l12, !tbaa !24
  store i64 %t163, ptr %l81, !tbaa !24
  %t164 = load i64, ptr %l16, !tbaa !24
  store i64 %t164, ptr %l82, !tbaa !24
  %t165 = load i64, ptr %l14, !tbaa !24
  store i64 %t165, ptr %l83, !tbaa !24
  %t166 = load i64, ptr %l82, !tbaa !24
  %t167 = load i64, ptr %l83, !tbaa !24
  %t168 = mul i64 %t166, %t167
  store i64 %t168, ptr %l84, !tbaa !24
  %t169 = load i64, ptr %l81, !tbaa !24
  %t170 = load i64, ptr %l84, !tbaa !24
  %t171 = add i64 %t169, %t170
  store i64 %t171, ptr %l85, !tbaa !24
  %t172 = load i64, ptr %l85, !tbaa !24
  store i64 %t172, ptr %l17, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t173, ptr %l86, !tbaa !27
  %t174 = load i64, ptr %l17, !tbaa !24
  store i64 %t174, ptr %l87, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t175, ptr %l88, !tbaa !27
  %t176 = load i64, ptr %l17, !tbaa !24
  store i64 %t176, ptr %l89, !tbaa !24
  %t177 = load i64, ptr %l89, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i32, ptr %t179, i64 %t177
  %t181 = load i32, ptr %t180, !tbaa !33
  store i32 %t181, ptr %l90, !tbaa !23
  %t182 = load i32, ptr %l90, !tbaa !23
  %t183 = load i64, ptr %l87, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t183
  store i32 %t182, ptr %t186, !tbaa !33
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t187 = load i64, ptr %l16, !tbaa !24
  store i64 %t187, ptr %l91, !tbaa !24
  %t188 = load i64, ptr %l91, !tbaa !24
  %t189 = add i64 %t188, 1
  store i64 %t189, ptr %l92, !tbaa !24
  %t190 = load i64, ptr %l92, !tbaa !24
  store i64 %t190, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb33:
  call void @__olang_scope_close(ptr %s7)
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l93, !tbaa !29
  %t192 = load ptr, ptr %l93, !tbaa !29
  %t193 = getelementptr %"compiler/types:Table", ptr %t192, i32 0, i32 6
  store ptr %t193, ptr %l94, !tbaa !29
  %t194 = load ptr, ptr %l94, !tbaa !29
  %t195 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H9437066785f0bdbcfc17884fffb14a92(ptr %v0, ptr %t194)
  store i64 %t195, ptr %l95
  br label %bb34
bb34:
  %t196 = load i64, ptr %l95, !tbaa !24
  store i64 %t196, ptr %l10, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l96, !tbaa !29
  %t198 = load ptr, ptr %l96, !tbaa !29
  %t199 = getelementptr %"compiler/types:Table", ptr %t198, i32 0, i32 6
  store ptr %t199, ptr %l97, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t200, ptr %l98, !tbaa !27
  %t201 = load ptr, ptr %l97, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l98, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v0, ptr %t201, { i64, ptr } %t202)
  br label %bb35
bb35:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l99, !tbaa !29
  %t204 = load ptr, ptr %l99, !tbaa !29
  %t205 = getelementptr %"compiler/types:Table", ptr %t204, i32 0, i32 7
  store ptr %t205, ptr %l100, !tbaa !29
  %t206 = load i32, ptr %l3, !tbaa !23
  store i32 %t206, ptr %l101, !tbaa !23
  %t207 = load ptr, ptr %l100, !tbaa !29
  %t208 = load i32, ptr %l101, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t207, i32 %t208)
  br label %bb36
bb36:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l102, !tbaa !29
  %t210 = load ptr, ptr %l102, !tbaa !29
  %t211 = getelementptr %"compiler/types:Table", ptr %t210, i32 0, i32 8
  store ptr %t211, ptr %l103, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t212, ptr %l104, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t213 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  call void @__olang_sb_put(ptr %s10, ptr %t214, i64 %t215)
  %t216 = load ptr, ptr %s10
  %t217 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t218 = load i64, ptr %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t216, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l105, !tbaa !27
  call void @__olang_sb_done(ptr %s10)
  %t222 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  store { i64, ptr } %t228, ptr %l106, !tbaa !27
  %t229 = load i64, ptr %l10, !tbaa !24
  store i64 %t229, ptr %l107, !tbaa !24
  %t230 = load ptr, ptr %l103, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t232 = load i64, ptr %l107, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t230, { i64, ptr } %t231, i64 %t232)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l108, !tbaa !29
  store i32 24, ptr %l109
  %t234 = load i64, ptr %l10, !tbaa !24
  store i64 %t234, ptr %l110, !tbaa !24
  %t235 = load i32, ptr %l109
  %t236 = load i64, ptr %l110, !tbaa !24
  %t237 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t235, i64 %t236, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t237, ptr %l111
  br label %bb39
bb39:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l112, !tbaa !29
  %t239 = load i32, ptr %l3, !tbaa !23
  store i32 %t239, ptr %l113, !tbaa !23
  %t240 = load ptr, ptr %l112, !tbaa !29
  %t241 = load i32, ptr %l113, !tbaa !23
  %t242 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t242, ptr %l114
  br label %bb40
bb40:
  %t243 = load i32, ptr %l114, !tbaa !23
  %t244 = add i32 %t243, 1
  store i32 %t244, ptr %l115, !tbaa !23
  %t245 = load ptr, ptr %l108, !tbaa !29
  %t246 = load %"compiler/types:data", ptr %l111
  %t247 = load i32, ptr %l115, !tbaa !23
  %t248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t245, %"compiler/types:data" %t246, i32 %t247)
  store i32 %t248, ptr %l116
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t249 = load i32, ptr %l116, !tbaa !23
  store i32 %t249, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca %"compiler/types:data"
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 19, ptr %l5
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  %t3 = load i32, ptr %l6, !tbaa !23
  %t4 = sext i32 %t3 to i64
  store i64 %t4, ptr %l7, !tbaa !24
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l8, !tbaa !23
  %t6 = load i32, ptr %l8, !tbaa !23
  %t7 = sext i32 %t6 to i64
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i32, ptr %l5
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t8, i64 %t9, i64 %t10, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  store i32 %t13, ptr %l12, !tbaa !23
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = add i32 %t17, 1
  store i32 %t18, ptr %l14, !tbaa !23
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load %"compiler/types:data", ptr %l10
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t19, %"compiler/types:data" %t20, i32 %t21)
  store i32 %t22, ptr %l15
  br label %bb3
bb3:
  %t23 = load i32, ptr %l15, !tbaa !23
  store i32 %t23, ptr %l3, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  store i32 %t25, ptr %l17, !tbaa !23
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i32, ptr %l17, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t28, ptr %l18
  br label %bb4
bb4:
  %t29 = load i32, ptr %l1, !tbaa !23
  store i32 %t29, ptr %l19, !tbaa !23
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = load i32, ptr %l19, !tbaa !23
  %t32 = icmp ne i32 %t30, %t31
  store i1 %t32, ptr %l20, !tbaa !21
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %l21, !tbaa !29
  %t36 = getelementptr %"compiler/types:Table", ptr %t35, i32 0, i32 23
  store ptr %t36, ptr %l22, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  store i32 %t37, ptr %l23, !tbaa !23
  %t38 = load i32, ptr %l23, !tbaa !23
  %t39 = sext i32 %t38 to i64
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  store i32 %t42, ptr %l27, !tbaa !23
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = load i32, ptr %l27, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t45, ptr %l28
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t46 = load i32, ptr %l2, !tbaa !23
  store i32 %t46, ptr %l29, !tbaa !23
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i32, ptr %l28, !tbaa !23
  %t49 = load i32, ptr %l29, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t47, i32 %t48, i32 %t49)
  store i32 %t50, ptr %l30
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load i64, ptr %l24, !tbaa !24
  %t53 = load i32, ptr %l30, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t51, i64 %t52, i32 %t53)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t54 = load i32, ptr %l3, !tbaa !23
  store i32 %t54, ptr %l31, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i32, ptr %l31, !tbaa !23
  store i32 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:data"
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:body"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 2
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l2, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp sle i32 %t2, 14
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = sext i32 %t6 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimBits, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t8
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eByAddress(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  store i32 %t8, ptr %l8, !tbaa !23
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load i32, ptr %l8, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i32, ptr %l9
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3
  store i32 %t13, ptr %l11
  %t14 = load i32, ptr %l11
  %t15 = trunc i64 22 to i32
  %t16 = icmp eq i32 %t14, %t15
  store i1 %t16, ptr %l12, !tbaa !21
  %t17 = load i1, ptr %l12, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load i32, ptr %l3
  store i32 %t18, ptr %l13
  %t19 = load i32, ptr %l13
  %t20 = trunc i64 23 to i32
  %t21 = icmp eq i32 %t19, %t20
  store i1 %t21, ptr %l14, !tbaa !21
  %t22 = load i1, ptr %l14, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb8:
  %t23 = load i32, ptr %l3
  store i32 %t23, ptr %l15
  %t24 = load i32, ptr %l15
  %t25 = trunc i64 18 to i32
  %t26 = icmp eq i32 %t24, %t25
  store i1 %t26, ptr %l16, !tbaa !21
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb15
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  store i32 %t30, ptr %l19, !tbaa !23
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load i32, ptr %l19, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l20
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l21
  br label %bb13
bb13:
  store ptr %l21, ptr %l22, !tbaa !29
  store i32 0, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  %t37 = load ptr, ptr %l22, !tbaa !29
  %t38 = load ptr, ptr %l24, !tbaa !29
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %t37, ptr %t38)
  store i1 %t39, ptr %l25
  br label %bb14
bb14:
  %t40 = load i1, ptr %l25, !tbaa !21
  store i1 %t40, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb15:
  %t41 = load i32, ptr %l3
  store i32 %t41, ptr %l26
  %t42 = load i32, ptr %l26
  %t43 = trunc i64 19 to i32
  %t44 = icmp eq i32 %t42, %t43
  store i1 %t44, ptr %l27, !tbaa !21
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  store i32 %t47, ptr %l29, !tbaa !23
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t49 = load i32, ptr %l29, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t50, ptr %l30
  br label %bb19
bb19:
  %t51 = load i32, ptr %l30, !tbaa !23
  %t52 = icmp ne i32 %t51, 0
  store i1 %t52, ptr %l31, !tbaa !21
  %t53 = load i1, ptr %l31, !tbaa !21
  store i1 %t53, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load i1, ptr %l10, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:data"
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 3
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l4, !tbaa !29
  store ptr %l2, ptr %l5, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %s0, ptr %t5, ptr %t6, i32 %t7)
  br label %bb2
bb2:
  store ptr %l2, ptr %l7, !tbaa !29
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t8)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 15
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v0, ptr %t5, i32 %t6)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } zeroinitializer, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:body"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i1
  %l35 = alloca i32
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca i32
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i32
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i32
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i32
  %l78 = alloca i1
  %l79 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca i1
  %l86 = alloca i32
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l7
  %t9 = load i32, ptr %l7
  store i32 %t9, ptr %l3
  %t10 = load i32, ptr %l3
  store i32 %t10, ptr %l9
  %t11 = load i32, ptr %l9
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %l10, !tbaa !21
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  %t15 = load i32, ptr %l3
  store i32 %t15, ptr %l11
  %t16 = load i32, ptr %l11
  %t17 = trunc i64 25 to i32
  %t18 = icmp eq i32 %t16, %t17
  store i1 %t18, ptr %l12, !tbaa !21
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  %t20 = load i32, ptr %l3
  store i32 %t20, ptr %l13
  %t21 = load i32, ptr %l13
  %t22 = trunc i64 27 to i32
  %t23 = icmp eq i32 %t21, %t22
  store i1 %t23, ptr %l14, !tbaa !21
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  %t25 = load i32, ptr %l3
  store i32 %t25, ptr %l15
  %t26 = load i32, ptr %l15
  %t27 = trunc i64 15 to i32
  %t28 = icmp eq i32 %t26, %t27
  store i1 %t28, ptr %l16, !tbaa !21
  %t29 = load i1, ptr %l16, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb78
bb11:
  %t30 = load i32, ptr %l3
  store i32 %t30, ptr %l17
  %t31 = load i32, ptr %l17
  %t32 = trunc i64 18 to i32
  %t33 = icmp eq i32 %t31, %t32
  store i1 %t33, ptr %l18, !tbaa !21
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t35 = load i32, ptr %l3
  store i32 %t35, ptr %l19
  %t36 = load i32, ptr %l19
  %t37 = trunc i64 22 to i32
  %t38 = icmp eq i32 %t36, %t37
  store i1 %t38, ptr %l20, !tbaa !21
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t40 = load i32, ptr %l3
  store i32 %t40, ptr %l21
  %t41 = load i32, ptr %l21
  %t42 = trunc i64 23 to i32
  %t43 = icmp eq i32 %t41, %t42
  store i1 %t43, ptr %l22, !tbaa !21
  %t44 = load i1, ptr %l22, !tbaa !21
  br i1 %t44, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb24
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l24
  store ptr %l24, ptr %l25, !tbaa !29
  store i32 18, ptr %l26
  store ptr %l26, ptr %l27, !tbaa !29
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t48, ptr %t49)
  store i1 %t50, ptr %l28
  br label %bb19
bb19:
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb20, label %bb21
bb20:
  %t52 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l30, !tbaa !24
  %t54 = load i64, ptr %l30, !tbaa !24
  store i64 %t54, ptr %l29, !tbaa !24
  br label %bb22
bb21:
  %t55 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l31, !tbaa !24
  %t57 = load i64, ptr %l31, !tbaa !24
  store i64 %t57, ptr %l29, !tbaa !24
  br label %bb22
bb22:
  %t58 = load i64, ptr %l29, !tbaa !24
  %t59 = trunc i64 %t58 to i32
  store i32 %t59, ptr %l32, !tbaa !23
  %t60 = load i32, ptr %l32, !tbaa !23
  store i32 %t60, ptr %l33, !tbaa !23
  %t61 = load ptr, ptr %l23, !tbaa !29
  %t62 = load i32, ptr %l33, !tbaa !23
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t63, ptr %l34
  br label %bb23
bb23:
  %t64 = load i1, ptr %l34, !tbaa !21
  store i1 %t64, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb24:
  %t65 = load i32, ptr %l3
  store i32 %t65, ptr %l35
  %t66 = load i32, ptr %l35
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t66, %t67
  store i1 %t68, ptr %l36, !tbaa !21
  %t69 = load i1, ptr %l36, !tbaa !21
  br i1 %t69, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb39
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l38, !tbaa !29
  %t72 = load i32, ptr %l1, !tbaa !23
  store i32 %t72, ptr %l39, !tbaa !23
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t75, ptr %l40
  br label %bb28
bb28:
  %t76 = load ptr, ptr %l37, !tbaa !29
  %t77 = load i32, ptr %l40, !tbaa !23
  %t78 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t78, ptr %l41
  br label %bb29
bb29:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb30, label %bb31
bb30:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l43, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  store i32 %t81, ptr %l44, !tbaa !23
  %t82 = load ptr, ptr %l43, !tbaa !29
  %t83 = load i32, ptr %l44, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t84, ptr %l45
  br label %bb32
bb31:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb38
bb32:
  %t85 = load i32, ptr %l45, !tbaa !23
  %t86 = icmp eq i32 %t85, 0
  store i1 %t86, ptr %l46, !tbaa !21
  %t87 = load i1, ptr %l46, !tbaa !21
  br i1 %t87, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb37
bb34:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l48, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l49, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  store i32 %t90, ptr %l50, !tbaa !23
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load i32, ptr %l50, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t93, ptr %l51
  br label %bb35
bb35:
  %t94 = load ptr, ptr %l48, !tbaa !29
  %t95 = load i32, ptr %l51, !tbaa !23
  %t96 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t96, ptr %l52
  br label %bb36
bb36:
  %t97 = load i1, ptr %l52, !tbaa !21
  store i1 %t97, ptr %l47, !tbaa !21
  br label %bb37
bb37:
  %t98 = load i1, ptr %l47, !tbaa !21
  store i1 %t98, ptr %l42, !tbaa !21
  br label %bb38
bb38:
  %t99 = load i1, ptr %l42, !tbaa !21
  store i1 %t99, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb39:
  %t100 = load i32, ptr %l3
  store i32 %t100, ptr %l53
  %t101 = load i32, ptr %l53
  %t102 = trunc i64 20 to i32
  %t103 = icmp eq i32 %t101, %t102
  store i1 %t103, ptr %l54, !tbaa !21
  %t104 = load i1, ptr %l54, !tbaa !21
  br i1 %t104, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb45
bb42:
  store %olang.scope zeroinitializer, ptr %s4
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l56, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  store i32 %t107, ptr %l57, !tbaa !23
  %t108 = load ptr, ptr %l56, !tbaa !29
  %t109 = load i32, ptr %l57, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t110, ptr %l58
  br label %bb43
bb43:
  %t111 = load ptr, ptr %l55, !tbaa !29
  %t112 = load i32, ptr %l58, !tbaa !23
  %t113 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t113, ptr %l59
  br label %bb44
bb44:
  %t114 = load i1, ptr %l59, !tbaa !21
  store i1 %t114, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb78
bb45:
  %t115 = load i32, ptr %l3
  store i32 %t115, ptr %l60
  %t116 = load i32, ptr %l60
  %t117 = trunc i64 21 to i32
  %t118 = icmp eq i32 %t116, %t117
  store i1 %t118, ptr %l61, !tbaa !21
  %t119 = load i1, ptr %l61, !tbaa !21
  br i1 %t119, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb61
bb48:
  store %olang.scope zeroinitializer, ptr %s5
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l62, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l63, !tbaa !29
  %t122 = load i32, ptr %l1, !tbaa !23
  store i32 %t122, ptr %l64, !tbaa !23
  %t123 = load ptr, ptr %l63, !tbaa !29
  %t124 = load i32, ptr %l64, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t125, ptr %l65
  br label %bb49
bb49:
  %t126 = load ptr, ptr %l62, !tbaa !29
  %t127 = load i32, ptr %l65, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l66
  br label %bb50
bb50:
  %t129 = load i1, ptr %l66, !tbaa !21
  br i1 %t129, label %bb51, label %bb52
bb51:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l68, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l69, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  store i32 %t132, ptr %l70, !tbaa !23
  %t133 = load ptr, ptr %l69, !tbaa !29
  %t134 = load i32, ptr %l70, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t135, ptr %l71
  br label %bb53
bb52:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb55
bb53:
  %t136 = load ptr, ptr %l68, !tbaa !29
  %t137 = load i32, ptr %l71, !tbaa !23
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t138, ptr %l72
  br label %bb54
bb54:
  %t139 = load i1, ptr %l72, !tbaa !21
  store i1 %t139, ptr %l67, !tbaa !21
  br label %bb55
bb55:
  %t140 = load i1, ptr %l67, !tbaa !21
  br i1 %t140, label %bb56, label %bb57
bb56:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l74, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l75, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  store i32 %t143, ptr %l76, !tbaa !23
  %t144 = load ptr, ptr %l75, !tbaa !29
  %t145 = load i32, ptr %l76, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t146, ptr %l77
  br label %bb58
bb57:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb60
bb58:
  %t147 = load ptr, ptr %l74, !tbaa !29
  %t148 = load i32, ptr %l77, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t147, i32 %t148)
  store i1 %t149, ptr %l78
  br label %bb59
bb59:
  %t150 = load i1, ptr %l78, !tbaa !21
  store i1 %t150, ptr %l73, !tbaa !21
  br label %bb60
bb60:
  %t151 = load i1, ptr %l73, !tbaa !21
  store i1 %t151, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb78
bb61:
  %t152 = load i32, ptr %l3
  store i32 %t152, ptr %l79
  %t153 = load i32, ptr %l79
  %t154 = trunc i64 24 to i32
  %t155 = icmp eq i32 %t153, %t154
  store i1 %t155, ptr %l80, !tbaa !21
  %t156 = load i1, ptr %l80, !tbaa !21
  br i1 %t156, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  store %olang.scope zeroinitializer, ptr %s6
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l82, !tbaa !29
  %t159 = load i32, ptr %l1, !tbaa !23
  store i32 %t159, ptr %l83, !tbaa !23
  %t160 = load ptr, ptr %l82, !tbaa !29
  %t161 = load i32, ptr %l83, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t162, ptr %l84
  br label %bb65
bb65:
  %t163 = load ptr, ptr %l81, !tbaa !29
  %t164 = load i32, ptr %l84, !tbaa !23
  %t165 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t165, ptr %l85
  br label %bb66
bb66:
  %t166 = load i1, ptr %l85, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb78
bb67:
  %t167 = load i32, ptr %l3
  store i32 %t167, ptr %l86
  %t168 = load i32, ptr %l86
  %t169 = trunc i64 26 to i32
  %t170 = icmp eq i32 %t168, %t169
  store i1 %t170, ptr %l87, !tbaa !21
  %t171 = load i1, ptr %l87, !tbaa !21
  br i1 %t171, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb73
bb70:
  store %olang.scope zeroinitializer, ptr %s7
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l88, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l89, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  store i32 %t174, ptr %l90, !tbaa !23
  %t175 = load ptr, ptr %l89, !tbaa !29
  %t176 = load i32, ptr %l90, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t177, ptr %l91
  br label %bb71
bb71:
  %t178 = load ptr, ptr %l88, !tbaa !29
  %t179 = load i32, ptr %l91, !tbaa !23
  %t180 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t178, i32 %t179)
  store i1 %t180, ptr %l92
  br label %bb72
bb72:
  %t181 = load i1, ptr %l92, !tbaa !21
  store i1 %t181, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s8
  store i1 true, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb78:
  call void @__olang_scope_close(ptr %s0)
  %t182 = load i1, ptr %l8, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, i64 }
  %l20 = alloca { i64, i64 }
  %l21 = alloca i32
  %l22 = alloca { i64, i64 }
  %l23 = alloca { i64, i64 }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca %"compiler/types:data"
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i1
  %l35 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i32
  %l38 = alloca i1
  %l39 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i32
  %l42 = alloca i1
  %l43 = alloca i32
  %l44 = alloca i1
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i32
  %l48 = alloca i1
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca i32
  %l54 = alloca i1
  %l55 = alloca i32
  %l56 = alloca i1
  %l57 = alloca i32
  %l58 = alloca i1
  %l59 = alloca i32
  %l60 = alloca i1
  %l61 = alloca i32
  %l62 = alloca i1
  %l63 = alloca i32
  %l64 = alloca i32
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca i32
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i32
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i32
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca i1
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i32
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca i32
  %l96 = alloca i1
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca ptr
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca i32
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i32
  %l128 = alloca i1
  %l129 = alloca i32
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca i32
  %l136 = alloca { i64, i64 }
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i32
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca ptr
  %l144 = alloca i32
  %l145 = alloca i32
  %l146 = alloca { i64, i64 }
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i32
  %l150 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i32
  %l153 = alloca i1
  %l154 = alloca i1
  %l155 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca ptr
  %l158 = alloca i32
  %l159 = alloca i32
  %l160 = alloca i32
  %l161 = alloca i32
  %l162 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca ptr
  %l166 = alloca i32
  %l167 = alloca i32
  %l168 = alloca { i64, i64 }
  %l169 = alloca i64
  %l170 = alloca i64
  %l171 = alloca i32
  %l172 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca ptr
  %l176 = alloca i32
  %l177 = alloca i32
  %l178 = alloca { i64, i64 }
  %l179 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i32
  %l182 = alloca i1
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i32
  %l186 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i32
  %l189 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca i64
  %l193 = alloca i64
  %l194 = alloca i1
  %l195 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i32
  %l198 = alloca i64
  %l199 = alloca ptr
  %l200 = alloca i32
  %l201 = alloca i64
  %l202 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i32
  %l205 = alloca i1
  %l206 = alloca i1
  %l207 = alloca i1
  %l208 = alloca ptr
  %l209 = alloca ptr
  %l210 = alloca i32
  %l211 = alloca i64
  %l212 = alloca i64
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca i32
  %l216 = alloca i64
  %l217 = alloca i64
  %l218 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l30, !tbaa !23
  %t3 = load ptr, ptr %l29, !tbaa !29
  %t4 = load i32, ptr %l30, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l31
  store %"compiler/types:data" %t6, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l32
  %t9 = load i32, ptr %l32
  store i32 %t9, ptr %l5
  %t10 = load i32, ptr %l5
  store i32 %t10, ptr %l33
  %t11 = load i32, ptr %l33
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %l34, !tbaa !21
  %t14 = load i1, ptr %l34, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  %t15 = load i32, ptr %l5
  store i32 %t15, ptr %l35
  %t16 = load i32, ptr %l35
  %t17 = trunc i64 17 to i32
  %t18 = icmp eq i32 %t16, %t17
  store i1 %t18, ptr %l36, !tbaa !21
  %t19 = load i1, ptr %l36, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb135
bb7:
  %t20 = load i32, ptr %l5
  store i32 %t20, ptr %l37
  %t21 = load i32, ptr %l37
  %t22 = trunc i64 2 to i32
  %t23 = icmp eq i32 %t21, %t22
  store i1 %t23, ptr %l38, !tbaa !21
  %t24 = load i1, ptr %l38, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb34
bb9:
  %t25 = load i32, ptr %l5
  store i32 %t25, ptr %l39
  %t26 = load i32, ptr %l39
  %t27 = trunc i64 3 to i32
  %t28 = icmp eq i32 %t26, %t27
  store i1 %t28, ptr %l40, !tbaa !21
  %t29 = load i1, ptr %l40, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  br label %bb34
bb11:
  %t30 = load i32, ptr %l5
  store i32 %t30, ptr %l41
  %t31 = load i32, ptr %l41
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t31, %t32
  store i1 %t33, ptr %l42, !tbaa !21
  %t34 = load i1, ptr %l42, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb12:
  br label %bb34
bb13:
  %t35 = load i32, ptr %l5
  store i32 %t35, ptr %l43
  %t36 = load i32, ptr %l43
  %t37 = trunc i64 5 to i32
  %t38 = icmp eq i32 %t36, %t37
  store i1 %t38, ptr %l44, !tbaa !21
  %t39 = load i1, ptr %l44, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  br label %bb34
bb15:
  %t40 = load i32, ptr %l5
  store i32 %t40, ptr %l45
  %t41 = load i32, ptr %l45
  %t42 = trunc i64 6 to i32
  %t43 = icmp eq i32 %t41, %t42
  store i1 %t43, ptr %l46, !tbaa !21
  %t44 = load i1, ptr %l46, !tbaa !21
  br i1 %t44, label %bb16, label %bb17
bb16:
  br label %bb34
bb17:
  %t45 = load i32, ptr %l5
  store i32 %t45, ptr %l47
  %t46 = load i32, ptr %l47
  %t47 = trunc i64 7 to i32
  %t48 = icmp eq i32 %t46, %t47
  store i1 %t48, ptr %l48, !tbaa !21
  %t49 = load i1, ptr %l48, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb34
bb19:
  %t50 = load i32, ptr %l5
  store i32 %t50, ptr %l49
  %t51 = load i32, ptr %l49
  %t52 = trunc i64 8 to i32
  %t53 = icmp eq i32 %t51, %t52
  store i1 %t53, ptr %l50, !tbaa !21
  %t54 = load i1, ptr %l50, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  br label %bb34
bb21:
  %t55 = load i32, ptr %l5
  store i32 %t55, ptr %l51
  %t56 = load i32, ptr %l51
  %t57 = trunc i64 9 to i32
  %t58 = icmp eq i32 %t56, %t57
  store i1 %t58, ptr %l52, !tbaa !21
  %t59 = load i1, ptr %l52, !tbaa !21
  br i1 %t59, label %bb22, label %bb23
bb22:
  br label %bb34
bb23:
  %t60 = load i32, ptr %l5
  store i32 %t60, ptr %l53
  %t61 = load i32, ptr %l53
  %t62 = trunc i64 10 to i32
  %t63 = icmp eq i32 %t61, %t62
  store i1 %t63, ptr %l54, !tbaa !21
  %t64 = load i1, ptr %l54, !tbaa !21
  br i1 %t64, label %bb24, label %bb25
bb24:
  br label %bb34
bb25:
  %t65 = load i32, ptr %l5
  store i32 %t65, ptr %l55
  %t66 = load i32, ptr %l55
  %t67 = trunc i64 11 to i32
  %t68 = icmp eq i32 %t66, %t67
  store i1 %t68, ptr %l56, !tbaa !21
  %t69 = load i1, ptr %l56, !tbaa !21
  br i1 %t69, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  %t70 = load i32, ptr %l5
  store i32 %t70, ptr %l57
  %t71 = load i32, ptr %l57
  %t72 = trunc i64 12 to i32
  %t73 = icmp eq i32 %t71, %t72
  store i1 %t73, ptr %l58, !tbaa !21
  %t74 = load i1, ptr %l58, !tbaa !21
  br i1 %t74, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  %t75 = load i32, ptr %l5
  store i32 %t75, ptr %l59
  %t76 = load i32, ptr %l59
  %t77 = trunc i64 13 to i32
  %t78 = icmp eq i32 %t76, %t77
  store i1 %t78, ptr %l60, !tbaa !21
  %t79 = load i1, ptr %l60, !tbaa !21
  br i1 %t79, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t80 = load i32, ptr %l5
  store i32 %t80, ptr %l61
  %t81 = load i32, ptr %l61
  %t82 = trunc i64 14 to i32
  %t83 = icmp eq i32 %t81, %t82
  store i1 %t83, ptr %l62, !tbaa !21
  %t84 = load i1, ptr %l62, !tbaa !21
  br i1 %t84, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s2
  %t85 = load i32, ptr %l1, !tbaa !23
  store i32 %t85, ptr %l63, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t86, ptr %l64, !tbaa !23
  %t87 = load i32, ptr %l63, !tbaa !23
  %t88 = load i32, ptr %l64, !tbaa !23
  %t89 = icmp ne i32 %t87, %t88
  store i1 %t89, ptr %l65, !tbaa !21
  %t90 = load i1, ptr %l65, !tbaa !21
  br i1 %t90, label %bb35, label %bb36
bb35:
  %t91 = load i32, ptr %l1, !tbaa !23
  store i32 %t91, ptr %l67, !tbaa !23
  %t92 = load i32, ptr %l67, !tbaa !23
  %t93 = sext i32 %t92 to i64
  store i64 %t93, ptr %l68, !tbaa !24
  %t94 = load i64, ptr %l68, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimBits, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i64, ptr %t96, i64 %t94
  %t98 = load i64, ptr %t97, !tbaa !34
  store i64 %t98, ptr %l69, !tbaa !24
  %t99 = load i64, ptr %l69, !tbaa !24
  %t100 = sdiv i64 %t99, 8
  store i64 %t100, ptr %l70, !tbaa !24
  %t101 = load i64, ptr %l70, !tbaa !24
  store i64 %t101, ptr %l66, !tbaa !24
  br label %bb37
bb36:
  store i64 1, ptr %l66, !tbaa !24
  br label %bb37
bb37:
  %t102 = load i64, ptr %l66, !tbaa !24
  store i64 %t102, ptr %l3, !tbaa !24
  %t103 = load i64, ptr %l3, !tbaa !24
  store i64 %t103, ptr %l71, !tbaa !24
  %t104 = load i64, ptr %l71, !tbaa !24
  store i64 %t104, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb135
bb38:
  %t105 = load i32, ptr %l5
  store i32 %t105, ptr %l72
  %t106 = load i32, ptr %l72
  %t107 = trunc i64 16 to i32
  %t108 = icmp eq i32 %t106, %t107
  store i1 %t108, ptr %l73, !tbaa !21
  %t109 = load i1, ptr %l73, !tbaa !21
  br i1 %t109, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 4, ptr %l6, !tbaa !24
  store i64 4, ptr %l7, !tbaa !24
  %t110 = load i64, ptr %l6, !tbaa !24
  store i64 %t110, ptr %l74, !tbaa !24
  %t111 = load i64, ptr %l74, !tbaa !24
  store i64 %t111, ptr %l3, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  store i64 %t112, ptr %l75, !tbaa !24
  %t113 = load i64, ptr %l75, !tbaa !24
  store i64 %t113, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb135
bb42:
  %t114 = load i32, ptr %l5
  store i32 %t114, ptr %l76
  %t115 = load i32, ptr %l76
  %t116 = trunc i64 21 to i32
  %t117 = icmp eq i32 %t115, %t116
  store i1 %t117, ptr %l77, !tbaa !21
  %t118 = load i1, ptr %l77, !tbaa !21
  br i1 %t118, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 16, ptr %l8, !tbaa !24
  store i64 8, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l8, !tbaa !24
  store i64 %t119, ptr %l78, !tbaa !24
  %t120 = load i64, ptr %l78, !tbaa !24
  store i64 %t120, ptr %l3, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  store i64 %t121, ptr %l79, !tbaa !24
  %t122 = load i64, ptr %l79, !tbaa !24
  store i64 %t122, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb135
bb46:
  %t123 = load i32, ptr %l5
  store i32 %t123, ptr %l80
  %t124 = load i32, ptr %l80
  %t125 = trunc i64 20 to i32
  %t126 = icmp eq i32 %t124, %t125
  store i1 %t126, ptr %l81, !tbaa !21
  %t127 = load i1, ptr %l81, !tbaa !21
  br i1 %t127, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb55
bb49:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l82, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l83, !tbaa !29
  %t130 = load i32, ptr %l1, !tbaa !23
  store i32 %t130, ptr %l84, !tbaa !23
  %t131 = load ptr, ptr %l83, !tbaa !29
  %t132 = load i32, ptr %l84, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t133, ptr %l85
  br label %bb50
bb50:
  %t134 = load ptr, ptr %l82, !tbaa !29
  %t135 = load i32, ptr %l85, !tbaa !23
  %t136 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t136, ptr %l86
  br label %bb51
bb51:
  %t137 = load i1, ptr %l86, !tbaa !21
  br i1 %t137, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s6
  store i64 16, ptr %l10, !tbaa !24
  store i64 8, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l10, !tbaa !24
  store i64 %t138, ptr %l87, !tbaa !24
  %t139 = load i64, ptr %l87, !tbaa !24
  store i64 %t139, ptr %l3, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  store i64 %t140, ptr %l88, !tbaa !24
  %t141 = load i64, ptr %l88, !tbaa !24
  store i64 %t141, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s7
  store i64 8, ptr %l12, !tbaa !24
  store i64 8, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l12, !tbaa !24
  store i64 %t142, ptr %l89, !tbaa !24
  %t143 = load i64, ptr %l89, !tbaa !24
  store i64 %t143, ptr %l3, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  store i64 %t144, ptr %l90, !tbaa !24
  %t145 = load i64, ptr %l90, !tbaa !24
  store i64 %t145, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb135
bb55:
  %t146 = load i32, ptr %l5
  store i32 %t146, ptr %l91
  %t147 = load i32, ptr %l91
  %t148 = trunc i64 19 to i32
  %t149 = icmp eq i32 %t147, %t148
  store i1 %t149, ptr %l92, !tbaa !21
  %t150 = load i1, ptr %l92, !tbaa !21
  br i1 %t150, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb74
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l93, !tbaa !29
  %t152 = load i32, ptr %l1, !tbaa !23
  store i32 %t152, ptr %l94, !tbaa !23
  %t153 = load ptr, ptr %l93, !tbaa !29
  %t154 = load i32, ptr %l94, !tbaa !23
  %t155 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t153, i32 %t154)
  store i32 %t155, ptr %l95
  br label %bb59
bb59:
  %t156 = load i32, ptr %l95, !tbaa !23
  %t157 = icmp eq i32 %t156, 0
  store i1 %t157, ptr %l96, !tbaa !21
  %t158 = load i1, ptr %l96, !tbaa !21
  br i1 %t158, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  store i64 16, ptr %l14, !tbaa !24
  store i64 8, ptr %l15, !tbaa !24
  %t159 = load i64, ptr %l14, !tbaa !24
  store i64 %t159, ptr %l97, !tbaa !24
  %t160 = load i64, ptr %l97, !tbaa !24
  store i64 %t160, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l15, !tbaa !24
  store i64 %t161, ptr %l98, !tbaa !24
  %t162 = load i64, ptr %l98, !tbaa !24
  store i64 %t162, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb73
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l99, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l100, !tbaa !29
  %t165 = load i32, ptr %l1, !tbaa !23
  store i32 %t165, ptr %l101, !tbaa !23
  %t166 = load ptr, ptr %l100, !tbaa !29
  %t167 = load i32, ptr %l101, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t166, i32 %t167)
  store i32 %t168, ptr %l102
  br label %bb62
bb62:
  %t169 = load ptr, ptr %l99, !tbaa !29
  %t170 = load i32, ptr %l102, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t169, i32 %t170)
  store i32 %t171, ptr %l103
  br label %bb63
bb63:
  store ptr %l103, ptr %l104, !tbaa !29
  store i32 26, ptr %l105
  store ptr %l105, ptr %l106, !tbaa !29
  %t172 = load ptr, ptr %l104, !tbaa !29
  %t173 = load ptr, ptr %l106, !tbaa !29
  %t174 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t172, ptr %t173)
  store i1 %t174, ptr %l107
  br label %bb64
bb64:
  %t175 = load i1, ptr %l107, !tbaa !21
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l108, !tbaa !21
  %t177 = load i1, ptr %l108, !tbaa !21
  br i1 %t177, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  store i1 false, ptr %l109, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t178 = load i1, ptr %l109, !tbaa !21
  store i1 %t178, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l110, !tbaa !29
  %t180 = load i32, ptr %l1, !tbaa !23
  store i32 %t180, ptr %l111, !tbaa !23
  %t181 = load ptr, ptr %l110, !tbaa !29
  %t182 = load i32, ptr %l111, !tbaa !23
  %t183 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t181, i32 %t182)
  store i32 %t183, ptr %l112
  br label %bb68
bb68:
  %t184 = load i32, ptr %l112, !tbaa !23
  store i32 %t184, ptr %l16, !tbaa !23
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l113, !tbaa !29
  %t186 = load i32, ptr %l16, !tbaa !23
  store i32 %t186, ptr %l114, !tbaa !23
  %t187 = load ptr, ptr %l113, !tbaa !29
  %t188 = load i32, ptr %l114, !tbaa !23
  %t189 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t187, i32 %t188)
  store i64 %t189, ptr %l115
  br label %bb69
bb69:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l116, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l117, !tbaa !29
  %t192 = load i32, ptr %l1, !tbaa !23
  store i32 %t192, ptr %l118, !tbaa !23
  %t193 = load ptr, ptr %l117, !tbaa !29
  %t194 = load i32, ptr %l118, !tbaa !23
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t193, i32 %t194)
  store i32 %t195, ptr %l119
  br label %bb70
bb70:
  %t196 = load ptr, ptr %l116, !tbaa !29
  %t197 = load i32, ptr %l119, !tbaa !23
  %t198 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t196, i32 %t197)
  store i64 %t198, ptr %l120
  br label %bb71
bb71:
  %t199 = load i64, ptr %l115, !tbaa !24
  %t200 = load i64, ptr %l120, !tbaa !24
  %t201 = mul i64 %t199, %t200
  store i64 %t201, ptr %l121, !tbaa !24
  %t202 = load i64, ptr %l121, !tbaa !24
  store i64 %t202, ptr %l17, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l122, !tbaa !29
  %t204 = load i32, ptr %l16, !tbaa !23
  store i32 %t204, ptr %l123, !tbaa !23
  %t205 = load ptr, ptr %l122, !tbaa !29
  %t206 = load i32, ptr %l123, !tbaa !23
  %t207 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t205, i32 %t206)
  store i64 %t207, ptr %l124
  br label %bb72
bb72:
  %t208 = load i64, ptr %l124, !tbaa !24
  store i64 %t208, ptr %l18, !tbaa !24
  %t209 = load i64, ptr %l17, !tbaa !24
  store i64 %t209, ptr %l125, !tbaa !24
  %t210 = load i64, ptr %l125, !tbaa !24
  store i64 %t210, ptr %l3, !tbaa !24
  %t211 = load i64, ptr %l18, !tbaa !24
  store i64 %t211, ptr %l126, !tbaa !24
  %t212 = load i64, ptr %l126, !tbaa !24
  store i64 %t212, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb135
bb74:
  %t213 = load i32, ptr %l5
  store i32 %t213, ptr %l127
  %t214 = load i32, ptr %l127
  %t215 = trunc i64 22 to i32
  %t216 = icmp eq i32 %t214, %t215
  store i1 %t216, ptr %l128, !tbaa !21
  %t217 = load i1, ptr %l128, !tbaa !21
  br i1 %t217, label %bb75, label %bb76
bb75:
  br label %bb79
bb76:
  %t218 = load i32, ptr %l5
  store i32 %t218, ptr %l129
  %t219 = load i32, ptr %l129
  %t220 = trunc i64 23 to i32
  %t221 = icmp eq i32 %t219, %t220
  store i1 %t221, ptr %l130, !tbaa !21
  %t222 = load i1, ptr %l130, !tbaa !21
  br i1 %t222, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb82
bb79:
  store %olang.scope zeroinitializer, ptr %s12
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l131, !tbaa !29
  %t224 = load i32, ptr %l1, !tbaa !23
  store i32 %t224, ptr %l132, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l133, !tbaa !29
  %t226 = load i32, ptr %l1, !tbaa !23
  store i32 %t226, ptr %l134, !tbaa !23
  %t227 = load ptr, ptr %l133, !tbaa !29
  %t228 = load i32, ptr %l134, !tbaa !23
  %t229 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t227, i32 %t228)
  store i32 %t229, ptr %l135
  br label %bb80
bb80:
  %t230 = load ptr, ptr %l131, !tbaa !29
  %t231 = load i32, ptr %l132, !tbaa !23
  %t232 = load i32, ptr %l135, !tbaa !23
  %t233 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t230, i32 %t231, i32 %t232)
  store { i64, i64 } %t233, ptr %l136
  br label %bb81
bb81:
  %t234 = load { i64, i64 }, ptr %l136
  store { i64, i64 } %t234, ptr %l19
  %t235 = getelementptr { i64, i64 }, ptr %l19, i32 0, i32 0
  %t236 = load i64, ptr %t235, !tbaa !24
  store i64 %t236, ptr %l137, !tbaa !24
  %t237 = load i64, ptr %l137, !tbaa !24
  store i64 %t237, ptr %l3, !tbaa !24
  %t238 = getelementptr { i64, i64 }, ptr %l19, i32 0, i32 1
  %t239 = load i64, ptr %t238, !tbaa !24
  store i64 %t239, ptr %l138, !tbaa !24
  %t240 = load i64, ptr %l138, !tbaa !24
  store i64 %t240, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb135
bb82:
  %t241 = load i32, ptr %l5
  store i32 %t241, ptr %l139
  %t242 = load i32, ptr %l139
  %t243 = trunc i64 24 to i32
  %t244 = icmp eq i32 %t242, %t243
  store i1 %t244, ptr %l140, !tbaa !21
  %t245 = load i1, ptr %l140, !tbaa !21
  br i1 %t245, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb88
bb85:
  store %olang.scope zeroinitializer, ptr %s13
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l141, !tbaa !29
  %t247 = load i32, ptr %l1, !tbaa !23
  store i32 %t247, ptr %l142, !tbaa !23
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l143, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  store i32 %t249, ptr %l144, !tbaa !23
  %t250 = load ptr, ptr %l143, !tbaa !29
  %t251 = load i32, ptr %l144, !tbaa !23
  %t252 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t252, ptr %l145
  br label %bb86
bb86:
  %t253 = load ptr, ptr %l141, !tbaa !29
  %t254 = load i32, ptr %l142, !tbaa !23
  %t255 = load i32, ptr %l145, !tbaa !23
  %t256 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t253, i32 %t254, i32 %t255)
  store { i64, i64 } %t256, ptr %l146
  br label %bb87
bb87:
  %t257 = load { i64, i64 }, ptr %l146
  store { i64, i64 } %t257, ptr %l20
  %t258 = getelementptr { i64, i64 }, ptr %l20, i32 0, i32 0
  %t259 = load i64, ptr %t258, !tbaa !24
  store i64 %t259, ptr %l147, !tbaa !24
  %t260 = load i64, ptr %l147, !tbaa !24
  store i64 %t260, ptr %l3, !tbaa !24
  %t261 = getelementptr { i64, i64 }, ptr %l20, i32 0, i32 1
  %t262 = load i64, ptr %t261, !tbaa !24
  store i64 %t262, ptr %l148, !tbaa !24
  %t263 = load i64, ptr %l148, !tbaa !24
  store i64 %t263, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb135
bb88:
  %t264 = load i32, ptr %l5
  store i32 %t264, ptr %l149
  %t265 = load i32, ptr %l149
  %t266 = trunc i64 18 to i32
  %t267 = icmp eq i32 %t265, %t266
  store i1 %t267, ptr %l150, !tbaa !21
  %t268 = load i1, ptr %l150, !tbaa !21
  br i1 %t268, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb130
bb91:
  store %olang.scope zeroinitializer, ptr %s14
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l151, !tbaa !29
  %t270 = load i32, ptr %l1, !tbaa !23
  store i32 %t270, ptr %l152, !tbaa !23
  %t271 = load ptr, ptr %l151, !tbaa !29
  %t272 = load i32, ptr %l152, !tbaa !23
  %t273 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t271, i32 %t272)
  store i1 %t273, ptr %l153
  br label %bb92
bb92:
  %t274 = load i1, ptr %l153, !tbaa !21
  %t275 = xor i1 %t274, true
  store i1 %t275, ptr %l154, !tbaa !21
  %t276 = load i1, ptr %l154, !tbaa !21
  br i1 %t276, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s15
  store i1 false, ptr %l155, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t277 = load i1, ptr %l155, !tbaa !21
  store i1 %t277, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l156, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l157, !tbaa !29
  %t280 = load i32, ptr %l1, !tbaa !23
  store i32 %t280, ptr %l158, !tbaa !23
  %t281 = load ptr, ptr %l157, !tbaa !29
  %t282 = load i32, ptr %l158, !tbaa !23
  %t283 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t281, i32 %t282)
  store i32 %t283, ptr %l159
  br label %bb96
bb96:
  %t284 = load ptr, ptr %l156, !tbaa !29
  %t285 = load i32, ptr %l159, !tbaa !23
  %t286 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t284, i32 %t285)
  store i32 %t286, ptr %l160
  br label %bb97
bb97:
  %t287 = load i32, ptr %l160
  store i32 %t287, ptr %l21
  %t288 = load i32, ptr %l21
  store i32 %t288, ptr %l161
  %t289 = load i32, ptr %l161
  %t290 = trunc i64 0 to i32
  %t291 = icmp eq i32 %t289, %t290
  store i1 %t291, ptr %l162, !tbaa !21
  %t292 = load i1, ptr %l162, !tbaa !21
  br i1 %t292, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb103
bb100:
  store %olang.scope zeroinitializer, ptr %s16
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l163, !tbaa !29
  %t294 = load i32, ptr %l1, !tbaa !23
  store i32 %t294, ptr %l164, !tbaa !23
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l165, !tbaa !29
  %t296 = load i32, ptr %l1, !tbaa !23
  store i32 %t296, ptr %l166, !tbaa !23
  %t297 = load ptr, ptr %l165, !tbaa !29
  %t298 = load i32, ptr %l166, !tbaa !23
  %t299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t297, i32 %t298)
  store i32 %t299, ptr %l167
  br label %bb101
bb101:
  %t300 = load ptr, ptr %l163, !tbaa !29
  %t301 = load i32, ptr %l164, !tbaa !23
  %t302 = load i32, ptr %l167, !tbaa !23
  %t303 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t300, i32 %t301, i32 %t302)
  store { i64, i64 } %t303, ptr %l168
  br label %bb102
bb102:
  %t304 = load { i64, i64 }, ptr %l168
  store { i64, i64 } %t304, ptr %l22
  %t305 = getelementptr { i64, i64 }, ptr %l22, i32 0, i32 0
  %t306 = load i64, ptr %t305, !tbaa !24
  store i64 %t306, ptr %l169, !tbaa !24
  %t307 = load i64, ptr %l169, !tbaa !24
  store i64 %t307, ptr %l3, !tbaa !24
  %t308 = getelementptr { i64, i64 }, ptr %l22, i32 0, i32 1
  %t309 = load i64, ptr %t308, !tbaa !24
  store i64 %t309, ptr %l170, !tbaa !24
  %t310 = load i64, ptr %l170, !tbaa !24
  store i64 %t310, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb129
bb103:
  %t311 = load i32, ptr %l21
  store i32 %t311, ptr %l171
  %t312 = load i32, ptr %l171
  %t313 = trunc i64 1 to i32
  %t314 = icmp eq i32 %t312, %t313
  store i1 %t314, ptr %l172, !tbaa !21
  %t315 = load i1, ptr %l172, !tbaa !21
  br i1 %t315, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb109
bb106:
  store %olang.scope zeroinitializer, ptr %s17
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l173, !tbaa !29
  %t317 = load i32, ptr %l1, !tbaa !23
  store i32 %t317, ptr %l174, !tbaa !23
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l175, !tbaa !29
  %t319 = load i32, ptr %l1, !tbaa !23
  store i32 %t319, ptr %l176, !tbaa !23
  %t320 = load ptr, ptr %l175, !tbaa !29
  %t321 = load i32, ptr %l176, !tbaa !23
  %t322 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t322, ptr %l177
  br label %bb107
bb107:
  %t323 = load ptr, ptr %l173, !tbaa !29
  %t324 = load i32, ptr %l174, !tbaa !23
  %t325 = load i32, ptr %l177, !tbaa !23
  %t326 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t323, i32 %t324, i32 %t325)
  store { i64, i64 } %t326, ptr %l178
  br label %bb108
bb108:
  %t327 = load { i64, i64 }, ptr %l178
  store { i64, i64 } %t327, ptr %l23
  %t328 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 0
  %t329 = load i64, ptr %t328, !tbaa !24
  store i64 %t329, ptr %l179, !tbaa !24
  %t330 = load i64, ptr %l179, !tbaa !24
  store i64 %t330, ptr %l3, !tbaa !24
  %t331 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 1
  %t332 = load i64, ptr %t331, !tbaa !24
  store i64 %t332, ptr %l180, !tbaa !24
  %t333 = load i64, ptr %l180, !tbaa !24
  store i64 %t333, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb129
bb109:
  %t334 = load i32, ptr %l21
  store i32 %t334, ptr %l181
  %t335 = load i32, ptr %l181
  %t336 = trunc i64 2 to i32
  %t337 = icmp eq i32 %t335, %t336
  store i1 %t337, ptr %l182, !tbaa !21
  %t338 = load i1, ptr %l182, !tbaa !21
  br i1 %t338, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s18
  store i64 4, ptr %l24, !tbaa !24
  store i64 4, ptr %l25, !tbaa !24
  %t339 = load i64, ptr %l24, !tbaa !24
  store i64 %t339, ptr %l183, !tbaa !24
  %t340 = load i64, ptr %l183, !tbaa !24
  store i64 %t340, ptr %l3, !tbaa !24
  %t341 = load i64, ptr %l25, !tbaa !24
  store i64 %t341, ptr %l184, !tbaa !24
  %t342 = load i64, ptr %l184, !tbaa !24
  store i64 %t342, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb129
bb113:
  %t343 = load i32, ptr %l21
  store i32 %t343, ptr %l185
  %t344 = load i32, ptr %l185
  %t345 = trunc i64 4 to i32
  %t346 = icmp eq i32 %t344, %t345
  store i1 %t346, ptr %l186, !tbaa !21
  %t347 = load i1, ptr %l186, !tbaa !21
  br i1 %t347, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb124
bb116:
  store %olang.scope zeroinitializer, ptr %s19
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l187, !tbaa !29
  %t349 = load i32, ptr %l1, !tbaa !23
  store i32 %t349, ptr %l188, !tbaa !23
  %t350 = load ptr, ptr %l187, !tbaa !29
  %t351 = load i32, ptr %l188, !tbaa !23
  %t352 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t350, i32 %t351)
  store i32 %t352, ptr %l189
  br label %bb117
bb117:
  %t353 = load i32, ptr %l189, !tbaa !23
  store i32 %t353, ptr %l26, !tbaa !23
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l190, !tbaa !29
  %t355 = load i32, ptr %l26, !tbaa !23
  store i32 %t355, ptr %l191, !tbaa !23
  %t356 = load ptr, ptr %l190, !tbaa !29
  %t357 = load i32, ptr %l191, !tbaa !23
  %t358 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t356, i32 %t357)
  store i64 %t358, ptr %l192
  br label %bb118
bb118:
  %t359 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  store i64 %t359, ptr %l193, !tbaa !24
  %t360 = load i64, ptr %l192, !tbaa !24
  %t361 = load i64, ptr %l193, !tbaa !24
  %t362 = icmp ne i64 %t360, %t361
  store i1 %t362, ptr %l194, !tbaa !21
  %t363 = load i1, ptr %l194, !tbaa !21
  br i1 %t363, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s20
  store i1 false, ptr %l195, !tbaa !21
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t364 = load i1, ptr %l195, !tbaa !21
  store i1 %t364, ptr %rv
  br label %ret
bb120:
  br label %bb121
bb121:
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l196, !tbaa !29
  %t366 = load i32, ptr %l26, !tbaa !23
  store i32 %t366, ptr %l197, !tbaa !23
  %t367 = load ptr, ptr %l196, !tbaa !29
  %t368 = load i32, ptr %l197, !tbaa !23
  %t369 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t367, i32 %t368)
  store i64 %t369, ptr %l198
  br label %bb122
bb122:
  %t370 = load i64, ptr %l198, !tbaa !24
  store i64 %t370, ptr %l27, !tbaa !24
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l199, !tbaa !29
  %t372 = load i32, ptr %l26, !tbaa !23
  store i32 %t372, ptr %l200, !tbaa !23
  %t373 = load ptr, ptr %l199, !tbaa !29
  %t374 = load i32, ptr %l200, !tbaa !23
  %t375 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t373, i32 %t374)
  store i64 %t375, ptr %l201
  br label %bb123
bb123:
  %t376 = load i64, ptr %l201, !tbaa !24
  store i64 %t376, ptr %l28, !tbaa !24
  %t377 = load i64, ptr %l27, !tbaa !24
  store i64 %t377, ptr %l202, !tbaa !24
  %t378 = load i64, ptr %l202, !tbaa !24
  store i64 %t378, ptr %l3, !tbaa !24
  %t379 = load i64, ptr %l28, !tbaa !24
  store i64 %t379, ptr %l203, !tbaa !24
  %t380 = load i64, ptr %l203, !tbaa !24
  store i64 %t380, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb129
bb124:
  %t381 = load i32, ptr %l21
  store i32 %t381, ptr %l204
  %t382 = load i32, ptr %l204
  %t383 = trunc i64 3 to i32
  %t384 = icmp eq i32 %t382, %t383
  store i1 %t384, ptr %l205, !tbaa !21
  %t385 = load i1, ptr %l205, !tbaa !21
  br i1 %t385, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s21
  store i1 false, ptr %l206, !tbaa !21
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t386 = load i1, ptr %l206, !tbaa !21
  store i1 %t386, ptr %rv
  br label %ret
bb128:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb129:
  call void @__olang_scope_close(ptr %s14)
  br label %bb135
bb130:
  br i1 true, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s22
  store i1 false, ptr %l207, !tbaa !21
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t387 = load i1, ptr %l207, !tbaa !21
  store i1 %t387, ptr %rv
  br label %ret
bb134:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb135:
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l208, !tbaa !29
  %t389 = load ptr, ptr %l208, !tbaa !29
  %t390 = getelementptr %"compiler/types:Table", ptr %t389, i32 0, i32 17
  store ptr %t390, ptr %l209, !tbaa !29
  %t391 = load i32, ptr %l1, !tbaa !23
  store i32 %t391, ptr %l210, !tbaa !23
  %t392 = load i32, ptr %l210, !tbaa !23
  %t393 = sext i32 %t392 to i64
  store i64 %t393, ptr %l211, !tbaa !24
  %t394 = load i64, ptr %l3, !tbaa !24
  store i64 %t394, ptr %l212, !tbaa !24
  %t395 = load ptr, ptr %l209, !tbaa !29
  %t396 = load i64, ptr %l211, !tbaa !24
  %t397 = load i64, ptr %l212, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t395, i64 %t396, i64 %t397)
  br label %bb136
bb136:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l213, !tbaa !29
  %t399 = load ptr, ptr %l213, !tbaa !29
  %t400 = getelementptr %"compiler/types:Table", ptr %t399, i32 0, i32 18
  store ptr %t400, ptr %l214, !tbaa !29
  %t401 = load i32, ptr %l1, !tbaa !23
  store i32 %t401, ptr %l215, !tbaa !23
  %t402 = load i32, ptr %l215, !tbaa !23
  %t403 = sext i32 %t402 to i64
  store i64 %t403, ptr %l216, !tbaa !24
  %t404 = load i64, ptr %l4, !tbaa !24
  store i64 %t404, ptr %l217, !tbaa !24
  %t405 = load ptr, ptr %l214, !tbaa !29
  %t406 = load i64, ptr %l216, !tbaa !24
  %t407 = load i64, ptr %l217, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t405, i64 %t406, i64 %t407)
  br label %bb137
bb137:
  store i1 true, ptr %l218, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t408 = load i1, ptr %l218, !tbaa !21
  store i1 %t408, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/types:data"
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i32 26, ptr %l4
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load i32, ptr %l5, !tbaa !23
  %t4 = sext i32 %t3 to i64
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load i32, ptr %l4
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t6, i64 %t7, i64 %t8, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l8
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t10, %"compiler/types:data" %t11, i32 1)
  store i32 %t12, ptr %l9
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca %"compiler/types:data"
  %l30 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 10
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %t6)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = icmp slt i64 %t15, 0
  store i1 %t16, ptr %l10, !tbaa !21
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l11, !tbaa !29
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = getelementptr %"compiler/types:Table", ptr %t19, i32 0, i32 9
  store ptr %t20, ptr %l12, !tbaa !29
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t21)
  store i64 %t22, ptr %l13
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t23 = load i64, ptr %l13, !tbaa !24
  store i64 %t23, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/types:Table", ptr %t25, i32 0, i32 9
  store ptr %t26, ptr %l15, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  call void @__olang_sb_put(ptr %s2, ptr %t29, i64 %t30)
  %t31 = load ptr, ptr %s2
  %t32 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t33 = load i64, ptr %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t31, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l17, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l18, !tbaa !27
  %t44 = load ptr, ptr %l15, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t44, { i64, ptr } %t45)
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l19, !tbaa !29
  %t47 = load ptr, ptr %l19, !tbaa !29
  %t48 = getelementptr %"compiler/types:Table", ptr %t47, i32 0, i32 10
  store ptr %t48, ptr %l20, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l21, !tbaa !29
  %t50 = load ptr, ptr %l21, !tbaa !29
  %t51 = getelementptr %"compiler/types:Table", ptr %t50, i32 0, i32 9
  store ptr %t51, ptr %l22, !tbaa !29
  %t52 = load i64, ptr %l2, !tbaa !24
  store i64 %t52, ptr %l23, !tbaa !24
  %t53 = load ptr, ptr %l22, !tbaa !29
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store { i64, ptr } %t55, ptr %l24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l2, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  %t57 = load ptr, ptr %l20, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t59 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t57, { i64, ptr } %t58, i64 %t59)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l26, !tbaa !29
  store i32 27, ptr %l27
  %t61 = load i64, ptr %l2, !tbaa !24
  store i64 %t61, ptr %l28, !tbaa !24
  %t62 = load i32, ptr %l27
  %t63 = load i64, ptr %l28, !tbaa !24
  %t64 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t62, i64 %t63, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t64, ptr %l29
  br label %bb12
bb12:
  %t65 = load ptr, ptr %l26, !tbaa !29
  %t66 = load %"compiler/types:data", ptr %l29
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t65, %"compiler/types:data" %t66, i32 1)
  store i32 %t67, ptr %l30
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i32, ptr %l30, !tbaa !23
  store i32 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/types:decl"
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t7, i64 %t8)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 2
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l7
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i32, ptr %l7
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/types:decl"
  %l7 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t7, i64 %t8)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/types:decl"
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t7, i64 %t8)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i32, ptr %l7, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/types:decl"
  %l7 = alloca i32
  %l8 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t7, i64 %t8)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 3
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l7, !tbaa !23
  %t12 = load i32, ptr %l7, !tbaa !23
  %t13 = sext i32 %t12 to i64
  store i64 %t13, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i64, ptr %l8, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDepth(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = sext i32 %t6 to i64
  store i64 %t7, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:body"
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 3
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/list:List<compiler/types:TypeId>"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca %"std/prelude/list:List<compiler/types:TypeId>"
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i32
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i32
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca i32
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca i32
  %l108 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i32
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca i32
  %l128 = alloca i32
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i32
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/types:TypeId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List<compiler/types:TypeId>" %t2, ptr %l21
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<compiler/types:TypeId>", ptr %l21
  store %"std/prelude/list:List<compiler/types:TypeId>" %t3, ptr %l2
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l22, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l23, !tbaa !23
  %t6 = load ptr, ptr %l22, !tbaa !29
  %t7 = load i32, ptr %l23, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l24
  br label %bb2
bb2:
  %t9 = load i32, ptr %l24
  store i32 %t9, ptr %l3
  %t10 = load i32, ptr %l3
  store i32 %t10, ptr %l25
  %t11 = load i32, ptr %l25
  %t12 = trunc i64 18 to i32
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %l26, !tbaa !21
  %t14 = load i1, ptr %l26, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb44
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l27, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l28, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  store i32 %t17, ptr %l29, !tbaa !23
  %t18 = load ptr, ptr %l28, !tbaa !29
  %t19 = load i32, ptr %l29, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t20, ptr %l30
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l27, !tbaa !29
  %t22 = load i32, ptr %l30, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l31
  br label %bb7
bb7:
  %t24 = load i32, ptr %l31
  store i32 %t24, ptr %l4
  %t25 = load i32, ptr %l4
  store i32 %t25, ptr %l32
  %t26 = load i32, ptr %l32
  %t27 = trunc i64 0 to i32
  %t28 = icmp eq i32 %t26, %t27
  store i1 %t28, ptr %l33, !tbaa !21
  %t29 = load i1, ptr %l33, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l34, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l35, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  store i32 %t32, ptr %l36, !tbaa !23
  %t33 = load ptr, ptr %l35, !tbaa !29
  %t34 = load i32, ptr %l36, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l37
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l34, !tbaa !29
  %t37 = load i32, ptr %l37, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t38, ptr %l38
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t39, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l39, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l40, !tbaa !24
  %t43 = load i64, ptr %l40, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l41, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  store i64 %t45, ptr %l42, !tbaa !24
  %t46 = load i64, ptr %l41, !tbaa !24
  %t47 = load i64, ptr %l42, !tbaa !24
  %t48 = icmp slt i64 %t46, %t47
  store i1 %t48, ptr %l43, !tbaa !21
  %t49 = load i1, ptr %l43, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l44, !tbaa !21
  %t51 = load i1, ptr %l44, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t52, ptr %l45, !tbaa !27
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l46, !tbaa !24
  %t54 = load i64, ptr %l46, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 %t54
  %t58 = load i32, ptr %t57, !tbaa !33
  store i32 %t58, ptr %l47, !tbaa !23
  %t59 = load i32, ptr %l47, !tbaa !23
  store i32 %t59, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l48, !tbaa !29
  %t60 = load i32, ptr %l8, !tbaa !23
  store i32 %t60, ptr %l49, !tbaa !23
  %t61 = load ptr, ptr %l48, !tbaa !29
  %t62 = load i32, ptr %l49, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t61, i32 %t62)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t63 = load i64, ptr %l6, !tbaa !24
  store i64 %t63, ptr %l50, !tbaa !24
  %t64 = load i64, ptr %l50, !tbaa !24
  %t65 = add i64 %t64, 1
  store i64 %t65, ptr %l51, !tbaa !24
  %t66 = load i64, ptr %l51, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb13
bb19:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb20:
  %t67 = load i32, ptr %l4
  store i32 %t67, ptr %l52
  %t68 = load i32, ptr %l52
  %t69 = trunc i64 1 to i32
  %t70 = icmp eq i32 %t68, %t69
  store i1 %t70, ptr %l53, !tbaa !21
  %t71 = load i1, ptr %l53, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb36
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  store %olang.scope zeroinitializer, ptr %s7
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l54, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l55, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  store i32 %t74, ptr %l56, !tbaa !23
  %t75 = load ptr, ptr %l55, !tbaa !29
  %t76 = load i32, ptr %l56, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l57
  br label %bb24
bb24:
  %t78 = load ptr, ptr %l54, !tbaa !29
  %t79 = load i32, ptr %l57, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l58
  br label %bb25
bb25:
  %t81 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t81, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t82, ptr %l59, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l60, !tbaa !24
  %t85 = load i64, ptr %l60, !tbaa !24
  store i64 %t85, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t86 = load i64, ptr %l10, !tbaa !24
  store i64 %t86, ptr %l61, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  store i64 %t87, ptr %l62, !tbaa !24
  %t88 = load i64, ptr %l61, !tbaa !24
  %t89 = load i64, ptr %l62, !tbaa !24
  %t90 = icmp slt i64 %t88, %t89
  store i1 %t90, ptr %l63, !tbaa !21
  %t91 = load i1, ptr %l63, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l64, !tbaa !21
  %t93 = load i1, ptr %l64, !tbaa !21
  br i1 %t93, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t94, ptr %l65, !tbaa !27
  %t95 = load i64, ptr %l10, !tbaa !24
  store i64 %t95, ptr %l66, !tbaa !24
  %t96 = load i64, ptr %l66, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t96
  %t100 = load i32, ptr %t99, !tbaa !33
  store i32 %t100, ptr %l67, !tbaa !23
  %t101 = load i32, ptr %l67, !tbaa !23
  store i32 %t101, ptr %l12, !tbaa !23
  %t102 = load i32, ptr %l12, !tbaa !23
  store i32 %t102, ptr %l68, !tbaa !23
  %t103 = load i32, ptr %l68, !tbaa !23
  %t104 = icmp ne i32 %t103, 0
  store i1 %t104, ptr %l69, !tbaa !21
  %t105 = load i1, ptr %l69, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l2, ptr %l70, !tbaa !29
  %t106 = load i32, ptr %l12, !tbaa !23
  store i32 %t106, ptr %l71, !tbaa !23
  %t107 = load ptr, ptr %l70, !tbaa !29
  %t108 = load i32, ptr %l71, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t107, i32 %t108)
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  %t109 = load i64, ptr %l10, !tbaa !24
  store i64 %t109, ptr %l72, !tbaa !24
  %t110 = load i64, ptr %l72, !tbaa !24
  %t111 = add i64 %t110, 1
  store i64 %t111, ptr %l73, !tbaa !24
  %t112 = load i64, ptr %l73, !tbaa !24
  store i64 %t112, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb26
bb35:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb36:
  %t113 = load i32, ptr %l4
  store i32 %t113, ptr %l74
  %t114 = load i32, ptr %l74
  %t115 = trunc i64 4 to i32
  %t116 = icmp eq i32 %t114, %t115
  store i1 %t116, ptr %l75, !tbaa !21
  %t117 = load i1, ptr %l75, !tbaa !21
  br i1 %t117, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb42
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l2, ptr %l76, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l77, !tbaa !29
  %t119 = load i32, ptr %l1, !tbaa !23
  store i32 %t119, ptr %l78, !tbaa !23
  %t120 = load ptr, ptr %l77, !tbaa !29
  %t121 = load i32, ptr %l78, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t122, ptr %l79
  br label %bb40
bb40:
  %t123 = load ptr, ptr %l76, !tbaa !29
  %t124 = load i32, ptr %l79, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t123, i32 %t124)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s12
  call void @__olang_scope_close(ptr %s12)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s1)
  br label %bb86
bb44:
  %t125 = load i32, ptr %l3
  store i32 %t125, ptr %l80
  %t126 = load i32, ptr %l80
  %t127 = trunc i64 19 to i32
  %t128 = icmp eq i32 %t126, %t127
  store i1 %t128, ptr %l81, !tbaa !21
  %t129 = load i1, ptr %l81, !tbaa !21
  br i1 %t129, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb54
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l82, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  store i32 %t131, ptr %l83, !tbaa !23
  %t132 = load ptr, ptr %l82, !tbaa !29
  %t133 = load i32, ptr %l83, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t134, ptr %l84
  br label %bb48
bb48:
  %t135 = load i32, ptr %l84, !tbaa !23
  %t136 = icmp ne i32 %t135, 0
  store i1 %t136, ptr %l85, !tbaa !21
  %t137 = load i1, ptr %l85, !tbaa !21
  br i1 %t137, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s14
  store ptr %l2, ptr %l86, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l87, !tbaa !29
  %t139 = load i32, ptr %l1, !tbaa !23
  store i32 %t139, ptr %l88, !tbaa !23
  %t140 = load ptr, ptr %l87, !tbaa !29
  %t141 = load i32, ptr %l88, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t142, ptr %l89
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t143 = load ptr, ptr %l86, !tbaa !29
  %t144 = load i32, ptr %l89, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t143, i32 %t144)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s14)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s13)
  br label %bb86
bb54:
  %t145 = load i32, ptr %l3
  store i32 %t145, ptr %l90
  %t146 = load i32, ptr %l90
  %t147 = trunc i64 22 to i32
  %t148 = icmp eq i32 %t146, %t147
  store i1 %t148, ptr %l91, !tbaa !21
  %t149 = load i1, ptr %l91, !tbaa !21
  br i1 %t149, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  %t150 = load i32, ptr %l3
  store i32 %t150, ptr %l92
  %t151 = load i32, ptr %l92
  %t152 = trunc i64 23 to i32
  %t153 = icmp eq i32 %t151, %t152
  store i1 %t153, ptr %l93, !tbaa !21
  %t154 = load i1, ptr %l93, !tbaa !21
  br i1 %t154, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb69
bb59:
  store %olang.scope zeroinitializer, ptr %s15
  store %olang.scope zeroinitializer, ptr %s16
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l94, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l95, !tbaa !29
  %t157 = load i32, ptr %l1, !tbaa !23
  store i32 %t157, ptr %l96, !tbaa !23
  %t158 = load ptr, ptr %l95, !tbaa !29
  %t159 = load i32, ptr %l96, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t160, ptr %l97
  br label %bb60
bb60:
  %t161 = load ptr, ptr %l94, !tbaa !29
  %t162 = load i32, ptr %l97, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t161, i32 %t162)
  store { i64, ptr } %t163, ptr %l98
  br label %bb61
bb61:
  %t164 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t164, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t165, ptr %l99, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 0
  store i64 %t167, ptr %l100, !tbaa !24
  %t168 = load i64, ptr %l100, !tbaa !24
  store i64 %t168, ptr %l15, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s17
  %t169 = load i64, ptr %l14, !tbaa !24
  store i64 %t169, ptr %l101, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  store i64 %t170, ptr %l102, !tbaa !24
  %t171 = load i64, ptr %l101, !tbaa !24
  %t172 = load i64, ptr %l102, !tbaa !24
  %t173 = icmp slt i64 %t171, %t172
  store i1 %t173, ptr %l103, !tbaa !21
  %t174 = load i1, ptr %l103, !tbaa !21
  %t175 = xor i1 %t174, true
  store i1 %t175, ptr %l104, !tbaa !21
  %t176 = load i1, ptr %l104, !tbaa !21
  br i1 %t176, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s17)
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t177, ptr %l105, !tbaa !27
  %t178 = load i64, ptr %l14, !tbaa !24
  store i64 %t178, ptr %l106, !tbaa !24
  %t179 = load i64, ptr %l106, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 %t179
  %t183 = load i32, ptr %t182, !tbaa !33
  store i32 %t183, ptr %l107, !tbaa !23
  %t184 = load i32, ptr %l107, !tbaa !23
  store i32 %t184, ptr %l16, !tbaa !23
  store ptr %l2, ptr %l108, !tbaa !29
  %t185 = load i32, ptr %l16, !tbaa !23
  store i32 %t185, ptr %l109, !tbaa !23
  %t186 = load ptr, ptr %l108, !tbaa !29
  %t187 = load i32, ptr %l109, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t186, i32 %t187)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s17)
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s18
  %t188 = load i64, ptr %l14, !tbaa !24
  store i64 %t188, ptr %l110, !tbaa !24
  %t189 = load i64, ptr %l110, !tbaa !24
  %t190 = add i64 %t189, 1
  store i64 %t190, ptr %l111, !tbaa !24
  %t191 = load i64, ptr %l111, !tbaa !24
  store i64 %t191, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb62
bb68:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb69:
  %t192 = load i32, ptr %l3
  store i32 %t192, ptr %l112
  %t193 = load i32, ptr %l112
  %t194 = trunc i64 24 to i32
  %t195 = icmp eq i32 %t193, %t194
  store i1 %t195, ptr %l113, !tbaa !21
  %t196 = load i1, ptr %l113, !tbaa !21
  br i1 %t196, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb85
bb72:
  store %olang.scope zeroinitializer, ptr %s19
  store %olang.scope zeroinitializer, ptr %s20
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l114, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l115, !tbaa !29
  %t199 = load i32, ptr %l1, !tbaa !23
  store i32 %t199, ptr %l116, !tbaa !23
  %t200 = load ptr, ptr %l115, !tbaa !29
  %t201 = load i32, ptr %l116, !tbaa !23
  %t202 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t202, ptr %l117
  br label %bb73
bb73:
  %t203 = load ptr, ptr %l114, !tbaa !29
  %t204 = load i32, ptr %l117, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t203, i32 %t204)
  store { i64, ptr } %t205, ptr %l118
  br label %bb74
bb74:
  %t206 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t206, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t207, ptr %l119, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l120, !tbaa !24
  %t210 = load i64, ptr %l120, !tbaa !24
  store i64 %t210, ptr %l19, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s21
  %t211 = load i64, ptr %l18, !tbaa !24
  store i64 %t211, ptr %l121, !tbaa !24
  %t212 = load i64, ptr %l19, !tbaa !24
  store i64 %t212, ptr %l122, !tbaa !24
  %t213 = load i64, ptr %l121, !tbaa !24
  %t214 = load i64, ptr %l122, !tbaa !24
  %t215 = icmp slt i64 %t213, %t214
  store i1 %t215, ptr %l123, !tbaa !21
  %t216 = load i1, ptr %l123, !tbaa !21
  %t217 = xor i1 %t216, true
  store i1 %t217, ptr %l124, !tbaa !21
  %t218 = load i1, ptr %l124, !tbaa !21
  br i1 %t218, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s21)
  br label %bb84
bb77:
  br label %bb78
bb78:
  %t219 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t219, ptr %l125, !tbaa !27
  %t220 = load i64, ptr %l18, !tbaa !24
  store i64 %t220, ptr %l126, !tbaa !24
  %t221 = load i64, ptr %l126, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i32, ptr %t223, i64 %t221
  %t225 = load i32, ptr %t224, !tbaa !33
  store i32 %t225, ptr %l127, !tbaa !23
  %t226 = load i32, ptr %l127, !tbaa !23
  store i32 %t226, ptr %l20, !tbaa !23
  %t227 = load i32, ptr %l20, !tbaa !23
  store i32 %t227, ptr %l128, !tbaa !23
  %t228 = load i32, ptr %l128, !tbaa !23
  %t229 = icmp ne i32 %t228, 0
  store i1 %t229, ptr %l129, !tbaa !21
  %t230 = load i1, ptr %l129, !tbaa !21
  br i1 %t230, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s22
  store ptr %l2, ptr %l130, !tbaa !29
  %t231 = load i32, ptr %l20, !tbaa !23
  store i32 %t231, ptr %l131, !tbaa !23
  %t232 = load ptr, ptr %l130, !tbaa !29
  %t233 = load i32, ptr %l131, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t232, i32 %t233)
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s22)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s21)
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s23
  %t234 = load i64, ptr %l18, !tbaa !24
  store i64 %t234, ptr %l132, !tbaa !24
  %t235 = load i64, ptr %l132, !tbaa !24
  %t236 = add i64 %t235, 1
  store i64 %t236, ptr %l133, !tbaa !24
  %t237 = load i64, ptr %l133, !tbaa !24
  store i64 %t237, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb75
bb84:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s24
  call void @__olang_scope_close(ptr %s24)
  br label %bb86
bb86:
  store ptr %l2, ptr %l134, !tbaa !29
  %t238 = load ptr, ptr %l134, !tbaa !29
  %t239 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s0, ptr %v1, ptr %t238)
  store { i64, ptr } %t239, ptr %l135
  br label %bb87
bb87:
  %t240 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t240, ptr %l136, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l137, !tbaa !24
  %t243 = load i64, ptr %l137, !tbaa !24
  %t244 = mul i64 %t243, 4
  %t245 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l138, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l137, !tbaa !24
  %t253 = mul i64 %t252, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t254, ptr %l136, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t255 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t255, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store ptr %l4, ptr %l5, !tbaa !29
  store i32 28, ptr %l6
  store ptr %l6, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t6, ptr %t7)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  store i32 %t11, ptr %l11, !tbaa !23
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t12, i32 %t13)
  store i64 %t14, ptr %l12
  br label %bb5
bb4:
  %t15 = sub i64 0, 1
  store i64 %t15, ptr %l14, !tbaa !65
  %t16 = load i64, ptr %l14, !tbaa !65
  store i64 %t16, ptr %l9, !tbaa !65
  br label %bb6
bb5:
  %t17 = load i64, ptr %l12, !tbaa !24
  store i64 %t17, ptr %l13, !tbaa !65
  %t18 = load i64, ptr %l13, !tbaa !65
  store i64 %t18, ptr %l9, !tbaa !65
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i64, ptr %l9, !tbaa !65
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store ptr %l4, ptr %l5, !tbaa !29
  store i32 28, ptr %l6
  store ptr %l6, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t6, ptr %t7)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  store i32 %t11, ptr %l11, !tbaa !23
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t12, i32 %t13)
  store i64 %t14, ptr %l12
  br label %bb5
bb4:
  %t15 = load i32, ptr %l1, !tbaa !23
  store i32 %t15, ptr %l15, !tbaa !23
  %t16 = load i32, ptr %l15, !tbaa !23
  store i32 %t16, ptr %l9, !tbaa !23
  br label %bb6
bb5:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = trunc i64 %t17 to i32
  store i32 %t18, ptr %l13, !tbaa !23
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l14, !tbaa !23
  %t20 = load i32, ptr %l14, !tbaa !23
  store i32 %t20, ptr %l9, !tbaa !23
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i32, ptr %l9, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i32 28, ptr %l4
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load i32, ptr %l5, !tbaa !23
  %t4 = sext i32 %t3 to i64
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !65
  store i64 %t5, ptr %l7, !tbaa !65
  %t6 = load i64, ptr %l7, !tbaa !65
  store i64 %t6, ptr %l8, !tbaa !24
  %t7 = load i32, ptr %l4
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t7, i64 %t8, i64 %t9, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load %"compiler/types:data", ptr %l9
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t11, %"compiler/types:data" %t12, i32 1)
  store i32 %t13, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i32, ptr %l10, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:body"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca %"compiler/types:data"
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i32
  %l62 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l11, !tbaa !23
  %t3 = load ptr, ptr %l10, !tbaa !29
  %t4 = load i32, ptr %l11, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i32, ptr %l12, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  store i32 %t8, ptr %l14, !tbaa !23
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = load i32, ptr %l14, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i32, ptr %l6, !tbaa !23
  store i32 %t12, ptr %l16, !tbaa !23
  %t13 = load i32, ptr %l15, !tbaa !23
  %t14 = load i32, ptr %l16, !tbaa !23
  %t15 = icmp sgt i32 %t13, %t14
  store i1 %t15, ptr %l17, !tbaa !21
  %t16 = load i1, ptr %l17, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l18, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  store i32 %t18, ptr %l19, !tbaa !23
  %t19 = load ptr, ptr %l18, !tbaa !29
  %t20 = load i32, ptr %l19, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t21, ptr %l20
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t22 = load i32, ptr %l20, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  store i32 21, ptr %l22
  %t24 = load i32, ptr %l1, !tbaa !23
  store i32 %t24, ptr %l23, !tbaa !23
  %t25 = load i32, ptr %l23, !tbaa !23
  %t26 = sext i32 %t25 to i64
  store i64 %t26, ptr %l24, !tbaa !24
  %t27 = load i32, ptr %l2, !tbaa !23
  store i32 %t27, ptr %l25, !tbaa !23
  %t28 = load i32, ptr %l25, !tbaa !23
  %t29 = sext i32 %t28 to i64
  store i64 %t29, ptr %l26, !tbaa !24
  %t30 = load i32, ptr %l3, !tbaa !23
  store i32 %t30, ptr %l27, !tbaa !23
  %t31 = load i32, ptr %l27, !tbaa !23
  %t32 = sext i32 %t31 to i64
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load i32, ptr %l4, !tbaa !23
  store i32 %t33, ptr %l29, !tbaa !23
  %t34 = load i32, ptr %l29, !tbaa !23
  %t35 = sext i32 %t34 to i64
  store i64 %t35, ptr %l30, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %l31, !tbaa !24
  %t37 = load i32, ptr %l22
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = load i64, ptr %l28, !tbaa !24
  %t41 = load i64, ptr %l30, !tbaa !24
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t37, i64 %t38, i64 %t39, i64 %t40, i64 %t41, i64 %t42)
  store %"compiler/types:data" %t43, ptr %l32
  br label %bb7
bb7:
  %t44 = load i32, ptr %l6, !tbaa !23
  store i32 %t44, ptr %l33, !tbaa !23
  %t45 = load i32, ptr %l33, !tbaa !23
  %t46 = add i32 %t45, 1
  store i32 %t46, ptr %l34, !tbaa !23
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load %"compiler/types:data", ptr %l32
  %t49 = load i32, ptr %l34, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t47, %"compiler/types:data" %t48, i32 %t49)
  store i32 %t50, ptr %l35
  br label %bb8
bb8:
  %t51 = load i32, ptr %l35, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l36, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  store i32 %t53, ptr %l37, !tbaa !23
  %t54 = load ptr, ptr %l36, !tbaa !29
  %t55 = load i32, ptr %l37, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t56, ptr %l38
  br label %bb9
bb9:
  %t57 = load i32, ptr %l38, !tbaa !23
  store i32 %t57, ptr %l8, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l39, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  store i32 %t59, ptr %l40, !tbaa !23
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = load i32, ptr %l40, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t62, ptr %l41
  br label %bb10
bb10:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %l9, !tbaa !23
  %t64 = load i32, ptr %l4, !tbaa !23
  store i32 %t64, ptr %l42, !tbaa !23
  %t65 = load i32, ptr %l42, !tbaa !23
  %t66 = icmp ne i32 %t65, 0
  store i1 %t66, ptr %l43, !tbaa !21
  %t67 = load i1, ptr %l43, !tbaa !21
  br i1 %t67, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb13
bb12:
  %t68 = load i64, ptr %l5, !tbaa !24
  store i64 %t68, ptr %l45, !tbaa !24
  %t69 = load i64, ptr %l45, !tbaa !24
  %t70 = icmp ne i64 %t69, 0
  store i1 %t70, ptr %l46, !tbaa !21
  %t71 = load i1, ptr %l46, !tbaa !21
  store i1 %t71, ptr %l44, !tbaa !21
  br label %bb13
bb13:
  %t72 = load i1, ptr %l44, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i32, ptr %l8, !tbaa !23
  store i32 %t73, ptr %l48, !tbaa !23
  %t74 = load i32, ptr %l1, !tbaa !23
  store i32 %t74, ptr %l49, !tbaa !23
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = load i32, ptr %l49, !tbaa !23
  %t77 = icmp ne i32 %t75, %t76
  store i1 %t77, ptr %l50, !tbaa !21
  %t78 = load i1, ptr %l50, !tbaa !21
  store i1 %t78, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb19
bb18:
  %t80 = load i32, ptr %l9, !tbaa !23
  store i32 %t80, ptr %l52, !tbaa !23
  %t81 = load i32, ptr %l2, !tbaa !23
  store i32 %t81, ptr %l53, !tbaa !23
  %t82 = load i32, ptr %l52, !tbaa !23
  %t83 = load i32, ptr %l53, !tbaa !23
  %t84 = icmp ne i32 %t82, %t83
  store i1 %t84, ptr %l54, !tbaa !21
  %t85 = load i1, ptr %l54, !tbaa !21
  store i1 %t85, ptr %l51, !tbaa !21
  br label %bb19
bb19:
  %t86 = load i1, ptr %l51, !tbaa !21
  br i1 %t86, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l55, !tbaa !29
  %t88 = load ptr, ptr %l55, !tbaa !29
  %t89 = getelementptr %"compiler/types:Table", ptr %t88, i32 0, i32 23
  store ptr %t89, ptr %l56, !tbaa !29
  %t90 = load i32, ptr %l7, !tbaa !23
  store i32 %t90, ptr %l57, !tbaa !23
  %t91 = load i32, ptr %l57, !tbaa !23
  %t92 = sext i32 %t91 to i64
  store i64 %t92, ptr %l58, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l59, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  store i32 %t94, ptr %l60, !tbaa !23
  %t95 = load i32, ptr %l9, !tbaa !23
  store i32 %t95, ptr %l61, !tbaa !23
  %t96 = load i32, ptr %l3, !tbaa !23
  store i32 %t96, ptr %l62, !tbaa !23
  %t97 = load ptr, ptr %l59, !tbaa !29
  %t98 = load i32, ptr %l60, !tbaa !23
  %t99 = load i32, ptr %l61, !tbaa !23
  %t100 = load i32, ptr %l62, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t97, i32 %t98, i32 %t99, i32 %t100, i32 0, i64 0)
  store i32 %t101, ptr %l63
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t102 = load ptr, ptr %l56, !tbaa !29
  %t103 = load i64, ptr %l58, !tbaa !24
  %t104 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t102, i64 %t103, i32 %t104)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t105 = load i32, ptr %l7, !tbaa !23
  store i32 %t105, ptr %l64, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t106 = load i32, ptr %l64, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:body"
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l7, !tbaa !23
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t4 = load i32, ptr %l7, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t3, i32 %t4)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l11, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  store i1 %t15, ptr %l13, !tbaa !21
  %t16 = load i1, ptr %l13, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l14, !tbaa !21
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l16, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t21
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l17, !tbaa !23
  %t26 = load i32, ptr %l17, !tbaa !23
  store i32 %t26, ptr %l5, !tbaa !23
  %t27 = load i32, ptr %l5, !tbaa !23
  store i32 %t27, ptr %l18, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = icmp ne i32 %t28, 0
  store i1 %t29, ptr %l19, !tbaa !21
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i1, ptr %l20, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t32 = load i64, ptr %l3, !tbaa !24
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = add i64 %t33, 1
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb2
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %l23, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i1, ptr %l23, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca ptr
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i64
  %l79 = alloca i32
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca i32
  %l96 = alloca i32
  %l97 = alloca i32
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca i1
  %l104 = alloca i32
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca i32
  %l110 = alloca i1
  %l111 = alloca i32
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca i32
  %l117 = alloca i1
  %l118 = alloca i32
  %l119 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca i32
  %l124 = alloca i1
  %l125 = alloca i32
  %l126 = alloca i1
  %l127 = alloca i32
  %l128 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca i32
  %l132 = alloca i32
  %l133 = alloca i1
  %l134 = alloca i32
  %l135 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca i32
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca i32
  %l146 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca i32
  %l150 = alloca i1
  %l151 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i1
  %l155 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l8, !tbaa !23
  %t3 = load ptr, ptr %l7, !tbaa !29
  %t4 = load i32, ptr %l8, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  store i32 %t7, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  store i32 20, ptr %l12
  store ptr %l12, ptr %l13, !tbaa !29
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t8, ptr %t9)
  store i1 %t10, ptr %l14
  br label %bb2
bb2:
  %t11 = load i1, ptr %l14, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t12 = load i32, ptr %l2
  store i32 %t12, ptr %l16
  store ptr %l16, ptr %l17, !tbaa !29
  store i32 21, ptr %l18
  store ptr %l18, ptr %l19, !tbaa !29
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t14 = load ptr, ptr %l19, !tbaa !29
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t13, ptr %t14)
  store i1 %t15, ptr %l20
  br label %bb5
bb5:
  %t16 = load i1, ptr %l20, !tbaa !21
  store i1 %t16, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l15, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb8:
  %t18 = load i32, ptr %l2
  store i32 %t18, ptr %l22
  store ptr %l22, ptr %l23, !tbaa !29
  store i32 25, ptr %l24
  store ptr %l24, ptr %l25, !tbaa !29
  %t19 = load ptr, ptr %l23, !tbaa !29
  %t20 = load ptr, ptr %l25, !tbaa !29
  %t21 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t19, ptr %t20)
  store i1 %t21, ptr %l26
  br label %bb9
bb9:
  %t22 = load i1, ptr %l26, !tbaa !21
  store i1 %t22, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l27, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l27, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t25 = load i32, ptr %l2
  store i32 %t25, ptr %l28
  store ptr %l28, ptr %l29, !tbaa !29
  store i32 18, ptr %l30
  store ptr %l30, ptr %l31, !tbaa !29
  %t26 = load ptr, ptr %l29, !tbaa !29
  %t27 = load ptr, ptr %l31, !tbaa !29
  %t28 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t26, ptr %t27)
  store i1 %t28, ptr %l32
  br label %bb14
bb14:
  %t29 = load i1, ptr %l32, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l33, !tbaa !21
  %t31 = load i1, ptr %l33, !tbaa !21
  br i1 %t31, label %bb15, label %bb16
bb15:
  %t32 = load i32, ptr %l2
  store i32 %t32, ptr %l35
  store ptr %l35, ptr %l36, !tbaa !29
  store i32 19, ptr %l37
  store ptr %l37, ptr %l38, !tbaa !29
  %t33 = load ptr, ptr %l36, !tbaa !29
  %t34 = load ptr, ptr %l38, !tbaa !29
  %t35 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t33, ptr %t34)
  store i1 %t35, ptr %l39
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i1, ptr %l39, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l40, !tbaa !21
  %t38 = load i1, ptr %l40, !tbaa !21
  store i1 %t38, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t39 = load i1, ptr %l34, !tbaa !21
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t40 = load i32, ptr %l2
  store i32 %t40, ptr %l42
  store ptr %l42, ptr %l43, !tbaa !29
  store i32 22, ptr %l44
  store ptr %l44, ptr %l45, !tbaa !29
  %t41 = load ptr, ptr %l43, !tbaa !29
  %t42 = load ptr, ptr %l45, !tbaa !29
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t41, ptr %t42)
  store i1 %t43, ptr %l46
  br label %bb21
bb20:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t44 = load i1, ptr %l46, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l47, !tbaa !21
  %t46 = load i1, ptr %l47, !tbaa !21
  store i1 %t46, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t47 = load i1, ptr %l41, !tbaa !21
  br i1 %t47, label %bb23, label %bb24
bb23:
  %t48 = load i32, ptr %l2
  store i32 %t48, ptr %l49
  store ptr %l49, ptr %l50, !tbaa !29
  store i32 23, ptr %l51
  store ptr %l51, ptr %l52, !tbaa !29
  %t49 = load ptr, ptr %l50, !tbaa !29
  %t50 = load ptr, ptr %l52, !tbaa !29
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t49, ptr %t50)
  store i1 %t51, ptr %l53
  br label %bb25
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb26
bb25:
  %t52 = load i1, ptr %l53, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l54, !tbaa !21
  %t54 = load i1, ptr %l54, !tbaa !21
  store i1 %t54, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  %t55 = load i1, ptr %l48, !tbaa !21
  br i1 %t55, label %bb27, label %bb28
bb27:
  %t56 = load i32, ptr %l2
  store i32 %t56, ptr %l56
  store ptr %l56, ptr %l57, !tbaa !29
  store i32 24, ptr %l58
  store ptr %l58, ptr %l59, !tbaa !29
  %t57 = load ptr, ptr %l57, !tbaa !29
  %t58 = load ptr, ptr %l59, !tbaa !29
  %t59 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t57, ptr %t58)
  store i1 %t59, ptr %l60
  br label %bb29
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb30
bb29:
  %t60 = load i1, ptr %l60, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l61, !tbaa !21
  %t62 = load i1, ptr %l61, !tbaa !21
  store i1 %t62, ptr %l55, !tbaa !21
  br label %bb30
bb30:
  %t63 = load i1, ptr %l55, !tbaa !21
  br i1 %t63, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 false, ptr %l62, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t64 = load i1, ptr %l62, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t65 = load i32, ptr %l2
  store i32 %t65, ptr %l63
  store ptr %l63, ptr %l64, !tbaa !29
  store i32 18, ptr %l65
  store ptr %l65, ptr %l66, !tbaa !29
  %t66 = load ptr, ptr %l64, !tbaa !29
  %t67 = load ptr, ptr %l66, !tbaa !29
  %t68 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t66, ptr %t67)
  store i1 %t68, ptr %l67
  br label %bb34
bb34:
  %t69 = load i1, ptr %l67, !tbaa !21
  br i1 %t69, label %bb35, label %bb36
bb35:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l69, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  store i32 %t71, ptr %l70, !tbaa !23
  %t72 = load ptr, ptr %l69, !tbaa !29
  %t73 = load i32, ptr %l70, !tbaa !23
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t74, ptr %l71
  br label %bb37
bb36:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb38
bb37:
  %t75 = load i1, ptr %l71, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %l72, !tbaa !21
  %t77 = load i1, ptr %l72, !tbaa !21
  store i1 %t77, ptr %l68, !tbaa !21
  br label %bb38
bb38:
  %t78 = load i1, ptr %l68, !tbaa !21
  br i1 %t78, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l73, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t79 = load i1, ptr %l73, !tbaa !21
  store i1 %t79, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l75, !tbaa !29
  %t81 = load ptr, ptr %l75, !tbaa !29
  %t82 = getelementptr %"compiler/types:Table", ptr %t81, i32 0, i32 28
  store ptr %t82, ptr %l76, !tbaa !29
  %t83 = load i32, ptr %l1, !tbaa !23
  store i32 %t83, ptr %l77, !tbaa !23
  %t84 = load ptr, ptr %l76, !tbaa !29
  %t85 = load i32, ptr %l77, !tbaa !23
  %t86 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t84, i32 %t85)
  %t87 = extractvalue { i32, i64 } %t86, 1
  %t88 = extractvalue { i32, i64 } %t86, 0
  store i32 %t88, ptr %l79
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb43, label %ok.90
ok.90:
  store i64 %t87, ptr %l78
  br label %bb42
bb42:
  %t91 = load i64, ptr %l78, !tbaa !24
  store i64 %t91, ptr %l74, !tbaa !24
  br label %bb45
bb43:
  br label %bb44
bb44:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb45
bb45:
  %t92 = load i64, ptr %l74, !tbaa !24
  store i64 %t92, ptr %l3, !tbaa !24
  %t93 = load i64, ptr %l3, !tbaa !24
  store i64 %t93, ptr %l80, !tbaa !24
  %t94 = load i64, ptr %l80, !tbaa !24
  %t95 = icmp ne i64 %t94, 0
  store i1 %t95, ptr %l81, !tbaa !21
  %t96 = load i1, ptr %l81, !tbaa !21
  br i1 %t96, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load i64, ptr %l3, !tbaa !24
  store i64 %t97, ptr %l82, !tbaa !24
  %t98 = load i64, ptr %l82, !tbaa !24
  %t99 = icmp eq i64 %t98, 3
  store i1 %t99, ptr %l83, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i1, ptr %l83, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l84, !tbaa !29
  %t102 = load ptr, ptr %l84, !tbaa !29
  %t103 = getelementptr %"compiler/types:Table", ptr %t102, i32 0, i32 28
  store ptr %t103, ptr %l85, !tbaa !29
  %t104 = load i32, ptr %l1, !tbaa !23
  store i32 %t104, ptr %l86, !tbaa !23
  %t105 = load ptr, ptr %l85, !tbaa !29
  %t106 = load i32, ptr %l86, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t105, i32 %t106, i64 1)
  br label %bb49
bb49:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l87, !tbaa !29
  %t108 = load ptr, ptr %l87, !tbaa !29
  %t109 = getelementptr %"compiler/types:Table", ptr %t108, i32 0, i32 29
  %t110 = load i1, ptr %t109, !tbaa !21
  store i1 %t110, ptr %l88, !tbaa !21
  %t111 = load i1, ptr %l88, !tbaa !21
  store i1 %t111, ptr %l4, !tbaa !21
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l89, !tbaa !29
  %t113 = load ptr, ptr %l89, !tbaa !29
  %t114 = getelementptr %"compiler/types:Table", ptr %t113, i32 0, i32 29
  store i1 false, ptr %t114, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  %t115 = load i32, ptr %l2
  store i32 %t115, ptr %l90
  %t116 = load i32, ptr %l90
  %t117 = trunc i64 18 to i32
  %t118 = icmp eq i32 %t116, %t117
  store i1 %t118, ptr %l91, !tbaa !21
  %t119 = load i1, ptr %l91, !tbaa !21
  br i1 %t119, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb74
bb52:
  store %olang.scope zeroinitializer, ptr %s5
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l92, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l93, !tbaa !29
  %t122 = load i32, ptr %l1, !tbaa !23
  store i32 %t122, ptr %l94, !tbaa !23
  %t123 = load ptr, ptr %l93, !tbaa !29
  %t124 = load i32, ptr %l94, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t125, ptr %l95
  br label %bb53
bb53:
  %t126 = load ptr, ptr %l92, !tbaa !29
  %t127 = load i32, ptr %l95, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t128, ptr %l96
  br label %bb54
bb54:
  %t129 = load i32, ptr %l96
  store i32 %t129, ptr %l6
  %t130 = load i32, ptr %l6
  store i32 %t130, ptr %l97
  %t131 = load i32, ptr %l97
  %t132 = trunc i64 0 to i32
  %t133 = icmp eq i32 %t131, %t132
  store i1 %t133, ptr %l98, !tbaa !21
  %t134 = load i1, ptr %l98, !tbaa !21
  br i1 %t134, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb60
bb57:
  store %olang.scope zeroinitializer, ptr %s6
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l99, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l100, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  store i32 %t137, ptr %l101, !tbaa !23
  %t138 = load ptr, ptr %l100, !tbaa !29
  %t139 = load i32, ptr %l101, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t140, ptr %l102
  br label %bb58
bb58:
  %t141 = load ptr, ptr %l99, !tbaa !29
  %t142 = load i32, ptr %l102, !tbaa !23
  %t143 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t143, ptr %l103
  br label %bb59
bb59:
  %t144 = load i1, ptr %l103, !tbaa !21
  store i1 %t144, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb73
bb60:
  %t145 = load i32, ptr %l6
  store i32 %t145, ptr %l104
  %t146 = load i32, ptr %l104
  %t147 = trunc i64 1 to i32
  %t148 = icmp eq i32 %t146, %t147
  store i1 %t148, ptr %l105, !tbaa !21
  %t149 = load i1, ptr %l105, !tbaa !21
  br i1 %t149, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l106, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l107, !tbaa !29
  %t152 = load i32, ptr %l1, !tbaa !23
  store i32 %t152, ptr %l108, !tbaa !23
  %t153 = load ptr, ptr %l107, !tbaa !29
  %t154 = load i32, ptr %l108, !tbaa !23
  %t155 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t153, i32 %t154)
  store i32 %t155, ptr %l109
  br label %bb64
bb64:
  %t156 = load ptr, ptr %l106, !tbaa !29
  %t157 = load i32, ptr %l109, !tbaa !23
  %t158 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t156, i32 %t157)
  store i1 %t158, ptr %l110
  br label %bb65
bb65:
  %t159 = load i1, ptr %l110, !tbaa !21
  store i1 %t159, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb73
bb66:
  %t160 = load i32, ptr %l6
  store i32 %t160, ptr %l111
  %t161 = load i32, ptr %l111
  %t162 = trunc i64 4 to i32
  %t163 = icmp eq i32 %t161, %t162
  store i1 %t163, ptr %l112, !tbaa !21
  %t164 = load i1, ptr %l112, !tbaa !21
  br i1 %t164, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb72
bb69:
  store %olang.scope zeroinitializer, ptr %s8
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l113, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l114, !tbaa !29
  %t167 = load i32, ptr %l1, !tbaa !23
  store i32 %t167, ptr %l115, !tbaa !23
  %t168 = load ptr, ptr %l114, !tbaa !29
  %t169 = load i32, ptr %l115, !tbaa !23
  %t170 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t170, ptr %l116
  br label %bb70
bb70:
  %t171 = load ptr, ptr %l113, !tbaa !29
  %t172 = load i32, ptr %l116, !tbaa !23
  %t173 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t171, i32 %t172)
  store i1 %t173, ptr %l117
  br label %bb71
bb71:
  %t174 = load i1, ptr %l117, !tbaa !21
  store i1 %t174, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s9
  call void @__olang_scope_close(ptr %s9)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s5)
  br label %bb95
bb74:
  %t175 = load i32, ptr %l2
  store i32 %t175, ptr %l118
  %t176 = load i32, ptr %l118
  %t177 = trunc i64 19 to i32
  %t178 = icmp eq i32 %t176, %t177
  store i1 %t178, ptr %l119, !tbaa !21
  %t179 = load i1, ptr %l119, !tbaa !21
  br i1 %t179, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb80
bb77:
  store %olang.scope zeroinitializer, ptr %s10
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l120, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l121, !tbaa !29
  %t182 = load i32, ptr %l1, !tbaa !23
  store i32 %t182, ptr %l122, !tbaa !23
  %t183 = load ptr, ptr %l121, !tbaa !29
  %t184 = load i32, ptr %l122, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t185, ptr %l123
  br label %bb78
bb78:
  %t186 = load ptr, ptr %l120, !tbaa !29
  %t187 = load i32, ptr %l123, !tbaa !23
  %t188 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t186, i32 %t187)
  store i1 %t188, ptr %l124
  br label %bb79
bb79:
  %t189 = load i1, ptr %l124, !tbaa !21
  store i1 %t189, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb95
bb80:
  %t190 = load i32, ptr %l2
  store i32 %t190, ptr %l125
  %t191 = load i32, ptr %l125
  %t192 = trunc i64 22 to i32
  %t193 = icmp eq i32 %t191, %t192
  store i1 %t193, ptr %l126, !tbaa !21
  %t194 = load i1, ptr %l126, !tbaa !21
  br i1 %t194, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  %t195 = load i32, ptr %l2
  store i32 %t195, ptr %l127
  %t196 = load i32, ptr %l127
  %t197 = trunc i64 23 to i32
  %t198 = icmp eq i32 %t196, %t197
  store i1 %t198, ptr %l128, !tbaa !21
  %t199 = load i1, ptr %l128, !tbaa !21
  br i1 %t199, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb88
bb85:
  store %olang.scope zeroinitializer, ptr %s11
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l129, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l130, !tbaa !29
  %t202 = load i32, ptr %l1, !tbaa !23
  store i32 %t202, ptr %l131, !tbaa !23
  %t203 = load ptr, ptr %l130, !tbaa !29
  %t204 = load i32, ptr %l131, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t205, ptr %l132
  br label %bb86
bb86:
  %t206 = load ptr, ptr %l129, !tbaa !29
  %t207 = load i32, ptr %l132, !tbaa !23
  %t208 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t206, i32 %t207)
  store i1 %t208, ptr %l133
  br label %bb87
bb87:
  %t209 = load i1, ptr %l133, !tbaa !21
  store i1 %t209, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb88:
  %t210 = load i32, ptr %l2
  store i32 %t210, ptr %l134
  %t211 = load i32, ptr %l134
  %t212 = trunc i64 24 to i32
  %t213 = icmp eq i32 %t211, %t212
  store i1 %t213, ptr %l135, !tbaa !21
  %t214 = load i1, ptr %l135, !tbaa !21
  br i1 %t214, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb94
bb91:
  store %olang.scope zeroinitializer, ptr %s12
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l136, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l137, !tbaa !29
  %t217 = load i32, ptr %l1, !tbaa !23
  store i32 %t217, ptr %l138, !tbaa !23
  %t218 = load ptr, ptr %l137, !tbaa !29
  %t219 = load i32, ptr %l138, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t218, i32 %t219)
  store i32 %t220, ptr %l139
  br label %bb92
bb92:
  %t221 = load ptr, ptr %l136, !tbaa !29
  %t222 = load i32, ptr %l139, !tbaa !23
  %t223 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t221, i32 %t222)
  store i1 %t223, ptr %l140
  br label %bb93
bb93:
  %t224 = load i1, ptr %l140, !tbaa !21
  store i1 %t224, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s13
  call void @__olang_scope_close(ptr %s13)
  br label %bb95
bb95:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l141, !tbaa !29
  %t226 = load ptr, ptr %l141, !tbaa !29
  %t227 = getelementptr %"compiler/types:Table", ptr %t226, i32 0, i32 29
  %t228 = load i1, ptr %t227, !tbaa !21
  store i1 %t228, ptr %l142, !tbaa !21
  %t229 = load i1, ptr %l142, !tbaa !21
  br i1 %t229, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s14
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l143, !tbaa !29
  %t231 = load ptr, ptr %l143, !tbaa !29
  %t232 = getelementptr %"compiler/types:Table", ptr %t231, i32 0, i32 28
  store ptr %t232, ptr %l144, !tbaa !29
  %t233 = load i32, ptr %l1, !tbaa !23
  store i32 %t233, ptr %l145, !tbaa !23
  %t234 = load ptr, ptr %l144, !tbaa !29
  %t235 = load i32, ptr %l145, !tbaa !23
  %t236 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H0a23e53200851bc31b5ac3bae3d00df4(ptr %v0, ptr %t234, i32 %t235)
  store i1 %t236, ptr %l146
  br label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s15
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l147, !tbaa !29
  %t238 = load ptr, ptr %l147, !tbaa !29
  %t239 = getelementptr %"compiler/types:Table", ptr %t238, i32 0, i32 28
  store ptr %t239, ptr %l148, !tbaa !29
  %t240 = load i32, ptr %l1, !tbaa !23
  store i32 %t240, ptr %l149, !tbaa !23
  %t241 = load i1, ptr %l5, !tbaa !21
  store i1 %t241, ptr %l150, !tbaa !21
  %t242 = load i1, ptr %l150, !tbaa !21
  br i1 %t242, label %bb99, label %bb100
bb98:
  call void @__olang_scope_close(ptr %s14)
  br label %bb103
bb99:
  store i64 3, ptr %l151, !tbaa !24
  br label %bb101
bb100:
  store i64 2, ptr %l151, !tbaa !24
  br label %bb101
bb101:
  %t243 = load ptr, ptr %l148, !tbaa !29
  %t244 = load i32, ptr %l149, !tbaa !23
  %t245 = load i64, ptr %l151, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t243, i32 %t244, i64 %t245)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s15)
  br label %bb103
bb103:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l152, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l153, !tbaa !29
  %t248 = load ptr, ptr %l153, !tbaa !29
  %t249 = getelementptr %"compiler/types:Table", ptr %t248, i32 0, i32 29
  %t250 = load i1, ptr %t249, !tbaa !21
  store i1 %t250, ptr %l154, !tbaa !21
  %t251 = load i1, ptr %l154, !tbaa !21
  br i1 %t251, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb106
bb105:
  %t252 = load i1, ptr %l4, !tbaa !21
  store i1 %t252, ptr %l156, !tbaa !21
  %t253 = load i1, ptr %l156, !tbaa !21
  store i1 %t253, ptr %l155, !tbaa !21
  br label %bb106
bb106:
  %t254 = load i1, ptr %l155, !tbaa !21
  %t255 = load ptr, ptr %l152, !tbaa !29
  %t256 = getelementptr %"compiler/types:Table", ptr %t255, i32 0, i32 29
  store i1 %t254, ptr %t256, !tbaa !21
  %t257 = load i1, ptr %l5, !tbaa !21
  store i1 %t257, ptr %l157, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t258 = load i1, ptr %l157, !tbaa !21
  store i1 %t258, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l2, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp sge i32 %t2, 11
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = icmp sle i32 %t6, 14
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l2, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp sge i32 %t2, 3
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = icmp sle i32 %t6, 10
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l2, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp sge i32 %t2, 3
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = icmp sle i32 %t6, 14
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store ptr %l4, ptr %l5, !tbaa !29
  store i32 20, ptr %l6
  store ptr %l6, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t6, ptr %t7)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l8, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l2, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp sge i32 %t2, 7
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = icmp sle i32 %t6, 10
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 4
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store { i64, ptr } %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:data"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 0
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i32, ptr %l5
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 16
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i32
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l74 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l10, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l11, !tbaa !24
  %t4 = load i64, ptr %l11, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l12, !tbaa !21
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 0, ptr %l13, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l13, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l15, !tbaa !29
  %t9 = load ptr, ptr %l15, !tbaa !29
  %t10 = getelementptr %"compiler/types:Table", ptr %t9, i32 0, i32 5
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l17, !tbaa !27
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t14 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %t12, { i64, ptr } %t13)
  %t15 = extractvalue { i32, i32 } %t14, 1
  %t16 = extractvalue { i32, i32 } %t14, 0
  store i32 %t16, ptr %l19
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18
ok.18:
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t19 = load i32, ptr %l18, !tbaa !23
  store i32 %t19, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i32 -1, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t20 = load i32, ptr %l14, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  %t21 = load i32, ptr %l2, !tbaa !23
  store i32 %t21, ptr %l20, !tbaa !23
  %t22 = load i32, ptr %l20, !tbaa !23
  %t23 = icmp sge i32 %t22, 0
  store i1 %t23, ptr %l21, !tbaa !21
  %t24 = load i1, ptr %l21, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i32, ptr %l2, !tbaa !23
  store i32 %t25, ptr %l22, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l22, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  store i1 %t31, ptr %l25, !tbaa !21
  %t32 = load i1, ptr %l25, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp sle i64 %t33, 2305843009213693951
  store i1 %t34, ptr %l26, !tbaa !21
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb13:
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = mul i64 %t36, 4
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 4
  %t45 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l28, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l4, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t49, ptr %l29, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l30, !tbaa !24
  %t52 = load i64, ptr %l30, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  store i64 %t53, ptr %l31, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  store i64 %t54, ptr %l32, !tbaa !24
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = icmp sgt i64 %t55, %t56
  store i1 %t57, ptr %l33, !tbaa !21
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb15:
  %t59 = load i64, ptr %l6, !tbaa !24
  store i64 %t59, ptr %l35, !tbaa !24
  %t60 = load i64, ptr %l35, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  store i1 %t61, ptr %l36, !tbaa !21
  %t62 = load i1, ptr %l36, !tbaa !21
  br i1 %t62, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb20
bb17:
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l38, !tbaa !24
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = sub i64 %t65, %t66
  store i64 %t67, ptr %l40, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  store i64 %t68, ptr %l41, !tbaa !24
  %t69 = load i64, ptr %l40, !tbaa !24
  %t70 = load i64, ptr %l41, !tbaa !24
  %t71 = add i64 %t69, %t70
  store i64 %t71, ptr %l42, !tbaa !24
  %t72 = load i64, ptr %l42, !tbaa !24
  %t73 = sub i64 %t72, 1
  store i64 %t73, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  store i64 %t74, ptr %l44, !tbaa !24
  %t75 = load i64, ptr %l43, !tbaa !24
  %t76 = load i64, ptr %l44, !tbaa !24
  %t77 = sdiv i64 %t75, %t76
  store i64 %t77, ptr %l45, !tbaa !24
  %t78 = load i64, ptr %l45, !tbaa !24
  store i64 %t78, ptr %l37, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb19
bb19:
  %t79 = load i64, ptr %l37, !tbaa !24
  store i64 %t79, ptr %l34, !tbaa !24
  br label %bb20
bb20:
  %t80 = load i64, ptr %l34, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l46, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  store i64 %t82, ptr %l47, !tbaa !24
  %t83 = load i64, ptr %l46, !tbaa !24
  %t84 = load i64, ptr %l47, !tbaa !24
  %t85 = icmp slt i64 %t83, %t84
  store i1 %t85, ptr %l48, !tbaa !21
  %t86 = load i1, ptr %l48, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l49, !tbaa !21
  %t88 = load i1, ptr %l49, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t89 = load i64, ptr %l4, !tbaa !24
  store i64 %t89, ptr %l50, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  store i64 %t90, ptr %l51, !tbaa !24
  %t91 = load i64, ptr %l6, !tbaa !24
  store i64 %t91, ptr %l52, !tbaa !24
  %t92 = load i64, ptr %l51, !tbaa !24
  %t93 = load i64, ptr %l52, !tbaa !24
  %t94 = mul i64 %t92, %t93
  store i64 %t94, ptr %l53, !tbaa !24
  %t95 = load i64, ptr %l50, !tbaa !24
  %t96 = load i64, ptr %l53, !tbaa !24
  %t97 = add i64 %t95, %t96
  store i64 %t97, ptr %l54, !tbaa !24
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l9, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  %t100 = load i64, ptr %l9, !tbaa !24
  store i64 %t100, ptr %l56, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t101, ptr %l57, !tbaa !27
  %t102 = load i64, ptr %l9, !tbaa !24
  store i64 %t102, ptr %l58, !tbaa !24
  %t103 = load i64, ptr %l58, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t103
  %t107 = load i32, ptr %t106, !tbaa !33
  store i32 %t107, ptr %l59, !tbaa !23
  %t108 = load i32, ptr %l59, !tbaa !23
  %t109 = load i64, ptr %l56, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t109
  store i32 %t108, ptr %t112, !tbaa !33
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t113 = load i64, ptr %l8, !tbaa !24
  store i64 %t113, ptr %l60, !tbaa !24
  %t114 = load i64, ptr %l60, !tbaa !24
  %t115 = add i64 %t114, 1
  store i64 %t115, ptr %l61, !tbaa !24
  %t116 = load i64, ptr %l61, !tbaa !24
  store i64 %t116, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb26:
  call void @__olang_scope_close(ptr %s3)
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l62, !tbaa !29
  %t118 = load ptr, ptr %l62, !tbaa !29
  %t119 = getelementptr %"compiler/types:Table", ptr %t118, i32 0, i32 4
  store ptr %t119, ptr %l63, !tbaa !29
  %t120 = load ptr, ptr %l63, !tbaa !29
  %t121 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_H503e6d35c0db63145eb2ca8ce5f41f51(ptr %v0, ptr %t120)
  store i64 %t121, ptr %l64
  br label %bb27
bb27:
  %t122 = load i64, ptr %l64, !tbaa !24
  %t123 = trunc i64 %t122 to i32
  store i32 %t123, ptr %l65, !tbaa !23
  %t124 = load i32, ptr %l65, !tbaa !23
  store i32 %t124, ptr %l66, !tbaa !23
  %t125 = load i32, ptr %l66, !tbaa !23
  store i32 %t125, ptr %l2, !tbaa !23
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l67, !tbaa !29
  %t127 = load ptr, ptr %l67, !tbaa !29
  %t128 = getelementptr %"compiler/types:Table", ptr %t127, i32 0, i32 4
  store ptr %t128, ptr %l68, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t129, ptr %l69, !tbaa !27
  %t130 = load ptr, ptr %l68, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l69, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v0, ptr %v0, ptr %t130, { i64, ptr } %t131)
  br label %bb28
bb28:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l70, !tbaa !29
  %t133 = load ptr, ptr %l70, !tbaa !29
  %t134 = getelementptr %"compiler/types:Table", ptr %t133, i32 0, i32 5
  store ptr %t134, ptr %l71, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t135, ptr %l72, !tbaa !27
  %t136 = load i32, ptr %l2, !tbaa !23
  store i32 %t136, ptr %l73, !tbaa !23
  %t137 = load ptr, ptr %l71, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t139 = load i32, ptr %l73, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v0, ptr %t137, { i64, ptr } %t138, i32 %t139)
  br label %bb29
bb29:
  %t140 = load i32, ptr %l2, !tbaa !23
  store i32 %t140, ptr %l74, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l74, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca [1 x i32]
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load i32, ptr %l3, !tbaa !23
  %t4 = insertvalue [1 x i32] undef, i32 %t3, 0
  store [1 x i32] %t4, ptr %l4
  %t5 = load [1 x i32], ptr %l4
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call ptr @__olang_scope_alloc(ptr %t6, i64 4)
  store [1 x i32] %t5, ptr %t7
  %t8 = insertvalue { i64, ptr } undef, i64 1, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  store { i64, ptr } %t9, ptr %l5, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 4
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t17, { i64, ptr } %t18)
  store i32 %t19, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l7, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t2 = load i32, ptr %l3, !tbaa !23
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 22
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr @.d16 })
  store i1 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l10, !tbaa !21
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l11, !tbaa !29
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t18, i32 0, i32 22
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = load i64, ptr %l13, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store { i64, ptr } %t23, ptr %l14
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = getelementptr %"compiler/types:Table", ptr %t26, i32 0, i32 22
  store ptr %t27, ptr %l16, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  store i32 %t30, ptr %l19, !tbaa !23
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load i32, ptr %l19, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l20
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l21, !tbaa !27
  %t41 = load ptr, ptr %l16, !tbaa !29
  %t42 = load i64, ptr %l17, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v0, ptr %t41, i64 %t42, { i64, ptr } %t43)
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l22, !tbaa !29
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = getelementptr %"compiler/types:Table", ptr %t45, i32 0, i32 22
  store ptr %t46, ptr %l23, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l24, !tbaa !24
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t50, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca %"compiler/types:data"
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  store i32 18, ptr %l8
  %t8 = load i32, ptr %l1, !tbaa !23
  store i32 %t8, ptr %l9, !tbaa !23
  %t9 = load i32, ptr %l9, !tbaa !23
  %t10 = sext i32 %t9 to i64
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i32, ptr %l3, !tbaa !23
  store i32 %t11, ptr %l11, !tbaa !23
  %t12 = load i32, ptr %l11, !tbaa !23
  %t13 = sext i32 %t12 to i64
  store i64 %t13, ptr %l12, !tbaa !24
  %t14 = load i32, ptr %l8
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = load i64, ptr %l12, !tbaa !24
  %t17 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t14, i64 %t15, i64 %t16, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t17, ptr %l13
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l14, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  store i32 %t19, ptr %l15, !tbaa !23
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load i32, ptr %l15, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l16
  br label %bb3
bb3:
  %t23 = load i32, ptr %l16, !tbaa !23
  %t24 = add i32 %t23, 1
  store i32 %t24, ptr %l17, !tbaa !23
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load %"compiler/types:data", ptr %l13
  %t27 = load i32, ptr %l17, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t25, %"compiler/types:data" %t26, i32 %t27)
  store i32 %t28, ptr %l18
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l18, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca %"compiler/types:data"
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store ptr %l4, ptr %l5, !tbaa !29
  store i32 21, ptr %l6
  store ptr %l6, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t6, ptr %t7)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  store i32 %t11, ptr %l11, !tbaa !23
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t12, i32 %t13)
  store %"compiler/types:data" %t14, ptr %l12
  br label %bb5
bb4:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb6
bb5:
  %t15 = getelementptr %"compiler/types:data", ptr %l12, i32 0, i32 5
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l13, !tbaa !24
  %t17 = load i64, ptr %l13, !tbaa !24
  store i64 %t17, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i64, ptr %l9, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca %"compiler/types:data"
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  store ptr %l4, ptr %l5, !tbaa !29
  store i32 21, ptr %l6
  store ptr %l6, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t6, ptr %t7)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 26
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l12, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  store i32 %t14, ptr %l13, !tbaa !23
  %t15 = load ptr, ptr %l12, !tbaa !29
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t15, i32 %t16)
  store %"compiler/types:data" %t17, ptr %l14
  br label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l17, !tbaa !29
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = getelementptr %"compiler/types:Table", ptr %t19, i32 0, i32 26
  store ptr %t20, ptr %l18, !tbaa !29
  %t21 = load ptr, ptr %l18, !tbaa !29
  %t22 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t21, i64 0)
  store { i64, ptr } %t22, ptr %l19
  br label %bb7
bb5:
  %t23 = getelementptr %"compiler/types:data", ptr %l14, i32 0, i32 5
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l15, !tbaa !24
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t25, i64 %t26)
  store { i64, ptr } %t27, ptr %l16
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l9, !tbaa !27
  br label %bb8
bb7:
  %t29 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l12, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  store i32 %t3, ptr %l13, !tbaa !23
  %t4 = load ptr, ptr %l12, !tbaa !29
  %t5 = load i32, ptr %l13, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldList(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i32, ptr %l14, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l17, !tbaa !24
  %t14 = load i64, ptr %l17, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  store i1 %t15, ptr %l18, !tbaa !21
  %t16 = load i1, ptr %l18, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  store i1 %t18, ptr %l19, !tbaa !21
  %t19 = load i1, ptr %l19, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb5:
  %t20 = load i64, ptr %l17, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l20, !tbaa !27
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t25, ptr %lp3
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t27 = load ptr, ptr %lp3
  store { i64, ptr } %t26, ptr %t27, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t30 = getelementptr %"compiler/types:Table", ptr %t29, i32 0, i32 19
  store ptr %t30, ptr %l22, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %l23, !tbaa !23
  %t32 = load i32, ptr %l23, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l24, !tbaa !24
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  store i64 %t36, ptr %l25
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb7:
  %t37 = load i64, ptr %l25, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l26, !tbaa !24
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = icmp slt i64 %t39, 0
  store i1 %t40, ptr %l27, !tbaa !21
  %t41 = load i1, ptr %l27, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t42 = load ptr, ptr %lp3
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l2, !tbaa !24
  store i64 %t45, ptr %l29, !tbaa !24
  %t46 = load i64, ptr %l29, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  store i64 %t47, ptr %l30, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  store i64 %t48, ptr %l31, !tbaa !24
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = load i64, ptr %l31, !tbaa !24
  %t51 = icmp sgt i64 %t49, %t50
  store i1 %t51, ptr %l32, !tbaa !21
  %t52 = load i1, ptr %l32, !tbaa !21
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l34, !tbaa !24
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = icmp sgt i64 %t54, 0
  store i1 %t55, ptr %l35, !tbaa !21
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb16
bb13:
  %t57 = load i64, ptr %l6, !tbaa !24
  store i64 %t57, ptr %l37, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  store i64 %t58, ptr %l38, !tbaa !24
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = sub i64 %t59, %t60
  store i64 %t61, ptr %l39, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  store i64 %t62, ptr %l40, !tbaa !24
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = load i64, ptr %l40, !tbaa !24
  %t65 = add i64 %t63, %t64
  store i64 %t65, ptr %l41, !tbaa !24
  %t66 = load i64, ptr %l41, !tbaa !24
  %t67 = sub i64 %t66, 1
  store i64 %t67, ptr %l42, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  store i64 %t68, ptr %l43, !tbaa !24
  %t69 = load i64, ptr %l42, !tbaa !24
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = sdiv i64 %t69, %t70
  store i64 %t71, ptr %l44, !tbaa !24
  %t72 = load i64, ptr %l44, !tbaa !24
  store i64 %t72, ptr %l36, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb15
bb15:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t74 = load i64, ptr %l33, !tbaa !24
  store i64 %t74, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load i64, ptr %l9, !tbaa !24
  store i64 %t75, ptr %l45, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  store i64 %t76, ptr %l46, !tbaa !24
  %t77 = load i64, ptr %l45, !tbaa !24
  %t78 = load i64, ptr %l46, !tbaa !24
  %t79 = icmp slt i64 %t77, %t78
  store i1 %t79, ptr %l47, !tbaa !21
  %t80 = load i1, ptr %l47, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l48, !tbaa !21
  %t82 = load i1, ptr %l48, !tbaa !21
  br i1 %t82, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %l49, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  store i64 %t84, ptr %l50, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  store i64 %t85, ptr %l51, !tbaa !24
  %t86 = load i64, ptr %l50, !tbaa !24
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = mul i64 %t86, %t87
  store i64 %t88, ptr %l52, !tbaa !24
  %t89 = load i64, ptr %l49, !tbaa !24
  %t90 = load i64, ptr %l52, !tbaa !24
  %t91 = add i64 %t89, %t90
  store i64 %t91, ptr %l53, !tbaa !24
  %t92 = load i64, ptr %l53, !tbaa !24
  store i64 %t92, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  store i64 %t93, ptr %l54, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = getelementptr %"compiler/types:Table", ptr %t95, i32 0, i32 20
  store ptr %t96, ptr %l56, !tbaa !29
  %t97 = load i64, ptr %l4, !tbaa !24
  store i64 %t97, ptr %l57, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  store i64 %t98, ptr %l58, !tbaa !24
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = load i64, ptr %l58, !tbaa !24
  %t101 = add i64 %t99, %t100
  store i64 %t101, ptr %l59, !tbaa !24
  %t102 = load ptr, ptr %l56, !tbaa !29
  %t103 = load i64, ptr %l59, !tbaa !24
  %t104 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t104, ptr %l60
  br label %bb21
bb21:
  %t105 = load i64, ptr %l60, !tbaa !24
  %t106 = load ptr, ptr %lp3
  %t107 = load i64, ptr %l54, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i64, ptr %t109, i64 %t107
  store i64 %t105, ptr %t110, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t111 = load i64, ptr %l9, !tbaa !24
  store i64 %t111, ptr %l61, !tbaa !24
  %t112 = load i64, ptr %l61, !tbaa !24
  %t113 = add i64 %t112, 1
  store i64 %t113, ptr %l62, !tbaa !24
  %t114 = load i64, ptr %l62, !tbaa !24
  store i64 %t114, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb23:
  call void @__olang_scope_close(ptr %s2)
  %t115 = load ptr, ptr %lp3
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamIsConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/types:decl"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l5, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t7, i64 %t8)
  store %"compiler/types:decl" %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l7, i32 0, i32 4
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = ashr i64 %t13, %t15
  store i64 %t16, ptr %l10, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = and i64 %t17, 1
  store i64 %t18, ptr %l11, !tbaa !24
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = icmp eq i64 %t19, 1
  store i1 %t20, ptr %l12, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l12, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l10, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l11, !tbaa !24
  %t4 = load i64, ptr %l11, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l12, !tbaa !21
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i64, ptr %l13, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l14, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l15, !tbaa !24
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  store i1 %t12, ptr %l16, !tbaa !21
  %t13 = load i1, ptr %l16, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = icmp sle i64 %t14, 1152921504606846975
  store i1 %t15, ptr %l17, !tbaa !21
  %t16 = load i1, ptr %l17, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb6:
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = mul i64 %t17, 8
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  %t24 = extractvalue { i64, ptr } %t22, 1
  %t25 = mul i64 %t23, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l3, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l21, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = icmp sgt i64 %t36, %t37
  store i1 %t38, ptr %l24, !tbaa !21
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb8:
  %t40 = load i64, ptr %l5, !tbaa !24
  store i64 %t40, ptr %l26, !tbaa !24
  %t41 = load i64, ptr %l26, !tbaa !24
  %t42 = icmp sgt i64 %t41, 0
  store i1 %t42, ptr %l27, !tbaa !21
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l4, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  store i64 %t45, ptr %l30, !tbaa !24
  %t46 = load i64, ptr %l29, !tbaa !24
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = sub i64 %t46, %t47
  store i64 %t48, ptr %l31, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  store i64 %t49, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l31, !tbaa !24
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = add i64 %t50, %t51
  store i64 %t52, ptr %l33, !tbaa !24
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = sub i64 %t53, 1
  store i64 %t54, ptr %l34, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  store i64 %t55, ptr %l35, !tbaa !24
  %t56 = load i64, ptr %l34, !tbaa !24
  %t57 = load i64, ptr %l35, !tbaa !24
  %t58 = sdiv i64 %t56, %t57
  store i64 %t58, ptr %l36, !tbaa !24
  %t59 = load i64, ptr %l36, !tbaa !24
  store i64 %t59, ptr %l28, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l28, !tbaa !24
  store i64 %t60, ptr %l25, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l25, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load i64, ptr %l7, !tbaa !24
  store i64 %t62, ptr %l37, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load i64, ptr %l37, !tbaa !24
  %t65 = load i64, ptr %l38, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  store i1 %t66, ptr %l39, !tbaa !21
  %t67 = load i1, ptr %l39, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l40, !tbaa !21
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l3, !tbaa !24
  store i64 %t70, ptr %l41, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  store i64 %t71, ptr %l42, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  store i64 %t72, ptr %l43, !tbaa !24
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i64, ptr %l43, !tbaa !24
  %t75 = mul i64 %t73, %t74
  store i64 %t75, ptr %l44, !tbaa !24
  %t76 = load i64, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l44, !tbaa !24
  %t78 = add i64 %t76, %t77
  store i64 %t78, ptr %l45, !tbaa !24
  %t79 = load i64, ptr %l45, !tbaa !24
  store i64 %t79, ptr %l8, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t80, ptr %l46, !tbaa !27
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l47, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t82, ptr %l48, !tbaa !27
  %t83 = load i64, ptr %l8, !tbaa !24
  store i64 %t83, ptr %l49, !tbaa !24
  %t84 = load i64, ptr %l49, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i64, ptr %t86, i64 %t84
  %t88 = load i64, ptr %t87, !tbaa !34
  store i64 %t88, ptr %l50, !tbaa !24
  %t89 = load i64, ptr %l50, !tbaa !24
  %t90 = load i64, ptr %l47, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i64, ptr %t92, i64 %t90
  store i64 %t89, ptr %t93, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t94 = load i64, ptr %l7, !tbaa !24
  store i64 %t94, ptr %l51, !tbaa !24
  %t95 = load i64, ptr %l51, !tbaa !24
  %t96 = add i64 %t95, 1
  store i64 %t96, ptr %l52, !tbaa !24
  %t97 = load i64, ptr %l52, !tbaa !24
  store i64 %t97, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l54, !tbaa !29
  %t99 = load ptr, ptr %l54, !tbaa !29
  %t100 = getelementptr %"compiler/types:Table", ptr %t99, i32 0, i32 27
  store ptr %t100, ptr %l55, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t101, ptr %l56, !tbaa !27
  %t102 = load ptr, ptr %l55, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t104 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t102, { i64, ptr } %t103)
  %t105 = extractvalue { i32, i64 } %t104, 1
  %t106 = extractvalue { i32, i64 } %t104, 0
  store i32 %t106, ptr %l58
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb21, label %ok.108
ok.108:
  store i64 %t105, ptr %l57
  br label %bb20
bb20:
  %t109 = load i64, ptr %l57, !tbaa !24
  store i64 %t109, ptr %l53, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t110 = load i64, ptr %l53, !tbaa !24
  store i64 %t110, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  store i64 %t111, ptr %l59, !tbaa !24
  %t112 = load i64, ptr %l59, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  store i1 %t113, ptr %l60, !tbaa !21
  %t114 = load i1, ptr %l60, !tbaa !21
  br i1 %t114, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t115 = load i64, ptr %l9, !tbaa !24
  store i64 %t115, ptr %l61, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load i64, ptr %l61, !tbaa !24
  store i64 %t116, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l62, !tbaa !29
  %t118 = load ptr, ptr %l62, !tbaa !29
  %t119 = getelementptr %"compiler/types:Table", ptr %t118, i32 0, i32 26
  store ptr %t119, ptr %l63, !tbaa !29
  %t120 = load ptr, ptr %l63, !tbaa !29
  %t121 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t120)
  store i64 %t121, ptr %l64
  br label %bb27
bb27:
  %t122 = load i64, ptr %l64, !tbaa !24
  store i64 %t122, ptr %l9, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l65, !tbaa !29
  %t124 = load ptr, ptr %l65, !tbaa !29
  %t125 = getelementptr %"compiler/types:Table", ptr %t124, i32 0, i32 26
  store ptr %t125, ptr %l66, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t126, ptr %l67, !tbaa !27
  %t127 = load ptr, ptr %l66, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l67, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t127, { i64, ptr } %t128)
  br label %bb28
bb28:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l68, !tbaa !29
  %t130 = load ptr, ptr %l68, !tbaa !29
  %t131 = getelementptr %"compiler/types:Table", ptr %t130, i32 0, i32 27
  store ptr %t131, ptr %l69, !tbaa !29
  %t132 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t132, ptr %l70, !tbaa !27
  %t133 = load i64, ptr %l9, !tbaa !24
  store i64 %t133, ptr %l71, !tbaa !24
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t136 = load i64, ptr %l71, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t134, { i64, ptr } %t135, i64 %t136)
  br label %bb29
bb29:
  %t137 = load i64, ptr %l9, !tbaa !24
  store i64 %t137, ptr %l72, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t138 = load i64, ptr %l72, !tbaa !24
  store i64 %t138, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l9, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l10, !tbaa !23
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = load i32, ptr %l10, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t13, ptr %l13, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l15, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = load i64, ptr %l16, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  store i1 %t21, ptr %l17, !tbaa !21
  %t22 = load i1, ptr %l17, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l18, !tbaa !21
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 %t27
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l21, !tbaa !23
  %t32 = load i32, ptr %l21, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  store i32 %t34, ptr %l23, !tbaa !23
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i32, ptr %l23, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t37, ptr %l24
  br label %bb8
bb8:
  %t38 = load i1, ptr %l24, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l2, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t39, i8 109)
  br label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l26, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  store i32 %t41, ptr %l27, !tbaa !23
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = load i32, ptr %l27, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t44, ptr %l28
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  store ptr %l28, ptr %l29, !tbaa !29
  store i32 21, ptr %l30
  store ptr %l30, ptr %l31, !tbaa !29
  %t45 = load ptr, ptr %l29, !tbaa !29
  %t46 = load ptr, ptr %l31, !tbaa !29
  %t47 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t45, ptr %t46)
  store i1 %t47, ptr %l32
  br label %bb13
bb13:
  %t48 = load i1, ptr %l32, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l2, ptr %l33, !tbaa !29
  %t49 = load ptr, ptr %l33, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t49, i8 115)
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l2, ptr %l34, !tbaa !29
  %t50 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t50, i8 118)
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l35, !tbaa !24
  %t52 = load i64, ptr %l35, !tbaa !24
  %t53 = add i64 %t52, 1
  store i64 %t53, ptr %l36, !tbaa !24
  %t54 = load i64, ptr %l36, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb4
bb21:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l2, ptr %l37, !tbaa !29
  %t55 = load ptr, ptr %l37, !tbaa !29
  %t56 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t55)
  store { i64, ptr } %t56, ptr %l38
  br label %bb22
bb22:
  %t57 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t57, ptr %l39, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l40, !tbaa !24
  %t60 = load i64, ptr %l40, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l41, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l40, !tbaa !24
  %t70 = mul i64 %t69, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t71, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 9
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 21
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 23
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7, i64 %t8)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l16, !tbaa !23
  %t3 = load ptr, ptr %l15, !tbaa !29
  %t4 = load i32, ptr %l16, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t3, i32 %t4)
  store { i64, ptr } %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i1 true, ptr %l3, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l18, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t9, ptr %l19, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l20, !tbaa !24
  %t12 = load i64, ptr %l20, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l21, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  store i64 %t14, ptr %l22, !tbaa !24
  %t15 = load i64, ptr %l21, !tbaa !24
  %t16 = load i64, ptr %l22, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  store i1 %t17, ptr %l23, !tbaa !21
  %t18 = load i1, ptr %l23, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l24, !tbaa !21
  %t20 = load i1, ptr %l24, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  store i64 %t22, ptr %l26, !tbaa !24
  %t23 = load i64, ptr %l26, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t23
  %t27 = load i32, ptr %t26, !tbaa !33
  store i32 %t27, ptr %l27, !tbaa !23
  %t28 = load i32, ptr %l27, !tbaa !23
  store i32 %t28, ptr %l7, !tbaa !23
  %t29 = load i1, ptr %l3, !tbaa !21
  store i1 %t29, ptr %l28, !tbaa !21
  %t30 = load i1, ptr %l28, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l30, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  store i32 %t32, ptr %l31, !tbaa !23
  %t33 = load ptr, ptr %l30, !tbaa !29
  %t34 = load i32, ptr %l31, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l32
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i32, ptr %l7, !tbaa !23
  store i32 %t36, ptr %l33, !tbaa !23
  %t37 = load i32, ptr %l32, !tbaa !23
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = icmp eq i32 %t37, %t38
  store i1 %t39, ptr %l34, !tbaa !21
  %t40 = load i1, ptr %l34, !tbaa !21
  store i1 %t40, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l29, !tbaa !21
  store i1 %t41, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load i64, ptr %l5, !tbaa !24
  store i64 %t42, ptr %l35, !tbaa !24
  %t43 = load i64, ptr %l35, !tbaa !24
  %t44 = add i64 %t43, 1
  store i64 %t44, ptr %l36, !tbaa !24
  %t45 = load i64, ptr %l36, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb2
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t46 = load i1, ptr %l3, !tbaa !21
  store i1 %t46, ptr %l37, !tbaa !21
  %t47 = load i1, ptr %l37, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i32, ptr %l1, !tbaa !23
  store i32 %t48, ptr %l38, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i32, ptr %l38, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t50, ptr %l39, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l40, !tbaa !24
  %t53 = load i64, ptr %l40, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  store i1 %t54, ptr %l41, !tbaa !21
  %t55 = load i1, ptr %l41, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load i64, ptr %l40, !tbaa !24
  %t57 = icmp sle i64 %t56, 2305843009213693951
  store i1 %t57, ptr %l42, !tbaa !21
  %t58 = load i1, ptr %l42, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb17:
  %t59 = load i64, ptr %l40, !tbaa !24
  %t60 = mul i64 %t59, 4
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l43, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t64, ptr %l8, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s5
  store i64 0, ptr %l9, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t65, ptr %l44, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l45, !tbaa !24
  %t68 = load i64, ptr %l45, !tbaa !24
  store i64 %t68, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  store i64 %t69, ptr %l46, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  store i64 %t70, ptr %l47, !tbaa !24
  %t71 = load i64, ptr %l46, !tbaa !24
  %t72 = load i64, ptr %l47, !tbaa !24
  %t73 = icmp sgt i64 %t71, %t72
  store i1 %t73, ptr %l48, !tbaa !21
  %t74 = load i1, ptr %l48, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb19:
  %t75 = load i64, ptr %l11, !tbaa !24
  store i64 %t75, ptr %l50, !tbaa !24
  %t76 = load i64, ptr %l50, !tbaa !24
  %t77 = icmp sgt i64 %t76, 0
  store i1 %t77, ptr %l51, !tbaa !21
  %t78 = load i1, ptr %l51, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb24
bb21:
  %t79 = load i64, ptr %l10, !tbaa !24
  store i64 %t79, ptr %l53, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  store i64 %t80, ptr %l54, !tbaa !24
  %t81 = load i64, ptr %l53, !tbaa !24
  %t82 = load i64, ptr %l54, !tbaa !24
  %t83 = sub i64 %t81, %t82
  store i64 %t83, ptr %l55, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  store i64 %t84, ptr %l56, !tbaa !24
  %t85 = load i64, ptr %l55, !tbaa !24
  %t86 = load i64, ptr %l56, !tbaa !24
  %t87 = add i64 %t85, %t86
  store i64 %t87, ptr %l57, !tbaa !24
  %t88 = load i64, ptr %l57, !tbaa !24
  %t89 = sub i64 %t88, 1
  store i64 %t89, ptr %l58, !tbaa !24
  %t90 = load i64, ptr %l11, !tbaa !24
  store i64 %t90, ptr %l59, !tbaa !24
  %t91 = load i64, ptr %l58, !tbaa !24
  %t92 = load i64, ptr %l59, !tbaa !24
  %t93 = sdiv i64 %t91, %t92
  store i64 %t93, ptr %l60, !tbaa !24
  %t94 = load i64, ptr %l60, !tbaa !24
  store i64 %t94, ptr %l52, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t95 = load i64, ptr %l52, !tbaa !24
  store i64 %t95, ptr %l49, !tbaa !24
  br label %bb24
bb24:
  %t96 = load i64, ptr %l49, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l13, !tbaa !24
  store i64 %t97, ptr %l61, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  store i64 %t98, ptr %l62, !tbaa !24
  %t99 = load i64, ptr %l61, !tbaa !24
  %t100 = load i64, ptr %l62, !tbaa !24
  %t101 = icmp slt i64 %t99, %t100
  store i1 %t101, ptr %l63, !tbaa !21
  %t102 = load i1, ptr %l63, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l64, !tbaa !21
  %t104 = load i1, ptr %l64, !tbaa !21
  br i1 %t104, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l9, !tbaa !24
  store i64 %t105, ptr %l65, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  store i64 %t106, ptr %l66, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  store i64 %t107, ptr %l67, !tbaa !24
  %t108 = load i64, ptr %l66, !tbaa !24
  %t109 = load i64, ptr %l67, !tbaa !24
  %t110 = mul i64 %t108, %t109
  store i64 %t110, ptr %l68, !tbaa !24
  %t111 = load i64, ptr %l65, !tbaa !24
  %t112 = load i64, ptr %l68, !tbaa !24
  %t113 = add i64 %t111, %t112
  store i64 %t113, ptr %l69, !tbaa !24
  %t114 = load i64, ptr %l69, !tbaa !24
  store i64 %t114, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  store i64 %t115, ptr %l70, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l71, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t117, ptr %l72, !tbaa !27
  %t118 = load i64, ptr %l14, !tbaa !24
  store i64 %t118, ptr %l73, !tbaa !24
  %t119 = load i64, ptr %l73, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i32, ptr %t121, i64 %t119
  %t123 = load i32, ptr %t122, !tbaa !33
  store i32 %t123, ptr %l74, !tbaa !23
  %t124 = load ptr, ptr %l71, !tbaa !29
  %t125 = load i32, ptr %l74, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l75
  br label %bb29
bb29:
  %t127 = load i32, ptr %l75, !tbaa !23
  %t128 = load i64, ptr %l70, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t128
  store i32 %t127, ptr %t131, !tbaa !33
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l13, !tbaa !24
  store i64 %t132, ptr %l76, !tbaa !24
  %t133 = load i64, ptr %l76, !tbaa !24
  %t134 = add i64 %t133, 1
  store i64 %t134, ptr %l77, !tbaa !24
  %t135 = load i64, ptr %l77, !tbaa !24
  store i64 %t135, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb25
bb31:
  call void @__olang_scope_close(ptr %s5)
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t137, ptr %l79, !tbaa !27
  %t138 = load ptr, ptr %l78, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t138, { i64, ptr } %t139)
  store i32 %t140, ptr %l80
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l80, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 1, ptr %l2, !tbaa !24
  store i64 15, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  store i64 %t1, ptr %l8, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  store i64 %t2, ptr %l9, !tbaa !24
  %t3 = load i64, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l9, !tbaa !24
  %t5 = icmp sgt i64 %t3, %t4
  store i1 %t5, ptr %l10, !tbaa !21
  %t6 = load i1, ptr %l10, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l12, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = icmp sgt i64 %t8, 0
  store i1 %t9, ptr %l13, !tbaa !21
  %t10 = load i1, ptr %l13, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l15, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l16, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  %t15 = sub i64 %t13, %t14
  store i64 %t15, ptr %l17, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l18, !tbaa !24
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = add i64 %t17, %t18
  store i64 %t19, ptr %l19, !tbaa !24
  %t20 = load i64, ptr %l19, !tbaa !24
  %t21 = sub i64 %t20, 1
  store i64 %t21, ptr %l20, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l21, !tbaa !24
  %t23 = load i64, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = sdiv i64 %t23, %t24
  store i64 %t25, ptr %l22, !tbaa !24
  %t26 = load i64, ptr %l22, !tbaa !24
  store i64 %t26, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l6, !tbaa !24
  store i64 %t29, ptr %l23, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load i64, ptr %l23, !tbaa !24
  %t32 = load i64, ptr %l24, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l25, !tbaa !21
  %t34 = load i1, ptr %l25, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l26, !tbaa !21
  %t36 = load i1, ptr %l26, !tbaa !21
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  store i64 %t37, ptr %l27, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  store i64 %t38, ptr %l28, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  store i64 %t39, ptr %l29, !tbaa !24
  %t40 = load i64, ptr %l28, !tbaa !24
  %t41 = load i64, ptr %l29, !tbaa !24
  %t42 = mul i64 %t40, %t41
  store i64 %t42, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l27, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = add i64 %t43, %t44
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l32, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimNames, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %t50, i64 %t48
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !37
  store { i64, ptr } %t52, ptr %l33, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t53, ptr %l34, !tbaa !27
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t54, ptr %v1, { i64, ptr } %t55, { i64, ptr } %t56)
  store i1 %t57, ptr %l35
  br label %bb11
bb11:
  %t58 = load i1, ptr %l35, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load i64, ptr %l7, !tbaa !24
  store i64 %t59, ptr %l36, !tbaa !24
  %t60 = load i64, ptr %l36, !tbaa !24
  %t61 = trunc i64 %t60 to i32
  store i32 %t61, ptr %l37, !tbaa !23
  %t62 = load i32, ptr %l37, !tbaa !23
  store i32 %t62, ptr %l38, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t63 = load i32, ptr %l38, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i64, ptr %l6, !tbaa !24
  store i64 %t64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l39, !tbaa !24
  %t66 = add i64 %t65, 1
  store i64 %t66, ptr %l40, !tbaa !24
  %t67 = load i64, ptr %l40, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb7
bb16:
  call void @__olang_scope_close(ptr %s1)
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t68, ptr %l41, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i32, ptr %l41, !tbaa !23
  store i32 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca %"compiler/types:data"
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 23, ptr %l5
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  %t3 = load i32, ptr %l6, !tbaa !23
  %t4 = sext i32 %t3 to i64
  store i64 %t4, ptr %l7, !tbaa !24
  %t5 = load i32, ptr %l5
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t5, i64 %t6, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  store i32 %t9, ptr %l10, !tbaa !23
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i32, ptr %l10, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = add i32 %t13, 1
  store i32 %t14, ptr %l12, !tbaa !23
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l8
  %t17 = load i32, ptr %l12, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t17)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l15, !tbaa !23
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load i32, ptr %l3, !tbaa !23
  store i32 %t26, ptr %l17, !tbaa !23
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l18, !tbaa !23
  %t28 = load i32, ptr %l17, !tbaa !23
  %t29 = load i32, ptr %l18, !tbaa !23
  %t30 = icmp ne i32 %t28, %t29
  store i1 %t30, ptr %l19, !tbaa !21
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t33, i32 0, i32 23
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  store i32 %t35, ptr %l22, !tbaa !23
  %t36 = load i32, ptr %l22, !tbaa !23
  %t37 = sext i32 %t36 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  store i32 %t39, ptr %l25, !tbaa !23
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = load i32, ptr %l25, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t42, ptr %l26
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t43, i64 %t44, i32 %t45)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t46 = load i32, ptr %l2, !tbaa !23
  store i32 %t46, ptr %l27, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i32, ptr %l27, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 20, ptr %l5
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  %t3 = load i32, ptr %l6, !tbaa !23
  %t4 = sext i32 %t3 to i64
  store i64 %t4, ptr %l7, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load i32, ptr %l5
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t6, i64 %t7, i64 %t8, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  store i32 %t11, ptr %l11, !tbaa !23
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = add i32 %t15, 1
  store i32 %t16, ptr %l13, !tbaa !23
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load %"compiler/types:data", ptr %l9
  %t19 = load i32, ptr %l13, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t17, %"compiler/types:data" %t18, i32 %t19)
  store i32 %t20, ptr %l14
  br label %bb3
bb3:
  %t21 = load i32, ptr %l14, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  store i32 %t23, ptr %l16, !tbaa !23
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i32, ptr %l16, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l17
  br label %bb4
bb4:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l18, !tbaa !23
  %t28 = load i32, ptr %l17, !tbaa !23
  %t29 = load i32, ptr %l18, !tbaa !23
  %t30 = icmp ne i32 %t28, %t29
  store i1 %t30, ptr %l19, !tbaa !21
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t33, i32 0, i32 23
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  store i32 %t35, ptr %l22, !tbaa !23
  %t36 = load i32, ptr %l22, !tbaa !23
  %t37 = sext i32 %t36 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l25, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  store i32 %t40, ptr %l26, !tbaa !23
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t42 = load i32, ptr %l26, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t43, ptr %l27
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l28, !tbaa !24
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i32, ptr %l27, !tbaa !23
  %t47 = load i64, ptr %l28, !tbaa !24
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t45, i32 %t46, i64 %t47)
  store i32 %t48, ptr %l29
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = load i32, ptr %l29, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t49, i64 %t50, i32 %t51)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t52 = load i32, ptr %l3, !tbaa !23
  store i32 %t52, ptr %l30, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i32, ptr %l30, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t2 = load i32, ptr %l3, !tbaa !23
  store i32 %t2, ptr %l2, !tbaa !23
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t7, ptr %l6
  br label %bb2
bb2:
  store ptr %l6, ptr %l7, !tbaa !29
  store i32 18, ptr %l8
  store ptr %l8, ptr %l9, !tbaa !29
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t8, ptr %t9)
  store i1 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l12, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  store i32 %t14, ptr %l14, !tbaa !23
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i32, ptr %l14, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l15
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb6:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t20, ptr %l16
  br label %bb7
bb7:
  store ptr %l16, ptr %l17, !tbaa !29
  store i32 4, ptr %l18
  store ptr %l18, ptr %l19, !tbaa !29
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = load ptr, ptr %l19, !tbaa !29
  %t23 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %t21, ptr %t22)
  store i1 %t23, ptr %l20
  br label %bb8
bb8:
  %t24 = load i1, ptr %l20, !tbaa !21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t25 = load i1, ptr %l11, !tbaa !21
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  store i32 %t27, ptr %l23, !tbaa !23
  %t28 = load ptr, ptr %l22, !tbaa !29
  %t29 = load i32, ptr %l23, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t30, ptr %l24
  br label %bb12
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t31 = load i1, ptr %l24, !tbaa !21
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l21, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l25, !tbaa !21
  %t34 = load i1, ptr %l25, !tbaa !21
  br i1 %t34, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l26, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  store i32 %t36, ptr %l27, !tbaa !23
  %t37 = load ptr, ptr %l26, !tbaa !29
  %t38 = load i32, ptr %l27, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l28
  br label %bb17
bb17:
  %t40 = load i32, ptr %l28, !tbaa !23
  store i32 %t40, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb18:
  br label %bb1
bb19:
  %t41 = load i32, ptr %l2, !tbaa !23
  store i32 %t41, ptr %l29, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i32, ptr %l29, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 24
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l7, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = sext i32 %t9 to i64
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store { i64, ptr } %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp sgt i64 %t18, 0
  store i1 %t19, ptr %l13, !tbaa !21
  %t20 = load i1, ptr %l13, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 1
  %t26 = load i64, ptr %t25, !tbaa !34
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = add i64 2, %t27
  store i64 %t28, ptr %l18, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = load i64, ptr %l18, !tbaa !24
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = add i64 %t30, %t31
  store i64 %t32, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i64, ptr %t35, i64 %t33
  %t37 = load i64, ptr %t36, !tbaa !34
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i64, ptr %l14, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l71 = alloca [1 x i32]
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l12, !tbaa !23
  %t3 = load ptr, ptr %l11, !tbaa !29
  %t4 = load i32, ptr %l12, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i32, ptr %l13, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %l14, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t8, ptr %l15, !tbaa !23
  %t9 = load i32, ptr %l14, !tbaa !23
  %t10 = load i32, ptr %l15, !tbaa !23
  %t11 = icmp eq i32 %t9, %t10
  store i1 %t11, ptr %l16, !tbaa !21
  %t12 = load i1, ptr %l16, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = icmp sge i64 0, 0
  store i1 %t13, ptr %l17, !tbaa !21
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t15 = icmp sle i64 0, 2305843009213693951
  store i1 %t15, ptr %l18, !tbaa !21
  %t16 = load i1, ptr %l18, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c20)
  unreachable
bb6:
  %t17 = mul i64 0, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @.c20)
  unreachable
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  store i32 %t23, ptr %l21, !tbaa !23
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t25 = load i32, ptr %l21, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l22
  br label %bb9
bb9:
  store ptr %l22, ptr %l23, !tbaa !29
  store i32 22, ptr %l24
  store ptr %l24, ptr %l25, !tbaa !29
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t27, ptr %t28)
  store i1 %t29, ptr %l26
  br label %bb10
bb10:
  %t30 = load i1, ptr %l26, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l27, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l28, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  store i32 %t33, ptr %l29, !tbaa !23
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load i32, ptr %l29, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l30
  br label %bb13
bb12:
  br label %bb31
bb13:
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = load i32, ptr %l30, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l31
  br label %bb14
bb14:
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l32, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l33, !tbaa !24
  %t44 = load i64, ptr %l33, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  store i1 %t45, ptr %l34, !tbaa !21
  %t46 = load i1, ptr %l34, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t47 = load i64, ptr %l33, !tbaa !24
  %t48 = icmp sle i64 %t47, 2305843009213693951
  store i1 %t48, ptr %l35, !tbaa !21
  %t49 = load i1, ptr %l35, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb17:
  %t50 = load i64, ptr %l33, !tbaa !24
  %t51 = mul i64 %t50, 4
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t55, ptr %lp4
  %t56 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t57 = load ptr, ptr %lp4
  store { i64, ptr } %t56, ptr %t57, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l5, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l39, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l40, !tbaa !24
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = icmp sgt i64 %t64, %t65
  store i1 %t66, ptr %l41, !tbaa !21
  %t67 = load i1, ptr %l41, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb19:
  %t68 = load i64, ptr %l7, !tbaa !24
  store i64 %t68, ptr %l43, !tbaa !24
  %t69 = load i64, ptr %l43, !tbaa !24
  %t70 = icmp sgt i64 %t69, 0
  store i1 %t70, ptr %l44, !tbaa !21
  %t71 = load i1, ptr %l44, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb24
bb21:
  %t72 = load i64, ptr %l6, !tbaa !24
  store i64 %t72, ptr %l46, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  store i64 %t73, ptr %l47, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = sub i64 %t74, %t75
  store i64 %t76, ptr %l48, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  store i64 %t77, ptr %l49, !tbaa !24
  %t78 = load i64, ptr %l48, !tbaa !24
  %t79 = load i64, ptr %l49, !tbaa !24
  %t80 = add i64 %t78, %t79
  store i64 %t80, ptr %l50, !tbaa !24
  %t81 = load i64, ptr %l50, !tbaa !24
  %t82 = sub i64 %t81, 1
  store i64 %t82, ptr %l51, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  store i64 %t83, ptr %l52, !tbaa !24
  %t84 = load i64, ptr %l51, !tbaa !24
  %t85 = load i64, ptr %l52, !tbaa !24
  %t86 = sdiv i64 %t84, %t85
  store i64 %t86, ptr %l53, !tbaa !24
  %t87 = load i64, ptr %l53, !tbaa !24
  store i64 %t87, ptr %l45, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l45, !tbaa !24
  store i64 %t88, ptr %l42, !tbaa !24
  br label %bb24
bb24:
  %t89 = load i64, ptr %l42, !tbaa !24
  store i64 %t89, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load i64, ptr %l9, !tbaa !24
  store i64 %t90, ptr %l54, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  store i64 %t91, ptr %l55, !tbaa !24
  %t92 = load i64, ptr %l54, !tbaa !24
  %t93 = load i64, ptr %l55, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  store i1 %t94, ptr %l56, !tbaa !21
  %t95 = load i1, ptr %l56, !tbaa !21
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l57, !tbaa !21
  %t97 = load i1, ptr %l57, !tbaa !21
  br i1 %t97, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t98 = load i64, ptr %l5, !tbaa !24
  store i64 %t98, ptr %l58, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  store i64 %t99, ptr %l59, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  store i64 %t100, ptr %l60, !tbaa !24
  %t101 = load i64, ptr %l59, !tbaa !24
  %t102 = load i64, ptr %l60, !tbaa !24
  %t103 = mul i64 %t101, %t102
  store i64 %t103, ptr %l61, !tbaa !24
  %t104 = load i64, ptr %l58, !tbaa !24
  %t105 = load i64, ptr %l61, !tbaa !24
  %t106 = add i64 %t104, %t105
  store i64 %t106, ptr %l62, !tbaa !24
  %t107 = load i64, ptr %l62, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  store i64 %t108, ptr %l63, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %l64, !tbaa !27
  %t110 = load i64, ptr %l10, !tbaa !24
  store i64 %t110, ptr %l65, !tbaa !24
  %t111 = load i64, ptr %l65, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t111
  %t115 = load i32, ptr %t114, !tbaa !33
  store i32 %t115, ptr %l66, !tbaa !23
  %t116 = load i32, ptr %l66, !tbaa !23
  %t117 = load ptr, ptr %lp4
  %t118 = load i64, ptr %l63, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t118
  store i32 %t116, ptr %t121, !tbaa !33
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t122 = load i64, ptr %l9, !tbaa !24
  store i64 %t122, ptr %l67, !tbaa !24
  %t123 = load i64, ptr %l67, !tbaa !24
  %t124 = add i64 %t123, 1
  store i64 %t124, ptr %l68, !tbaa !24
  %t125 = load i64, ptr %l68, !tbaa !24
  store i64 %t125, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb30:
  call void @__olang_scope_close(ptr %s3)
  %t126 = load ptr, ptr %lp4
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t128 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t128, ptr %rv
  br label %ret
bb31:
  %t129 = load i32, ptr %l2, !tbaa !23
  store i32 %t129, ptr %l70, !tbaa !23
  %t130 = load i32, ptr %l70, !tbaa !23
  %t131 = insertvalue [1 x i32] undef, i32 %t130, 0
  store [1 x i32] %t131, ptr %l71
  %t132 = load [1 x i32], ptr %l71
  %t133 = load ptr, ptr @__olang_prog_scope
  %t134 = call ptr @__olang_scope_alloc(ptr %t133, i64 4)
  store [1 x i32] %t132, ptr %t134
  %t135 = insertvalue { i64, ptr } undef, i64 1, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l72, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  store i32 %t9, ptr %l9, !tbaa !23
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t13, i32 %t14)
  store { i64, ptr } %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp sgt i64 %t18, 0
  store i1 %t19, ptr %l13, !tbaa !21
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l3, !tbaa !21
  %t21 = load i32, ptr %l2, !tbaa !23
  store i32 %t21, ptr %l14, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t22, ptr %l15, !tbaa !23
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = icmp ne i32 %t23, %t24
  store i1 %t25, ptr %l16, !tbaa !21
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  store i32 %t28, ptr %l19, !tbaa !23
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i32, ptr %l19, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t31, ptr %l20
  br label %bb6
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l20, !tbaa !21
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load i1, ptr %l3, !tbaa !21
  store i1 %t34, ptr %l21, !tbaa !21
  %t35 = load i1, ptr %l21, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  store { i64, ptr } { i64 3, ptr @.d22 }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l24, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t37, ptr %l22, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr @.d23 }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l26, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t39, ptr %l22, !tbaa !27
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb13:
  %t41 = load i1, ptr %l3, !tbaa !21
  store i1 %t41, ptr %l27, !tbaa !21
  %t42 = load i1, ptr %l27, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l28, !tbaa !21
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l29, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  store i32 %t46, ptr %l30, !tbaa !23
  %t47 = load ptr, ptr %l29, !tbaa !29
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t47, i32 %t48)
  store { i64, ptr } %t49, ptr %l31
  br label %bb16
bb15:
  br label %bb17
bb16:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t50 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  call void @__olang_sb_put(ptr %s3, ptr %t51, i64 %t52)
  %t53 = load ptr, ptr %s3
  %t54 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t55 = load i64, ptr %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t53, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb17:
  %t60 = load i32, ptr %l2, !tbaa !23
  store i32 %t60, ptr %l33, !tbaa !23
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t61, ptr %l34, !tbaa !23
  %t62 = load i32, ptr %l33, !tbaa !23
  %t63 = load i32, ptr %l34, !tbaa !23
  %t64 = icmp eq i32 %t62, %t63
  store i1 %t64, ptr %l35, !tbaa !21
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 3, ptr @.d24 }, ptr %l36, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t66, ptr %l37, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l38, !tbaa !24
  %t69 = load i64, ptr %l38, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l39, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l38, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t80, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l40, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  store i32 %t83, ptr %l41, !tbaa !23
  %t84 = load ptr, ptr %l40, !tbaa !29
  %t85 = load i32, ptr %l41, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t84, i32 %t85)
  store { i64, ptr } %t86, ptr %l42
  br label %bb21
bb21:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t87 = extractvalue { i64, ptr } { i64 7, ptr @.d25 }, 1
  %t88 = extractvalue { i64, ptr } { i64 7, ptr @.d25 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t87, i64 %t88)
  %t89 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  call void @__olang_sb_put(ptr %s5, ptr %t90, i64 %t91)
  %t92 = extractvalue { i64, ptr } { i64 2, ptr @.d26 }, 1
  %t93 = extractvalue { i64, ptr } { i64 2, ptr @.d26 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t92, i64 %t93)
  %t94 = load ptr, ptr %s5
  %t95 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t96 = load i64, ptr %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t94, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l43, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 24
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l6, !tbaa !23
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l6, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = sext i32 %t9 to i64
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store { i64, ptr } %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp sgt i64 %t18, 0
  store i1 %t19, ptr %l12, !tbaa !21
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 0
  %t25 = load i64, ptr %t24, !tbaa !34
  store i64 %t25, ptr %l15, !tbaa !24
  %t26 = load i64, ptr %l15, !tbaa !24
  store i64 %t26, ptr %l13, !tbaa !24
  br label %bb5
bb4:
  %t27 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t27, ptr %l16, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l13, !tbaa !24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i64, ptr %l13, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %l7, !tbaa !23
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/list:List<I64>"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca [1 x i64]
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/list:List<I64>"
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i32
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i1
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca i32
  %l124 = alloca i1
  %l125 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i64
  %l128 = alloca i32
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l21, !tbaa !23
  %t3 = load ptr, ptr %l20, !tbaa !29
  %t4 = load i32, ptr %l21, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l23, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleDtor, !tbaa !24
  store i64 %t8, ptr %l24, !tbaa !24
  %t9 = load i64, ptr %l23, !tbaa !24
  %t10 = load i64, ptr %l24, !tbaa !24
  %t11 = icmp eq i64 %t9, %t10
  store i1 %t11, ptr %l25, !tbaa !21
  %t12 = load i1, ptr %l25, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  store i64 %t13, ptr %l26, !tbaa !24
  %t14 = load i64, ptr %l26, !tbaa !24
  %t15 = insertvalue [1 x i64] undef, i64 %t14, 0
  store [1 x i64] %t15, ptr %l27
  %t16 = load [1 x i64], ptr %l27
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call ptr @__olang_scope_alloc(ptr %t17, i64 8)
  store [1 x i64] %t16, ptr %t18
  %t19 = insertvalue { i64, ptr } undef, i64 1, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr @__olang_prog_scope
  %t23 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t22)
  store %"std/prelude/list:List<I64>" %t23, ptr %l29
  br label %bb5
bb5:
  %t24 = load %"std/prelude/list:List<I64>", ptr %l29
  store %"std/prelude/list:List<I64>" %t24, ptr %l3
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l30, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l31, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l32, !tbaa !23
  %t28 = load ptr, ptr %l31, !tbaa !29
  %t29 = load i32, ptr %l32, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l33
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l30, !tbaa !29
  %t32 = load i32, ptr %l33, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l34
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l5, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t35, ptr %l35, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l36, !tbaa !24
  %t38 = load i64, ptr %l36, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  store i64 %t39, ptr %l37, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  store i64 %t40, ptr %l38, !tbaa !24
  %t41 = load i64, ptr %l37, !tbaa !24
  %t42 = load i64, ptr %l38, !tbaa !24
  %t43 = icmp sgt i64 %t41, %t42
  store i1 %t43, ptr %l39, !tbaa !21
  %t44 = load i1, ptr %l39, !tbaa !21
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t45 = load i64, ptr %l7, !tbaa !24
  store i64 %t45, ptr %l41, !tbaa !24
  %t46 = load i64, ptr %l41, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  store i1 %t47, ptr %l42, !tbaa !21
  %t48 = load i1, ptr %l42, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb13
bb10:
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l44, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  store i64 %t50, ptr %l45, !tbaa !24
  %t51 = load i64, ptr %l44, !tbaa !24
  %t52 = load i64, ptr %l45, !tbaa !24
  %t53 = sub i64 %t51, %t52
  store i64 %t53, ptr %l46, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  store i64 %t54, ptr %l47, !tbaa !24
  %t55 = load i64, ptr %l46, !tbaa !24
  %t56 = load i64, ptr %l47, !tbaa !24
  %t57 = add i64 %t55, %t56
  store i64 %t57, ptr %l48, !tbaa !24
  %t58 = load i64, ptr %l48, !tbaa !24
  %t59 = sub i64 %t58, 1
  store i64 %t59, ptr %l49, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  store i64 %t60, ptr %l50, !tbaa !24
  %t61 = load i64, ptr %l49, !tbaa !24
  %t62 = load i64, ptr %l50, !tbaa !24
  %t63 = sdiv i64 %t61, %t62
  store i64 %t63, ptr %l51, !tbaa !24
  %t64 = load i64, ptr %l51, !tbaa !24
  store i64 %t64, ptr %l43, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb12
bb12:
  %t65 = load i64, ptr %l43, !tbaa !24
  store i64 %t65, ptr %l40, !tbaa !24
  br label %bb13
bb13:
  %t66 = load i64, ptr %l40, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9, !tbaa !24
  store i64 %t67, ptr %l52, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  store i64 %t68, ptr %l53, !tbaa !24
  %t69 = load i64, ptr %l52, !tbaa !24
  %t70 = load i64, ptr %l53, !tbaa !24
  %t71 = icmp slt i64 %t69, %t70
  store i1 %t71, ptr %l54, !tbaa !21
  %t72 = load i1, ptr %l54, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l55, !tbaa !21
  %t74 = load i1, ptr %l55, !tbaa !21
  br i1 %t74, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l5, !tbaa !24
  store i64 %t75, ptr %l56, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  store i64 %t76, ptr %l57, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  store i64 %t77, ptr %l58, !tbaa !24
  %t78 = load i64, ptr %l57, !tbaa !24
  %t79 = load i64, ptr %l58, !tbaa !24
  %t80 = mul i64 %t78, %t79
  store i64 %t80, ptr %l59, !tbaa !24
  %t81 = load i64, ptr %l56, !tbaa !24
  %t82 = load i64, ptr %l59, !tbaa !24
  %t83 = add i64 %t81, %t82
  store i64 %t83, ptr %l60, !tbaa !24
  %t84 = load i64, ptr %l60, !tbaa !24
  store i64 %t84, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l61, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  store i32 %t86, ptr %l62, !tbaa !23
  %t87 = load i64, ptr %l10, !tbaa !24
  store i64 %t87, ptr %l63, !tbaa !24
  %t88 = load ptr, ptr %l61, !tbaa !29
  %t89 = load i32, ptr %l62, !tbaa !23
  %t90 = load i64, ptr %l63, !tbaa !24
  %t91 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t88, i32 %t89, i64 %t90)
  store i64 %t91, ptr %l64
  br label %bb18
bb18:
  %t92 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t92, ptr %l65, !tbaa !24
  %t93 = load i64, ptr %l64, !tbaa !24
  %t94 = load i64, ptr %l65, !tbaa !24
  %t95 = icmp eq i64 %t93, %t94
  store i1 %t95, ptr %l66, !tbaa !21
  %t96 = load i1, ptr %l66, !tbaa !21
  br i1 %t96, label %bb19, label %bb20
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l68, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t98, ptr %l69, !tbaa !27
  %t99 = load i64, ptr %l10, !tbaa !24
  store i64 %t99, ptr %l70, !tbaa !24
  %t100 = load i64, ptr %l70, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 %t100
  %t104 = load i32, ptr %t103, !tbaa !33
  store i32 %t104, ptr %l71, !tbaa !23
  %t105 = load ptr, ptr %l68, !tbaa !29
  %t106 = load i32, ptr %l71, !tbaa !23
  %t107 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t107, ptr %l72
  br label %bb21
bb20:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb22
bb21:
  %t108 = load i1, ptr %l72, !tbaa !21
  store i1 %t108, ptr %l67, !tbaa !21
  br label %bb22
bb22:
  %t109 = load i1, ptr %l67, !tbaa !21
  br i1 %t109, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l73, !tbaa !29
  %t110 = load i64, ptr %l10, !tbaa !24
  store i64 %t110, ptr %l74, !tbaa !24
  %t111 = load ptr, ptr %l73, !tbaa !29
  %t112 = load i64, ptr %l74, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t111, i64 %t112)
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t113 = load i64, ptr %l9, !tbaa !24
  store i64 %t113, ptr %l75, !tbaa !24
  %t114 = load i64, ptr %l75, !tbaa !24
  %t115 = add i64 %t114, 1
  store i64 %t115, ptr %l76, !tbaa !24
  %t116 = load i64, ptr %l76, !tbaa !24
  store i64 %t116, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb28:
  call void @__olang_scope_close(ptr %s2)
  %t117 = load i64, ptr %l2, !tbaa !24
  store i64 %t117, ptr %l77, !tbaa !24
  %t118 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  store i64 %t118, ptr %l78, !tbaa !24
  %t119 = load i64, ptr %l77, !tbaa !24
  %t120 = load i64, ptr %l78, !tbaa !24
  %t121 = icmp eq i64 %t119, %t120
  store i1 %t121, ptr %l79, !tbaa !21
  %t122 = load i1, ptr %l79, !tbaa !21
  store i1 %t122, ptr %l11, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l80, !tbaa !29
  %t124 = load i32, ptr %l1, !tbaa !23
  store i32 %t124, ptr %l81, !tbaa !23
  %t125 = load ptr, ptr %l80, !tbaa !29
  %t126 = load i32, ptr %l81, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t125, i32 %t126)
  store { i64, ptr } %t127, ptr %l82
  br label %bb29
bb29:
  %t128 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t128, ptr %l12, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s6
  store i64 0, ptr %l13, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t129, ptr %l83, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l84, !tbaa !24
  %t132 = load i64, ptr %l84, !tbaa !24
  store i64 %t132, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t133 = load i64, ptr %l14, !tbaa !24
  store i64 %t133, ptr %l85, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  store i64 %t134, ptr %l86, !tbaa !24
  %t135 = load i64, ptr %l85, !tbaa !24
  %t136 = load i64, ptr %l86, !tbaa !24
  %t137 = icmp sgt i64 %t135, %t136
  store i1 %t137, ptr %l87, !tbaa !21
  %t138 = load i1, ptr %l87, !tbaa !21
  br i1 %t138, label %bb30, label %bb31
bb30:
  %t139 = load i64, ptr %l15, !tbaa !24
  store i64 %t139, ptr %l89, !tbaa !24
  %t140 = load i64, ptr %l89, !tbaa !24
  %t141 = icmp sgt i64 %t140, 0
  store i1 %t141, ptr %l90, !tbaa !21
  %t142 = load i1, ptr %l90, !tbaa !21
  br i1 %t142, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb35
bb32:
  %t143 = load i64, ptr %l14, !tbaa !24
  store i64 %t143, ptr %l92, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  store i64 %t144, ptr %l93, !tbaa !24
  %t145 = load i64, ptr %l92, !tbaa !24
  %t146 = load i64, ptr %l93, !tbaa !24
  %t147 = sub i64 %t145, %t146
  store i64 %t147, ptr %l94, !tbaa !24
  %t148 = load i64, ptr %l15, !tbaa !24
  store i64 %t148, ptr %l95, !tbaa !24
  %t149 = load i64, ptr %l94, !tbaa !24
  %t150 = load i64, ptr %l95, !tbaa !24
  %t151 = add i64 %t149, %t150
  store i64 %t151, ptr %l96, !tbaa !24
  %t152 = load i64, ptr %l96, !tbaa !24
  %t153 = sub i64 %t152, 1
  store i64 %t153, ptr %l97, !tbaa !24
  %t154 = load i64, ptr %l15, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  %t155 = load i64, ptr %l97, !tbaa !24
  %t156 = load i64, ptr %l98, !tbaa !24
  %t157 = sdiv i64 %t155, %t156
  store i64 %t157, ptr %l99, !tbaa !24
  %t158 = load i64, ptr %l99, !tbaa !24
  store i64 %t158, ptr %l91, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb34
bb34:
  %t159 = load i64, ptr %l91, !tbaa !24
  store i64 %t159, ptr %l88, !tbaa !24
  br label %bb35
bb35:
  %t160 = load i64, ptr %l88, !tbaa !24
  store i64 %t160, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t161 = load i64, ptr %l17, !tbaa !24
  store i64 %t161, ptr %l100, !tbaa !24
  %t162 = load i64, ptr %l16, !tbaa !24
  store i64 %t162, ptr %l101, !tbaa !24
  %t163 = load i64, ptr %l100, !tbaa !24
  %t164 = load i64, ptr %l101, !tbaa !24
  %t165 = icmp slt i64 %t163, %t164
  store i1 %t165, ptr %l102, !tbaa !21
  %t166 = load i1, ptr %l102, !tbaa !21
  %t167 = xor i1 %t166, true
  store i1 %t167, ptr %l103, !tbaa !21
  %t168 = load i1, ptr %l103, !tbaa !21
  br i1 %t168, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb38:
  br label %bb39
bb39:
  %t169 = load i64, ptr %l13, !tbaa !24
  store i64 %t169, ptr %l104, !tbaa !24
  %t170 = load i64, ptr %l17, !tbaa !24
  store i64 %t170, ptr %l105, !tbaa !24
  %t171 = load i64, ptr %l15, !tbaa !24
  store i64 %t171, ptr %l106, !tbaa !24
  %t172 = load i64, ptr %l105, !tbaa !24
  %t173 = load i64, ptr %l106, !tbaa !24
  %t174 = mul i64 %t172, %t173
  store i64 %t174, ptr %l107, !tbaa !24
  %t175 = load i64, ptr %l104, !tbaa !24
  %t176 = load i64, ptr %l107, !tbaa !24
  %t177 = add i64 %t175, %t176
  store i64 %t177, ptr %l108, !tbaa !24
  %t178 = load i64, ptr %l108, !tbaa !24
  store i64 %t178, ptr %l18, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l109, !tbaa !29
  %t180 = load i32, ptr %l1, !tbaa !23
  store i32 %t180, ptr %l110, !tbaa !23
  %t181 = load i64, ptr %l18, !tbaa !24
  store i64 %t181, ptr %l111, !tbaa !24
  %t182 = load ptr, ptr %l109, !tbaa !29
  %t183 = load i32, ptr %l110, !tbaa !23
  %t184 = load i64, ptr %l111, !tbaa !24
  %t185 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t182, i32 %t183, i64 %t184)
  store i64 %t185, ptr %l112
  br label %bb40
bb40:
  %t186 = load i64, ptr %l112, !tbaa !24
  store i64 %t186, ptr %l19, !tbaa !24
  %t187 = load i64, ptr %l19, !tbaa !24
  store i64 %t187, ptr %l113, !tbaa !24
  %t188 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t188, ptr %l114, !tbaa !24
  %t189 = load i64, ptr %l113, !tbaa !24
  %t190 = load i64, ptr %l114, !tbaa !24
  %t191 = icmp eq i64 %t189, %t190
  store i1 %t191, ptr %l115, !tbaa !21
  %t192 = load i1, ptr %l115, !tbaa !21
  br i1 %t192, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb43
bb42:
  %t193 = load i64, ptr %l19, !tbaa !24
  store i64 %t193, ptr %l117, !tbaa !24
  %t194 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  store i64 %t194, ptr %l118, !tbaa !24
  %t195 = load i64, ptr %l117, !tbaa !24
  %t196 = load i64, ptr %l118, !tbaa !24
  %t197 = icmp eq i64 %t195, %t196
  store i1 %t197, ptr %l119, !tbaa !21
  %t198 = load i1, ptr %l119, !tbaa !21
  store i1 %t198, ptr %l116, !tbaa !21
  br label %bb43
bb43:
  %t199 = load i1, ptr %l116, !tbaa !21
  br i1 %t199, label %bb44, label %bb45
bb44:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l121, !tbaa !29
  %t201 = load i64, ptr %l18, !tbaa !24
  store i64 %t201, ptr %l122, !tbaa !24
  %t202 = load i64, ptr %l122, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i32, ptr %t204, i64 %t202
  %t206 = load i32, ptr %t205, !tbaa !33
  store i32 %t206, ptr %l123, !tbaa !23
  %t207 = load ptr, ptr %l121, !tbaa !29
  %t208 = load i32, ptr %l123, !tbaa !23
  %t209 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t207, i32 %t208)
  store i1 %t209, ptr %l124
  br label %bb46
bb45:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb51
bb46:
  %t210 = load i1, ptr %l124, !tbaa !21
  br i1 %t210, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb50
bb48:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l126, !tbaa !29
  %t212 = load i64, ptr %l18, !tbaa !24
  store i64 %t212, ptr %l127, !tbaa !24
  %t213 = load i64, ptr %l127, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i32, ptr %t215, i64 %t213
  %t217 = load i32, ptr %t216, !tbaa !33
  store i32 %t217, ptr %l128, !tbaa !23
  %t218 = load ptr, ptr %l126, !tbaa !29
  %t219 = load i32, ptr %l128, !tbaa !23
  %t220 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t218, i32 %t219)
  store i1 %t220, ptr %l129
  br label %bb49
bb49:
  %t221 = load i1, ptr %l129, !tbaa !21
  store i1 %t221, ptr %l125, !tbaa !21
  br label %bb50
bb50:
  %t222 = load i1, ptr %l125, !tbaa !21
  store i1 %t222, ptr %l120, !tbaa !21
  br label %bb51
bb51:
  %t223 = load i1, ptr %l120, !tbaa !21
  br i1 %t223, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s8
  store i1 true, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb54
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t224 = load i64, ptr %l17, !tbaa !24
  store i64 %t224, ptr %l130, !tbaa !24
  %t225 = load i64, ptr %l130, !tbaa !24
  %t226 = add i64 %t225, 1
  store i64 %t226, ptr %l131, !tbaa !24
  %t227 = load i64, ptr %l131, !tbaa !24
  store i64 %t227, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb56:
  call void @__olang_scope_close(ptr %s6)
  %t228 = load i1, ptr %l11, !tbaa !21
  store i1 %t228, ptr %l132, !tbaa !21
  %t229 = load i1, ptr %l132, !tbaa !21
  br i1 %t229, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l3, ptr %l133, !tbaa !29
  %t230 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  store i64 %t230, ptr %l134, !tbaa !24
  %t231 = load ptr, ptr %l133, !tbaa !29
  %t232 = load i64, ptr %l134, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t231, i64 %t232)
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  store ptr %l3, ptr %l135, !tbaa !29
  %t233 = load ptr, ptr %l135, !tbaa !29
  %t234 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v1, ptr %t233)
  store { i64, ptr } %t234, ptr %l136
  br label %bb61
bb61:
  %t235 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t235, ptr %l137, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  store i64 %t237, ptr %l138, !tbaa !24
  %t238 = load i64, ptr %l138, !tbaa !24
  %t239 = mul i64 %t238, 8
  %t240 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t239)
  %t241 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l139, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = load i64, ptr %l138, !tbaa !24
  %t248 = mul i64 %t247, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t244, ptr %t246, i64 %t248, i1 false)
  %t249 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t249, ptr %l137, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t250 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t250, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i1
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i64
  %l144 = alloca i64
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i32
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l160 = alloca i32
  %l161 = alloca i32
  %l162 = alloca i32
  %l163 = alloca i1
  %l164 = alloca i32
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca i64
  %l168 = alloca i32
  %l169 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l176 = alloca i32
  %l177 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l29, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t2, ptr %l30, !tbaa !24
  %t3 = load i64, ptr %l29, !tbaa !24
  %t4 = load i64, ptr %l30, !tbaa !24
  %t5 = icmp eq i64 %t3, %t4
  store i1 %t5, ptr %l31, !tbaa !21
  %t6 = load i1, ptr %l31, !tbaa !21
  store i1 %t6, ptr %l4, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l32, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t9, ptr %l33, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l34, !tbaa !24
  %t12 = load i64, ptr %l34, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l6, !tbaa !24
  store i64 %t13, ptr %l35, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l36, !tbaa !24
  %t15 = load i64, ptr %l35, !tbaa !24
  %t16 = load i64, ptr %l36, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  store i1 %t17, ptr %l37, !tbaa !21
  %t18 = load i1, ptr %l37, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l38, !tbaa !21
  %t20 = load i1, ptr %l38, !tbaa !21
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l39, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  store i64 %t22, ptr %l40, !tbaa !24
  %t23 = load i64, ptr %l40, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i64, ptr %t25, i64 %t23
  %t27 = load i64, ptr %t26, !tbaa !34
  store i64 %t27, ptr %l41, !tbaa !24
  %t28 = load i64, ptr %l41, !tbaa !24
  store i64 %t28, ptr %l8, !tbaa !24
  %t29 = load i1, ptr %l4, !tbaa !21
  store i1 %t29, ptr %l42, !tbaa !21
  %t30 = load i1, ptr %l42, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l8, !tbaa !24
  store i64 %t31, ptr %l44, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t32, ptr %l45, !tbaa !24
  %t33 = load i64, ptr %l44, !tbaa !24
  %t34 = load i64, ptr %l45, !tbaa !24
  %t35 = icmp eq i64 %t33, %t34
  store i1 %t35, ptr %l46, !tbaa !21
  %t36 = load i1, ptr %l46, !tbaa !21
  store i1 %t36, ptr %l43, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb7
bb7:
  %t37 = load i1, ptr %l43, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l6, !tbaa !24
  store i64 %t38, ptr %l47, !tbaa !24
  %t39 = load i64, ptr %l47, !tbaa !24
  %t40 = add i64 %t39, 1
  store i64 %t40, ptr %l48, !tbaa !24
  %t41 = load i64, ptr %l48, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb1
bb9:
  call void @__olang_scope_close(ptr %s1)
  store %olang.scope zeroinitializer, ptr %s4
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l49, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t43, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t44, ptr %l50, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l51, !tbaa !24
  %t47 = load i64, ptr %l51, !tbaa !24
  store i64 %t47, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load i64, ptr %l10, !tbaa !24
  store i64 %t48, ptr %l52, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  store i64 %t49, ptr %l53, !tbaa !24
  %t50 = load i64, ptr %l52, !tbaa !24
  %t51 = load i64, ptr %l53, !tbaa !24
  %t52 = icmp slt i64 %t50, %t51
  store i1 %t52, ptr %l54, !tbaa !21
  %t53 = load i1, ptr %l54, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l55, !tbaa !21
  %t55 = load i1, ptr %l55, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l56, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  store i64 %t57, ptr %l57, !tbaa !24
  %t58 = load i64, ptr %l57, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t58
  %t62 = load i64, ptr %t61, !tbaa !34
  store i64 %t62, ptr %l58, !tbaa !24
  %t63 = load i64, ptr %l58, !tbaa !24
  store i64 %t63, ptr %l12, !tbaa !24
  %t64 = load i1, ptr %l4, !tbaa !21
  store i1 %t64, ptr %l59, !tbaa !21
  %t65 = load i1, ptr %l59, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t66 = load i64, ptr %l12, !tbaa !24
  store i64 %t66, ptr %l61, !tbaa !24
  %t67 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t67, ptr %l62, !tbaa !24
  %t68 = load i64, ptr %l61, !tbaa !24
  %t69 = load i64, ptr %l62, !tbaa !24
  %t70 = icmp eq i64 %t68, %t69
  store i1 %t70, ptr %l63, !tbaa !21
  %t71 = load i1, ptr %l63, !tbaa !21
  store i1 %t71, ptr %l60, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l60, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t73 = load i64, ptr %l10, !tbaa !24
  store i64 %t73, ptr %l64, !tbaa !24
  %t74 = load i64, ptr %l64, !tbaa !24
  %t75 = add i64 %t74, 1
  store i64 %t75, ptr %l65, !tbaa !24
  %t76 = load i64, ptr %l65, !tbaa !24
  store i64 %t76, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb10
bb18:
  call void @__olang_scope_close(ptr %s4)
  %t77 = load i1, ptr %l4, !tbaa !21
  store i1 %t77, ptr %l66, !tbaa !21
  %t78 = load i1, ptr %l66, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 0, ptr %l67, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t79 = load i32, ptr %l67, !tbaa !23
  store i32 %t79, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t80, ptr %l68, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l69, !tbaa !24
  %t83 = load i64, ptr %l69, !tbaa !24
  %t84 = add i64 2, %t83
  store i64 %t84, ptr %l70, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t85, ptr %l71, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l72, !tbaa !24
  %t88 = load i64, ptr %l70, !tbaa !24
  %t89 = load i64, ptr %l72, !tbaa !24
  %t90 = add i64 %t88, %t89
  store i64 %t90, ptr %l73, !tbaa !24
  %t91 = load i64, ptr %l73, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  store i1 %t92, ptr %l74, !tbaa !21
  %t93 = load i1, ptr %l74, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = icmp sle i64 %t94, 1152921504606846975
  store i1 %t95, ptr %l75, !tbaa !21
  %t96 = load i1, ptr %l75, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb24:
  %t97 = load i64, ptr %l73, !tbaa !24
  %t98 = mul i64 %t97, 8
  %t99 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l76, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 8
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l77, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t109, ptr %l13, !tbaa !27
  %t110 = load i64, ptr %l1, !tbaa !24
  store i64 %t110, ptr %l78, !tbaa !24
  %t111 = load i64, ptr %l78, !tbaa !24
  store i64 %t111, ptr %l14, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t112, ptr %l79, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l80, !tbaa !24
  %t115 = load i64, ptr %l80, !tbaa !24
  store i64 %t115, ptr %l15, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t116, ptr %l81, !tbaa !27
  %t117 = load i64, ptr %l14, !tbaa !24
  store i64 %t117, ptr %l82, !tbaa !24
  %t118 = load i64, ptr %l82, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i64, ptr %t120, i64 0
  store i64 %t118, ptr %t121, !tbaa !34
  %t122 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t122, ptr %l83, !tbaa !27
  %t123 = load i64, ptr %l15, !tbaa !24
  store i64 %t123, ptr %l84, !tbaa !24
  %t124 = load i64, ptr %l84, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i64, ptr %t126, i64 1
  store i64 %t124, ptr %t127, !tbaa !34
  store %olang.scope zeroinitializer, ptr %s8
  store i64 0, ptr %l16, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t128, ptr %l85, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l86, !tbaa !24
  %t131 = load i64, ptr %l86, !tbaa !24
  store i64 %t131, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t132 = load i64, ptr %l17, !tbaa !24
  store i64 %t132, ptr %l87, !tbaa !24
  %t133 = load i64, ptr %l16, !tbaa !24
  store i64 %t133, ptr %l88, !tbaa !24
  %t134 = load i64, ptr %l87, !tbaa !24
  %t135 = load i64, ptr %l88, !tbaa !24
  %t136 = icmp sgt i64 %t134, %t135
  store i1 %t136, ptr %l89, !tbaa !21
  %t137 = load i1, ptr %l89, !tbaa !21
  br i1 %t137, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb26:
  %t138 = load i64, ptr %l18, !tbaa !24
  store i64 %t138, ptr %l91, !tbaa !24
  %t139 = load i64, ptr %l91, !tbaa !24
  %t140 = icmp sgt i64 %t139, 0
  store i1 %t140, ptr %l92, !tbaa !21
  %t141 = load i1, ptr %l92, !tbaa !21
  br i1 %t141, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb31
bb28:
  %t142 = load i64, ptr %l17, !tbaa !24
  store i64 %t142, ptr %l94, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  store i64 %t143, ptr %l95, !tbaa !24
  %t144 = load i64, ptr %l94, !tbaa !24
  %t145 = load i64, ptr %l95, !tbaa !24
  %t146 = sub i64 %t144, %t145
  store i64 %t146, ptr %l96, !tbaa !24
  %t147 = load i64, ptr %l18, !tbaa !24
  store i64 %t147, ptr %l97, !tbaa !24
  %t148 = load i64, ptr %l96, !tbaa !24
  %t149 = load i64, ptr %l97, !tbaa !24
  %t150 = add i64 %t148, %t149
  store i64 %t150, ptr %l98, !tbaa !24
  %t151 = load i64, ptr %l98, !tbaa !24
  %t152 = sub i64 %t151, 1
  store i64 %t152, ptr %l99, !tbaa !24
  %t153 = load i64, ptr %l18, !tbaa !24
  store i64 %t153, ptr %l100, !tbaa !24
  %t154 = load i64, ptr %l99, !tbaa !24
  %t155 = load i64, ptr %l100, !tbaa !24
  %t156 = sdiv i64 %t154, %t155
  store i64 %t156, ptr %l101, !tbaa !24
  %t157 = load i64, ptr %l101, !tbaa !24
  store i64 %t157, ptr %l93, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb30
bb30:
  %t158 = load i64, ptr %l93, !tbaa !24
  store i64 %t158, ptr %l90, !tbaa !24
  br label %bb31
bb31:
  %t159 = load i64, ptr %l90, !tbaa !24
  store i64 %t159, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t160 = load i64, ptr %l20, !tbaa !24
  store i64 %t160, ptr %l102, !tbaa !24
  %t161 = load i64, ptr %l19, !tbaa !24
  store i64 %t161, ptr %l103, !tbaa !24
  %t162 = load i64, ptr %l102, !tbaa !24
  %t163 = load i64, ptr %l103, !tbaa !24
  %t164 = icmp slt i64 %t162, %t163
  store i1 %t164, ptr %l104, !tbaa !21
  %t165 = load i1, ptr %l104, !tbaa !21
  %t166 = xor i1 %t165, true
  store i1 %t166, ptr %l105, !tbaa !21
  %t167 = load i1, ptr %l105, !tbaa !21
  br i1 %t167, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t168 = load i64, ptr %l16, !tbaa !24
  store i64 %t168, ptr %l106, !tbaa !24
  %t169 = load i64, ptr %l20, !tbaa !24
  store i64 %t169, ptr %l107, !tbaa !24
  %t170 = load i64, ptr %l18, !tbaa !24
  store i64 %t170, ptr %l108, !tbaa !24
  %t171 = load i64, ptr %l107, !tbaa !24
  %t172 = load i64, ptr %l108, !tbaa !24
  %t173 = mul i64 %t171, %t172
  store i64 %t173, ptr %l109, !tbaa !24
  %t174 = load i64, ptr %l106, !tbaa !24
  %t175 = load i64, ptr %l109, !tbaa !24
  %t176 = add i64 %t174, %t175
  store i64 %t176, ptr %l110, !tbaa !24
  %t177 = load i64, ptr %l110, !tbaa !24
  store i64 %t177, ptr %l21, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t178, ptr %l111, !tbaa !27
  %t179 = load i64, ptr %l21, !tbaa !24
  store i64 %t179, ptr %l112, !tbaa !24
  %t180 = load i64, ptr %l112, !tbaa !24
  %t181 = add i64 2, %t180
  store i64 %t181, ptr %l113, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t182, ptr %l114, !tbaa !27
  %t183 = load i64, ptr %l21, !tbaa !24
  store i64 %t183, ptr %l115, !tbaa !24
  %t184 = load i64, ptr %l115, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i64, ptr %t186, i64 %t184
  %t188 = load i64, ptr %t187, !tbaa !34
  store i64 %t188, ptr %l116, !tbaa !24
  %t189 = load i64, ptr %l116, !tbaa !24
  %t190 = load i64, ptr %l113, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i64, ptr %t192, i64 %t190
  store i64 %t189, ptr %t193, !tbaa !34
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s10
  %t194 = load i64, ptr %l20, !tbaa !24
  store i64 %t194, ptr %l117, !tbaa !24
  %t195 = load i64, ptr %l117, !tbaa !24
  %t196 = add i64 %t195, 1
  store i64 %t196, ptr %l118, !tbaa !24
  %t197 = load i64, ptr %l118, !tbaa !24
  store i64 %t197, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb32
bb37:
  call void @__olang_scope_close(ptr %s8)
  store %olang.scope zeroinitializer, ptr %s11
  store i64 0, ptr %l22, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t198, ptr %l119, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l120, !tbaa !24
  %t201 = load i64, ptr %l120, !tbaa !24
  store i64 %t201, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t202 = load i64, ptr %l23, !tbaa !24
  store i64 %t202, ptr %l121, !tbaa !24
  %t203 = load i64, ptr %l22, !tbaa !24
  store i64 %t203, ptr %l122, !tbaa !24
  %t204 = load i64, ptr %l121, !tbaa !24
  %t205 = load i64, ptr %l122, !tbaa !24
  %t206 = icmp sgt i64 %t204, %t205
  store i1 %t206, ptr %l123, !tbaa !21
  %t207 = load i1, ptr %l123, !tbaa !21
  br i1 %t207, label %bb38, label %bb39
bb38:
  %t208 = load i64, ptr %l24, !tbaa !24
  store i64 %t208, ptr %l125, !tbaa !24
  %t209 = load i64, ptr %l125, !tbaa !24
  %t210 = icmp sgt i64 %t209, 0
  store i1 %t210, ptr %l126, !tbaa !21
  %t211 = load i1, ptr %l126, !tbaa !21
  br i1 %t211, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb43
bb40:
  %t212 = load i64, ptr %l23, !tbaa !24
  store i64 %t212, ptr %l128, !tbaa !24
  %t213 = load i64, ptr %l22, !tbaa !24
  store i64 %t213, ptr %l129, !tbaa !24
  %t214 = load i64, ptr %l128, !tbaa !24
  %t215 = load i64, ptr %l129, !tbaa !24
  %t216 = sub i64 %t214, %t215
  store i64 %t216, ptr %l130, !tbaa !24
  %t217 = load i64, ptr %l24, !tbaa !24
  store i64 %t217, ptr %l131, !tbaa !24
  %t218 = load i64, ptr %l130, !tbaa !24
  %t219 = load i64, ptr %l131, !tbaa !24
  %t220 = add i64 %t218, %t219
  store i64 %t220, ptr %l132, !tbaa !24
  %t221 = load i64, ptr %l132, !tbaa !24
  %t222 = sub i64 %t221, 1
  store i64 %t222, ptr %l133, !tbaa !24
  %t223 = load i64, ptr %l24, !tbaa !24
  store i64 %t223, ptr %l134, !tbaa !24
  %t224 = load i64, ptr %l133, !tbaa !24
  %t225 = load i64, ptr %l134, !tbaa !24
  %t226 = sdiv i64 %t224, %t225
  store i64 %t226, ptr %l135, !tbaa !24
  %t227 = load i64, ptr %l135, !tbaa !24
  store i64 %t227, ptr %l127, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb42
bb42:
  %t228 = load i64, ptr %l127, !tbaa !24
  store i64 %t228, ptr %l124, !tbaa !24
  br label %bb43
bb43:
  %t229 = load i64, ptr %l124, !tbaa !24
  store i64 %t229, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s12
  %t230 = load i64, ptr %l26, !tbaa !24
  store i64 %t230, ptr %l136, !tbaa !24
  %t231 = load i64, ptr %l25, !tbaa !24
  store i64 %t231, ptr %l137, !tbaa !24
  %t232 = load i64, ptr %l136, !tbaa !24
  %t233 = load i64, ptr %l137, !tbaa !24
  %t234 = icmp slt i64 %t232, %t233
  store i1 %t234, ptr %l138, !tbaa !21
  %t235 = load i1, ptr %l138, !tbaa !21
  %t236 = xor i1 %t235, true
  store i1 %t236, ptr %l139, !tbaa !21
  %t237 = load i1, ptr %l139, !tbaa !21
  br i1 %t237, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t238 = load i64, ptr %l22, !tbaa !24
  store i64 %t238, ptr %l140, !tbaa !24
  %t239 = load i64, ptr %l26, !tbaa !24
  store i64 %t239, ptr %l141, !tbaa !24
  %t240 = load i64, ptr %l24, !tbaa !24
  store i64 %t240, ptr %l142, !tbaa !24
  %t241 = load i64, ptr %l141, !tbaa !24
  %t242 = load i64, ptr %l142, !tbaa !24
  %t243 = mul i64 %t241, %t242
  store i64 %t243, ptr %l143, !tbaa !24
  %t244 = load i64, ptr %l140, !tbaa !24
  %t245 = load i64, ptr %l143, !tbaa !24
  %t246 = add i64 %t244, %t245
  store i64 %t246, ptr %l144, !tbaa !24
  %t247 = load i64, ptr %l144, !tbaa !24
  store i64 %t247, ptr %l27, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t248, ptr %l145, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t249, ptr %l146, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  store i64 %t251, ptr %l147, !tbaa !24
  %t252 = load i64, ptr %l147, !tbaa !24
  %t253 = add i64 2, %t252
  store i64 %t253, ptr %l148, !tbaa !24
  %t254 = load i64, ptr %l27, !tbaa !24
  store i64 %t254, ptr %l149, !tbaa !24
  %t255 = load i64, ptr %l148, !tbaa !24
  %t256 = load i64, ptr %l149, !tbaa !24
  %t257 = add i64 %t255, %t256
  store i64 %t257, ptr %l150, !tbaa !24
  %t258 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t258, ptr %l151, !tbaa !27
  %t259 = load i64, ptr %l27, !tbaa !24
  store i64 %t259, ptr %l152, !tbaa !24
  %t260 = load i64, ptr %l152, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr i64, ptr %t262, i64 %t260
  %t264 = load i64, ptr %t263, !tbaa !34
  store i64 %t264, ptr %l153, !tbaa !24
  %t265 = load i64, ptr %l153, !tbaa !24
  %t266 = load i64, ptr %l150, !tbaa !24
  %t267 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr i64, ptr %t268, i64 %t266
  store i64 %t265, ptr %t269, !tbaa !34
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s13
  %t270 = load i64, ptr %l26, !tbaa !24
  store i64 %t270, ptr %l154, !tbaa !24
  %t271 = load i64, ptr %l154, !tbaa !24
  %t272 = add i64 %t271, 1
  store i64 %t272, ptr %l155, !tbaa !24
  %t273 = load i64, ptr %l155, !tbaa !24
  store i64 %t273, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb44
bb49:
  call void @__olang_scope_close(ptr %s11)
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l157, !tbaa !29
  %t275 = load ptr, ptr %l157, !tbaa !29
  %t276 = getelementptr %"compiler/types:Table", ptr %t275, i32 0, i32 25
  store ptr %t276, ptr %l158, !tbaa !29
  %t277 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t277, ptr %l159, !tbaa !27
  %t278 = load ptr, ptr %l158, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t280 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v0, ptr %t278, { i64, ptr } %t279)
  %t281 = extractvalue { i32, i32 } %t280, 1
  %t282 = extractvalue { i32, i32 } %t280, 0
  store i32 %t282, ptr %l161
  %t283 = icmp ne i32 %t282, 0
  br i1 %t283, label %bb51, label %ok.284
ok.284:
  store i32 %t281, ptr %l160
  br label %bb50
bb50:
  %t285 = load i32, ptr %l160, !tbaa !23
  store i32 %t285, ptr %l156, !tbaa !23
  br label %bb53
bb51:
  br label %bb52
bb52:
  store i32 -1, ptr %l156, !tbaa !23
  br label %bb53
bb53:
  %t286 = load i32, ptr %l156, !tbaa !23
  store i32 %t286, ptr %l28, !tbaa !23
  %t287 = load i32, ptr %l28, !tbaa !23
  store i32 %t287, ptr %l162, !tbaa !23
  %t288 = load i32, ptr %l162, !tbaa !23
  %t289 = icmp sge i32 %t288, 0
  store i1 %t289, ptr %l163, !tbaa !21
  %t290 = load i1, ptr %l163, !tbaa !21
  br i1 %t290, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s14
  %t291 = load i32, ptr %l28, !tbaa !23
  store i32 %t291, ptr %l164, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t292 = load i32, ptr %l164, !tbaa !23
  store i32 %t292, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l165, !tbaa !29
  %t294 = load ptr, ptr %l165, !tbaa !29
  %t295 = getelementptr %"compiler/types:Table", ptr %t294, i32 0, i32 24
  store ptr %t295, ptr %l166, !tbaa !29
  %t296 = load ptr, ptr %l166, !tbaa !29
  %t297 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t296)
  store i64 %t297, ptr %l167
  br label %bb57
bb57:
  %t298 = load i64, ptr %l167, !tbaa !24
  %t299 = trunc i64 %t298 to i32
  store i32 %t299, ptr %l168, !tbaa !23
  %t300 = load i32, ptr %l168, !tbaa !23
  store i32 %t300, ptr %l169, !tbaa !23
  %t301 = load i32, ptr %l169, !tbaa !23
  store i32 %t301, ptr %l28, !tbaa !23
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l170, !tbaa !29
  %t303 = load ptr, ptr %l170, !tbaa !29
  %t304 = getelementptr %"compiler/types:Table", ptr %t303, i32 0, i32 24
  store ptr %t304, ptr %l171, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t305, ptr %l172, !tbaa !27
  %t306 = load ptr, ptr %l171, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l172, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t306, { i64, ptr } %t307)
  br label %bb58
bb58:
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l173, !tbaa !29
  %t309 = load ptr, ptr %l173, !tbaa !29
  %t310 = getelementptr %"compiler/types:Table", ptr %t309, i32 0, i32 25
  store ptr %t310, ptr %l174, !tbaa !29
  %t311 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t311, ptr %l175, !tbaa !27
  %t312 = load i32, ptr %l28, !tbaa !23
  store i32 %t312, ptr %l176, !tbaa !23
  %t313 = load ptr, ptr %l174, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t315 = load i32, ptr %l176, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v0, ptr %t313, { i64, ptr } %t314, i32 %t315)
  br label %bb59
bb59:
  %t316 = load i32, ptr %l28, !tbaa !23
  store i32 %t316, ptr %l177, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t317 = load i32, ptr %l177, !tbaa !23
  store i32 %t317, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i1
  %l94 = alloca i1
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i32
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca i32
  %l117 = alloca i1
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i1
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i1
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i64
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l155 = alloca { i64, ptr }
  %l156 = alloca i64
  %l157 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i64
  %l161 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i64
  %l167 = alloca i64
  %l168 = alloca i1
  %l169 = alloca i1
  %l170 = alloca i64
  %l171 = alloca i64
  %l172 = alloca i1
  %l173 = alloca i1
  %l174 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i1
  %l181 = alloca i1
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i1
  %l185 = alloca i1
  %l186 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i64
  %l189 = alloca i32
  %l190 = alloca i64
  %l191 = alloca i32
  %l192 = alloca i1
  %l193 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i1
  %l198 = alloca i32
  %l199 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca i32
  %l203 = alloca i32
  %l204 = alloca ptr
  %l205 = alloca i32
  %l206 = alloca i32
  %l207 = alloca i1
  %l208 = alloca i32
  %l209 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca i32
  %l214 = alloca ptr
  %l215 = alloca i32
  %l216 = alloca i32
  %l217 = alloca i1
  %l218 = alloca i32
  %l219 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca ptr
  %l222 = alloca i32
  %l223 = alloca i32
  %l224 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l226 = alloca ptr
  %l227 = alloca i32
  %l228 = alloca i32
  %l229 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca i64
  %l232 = alloca i64
  %l233 = alloca i64
  %l234 = alloca i1
  %l235 = alloca i64
  %l236 = alloca i64
  %l237 = alloca i1
  %l238 = alloca i64
  %l239 = alloca i64
  %l240 = alloca i64
  %l241 = alloca i64
  %l242 = alloca i64
  %l243 = alloca i64
  %l244 = alloca i64
  %l245 = alloca i64
  %l246 = alloca i64
  %l247 = alloca i64
  %l248 = alloca i64
  %l249 = alloca i1
  %l250 = alloca i1
  %l251 = alloca i64
  %l252 = alloca i64
  %l253 = alloca i64
  %l254 = alloca i64
  %l255 = alloca i64
  %l256 = alloca i64
  %l257 = alloca { i64, ptr }
  %l258 = alloca i64
  %l259 = alloca i1
  %l260 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca { i64, ptr }
  %l263 = alloca i64
  %l264 = alloca i32
  %l265 = alloca { i64, ptr }
  %l266 = alloca i64
  %l267 = alloca i32
  %l268 = alloca i1
  %l269 = alloca i1
  %l270 = alloca i1
  %l271 = alloca i64
  %l272 = alloca i64
  %l273 = alloca i1
  %l274 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l30, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l31, !tbaa !23
  %t3 = load i32, ptr %l30, !tbaa !23
  %t4 = load i32, ptr %l31, !tbaa !23
  %t5 = icmp eq i32 %t3, %t4
  store i1 %t5, ptr %l32, !tbaa !21
  %t6 = load i1, ptr %l32, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb6
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l34, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  store i32 %t8, ptr %l35, !tbaa !23
  %t9 = load ptr, ptr %l34, !tbaa !29
  %t10 = load i32, ptr %l35, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t11, ptr %l36
  br label %bb3
bb3:
  store ptr %l36, ptr %l37, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l38, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  store i32 %t13, ptr %l39, !tbaa !23
  %t14 = load ptr, ptr %l38, !tbaa !29
  %t15 = load i32, ptr %l39, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l40
  br label %bb4
bb4:
  store ptr %l40, ptr %l41, !tbaa !29
  %t17 = load ptr, ptr %l37, !tbaa !29
  %t18 = load ptr, ptr %l41, !tbaa !29
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t17, ptr %t18)
  store i1 %t19, ptr %l42
  br label %bb5
bb5:
  %t20 = load i1, ptr %l42, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l43, !tbaa !21
  %t22 = load i1, ptr %l43, !tbaa !21
  store i1 %t22, ptr %l33, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l33, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l44, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l44, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l45, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  store i32 %t26, ptr %l46, !tbaa !23
  %t27 = load ptr, ptr %l45, !tbaa !29
  %t28 = load i32, ptr %l46, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t29, ptr %l47
  br label %bb10
bb10:
  %t30 = load i32, ptr %l47
  store i32 %t30, ptr %l3
  %t31 = load i32, ptr %l3
  store i32 %t31, ptr %l48
  %t32 = load i32, ptr %l48
  %t33 = trunc i64 21 to i32
  %t34 = icmp eq i32 %t32, %t33
  store i1 %t34, ptr %l49, !tbaa !21
  %t35 = load i1, ptr %l49, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb85
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l50, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  store i32 %t37, ptr %l51, !tbaa !23
  %t38 = load ptr, ptr %l50, !tbaa !29
  %t39 = load i32, ptr %l51, !tbaa !23
  %t40 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t38, i32 %t39)
  store i64 %t40, ptr %l52
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l53, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  store i32 %t42, ptr %l54, !tbaa !23
  %t43 = load ptr, ptr %l53, !tbaa !29
  %t44 = load i32, ptr %l54, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t43, i32 %t44)
  store i64 %t45, ptr %l55
  br label %bb15
bb15:
  %t46 = load i64, ptr %l52, !tbaa !24
  %t47 = load i64, ptr %l55, !tbaa !24
  %t48 = icmp ne i64 %t46, %t47
  store i1 %t48, ptr %l56, !tbaa !21
  %t49 = load i1, ptr %l56, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 false, ptr %l57, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i1, ptr %l57, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l58, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l59, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  store i32 %t53, ptr %l60, !tbaa !23
  %t54 = load ptr, ptr %l59, !tbaa !29
  %t55 = load i32, ptr %l60, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t56, ptr %l61
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l58, !tbaa !29
  %t58 = load i32, ptr %l61, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t57, i32 %t58)
  store { i64, ptr } %t59, ptr %l62
  br label %bb20
bb20:
  %t60 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l63, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l64, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l65, !tbaa !23
  %t64 = load ptr, ptr %l64, !tbaa !29
  %t65 = load i32, ptr %l65, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t66, ptr %l66
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l63, !tbaa !29
  %t68 = load i32, ptr %l66, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t69, ptr %l67
  br label %bb22
bb22:
  %t70 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t70, ptr %l5, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l68, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l69, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l70, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l71, !tbaa !24
  %t77 = load i64, ptr %l69, !tbaa !24
  %t78 = load i64, ptr %l71, !tbaa !24
  %t79 = icmp ne i64 %t77, %t78
  store i1 %t79, ptr %l72, !tbaa !21
  %t80 = load i1, ptr %l72, !tbaa !21
  br i1 %t80, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l73, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i1, ptr %l73, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t82, ptr %l74, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l75, !tbaa !24
  %t85 = load i64, ptr %l75, !tbaa !24
  store i64 %t85, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  store i64 %t86, ptr %l76, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  store i64 %t87, ptr %l77, !tbaa !24
  %t88 = load i64, ptr %l76, !tbaa !24
  %t89 = load i64, ptr %l77, !tbaa !24
  %t90 = icmp sgt i64 %t88, %t89
  store i1 %t90, ptr %l78, !tbaa !21
  %t91 = load i1, ptr %l78, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t92 = load i64, ptr %l8, !tbaa !24
  store i64 %t92, ptr %l80, !tbaa !24
  %t93 = load i64, ptr %l80, !tbaa !24
  %t94 = icmp sgt i64 %t93, 0
  store i1 %t94, ptr %l81, !tbaa !21
  %t95 = load i1, ptr %l81, !tbaa !21
  br i1 %t95, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb31
bb28:
  %t96 = load i64, ptr %l7, !tbaa !24
  store i64 %t96, ptr %l83, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  store i64 %t97, ptr %l84, !tbaa !24
  %t98 = load i64, ptr %l83, !tbaa !24
  %t99 = load i64, ptr %l84, !tbaa !24
  %t100 = sub i64 %t98, %t99
  store i64 %t100, ptr %l85, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  store i64 %t101, ptr %l86, !tbaa !24
  %t102 = load i64, ptr %l85, !tbaa !24
  %t103 = load i64, ptr %l86, !tbaa !24
  %t104 = add i64 %t102, %t103
  store i64 %t104, ptr %l87, !tbaa !24
  %t105 = load i64, ptr %l87, !tbaa !24
  %t106 = sub i64 %t105, 1
  store i64 %t106, ptr %l88, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  store i64 %t107, ptr %l89, !tbaa !24
  %t108 = load i64, ptr %l88, !tbaa !24
  %t109 = load i64, ptr %l89, !tbaa !24
  %t110 = sdiv i64 %t108, %t109
  store i64 %t110, ptr %l90, !tbaa !24
  %t111 = load i64, ptr %l90, !tbaa !24
  store i64 %t111, ptr %l82, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb30
bb30:
  %t112 = load i64, ptr %l82, !tbaa !24
  store i64 %t112, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t113 = load i64, ptr %l79, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load i64, ptr %l10, !tbaa !24
  store i64 %t114, ptr %l91, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  store i64 %t115, ptr %l92, !tbaa !24
  %t116 = load i64, ptr %l91, !tbaa !24
  %t117 = load i64, ptr %l92, !tbaa !24
  %t118 = icmp slt i64 %t116, %t117
  store i1 %t118, ptr %l93, !tbaa !21
  %t119 = load i1, ptr %l93, !tbaa !21
  %t120 = xor i1 %t119, true
  store i1 %t120, ptr %l94, !tbaa !21
  %t121 = load i1, ptr %l94, !tbaa !21
  br i1 %t121, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb34:
  br label %bb35
bb35:
  %t122 = load i64, ptr %l6, !tbaa !24
  store i64 %t122, ptr %l95, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  store i64 %t123, ptr %l96, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  store i64 %t124, ptr %l97, !tbaa !24
  %t125 = load i64, ptr %l96, !tbaa !24
  %t126 = load i64, ptr %l97, !tbaa !24
  %t127 = mul i64 %t125, %t126
  store i64 %t127, ptr %l98, !tbaa !24
  %t128 = load i64, ptr %l95, !tbaa !24
  %t129 = load i64, ptr %l98, !tbaa !24
  %t130 = add i64 %t128, %t129
  store i64 %t130, ptr %l99, !tbaa !24
  %t131 = load i64, ptr %l99, !tbaa !24
  store i64 %t131, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l100, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  store i32 %t133, ptr %l101, !tbaa !23
  %t134 = load i64, ptr %l11, !tbaa !24
  store i64 %t134, ptr %l102, !tbaa !24
  %t135 = load ptr, ptr %l100, !tbaa !29
  %t136 = load i32, ptr %l101, !tbaa !23
  %t137 = load i64, ptr %l102, !tbaa !24
  %t138 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t135, i32 %t136, i64 %t137)
  store i64 %t138, ptr %l103
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l104, !tbaa !29
  %t140 = load i32, ptr %l2, !tbaa !23
  store i32 %t140, ptr %l105, !tbaa !23
  %t141 = load i64, ptr %l11, !tbaa !24
  store i64 %t141, ptr %l106, !tbaa !24
  %t142 = load ptr, ptr %l104, !tbaa !29
  %t143 = load i32, ptr %l105, !tbaa !23
  %t144 = load i64, ptr %l106, !tbaa !24
  %t145 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t142, i32 %t143, i64 %t144)
  store i64 %t145, ptr %l107
  br label %bb37
bb37:
  %t146 = load i64, ptr %l103, !tbaa !24
  %t147 = load i64, ptr %l107, !tbaa !24
  %t148 = icmp ne i64 %t146, %t147
  store i1 %t148, ptr %l108, !tbaa !21
  %t149 = load i1, ptr %l108, !tbaa !21
  br i1 %t149, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb41
bb39:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l110, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t151, ptr %l111, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  store i64 %t152, ptr %l112, !tbaa !24
  %t153 = load i64, ptr %l112, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i32, ptr %t155, i64 %t153
  %t157 = load i32, ptr %t156, !tbaa !33
  store i32 %t157, ptr %l113, !tbaa !23
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t158, ptr %l114, !tbaa !27
  %t159 = load i64, ptr %l11, !tbaa !24
  store i64 %t159, ptr %l115, !tbaa !24
  %t160 = load i64, ptr %l115, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t160
  %t164 = load i32, ptr %t163, !tbaa !33
  store i32 %t164, ptr %l116, !tbaa !23
  %t165 = load ptr, ptr %l110, !tbaa !29
  %t166 = load i32, ptr %l113, !tbaa !23
  %t167 = load i32, ptr %l116, !tbaa !23
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t165, i32 %t166, i32 %t167)
  store i1 %t168, ptr %l117
  br label %bb40
bb40:
  %t169 = load i1, ptr %l117, !tbaa !21
  %t170 = xor i1 %t169, true
  store i1 %t170, ptr %l118, !tbaa !21
  %t171 = load i1, ptr %l118, !tbaa !21
  store i1 %t171, ptr %l109, !tbaa !21
  br label %bb41
bb41:
  %t172 = load i1, ptr %l109, !tbaa !21
  br i1 %t172, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  store i1 false, ptr %l119, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t173 = load i1, ptr %l119, !tbaa !21
  store i1 %t173, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t174 = load i64, ptr %l10, !tbaa !24
  store i64 %t174, ptr %l120, !tbaa !24
  %t175 = load i64, ptr %l120, !tbaa !24
  %t176 = add i64 %t175, 1
  store i64 %t176, ptr %l121, !tbaa !24
  %t177 = load i64, ptr %l121, !tbaa !24
  store i64 %t177, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb46:
  call void @__olang_scope_close(ptr %s5)
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l122, !tbaa !29
  %t179 = load i32, ptr %l1, !tbaa !23
  store i32 %t179, ptr %l123, !tbaa !23
  %t180 = load ptr, ptr %l122, !tbaa !29
  %t181 = load i32, ptr %l123, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t180, i32 %t181)
  store { i64, ptr } %t182, ptr %l124
  br label %bb47
bb47:
  %t183 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t183, ptr %l12, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l125, !tbaa !29
  %t185 = load i32, ptr %l2, !tbaa !23
  store i32 %t185, ptr %l126, !tbaa !23
  %t186 = load ptr, ptr %l125, !tbaa !29
  %t187 = load i32, ptr %l126, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t186, i32 %t187)
  store { i64, ptr } %t188, ptr %l127
  br label %bb48
bb48:
  %t189 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t189, ptr %l13, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s9
  store i64 0, ptr %l14, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t190, ptr %l128, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l129, !tbaa !24
  %t193 = load i64, ptr %l129, !tbaa !24
  store i64 %t193, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l15, !tbaa !24
  store i64 %t194, ptr %l130, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  store i64 %t195, ptr %l131, !tbaa !24
  %t196 = load i64, ptr %l130, !tbaa !24
  %t197 = load i64, ptr %l131, !tbaa !24
  %t198 = icmp sgt i64 %t196, %t197
  store i1 %t198, ptr %l132, !tbaa !21
  %t199 = load i1, ptr %l132, !tbaa !21
  br i1 %t199, label %bb49, label %bb50
bb49:
  %t200 = load i64, ptr %l16, !tbaa !24
  store i64 %t200, ptr %l134, !tbaa !24
  %t201 = load i64, ptr %l134, !tbaa !24
  %t202 = icmp sgt i64 %t201, 0
  store i1 %t202, ptr %l135, !tbaa !21
  %t203 = load i1, ptr %l135, !tbaa !21
  br i1 %t203, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb54
bb51:
  %t204 = load i64, ptr %l15, !tbaa !24
  store i64 %t204, ptr %l137, !tbaa !24
  %t205 = load i64, ptr %l14, !tbaa !24
  store i64 %t205, ptr %l138, !tbaa !24
  %t206 = load i64, ptr %l137, !tbaa !24
  %t207 = load i64, ptr %l138, !tbaa !24
  %t208 = sub i64 %t206, %t207
  store i64 %t208, ptr %l139, !tbaa !24
  %t209 = load i64, ptr %l16, !tbaa !24
  store i64 %t209, ptr %l140, !tbaa !24
  %t210 = load i64, ptr %l139, !tbaa !24
  %t211 = load i64, ptr %l140, !tbaa !24
  %t212 = add i64 %t210, %t211
  store i64 %t212, ptr %l141, !tbaa !24
  %t213 = load i64, ptr %l141, !tbaa !24
  %t214 = sub i64 %t213, 1
  store i64 %t214, ptr %l142, !tbaa !24
  %t215 = load i64, ptr %l16, !tbaa !24
  store i64 %t215, ptr %l143, !tbaa !24
  %t216 = load i64, ptr %l142, !tbaa !24
  %t217 = load i64, ptr %l143, !tbaa !24
  %t218 = sdiv i64 %t216, %t217
  store i64 %t218, ptr %l144, !tbaa !24
  %t219 = load i64, ptr %l144, !tbaa !24
  store i64 %t219, ptr %l136, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb53
bb53:
  %t220 = load i64, ptr %l136, !tbaa !24
  store i64 %t220, ptr %l133, !tbaa !24
  br label %bb54
bb54:
  %t221 = load i64, ptr %l133, !tbaa !24
  store i64 %t221, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t222 = load i64, ptr %l18, !tbaa !24
  store i64 %t222, ptr %l145, !tbaa !24
  %t223 = load i64, ptr %l17, !tbaa !24
  store i64 %t223, ptr %l146, !tbaa !24
  %t224 = load i64, ptr %l145, !tbaa !24
  %t225 = load i64, ptr %l146, !tbaa !24
  %t226 = icmp slt i64 %t224, %t225
  store i1 %t226, ptr %l147, !tbaa !21
  %t227 = load i1, ptr %l147, !tbaa !21
  %t228 = xor i1 %t227, true
  store i1 %t228, ptr %l148, !tbaa !21
  %t229 = load i1, ptr %l148, !tbaa !21
  br i1 %t229, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb57:
  br label %bb58
bb58:
  %t230 = load i64, ptr %l14, !tbaa !24
  store i64 %t230, ptr %l149, !tbaa !24
  %t231 = load i64, ptr %l18, !tbaa !24
  store i64 %t231, ptr %l150, !tbaa !24
  %t232 = load i64, ptr %l16, !tbaa !24
  store i64 %t232, ptr %l151, !tbaa !24
  %t233 = load i64, ptr %l150, !tbaa !24
  %t234 = load i64, ptr %l151, !tbaa !24
  %t235 = mul i64 %t233, %t234
  store i64 %t235, ptr %l152, !tbaa !24
  %t236 = load i64, ptr %l149, !tbaa !24
  %t237 = load i64, ptr %l152, !tbaa !24
  %t238 = add i64 %t236, %t237
  store i64 %t238, ptr %l153, !tbaa !24
  %t239 = load i64, ptr %l153, !tbaa !24
  store i64 %t239, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l19, !tbaa !24
  store i64 %t240, ptr %l154, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t241, ptr %l155, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l156, !tbaa !24
  %t244 = load i64, ptr %l154, !tbaa !24
  %t245 = load i64, ptr %l156, !tbaa !24
  %t246 = icmp sge i64 %t244, %t245
  store i1 %t246, ptr %l157, !tbaa !21
  %t247 = load i1, ptr %l157, !tbaa !21
  br i1 %t247, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb60:
  br label %bb61
bb61:
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l158, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  store i32 %t249, ptr %l159, !tbaa !23
  %t250 = load i64, ptr %l19, !tbaa !24
  store i64 %t250, ptr %l160, !tbaa !24
  %t251 = load ptr, ptr %l158, !tbaa !29
  %t252 = load i32, ptr %l159, !tbaa !23
  %t253 = load i64, ptr %l160, !tbaa !24
  %t254 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t251, i32 %t252, i64 %t253)
  store i64 %t254, ptr %l161
  br label %bb62
bb62:
  %t255 = load i64, ptr %l161, !tbaa !24
  store i64 %t255, ptr %l20, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l162, !tbaa !29
  %t257 = load i32, ptr %l2, !tbaa !23
  store i32 %t257, ptr %l163, !tbaa !23
  %t258 = load i64, ptr %l19, !tbaa !24
  store i64 %t258, ptr %l164, !tbaa !24
  %t259 = load ptr, ptr %l162, !tbaa !29
  %t260 = load i32, ptr %l163, !tbaa !23
  %t261 = load i64, ptr %l164, !tbaa !24
  %t262 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t259, i32 %t260, i64 %t261)
  store i64 %t262, ptr %l165
  br label %bb63
bb63:
  %t263 = load i64, ptr %l165, !tbaa !24
  store i64 %t263, ptr %l21, !tbaa !24
  %t264 = load i64, ptr %l20, !tbaa !24
  store i64 %t264, ptr %l166, !tbaa !24
  %t265 = load i64, ptr %l21, !tbaa !24
  store i64 %t265, ptr %l167, !tbaa !24
  %t266 = load i64, ptr %l166, !tbaa !24
  %t267 = load i64, ptr %l167, !tbaa !24
  %t268 = icmp ne i64 %t266, %t267
  store i1 %t268, ptr %l168, !tbaa !21
  %t269 = load i1, ptr %l168, !tbaa !21
  br i1 %t269, label %bb64, label %bb65
bb64:
  %t270 = load i64, ptr %l20, !tbaa !24
  store i64 %t270, ptr %l170, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t271, ptr %l171, !tbaa !24
  %t272 = load i64, ptr %l170, !tbaa !24
  %t273 = load i64, ptr %l171, !tbaa !24
  %t274 = icmp eq i64 %t272, %t273
  store i1 %t274, ptr %l172, !tbaa !21
  %t275 = load i1, ptr %l172, !tbaa !21
  br i1 %t275, label %bb66, label %bb67
bb65:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb75
bb66:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb68
bb67:
  %t276 = load i64, ptr %l20, !tbaa !24
  store i64 %t276, ptr %l174, !tbaa !24
  %t277 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  store i64 %t277, ptr %l175, !tbaa !24
  %t278 = load i64, ptr %l174, !tbaa !24
  %t279 = load i64, ptr %l175, !tbaa !24
  %t280 = icmp eq i64 %t278, %t279
  store i1 %t280, ptr %l176, !tbaa !21
  %t281 = load i1, ptr %l176, !tbaa !21
  store i1 %t281, ptr %l173, !tbaa !21
  br label %bb68
bb68:
  %t282 = load i1, ptr %l173, !tbaa !21
  br i1 %t282, label %bb69, label %bb70
bb69:
  %t283 = load i64, ptr %l21, !tbaa !24
  store i64 %t283, ptr %l178, !tbaa !24
  %t284 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t284, ptr %l179, !tbaa !24
  %t285 = load i64, ptr %l178, !tbaa !24
  %t286 = load i64, ptr %l179, !tbaa !24
  %t287 = icmp eq i64 %t285, %t286
  store i1 %t287, ptr %l180, !tbaa !21
  %t288 = load i1, ptr %l180, !tbaa !21
  br i1 %t288, label %bb71, label %bb72
bb70:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb74
bb71:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb73
bb72:
  %t289 = load i64, ptr %l21, !tbaa !24
  store i64 %t289, ptr %l182, !tbaa !24
  %t290 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  store i64 %t290, ptr %l183, !tbaa !24
  %t291 = load i64, ptr %l182, !tbaa !24
  %t292 = load i64, ptr %l183, !tbaa !24
  %t293 = icmp eq i64 %t291, %t292
  store i1 %t293, ptr %l184, !tbaa !21
  %t294 = load i1, ptr %l184, !tbaa !21
  store i1 %t294, ptr %l181, !tbaa !21
  br label %bb73
bb73:
  %t295 = load i1, ptr %l181, !tbaa !21
  store i1 %t295, ptr %l177, !tbaa !21
  br label %bb74
bb74:
  %t296 = load i1, ptr %l177, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l185, !tbaa !21
  %t298 = load i1, ptr %l185, !tbaa !21
  store i1 %t298, ptr %l169, !tbaa !21
  br label %bb75
bb75:
  %t299 = load i1, ptr %l169, !tbaa !21
  br i1 %t299, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s12
  store i1 false, ptr %l186, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t300 = load i1, ptr %l186, !tbaa !21
  store i1 %t300, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l187, !tbaa !29
  %t302 = load i64, ptr %l19, !tbaa !24
  store i64 %t302, ptr %l188, !tbaa !24
  %t303 = load i64, ptr %l188, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i32, ptr %t305, i64 %t303
  %t307 = load i32, ptr %t306, !tbaa !33
  store i32 %t307, ptr %l189, !tbaa !23
  %t308 = load i64, ptr %l19, !tbaa !24
  store i64 %t308, ptr %l190, !tbaa !24
  %t309 = load i64, ptr %l190, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i32, ptr %t311, i64 %t309
  %t313 = load i32, ptr %t312, !tbaa !33
  store i32 %t313, ptr %l191, !tbaa !23
  %t314 = load ptr, ptr %l187, !tbaa !29
  %t315 = load i32, ptr %l189, !tbaa !23
  %t316 = load i32, ptr %l191, !tbaa !23
  %t317 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t314, i32 %t315, i32 %t316)
  store i1 %t317, ptr %l192
  br label %bb79
bb79:
  %t318 = load i1, ptr %l192, !tbaa !21
  %t319 = xor i1 %t318, true
  store i1 %t319, ptr %l193, !tbaa !21
  %t320 = load i1, ptr %l193, !tbaa !21
  br i1 %t320, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s13
  store i1 false, ptr %l194, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t321 = load i1, ptr %l194, !tbaa !21
  store i1 %t321, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s14
  %t322 = load i64, ptr %l18, !tbaa !24
  store i64 %t322, ptr %l195, !tbaa !24
  %t323 = load i64, ptr %l195, !tbaa !24
  %t324 = add i64 %t323, 1
  store i64 %t324, ptr %l196, !tbaa !24
  %t325 = load i64, ptr %l196, !tbaa !24
  store i64 %t325, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb84:
  call void @__olang_scope_close(ptr %s9)
  store i1 true, ptr %l197, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t326 = load i1, ptr %l197, !tbaa !21
  store i1 %t326, ptr %rv
  br label %ret
bb85:
  %t327 = load i32, ptr %l3
  store i32 %t327, ptr %l198
  %t328 = load i32, ptr %l198
  %t329 = trunc i64 19 to i32
  %t330 = icmp eq i32 %t328, %t329
  store i1 %t330, ptr %l199, !tbaa !21
  %t331 = load i1, ptr %l199, !tbaa !21
  br i1 %t331, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb92
bb88:
  store %olang.scope zeroinitializer, ptr %s15
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l200, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l201, !tbaa !29
  %t334 = load i32, ptr %l1, !tbaa !23
  store i32 %t334, ptr %l202, !tbaa !23
  %t335 = load ptr, ptr %l201, !tbaa !29
  %t336 = load i32, ptr %l202, !tbaa !23
  %t337 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t335, i32 %t336)
  store i32 %t337, ptr %l203
  br label %bb89
bb89:
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l204, !tbaa !29
  %t339 = load i32, ptr %l2, !tbaa !23
  store i32 %t339, ptr %l205, !tbaa !23
  %t340 = load ptr, ptr %l204, !tbaa !29
  %t341 = load i32, ptr %l205, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t340, i32 %t341)
  store i32 %t342, ptr %l206
  br label %bb90
bb90:
  %t343 = load ptr, ptr %l200, !tbaa !29
  %t344 = load i32, ptr %l203, !tbaa !23
  %t345 = load i32, ptr %l206, !tbaa !23
  %t346 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t343, i32 %t344, i32 %t345)
  store i1 %t346, ptr %l207
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t347 = load i1, ptr %l207, !tbaa !21
  store i1 %t347, ptr %rv
  br label %ret
bb92:
  %t348 = load i32, ptr %l3
  store i32 %t348, ptr %l208
  %t349 = load i32, ptr %l208
  %t350 = trunc i64 20 to i32
  %t351 = icmp eq i32 %t349, %t350
  store i1 %t351, ptr %l209, !tbaa !21
  %t352 = load i1, ptr %l209, !tbaa !21
  br i1 %t352, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb99
bb95:
  store %olang.scope zeroinitializer, ptr %s16
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l210, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l211, !tbaa !29
  %t355 = load i32, ptr %l1, !tbaa !23
  store i32 %t355, ptr %l212, !tbaa !23
  %t356 = load ptr, ptr %l211, !tbaa !29
  %t357 = load i32, ptr %l212, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t356, i32 %t357)
  store i32 %t358, ptr %l213
  br label %bb96
bb96:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l214, !tbaa !29
  %t360 = load i32, ptr %l2, !tbaa !23
  store i32 %t360, ptr %l215, !tbaa !23
  %t361 = load ptr, ptr %l214, !tbaa !29
  %t362 = load i32, ptr %l215, !tbaa !23
  %t363 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t361, i32 %t362)
  store i32 %t363, ptr %l216
  br label %bb97
bb97:
  %t364 = load ptr, ptr %l210, !tbaa !29
  %t365 = load i32, ptr %l213, !tbaa !23
  %t366 = load i32, ptr %l216, !tbaa !23
  %t367 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t364, i32 %t365, i32 %t366)
  store i1 %t367, ptr %l217
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t368 = load i1, ptr %l217, !tbaa !21
  store i1 %t368, ptr %rv
  br label %ret
bb99:
  %t369 = load i32, ptr %l3
  store i32 %t369, ptr %l218
  %t370 = load i32, ptr %l218
  %t371 = trunc i64 22 to i32
  %t372 = icmp eq i32 %t370, %t371
  store i1 %t372, ptr %l219, !tbaa !21
  %t373 = load i1, ptr %l219, !tbaa !21
  br i1 %t373, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb126
bb102:
  store %olang.scope zeroinitializer, ptr %s17
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l220, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l221, !tbaa !29
  %t376 = load i32, ptr %l1, !tbaa !23
  store i32 %t376, ptr %l222, !tbaa !23
  %t377 = load ptr, ptr %l221, !tbaa !29
  %t378 = load i32, ptr %l222, !tbaa !23
  %t379 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t377, i32 %t378)
  store i32 %t379, ptr %l223
  br label %bb103
bb103:
  %t380 = load ptr, ptr %l220, !tbaa !29
  %t381 = load i32, ptr %l223, !tbaa !23
  %t382 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t380, i32 %t381)
  store { i64, ptr } %t382, ptr %l224
  br label %bb104
bb104:
  %t383 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t383, ptr %l22, !tbaa !27
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l225, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t385, ptr %l226, !tbaa !29
  %t386 = load i32, ptr %l2, !tbaa !23
  store i32 %t386, ptr %l227, !tbaa !23
  %t387 = load ptr, ptr %l226, !tbaa !29
  %t388 = load i32, ptr %l227, !tbaa !23
  %t389 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t387, i32 %t388)
  store i32 %t389, ptr %l228
  br label %bb105
bb105:
  %t390 = load ptr, ptr %l225, !tbaa !29
  %t391 = load i32, ptr %l228, !tbaa !23
  %t392 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t390, i32 %t391)
  store { i64, ptr } %t392, ptr %l229
  br label %bb106
bb106:
  %t393 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t393, ptr %l23, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s18
  store i64 0, ptr %l24, !tbaa !24
  %t394 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t394, ptr %l230, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l231, !tbaa !24
  %t397 = load i64, ptr %l231, !tbaa !24
  store i64 %t397, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t398 = load i64, ptr %l25, !tbaa !24
  store i64 %t398, ptr %l232, !tbaa !24
  %t399 = load i64, ptr %l24, !tbaa !24
  store i64 %t399, ptr %l233, !tbaa !24
  %t400 = load i64, ptr %l232, !tbaa !24
  %t401 = load i64, ptr %l233, !tbaa !24
  %t402 = icmp sgt i64 %t400, %t401
  store i1 %t402, ptr %l234, !tbaa !21
  %t403 = load i1, ptr %l234, !tbaa !21
  br i1 %t403, label %bb107, label %bb108
bb107:
  %t404 = load i64, ptr %l26, !tbaa !24
  store i64 %t404, ptr %l236, !tbaa !24
  %t405 = load i64, ptr %l236, !tbaa !24
  %t406 = icmp sgt i64 %t405, 0
  store i1 %t406, ptr %l237, !tbaa !21
  %t407 = load i1, ptr %l237, !tbaa !21
  br i1 %t407, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb112
bb109:
  %t408 = load i64, ptr %l25, !tbaa !24
  store i64 %t408, ptr %l239, !tbaa !24
  %t409 = load i64, ptr %l24, !tbaa !24
  store i64 %t409, ptr %l240, !tbaa !24
  %t410 = load i64, ptr %l239, !tbaa !24
  %t411 = load i64, ptr %l240, !tbaa !24
  %t412 = sub i64 %t410, %t411
  store i64 %t412, ptr %l241, !tbaa !24
  %t413 = load i64, ptr %l26, !tbaa !24
  store i64 %t413, ptr %l242, !tbaa !24
  %t414 = load i64, ptr %l241, !tbaa !24
  %t415 = load i64, ptr %l242, !tbaa !24
  %t416 = add i64 %t414, %t415
  store i64 %t416, ptr %l243, !tbaa !24
  %t417 = load i64, ptr %l243, !tbaa !24
  %t418 = sub i64 %t417, 1
  store i64 %t418, ptr %l244, !tbaa !24
  %t419 = load i64, ptr %l26, !tbaa !24
  store i64 %t419, ptr %l245, !tbaa !24
  %t420 = load i64, ptr %l244, !tbaa !24
  %t421 = load i64, ptr %l245, !tbaa !24
  %t422 = sdiv i64 %t420, %t421
  store i64 %t422, ptr %l246, !tbaa !24
  %t423 = load i64, ptr %l246, !tbaa !24
  store i64 %t423, ptr %l238, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb111
bb111:
  %t424 = load i64, ptr %l238, !tbaa !24
  store i64 %t424, ptr %l235, !tbaa !24
  br label %bb112
bb112:
  %t425 = load i64, ptr %l235, !tbaa !24
  store i64 %t425, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s19
  %t426 = load i64, ptr %l28, !tbaa !24
  store i64 %t426, ptr %l247, !tbaa !24
  %t427 = load i64, ptr %l27, !tbaa !24
  store i64 %t427, ptr %l248, !tbaa !24
  %t428 = load i64, ptr %l247, !tbaa !24
  %t429 = load i64, ptr %l248, !tbaa !24
  %t430 = icmp slt i64 %t428, %t429
  store i1 %t430, ptr %l249, !tbaa !21
  %t431 = load i1, ptr %l249, !tbaa !21
  %t432 = xor i1 %t431, true
  store i1 %t432, ptr %l250, !tbaa !21
  %t433 = load i1, ptr %l250, !tbaa !21
  br i1 %t433, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s19)
  br label %bb125
bb115:
  br label %bb116
bb116:
  %t434 = load i64, ptr %l24, !tbaa !24
  store i64 %t434, ptr %l251, !tbaa !24
  %t435 = load i64, ptr %l28, !tbaa !24
  store i64 %t435, ptr %l252, !tbaa !24
  %t436 = load i64, ptr %l26, !tbaa !24
  store i64 %t436, ptr %l253, !tbaa !24
  %t437 = load i64, ptr %l252, !tbaa !24
  %t438 = load i64, ptr %l253, !tbaa !24
  %t439 = mul i64 %t437, %t438
  store i64 %t439, ptr %l254, !tbaa !24
  %t440 = load i64, ptr %l251, !tbaa !24
  %t441 = load i64, ptr %l254, !tbaa !24
  %t442 = add i64 %t440, %t441
  store i64 %t442, ptr %l255, !tbaa !24
  %t443 = load i64, ptr %l255, !tbaa !24
  store i64 %t443, ptr %l29, !tbaa !24
  %t444 = load i64, ptr %l29, !tbaa !24
  store i64 %t444, ptr %l256, !tbaa !24
  %t445 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t445, ptr %l257, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t446, 0
  store i64 %t447, ptr %l258, !tbaa !24
  %t448 = load i64, ptr %l256, !tbaa !24
  %t449 = load i64, ptr %l258, !tbaa !24
  %t450 = icmp slt i64 %t448, %t449
  store i1 %t450, ptr %l259, !tbaa !21
  %t451 = load i1, ptr %l259, !tbaa !21
  br i1 %t451, label %bb117, label %bb118
bb117:
  %t452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t452, ptr %l261, !tbaa !29
  %t453 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t453, ptr %l262, !tbaa !27
  %t454 = load i64, ptr %l29, !tbaa !24
  store i64 %t454, ptr %l263, !tbaa !24
  %t455 = load i64, ptr %l263, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i32, ptr %t457, i64 %t455
  %t459 = load i32, ptr %t458, !tbaa !33
  store i32 %t459, ptr %l264, !tbaa !23
  %t460 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t460, ptr %l265, !tbaa !27
  %t461 = load i64, ptr %l29, !tbaa !24
  store i64 %t461, ptr %l266, !tbaa !24
  %t462 = load i64, ptr %l266, !tbaa !24
  %t463 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr i32, ptr %t464, i64 %t462
  %t466 = load i32, ptr %t465, !tbaa !33
  store i32 %t466, ptr %l267, !tbaa !23
  %t467 = load ptr, ptr %l261, !tbaa !29
  %t468 = load i32, ptr %l264, !tbaa !23
  %t469 = load i32, ptr %l267, !tbaa !23
  %t470 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t467, i32 %t468, i32 %t469)
  store i1 %t470, ptr %l268
  br label %bb119
bb118:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb120
bb119:
  %t471 = load i1, ptr %l268, !tbaa !21
  %t472 = xor i1 %t471, true
  store i1 %t472, ptr %l269, !tbaa !21
  %t473 = load i1, ptr %l269, !tbaa !21
  store i1 %t473, ptr %l260, !tbaa !21
  br label %bb120
bb120:
  %t474 = load i1, ptr %l260, !tbaa !21
  br i1 %t474, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s20
  store i1 false, ptr %l270, !tbaa !21
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t475 = load i1, ptr %l270, !tbaa !21
  store i1 %t475, ptr %rv
  br label %ret
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s19)
  br label %bb124
bb124:
  store %olang.scope zeroinitializer, ptr %s21
  %t476 = load i64, ptr %l28, !tbaa !24
  store i64 %t476, ptr %l271, !tbaa !24
  %t477 = load i64, ptr %l271, !tbaa !24
  %t478 = add i64 %t477, 1
  store i64 %t478, ptr %l272, !tbaa !24
  %t479 = load i64, ptr %l272, !tbaa !24
  store i64 %t479, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb113
bb125:
  call void @__olang_scope_close(ptr %s18)
  store i1 true, ptr %l273, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t480 = load i1, ptr %l273, !tbaa !21
  store i1 %t480, ptr %rv
  br label %ret
bb126:
  store %olang.scope zeroinitializer, ptr %s22
  store i1 true, ptr %l274, !tbaa !21
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t481 = load i1, ptr %l274, !tbaa !21
  store i1 %t481, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/types:data"
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 4
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = trunc i64 %t8 to i32
  store i32 %t9, ptr %l6, !tbaa !23
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEmptyBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 14
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t6, i1 false, i1 true)
  store %"compiler/types:body" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = load %"compiler/types:body", ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t8, i32 %t9, %"compiler/types:body" %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEnumBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l11, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  store i1 %t5, ptr %l13, !tbaa !21
  %t6 = load i1, ptr %l13, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  store i1 %t8, ptr %l14, !tbaa !21
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 4
  %t19 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l5, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  store i64 %t26, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  store i64 %t27, ptr %l19, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = load i64, ptr %l19, !tbaa !24
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = icmp sgt i64 %t29, %t30
  store i1 %t31, ptr %l21, !tbaa !21
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb5:
  %t33 = load i64, ptr %l7, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp sgt i64 %t34, 0
  store i1 %t35, ptr %l24, !tbaa !21
  %t36 = load i1, ptr %l24, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb7:
  %t37 = load i64, ptr %l6, !tbaa !24
  store i64 %t37, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = load i64, ptr %l27, !tbaa !24
  %t41 = sub i64 %t39, %t40
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  store i64 %t42, ptr %l29, !tbaa !24
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = load i64, ptr %l29, !tbaa !24
  %t45 = add i64 %t43, %t44
  store i64 %t45, ptr %l30, !tbaa !24
  %t46 = load i64, ptr %l30, !tbaa !24
  %t47 = sub i64 %t46, 1
  store i64 %t47, ptr %l31, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  store i64 %t48, ptr %l32, !tbaa !24
  %t49 = load i64, ptr %l31, !tbaa !24
  %t50 = load i64, ptr %l32, !tbaa !24
  %t51 = sdiv i64 %t49, %t50
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load i64, ptr %l33, !tbaa !24
  store i64 %t52, ptr %l25, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l25, !tbaa !24
  store i64 %t53, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l22, !tbaa !24
  store i64 %t54, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t55 = load i64, ptr %l9, !tbaa !24
  store i64 %t55, ptr %l34, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  store i64 %t56, ptr %l35, !tbaa !24
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = icmp slt i64 %t57, %t58
  store i1 %t59, ptr %l36, !tbaa !21
  %t60 = load i1, ptr %l36, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l37, !tbaa !21
  %t62 = load i1, ptr %l37, !tbaa !21
  br i1 %t62, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  store i64 %t64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = mul i64 %t66, %t67
  store i64 %t68, ptr %l41, !tbaa !24
  %t69 = load i64, ptr %l38, !tbaa !24
  %t70 = load i64, ptr %l41, !tbaa !24
  %t71 = add i64 %t69, %t70
  store i64 %t71, ptr %l42, !tbaa !24
  %t72 = load i64, ptr %l42, !tbaa !24
  store i64 %t72, ptr %l10, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t73, ptr %l43, !tbaa !27
  %t74 = load i64, ptr %l10, !tbaa !24
  store i64 %t74, ptr %l44, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t75, ptr %l45, !tbaa !27
  %t76 = load i64, ptr %l10, !tbaa !24
  store i64 %t76, ptr %l46, !tbaa !24
  %t77 = load i64, ptr %l46, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i32, ptr %t79, i64 %t77
  %t81 = load i32, ptr %t80, !tbaa !33
  store i32 %t81, ptr %l47, !tbaa !23
  %t82 = load i32, ptr %l47, !tbaa !23
  %t83 = load i64, ptr %l44, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i32, ptr %t85, i64 %t83
  store i32 %t82, ptr %t86, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t87 = load i64, ptr %l9, !tbaa !24
  store i64 %t87, ptr %l48, !tbaa !24
  %t88 = load i64, ptr %l48, !tbaa !24
  %t89 = add i64 %t88, 1
  store i64 %t89, ptr %l49, !tbaa !24
  %t90 = load i64, ptr %l49, !tbaa !24
  store i64 %t90, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb16:
  call void @__olang_scope_close(ptr %s1)
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l50, !tbaa !29
  %t92 = load ptr, ptr %l50, !tbaa !29
  %t93 = getelementptr %"compiler/types:Table", ptr %t92, i32 0, i32 15
  store ptr %t93, ptr %l51, !tbaa !29
  %t94 = load i32, ptr %l1, !tbaa !23
  store i32 %t94, ptr %l52, !tbaa !23
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l53, !tbaa !27
  %t96 = load ptr, ptr %l51, !tbaa !29
  %t97 = load i32, ptr %l52, !tbaa !23
  %t98 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v0, ptr %t96, i32 %t97, { i64, ptr } %t98)
  br label %bb17
bb17:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l54, !tbaa !29
  %t100 = load ptr, ptr %l54, !tbaa !29
  %t101 = getelementptr %"compiler/types:Table", ptr %t100, i32 0, i32 14
  store ptr %t101, ptr %l55, !tbaa !29
  %t102 = load i32, ptr %l1, !tbaa !23
  store i32 %t102, ptr %l56, !tbaa !23
  %t103 = load i32, ptr %l3, !tbaa !23
  store i32 %t103, ptr %l57, !tbaa !23
  %t104 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t104, ptr %l58, !tbaa !23
  %t105 = load i32, ptr %l57, !tbaa !23
  %t106 = load i32, ptr %l58, !tbaa !23
  %t107 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 %t105, i32 %t106, i1 false, i1 true)
  store %"compiler/types:body" %t107, ptr %l59
  br label %bb18
bb18:
  %t108 = load ptr, ptr %l55, !tbaa !29
  %t109 = load i32, ptr %l56, !tbaa !23
  %t110 = load %"compiler/types:body", ptr %l59
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t108, i32 %t109, %"compiler/types:body" %t110)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 16
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l5, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t8, i64 %t9, i64 %t10)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetOverBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 14
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l6, !tbaa !23
  %t6 = load i32, ptr %l6, !tbaa !23
  %t7 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t6, i1 false, i1 true)
  store %"compiler/types:body" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = load %"compiler/types:body", ptr %l7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t8, i32 %t9, %"compiler/types:body" %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 14
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t6, ptr %l8, !tbaa !23
  %t7 = load i1, ptr %l3, !tbaa !21
  store i1 %t7, ptr %l9, !tbaa !21
  %t8 = load i32, ptr %l7, !tbaa !23
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = load i1, ptr %l9, !tbaa !21
  %t11 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 %t8, i32 0, i32 %t9, i1 %t10, i1 true)
  store %"compiler/types:body" %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = load %"compiler/types:body", ptr %l10
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t12, i32 %t13, %"compiler/types:body" %t14)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 7
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t9, i64 %t10)
  store i32 %t11, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i32, ptr %l7, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 6
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 24
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l7, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = sext i32 %t9 to i64
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store { i64, ptr } %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp sgt i64 %t18, 0
  store i1 %t19, ptr %l13, !tbaa !21
  %t20 = load i1, ptr %l13, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %l16, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = add i64 2, %t23
  store i64 %t24, ptr %l17, !tbaa !24
  %t25 = load i64, ptr %l17, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i64, ptr %t27, i64 %t25
  %t29 = load i64, ptr %t28, !tbaa !34
  store i64 %t29, ptr %l18, !tbaa !24
  %t30 = load i64, ptr %l18, !tbaa !24
  store i64 %t30, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  %t31 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t31, ptr %l19, !tbaa !24
  %t32 = load i64, ptr %l19, !tbaa !24
  store i64 %t32, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i64, ptr %l14, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 17
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l3, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  store i32 %t3, ptr %l4, !tbaa !23
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l5, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp eq i64 %t12, 0
  store i1 %t13, ptr %l8, !tbaa !21
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 3, ptr @.d29 }, ptr %l9, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l11, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l13, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l14, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  store i32 %t33, ptr %l15, !tbaa !23
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t35 = load i32, ptr %l15, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l16
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l13, !tbaa !29
  %t38 = load i32, ptr %l16, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l17
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca %"compiler/types:data"
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 22, ptr %l5
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  %t3 = load i32, ptr %l6, !tbaa !23
  %t4 = sext i32 %t3 to i64
  store i64 %t4, ptr %l7, !tbaa !24
  %t5 = load i32, ptr %l5
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t5, i64 %t6, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  store i32 %t9, ptr %l10, !tbaa !23
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i32, ptr %l10, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = add i32 %t13, 1
  store i32 %t14, ptr %l12, !tbaa !23
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l8
  %t17 = load i32, ptr %l12, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t17)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l15, !tbaa !23
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load i32, ptr %l3, !tbaa !23
  store i32 %t26, ptr %l17, !tbaa !23
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l18, !tbaa !23
  %t28 = load i32, ptr %l17, !tbaa !23
  %t29 = load i32, ptr %l18, !tbaa !23
  %t30 = icmp ne i32 %t28, %t29
  store i1 %t30, ptr %l19, !tbaa !21
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t33, i32 0, i32 23
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  store i32 %t35, ptr %l22, !tbaa !23
  %t36 = load i32, ptr %l22, !tbaa !23
  %t37 = sext i32 %t36 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  store i32 %t39, ptr %l25, !tbaa !23
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = load i32, ptr %l25, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t42, ptr %l26
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t43, i64 %t44, i32 %t45)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t46 = load i32, ptr %l2, !tbaa !23
  store i32 %t46, ptr %l27, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i32, ptr %l27, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i64
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca ptr
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca i32
  %l70 = alloca i32
  %l71 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  store i32 %t7, ptr %l6
  store ptr %l6, ptr %l7, !tbaa !29
  store i32 21, ptr %l8
  store ptr %l8, ptr %l9, !tbaa !29
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t8, ptr %t9)
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l12, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l13, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  store i32 %t15, ptr %l14, !tbaa !23
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l14, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t18, ptr %l15
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t19 = load ptr, ptr %l12, !tbaa !29
  %t20 = load i32, ptr %l15, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t21, ptr %l16
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  store i32 %t24, ptr %l19, !tbaa !23
  %t25 = load ptr, ptr %l18, !tbaa !29
  %t26 = load i32, ptr %l19, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t27, ptr %l20
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i32, ptr %l20, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l21
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  store i32 %t32, ptr %l23, !tbaa !23
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t34 = load i32, ptr %l23, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l24
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l25, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  store i32 %t37, ptr %l26, !tbaa !23
  %t38 = load ptr, ptr %l25, !tbaa !29
  %t39 = load i32, ptr %l26, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l11, !tbaa !29
  %t42 = load i32, ptr %l16, !tbaa !23
  %t43 = load i32, ptr %l21, !tbaa !23
  %t44 = load i32, ptr %l24, !tbaa !23
  %t45 = load i32, ptr %l27, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t41, i32 %t42, i32 %t43, i32 %t44, i32 %t45, i64 0)
  store i32 %t46, ptr %l28
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i32, ptr %l28, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb12:
  %t48 = load i32, ptr %l2
  store i32 %t48, ptr %l29
  store ptr %l29, ptr %l30, !tbaa !29
  store i32 20, ptr %l31
  store ptr %l31, ptr %l32, !tbaa !29
  %t49 = load ptr, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t49, ptr %t50)
  store i1 %t51, ptr %l33
  br label %bb13
bb13:
  %t52 = load i1, ptr %l33, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l35, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l36, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  store i32 %t56, ptr %l37, !tbaa !23
  %t57 = load ptr, ptr %l36, !tbaa !29
  %t58 = load i32, ptr %l37, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t59, ptr %l38
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t62, ptr %l39
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l40, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  store i32 %t64, ptr %l41, !tbaa !23
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i32, ptr %l41, !tbaa !23
  %t67 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t67, ptr %l42
  br label %bb18
bb18:
  %t68 = load ptr, ptr %l34, !tbaa !29
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t68, i32 %t69, i64 %t70)
  store i32 %t71, ptr %l43
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t72 = load i32, ptr %l43, !tbaa !23
  store i32 %t72, ptr %rv
  br label %ret
bb20:
  %t73 = load i32, ptr %l2
  store i32 %t73, ptr %l44
  store ptr %l44, ptr %l45, !tbaa !29
  store i32 19, ptr %l46
  store ptr %l46, ptr %l47, !tbaa !29
  %t74 = load ptr, ptr %l45, !tbaa !29
  %t75 = load ptr, ptr %l47, !tbaa !29
  %t76 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t74, ptr %t75)
  store i1 %t76, ptr %l48
  br label %bb21
bb21:
  %t77 = load i1, ptr %l48, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l49, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l50, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l51, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  store i32 %t81, ptr %l52, !tbaa !23
  %t82 = load ptr, ptr %l51, !tbaa !29
  %t83 = load i32, ptr %l52, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t84, ptr %l53
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t85 = load ptr, ptr %l50, !tbaa !29
  %t86 = load i32, ptr %l53, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t87, ptr %l54
  br label %bb25
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l55, !tbaa !29
  %t89 = load i32, ptr %l1, !tbaa !23
  store i32 %t89, ptr %l56, !tbaa !23
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = load i32, ptr %l56, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t92, ptr %l57
  br label %bb26
bb26:
  %t93 = load ptr, ptr %l49, !tbaa !29
  %t94 = load i32, ptr %l54, !tbaa !23
  %t95 = load i32, ptr %l57, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t93, i32 %t94, i32 %t95)
  store i32 %t96, ptr %l58
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t97 = load i32, ptr %l58, !tbaa !23
  store i32 %t97, ptr %rv
  br label %ret
bb28:
  %t98 = load i32, ptr %l2
  store i32 %t98, ptr %l59
  store ptr %l59, ptr %l60, !tbaa !29
  store i32 22, ptr %l61
  store ptr %l61, ptr %l62, !tbaa !29
  %t99 = load ptr, ptr %l60, !tbaa !29
  %t100 = load ptr, ptr %l62, !tbaa !29
  %t101 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t99, ptr %t100)
  store i1 %t101, ptr %l63
  br label %bb29
bb29:
  %t102 = load i1, ptr %l63, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l64, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l65, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l66, !tbaa !29
  %t106 = load i32, ptr %l1, !tbaa !23
  store i32 %t106, ptr %l67, !tbaa !23
  %t107 = load ptr, ptr %l66, !tbaa !29
  %t108 = load i32, ptr %l67, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t109, ptr %l68
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t110 = load ptr, ptr %l65, !tbaa !29
  %t111 = load i32, ptr %l68, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t112, ptr %l69
  br label %bb33
bb33:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i32, ptr %l69, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t115, ptr %l70
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load i32, ptr %l70, !tbaa !23
  store i32 %t116, ptr %rv
  br label %ret
bb35:
  %t117 = load i32, ptr %l1, !tbaa !23
  store i32 %t117, ptr %l71, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i32, ptr %l71, !tbaa !23
  store i32 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 25, ptr %l5
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  store i64 %t4, ptr %l8, !tbaa !24
  %t5 = load i32, ptr %l5
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 %t5, i64 %t6, i64 %t7, i64 %t8, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l9
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t10, %"compiler/types:data" %t11, i32 1)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l10, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eByAddress(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  store i32 %t8, ptr %l7, !tbaa !23
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i32, ptr %l7, !tbaa !23
  %t11 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t9, i32 %t10)
  store i64 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i64, ptr @G_2ecompiler_2ftypes_2eBigAggregate, !tbaa !24
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = icmp sgt i64 %t13, %t14
  store i1 %t15, ptr %l10, !tbaa !21
  %t16 = load i1, ptr %l10, !tbaa !21
  store i1 %t16, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i1, ptr %l5, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  store ptr %l5, ptr %l6, !tbaa !29
  store i32 21, ptr %l7
  store ptr %l7, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t6, ptr %t7)
  store i1 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  %t10 = xor i1 %t9, true
  store i1 %t10, ptr %l10, !tbaa !21
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load i32, ptr %l1, !tbaa !23
  store i32 %t12, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l13, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l14, !tbaa !23
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l17, !tbaa !23
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = load i32, ptr %l17, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t24, ptr %l18
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l19, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  store i32 %t26, ptr %l20, !tbaa !23
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i32, ptr %l20, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l22, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %l23, !tbaa !23
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = load i32, ptr %l23, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t34, ptr %l24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l25, !tbaa !24
  %t36 = load ptr, ptr %l12, !tbaa !29
  %t37 = load i32, ptr %l15, !tbaa !23
  %t38 = load i32, ptr %l18, !tbaa !23
  %t39 = load i32, ptr %l21, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t41 = load i64, ptr %l25, !tbaa !24
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t36, i32 %t37, i32 %t38, i32 %t39, i32 %t40, i64 %t41)
  store i32 %t42, ptr %l26
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l26, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l11, !tbaa !29
  %t3 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t3, { i64, ptr } { i64 2, ptr @.d30 })
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l12, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l13, !tbaa !23
  %t6 = load ptr, ptr %l12, !tbaa !29
  %t7 = load i32, ptr %l13, !tbaa !23
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %t7)
  store { i64, ptr } %t8, ptr %l14
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t10, ptr %l15, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l16, !tbaa !24
  %t13 = load i64, ptr %l16, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  store i64 %t14, ptr %l17, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  store i64 %t15, ptr %l18, !tbaa !24
  %t16 = load i64, ptr %l17, !tbaa !24
  %t17 = load i64, ptr %l18, !tbaa !24
  %t18 = icmp sgt i64 %t16, %t17
  store i1 %t18, ptr %l19, !tbaa !21
  %t19 = load i1, ptr %l19, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load i64, ptr %l6, !tbaa !24
  store i64 %t20, ptr %l21, !tbaa !24
  %t21 = load i64, ptr %l21, !tbaa !24
  %t22 = icmp sgt i64 %t21, 0
  store i1 %t22, ptr %l22, !tbaa !21
  %t23 = load i1, ptr %l22, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb6:
  %t24 = load i64, ptr %l5, !tbaa !24
  store i64 %t24, ptr %l24, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %l25, !tbaa !24
  %t26 = load i64, ptr %l24, !tbaa !24
  %t27 = load i64, ptr %l25, !tbaa !24
  %t28 = sub i64 %t26, %t27
  store i64 %t28, ptr %l26, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  store i64 %t29, ptr %l27, !tbaa !24
  %t30 = load i64, ptr %l26, !tbaa !24
  %t31 = load i64, ptr %l27, !tbaa !24
  %t32 = add i64 %t30, %t31
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load i64, ptr %l28, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l29, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  store i64 %t35, ptr %l30, !tbaa !24
  %t36 = load i64, ptr %l29, !tbaa !24
  %t37 = load i64, ptr %l30, !tbaa !24
  %t38 = sdiv i64 %t36, %t37
  store i64 %t38, ptr %l31, !tbaa !24
  %t39 = load i64, ptr %l31, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l8, !tbaa !24
  store i64 %t42, ptr %l32, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  store i64 %t43, ptr %l33, !tbaa !24
  %t44 = load i64, ptr %l32, !tbaa !24
  %t45 = load i64, ptr %l33, !tbaa !24
  %t46 = icmp slt i64 %t44, %t45
  store i1 %t46, ptr %l34, !tbaa !21
  %t47 = load i1, ptr %l34, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l35, !tbaa !21
  %t49 = load i1, ptr %l35, !tbaa !21
  br i1 %t49, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l36, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  store i64 %t51, ptr %l37, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  store i64 %t52, ptr %l38, !tbaa !24
  %t53 = load i64, ptr %l37, !tbaa !24
  %t54 = load i64, ptr %l38, !tbaa !24
  %t55 = mul i64 %t53, %t54
  store i64 %t55, ptr %l39, !tbaa !24
  %t56 = load i64, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l39, !tbaa !24
  %t58 = add i64 %t56, %t57
  store i64 %t58, ptr %l40, !tbaa !24
  %t59 = load i64, ptr %l40, !tbaa !24
  store i64 %t59, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  store i64 %t60, ptr %l41, !tbaa !24
  %t61 = load i64, ptr %l41, !tbaa !24
  %t62 = icmp sgt i64 %t61, 0
  store i1 %t62, ptr %l42, !tbaa !21
  %t63 = load i1, ptr %l42, !tbaa !21
  br i1 %t63, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l2, ptr %l43, !tbaa !29
  %t64 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t64, { i64, ptr } { i64 2, ptr @.d31 })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  store ptr %l2, ptr %l44, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l45, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t66, ptr %l46, !tbaa !27
  %t67 = load i64, ptr %l9, !tbaa !24
  store i64 %t67, ptr %l47, !tbaa !24
  %t68 = load i64, ptr %l47, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i32, ptr %t70, i64 %t68
  %t72 = load i32, ptr %t71, !tbaa !33
  store i32 %t72, ptr %l48, !tbaa !23
  %t73 = load ptr, ptr %l45, !tbaa !29
  %t74 = load i32, ptr %l48, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l49
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t76, { i64, ptr } %t77)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load i64, ptr %l8, !tbaa !24
  store i64 %t78, ptr %l50, !tbaa !24
  %t79 = load i64, ptr %l50, !tbaa !24
  %t80 = add i64 %t79, 1
  store i64 %t80, ptr %l51, !tbaa !24
  %t81 = load i64, ptr %l51, !tbaa !24
  store i64 %t81, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb10
bb21:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l2, ptr %l52, !tbaa !29
  %t82 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t82, { i64, ptr } { i64 2, ptr @.d32 })
  br label %bb22
bb22:
  store ptr %l2, ptr %l53, !tbaa !29
  %t83 = load ptr, ptr %l53, !tbaa !29
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t83)
  store { i64, ptr } %t84, ptr %l54
  br label %bb23
bb23:
  %t85 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t85, ptr %l55, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l56, !tbaa !24
  %t88 = load i64, ptr %l56, !tbaa !24
  %t89 = mul i64 %t88, 1
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l57, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l56, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  %t99 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp eq i32 %t6, 0
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 12, ptr @.d33 }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l10, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l11, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l12, !tbaa !23
  %t28 = load ptr, ptr %l11, !tbaa !29
  %t29 = load i32, ptr %l12, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l13
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l10, !tbaa !29
  %t32 = load i32, ptr %l13, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t33, ptr %l14
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l16, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  store i32 %t36, ptr %l17, !tbaa !23
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l17, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l18
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l15, !tbaa !29
  %t41 = load i32, ptr %l18, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l19
  br label %bb8
bb8:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t43 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t43, i64 %t44)
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = call ptr @__olang_sb_room(ptr %s2, i64 24)
  %t47 = call i64 @__olang_fmt_i64(ptr %t46, i64 %t45)
  call void @__olang_sb_add(ptr %s2, i64 %t47)
  %t48 = extractvalue { i64, ptr } { i64 3, ptr @.d35 }, 1
  %t49 = extractvalue { i64, ptr } { i64 3, ptr @.d35 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t48, i64 %t49)
  %t50 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  call void @__olang_sb_put(ptr %s2, ptr %t51, i64 %t52)
  %t53 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t54 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t53, i64 %t54)
  %t55 = load ptr, ptr %s2
  %t56 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t57 = load i64, ptr %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t55, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l20, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/types:data"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/types:data"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 1
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call %"compiler/types:data" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t7, i64 %t8)
  store %"compiler/types:data" %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:body"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/types:body"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/types:body"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 14
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = call { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %t5, i32 %t6)
  %t8 = extractvalue { i32, %"compiler/types:body" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/types:body" } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store %"compiler/types:body" %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load %"compiler/types:body", ptr %l6
  store %"compiler/types:body" %t12, ptr %l2
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t13, ptr %l8, !tbaa !23
  %t14 = load i32, ptr %l8, !tbaa !23
  %t15 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t14, i1 false, i1 false)
  store %"compiler/types:body" %t15, ptr %l9
  br label %bb4
bb4:
  %t16 = load %"compiler/types:body", ptr %l9
  store %"compiler/types:body" %t16, ptr %l2
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/types:body", ptr %l2
  store %"compiler/types:body" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:body", ptr %rv
  ret %"compiler/types:body" %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:data"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca %"compiler/types:data"
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i32
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l69 = alloca i1
  %l70 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i32
  %l73 = alloca i1
  %l74 = alloca i32
  %l75 = alloca i1
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i32
  %l79 = alloca i1
  %l80 = alloca i32
  %l81 = alloca i1
  %l82 = alloca i32
  %l83 = alloca i1
  %l84 = alloca i32
  %l85 = alloca i1
  %l86 = alloca i32
  %l87 = alloca i1
  %l88 = alloca i32
  %l89 = alloca i1
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca i32
  %l93 = alloca i1
  %l94 = alloca i32
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i32
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l101 = alloca i32
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i32
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca i32
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i64
  %l115 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca i32
  %l123 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i1
  %l138 = alloca i64
  %l139 = alloca i64
  %l140 = alloca i1
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i64
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i1
  %l153 = alloca i1
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l165 = alloca i64
  %l166 = alloca i32
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca i32
  %l177 = alloca i32
  %l178 = alloca ptr
  %l179 = alloca i32
  %l180 = alloca i32
  %l181 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca ptr
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca i32
  %l190 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i32
  %l193 = alloca i64
  %l194 = alloca i64
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i64
  %l200 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i1
  %l203 = alloca ptr
  %l204 = alloca ptr
  %l205 = alloca ptr
  %l206 = alloca ptr
  %l207 = alloca i32
  %l208 = alloca i32
  %l209 = alloca ptr
  %l210 = alloca i32
  %l211 = alloca i1
  %l212 = alloca ptr
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca i32
  %l217 = alloca i32
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca i32
  %l221 = alloca i32
  %l222 = alloca i32
  %l223 = alloca i32
  %l224 = alloca i1
  %l225 = alloca ptr
  %l226 = alloca i32
  %l227 = alloca i32
  %l228 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca ptr
  %l231 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i1
  %l234 = alloca { i64, ptr }
  %l235 = alloca ptr
  %l236 = alloca ptr
  %l237 = alloca i32
  %l238 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca i32
  %l243 = alloca i32
  %l244 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca i64
  %l247 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca { i64, ptr }
  %l250 = alloca i64
  %l251 = alloca i1
  %l252 = alloca i1
  %l253 = alloca { i64, ptr }
  %l254 = alloca i32
  %l255 = alloca i32
  %l256 = alloca i1
  %l257 = alloca i1
  %l258 = alloca { i64, ptr }
  %l259 = alloca i64
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca i1
  %l263 = alloca i64
  %l264 = alloca i64
  %l265 = alloca i1
  %l266 = alloca i64
  %l267 = alloca i64
  %l268 = alloca i64
  %l269 = alloca i64
  %l270 = alloca i64
  %l271 = alloca i64
  %l272 = alloca i64
  %l273 = alloca i64
  %l274 = alloca i64
  %l275 = alloca i64
  %l276 = alloca i64
  %l277 = alloca i1
  %l278 = alloca i1
  %l279 = alloca i64
  %l280 = alloca i64
  %l281 = alloca i64
  %l282 = alloca i64
  %l283 = alloca i64
  %l284 = alloca ptr
  %l285 = alloca i64
  %l286 = alloca i1
  %l287 = alloca { i64, ptr }
  %l288 = alloca ptr
  %l289 = alloca ptr
  %l290 = alloca { i64, ptr }
  %l291 = alloca i64
  %l292 = alloca i32
  %l293 = alloca i64
  %l294 = alloca i64
  %l295 = alloca i64
  %l296 = alloca i1
  %l297 = alloca ptr
  %l298 = alloca ptr
  %l299 = alloca i64
  %l300 = alloca { i64, ptr }
  %l301 = alloca ptr
  %l302 = alloca { i64, ptr }
  %l303 = alloca i64
  %l304 = alloca i64
  %l305 = alloca i64
  %l306 = alloca i1
  %l307 = alloca i64
  %l308 = alloca i64
  %l309 = alloca i1
  %l310 = alloca i64
  %l311 = alloca i64
  %l312 = alloca i64
  %l313 = alloca i64
  %l314 = alloca i64
  %l315 = alloca i64
  %l316 = alloca i64
  %l317 = alloca i64
  %l318 = alloca i64
  %l319 = alloca i64
  %l320 = alloca i64
  %l321 = alloca i1
  %l322 = alloca i1
  %l323 = alloca i64
  %l324 = alloca i64
  %l325 = alloca i64
  %l326 = alloca i64
  %l327 = alloca i64
  %l328 = alloca i64
  %l329 = alloca i1
  %l330 = alloca ptr
  %l331 = alloca ptr
  %l332 = alloca { i64, ptr }
  %l333 = alloca i64
  %l334 = alloca i64
  %l335 = alloca { i64, ptr }
  %l336 = alloca { i64, ptr }
  %l337 = alloca i64
  %l338 = alloca i64
  %l339 = alloca ptr
  %l340 = alloca i32
  %l341 = alloca i1
  %l342 = alloca ptr
  %l343 = alloca ptr
  %l344 = alloca ptr
  %l345 = alloca ptr
  %l346 = alloca i32
  %l347 = alloca i32
  %l348 = alloca ptr
  %l349 = alloca i32
  %l350 = alloca i1
  %l351 = alloca ptr
  %l352 = alloca ptr
  %l353 = alloca ptr
  %l354 = alloca ptr
  %l355 = alloca i32
  %l356 = alloca i32
  %l357 = alloca ptr
  %l358 = alloca i32
  %l359 = alloca i1
  %l360 = alloca ptr
  %l361 = alloca ptr
  %l362 = alloca i32
  %l363 = alloca { i64, ptr }
  %l364 = alloca ptr
  %l365 = alloca ptr
  %l366 = alloca i32
  %l367 = alloca i32
  %l368 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l370 = alloca i64
  %l371 = alloca i64
  %l372 = alloca i64
  %l373 = alloca i1
  %l374 = alloca i64
  %l375 = alloca i64
  %l376 = alloca i1
  %l377 = alloca i64
  %l378 = alloca i64
  %l379 = alloca i64
  %l380 = alloca i64
  %l381 = alloca i64
  %l382 = alloca i64
  %l383 = alloca i64
  %l384 = alloca i64
  %l385 = alloca i64
  %l386 = alloca i64
  %l387 = alloca i64
  %l388 = alloca i1
  %l389 = alloca i1
  %l390 = alloca i64
  %l391 = alloca i64
  %l392 = alloca i64
  %l393 = alloca i64
  %l394 = alloca i64
  %l395 = alloca i64
  %l396 = alloca i1
  %l397 = alloca ptr
  %l398 = alloca ptr
  %l399 = alloca ptr
  %l400 = alloca ptr
  %l401 = alloca { i64, ptr }
  %l402 = alloca i64
  %l403 = alloca i32
  %l404 = alloca { i64, ptr }
  %l405 = alloca { i64, ptr }
  %l406 = alloca i64
  %l407 = alloca i32
  %l408 = alloca i1
  %l409 = alloca ptr
  %l410 = alloca ptr
  %l411 = alloca ptr
  %l412 = alloca ptr
  %l413 = alloca { i64, ptr }
  %l414 = alloca i64
  %l415 = alloca i32
  %l416 = alloca i32
  %l417 = alloca ptr
  %l418 = alloca i64
  %l419 = alloca i64
  %l420 = alloca ptr
  %l421 = alloca i32
  %l422 = alloca i1
  %l423 = alloca ptr
  %l424 = alloca i64
  %l425 = alloca i64
  %l426 = alloca { i64, ptr }
  %l427 = alloca { i64, ptr }
  %l428 = alloca i32
  %l429 = alloca i1
  %l430 = alloca ptr
  %l431 = alloca i32
  %l432 = alloca i32
  %l433 = alloca i32
  %l434 = alloca i32
  %l435 = alloca i1
  %l436 = alloca ptr
  %l437 = alloca i64
  %l438 = alloca i1
  %l439 = alloca { i64, ptr }
  %l440 = alloca ptr
  %l441 = alloca i32
  %l442 = alloca i1
  %l443 = alloca i1
  %l444 = alloca i64
  %l445 = alloca i1
  %l446 = alloca ptr
  %l447 = alloca i64
  %l448 = alloca { i64, ptr }
  %l449 = alloca { i64, ptr }
  %l450 = alloca ptr
  %l451 = alloca i64
  %l452 = alloca { i64, ptr }
  %l453 = alloca { i64, ptr }
  %l454 = alloca i32
  %l455 = alloca i1
  %l456 = alloca ptr
  %l457 = alloca ptr
  %l458 = alloca i32
  %l459 = alloca { i64, ptr }
  %l460 = alloca { i64, ptr }
  %l461 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.builder
  %s31room = alloca [64 x i8], align 8
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.builder
  %s42room = alloca [64 x i8], align 8
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s48 = alloca %olang.builder
  %s48room = alloca [64 x i8], align 8
  %s49 = alloca %olang.scope
  %s50 = alloca %olang.builder
  %s50room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l39, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l40, !tbaa !23
  %t3 = load ptr, ptr %l39, !tbaa !29
  %t4 = load i32, ptr %l40, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l41
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l41
  store %"compiler/types:data" %t6, ptr %l3
  %t7 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l42
  %t9 = load i32, ptr %l42
  store i32 %t9, ptr %l4
  %t10 = load i32, ptr %l4
  store i32 %t10, ptr %l43
  %t11 = load i32, ptr %l43
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %l44, !tbaa !21
  %t14 = load i1, ptr %l44, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l45, !tbaa !29
  %t16 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t16, { i64, ptr } { i64 1, ptr @.d37 })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb289
bb6:
  %t17 = load i32, ptr %l4
  store i32 %t17, ptr %l46
  %t18 = load i32, ptr %l46
  %t19 = trunc i64 15 to i32
  %t20 = icmp eq i32 %t18, %t19
  store i1 %t20, ptr %l47, !tbaa !21
  %t21 = load i1, ptr %l47, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l48, !tbaa !29
  %t23 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t23, { i64, ptr } { i64 4, ptr @.d38 })
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb289
bb11:
  %t24 = load i32, ptr %l4
  store i32 %t24, ptr %l49
  %t25 = load i32, ptr %l49
  %t26 = trunc i64 16 to i32
  %t27 = icmp eq i32 %t25, %t26
  store i1 %t27, ptr %l50, !tbaa !21
  %t28 = load i1, ptr %l50, !tbaa !21
  br i1 %t28, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l51, !tbaa !29
  %t30 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t30, { i64, ptr } { i64 7, ptr @.d39 })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb289
bb16:
  %t31 = load i32, ptr %l4
  store i32 %t31, ptr %l52
  %t32 = load i32, ptr %l52
  %t33 = trunc i64 17 to i32
  %t34 = icmp eq i32 %t32, %t33
  store i1 %t34, ptr %l53, !tbaa !21
  %t35 = load i1, ptr %l53, !tbaa !21
  br i1 %t35, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l54, !tbaa !29
  %t37 = load ptr, ptr %l54, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t37, { i64, ptr } { i64 8, ptr @.d40 })
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb289
bb21:
  %t38 = load i32, ptr %l4
  store i32 %t38, ptr %l55
  %t39 = load i32, ptr %l55
  %t40 = trunc i64 28 to i32
  %t41 = icmp eq i32 %t39, %t40
  store i1 %t41, ptr %l56, !tbaa !21
  %t42 = load i1, ptr %l56, !tbaa !21
  br i1 %t42, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l57, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l58, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l59, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  store i32 %t46, ptr %l60, !tbaa !23
  %t47 = load ptr, ptr %l59, !tbaa !29
  %t48 = load i32, ptr %l60, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t49, ptr %l61
  br label %bb25
bb25:
  %t50 = load ptr, ptr %l57, !tbaa !29
  %t51 = load ptr, ptr %l58, !tbaa !29
  %t52 = load i32, ptr %l61, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t50, ptr %t51, i32 %t52)
  br label %bb26
bb26:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l62, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l63, !tbaa !29
  %t55 = load i32, ptr %l2, !tbaa !23
  store i32 %t55, ptr %l64, !tbaa !23
  %t56 = load ptr, ptr %l63, !tbaa !29
  %t57 = load i32, ptr %l64, !tbaa !23
  %t58 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t56, i32 %t57)
  store i64 %t58, ptr %l65
  br label %bb27
bb27:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t59 = extractvalue { i64, ptr } { i64 2, ptr @.d41 }, 1
  %t60 = extractvalue { i64, ptr } { i64 2, ptr @.d41 }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t59, i64 %t60)
  %t61 = load i64, ptr %l65, !tbaa !65
  %t62 = call ptr @__olang_sb_room(ptr %s6, i64 24)
  %t63 = call i64 @__olang_fmt_u64(ptr %t62, i64 %t61)
  call void @__olang_sb_add(ptr %s6, i64 %t63)
  %t64 = load ptr, ptr %s6
  %t65 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t66 = load i64, ptr %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t64, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l66, !tbaa !27
  call void @__olang_sb_done(ptr %s6)
  %t70 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l67, !tbaa !27
  %t77 = load ptr, ptr %l62, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l67, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t77, { i64, ptr } %t78)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb289
bb29:
  %t79 = load i32, ptr %l4
  store i32 %t79, ptr %l68
  %t80 = load i32, ptr %l68
  %t81 = trunc i64 1 to i32
  %t82 = icmp eq i32 %t80, %t81
  store i1 %t82, ptr %l69, !tbaa !21
  %t83 = load i1, ptr %l69, !tbaa !21
  br i1 %t83, label %bb30, label %bb31
bb30:
  br label %bb58
bb31:
  %t84 = load i32, ptr %l4
  store i32 %t84, ptr %l70
  %t85 = load i32, ptr %l70
  %t86 = trunc i64 2 to i32
  %t87 = icmp eq i32 %t85, %t86
  store i1 %t87, ptr %l71, !tbaa !21
  %t88 = load i1, ptr %l71, !tbaa !21
  br i1 %t88, label %bb32, label %bb33
bb32:
  br label %bb58
bb33:
  %t89 = load i32, ptr %l4
  store i32 %t89, ptr %l72
  %t90 = load i32, ptr %l72
  %t91 = trunc i64 3 to i32
  %t92 = icmp eq i32 %t90, %t91
  store i1 %t92, ptr %l73, !tbaa !21
  %t93 = load i1, ptr %l73, !tbaa !21
  br i1 %t93, label %bb34, label %bb35
bb34:
  br label %bb58
bb35:
  %t94 = load i32, ptr %l4
  store i32 %t94, ptr %l74
  %t95 = load i32, ptr %l74
  %t96 = trunc i64 4 to i32
  %t97 = icmp eq i32 %t95, %t96
  store i1 %t97, ptr %l75, !tbaa !21
  %t98 = load i1, ptr %l75, !tbaa !21
  br i1 %t98, label %bb36, label %bb37
bb36:
  br label %bb58
bb37:
  %t99 = load i32, ptr %l4
  store i32 %t99, ptr %l76
  %t100 = load i32, ptr %l76
  %t101 = trunc i64 5 to i32
  %t102 = icmp eq i32 %t100, %t101
  store i1 %t102, ptr %l77, !tbaa !21
  %t103 = load i1, ptr %l77, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  %t104 = load i32, ptr %l4
  store i32 %t104, ptr %l78
  %t105 = load i32, ptr %l78
  %t106 = trunc i64 6 to i32
  %t107 = icmp eq i32 %t105, %t106
  store i1 %t107, ptr %l79, !tbaa !21
  %t108 = load i1, ptr %l79, !tbaa !21
  br i1 %t108, label %bb40, label %bb41
bb40:
  br label %bb58
bb41:
  %t109 = load i32, ptr %l4
  store i32 %t109, ptr %l80
  %t110 = load i32, ptr %l80
  %t111 = trunc i64 7 to i32
  %t112 = icmp eq i32 %t110, %t111
  store i1 %t112, ptr %l81, !tbaa !21
  %t113 = load i1, ptr %l81, !tbaa !21
  br i1 %t113, label %bb42, label %bb43
bb42:
  br label %bb58
bb43:
  %t114 = load i32, ptr %l4
  store i32 %t114, ptr %l82
  %t115 = load i32, ptr %l82
  %t116 = trunc i64 8 to i32
  %t117 = icmp eq i32 %t115, %t116
  store i1 %t117, ptr %l83, !tbaa !21
  %t118 = load i1, ptr %l83, !tbaa !21
  br i1 %t118, label %bb44, label %bb45
bb44:
  br label %bb58
bb45:
  %t119 = load i32, ptr %l4
  store i32 %t119, ptr %l84
  %t120 = load i32, ptr %l84
  %t121 = trunc i64 9 to i32
  %t122 = icmp eq i32 %t120, %t121
  store i1 %t122, ptr %l85, !tbaa !21
  %t123 = load i1, ptr %l85, !tbaa !21
  br i1 %t123, label %bb46, label %bb47
bb46:
  br label %bb58
bb47:
  %t124 = load i32, ptr %l4
  store i32 %t124, ptr %l86
  %t125 = load i32, ptr %l86
  %t126 = trunc i64 10 to i32
  %t127 = icmp eq i32 %t125, %t126
  store i1 %t127, ptr %l87, !tbaa !21
  %t128 = load i1, ptr %l87, !tbaa !21
  br i1 %t128, label %bb48, label %bb49
bb48:
  br label %bb58
bb49:
  %t129 = load i32, ptr %l4
  store i32 %t129, ptr %l88
  %t130 = load i32, ptr %l88
  %t131 = trunc i64 11 to i32
  %t132 = icmp eq i32 %t130, %t131
  store i1 %t132, ptr %l89, !tbaa !21
  %t133 = load i1, ptr %l89, !tbaa !21
  br i1 %t133, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  %t134 = load i32, ptr %l4
  store i32 %t134, ptr %l90
  %t135 = load i32, ptr %l90
  %t136 = trunc i64 12 to i32
  %t137 = icmp eq i32 %t135, %t136
  store i1 %t137, ptr %l91, !tbaa !21
  %t138 = load i1, ptr %l91, !tbaa !21
  br i1 %t138, label %bb52, label %bb53
bb52:
  br label %bb58
bb53:
  %t139 = load i32, ptr %l4
  store i32 %t139, ptr %l92
  %t140 = load i32, ptr %l92
  %t141 = trunc i64 13 to i32
  %t142 = icmp eq i32 %t140, %t141
  store i1 %t142, ptr %l93, !tbaa !21
  %t143 = load i1, ptr %l93, !tbaa !21
  br i1 %t143, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  %t144 = load i32, ptr %l4
  store i32 %t144, ptr %l94
  %t145 = load i32, ptr %l94
  %t146 = trunc i64 14 to i32
  %t147 = icmp eq i32 %t145, %t146
  store i1 %t147, ptr %l95, !tbaa !21
  %t148 = load i1, ptr %l95, !tbaa !21
  br i1 %t148, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb63
bb58:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l96, !tbaa !29
  %t150 = load i32, ptr %l2, !tbaa !23
  store i32 %t150, ptr %l97, !tbaa !23
  %t151 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t151, ptr %l98, !tbaa !23
  %t152 = load i32, ptr %l97, !tbaa !23
  %t153 = load i32, ptr %l98, !tbaa !23
  %t154 = icmp eq i32 %t152, %t153
  store i1 %t154, ptr %l99, !tbaa !21
  %t155 = load i1, ptr %l99, !tbaa !21
  br i1 %t155, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 4, ptr @.d42 }, ptr %l100, !tbaa !27
  br label %bb61
bb60:
  %t156 = load i32, ptr %l2, !tbaa !23
  store i32 %t156, ptr %l101, !tbaa !23
  %t157 = load i32, ptr %l101, !tbaa !23
  %t158 = sext i32 %t157 to i64
  store i64 %t158, ptr %l102, !tbaa !24
  %t159 = load i64, ptr %l102, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimNames, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %t161, i64 %t159
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !37
  store { i64, ptr } %t163, ptr %l103, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t164, ptr %l100, !tbaa !27
  br label %bb61
bb61:
  %t165 = load ptr, ptr @__olang_prog_scope
  %t166 = load ptr, ptr %l96, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %t165, ptr %t166, { i64, ptr } %t167)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s7)
  br label %bb289
bb63:
  %t168 = load i32, ptr %l4
  store i32 %t168, ptr %l104
  %t169 = load i32, ptr %l104
  %t170 = trunc i64 18 to i32
  %t171 = icmp eq i32 %t169, %t170
  store i1 %t171, ptr %l105, !tbaa !21
  %t172 = load i1, ptr %l105, !tbaa !21
  br i1 %t172, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb99
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l106, !tbaa !29
  %t174 = load i32, ptr %l2, !tbaa !23
  store i32 %t174, ptr %l107, !tbaa !23
  %t175 = load ptr, ptr %l106, !tbaa !29
  %t176 = load i32, ptr %l107, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t177, ptr %l108
  br label %bb67
bb67:
  %t178 = load i32, ptr %l108, !tbaa !23
  store i32 %t178, ptr %l5, !tbaa !23
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l109, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l110, !tbaa !29
  %t181 = load ptr, ptr %l110, !tbaa !29
  %t182 = getelementptr %"compiler/types:Table", ptr %t181, i32 0, i32 12
  store ptr %t182, ptr %l111, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l112, !tbaa !29
  %t184 = load i32, ptr %l5, !tbaa !23
  store i32 %t184, ptr %l113, !tbaa !23
  %t185 = load ptr, ptr %l112, !tbaa !29
  %t186 = load i32, ptr %l113, !tbaa !23
  %t187 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t185, i32 %t186)
  store i64 %t187, ptr %l114
  br label %bb68
bb68:
  %t188 = load ptr, ptr %l111, !tbaa !29
  %t189 = load i64, ptr %l114, !tbaa !24
  %t190 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t188, i64 %t189)
  store { i64, ptr } %t190, ptr %l115
  br label %bb69
bb69:
  %t191 = load ptr, ptr %l109, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l115, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t191, { i64, ptr } %t192)
  br label %bb70
bb70:
  %t193 = load ptr, ptr %l1, !tbaa !29
  store ptr %t193, ptr %l116, !tbaa !29
  %t194 = load ptr, ptr %l116, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t194, i8 58)
  br label %bb71
bb71:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l117, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l118, !tbaa !29
  %t197 = load ptr, ptr %l118, !tbaa !29
  %t198 = getelementptr %"compiler/types:Table", ptr %t197, i32 0, i32 0
  %t199 = load ptr, ptr %t198, !tbaa !29
  store ptr %t199, ptr %l119, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l120, !tbaa !29
  %t201 = load i32, ptr %l5, !tbaa !23
  store i32 %t201, ptr %l121, !tbaa !23
  %t202 = load ptr, ptr %l120, !tbaa !29
  %t203 = load i32, ptr %l121, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t204, ptr %l122
  br label %bb72
bb72:
  %t205 = load ptr, ptr %l119, !tbaa !29
  %t206 = load i32, ptr %l122, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t205, i32 %t206)
  store { i64, ptr } %t207, ptr %l123
  br label %bb73
bb73:
  %t208 = load ptr, ptr %l117, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l123, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t208, { i64, ptr } %t209)
  br label %bb74
bb74:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l124, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l125, !tbaa !29
  %t212 = load i32, ptr %l2, !tbaa !23
  store i32 %t212, ptr %l126, !tbaa !23
  %t213 = load ptr, ptr %l125, !tbaa !29
  %t214 = load i32, ptr %l126, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t215, ptr %l127
  br label %bb75
bb75:
  %t216 = load ptr, ptr %l124, !tbaa !29
  %t217 = load i32, ptr %l127, !tbaa !23
  %t218 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t216, i32 %t217)
  store { i64, ptr } %t218, ptr %l128
  br label %bb76
bb76:
  %t219 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t219, ptr %l6, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t220, ptr %l129, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l130, !tbaa !24
  %t223 = load i64, ptr %l130, !tbaa !24
  %t224 = icmp sgt i64 %t223, 0
  store i1 %t224, ptr %l131, !tbaa !21
  %t225 = load i1, ptr %l131, !tbaa !21
  br i1 %t225, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s9
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l132, !tbaa !29
  %t227 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t227, i8 60)
  br label %bb79
bb78:
  br label %bb98
bb79:
  store %olang.scope zeroinitializer, ptr %s10
  store i64 0, ptr %l7, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t228, ptr %l133, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  store i64 %t230, ptr %l134, !tbaa !24
  %t231 = load i64, ptr %l134, !tbaa !24
  store i64 %t231, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t232 = load i64, ptr %l8, !tbaa !24
  store i64 %t232, ptr %l135, !tbaa !24
  %t233 = load i64, ptr %l7, !tbaa !24
  store i64 %t233, ptr %l136, !tbaa !24
  %t234 = load i64, ptr %l135, !tbaa !24
  %t235 = load i64, ptr %l136, !tbaa !24
  %t236 = icmp sgt i64 %t234, %t235
  store i1 %t236, ptr %l137, !tbaa !21
  %t237 = load i1, ptr %l137, !tbaa !21
  br i1 %t237, label %bb80, label %bb81
bb80:
  %t238 = load i64, ptr %l9, !tbaa !24
  store i64 %t238, ptr %l139, !tbaa !24
  %t239 = load i64, ptr %l139, !tbaa !24
  %t240 = icmp sgt i64 %t239, 0
  store i1 %t240, ptr %l140, !tbaa !21
  %t241 = load i1, ptr %l140, !tbaa !21
  br i1 %t241, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb85
bb82:
  %t242 = load i64, ptr %l8, !tbaa !24
  store i64 %t242, ptr %l142, !tbaa !24
  %t243 = load i64, ptr %l7, !tbaa !24
  store i64 %t243, ptr %l143, !tbaa !24
  %t244 = load i64, ptr %l142, !tbaa !24
  %t245 = load i64, ptr %l143, !tbaa !24
  %t246 = sub i64 %t244, %t245
  store i64 %t246, ptr %l144, !tbaa !24
  %t247 = load i64, ptr %l9, !tbaa !24
  store i64 %t247, ptr %l145, !tbaa !24
  %t248 = load i64, ptr %l144, !tbaa !24
  %t249 = load i64, ptr %l145, !tbaa !24
  %t250 = add i64 %t248, %t249
  store i64 %t250, ptr %l146, !tbaa !24
  %t251 = load i64, ptr %l146, !tbaa !24
  %t252 = sub i64 %t251, 1
  store i64 %t252, ptr %l147, !tbaa !24
  %t253 = load i64, ptr %l9, !tbaa !24
  store i64 %t253, ptr %l148, !tbaa !24
  %t254 = load i64, ptr %l147, !tbaa !24
  %t255 = load i64, ptr %l148, !tbaa !24
  %t256 = sdiv i64 %t254, %t255
  store i64 %t256, ptr %l149, !tbaa !24
  %t257 = load i64, ptr %l149, !tbaa !24
  store i64 %t257, ptr %l141, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb84
bb84:
  %t258 = load i64, ptr %l141, !tbaa !24
  store i64 %t258, ptr %l138, !tbaa !24
  br label %bb85
bb85:
  %t259 = load i64, ptr %l138, !tbaa !24
  store i64 %t259, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s11
  %t260 = load i64, ptr %l11, !tbaa !24
  store i64 %t260, ptr %l150, !tbaa !24
  %t261 = load i64, ptr %l10, !tbaa !24
  store i64 %t261, ptr %l151, !tbaa !24
  %t262 = load i64, ptr %l150, !tbaa !24
  %t263 = load i64, ptr %l151, !tbaa !24
  %t264 = icmp slt i64 %t262, %t263
  store i1 %t264, ptr %l152, !tbaa !21
  %t265 = load i1, ptr %l152, !tbaa !21
  %t266 = xor i1 %t265, true
  store i1 %t266, ptr %l153, !tbaa !21
  %t267 = load i1, ptr %l153, !tbaa !21
  br i1 %t267, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s11)
  br label %bb96
bb88:
  br label %bb89
bb89:
  %t268 = load i64, ptr %l7, !tbaa !24
  store i64 %t268, ptr %l154, !tbaa !24
  %t269 = load i64, ptr %l11, !tbaa !24
  store i64 %t269, ptr %l155, !tbaa !24
  %t270 = load i64, ptr %l9, !tbaa !24
  store i64 %t270, ptr %l156, !tbaa !24
  %t271 = load i64, ptr %l155, !tbaa !24
  %t272 = load i64, ptr %l156, !tbaa !24
  %t273 = mul i64 %t271, %t272
  store i64 %t273, ptr %l157, !tbaa !24
  %t274 = load i64, ptr %l154, !tbaa !24
  %t275 = load i64, ptr %l157, !tbaa !24
  %t276 = add i64 %t274, %t275
  store i64 %t276, ptr %l158, !tbaa !24
  %t277 = load i64, ptr %l158, !tbaa !24
  store i64 %t277, ptr %l12, !tbaa !24
  %t278 = load i64, ptr %l12, !tbaa !24
  store i64 %t278, ptr %l159, !tbaa !24
  %t279 = load i64, ptr %l159, !tbaa !24
  %t280 = icmp sgt i64 %t279, 0
  store i1 %t280, ptr %l160, !tbaa !21
  %t281 = load i1, ptr %l160, !tbaa !21
  br i1 %t281, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s12
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l161, !tbaa !29
  %t283 = load ptr, ptr %l161, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s12, ptr %t283, { i64, ptr } { i64 2, ptr @.d43 })
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb93:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l162, !tbaa !29
  %t285 = load ptr, ptr %l1, !tbaa !29
  store ptr %t285, ptr %l163, !tbaa !29
  %t286 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t286, ptr %l164, !tbaa !27
  %t287 = load i64, ptr %l12, !tbaa !24
  store i64 %t287, ptr %l165, !tbaa !24
  %t288 = load i64, ptr %l165, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i32, ptr %t290, i64 %t288
  %t292 = load i32, ptr %t291, !tbaa !33
  store i32 %t292, ptr %l166, !tbaa !23
  %t293 = load ptr, ptr %l162, !tbaa !29
  %t294 = load ptr, ptr %l163, !tbaa !29
  %t295 = load i32, ptr %l166, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t293, ptr %t294, i32 %t295)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s13
  %t296 = load i64, ptr %l11, !tbaa !24
  store i64 %t296, ptr %l167, !tbaa !24
  %t297 = load i64, ptr %l167, !tbaa !24
  %t298 = add i64 %t297, 1
  store i64 %t298, ptr %l168, !tbaa !24
  %t299 = load i64, ptr %l168, !tbaa !24
  store i64 %t299, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb86
bb96:
  call void @__olang_scope_close(ptr %s10)
  %t300 = load ptr, ptr %l1, !tbaa !29
  store ptr %t300, ptr %l169, !tbaa !29
  %t301 = load ptr, ptr %l169, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t301, i8 62)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s9)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s8)
  br label %bb289
bb99:
  %t302 = load i32, ptr %l4
  store i32 %t302, ptr %l170
  %t303 = load i32, ptr %l170
  %t304 = trunc i64 19 to i32
  %t305 = icmp eq i32 %t303, %t304
  store i1 %t305, ptr %l171, !tbaa !21
  %t306 = load i1, ptr %l171, !tbaa !21
  br i1 %t306, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb114
bb102:
  store %olang.scope zeroinitializer, ptr %s14
  %t307 = load ptr, ptr %l1, !tbaa !29
  store ptr %t307, ptr %l172, !tbaa !29
  %t308 = load ptr, ptr %l172, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s14, ptr %t308, { i64, ptr } { i64 6, ptr @.d44 })
  br label %bb103
bb103:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l173, !tbaa !29
  %t310 = load ptr, ptr %l1, !tbaa !29
  store ptr %t310, ptr %l174, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l175, !tbaa !29
  %t312 = load i32, ptr %l2, !tbaa !23
  store i32 %t312, ptr %l176, !tbaa !23
  %t313 = load ptr, ptr %l175, !tbaa !29
  %t314 = load i32, ptr %l176, !tbaa !23
  %t315 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t313, i32 %t314)
  store i32 %t315, ptr %l177
  br label %bb104
bb104:
  %t316 = load ptr, ptr %l173, !tbaa !29
  %t317 = load ptr, ptr %l174, !tbaa !29
  %t318 = load i32, ptr %l177, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t316, ptr %t317, i32 %t318)
  br label %bb105
bb105:
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l178, !tbaa !29
  %t320 = load i32, ptr %l2, !tbaa !23
  store i32 %t320, ptr %l179, !tbaa !23
  %t321 = load ptr, ptr %l178, !tbaa !29
  %t322 = load i32, ptr %l179, !tbaa !23
  %t323 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t321, i32 %t322)
  store i32 %t323, ptr %l180
  br label %bb106
bb106:
  %t324 = load i32, ptr %l180, !tbaa !23
  %t325 = icmp ne i32 %t324, 0
  store i1 %t325, ptr %l181, !tbaa !21
  %t326 = load i1, ptr %l181, !tbaa !21
  br i1 %t326, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s15
  %t327 = load ptr, ptr %l1, !tbaa !29
  store ptr %t327, ptr %l182, !tbaa !29
  %t328 = load ptr, ptr %l182, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t328, { i64, ptr } { i64 2, ptr @.d45 })
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l183, !tbaa !29
  %t330 = load ptr, ptr %l1, !tbaa !29
  store ptr %t330, ptr %l184, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l185, !tbaa !29
  %t332 = load i32, ptr %l2, !tbaa !23
  store i32 %t332, ptr %l186, !tbaa !23
  %t333 = load ptr, ptr %l185, !tbaa !29
  %t334 = load i32, ptr %l186, !tbaa !23
  %t335 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t335, ptr %l187
  br label %bb110
bb110:
  %t336 = load ptr, ptr %l183, !tbaa !29
  %t337 = load ptr, ptr %l184, !tbaa !29
  %t338 = load i32, ptr %l187, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t336, ptr %t337, i32 %t338)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s15)
  br label %bb112
bb112:
  %t339 = load ptr, ptr %l1, !tbaa !29
  store ptr %t339, ptr %l188, !tbaa !29
  %t340 = load ptr, ptr %l188, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t340, i8 62)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s14)
  br label %bb289
bb114:
  %t341 = load i32, ptr %l4
  store i32 %t341, ptr %l189
  %t342 = load i32, ptr %l189
  %t343 = trunc i64 20 to i32
  %t344 = icmp eq i32 %t342, %t343
  store i1 %t344, ptr %l190, !tbaa !21
  %t345 = load i1, ptr %l190, !tbaa !21
  br i1 %t345, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb130
bb117:
  store %olang.scope zeroinitializer, ptr %s16
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l191, !tbaa !29
  %t347 = load i32, ptr %l2, !tbaa !23
  store i32 %t347, ptr %l192, !tbaa !23
  %t348 = load ptr, ptr %l191, !tbaa !29
  %t349 = load i32, ptr %l192, !tbaa !23
  %t350 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t348, i32 %t349)
  store i64 %t350, ptr %l193
  br label %bb118
bb118:
  %t351 = load i64, ptr %l193, !tbaa !24
  store i64 %t351, ptr %l13, !tbaa !24
  %t352 = load i64, ptr %l13, !tbaa !24
  store i64 %t352, ptr %l194, !tbaa !24
  %t353 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  store i64 %t353, ptr %l195, !tbaa !24
  %t354 = load i64, ptr %l194, !tbaa !24
  %t355 = load i64, ptr %l195, !tbaa !24
  %t356 = and i64 %t354, %t355
  store i64 %t356, ptr %l196, !tbaa !24
  %t357 = load i64, ptr %l196, !tbaa !24
  %t358 = icmp ne i64 %t357, 0
  store i1 %t358, ptr %l197, !tbaa !21
  %t359 = load i1, ptr %l197, !tbaa !21
  br i1 %t359, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s17
  %t360 = load ptr, ptr %l1, !tbaa !29
  store ptr %t360, ptr %l198, !tbaa !29
  %t361 = load ptr, ptr %l198, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s17, ptr %t361, { i64, ptr } { i64 4, ptr @.d46 })
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s17)
  br label %bb122
bb122:
  %t362 = load i64, ptr %l13, !tbaa !24
  store i64 %t362, ptr %l199, !tbaa !24
  %t363 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t363, ptr %l200, !tbaa !24
  %t364 = load i64, ptr %l199, !tbaa !24
  %t365 = load i64, ptr %l200, !tbaa !24
  %t366 = and i64 %t364, %t365
  store i64 %t366, ptr %l201, !tbaa !24
  %t367 = load i64, ptr %l201, !tbaa !24
  %t368 = icmp ne i64 %t367, 0
  store i1 %t368, ptr %l202, !tbaa !21
  %t369 = load i1, ptr %l202, !tbaa !21
  br i1 %t369, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s18
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l203, !tbaa !29
  %t371 = load ptr, ptr %l203, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s18, ptr %t371, { i64, ptr } { i64 4, ptr @.d47 })
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s18)
  br label %bb126
bb126:
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l204, !tbaa !29
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l205, !tbaa !29
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l206, !tbaa !29
  %t375 = load i32, ptr %l2, !tbaa !23
  store i32 %t375, ptr %l207, !tbaa !23
  %t376 = load ptr, ptr %l206, !tbaa !29
  %t377 = load i32, ptr %l207, !tbaa !23
  %t378 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t376, i32 %t377)
  store i32 %t378, ptr %l208
  br label %bb127
bb127:
  %t379 = load ptr, ptr %l204, !tbaa !29
  %t380 = load ptr, ptr %l205, !tbaa !29
  %t381 = load i32, ptr %l208, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t379, ptr %t380, i32 %t381)
  br label %bb128
bb128:
  %t382 = load ptr, ptr %l1, !tbaa !29
  store ptr %t382, ptr %l209, !tbaa !29
  %t383 = load ptr, ptr %l209, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t383, i8 38)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s16)
  br label %bb289
bb130:
  %t384 = load i32, ptr %l4
  store i32 %t384, ptr %l210
  %t385 = load i32, ptr %l210
  %t386 = trunc i64 21 to i32
  %t387 = icmp eq i32 %t385, %t386
  store i1 %t387, ptr %l211, !tbaa !21
  %t388 = load i1, ptr %l211, !tbaa !21
  br i1 %t388, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb205
bb133:
  store %olang.scope zeroinitializer, ptr %s19
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l212, !tbaa !29
  %t390 = load ptr, ptr %l212, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t390, { i64, ptr } { i64 3, ptr @.d48 })
  br label %bb134
bb134:
  %t391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t391, ptr %l213, !tbaa !29
  %t392 = load ptr, ptr %l1, !tbaa !29
  store ptr %t392, ptr %l214, !tbaa !29
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l215, !tbaa !29
  %t394 = load i32, ptr %l2, !tbaa !23
  store i32 %t394, ptr %l216, !tbaa !23
  %t395 = load ptr, ptr %l215, !tbaa !29
  %t396 = load i32, ptr %l216, !tbaa !23
  %t397 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t395, i32 %t396)
  store i32 %t397, ptr %l217
  br label %bb135
bb135:
  %t398 = load ptr, ptr %l213, !tbaa !29
  %t399 = load ptr, ptr %l214, !tbaa !29
  %t400 = load i32, ptr %l217, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t398, ptr %t399, i32 %t400)
  br label %bb136
bb136:
  %t401 = load ptr, ptr %l1, !tbaa !29
  store ptr %t401, ptr %l218, !tbaa !29
  %t402 = load ptr, ptr %l218, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t402, i8 41)
  br label %bb137
bb137:
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l219, !tbaa !29
  %t404 = load i32, ptr %l2, !tbaa !23
  store i32 %t404, ptr %l220, !tbaa !23
  %t405 = load ptr, ptr %l219, !tbaa !29
  %t406 = load i32, ptr %l220, !tbaa !23
  %t407 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t407, ptr %l221
  br label %bb138
bb138:
  %t408 = load i32, ptr %l221, !tbaa !23
  store i32 %t408, ptr %l14, !tbaa !23
  %t409 = load i32, ptr %l14, !tbaa !23
  store i32 %t409, ptr %l222, !tbaa !23
  %t410 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t410, ptr %l223, !tbaa !23
  %t411 = load i32, ptr %l222, !tbaa !23
  %t412 = load i32, ptr %l223, !tbaa !23
  %t413 = icmp ne i32 %t411, %t412
  store i1 %t413, ptr %l224, !tbaa !21
  %t414 = load i1, ptr %l224, !tbaa !21
  br i1 %t414, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s20
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l225, !tbaa !29
  %t416 = load i32, ptr %l14, !tbaa !23
  store i32 %t416, ptr %l226, !tbaa !23
  %t417 = load ptr, ptr %l225, !tbaa !29
  %t418 = load i32, ptr %l226, !tbaa !23
  %t419 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t417, i32 %t418)
  store i32 %t419, ptr %l227
  br label %bb141
bb140:
  br label %bb152
bb141:
  store ptr %l227, ptr %l228, !tbaa !29
  store i32 21, ptr %l229
  store ptr %l229, ptr %l230, !tbaa !29
  %t420 = load ptr, ptr %l228, !tbaa !29
  %t421 = load ptr, ptr %l230, !tbaa !29
  %t422 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t420, ptr %t421)
  store i1 %t422, ptr %l231
  br label %bb142
bb142:
  %t423 = load i1, ptr %l231, !tbaa !21
  store i1 %t423, ptr %l15, !tbaa !21
  %t424 = load ptr, ptr %l1, !tbaa !29
  store ptr %t424, ptr %l232, !tbaa !29
  %t425 = load i1, ptr %l15, !tbaa !21
  store i1 %t425, ptr %l233, !tbaa !21
  %t426 = load i1, ptr %l233, !tbaa !21
  br i1 %t426, label %bb143, label %bb144
bb143:
  store { i64, ptr } { i64 2, ptr @.d49 }, ptr %l234, !tbaa !27
  br label %bb145
bb144:
  store { i64, ptr } { i64 1, ptr @.d50 }, ptr %l234, !tbaa !27
  br label %bb145
bb145:
  %t427 = load ptr, ptr %l232, !tbaa !29
  %t428 = load { i64, ptr }, ptr %l234, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s20, ptr %t427, { i64, ptr } %t428)
  br label %bb146
bb146:
  %t429 = load ptr, ptr %l0, !tbaa !29
  store ptr %t429, ptr %l235, !tbaa !29
  %t430 = load ptr, ptr %l1, !tbaa !29
  store ptr %t430, ptr %l236, !tbaa !29
  %t431 = load i32, ptr %l14, !tbaa !23
  store i32 %t431, ptr %l237, !tbaa !23
  %t432 = load ptr, ptr %l235, !tbaa !29
  %t433 = load ptr, ptr %l236, !tbaa !29
  %t434 = load i32, ptr %l237, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t432, ptr %t433, i32 %t434)
  br label %bb147
bb147:
  %t435 = load i1, ptr %l15, !tbaa !21
  store i1 %t435, ptr %l238, !tbaa !21
  %t436 = load i1, ptr %l238, !tbaa !21
  br i1 %t436, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s21
  %t437 = load ptr, ptr %l1, !tbaa !29
  store ptr %t437, ptr %l239, !tbaa !29
  %t438 = load ptr, ptr %l239, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t438, i8 41)
  br label %bb150
bb149:
  br label %bb151
bb150:
  call void @__olang_scope_close(ptr %s21)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s20)
  br label %bb152
bb152:
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l240, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l241, !tbaa !29
  %t441 = load i32, ptr %l2, !tbaa !23
  store i32 %t441, ptr %l242, !tbaa !23
  %t442 = load ptr, ptr %l241, !tbaa !29
  %t443 = load i32, ptr %l242, !tbaa !23
  %t444 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t442, i32 %t443)
  store i32 %t444, ptr %l243
  br label %bb153
bb153:
  %t445 = load ptr, ptr %l240, !tbaa !29
  %t446 = load i32, ptr %l243, !tbaa !23
  %t447 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t445, i32 %t446)
  store { i64, ptr } %t447, ptr %l244
  br label %bb154
bb154:
  %t448 = load { i64, ptr }, ptr %l244, !tbaa !27
  store { i64, ptr } %t448, ptr %l16, !tbaa !27
  %t449 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t449, ptr %l245, !tbaa !27
  %t450 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 0
  store i64 %t451, ptr %l246, !tbaa !24
  %t452 = load i64, ptr %l246, !tbaa !24
  %t453 = icmp sgt i64 %t452, 0
  store i1 %t453, ptr %l247, !tbaa !21
  %t454 = load i1, ptr %l247, !tbaa !21
  br i1 %t454, label %bb155, label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s22
  %t455 = load ptr, ptr %l1, !tbaa !29
  store ptr %t455, ptr %l248, !tbaa !29
  %t456 = load ptr, ptr %l248, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s22, ptr %t456, { i64, ptr } { i64 2, ptr @.d51 })
  br label %bb157
bb156:
  br label %bb181
bb157:
  %t457 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t457, ptr %l249, !tbaa !27
  %t458 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 0
  store i64 %t459, ptr %l250, !tbaa !24
  %t460 = load i64, ptr %l250, !tbaa !24
  %t461 = icmp eq i64 %t460, 1
  store i1 %t461, ptr %l251, !tbaa !21
  %t462 = load i1, ptr %l251, !tbaa !21
  br i1 %t462, label %bb158, label %bb159
bb158:
  %t463 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t463, ptr %l253, !tbaa !27
  %t464 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !27
  %t466 = getelementptr i32, ptr %t465, i64 0
  %t467 = load i32, ptr %t466, !tbaa !33
  store i32 %t467, ptr %l254, !tbaa !23
  %t468 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  store i32 %t468, ptr %l255, !tbaa !23
  %t469 = load i32, ptr %l254, !tbaa !23
  %t470 = load i32, ptr %l255, !tbaa !23
  %t471 = icmp eq i32 %t469, %t470
  store i1 %t471, ptr %l256, !tbaa !21
  %t472 = load i1, ptr %l256, !tbaa !21
  store i1 %t472, ptr %l252, !tbaa !21
  br label %bb160
bb159:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb160
bb160:
  %t473 = load i1, ptr %l252, !tbaa !21
  %t474 = xor i1 %t473, true
  store i1 %t474, ptr %l257, !tbaa !21
  %t475 = load i1, ptr %l257, !tbaa !21
  br i1 %t475, label %bb161, label %bb162
bb161:
  store %olang.scope zeroinitializer, ptr %s23
  store %olang.scope zeroinitializer, ptr %s24
  store i64 0, ptr %l17, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t476, ptr %l258, !tbaa !27
  %t477 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t477, 0
  store i64 %t478, ptr %l259, !tbaa !24
  %t479 = load i64, ptr %l259, !tbaa !24
  store i64 %t479, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t480 = load i64, ptr %l18, !tbaa !24
  store i64 %t480, ptr %l260, !tbaa !24
  %t481 = load i64, ptr %l17, !tbaa !24
  store i64 %t481, ptr %l261, !tbaa !24
  %t482 = load i64, ptr %l260, !tbaa !24
  %t483 = load i64, ptr %l261, !tbaa !24
  %t484 = icmp sgt i64 %t482, %t483
  store i1 %t484, ptr %l262, !tbaa !21
  %t485 = load i1, ptr %l262, !tbaa !21
  br i1 %t485, label %bb163, label %bb164
bb162:
  br label %bb180
bb163:
  %t486 = load i64, ptr %l19, !tbaa !24
  store i64 %t486, ptr %l264, !tbaa !24
  %t487 = load i64, ptr %l264, !tbaa !24
  %t488 = icmp sgt i64 %t487, 0
  store i1 %t488, ptr %l265, !tbaa !21
  %t489 = load i1, ptr %l265, !tbaa !21
  br i1 %t489, label %bb165, label %bb166
bb164:
  store i64 0, ptr %l263, !tbaa !24
  br label %bb168
bb165:
  %t490 = load i64, ptr %l18, !tbaa !24
  store i64 %t490, ptr %l267, !tbaa !24
  %t491 = load i64, ptr %l17, !tbaa !24
  store i64 %t491, ptr %l268, !tbaa !24
  %t492 = load i64, ptr %l267, !tbaa !24
  %t493 = load i64, ptr %l268, !tbaa !24
  %t494 = sub i64 %t492, %t493
  store i64 %t494, ptr %l269, !tbaa !24
  %t495 = load i64, ptr %l19, !tbaa !24
  store i64 %t495, ptr %l270, !tbaa !24
  %t496 = load i64, ptr %l269, !tbaa !24
  %t497 = load i64, ptr %l270, !tbaa !24
  %t498 = add i64 %t496, %t497
  store i64 %t498, ptr %l271, !tbaa !24
  %t499 = load i64, ptr %l271, !tbaa !24
  %t500 = sub i64 %t499, 1
  store i64 %t500, ptr %l272, !tbaa !24
  %t501 = load i64, ptr %l19, !tbaa !24
  store i64 %t501, ptr %l273, !tbaa !24
  %t502 = load i64, ptr %l272, !tbaa !24
  %t503 = load i64, ptr %l273, !tbaa !24
  %t504 = sdiv i64 %t502, %t503
  store i64 %t504, ptr %l274, !tbaa !24
  %t505 = load i64, ptr %l274, !tbaa !24
  store i64 %t505, ptr %l266, !tbaa !24
  br label %bb167
bb166:
  store i64 0, ptr %l266, !tbaa !24
  br label %bb167
bb167:
  %t506 = load i64, ptr %l266, !tbaa !24
  store i64 %t506, ptr %l263, !tbaa !24
  br label %bb168
bb168:
  %t507 = load i64, ptr %l263, !tbaa !24
  store i64 %t507, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb169
bb169:
  store %olang.scope zeroinitializer, ptr %s25
  %t508 = load i64, ptr %l21, !tbaa !24
  store i64 %t508, ptr %l275, !tbaa !24
  %t509 = load i64, ptr %l20, !tbaa !24
  store i64 %t509, ptr %l276, !tbaa !24
  %t510 = load i64, ptr %l275, !tbaa !24
  %t511 = load i64, ptr %l276, !tbaa !24
  %t512 = icmp slt i64 %t510, %t511
  store i1 %t512, ptr %l277, !tbaa !21
  %t513 = load i1, ptr %l277, !tbaa !21
  %t514 = xor i1 %t513, true
  store i1 %t514, ptr %l278, !tbaa !21
  %t515 = load i1, ptr %l278, !tbaa !21
  br i1 %t515, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s25)
  br label %bb179
bb171:
  br label %bb172
bb172:
  %t516 = load i64, ptr %l17, !tbaa !24
  store i64 %t516, ptr %l279, !tbaa !24
  %t517 = load i64, ptr %l21, !tbaa !24
  store i64 %t517, ptr %l280, !tbaa !24
  %t518 = load i64, ptr %l19, !tbaa !24
  store i64 %t518, ptr %l281, !tbaa !24
  %t519 = load i64, ptr %l280, !tbaa !24
  %t520 = load i64, ptr %l281, !tbaa !24
  %t521 = mul i64 %t519, %t520
  store i64 %t521, ptr %l282, !tbaa !24
  %t522 = load i64, ptr %l279, !tbaa !24
  %t523 = load i64, ptr %l282, !tbaa !24
  %t524 = add i64 %t522, %t523
  store i64 %t524, ptr %l283, !tbaa !24
  %t525 = load i64, ptr %l283, !tbaa !24
  store i64 %t525, ptr %l22, !tbaa !24
  %t526 = load ptr, ptr %l1, !tbaa !29
  store ptr %t526, ptr %l284, !tbaa !29
  %t527 = load i64, ptr %l22, !tbaa !24
  store i64 %t527, ptr %l285, !tbaa !24
  %t528 = load i64, ptr %l285, !tbaa !24
  %t529 = icmp sgt i64 %t528, 0
  store i1 %t529, ptr %l286, !tbaa !21
  %t530 = load i1, ptr %l286, !tbaa !21
  br i1 %t530, label %bb173, label %bb174
bb173:
  store { i64, ptr } { i64 3, ptr @.d52 }, ptr %l287, !tbaa !27
  br label %bb175
bb174:
  store { i64, ptr } { i64 1, ptr @.d53 }, ptr %l287, !tbaa !27
  br label %bb175
bb175:
  %t531 = load ptr, ptr %l284, !tbaa !29
  %t532 = load { i64, ptr }, ptr %l287, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s25, ptr %t531, { i64, ptr } %t532)
  br label %bb176
bb176:
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l288, !tbaa !29
  %t534 = load ptr, ptr %l1, !tbaa !29
  store ptr %t534, ptr %l289, !tbaa !29
  %t535 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t535, ptr %l290, !tbaa !27
  %t536 = load i64, ptr %l22, !tbaa !24
  store i64 %t536, ptr %l291, !tbaa !24
  %t537 = load i64, ptr %l291, !tbaa !24
  %t538 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t539 = load ptr, ptr %t538, !tbaa !27
  %t540 = getelementptr i32, ptr %t539, i64 %t537
  %t541 = load i32, ptr %t540, !tbaa !33
  store i32 %t541, ptr %l292, !tbaa !23
  %t542 = load ptr, ptr %l288, !tbaa !29
  %t543 = load ptr, ptr %l289, !tbaa !29
  %t544 = load i32, ptr %l292, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t542, ptr %t543, i32 %t544)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s25)
  br label %bb178
bb178:
  store %olang.scope zeroinitializer, ptr %s26
  %t545 = load i64, ptr %l21, !tbaa !24
  store i64 %t545, ptr %l293, !tbaa !24
  %t546 = load i64, ptr %l293, !tbaa !24
  %t547 = add i64 %t546, 1
  store i64 %t547, ptr %l294, !tbaa !24
  %t548 = load i64, ptr %l294, !tbaa !24
  store i64 %t548, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb169
bb179:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s22)
  br label %bb181
bb181:
  %t549 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t550 = load i64, ptr %t549, !tbaa !24
  store i64 %t550, ptr %l295, !tbaa !24
  %t551 = load i64, ptr %l295, !tbaa !24
  %t552 = icmp ne i64 %t551, 0
  store i1 %t552, ptr %l296, !tbaa !21
  %t553 = load i1, ptr %l296, !tbaa !21
  br i1 %t553, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s27
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l297, !tbaa !29
  %t555 = load ptr, ptr %l297, !tbaa !29
  %t556 = getelementptr %"compiler/types:Table", ptr %t555, i32 0, i32 24
  store ptr %t556, ptr %l298, !tbaa !29
  %t557 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t558 = load i64, ptr %t557, !tbaa !24
  store i64 %t558, ptr %l299, !tbaa !24
  %t559 = load ptr, ptr %l298, !tbaa !29
  %t560 = load i64, ptr %l299, !tbaa !24
  %t561 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t559, i64 %t560)
  store { i64, ptr } %t561, ptr %l300
  br label %bb184
bb183:
  br label %bb204
bb184:
  %t562 = load { i64, ptr }, ptr %l300, !tbaa !27
  store { i64, ptr } %t562, ptr %l23, !tbaa !27
  %t563 = load ptr, ptr %l1, !tbaa !29
  store ptr %t563, ptr %l301, !tbaa !29
  %t564 = load ptr, ptr %l301, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s27, ptr %t564, { i64, ptr } { i64 3, ptr @.d54 })
  br label %bb185
bb185:
  store %olang.scope zeroinitializer, ptr %s28
  store i64 0, ptr %l24, !tbaa !24
  %t565 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t565, ptr %l302, !tbaa !27
  %t566 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t566, 0
  store i64 %t567, ptr %l303, !tbaa !24
  %t568 = load i64, ptr %l303, !tbaa !24
  store i64 %t568, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t569 = load i64, ptr %l25, !tbaa !24
  store i64 %t569, ptr %l304, !tbaa !24
  %t570 = load i64, ptr %l24, !tbaa !24
  store i64 %t570, ptr %l305, !tbaa !24
  %t571 = load i64, ptr %l304, !tbaa !24
  %t572 = load i64, ptr %l305, !tbaa !24
  %t573 = icmp sgt i64 %t571, %t572
  store i1 %t573, ptr %l306, !tbaa !21
  %t574 = load i1, ptr %l306, !tbaa !21
  br i1 %t574, label %bb186, label %bb187
bb186:
  %t575 = load i64, ptr %l26, !tbaa !24
  store i64 %t575, ptr %l308, !tbaa !24
  %t576 = load i64, ptr %l308, !tbaa !24
  %t577 = icmp sgt i64 %t576, 0
  store i1 %t577, ptr %l309, !tbaa !21
  %t578 = load i1, ptr %l309, !tbaa !21
  br i1 %t578, label %bb188, label %bb189
bb187:
  store i64 0, ptr %l307, !tbaa !24
  br label %bb191
bb188:
  %t579 = load i64, ptr %l25, !tbaa !24
  store i64 %t579, ptr %l311, !tbaa !24
  %t580 = load i64, ptr %l24, !tbaa !24
  store i64 %t580, ptr %l312, !tbaa !24
  %t581 = load i64, ptr %l311, !tbaa !24
  %t582 = load i64, ptr %l312, !tbaa !24
  %t583 = sub i64 %t581, %t582
  store i64 %t583, ptr %l313, !tbaa !24
  %t584 = load i64, ptr %l26, !tbaa !24
  store i64 %t584, ptr %l314, !tbaa !24
  %t585 = load i64, ptr %l313, !tbaa !24
  %t586 = load i64, ptr %l314, !tbaa !24
  %t587 = add i64 %t585, %t586
  store i64 %t587, ptr %l315, !tbaa !24
  %t588 = load i64, ptr %l315, !tbaa !24
  %t589 = sub i64 %t588, 1
  store i64 %t589, ptr %l316, !tbaa !24
  %t590 = load i64, ptr %l26, !tbaa !24
  store i64 %t590, ptr %l317, !tbaa !24
  %t591 = load i64, ptr %l316, !tbaa !24
  %t592 = load i64, ptr %l317, !tbaa !24
  %t593 = sdiv i64 %t591, %t592
  store i64 %t593, ptr %l318, !tbaa !24
  %t594 = load i64, ptr %l318, !tbaa !24
  store i64 %t594, ptr %l310, !tbaa !24
  br label %bb190
bb189:
  store i64 0, ptr %l310, !tbaa !24
  br label %bb190
bb190:
  %t595 = load i64, ptr %l310, !tbaa !24
  store i64 %t595, ptr %l307, !tbaa !24
  br label %bb191
bb191:
  %t596 = load i64, ptr %l307, !tbaa !24
  store i64 %t596, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s29
  %t597 = load i64, ptr %l28, !tbaa !24
  store i64 %t597, ptr %l319, !tbaa !24
  %t598 = load i64, ptr %l27, !tbaa !24
  store i64 %t598, ptr %l320, !tbaa !24
  %t599 = load i64, ptr %l319, !tbaa !24
  %t600 = load i64, ptr %l320, !tbaa !24
  %t601 = icmp slt i64 %t599, %t600
  store i1 %t601, ptr %l321, !tbaa !21
  %t602 = load i1, ptr %l321, !tbaa !21
  %t603 = xor i1 %t602, true
  store i1 %t603, ptr %l322, !tbaa !21
  %t604 = load i1, ptr %l322, !tbaa !21
  br i1 %t604, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s29)
  br label %bb202
bb194:
  br label %bb195
bb195:
  %t605 = load i64, ptr %l24, !tbaa !24
  store i64 %t605, ptr %l323, !tbaa !24
  %t606 = load i64, ptr %l28, !tbaa !24
  store i64 %t606, ptr %l324, !tbaa !24
  %t607 = load i64, ptr %l26, !tbaa !24
  store i64 %t607, ptr %l325, !tbaa !24
  %t608 = load i64, ptr %l324, !tbaa !24
  %t609 = load i64, ptr %l325, !tbaa !24
  %t610 = mul i64 %t608, %t609
  store i64 %t610, ptr %l326, !tbaa !24
  %t611 = load i64, ptr %l323, !tbaa !24
  %t612 = load i64, ptr %l326, !tbaa !24
  %t613 = add i64 %t611, %t612
  store i64 %t613, ptr %l327, !tbaa !24
  %t614 = load i64, ptr %l327, !tbaa !24
  store i64 %t614, ptr %l29, !tbaa !24
  %t615 = load i64, ptr %l29, !tbaa !24
  store i64 %t615, ptr %l328, !tbaa !24
  %t616 = load i64, ptr %l328, !tbaa !24
  %t617 = icmp sgt i64 %t616, 0
  store i1 %t617, ptr %l329, !tbaa !21
  %t618 = load i1, ptr %l329, !tbaa !21
  br i1 %t618, label %bb196, label %bb197
bb196:
  store %olang.scope zeroinitializer, ptr %s30
  %t619 = load ptr, ptr %l1, !tbaa !29
  store ptr %t619, ptr %l330, !tbaa !29
  %t620 = load ptr, ptr %l330, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t620, i8 44)
  br label %bb198
bb197:
  br label %bb199
bb198:
  call void @__olang_scope_close(ptr %s30)
  br label %bb199
bb199:
  %t621 = load ptr, ptr %l1, !tbaa !29
  store ptr %t621, ptr %l331, !tbaa !29
  %t622 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t622, ptr %l332, !tbaa !27
  %t623 = load i64, ptr %l29, !tbaa !24
  store i64 %t623, ptr %l333, !tbaa !24
  %t624 = load i64, ptr %l333, !tbaa !24
  %t625 = getelementptr { i64, ptr }, ptr %l332, i32 0, i32 1
  %t626 = load ptr, ptr %t625, !tbaa !27
  %t627 = getelementptr i64, ptr %t626, i64 %t624
  %t628 = load i64, ptr %t627, !tbaa !34
  store i64 %t628, ptr %l334, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s31
  store ptr %s31room, ptr %s31
  %t629 = load i64, ptr %l334, !tbaa !24
  %t630 = call ptr @__olang_sb_room(ptr %s31, i64 24)
  %t631 = call i64 @__olang_fmt_i64(ptr %t630, i64 %t629)
  call void @__olang_sb_add(ptr %s31, i64 %t631)
  %t632 = load ptr, ptr %s31
  %t633 = getelementptr %olang.builder, ptr %s31, i32 0, i32 1
  %t634 = load i64, ptr %t633
  %t635 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t634)
  call void @llvm.memcpy.p0.p0.i64(ptr %t635, ptr %t632, i64 %t634, i1 false)
  %t636 = insertvalue { i64, ptr } undef, i64 %t634, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t635, 1
  store { i64, ptr } %t637, ptr %l335, !tbaa !27
  call void @__olang_sb_done(ptr %s31)
  %t638 = load { i64, ptr }, ptr %l335, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t638, 0
  %t640 = extractvalue { i64, ptr } %t638, 1
  %t641 = mul i64 %t639, 1
  %t642 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t641)
  call void @llvm.memcpy.p0.p0.i64(ptr %t642, ptr %t640, i64 %t641, i1 false)
  %t643 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t644 = insertvalue { i64, ptr } %t643, ptr %t642, 1
  store { i64, ptr } %t644, ptr %l336, !tbaa !27
  %t645 = load ptr, ptr %l331, !tbaa !29
  %t646 = load { i64, ptr }, ptr %l336, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s29, ptr %t645, { i64, ptr } %t646)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s29)
  br label %bb201
bb201:
  store %olang.scope zeroinitializer, ptr %s32
  %t647 = load i64, ptr %l28, !tbaa !24
  store i64 %t647, ptr %l337, !tbaa !24
  %t648 = load i64, ptr %l337, !tbaa !24
  %t649 = add i64 %t648, 1
  store i64 %t649, ptr %l338, !tbaa !24
  %t650 = load i64, ptr %l338, !tbaa !24
  store i64 %t650, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s32)
  br label %bb192
bb202:
  call void @__olang_scope_close(ptr %s28)
  %t651 = load ptr, ptr %l1, !tbaa !29
  store ptr %t651, ptr %l339, !tbaa !29
  %t652 = load ptr, ptr %l339, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t652, i8 93)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s27)
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s19)
  br label %bb289
bb205:
  %t653 = load i32, ptr %l4
  store i32 %t653, ptr %l340
  %t654 = load i32, ptr %l340
  %t655 = trunc i64 22 to i32
  %t656 = icmp eq i32 %t654, %t655
  store i1 %t656, ptr %l341, !tbaa !21
  %t657 = load i1, ptr %l341, !tbaa !21
  br i1 %t657, label %bb206, label %bb207
bb206:
  br label %bb208
bb207:
  br label %bb213
bb208:
  store %olang.scope zeroinitializer, ptr %s33
  %t658 = load ptr, ptr %l1, !tbaa !29
  store ptr %t658, ptr %l342, !tbaa !29
  %t659 = load ptr, ptr %l342, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t659, i8 40)
  br label %bb209
bb209:
  %t660 = load ptr, ptr %l0, !tbaa !29
  store ptr %t660, ptr %l343, !tbaa !29
  %t661 = load ptr, ptr %l1, !tbaa !29
  store ptr %t661, ptr %l344, !tbaa !29
  %t662 = load ptr, ptr %l0, !tbaa !29
  store ptr %t662, ptr %l345, !tbaa !29
  %t663 = load i32, ptr %l2, !tbaa !23
  store i32 %t663, ptr %l346, !tbaa !23
  %t664 = load ptr, ptr %l345, !tbaa !29
  %t665 = load i32, ptr %l346, !tbaa !23
  %t666 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t664, i32 %t665)
  store i32 %t666, ptr %l347
  br label %bb210
bb210:
  %t667 = load ptr, ptr %l343, !tbaa !29
  %t668 = load ptr, ptr %l344, !tbaa !29
  %t669 = load i32, ptr %l347, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t667, ptr %t668, i32 %t669)
  br label %bb211
bb211:
  %t670 = load ptr, ptr %l1, !tbaa !29
  store ptr %t670, ptr %l348, !tbaa !29
  %t671 = load ptr, ptr %l348, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t671, i8 41)
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s33)
  br label %bb289
bb213:
  %t672 = load i32, ptr %l4
  store i32 %t672, ptr %l349
  %t673 = load i32, ptr %l349
  %t674 = trunc i64 23 to i32
  %t675 = icmp eq i32 %t673, %t674
  store i1 %t675, ptr %l350, !tbaa !21
  %t676 = load i1, ptr %l350, !tbaa !21
  br i1 %t676, label %bb214, label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb221
bb216:
  store %olang.scope zeroinitializer, ptr %s34
  %t677 = load ptr, ptr %l1, !tbaa !29
  store ptr %t677, ptr %l351, !tbaa !29
  %t678 = load ptr, ptr %l351, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s34, ptr %t678, { i64, ptr } { i64 7, ptr @.d55 })
  br label %bb217
bb217:
  %t679 = load ptr, ptr %l0, !tbaa !29
  store ptr %t679, ptr %l352, !tbaa !29
  %t680 = load ptr, ptr %l1, !tbaa !29
  store ptr %t680, ptr %l353, !tbaa !29
  %t681 = load ptr, ptr %l0, !tbaa !29
  store ptr %t681, ptr %l354, !tbaa !29
  %t682 = load i32, ptr %l2, !tbaa !23
  store i32 %t682, ptr %l355, !tbaa !23
  %t683 = load ptr, ptr %l354, !tbaa !29
  %t684 = load i32, ptr %l355, !tbaa !23
  %t685 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t683, i32 %t684)
  store i32 %t685, ptr %l356
  br label %bb218
bb218:
  %t686 = load ptr, ptr %l352, !tbaa !29
  %t687 = load ptr, ptr %l353, !tbaa !29
  %t688 = load i32, ptr %l356, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t686, ptr %t687, i32 %t688)
  br label %bb219
bb219:
  %t689 = load ptr, ptr %l1, !tbaa !29
  store ptr %t689, ptr %l357, !tbaa !29
  %t690 = load ptr, ptr %l357, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t690, i8 41)
  br label %bb220
bb220:
  call void @__olang_scope_close(ptr %s34)
  br label %bb289
bb221:
  %t691 = load i32, ptr %l4
  store i32 %t691, ptr %l358
  %t692 = load i32, ptr %l358
  %t693 = trunc i64 24 to i32
  %t694 = icmp eq i32 %t692, %t693
  store i1 %t694, ptr %l359, !tbaa !21
  %t695 = load i1, ptr %l359, !tbaa !21
  br i1 %t695, label %bb222, label %bb223
bb222:
  br label %bb224
bb223:
  br label %bb255
bb224:
  store %olang.scope zeroinitializer, ptr %s35
  %t696 = load ptr, ptr %l1, !tbaa !29
  store ptr %t696, ptr %l360, !tbaa !29
  %t697 = load ptr, ptr %l360, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s35, ptr %t697, { i64, ptr } { i64 5, ptr @.d56 })
  br label %bb225
bb225:
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l361, !tbaa !29
  %t699 = load i32, ptr %l2, !tbaa !23
  store i32 %t699, ptr %l362, !tbaa !23
  %t700 = load ptr, ptr %l361, !tbaa !29
  %t701 = load i32, ptr %l362, !tbaa !23
  %t702 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %t700, i32 %t701)
  store { i64, ptr } %t702, ptr %l363
  br label %bb226
bb226:
  %t703 = load { i64, ptr }, ptr %l363, !tbaa !27
  store { i64, ptr } %t703, ptr %l30, !tbaa !27
  %t704 = load ptr, ptr %l0, !tbaa !29
  store ptr %t704, ptr %l364, !tbaa !29
  %t705 = load ptr, ptr %l0, !tbaa !29
  store ptr %t705, ptr %l365, !tbaa !29
  %t706 = load i32, ptr %l2, !tbaa !23
  store i32 %t706, ptr %l366, !tbaa !23
  %t707 = load ptr, ptr %l365, !tbaa !29
  %t708 = load i32, ptr %l366, !tbaa !23
  %t709 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t707, i32 %t708)
  store i32 %t709, ptr %l367
  br label %bb227
bb227:
  %t710 = load ptr, ptr %l364, !tbaa !29
  %t711 = load i32, ptr %l367, !tbaa !23
  %t712 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t710, i32 %t711)
  store { i64, ptr } %t712, ptr %l368
  br label %bb228
bb228:
  %t713 = load { i64, ptr }, ptr %l368, !tbaa !27
  store { i64, ptr } %t713, ptr %l31, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s36
  store i64 0, ptr %l32, !tbaa !24
  %t714 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t714, ptr %l369, !tbaa !27
  %t715 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t716 = extractvalue { i64, ptr } %t715, 0
  store i64 %t716, ptr %l370, !tbaa !24
  %t717 = load i64, ptr %l370, !tbaa !24
  store i64 %t717, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t718 = load i64, ptr %l33, !tbaa !24
  store i64 %t718, ptr %l371, !tbaa !24
  %t719 = load i64, ptr %l32, !tbaa !24
  store i64 %t719, ptr %l372, !tbaa !24
  %t720 = load i64, ptr %l371, !tbaa !24
  %t721 = load i64, ptr %l372, !tbaa !24
  %t722 = icmp sgt i64 %t720, %t721
  store i1 %t722, ptr %l373, !tbaa !21
  %t723 = load i1, ptr %l373, !tbaa !21
  br i1 %t723, label %bb229, label %bb230
bb229:
  %t724 = load i64, ptr %l34, !tbaa !24
  store i64 %t724, ptr %l375, !tbaa !24
  %t725 = load i64, ptr %l375, !tbaa !24
  %t726 = icmp sgt i64 %t725, 0
  store i1 %t726, ptr %l376, !tbaa !21
  %t727 = load i1, ptr %l376, !tbaa !21
  br i1 %t727, label %bb231, label %bb232
bb230:
  store i64 0, ptr %l374, !tbaa !24
  br label %bb234
bb231:
  %t728 = load i64, ptr %l33, !tbaa !24
  store i64 %t728, ptr %l378, !tbaa !24
  %t729 = load i64, ptr %l32, !tbaa !24
  store i64 %t729, ptr %l379, !tbaa !24
  %t730 = load i64, ptr %l378, !tbaa !24
  %t731 = load i64, ptr %l379, !tbaa !24
  %t732 = sub i64 %t730, %t731
  store i64 %t732, ptr %l380, !tbaa !24
  %t733 = load i64, ptr %l34, !tbaa !24
  store i64 %t733, ptr %l381, !tbaa !24
  %t734 = load i64, ptr %l380, !tbaa !24
  %t735 = load i64, ptr %l381, !tbaa !24
  %t736 = add i64 %t734, %t735
  store i64 %t736, ptr %l382, !tbaa !24
  %t737 = load i64, ptr %l382, !tbaa !24
  %t738 = sub i64 %t737, 1
  store i64 %t738, ptr %l383, !tbaa !24
  %t739 = load i64, ptr %l34, !tbaa !24
  store i64 %t739, ptr %l384, !tbaa !24
  %t740 = load i64, ptr %l383, !tbaa !24
  %t741 = load i64, ptr %l384, !tbaa !24
  %t742 = sdiv i64 %t740, %t741
  store i64 %t742, ptr %l385, !tbaa !24
  %t743 = load i64, ptr %l385, !tbaa !24
  store i64 %t743, ptr %l377, !tbaa !24
  br label %bb233
bb232:
  store i64 0, ptr %l377, !tbaa !24
  br label %bb233
bb233:
  %t744 = load i64, ptr %l377, !tbaa !24
  store i64 %t744, ptr %l374, !tbaa !24
  br label %bb234
bb234:
  %t745 = load i64, ptr %l374, !tbaa !24
  store i64 %t745, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb235
bb235:
  store %olang.scope zeroinitializer, ptr %s37
  %t746 = load i64, ptr %l36, !tbaa !24
  store i64 %t746, ptr %l386, !tbaa !24
  %t747 = load i64, ptr %l35, !tbaa !24
  store i64 %t747, ptr %l387, !tbaa !24
  %t748 = load i64, ptr %l386, !tbaa !24
  %t749 = load i64, ptr %l387, !tbaa !24
  %t750 = icmp slt i64 %t748, %t749
  store i1 %t750, ptr %l388, !tbaa !21
  %t751 = load i1, ptr %l388, !tbaa !21
  %t752 = xor i1 %t751, true
  store i1 %t752, ptr %l389, !tbaa !21
  %t753 = load i1, ptr %l389, !tbaa !21
  br i1 %t753, label %bb236, label %bb237
bb236:
  call void @__olang_scope_close(ptr %s37)
  br label %bb253
bb237:
  br label %bb238
bb238:
  %t754 = load i64, ptr %l32, !tbaa !24
  store i64 %t754, ptr %l390, !tbaa !24
  %t755 = load i64, ptr %l36, !tbaa !24
  store i64 %t755, ptr %l391, !tbaa !24
  %t756 = load i64, ptr %l34, !tbaa !24
  store i64 %t756, ptr %l392, !tbaa !24
  %t757 = load i64, ptr %l391, !tbaa !24
  %t758 = load i64, ptr %l392, !tbaa !24
  %t759 = mul i64 %t757, %t758
  store i64 %t759, ptr %l393, !tbaa !24
  %t760 = load i64, ptr %l390, !tbaa !24
  %t761 = load i64, ptr %l393, !tbaa !24
  %t762 = add i64 %t760, %t761
  store i64 %t762, ptr %l394, !tbaa !24
  %t763 = load i64, ptr %l394, !tbaa !24
  store i64 %t763, ptr %l37, !tbaa !24
  %t764 = load i64, ptr %l37, !tbaa !24
  store i64 %t764, ptr %l395, !tbaa !24
  %t765 = load i64, ptr %l395, !tbaa !24
  %t766 = icmp sgt i64 %t765, 0
  store i1 %t766, ptr %l396, !tbaa !21
  %t767 = load i1, ptr %l396, !tbaa !21
  br i1 %t767, label %bb239, label %bb240
bb239:
  store %olang.scope zeroinitializer, ptr %s38
  %t768 = load ptr, ptr %l1, !tbaa !29
  store ptr %t768, ptr %l397, !tbaa !29
  %t769 = load ptr, ptr %l397, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t769, i8 32)
  br label %bb241
bb240:
  br label %bb242
bb241:
  call void @__olang_scope_close(ptr %s38)
  br label %bb242
bb242:
  %t770 = load ptr, ptr %l1, !tbaa !29
  store ptr %t770, ptr %l398, !tbaa !29
  %t771 = load ptr, ptr %l0, !tbaa !29
  store ptr %t771, ptr %l399, !tbaa !29
  %t772 = load ptr, ptr %l399, !tbaa !29
  %t773 = getelementptr %"compiler/types:Table", ptr %t772, i32 0, i32 0
  %t774 = load ptr, ptr %t773, !tbaa !29
  store ptr %t774, ptr %l400, !tbaa !29
  %t775 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t775, ptr %l401, !tbaa !27
  %t776 = load i64, ptr %l37, !tbaa !24
  store i64 %t776, ptr %l402, !tbaa !24
  %t777 = load i64, ptr %l402, !tbaa !24
  %t778 = getelementptr { i64, ptr }, ptr %l401, i32 0, i32 1
  %t779 = load ptr, ptr %t778, !tbaa !27
  %t780 = getelementptr i32, ptr %t779, i64 %t777
  %t781 = load i32, ptr %t780, !tbaa !33
  store i32 %t781, ptr %l403, !tbaa !23
  %t782 = load ptr, ptr %l400, !tbaa !29
  %t783 = load i32, ptr %l403, !tbaa !23
  %t784 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t782, i32 %t783)
  store { i64, ptr } %t784, ptr %l404
  br label %bb243
bb243:
  %t785 = load ptr, ptr %l398, !tbaa !29
  %t786 = load { i64, ptr }, ptr %l404, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t785, { i64, ptr } %t786)
  br label %bb244
bb244:
  %t787 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t787, ptr %l405, !tbaa !27
  %t788 = load i64, ptr %l37, !tbaa !24
  store i64 %t788, ptr %l406, !tbaa !24
  %t789 = load i64, ptr %l406, !tbaa !24
  %t790 = getelementptr { i64, ptr }, ptr %l405, i32 0, i32 1
  %t791 = load ptr, ptr %t790, !tbaa !27
  %t792 = getelementptr i32, ptr %t791, i64 %t789
  %t793 = load i32, ptr %t792, !tbaa !33
  store i32 %t793, ptr %l407, !tbaa !23
  %t794 = load i32, ptr %l407, !tbaa !23
  %t795 = icmp ne i32 %t794, 0
  store i1 %t795, ptr %l408, !tbaa !21
  %t796 = load i1, ptr %l408, !tbaa !21
  br i1 %t796, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s39
  %t797 = load ptr, ptr %l1, !tbaa !29
  store ptr %t797, ptr %l409, !tbaa !29
  %t798 = load ptr, ptr %l409, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t798, i8 40)
  br label %bb247
bb246:
  br label %bb251
bb247:
  %t799 = load ptr, ptr %l0, !tbaa !29
  store ptr %t799, ptr %l410, !tbaa !29
  %t800 = load ptr, ptr %l1, !tbaa !29
  store ptr %t800, ptr %l411, !tbaa !29
  %t801 = load ptr, ptr %l0, !tbaa !29
  store ptr %t801, ptr %l412, !tbaa !29
  %t802 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t802, ptr %l413, !tbaa !27
  %t803 = load i64, ptr %l37, !tbaa !24
  store i64 %t803, ptr %l414, !tbaa !24
  %t804 = load i64, ptr %l414, !tbaa !24
  %t805 = getelementptr { i64, ptr }, ptr %l413, i32 0, i32 1
  %t806 = load ptr, ptr %t805, !tbaa !27
  %t807 = getelementptr i32, ptr %t806, i64 %t804
  %t808 = load i32, ptr %t807, !tbaa !33
  store i32 %t808, ptr %l415, !tbaa !23
  %t809 = load ptr, ptr %l412, !tbaa !29
  %t810 = load i32, ptr %l415, !tbaa !23
  %t811 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t809, i32 %t810)
  store i32 %t811, ptr %l416
  br label %bb248
bb248:
  %t812 = load ptr, ptr %l410, !tbaa !29
  %t813 = load ptr, ptr %l411, !tbaa !29
  %t814 = load i32, ptr %l416, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t812, ptr %t813, i32 %t814)
  br label %bb249
bb249:
  %t815 = load ptr, ptr %l1, !tbaa !29
  store ptr %t815, ptr %l417, !tbaa !29
  %t816 = load ptr, ptr %l417, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t816, i8 41)
  br label %bb250
bb250:
  call void @__olang_scope_close(ptr %s39)
  br label %bb251
bb251:
  call void @__olang_scope_close(ptr %s37)
  br label %bb252
bb252:
  store %olang.scope zeroinitializer, ptr %s40
  %t817 = load i64, ptr %l36, !tbaa !24
  store i64 %t817, ptr %l418, !tbaa !24
  %t818 = load i64, ptr %l418, !tbaa !24
  %t819 = add i64 %t818, 1
  store i64 %t819, ptr %l419, !tbaa !24
  %t820 = load i64, ptr %l419, !tbaa !24
  store i64 %t820, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s40)
  br label %bb235
bb253:
  call void @__olang_scope_close(ptr %s36)
  %t821 = load ptr, ptr %l1, !tbaa !29
  store ptr %t821, ptr %l420, !tbaa !29
  %t822 = load ptr, ptr %l420, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t822, i8 125)
  br label %bb254
bb254:
  call void @__olang_scope_close(ptr %s35)
  br label %bb289
bb255:
  %t823 = load i32, ptr %l4
  store i32 %t823, ptr %l421
  %t824 = load i32, ptr %l421
  %t825 = trunc i64 25 to i32
  %t826 = icmp eq i32 %t824, %t825
  store i1 %t826, ptr %l422, !tbaa !21
  %t827 = load i1, ptr %l422, !tbaa !21
  br i1 %t827, label %bb256, label %bb257
bb256:
  br label %bb258
bb257:
  br label %bb260
bb258:
  store %olang.scope zeroinitializer, ptr %s41
  %t828 = load ptr, ptr %l1, !tbaa !29
  store ptr %t828, ptr %l423, !tbaa !29
  %t829 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 1
  %t830 = load i64, ptr %t829, !tbaa !24
  store i64 %t830, ptr %l424, !tbaa !24
  %t831 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t832 = load i64, ptr %t831, !tbaa !24
  store i64 %t832, ptr %l425, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s42
  store ptr %s42room, ptr %s42
  %t833 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 1
  %t834 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 0
  call void @__olang_sb_put(ptr %s42, ptr %t833, i64 %t834)
  %t835 = load i64, ptr %l424, !tbaa !24
  %t836 = call ptr @__olang_sb_room(ptr %s42, i64 24)
  %t837 = call i64 @__olang_fmt_i64(ptr %t836, i64 %t835)
  call void @__olang_sb_add(ptr %s42, i64 %t837)
  %t838 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 1
  %t839 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 0
  call void @__olang_sb_put(ptr %s42, ptr %t838, i64 %t839)
  %t840 = load i64, ptr %l425, !tbaa !24
  %t841 = call ptr @__olang_sb_room(ptr %s42, i64 24)
  %t842 = call i64 @__olang_fmt_i64(ptr %t841, i64 %t840)
  call void @__olang_sb_add(ptr %s42, i64 %t842)
  %t843 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 1
  %t844 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 0
  call void @__olang_sb_put(ptr %s42, ptr %t843, i64 %t844)
  %t845 = load ptr, ptr %s42
  %t846 = getelementptr %olang.builder, ptr %s42, i32 0, i32 1
  %t847 = load i64, ptr %t846
  %t848 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t847)
  call void @llvm.memcpy.p0.p0.i64(ptr %t848, ptr %t845, i64 %t847, i1 false)
  %t849 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t850 = insertvalue { i64, ptr } %t849, ptr %t848, 1
  store { i64, ptr } %t850, ptr %l426, !tbaa !27
  call void @__olang_sb_done(ptr %s42)
  %t851 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t852 = extractvalue { i64, ptr } %t851, 0
  %t853 = extractvalue { i64, ptr } %t851, 1
  %t854 = mul i64 %t852, 1
  %t855 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t854)
  call void @llvm.memcpy.p0.p0.i64(ptr %t855, ptr %t853, i64 %t854, i1 false)
  %t856 = insertvalue { i64, ptr } undef, i64 %t852, 0
  %t857 = insertvalue { i64, ptr } %t856, ptr %t855, 1
  store { i64, ptr } %t857, ptr %l427, !tbaa !27
  %t858 = load ptr, ptr %l423, !tbaa !29
  %t859 = load { i64, ptr }, ptr %l427, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s41, ptr %t858, { i64, ptr } %t859)
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s41)
  br label %bb289
bb260:
  %t860 = load i32, ptr %l4
  store i32 %t860, ptr %l428
  %t861 = load i32, ptr %l428
  %t862 = trunc i64 26 to i32
  %t863 = icmp eq i32 %t861, %t862
  store i1 %t863, ptr %l429, !tbaa !21
  %t864 = load i1, ptr %l429, !tbaa !21
  br i1 %t864, label %bb261, label %bb262
bb261:
  br label %bb263
bb262:
  br label %bb282
bb263:
  store %olang.scope zeroinitializer, ptr %s43
  %t865 = load ptr, ptr %l0, !tbaa !29
  store ptr %t865, ptr %l430, !tbaa !29
  %t866 = load i32, ptr %l2, !tbaa !23
  store i32 %t866, ptr %l431, !tbaa !23
  %t867 = load ptr, ptr %l430, !tbaa !29
  %t868 = load i32, ptr %l431, !tbaa !23
  %t869 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t867, i32 %t868)
  store i32 %t869, ptr %l432
  br label %bb264
bb264:
  %t870 = load i32, ptr %l432, !tbaa !23
  store i32 %t870, ptr %l38, !tbaa !23
  %t871 = load i32, ptr %l38, !tbaa !23
  store i32 %t871, ptr %l433, !tbaa !23
  %t872 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t872, ptr %l434, !tbaa !23
  %t873 = load i32, ptr %l433, !tbaa !23
  %t874 = load i32, ptr %l434, !tbaa !23
  %t875 = icmp eq i32 %t873, %t874
  store i1 %t875, ptr %l435, !tbaa !21
  %t876 = load i1, ptr %l435, !tbaa !21
  br i1 %t876, label %bb265, label %bb266
bb265:
  store %olang.scope zeroinitializer, ptr %s44
  %t877 = load ptr, ptr %l1, !tbaa !29
  store ptr %t877, ptr %l436, !tbaa !29
  %t878 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t879 = load i64, ptr %t878, !tbaa !24
  store i64 %t879, ptr %l437, !tbaa !24
  %t880 = load i64, ptr %l437, !tbaa !24
  %t881 = icmp ne i64 %t880, 0
  store i1 %t881, ptr %l438, !tbaa !21
  %t882 = load i1, ptr %l438, !tbaa !21
  br i1 %t882, label %bb267, label %bb268
bb266:
  store %olang.scope zeroinitializer, ptr %s45
  %t883 = load ptr, ptr %l0, !tbaa !29
  store ptr %t883, ptr %l440, !tbaa !29
  %t884 = load i32, ptr %l38, !tbaa !23
  store i32 %t884, ptr %l441, !tbaa !23
  %t885 = load ptr, ptr %l440, !tbaa !29
  %t886 = load i32, ptr %l441, !tbaa !23
  %t887 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t885, i32 %t886)
  store i1 %t887, ptr %l442
  br label %bb271
bb267:
  store { i64, ptr } { i64 4, ptr @.d60 }, ptr %l439, !tbaa !27
  br label %bb269
bb268:
  store { i64, ptr } { i64 5, ptr @.d61 }, ptr %l439, !tbaa !27
  br label %bb269
bb269:
  %t888 = load ptr, ptr %l436, !tbaa !29
  %t889 = load { i64, ptr }, ptr %l439, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s44, ptr %t888, { i64, ptr } %t889)
  br label %bb270
bb270:
  call void @__olang_scope_close(ptr %s44)
  br label %bb281
bb271:
  %t890 = load i1, ptr %l442, !tbaa !21
  br i1 %t890, label %bb272, label %bb273
bb272:
  %t891 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t892 = load i64, ptr %t891, !tbaa !24
  store i64 %t892, ptr %l444, !tbaa !24
  %t893 = load i64, ptr %l444, !tbaa !24
  %t894 = icmp slt i64 %t893, 0
  store i1 %t894, ptr %l445, !tbaa !21
  %t895 = load i1, ptr %l445, !tbaa !21
  store i1 %t895, ptr %l443, !tbaa !21
  br label %bb274
bb273:
  store i1 false, ptr %l443, !tbaa !21
  br label %bb274
bb274:
  %t896 = load i1, ptr %l443, !tbaa !21
  br i1 %t896, label %bb275, label %bb276
bb275:
  store %olang.scope zeroinitializer, ptr %s46
  %t897 = load ptr, ptr %l1, !tbaa !29
  store ptr %t897, ptr %l446, !tbaa !29
  %t898 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t899 = load i64, ptr %t898, !tbaa !24
  store i64 %t899, ptr %l447, !tbaa !24
  %t900 = load i64, ptr %l447, !tbaa !24
  %t901 = call { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %s46, i64 %t900)
  store { i64, ptr } %t901, ptr %l448
  br label %bb277
bb276:
  store %olang.scope zeroinitializer, ptr %s47
  %t902 = load ptr, ptr %l1, !tbaa !29
  store ptr %t902, ptr %l450, !tbaa !29
  %t903 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t904 = load i64, ptr %t903, !tbaa !24
  store i64 %t904, ptr %l451, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s48
  store ptr %s48room, ptr %s48
  %t905 = load i64, ptr %l451, !tbaa !24
  %t906 = call ptr @__olang_sb_room(ptr %s48, i64 24)
  %t907 = call i64 @__olang_fmt_i64(ptr %t906, i64 %t905)
  call void @__olang_sb_add(ptr %s48, i64 %t907)
  %t908 = load ptr, ptr %s48
  %t909 = getelementptr %olang.builder, ptr %s48, i32 0, i32 1
  %t910 = load i64, ptr %t909
  %t911 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t910)
  call void @llvm.memcpy.p0.p0.i64(ptr %t911, ptr %t908, i64 %t910, i1 false)
  %t912 = insertvalue { i64, ptr } undef, i64 %t910, 0
  %t913 = insertvalue { i64, ptr } %t912, ptr %t911, 1
  store { i64, ptr } %t913, ptr %l452, !tbaa !27
  call void @__olang_sb_done(ptr %s48)
  %t914 = load { i64, ptr }, ptr %l452, !tbaa !27
  %t915 = extractvalue { i64, ptr } %t914, 0
  %t916 = extractvalue { i64, ptr } %t914, 1
  %t917 = mul i64 %t915, 1
  %t918 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t917)
  call void @llvm.memcpy.p0.p0.i64(ptr %t918, ptr %t916, i64 %t917, i1 false)
  %t919 = insertvalue { i64, ptr } undef, i64 %t915, 0
  %t920 = insertvalue { i64, ptr } %t919, ptr %t918, 1
  store { i64, ptr } %t920, ptr %l453, !tbaa !27
  %t921 = load ptr, ptr %l450, !tbaa !29
  %t922 = load { i64, ptr }, ptr %l453, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s47, ptr %t921, { i64, ptr } %t922)
  br label %bb279
bb277:
  %t923 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t924 = extractvalue { i64, ptr } %t923, 0
  %t925 = extractvalue { i64, ptr } %t923, 1
  %t926 = mul i64 %t924, 1
  %t927 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t926)
  call void @llvm.memcpy.p0.p0.i64(ptr %t927, ptr %t925, i64 %t926, i1 false)
  %t928 = insertvalue { i64, ptr } undef, i64 %t924, 0
  %t929 = insertvalue { i64, ptr } %t928, ptr %t927, 1
  store { i64, ptr } %t929, ptr %l449, !tbaa !27
  %t930 = load ptr, ptr %l446, !tbaa !29
  %t931 = load { i64, ptr }, ptr %l449, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s46, ptr %t930, { i64, ptr } %t931)
  br label %bb278
bb278:
  call void @__olang_scope_close(ptr %s46)
  br label %bb280
bb279:
  call void @__olang_scope_close(ptr %s47)
  br label %bb280
bb280:
  call void @__olang_scope_close(ptr %s45)
  br label %bb281
bb281:
  call void @__olang_scope_close(ptr %s43)
  br label %bb289
bb282:
  %t932 = load i32, ptr %l4
  store i32 %t932, ptr %l454
  %t933 = load i32, ptr %l454
  %t934 = trunc i64 27 to i32
  %t935 = icmp eq i32 %t933, %t934
  store i1 %t935, ptr %l455, !tbaa !21
  %t936 = load i1, ptr %l455, !tbaa !21
  br i1 %t936, label %bb283, label %bb284
bb283:
  br label %bb285
bb284:
  br label %bb288
bb285:
  store %olang.scope zeroinitializer, ptr %s49
  %t937 = load ptr, ptr %l1, !tbaa !29
  store ptr %t937, ptr %l456, !tbaa !29
  %t938 = load ptr, ptr %l0, !tbaa !29
  store ptr %t938, ptr %l457, !tbaa !29
  %t939 = load i32, ptr %l2, !tbaa !23
  store i32 %t939, ptr %l458, !tbaa !23
  %t940 = load ptr, ptr %l457, !tbaa !29
  %t941 = load i32, ptr %l458, !tbaa !23
  %t942 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %t940, i32 %t941)
  store { i64, ptr } %t942, ptr %l459
  br label %bb286
bb286:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s50
  store ptr %s50room, ptr %s50
  %t943 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 1
  %t944 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 0
  call void @__olang_sb_put(ptr %s50, ptr %t943, i64 %t944)
  %t945 = load { i64, ptr }, ptr %l459, !tbaa !27
  %t946 = extractvalue { i64, ptr } %t945, 1
  %t947 = extractvalue { i64, ptr } %t945, 0
  call void @__olang_sb_put(ptr %s50, ptr %t946, i64 %t947)
  %t948 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 1
  %t949 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 0
  call void @__olang_sb_put(ptr %s50, ptr %t948, i64 %t949)
  %t950 = load ptr, ptr %s50
  %t951 = getelementptr %olang.builder, ptr %s50, i32 0, i32 1
  %t952 = load i64, ptr %t951
  %t953 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t952)
  call void @llvm.memcpy.p0.p0.i64(ptr %t953, ptr %t950, i64 %t952, i1 false)
  %t954 = insertvalue { i64, ptr } undef, i64 %t952, 0
  %t955 = insertvalue { i64, ptr } %t954, ptr %t953, 1
  store { i64, ptr } %t955, ptr %l460, !tbaa !27
  call void @__olang_sb_done(ptr %s50)
  %t956 = load { i64, ptr }, ptr %l460, !tbaa !27
  %t957 = extractvalue { i64, ptr } %t956, 0
  %t958 = extractvalue { i64, ptr } %t956, 1
  %t959 = mul i64 %t957, 1
  %t960 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t959)
  call void @llvm.memcpy.p0.p0.i64(ptr %t960, ptr %t958, i64 %t959, i1 false)
  %t961 = insertvalue { i64, ptr } undef, i64 %t957, 0
  %t962 = insertvalue { i64, ptr } %t961, ptr %t960, 1
  store { i64, ptr } %t962, ptr %l461, !tbaa !27
  %t963 = load ptr, ptr %l456, !tbaa !29
  %t964 = load { i64, ptr }, ptr %l461, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s49, ptr %t963, { i64, ptr } %t964)
  br label %bb287
bb287:
  call void @__olang_scope_close(ptr %s49)
  br label %bb289
bb288:
  call void @__olang_check_failed(ptr @.c64)
  unreachable
bb289:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l7, !tbaa !23
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t4 = load i32, ptr %l7, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t3, i32 %t4)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l11, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  store i1 %t15, ptr %l13, !tbaa !21
  %t16 = load i1, ptr %l13, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l14, !tbaa !21
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l16, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t21
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l17, !tbaa !23
  %t26 = load i32, ptr %l17, !tbaa !23
  store i32 %t26, ptr %l5, !tbaa !23
  %t27 = load i32, ptr %l5, !tbaa !23
  store i32 %t27, ptr %l18, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = icmp ne i32 %t28, 0
  store i1 %t29, ptr %l19, !tbaa !21
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  store i32 %t32, ptr %l22, !tbaa !23
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i32, ptr %l22, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t35, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l24, !tbaa !21
  %t38 = load i1, ptr %l24, !tbaa !21
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 false, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i1, ptr %l25, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t41 = load i64, ptr %l3, !tbaa !24
  store i64 %t41, ptr %l26, !tbaa !24
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = add i64 %t42, 1
  store i64 %t43, ptr %l27, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  store i64 %t44, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb2
bb14:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %l28, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i1, ptr %l28, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr %l2, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 4
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l9, !tbaa !23
  %t5 = load i32, ptr %l9, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l10, !tbaa !24
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store { i64, ptr } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t11, ptr %l12, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l13, !tbaa !24
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  store i64 %t15, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l16, !tbaa !21
  %t20 = load i1, ptr %l16, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l17, !tbaa !21
  %t22 = load i1, ptr %l17, !tbaa !21
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l18, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l19, !tbaa !24
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t25
  %t29 = load i32, ptr %t28, !tbaa !33
  store i32 %t29, ptr %l20, !tbaa !23
  %t30 = load i32, ptr %l20, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load i32, ptr %l6, !tbaa !23
  store i32 %t32, ptr %l22, !tbaa !23
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i32, ptr %l22, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load i32, ptr %l2, !tbaa !23
  store i32 %t36, ptr %l24, !tbaa !23
  %t37 = load i32, ptr %l23, !tbaa !23
  %t38 = load i32, ptr %l24, !tbaa !23
  %t39 = icmp sgt i32 %t37, %t38
  store i1 %t39, ptr %l25, !tbaa !21
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  store i32 %t42, ptr %l27, !tbaa !23
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = load i32, ptr %l27, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t45, ptr %l28
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t46 = load i32, ptr %l28, !tbaa !23
  store i32 %t46, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = load i64, ptr %l4, !tbaa !24
  store i64 %t47, ptr %l29, !tbaa !24
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = add i64 %t48, 1
  store i64 %t49, ptr %l30, !tbaa !24
  %t50 = load i64, ptr %l30, !tbaa !24
  store i64 %t50, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb2
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t51 = load i32, ptr %l2, !tbaa !23
  store i32 %t51, ptr %l31, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i32, ptr %l31, !tbaa !23
  store i32 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t7, i64 %t8)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t3, i32 %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 3, ptr @.d65 }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l10, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  store i32 %t26, ptr %l11, !tbaa !23
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = load i32, ptr %l11, !tbaa !23
  %t29 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t27, i32 %t28)
  store i64 %t29, ptr %l12
  br label %bb5
bb5:
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = sdiv i64 %t30, 8
  store i64 %t31, ptr %l13, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t32 = extractvalue { i64, ptr } { i64 8, ptr @.d66 }, 1
  %t33 = extractvalue { i64, ptr } { i64 8, ptr @.d66 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t32, i64 %t33)
  %t34 = load i64, ptr %l13, !tbaa !24
  %t35 = call ptr @__olang_sb_room(ptr %s2, i64 24)
  %t36 = call i64 @__olang_fmt_i64(ptr %t35, i64 %t34)
  call void @__olang_sb_add(ptr %s2, i64 %t36)
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d67 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d67 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t37, i64 %t38)
  %t39 = load ptr, ptr %s2
  %t40 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t41 = load i64, ptr %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t39, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l14, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  store i32 %t7, ptr %l7
  %t8 = load i32, ptr %l7
  %t9 = trunc i64 18 to i32
  %t10 = icmp eq i32 %t8, %t9
  store i1 %t10, ptr %l8, !tbaa !21
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  store i32 %t13, ptr %l10, !tbaa !23
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i32, ptr %l10, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load i32, ptr %l11, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb6:
  %t18 = load i32, ptr %l2
  store i32 %t18, ptr %l12
  %t19 = load i32, ptr %l12
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t19, %t20
  store i1 %t21, ptr %l13, !tbaa !21
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t23 = load i32, ptr %l2
  store i32 %t23, ptr %l14
  %t24 = load i32, ptr %l14
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t24, %t25
  store i1 %t26, ptr %l15, !tbaa !21
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb13
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  store i32 %t29, ptr %l17, !tbaa !23
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i32, ptr %l17, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t32, ptr %l18
  br label %bb12
bb12:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 0, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i32, ptr %l6, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/types:data"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/types:data"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/types:data"
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca %"compiler/types:data"
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/types:data" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 2
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load %"compiler/types:data", ptr %l1
  store %"compiler/types:data" %t4, ptr %l7
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load %"compiler/types:data", ptr %l7
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %t5, %"compiler/types:data" %t6)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i32, ptr %l8, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i32 -1, ptr %l4, !tbaa !23
  br label %bb4
bb4:
  %t13 = load i32, ptr %l4, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  store i32 %t14, ptr %l10, !tbaa !23
  %t15 = load i32, ptr %l10, !tbaa !23
  %t16 = icmp sge i32 %t15, 0
  store i1 %t16, ptr %l11, !tbaa !21
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load i32, ptr %l3, !tbaa !23
  store i32 %t18, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i32, ptr %l12, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t21, i32 0, i32 1
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t23)
  store i64 %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = trunc i64 %t25 to i32
  store i32 %t26, ptr %l16, !tbaa !23
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l17, !tbaa !23
  %t28 = load i32, ptr %l17, !tbaa !23
  store i32 %t28, ptr %l3, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = getelementptr %"compiler/types:Table", ptr %t30, i32 0, i32 1
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load %"compiler/types:data", ptr %l1
  store %"compiler/types:data" %t32, ptr %l20
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = load %"compiler/types:data", ptr %l20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t33, %"compiler/types:data" %t34)
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = getelementptr %"compiler/types:Table", ptr %t36, i32 0, i32 2
  store ptr %t37, ptr %l22, !tbaa !29
  %t38 = load %"compiler/types:data", ptr %l1
  store %"compiler/types:data" %t38, ptr %l23
  %t39 = load i32, ptr %l3, !tbaa !23
  store i32 %t39, ptr %l24, !tbaa !23
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = load %"compiler/types:data", ptr %l23
  %t42 = load i32, ptr %l24, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %t40, %"compiler/types:data" %t41, i32 %t42)
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = getelementptr %"compiler/types:Table", ptr %t44, i32 0, i32 3
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  store i32 %t46, ptr %l27, !tbaa !23
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i32, ptr %l27, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t47, i32 %t48)
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t51 = getelementptr %"compiler/types:Table", ptr %t50, i32 0, i32 16
  store ptr %t51, ptr %l29, !tbaa !29
  %t52 = load i64, ptr @G_2ecompiler_2ftypes_2eNotLaidOut, !tbaa !24
  store i64 %t52, ptr %l30, !tbaa !24
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load i64, ptr %l30, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t53, i64 %t54)
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = getelementptr %"compiler/types:Table", ptr %t56, i32 0, i32 17
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l32, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t58, i64 0)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t60, i32 0, i32 18
  store ptr %t61, ptr %l34, !tbaa !29
  %t62 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t62, i64 1)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l35, !tbaa !29
  %t64 = load ptr, ptr %l35, !tbaa !29
  %t65 = getelementptr %"compiler/types:Table", ptr %t64, i32 0, i32 19
  store ptr %t65, ptr %l36, !tbaa !29
  %t66 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t66, i64 -1)
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = getelementptr %"compiler/types:Table", ptr %t68, i32 0, i32 21
  store ptr %t69, ptr %l38, !tbaa !29
  %t70 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t70, i64 -1)
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t72, i32 0, i32 22
  store ptr %t73, ptr %l40, !tbaa !29
  %t74 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t74, { i64, ptr } { i64 0, ptr @.d69 })
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l41, !tbaa !29
  %t76 = load ptr, ptr %l41, !tbaa !29
  %t77 = getelementptr %"compiler/types:Table", ptr %t76, i32 0, i32 23
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  store i32 %t78, ptr %l43, !tbaa !23
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = load i32, ptr %l43, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t79, i32 %t80)
  br label %bb18
bb18:
  %t81 = load i32, ptr %l3, !tbaa !23
  store i32 %t81, ptr %l44, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t82 = load i32, ptr %l44, !tbaa !23
  store i32 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i64
  %l48 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l11, !tbaa !23
  %t3 = load ptr, ptr %l10, !tbaa !29
  %t4 = load i32, ptr %l11, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t3, i32 %t4)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t7, ptr %l13, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l14, !tbaa !24
  %t10 = load i64, ptr %l14, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %l15, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l16, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  %t15 = icmp sgt i64 %t13, %t14
  store i1 %t15, ptr %l17, !tbaa !21
  %t16 = load i1, ptr %l17, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l6, !tbaa !24
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load i64, ptr %l19, !tbaa !24
  %t19 = icmp sgt i64 %t18, 0
  store i1 %t19, ptr %l20, !tbaa !21
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l5, !tbaa !24
  store i64 %t21, ptr %l22, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l23, !tbaa !24
  %t23 = load i64, ptr %l22, !tbaa !24
  %t24 = load i64, ptr %l23, !tbaa !24
  %t25 = sub i64 %t23, %t24
  store i64 %t25, ptr %l24, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  store i64 %t26, ptr %l25, !tbaa !24
  %t27 = load i64, ptr %l24, !tbaa !24
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = add i64 %t27, %t28
  store i64 %t29, ptr %l26, !tbaa !24
  %t30 = load i64, ptr %l26, !tbaa !24
  %t31 = sub i64 %t30, 1
  store i64 %t31, ptr %l27, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load i64, ptr %l27, !tbaa !24
  %t34 = load i64, ptr %l28, !tbaa !24
  %t35 = sdiv i64 %t33, %t34
  store i64 %t35, ptr %l29, !tbaa !24
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l8, !tbaa !24
  store i64 %t39, ptr %l30, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  store i64 %t40, ptr %l31, !tbaa !24
  %t41 = load i64, ptr %l30, !tbaa !24
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  store i1 %t43, ptr %l32, !tbaa !21
  %t44 = load i1, ptr %l32, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l33, !tbaa !21
  %t46 = load i1, ptr %l33, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l4, !tbaa !24
  store i64 %t47, ptr %l34, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  store i64 %t48, ptr %l35, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l36, !tbaa !24
  %t50 = load i64, ptr %l35, !tbaa !24
  %t51 = load i64, ptr %l36, !tbaa !24
  %t52 = mul i64 %t50, %t51
  store i64 %t52, ptr %l37, !tbaa !24
  %t53 = load i64, ptr %l34, !tbaa !24
  %t54 = load i64, ptr %l37, !tbaa !24
  %t55 = add i64 %t53, %t54
  store i64 %t55, ptr %l38, !tbaa !24
  %t56 = load i64, ptr %l38, !tbaa !24
  store i64 %t56, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  store i64 %t57, ptr %l39, !tbaa !24
  %t58 = load i64, ptr %l39, !tbaa !24
  %t59 = icmp sgt i64 %t58, 0
  store i1 %t59, ptr %l40, !tbaa !21
  %t60 = load i1, ptr %l40, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l41, !tbaa !29
  %t62 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t62, { i64, ptr } { i64 2, ptr @.d70 })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l42, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l43, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t65, ptr %l44, !tbaa !27
  %t66 = load i64, ptr %l9, !tbaa !24
  store i64 %t66, ptr %l45, !tbaa !24
  %t67 = load i64, ptr %l45, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 %t67
  %t71 = load i32, ptr %t70, !tbaa !33
  store i32 %t71, ptr %l46, !tbaa !23
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load ptr, ptr %l43, !tbaa !29
  %t74 = load i32, ptr %l46, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t72, ptr %t73, i32 %t74)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t75 = load i64, ptr %l8, !tbaa !24
  store i64 %t75, ptr %l47, !tbaa !24
  %t76 = load i64, ptr %l47, !tbaa !24
  %t77 = add i64 %t76, 1
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load i64, ptr %l48, !tbaa !24
  store i64 %t78, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb18:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, i64 }
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l10, !tbaa !23
  %t3 = load ptr, ptr %l9, !tbaa !29
  %t4 = load i32, ptr %l10, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  %t7 = xor i1 %t6, true
  store i1 %t7, ptr %l12, !tbaa !21
  %t8 = load i1, ptr %l12, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = insertvalue { i64, i64 } undef, i64 4, 0
  %t10 = insertvalue { i64, i64 } %t9, i64 4, 1
  store { i64, i64 } %t10, ptr %l13
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load { i64, i64 }, ptr %l13
  store { i64, i64 } %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l14, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  store i32 %t13, ptr %l15, !tbaa !23
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l16
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l18, !tbaa !24
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t22 = load i64, ptr %l5, !tbaa !24
  store i64 %t22, ptr %l19, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  store i64 %t23, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l19, !tbaa !24
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  store i1 %t26, ptr %l21, !tbaa !21
  %t27 = load i1, ptr %l21, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l22, !tbaa !21
  %t29 = load i1, ptr %l22, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load i64, ptr %l24, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t32
  %t36 = load i32, ptr %t35, !tbaa !33
  store i32 %t36, ptr %l25, !tbaa !23
  %t37 = load i32, ptr %l25, !tbaa !23
  store i32 %t37, ptr %l7, !tbaa !23
  %t38 = load i32, ptr %l7, !tbaa !23
  store i32 %t38, ptr %l26, !tbaa !23
  %t39 = load i32, ptr %l26, !tbaa !23
  %t40 = icmp ne i32 %t39, 0
  store i1 %t40, ptr %l27, !tbaa !21
  %t41 = load i1, ptr %l27, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  %t43 = load i32, ptr %l7, !tbaa !23
  store i32 %t43, ptr %l30, !tbaa !23
  %t44 = load ptr, ptr %l29, !tbaa !29
  %t45 = load i32, ptr %l30, !tbaa !23
  %t46 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t46, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l31, !tbaa !24
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = icmp sgt i64 %t48, %t49
  store i1 %t50, ptr %l33, !tbaa !21
  %t51 = load i1, ptr %l33, !tbaa !21
  store i1 %t51, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  %t54 = load i32, ptr %l7, !tbaa !23
  store i32 %t54, ptr %l35, !tbaa !23
  %t55 = load ptr, ptr %l34, !tbaa !29
  %t56 = load i32, ptr %l35, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t57, ptr %l36
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t58 = load i64, ptr %l36, !tbaa !24
  store i64 %t58, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t59 = load i64, ptr %l5, !tbaa !24
  store i64 %t59, ptr %l37, !tbaa !24
  %t60 = load i64, ptr %l37, !tbaa !24
  %t61 = add i64 %t60, 1
  store i64 %t61, ptr %l38, !tbaa !24
  %t62 = load i64, ptr %l38, !tbaa !24
  store i64 %t62, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb6
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l39, !tbaa !24
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = add i64 %t64, 7
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l40, !tbaa !24
  %t67 = sdiv i64 %t66, 8
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load i64, ptr %l41, !tbaa !24
  %t69 = mul i64 %t68, 8
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load i64, ptr %l42, !tbaa !24
  store i64 %t70, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l43, !tbaa !29
  %t72 = load ptr, ptr %l43, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t72, i32 0, i32 21
  store ptr %t73, ptr %l44, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  store i32 %t74, ptr %l45, !tbaa !23
  %t75 = load i32, ptr %l45, !tbaa !23
  %t76 = sext i32 %t75 to i64
  store i64 %t76, ptr %l46, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  store i64 %t77, ptr %l47, !tbaa !24
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = load i64, ptr %l46, !tbaa !24
  %t80 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t78, i64 %t79, i64 %t80)
  br label %bb20
bb20:
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l48, !tbaa !24
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = add i64 8, %t82
  store i64 %t83, ptr %l49, !tbaa !24
  %t84 = load i64, ptr %l49, !tbaa !24
  %t85 = insertvalue { i64, i64 } undef, i64 %t84, 0
  %t86 = insertvalue { i64, i64 } %t85, i64 8, 1
  store { i64, i64 } %t86, ptr %l50
  call void @__olang_scope_close(ptr %s0)
  %t87 = load { i64, i64 }, ptr %l50
  store { i64, i64 } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t2, i32 0, i32 19
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l12, !tbaa !23
  %t5 = load i32, ptr %l12, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l13, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l14, !tbaa !29
  %t8 = load ptr, ptr %l14, !tbaa !29
  %t9 = getelementptr %"compiler/types:Table", ptr %t8, i32 0, i32 20
  store ptr %t9, ptr %l15, !tbaa !29
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13, i64 %t14)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l17, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  store i32 %t16, ptr %l18, !tbaa !23
  %t17 = load ptr, ptr %l17, !tbaa !29
  %t18 = load i32, ptr %l18, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l19
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l20, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l21, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l6, !tbaa !24
  store i64 %t25, ptr %l22, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load i64, ptr %l22, !tbaa !24
  %t28 = load i64, ptr %l23, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l24, !tbaa !21
  %t30 = load i1, ptr %l24, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l25, !tbaa !21
  %t32 = load i1, ptr %l25, !tbaa !21
  br i1 %t32, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l27, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t35
  %t39 = load i32, ptr %t38, !tbaa !33
  store i32 %t39, ptr %l28, !tbaa !23
  %t40 = load i32, ptr %l28, !tbaa !23
  store i32 %t40, ptr %l8, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l29, !tbaa !29
  %t42 = load i32, ptr %l8, !tbaa !23
  store i32 %t42, ptr %l30, !tbaa !23
  %t43 = load ptr, ptr %l29, !tbaa !29
  %t44 = load i32, ptr %l30, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t43, i32 %t44)
  store i64 %t45, ptr %l31
  br label %bb8
bb8:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  store i64 %t48, ptr %l33, !tbaa !24
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l33, !tbaa !24
  %t51 = icmp sgt i64 %t49, %t50
  store i1 %t51, ptr %l34, !tbaa !21
  %t52 = load i1, ptr %l34, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load i64, ptr %l9, !tbaa !24
  store i64 %t53, ptr %l35, !tbaa !24
  %t54 = load i64, ptr %l35, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l3, !tbaa !24
  store i64 %t55, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  store i64 %t56, ptr %l37, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = load i64, ptr %l37, !tbaa !24
  %t59 = add i64 %t57, %t58
  store i64 %t59, ptr %l38, !tbaa !24
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = sub i64 %t60, 1
  store i64 %t61, ptr %l39, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  store i64 %t62, ptr %l40, !tbaa !24
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = load i64, ptr %l40, !tbaa !24
  %t65 = sdiv i64 %t63, %t64
  store i64 %t65, ptr %l41, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  store i64 %t66, ptr %l42, !tbaa !24
  %t67 = load i64, ptr %l41, !tbaa !24
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = mul i64 %t67, %t68
  store i64 %t69, ptr %l43, !tbaa !24
  %t70 = load i64, ptr %l43, !tbaa !24
  store i64 %t70, ptr %l3, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l44, !tbaa !29
  %t72 = load ptr, ptr %l44, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t72, i32 0, i32 20
  store ptr %t73, ptr %l45, !tbaa !29
  %t74 = load i64, ptr %l3, !tbaa !24
  store i64 %t74, ptr %l46, !tbaa !24
  %t75 = load ptr, ptr %l45, !tbaa !29
  %t76 = load i64, ptr %l46, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb12
bb12:
  %t77 = load i64, ptr %l3, !tbaa !24
  store i64 %t77, ptr %l47, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l48, !tbaa !29
  %t79 = load i32, ptr %l8, !tbaa !23
  store i32 %t79, ptr %l49, !tbaa !23
  %t80 = load ptr, ptr %l48, !tbaa !29
  %t81 = load i32, ptr %l49, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t80, i32 %t81)
  store i64 %t82, ptr %l50
  br label %bb13
bb13:
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = add i64 %t83, %t84
  store i64 %t85, ptr %l51, !tbaa !24
  %t86 = load i64, ptr %l51, !tbaa !24
  store i64 %t86, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t87 = load i64, ptr %l6, !tbaa !24
  store i64 %t87, ptr %l52, !tbaa !24
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = add i64 %t88, 1
  store i64 %t89, ptr %l53, !tbaa !24
  %t90 = load i64, ptr %l53, !tbaa !24
  store i64 %t90, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb4
bb15:
  call void @__olang_scope_close(ptr %s1)
  %t91 = load i64, ptr %l3, !tbaa !24
  store i64 %t91, ptr %l54, !tbaa !24
  %t92 = load i64, ptr %l4, !tbaa !24
  store i64 %t92, ptr %l55, !tbaa !24
  %t93 = load i64, ptr %l54, !tbaa !24
  %t94 = load i64, ptr %l55, !tbaa !24
  %t95 = add i64 %t93, %t94
  store i64 %t95, ptr %l56, !tbaa !24
  %t96 = load i64, ptr %l56, !tbaa !24
  %t97 = sub i64 %t96, 1
  store i64 %t97, ptr %l57, !tbaa !24
  %t98 = load i64, ptr %l4, !tbaa !24
  store i64 %t98, ptr %l58, !tbaa !24
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = load i64, ptr %l58, !tbaa !24
  %t101 = sdiv i64 %t99, %t100
  store i64 %t101, ptr %l59, !tbaa !24
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l60, !tbaa !24
  %t103 = load i64, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l60, !tbaa !24
  %t105 = mul i64 %t103, %t104
  store i64 %t105, ptr %l61, !tbaa !24
  %t106 = load i64, ptr %l4, !tbaa !24
  store i64 %t106, ptr %l62, !tbaa !24
  %t107 = load i64, ptr %l61, !tbaa !24
  %t108 = insertvalue { i64, i64 } undef, i64 %t107, 0
  %t109 = load i64, ptr %l62, !tbaa !24
  %t110 = insertvalue { i64, i64 } %t108, i64 %t109, 1
  store { i64, i64 } %t110, ptr %l63
  call void @__olang_scope_close(ptr %s0)
  %t111 = load { i64, i64 }, ptr %l63
  store { i64, i64 } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l7, !tbaa !23
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t4 = load i32, ptr %l7, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t3, i32 %t4)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l11, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  store i1 %t15, ptr %l13, !tbaa !21
  %t16 = load i1, ptr %l13, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l14, !tbaa !21
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l16, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t21
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l17, !tbaa !23
  %t26 = load i32, ptr %l17, !tbaa !23
  store i32 %t26, ptr %l5, !tbaa !23
  %t27 = load i32, ptr %l5, !tbaa !23
  store i32 %t27, ptr %l18, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = icmp eq i32 %t28, 0
  store i1 %t29, ptr %l19, !tbaa !21
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 29
  store i1 true, ptr %t33, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l5, !tbaa !23
  store i32 %t35, ptr %l22, !tbaa !23
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load i32, ptr %l22, !tbaa !23
  %t38 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t38, ptr %l23
  br label %bb8
bb8:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  store i1 true, ptr %l24, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i1, ptr %l24, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s6
  %t41 = load i64, ptr %l3, !tbaa !24
  store i64 %t41, ptr %l25, !tbaa !24
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = add i64 %t42, 1
  store i64 %t43, ptr %l26, !tbaa !24
  %t44 = load i64, ptr %l26, !tbaa !24
  store i64 %t44, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb2
bb14:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %l27, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i1, ptr %l27, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  store i32 %t3, ptr %l5, !tbaa !23
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l5, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7
  store i32 %t10, ptr %l2
  %t11 = load i32, ptr %l2
  store i32 %t11, ptr %l9
  %t12 = load i32, ptr %l9
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t12, %t13
  store i1 %t14, ptr %l10, !tbaa !21
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  store i32 %t17, ptr %l12, !tbaa !23
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s1, ptr %t18, i32 %t19)
  store { i64, ptr } %t20, ptr %l13
  br label %bb6
bb6:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t21 = extractvalue { i64, ptr } { i64 2, ptr @.d71 }, 1
  %t22 = extractvalue { i64, ptr } { i64 2, ptr @.d71 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t21, i64 %t22)
  %t23 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  call void @__olang_sb_put(ptr %s2, ptr %t24, i64 %t25)
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d72 }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr @.d72 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t26, i64 %t27)
  %t28 = load ptr, ptr %s2
  %t29 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t30 = load i64, ptr %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t28, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l14, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t34 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb7:
  %t35 = load i32, ptr %l2
  store i32 %t35, ptr %l15
  %t36 = load i32, ptr %l15
  %t37 = trunc i64 1 to i32
  %t38 = icmp eq i32 %t36, %t37
  store i1 %t38, ptr %l16, !tbaa !21
  %t39 = load i1, ptr %l16, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l1, !tbaa !23
  store i32 %t41, ptr %l18, !tbaa !23
  %t42 = load ptr, ptr %l17, !tbaa !29
  %t43 = load i32, ptr %l18, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l19
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t45, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb12:
  %t46 = load i32, ptr %l2
  store i32 %t46, ptr %l20
  %t47 = load i32, ptr %l20
  %t48 = trunc i64 2 to i32
  %t49 = icmp eq i32 %t47, %t48
  store i1 %t49, ptr %l21, !tbaa !21
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 3, ptr @.d73 }, ptr %l22, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t51, ptr %l23, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t52, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb16:
  %t53 = load i32, ptr %l2
  store i32 %t53, ptr %l24
  %t54 = load i32, ptr %l24
  %t55 = trunc i64 4 to i32
  %t56 = icmp eq i32 %t54, %t55
  store i1 %t56, ptr %l25, !tbaa !21
  %t57 = load i1, ptr %l25, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l26, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l27, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  store i32 %t60, ptr %l28, !tbaa !23
  %t61 = load ptr, ptr %l27, !tbaa !29
  %t62 = load i32, ptr %l28, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t63, ptr %l29
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l26, !tbaa !29
  %t65 = load i32, ptr %l29, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l30
  br label %bb21
bb21:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t67 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  call void @__olang_sb_put(ptr %s6, ptr %t68, i64 %t69)
  %t70 = load ptr, ptr %s6
  %t71 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t72 = load i64, ptr %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t70, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l31, !tbaa !27
  call void @__olang_sb_done(ptr %s6)
  %t76 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t76, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 1, ptr @.d74 }, ptr %l32, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t77, ptr %l33, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t78, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c75)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t79 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  store i32 %t8, ptr %l7, !tbaa !23
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i32, ptr %l7, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  store ptr %l8, ptr %l9, !tbaa !29
  store i32 19, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t12, ptr %t13)
  store i1 %t14, ptr %l12
  br label %bb3
bb3:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  store i32 %t17, ptr %l15, !tbaa !23
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t20, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t21 = load i32, ptr %l16, !tbaa !23
  %t22 = icmp eq i32 %t21, 0
  store i1 %t22, ptr %l17, !tbaa !21
  %t23 = load i1, ptr %l17, !tbaa !21
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l13, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i32
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i32
  %l34 = alloca i1
  %l35 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i32
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i32
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l79 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca i32
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t3, i32 %t4)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l7
  %t9 = load i32, ptr %l7
  store i32 %t9, ptr %l3
  %t10 = load i32, ptr %l3
  store i32 %t10, ptr %l9
  %t11 = load i32, ptr %l9
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %l10, !tbaa !21
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  %t15 = load i32, ptr %l3
  store i32 %t15, ptr %l11
  %t16 = load i32, ptr %l11
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t16, %t17
  store i1 %t18, ptr %l12, !tbaa !21
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  %t20 = load i32, ptr %l3
  store i32 %t20, ptr %l13
  %t21 = load i32, ptr %l13
  %t22 = trunc i64 3 to i32
  %t23 = icmp eq i32 %t21, %t22
  store i1 %t23, ptr %l14, !tbaa !21
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb30
bb7:
  %t25 = load i32, ptr %l3
  store i32 %t25, ptr %l15
  %t26 = load i32, ptr %l15
  %t27 = trunc i64 4 to i32
  %t28 = icmp eq i32 %t26, %t27
  store i1 %t28, ptr %l16, !tbaa !21
  %t29 = load i1, ptr %l16, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb30
bb9:
  %t30 = load i32, ptr %l3
  store i32 %t30, ptr %l17
  %t31 = load i32, ptr %l17
  %t32 = trunc i64 5 to i32
  %t33 = icmp eq i32 %t31, %t32
  store i1 %t33, ptr %l18, !tbaa !21
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb30
bb11:
  %t35 = load i32, ptr %l3
  store i32 %t35, ptr %l19
  %t36 = load i32, ptr %l19
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t36, %t37
  store i1 %t38, ptr %l20, !tbaa !21
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %bb30
bb13:
  %t40 = load i32, ptr %l3
  store i32 %t40, ptr %l21
  %t41 = load i32, ptr %l21
  %t42 = trunc i64 7 to i32
  %t43 = icmp eq i32 %t41, %t42
  store i1 %t43, ptr %l22, !tbaa !21
  %t44 = load i1, ptr %l22, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  br label %bb30
bb15:
  %t45 = load i32, ptr %l3
  store i32 %t45, ptr %l23
  %t46 = load i32, ptr %l23
  %t47 = trunc i64 8 to i32
  %t48 = icmp eq i32 %t46, %t47
  store i1 %t48, ptr %l24, !tbaa !21
  %t49 = load i1, ptr %l24, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  br label %bb30
bb17:
  %t50 = load i32, ptr %l3
  store i32 %t50, ptr %l25
  %t51 = load i32, ptr %l25
  %t52 = trunc i64 9 to i32
  %t53 = icmp eq i32 %t51, %t52
  store i1 %t53, ptr %l26, !tbaa !21
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb18, label %bb19
bb18:
  br label %bb30
bb19:
  %t55 = load i32, ptr %l3
  store i32 %t55, ptr %l27
  %t56 = load i32, ptr %l27
  %t57 = trunc i64 10 to i32
  %t58 = icmp eq i32 %t56, %t57
  store i1 %t58, ptr %l28, !tbaa !21
  %t59 = load i1, ptr %l28, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  br label %bb30
bb21:
  %t60 = load i32, ptr %l3
  store i32 %t60, ptr %l29
  %t61 = load i32, ptr %l29
  %t62 = trunc i64 11 to i32
  %t63 = icmp eq i32 %t61, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  %t64 = load i1, ptr %l30, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  %t65 = load i32, ptr %l3
  store i32 %t65, ptr %l31
  %t66 = load i32, ptr %l31
  %t67 = trunc i64 12 to i32
  %t68 = icmp eq i32 %t66, %t67
  store i1 %t68, ptr %l32, !tbaa !21
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  %t70 = load i32, ptr %l3
  store i32 %t70, ptr %l33
  %t71 = load i32, ptr %l33
  %t72 = trunc i64 13 to i32
  %t73 = icmp eq i32 %t71, %t72
  store i1 %t73, ptr %l34, !tbaa !21
  %t74 = load i1, ptr %l34, !tbaa !21
  br i1 %t74, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t75 = load i32, ptr %l3
  store i32 %t75, ptr %l35
  %t76 = load i32, ptr %l35
  %t77 = trunc i64 14 to i32
  %t78 = icmp eq i32 %t76, %t77
  store i1 %t78, ptr %l36, !tbaa !21
  %t79 = load i1, ptr %l36, !tbaa !21
  br i1 %t79, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s1
  %t80 = load i32, ptr %l1, !tbaa !23
  store i32 %t80, ptr %l37, !tbaa !23
  %t81 = load i32, ptr %l37, !tbaa !23
  %t82 = sext i32 %t81 to i64
  store i64 %t82, ptr %l38, !tbaa !24
  %t83 = load i64, ptr %l38, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimLlvm, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %t85, i64 %t83
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !37
  store { i64, ptr } %t87, ptr %l39, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t88 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  call void @__olang_sb_put(ptr %s2, ptr %t89, i64 %t90)
  %t91 = load ptr, ptr %s2
  %t92 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t93 = load i64, ptr %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t91, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l40, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t97 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t97, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb80
bb31:
  %t98 = load i32, ptr %l3
  store i32 %t98, ptr %l41
  %t99 = load i32, ptr %l41
  %t100 = trunc i64 16 to i32
  %t101 = icmp eq i32 %t99, %t100
  store i1 %t101, ptr %l42, !tbaa !21
  %t102 = load i1, ptr %l42, !tbaa !21
  br i1 %t102, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 3, ptr @.d76 }, ptr %l43, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t103, ptr %l44, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t104, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb35:
  %t105 = load i32, ptr %l3
  store i32 %t105, ptr %l45
  %t106 = load i32, ptr %l45
  %t107 = trunc i64 17 to i32
  %t108 = icmp eq i32 %t106, %t107
  store i1 %t108, ptr %l46, !tbaa !21
  %t109 = load i1, ptr %l46, !tbaa !21
  br i1 %t109, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 4, ptr @.d77 }, ptr %l47, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t110, ptr %l48, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t111, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb80
bb39:
  %t112 = load i32, ptr %l3
  store i32 %t112, ptr %l49
  %t113 = load i32, ptr %l49
  %t114 = trunc i64 21 to i32
  %t115 = icmp eq i32 %t113, %t114
  store i1 %t115, ptr %l50, !tbaa !21
  %t116 = load i1, ptr %l50, !tbaa !21
  br i1 %t116, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 12, ptr @.d78 }, ptr %l51, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t117, ptr %l52, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t118, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb80
bb43:
  %t119 = load i32, ptr %l3
  store i32 %t119, ptr %l53
  %t120 = load i32, ptr %l53
  %t121 = trunc i64 20 to i32
  %t122 = icmp eq i32 %t120, %t121
  store i1 %t122, ptr %l54, !tbaa !21
  %t123 = load i1, ptr %l54, !tbaa !21
  br i1 %t123, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb52
bb46:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l55, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l56, !tbaa !29
  %t126 = load i32, ptr %l1, !tbaa !23
  store i32 %t126, ptr %l57, !tbaa !23
  %t127 = load ptr, ptr %l56, !tbaa !29
  %t128 = load i32, ptr %l57, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t129, ptr %l58
  br label %bb47
bb47:
  %t130 = load ptr, ptr %l55, !tbaa !29
  %t131 = load i32, ptr %l58, !tbaa !23
  %t132 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t130, i32 %t131)
  store i1 %t132, ptr %l59
  br label %bb48
bb48:
  %t133 = load i1, ptr %l59, !tbaa !21
  br i1 %t133, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 12, ptr @.d79 }, ptr %l61, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t134, ptr %l62, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t135, ptr %l60, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 3, ptr @.d80 }, ptr %l63, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t136, ptr %l64, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t137, ptr %l60, !tbaa !27
  br label %bb51
bb51:
  %t138 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t138, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb80
bb52:
  %t139 = load i32, ptr %l3
  store i32 %t139, ptr %l65
  %t140 = load i32, ptr %l65
  %t141 = trunc i64 19 to i32
  %t142 = icmp eq i32 %t140, %t141
  store i1 %t142, ptr %l66, !tbaa !21
  %t143 = load i1, ptr %l66, !tbaa !21
  br i1 %t143, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb57
bb55:
  store %olang.scope zeroinitializer, ptr %s7
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l67, !tbaa !29
  %t145 = load i32, ptr %l1, !tbaa !23
  store i32 %t145, ptr %l68, !tbaa !23
  %t146 = load ptr, ptr %l67, !tbaa !29
  %t147 = load i32, ptr %l68, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %t146, i32 %t147)
  store { i64, ptr } %t148, ptr %l69
  br label %bb56
bb56:
  %t149 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t149, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb57:
  %t150 = load i32, ptr %l3
  store i32 %t150, ptr %l70
  %t151 = load i32, ptr %l70
  %t152 = trunc i64 22 to i32
  %t153 = icmp eq i32 %t151, %t152
  store i1 %t153, ptr %l71, !tbaa !21
  %t154 = load i1, ptr %l71, !tbaa !21
  br i1 %t154, label %bb58, label %bb59
bb58:
  br label %bb62
bb59:
  %t155 = load i32, ptr %l3
  store i32 %t155, ptr %l72
  %t156 = load i32, ptr %l72
  %t157 = trunc i64 23 to i32
  %t158 = icmp eq i32 %t156, %t157
  store i1 %t158, ptr %l73, !tbaa !21
  %t159 = load i1, ptr %l73, !tbaa !21
  br i1 %t159, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s8
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l74, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l75, !tbaa !29
  %t162 = load i32, ptr %l1, !tbaa !23
  store i32 %t162, ptr %l76, !tbaa !23
  %t163 = load ptr, ptr %l75, !tbaa !29
  %t164 = load i32, ptr %l76, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t165, ptr %l77
  br label %bb63
bb63:
  %t166 = load ptr, ptr %l74, !tbaa !29
  %t167 = load i32, ptr %l77, !tbaa !23
  %t168 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %t166, i32 %t167)
  store { i64, ptr } %t168, ptr %l78
  br label %bb64
bb64:
  %t169 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t169, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb80
bb65:
  %t170 = load i32, ptr %l3
  store i32 %t170, ptr %l79
  %t171 = load i32, ptr %l79
  %t172 = trunc i64 24 to i32
  %t173 = icmp eq i32 %t171, %t172
  store i1 %t173, ptr %l80, !tbaa !21
  %t174 = load i1, ptr %l80, !tbaa !21
  br i1 %t174, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb70
bb68:
  store %olang.scope zeroinitializer, ptr %s9
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l81, !tbaa !29
  %t176 = load i32, ptr %l1, !tbaa !23
  store i32 %t176, ptr %l82, !tbaa !23
  %t177 = load ptr, ptr %l81, !tbaa !29
  %t178 = load i32, ptr %l82, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t177, i32 %t178)
  store { i64, ptr } %t179, ptr %l83
  br label %bb69
bb69:
  %t180 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t180, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb80
bb70:
  %t181 = load i32, ptr %l3
  store i32 %t181, ptr %l84
  %t182 = load i32, ptr %l84
  %t183 = trunc i64 18 to i32
  %t184 = icmp eq i32 %t182, %t183
  store i1 %t184, ptr %l85, !tbaa !21
  %t185 = load i1, ptr %l85, !tbaa !21
  br i1 %t185, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb75
bb73:
  store %olang.scope zeroinitializer, ptr %s10
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l86, !tbaa !29
  %t187 = load i32, ptr %l1, !tbaa !23
  store i32 %t187, ptr %l87, !tbaa !23
  %t188 = load ptr, ptr %l86, !tbaa !29
  %t189 = load i32, ptr %l87, !tbaa !23
  %t190 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %t188, i32 %t189)
  store { i64, ptr } %t190, ptr %l88
  br label %bb74
bb74:
  %t191 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t191, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb80
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s11
  store { i64, ptr } { i64 1, ptr @.d81 }, ptr %l89, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t192, ptr %l90, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t193, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb80:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t194, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i32
  %l58 = alloca i1
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i32
  %l63 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l12, !tbaa !23
  %t3 = load ptr, ptr %l11, !tbaa !29
  %t4 = load i32, ptr %l12, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t3, i32 %t4)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l14, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  store i1 %t11, ptr %l16, !tbaa !21
  %t12 = load i1, ptr %l16, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sle i64 %t13, 2305843009213693951
  store i1 %t14, ptr %l17, !tbaa !21
  %t15 = load i1, ptr %l17, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c83)
  unreachable
bb4:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = mul i64 %t16, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l18, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  store i1 true, ptr %l4, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l19, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l20, !tbaa !24
  %t25 = load i64, ptr %l20, !tbaa !24
  store i64 %t25, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  store i64 %t26, ptr %l21, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  store i64 %t27, ptr %l22, !tbaa !24
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = load i64, ptr %l22, !tbaa !24
  %t30 = icmp sgt i64 %t28, %t29
  store i1 %t30, ptr %l23, !tbaa !21
  %t31 = load i1, ptr %l23, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c83)
  unreachable
bb6:
  %t32 = load i64, ptr %l7, !tbaa !24
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = icmp sgt i64 %t33, 0
  store i1 %t34, ptr %l26, !tbaa !21
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  store i64 %t36, ptr %l28, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  store i64 %t37, ptr %l29, !tbaa !24
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = sub i64 %t38, %t39
  store i64 %t40, ptr %l30, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  store i64 %t41, ptr %l31, !tbaa !24
  %t42 = load i64, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l31, !tbaa !24
  %t44 = add i64 %t42, %t43
  store i64 %t44, ptr %l32, !tbaa !24
  %t45 = load i64, ptr %l32, !tbaa !24
  %t46 = sub i64 %t45, 1
  store i64 %t46, ptr %l33, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  store i64 %t47, ptr %l34, !tbaa !24
  %t48 = load i64, ptr %l33, !tbaa !24
  %t49 = load i64, ptr %l34, !tbaa !24
  %t50 = sdiv i64 %t48, %t49
  store i64 %t50, ptr %l35, !tbaa !24
  %t51 = load i64, ptr %l35, !tbaa !24
  store i64 %t51, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l27, !tbaa !24
  store i64 %t52, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l24, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load i64, ptr %l9, !tbaa !24
  store i64 %t54, ptr %l36, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  store i64 %t55, ptr %l37, !tbaa !24
  %t56 = load i64, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l37, !tbaa !24
  %t58 = icmp slt i64 %t56, %t57
  store i1 %t58, ptr %l38, !tbaa !21
  %t59 = load i1, ptr %l38, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l39, !tbaa !21
  %t61 = load i1, ptr %l39, !tbaa !21
  br i1 %t61, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %l40, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = load i64, ptr %l42, !tbaa !24
  %t67 = mul i64 %t65, %t66
  store i64 %t67, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = load i64, ptr %l43, !tbaa !24
  %t70 = add i64 %t68, %t69
  store i64 %t70, ptr %l44, !tbaa !24
  %t71 = load i64, ptr %l44, !tbaa !24
  store i64 %t71, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l45, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l46, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t74, ptr %l47, !tbaa !27
  %t75 = load i64, ptr %l10, !tbaa !24
  store i64 %t75, ptr %l48, !tbaa !24
  %t76 = load i64, ptr %l48, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t76
  %t80 = load i32, ptr %t79, !tbaa !33
  store i32 %t80, ptr %l49, !tbaa !23
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t82 = load i32, ptr %l49, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t83, ptr %l50
  br label %bb16
bb16:
  %t84 = load i32, ptr %l50, !tbaa !23
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i32, ptr %t87, i64 %t85
  store i32 %t84, ptr %t88, !tbaa !33
  %t89 = load i1, ptr %l4, !tbaa !21
  store i1 %t89, ptr %l51, !tbaa !21
  %t90 = load i1, ptr %l51, !tbaa !21
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t91 = load i64, ptr %l10, !tbaa !24
  store i64 %t91, ptr %l53, !tbaa !24
  %t92 = load i64, ptr %l53, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t92
  %t96 = load i32, ptr %t95, !tbaa !33
  store i32 %t96, ptr %l54, !tbaa !23
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = load i64, ptr %l10, !tbaa !24
  store i64 %t98, ptr %l56, !tbaa !24
  %t99 = load i64, ptr %l56, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t99
  %t103 = load i32, ptr %t102, !tbaa !33
  store i32 %t103, ptr %l57, !tbaa !23
  %t104 = load i32, ptr %l54, !tbaa !23
  %t105 = load i32, ptr %l57, !tbaa !23
  %t106 = icmp eq i32 %t104, %t105
  store i1 %t106, ptr %l58, !tbaa !21
  %t107 = load i1, ptr %l58, !tbaa !21
  store i1 %t107, ptr %l52, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb19
bb19:
  %t108 = load i1, ptr %l52, !tbaa !21
  store i1 %t108, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t109 = load i64, ptr %l9, !tbaa !24
  store i64 %t109, ptr %l59, !tbaa !24
  %t110 = load i64, ptr %l59, !tbaa !24
  %t111 = add i64 %t110, 1
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load i64, ptr %l60, !tbaa !24
  store i64 %t112, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb21:
  call void @__olang_scope_close(ptr %s1)
  %t113 = load i1, ptr %l4, !tbaa !21
  store i1 %t113, ptr %l61, !tbaa !21
  %t114 = load i1, ptr %l61, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t115 = load i32, ptr %l1, !tbaa !23
  store i32 %t115, ptr %l63, !tbaa !23
  %t116 = load i32, ptr %l63, !tbaa !23
  store i32 %t116, ptr %l62, !tbaa !23
  br label %bb25
bb23:
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l64, !tbaa !29
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t118, ptr %l65, !tbaa !27
  %t119 = load ptr, ptr %l64, !tbaa !29
  %t120 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t119, { i64, ptr } %t120)
  store i32 %t121, ptr %l66
  br label %bb24
bb24:
  %t122 = load i32, ptr %l66, !tbaa !23
  store i32 %t122, ptr %l62, !tbaa !23
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i32, ptr %l62, !tbaa !23
  store i32 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i8
  %l18 = alloca i64
  %l19 = alloca i8
  %l20 = alloca i8
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i8
  %l27 = alloca i8
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -3750763034362895579, ptr %l1, !tbaa !65
  store i64 7809847782465536322, ptr %l2, !tbaa !65
  store i64 1099511628211, ptr %l3, !tbaa !65
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l8, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t2, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t3, ptr %l9, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l12, !tbaa !24
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l13, !tbaa !21
  %t12 = load i1, ptr %l13, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l14, !tbaa !21
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  store i64 %t16, ptr %l16, !tbaa !24
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t17
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l17, !tbaa !22
  %t22 = load i8, ptr %l17, !tbaa !22
  store i8 %t22, ptr %l7, !tbaa !22
  %t23 = load i64, ptr %l1, !tbaa !65
  store i64 %t23, ptr %l18, !tbaa !65
  %t24 = load i8, ptr %l7, !tbaa !22
  store i8 %t24, ptr %l19, !tbaa !22
  %t25 = load i8, ptr %l19, !tbaa !22
  store i8 %t25, ptr %l20, !tbaa !22
  %t26 = load i8, ptr %l20, !tbaa !22
  %t27 = zext i8 %t26 to i64
  store i64 %t27, ptr %l21, !tbaa !65
  %t28 = load i64, ptr %l18, !tbaa !65
  %t29 = load i64, ptr %l21, !tbaa !65
  %t30 = xor i64 %t28, %t29
  store i64 %t30, ptr %l22, !tbaa !65
  %t31 = load i64, ptr %l3, !tbaa !65
  store i64 %t31, ptr %l23, !tbaa !65
  %t32 = load i64, ptr %l22, !tbaa !65
  %t33 = load i64, ptr %l23, !tbaa !65
  %t34 = mul i64 %t32, %t33
  store i64 %t34, ptr %l24, !tbaa !65
  %t35 = load i64, ptr %l24, !tbaa !65
  store i64 %t35, ptr %l1, !tbaa !65
  %t36 = load i64, ptr %l2, !tbaa !65
  store i64 %t36, ptr %l25, !tbaa !65
  %t37 = load i8, ptr %l7, !tbaa !22
  store i8 %t37, ptr %l26, !tbaa !22
  %t38 = load i8, ptr %l26, !tbaa !22
  store i8 %t38, ptr %l27, !tbaa !22
  %t39 = load i8, ptr %l27, !tbaa !22
  %t40 = zext i8 %t39 to i64
  store i64 %t40, ptr %l28, !tbaa !65
  %t41 = load i64, ptr %l25, !tbaa !65
  %t42 = load i64, ptr %l28, !tbaa !65
  %t43 = xor i64 %t41, %t42
  store i64 %t43, ptr %l29, !tbaa !65
  %t44 = load i64, ptr %l3, !tbaa !65
  store i64 %t44, ptr %l30, !tbaa !65
  %t45 = load i64, ptr %l29, !tbaa !65
  %t46 = load i64, ptr %l30, !tbaa !65
  %t47 = mul i64 %t45, %t46
  store i64 %t47, ptr %l31, !tbaa !65
  %t48 = load i64, ptr %l31, !tbaa !65
  store i64 %t48, ptr %l2, !tbaa !65
  %t49 = load i64, ptr %l2, !tbaa !65
  store i64 %t49, ptr %l32, !tbaa !65
  %t50 = load i64, ptr %l2, !tbaa !65
  store i64 %t50, ptr %l33, !tbaa !65
  %t51 = load i64, ptr %l33, !tbaa !65
  %t52 = lshr i64 %t51, 29
  store i64 %t52, ptr %l34, !tbaa !65
  %t53 = load i64, ptr %l32, !tbaa !65
  %t54 = load i64, ptr %l34, !tbaa !65
  %t55 = xor i64 %t53, %t54
  store i64 %t55, ptr %l35, !tbaa !65
  %t56 = load i64, ptr %l35, !tbaa !65
  store i64 %t56, ptr %l2, !tbaa !65
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load i64, ptr %l5, !tbaa !24
  store i64 %t57, ptr %l36, !tbaa !24
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = add i64 %t58, 1
  store i64 %t59, ptr %l37, !tbaa !24
  %t60 = load i64, ptr %l37, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb1
bb6:
  call void @__olang_scope_close(ptr %s1)
  %t61 = load i64, ptr %l1, !tbaa !65
  store i64 %t61, ptr %l38, !tbaa !65
  %t62 = load i64, ptr %l2, !tbaa !65
  store i64 %t62, ptr %l39, !tbaa !65
  %t63 = load i64, ptr %l38, !tbaa !65
  %t64 = insertvalue { i64, i64 } undef, i64 %t63, 0
  %t65 = load i64, ptr %l39, !tbaa !65
  %t66 = insertvalue { i64, i64 } %t64, i64 %t65, 1
  store { i64, i64 } %t66, ptr %l40
  call void @__olang_scope_close(ptr %s0)
  %t67 = load { i64, i64 }, ptr %l40
  store { i64, i64 } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex16(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !65
  store i64 %t1, ptr %l1, !tbaa !65
  %t2 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t3 = extractvalue { i32, i64 } %t2, 1
  %t4 = extractvalue { i32, i64 } %t2, 0
  store i32 %t4, ptr %l3
  %t5 = icmp ne i32 %t4, 0
  br i1 %t5, label %bb2, label %ok.6
ok.6:
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  %t7 = load i64, ptr %l1, !tbaa !65
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t7, i64 %t8)
  store { i64, ptr } %t9, ptr %l4
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c84)
  unreachable
bb3:
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t17, i64 16, i8 48)
  store { i64, ptr } %t18, ptr %l6
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex2(ptr %v0, i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = zext i8 %t2 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c85)
  unreachable
bb3:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l6, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t20 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t19, i64 2, i8 48)
  store { i64, ptr } %t20, ptr %l7
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eprimBits_2einit() #0 {
entry:
  %l0 = alloca [15 x i64]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [15 x i64] undef, i64 0, 0
  %t2 = insertvalue [15 x i64] %t1, i64 0, 1
  %t3 = insertvalue [15 x i64] %t2, i64 1, 2
  %t4 = insertvalue [15 x i64] %t3, i64 8, 3
  %t5 = insertvalue [15 x i64] %t4, i64 16, 4
  %t6 = insertvalue [15 x i64] %t5, i64 32, 5
  %t7 = insertvalue [15 x i64] %t6, i64 64, 6
  %t8 = insertvalue [15 x i64] %t7, i64 8, 7
  %t9 = insertvalue [15 x i64] %t8, i64 16, 8
  %t10 = insertvalue [15 x i64] %t9, i64 32, 9
  %t11 = insertvalue [15 x i64] %t10, i64 64, 10
  %t12 = insertvalue [15 x i64] %t11, i64 16, 11
  %t13 = insertvalue [15 x i64] %t12, i64 16, 12
  %t14 = insertvalue [15 x i64] %t13, i64 32, 13
  %t15 = insertvalue [15 x i64] %t14, i64 64, 14
  store [15 x i64] %t15, ptr %l0
  %t16 = load [15 x i64], ptr %l0
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call ptr @__olang_scope_alloc(ptr %t17, i64 120)
  store [15 x i64] %t16, ptr %t18
  %t19 = insertvalue { i64, ptr } undef, i64 15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  %t21 = load { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimBits, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp eq i64 %t25, %t26
  store i1 %t27, ptr %l4, !tbaa !21
  %t28 = load i1, ptr %l4, !tbaa !21
  br i1 %t28, label %bb1, label %bb2
bb1:
  %t29 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimBits, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  br label %bb3
bb2:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr @G_2ecompiler_2ftypes_2eprimBits, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eprimLlvm_2einit() #0 {
entry:
  %l0 = alloca [15 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [15 x { i64, ptr }] undef, { i64, ptr } { i64 0, ptr @.d86 }, 0
  %t2 = insertvalue [15 x { i64, ptr }] %t1, { i64, ptr } { i64 4, ptr @.d87 }, 1
  %t3 = insertvalue [15 x { i64, ptr }] %t2, { i64, ptr } { i64 2, ptr @.d88 }, 2
  %t4 = insertvalue [15 x { i64, ptr }] %t3, { i64, ptr } { i64 2, ptr @.d89 }, 3
  %t5 = insertvalue [15 x { i64, ptr }] %t4, { i64, ptr } { i64 3, ptr @.d90 }, 4
  %t6 = insertvalue [15 x { i64, ptr }] %t5, { i64, ptr } { i64 3, ptr @.d91 }, 5
  %t7 = insertvalue [15 x { i64, ptr }] %t6, { i64, ptr } { i64 3, ptr @.d92 }, 6
  %t8 = insertvalue [15 x { i64, ptr }] %t7, { i64, ptr } { i64 2, ptr @.d93 }, 7
  %t9 = insertvalue [15 x { i64, ptr }] %t8, { i64, ptr } { i64 3, ptr @.d94 }, 8
  %t10 = insertvalue [15 x { i64, ptr }] %t9, { i64, ptr } { i64 3, ptr @.d95 }, 9
  %t11 = insertvalue [15 x { i64, ptr }] %t10, { i64, ptr } { i64 3, ptr @.d96 }, 10
  %t12 = insertvalue [15 x { i64, ptr }] %t11, { i64, ptr } { i64 4, ptr @.d97 }, 11
  %t13 = insertvalue [15 x { i64, ptr }] %t12, { i64, ptr } { i64 6, ptr @.d98 }, 12
  %t14 = insertvalue [15 x { i64, ptr }] %t13, { i64, ptr } { i64 5, ptr @.d99 }, 13
  %t15 = insertvalue [15 x { i64, ptr }] %t14, { i64, ptr } { i64 6, ptr @.d100 }, 14
  store [15 x { i64, ptr }] %t15, ptr %l0
  %t16 = load [15 x { i64, ptr }], ptr %l0
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call ptr @__olang_scope_alloc(ptr %t17, i64 240)
  store [15 x { i64, ptr }] %t16, ptr %t18
  %t19 = insertvalue { i64, ptr } undef, i64 15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  %t21 = load { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimLlvm, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp eq i64 %t25, %t26
  store i1 %t27, ptr %l4, !tbaa !21
  %t28 = load i1, ptr %l4, !tbaa !21
  br i1 %t28, label %bb1, label %bb2
bb1:
  %t29 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimLlvm, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = mul i64 %t33, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  br label %bb3
bb2:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr @G_2ecompiler_2ftypes_2eprimLlvm, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eprimNames_2einit() #0 {
entry:
  %l0 = alloca [15 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [15 x { i64, ptr }] undef, { i64, ptr } { i64 0, ptr @.d101 }, 0
  %t2 = insertvalue [15 x { i64, ptr }] %t1, { i64, ptr } { i64 0, ptr @.d102 }, 1
  %t3 = insertvalue [15 x { i64, ptr }] %t2, { i64, ptr } { i64 4, ptr @.d103 }, 2
  %t4 = insertvalue [15 x { i64, ptr }] %t3, { i64, ptr } { i64 2, ptr @.d104 }, 3
  %t5 = insertvalue [15 x { i64, ptr }] %t4, { i64, ptr } { i64 3, ptr @.d105 }, 4
  %t6 = insertvalue [15 x { i64, ptr }] %t5, { i64, ptr } { i64 3, ptr @.d106 }, 5
  %t7 = insertvalue [15 x { i64, ptr }] %t6, { i64, ptr } { i64 3, ptr @.d107 }, 6
  %t8 = insertvalue [15 x { i64, ptr }] %t7, { i64, ptr } { i64 2, ptr @.d108 }, 7
  %t9 = insertvalue [15 x { i64, ptr }] %t8, { i64, ptr } { i64 3, ptr @.d109 }, 8
  %t10 = insertvalue [15 x { i64, ptr }] %t9, { i64, ptr } { i64 3, ptr @.d110 }, 9
  %t11 = insertvalue [15 x { i64, ptr }] %t10, { i64, ptr } { i64 3, ptr @.d111 }, 10
  %t12 = insertvalue [15 x { i64, ptr }] %t11, { i64, ptr } { i64 3, ptr @.d112 }, 11
  %t13 = insertvalue [15 x { i64, ptr }] %t12, { i64, ptr } { i64 4, ptr @.d113 }, 12
  %t14 = insertvalue [15 x { i64, ptr }] %t13, { i64, ptr } { i64 3, ptr @.d114 }, 13
  %t15 = insertvalue [15 x { i64, ptr }] %t14, { i64, ptr } { i64 3, ptr @.d115 }, 14
  store [15 x { i64, ptr }] %t15, ptr %l0
  %t16 = load [15 x { i64, ptr }], ptr %l0
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call ptr @__olang_scope_alloc(ptr %t17, i64 240)
  store [15 x { i64, ptr }] %t16, ptr %t18
  %t19 = insertvalue { i64, ptr } undef, i64 15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  %t21 = load { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimNames, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp eq i64 %t25, %t26
  store i1 %t27, ptr %l4, !tbaa !21
  %t28 = load i1, ptr %l4, !tbaa !21
  br i1 %t28, label %bb1, label %bb2
bb1:
  %t29 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2ftypes_2eprimNames, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = mul i64 %t33, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  br label %bb3
bb2:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr @G_2ecompiler_2ftypes_2eprimNames, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_3aTable_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List<compiler/types:data>"
  %l3 = alloca %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>"
  %l4 = alloca %"std/prelude/list:List<I32>"
  %l5 = alloca %"std/prelude/list:List<Array<compiler/types:TypeId>&>"
  %l6 = alloca %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>"
  %l7 = alloca %"std/prelude/list:List<Array<compiler/source:NameId>&>"
  %l8 = alloca %"std/prelude/list:List<compiler/types:ListId>"
  %l9 = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  %l10 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l11 = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  %l12 = alloca %"std/prelude/list:List<compiler/types:decl>"
  %l13 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l14 = alloca %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>"
  %l15 = alloca %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>"
  %l16 = alloca %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>"
  %l17 = alloca %"std/prelude/list:List<I64>"
  %l18 = alloca %"std/prelude/list:List<I64>"
  %l19 = alloca %"std/prelude/list:List<I64>"
  %l20 = alloca %"std/prelude/list:List<I64>"
  %l21 = alloca %"std/prelude/list:List<I64>"
  %l22 = alloca %"std/prelude/list:List<I64>"
  %l23 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l24 = alloca %"std/prelude/list:List<compiler/types:TypeId>"
  %l25 = alloca %"std/prelude/list:List<Array<I64>&>"
  %l26 = alloca %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>"
  %l27 = alloca %"std/prelude/list:List<Array<I64>&>"
  %l28 = alloca %"std/prelude/map:Map<Array<I64>&, I64>"
  %l29 = alloca %"std/prelude/map:Map<compiler/types:TypeId, I64>"
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca %"std/prelude/list:List<compiler/types:data>"
  %l33 = alloca %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>"
  %l34 = alloca %"std/prelude/list:List<I32>"
  %l35 = alloca %"std/prelude/list:List<Array<compiler/types:TypeId>&>"
  %l36 = alloca %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>"
  %l37 = alloca %"std/prelude/list:List<Array<compiler/source:NameId>&>"
  %l38 = alloca %"std/prelude/list:List<compiler/types:ListId>"
  %l39 = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  %l40 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l41 = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  %l42 = alloca %"std/prelude/list:List<compiler/types:decl>"
  %l43 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l44 = alloca %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>"
  %l45 = alloca %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>"
  %l46 = alloca %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>"
  %l47 = alloca %"std/prelude/list:List<I64>"
  %l48 = alloca %"std/prelude/list:List<I64>"
  %l49 = alloca %"std/prelude/list:List<I64>"
  %l50 = alloca %"std/prelude/list:List<I64>"
  %l51 = alloca %"std/prelude/list:List<I64>"
  %l52 = alloca %"std/prelude/list:List<I64>"
  %l53 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l54 = alloca %"std/prelude/list:List<compiler/types:TypeId>"
  %l55 = alloca %"std/prelude/list:List<Array<I64>&>"
  %l56 = alloca %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>"
  %l57 = alloca %"std/prelude/list:List<Array<I64>&>"
  %l58 = alloca %"std/prelude/map:Map<Array<I64>&, I64>"
  %l59 = alloca %"std/prelude/map:Map<compiler/types:TypeId, I64>"
  %l60 = alloca %"compiler/types:Table"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l31, !tbaa !29
  %t2 = load ptr, ptr %l31, !tbaa !29
  store ptr %t2, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List<compiler/types:data>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e(ptr %t3)
  store %"std/prelude/list:List<compiler/types:data>" %t4, ptr %l32
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List<compiler/types:data>", ptr %l32
  store %"std/prelude/list:List<compiler/types:data>" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %t6)
  store %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" %t7, ptr %l33
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>", ptr %l33
  store %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" %t8, ptr %l3
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List<I32>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %t9)
  store %"std/prelude/list:List<I32>" %t10, ptr %l34
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List<I32>", ptr %l34
  store %"std/prelude/list:List<I32>" %t11, ptr %l4
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List<Array<compiler/types:TypeId>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e(ptr %t12)
  store %"std/prelude/list:List<Array<compiler/types:TypeId>&>" %t13, ptr %l35
  br label %bb4
bb4:
  %t14 = load %"std/prelude/list:List<Array<compiler/types:TypeId>&>", ptr %l35
  store %"std/prelude/list:List<Array<compiler/types:TypeId>&>" %t14, ptr %l5
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeI_He375cb5a1de17a5d01c6b8903f9691e1(ptr %t15)
  store %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" %t16, ptr %l36
  br label %bb5
bb5:
  %t17 = load %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>", ptr %l36
  store %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" %t17, ptr %l6
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List<Array<compiler/source:NameId>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %t18)
  store %"std/prelude/list:List<Array<compiler/source:NameId>&>" %t19, ptr %l37
  br label %bb6
bb6:
  %t20 = load %"std/prelude/list:List<Array<compiler/source:NameId>&>", ptr %l37
  store %"std/prelude/list:List<Array<compiler/source:NameId>&>" %t20, ptr %l7
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/list:List<compiler/types:ListId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e(ptr %t21)
  store %"std/prelude/list:List<compiler/types:ListId>" %t22, ptr %l38
  br label %bb7
bb7:
  %t23 = load %"std/prelude/list:List<compiler/types:ListId>", ptr %l38
  store %"std/prelude/list:List<compiler/types:ListId>" %t23, ptr %l8
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/map:Map<std/prelude/text:String&, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t24)
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t25, ptr %l39
  br label %bb8
bb8:
  %t26 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %l39
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t26, ptr %l9
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t27)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t28, ptr %l40
  br label %bb9
bb9:
  %t29 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l40
  store %"std/prelude/list:List<std/prelude/text:String&>" %t29, ptr %l10
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/map:Map<std/prelude/text:String&, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t30)
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t31, ptr %l41
  br label %bb10
bb10:
  %t32 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %l41
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t32, ptr %l11
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List<compiler/types:decl>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e(ptr %t33)
  store %"std/prelude/list:List<compiler/types:decl>" %t34, ptr %l42
  br label %bb11
bb11:
  %t35 = load %"std/prelude/list:List<compiler/types:decl>", ptr %l42
  store %"std/prelude/list:List<compiler/types:decl>" %t35, ptr %l12
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t36)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t37, ptr %l43
  br label %bb12
bb12:
  %t38 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l43
  store %"std/prelude/list:List<std/prelude/text:String&>" %t38, ptr %l13
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He0d7a5bfd18ae956abf945564c24098c(ptr %t39)
  store %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" %t40, ptr %l44
  br label %bb13
bb13:
  %t41 = load %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>", ptr %l44
  store %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" %t41, ptr %l14
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %t42)
  store %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" %t43, ptr %l45
  br label %bb14
bb14:
  %t44 = load %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>", ptr %l45
  store %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" %t44, ptr %l15
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20A_Hcfba385079b3349cc13047539d410cc3(ptr %t45)
  store %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" %t46, ptr %l46
  br label %bb15
bb15:
  %t47 = load %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>", ptr %l46
  store %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" %t47, ptr %l16
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t48)
  store %"std/prelude/list:List<I64>" %t49, ptr %l47
  br label %bb16
bb16:
  %t50 = load %"std/prelude/list:List<I64>", ptr %l47
  store %"std/prelude/list:List<I64>" %t50, ptr %l17
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t51)
  store %"std/prelude/list:List<I64>" %t52, ptr %l48
  br label %bb17
bb17:
  %t53 = load %"std/prelude/list:List<I64>", ptr %l48
  store %"std/prelude/list:List<I64>" %t53, ptr %l18
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t54)
  store %"std/prelude/list:List<I64>" %t55, ptr %l49
  br label %bb18
bb18:
  %t56 = load %"std/prelude/list:List<I64>", ptr %l49
  store %"std/prelude/list:List<I64>" %t56, ptr %l19
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t57)
  store %"std/prelude/list:List<I64>" %t58, ptr %l50
  br label %bb19
bb19:
  %t59 = load %"std/prelude/list:List<I64>", ptr %l50
  store %"std/prelude/list:List<I64>" %t59, ptr %l20
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t60)
  store %"std/prelude/list:List<I64>" %t61, ptr %l51
  br label %bb20
bb20:
  %t62 = load %"std/prelude/list:List<I64>", ptr %l51
  store %"std/prelude/list:List<I64>" %t62, ptr %l21
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t63)
  store %"std/prelude/list:List<I64>" %t64, ptr %l52
  br label %bb21
bb21:
  %t65 = load %"std/prelude/list:List<I64>", ptr %l52
  store %"std/prelude/list:List<I64>" %t65, ptr %l22
  %t66 = load ptr, ptr @__olang_prog_scope
  %t67 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t66)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t67, ptr %l53
  br label %bb22
bb22:
  %t68 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l53
  store %"std/prelude/list:List<std/prelude/text:String&>" %t68, ptr %l23
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = call %"std/prelude/list:List<compiler/types:TypeId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t69)
  store %"std/prelude/list:List<compiler/types:TypeId>" %t70, ptr %l54
  br label %bb23
bb23:
  %t71 = load %"std/prelude/list:List<compiler/types:TypeId>", ptr %l54
  store %"std/prelude/list:List<compiler/types:TypeId>" %t71, ptr %l24
  %t72 = load ptr, ptr @__olang_prog_scope
  %t73 = call %"std/prelude/list:List<Array<I64>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t72)
  store %"std/prelude/list:List<Array<I64>&>" %t73, ptr %l55
  br label %bb24
bb24:
  %t74 = load %"std/prelude/list:List<Array<I64>&>", ptr %l55
  store %"std/prelude/list:List<Array<I64>&>" %t74, ptr %l25
  %t75 = load ptr, ptr @__olang_prog_scope
  %t76 = call %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %t75)
  store %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" %t76, ptr %l56
  br label %bb25
bb25:
  %t77 = load %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>", ptr %l56
  store %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" %t77, ptr %l26
  %t78 = load ptr, ptr @__olang_prog_scope
  %t79 = call %"std/prelude/list:List<Array<I64>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t78)
  store %"std/prelude/list:List<Array<I64>&>" %t79, ptr %l57
  br label %bb26
bb26:
  %t80 = load %"std/prelude/list:List<Array<I64>&>", ptr %l57
  store %"std/prelude/list:List<Array<I64>&>" %t80, ptr %l27
  %t81 = load ptr, ptr @__olang_prog_scope
  %t82 = call %"std/prelude/map:Map<Array<I64>&, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %t81)
  store %"std/prelude/map:Map<Array<I64>&, I64>" %t82, ptr %l58
  br label %bb27
bb27:
  %t83 = load %"std/prelude/map:Map<Array<I64>&, I64>", ptr %l58
  store %"std/prelude/map:Map<Array<I64>&, I64>" %t83, ptr %l28
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = call %"std/prelude/map:Map<compiler/types:TypeId, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t84)
  store %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t85, ptr %l59
  br label %bb28
bb28:
  %t86 = load %"std/prelude/map:Map<compiler/types:TypeId, I64>", ptr %l59
  store %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t86, ptr %l29
  store i1 false, ptr %l30, !tbaa !21
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = insertvalue %"compiler/types:Table" undef, ptr %t87, 0
  %t89 = load %"std/prelude/list:List<compiler/types:data>", ptr %l2
  %t90 = insertvalue %"compiler/types:Table" %t88, %"std/prelude/list:List<compiler/types:data>" %t89, 1
  %t91 = load %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>", ptr %l3
  %t92 = insertvalue %"compiler/types:Table" %t90, %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" %t91, 2
  %t93 = load %"std/prelude/list:List<I32>", ptr %l4
  %t94 = insertvalue %"compiler/types:Table" %t92, %"std/prelude/list:List<I32>" %t93, 3
  %t95 = load %"std/prelude/list:List<Array<compiler/types:TypeId>&>", ptr %l5
  %t96 = insertvalue %"compiler/types:Table" %t94, %"std/prelude/list:List<Array<compiler/types:TypeId>&>" %t95, 4
  %t97 = load %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>", ptr %l6
  %t98 = insertvalue %"compiler/types:Table" %t96, %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" %t97, 5
  %t99 = load %"std/prelude/list:List<Array<compiler/source:NameId>&>", ptr %l7
  %t100 = insertvalue %"compiler/types:Table" %t98, %"std/prelude/list:List<Array<compiler/source:NameId>&>" %t99, 6
  %t101 = load %"std/prelude/list:List<compiler/types:ListId>", ptr %l8
  %t102 = insertvalue %"compiler/types:Table" %t100, %"std/prelude/list:List<compiler/types:ListId>" %t101, 7
  %t103 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %l9
  %t104 = insertvalue %"compiler/types:Table" %t102, %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t103, 8
  %t105 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l10
  %t106 = insertvalue %"compiler/types:Table" %t104, %"std/prelude/list:List<std/prelude/text:String&>" %t105, 9
  %t107 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %l11
  %t108 = insertvalue %"compiler/types:Table" %t106, %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t107, 10
  %t109 = load %"std/prelude/list:List<compiler/types:decl>", ptr %l12
  %t110 = insertvalue %"compiler/types:Table" %t108, %"std/prelude/list:List<compiler/types:decl>" %t109, 11
  %t111 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l13
  %t112 = insertvalue %"compiler/types:Table" %t110, %"std/prelude/list:List<std/prelude/text:String&>" %t111, 12
  %t113 = load %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>", ptr %l14
  %t114 = insertvalue %"compiler/types:Table" %t112, %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" %t113, 13
  %t115 = load %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>", ptr %l15
  %t116 = insertvalue %"compiler/types:Table" %t114, %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" %t115, 14
  %t117 = load %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>", ptr %l16
  %t118 = insertvalue %"compiler/types:Table" %t116, %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" %t117, 15
  %t119 = load %"std/prelude/list:List<I64>", ptr %l17
  %t120 = insertvalue %"compiler/types:Table" %t118, %"std/prelude/list:List<I64>" %t119, 16
  %t121 = load %"std/prelude/list:List<I64>", ptr %l18
  %t122 = insertvalue %"compiler/types:Table" %t120, %"std/prelude/list:List<I64>" %t121, 17
  %t123 = load %"std/prelude/list:List<I64>", ptr %l19
  %t124 = insertvalue %"compiler/types:Table" %t122, %"std/prelude/list:List<I64>" %t123, 18
  %t125 = load %"std/prelude/list:List<I64>", ptr %l20
  %t126 = insertvalue %"compiler/types:Table" %t124, %"std/prelude/list:List<I64>" %t125, 19
  %t127 = load %"std/prelude/list:List<I64>", ptr %l21
  %t128 = insertvalue %"compiler/types:Table" %t126, %"std/prelude/list:List<I64>" %t127, 20
  %t129 = load %"std/prelude/list:List<I64>", ptr %l22
  %t130 = insertvalue %"compiler/types:Table" %t128, %"std/prelude/list:List<I64>" %t129, 21
  %t131 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l23
  %t132 = insertvalue %"compiler/types:Table" %t130, %"std/prelude/list:List<std/prelude/text:String&>" %t131, 22
  %t133 = load %"std/prelude/list:List<compiler/types:TypeId>", ptr %l24
  %t134 = insertvalue %"compiler/types:Table" %t132, %"std/prelude/list:List<compiler/types:TypeId>" %t133, 23
  %t135 = load %"std/prelude/list:List<Array<I64>&>", ptr %l25
  %t136 = insertvalue %"compiler/types:Table" %t134, %"std/prelude/list:List<Array<I64>&>" %t135, 24
  %t137 = load %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>", ptr %l26
  %t138 = insertvalue %"compiler/types:Table" %t136, %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" %t137, 25
  %t139 = load %"std/prelude/list:List<Array<I64>&>", ptr %l27
  %t140 = insertvalue %"compiler/types:Table" %t138, %"std/prelude/list:List<Array<I64>&>" %t139, 26
  %t141 = load %"std/prelude/map:Map<Array<I64>&, I64>", ptr %l28
  %t142 = insertvalue %"compiler/types:Table" %t140, %"std/prelude/map:Map<Array<I64>&, I64>" %t141, 27
  %t143 = load %"std/prelude/map:Map<compiler/types:TypeId, I64>", ptr %l29
  %t144 = insertvalue %"compiler/types:Table" %t142, %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t143, 28
  %t145 = load i1, ptr %l30, !tbaa !21
  %t146 = insertvalue %"compiler/types:Table" %t144, i1 %t145, 29
  store %"compiler/types:Table" %t146, ptr %l60
  call void @__olang_scope_close(ptr %s0)
  %t147 = load %"compiler/types:Table", ptr %l60
  store %"compiler/types:Table" %t147, ptr %out
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/types:body"
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l10, !tbaa !23
  %t2 = load i32, ptr %l10, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load i32, ptr %l1, !tbaa !23
  store i32 %t3, ptr %l11, !tbaa !23
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l12, !tbaa !23
  %t6 = load i32, ptr %l12, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load i1, ptr %l3, !tbaa !21
  store i1 %t7, ptr %l13, !tbaa !21
  %t8 = load i1, ptr %l13, !tbaa !21
  store i1 %t8, ptr %l8, !tbaa !21
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %l14, !tbaa !21
  %t10 = load i1, ptr %l14, !tbaa !21
  store i1 %t10, ptr %l9, !tbaa !21
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = insertvalue %"compiler/types:body" undef, i32 %t11, 0
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = insertvalue %"compiler/types:body" %t12, i32 %t13, 1
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = insertvalue %"compiler/types:body" %t14, i32 %t15, 2
  %t17 = load i1, ptr %l8, !tbaa !21
  %t18 = insertvalue %"compiler/types:body" %t16, i1 %t17, 3
  %t19 = load i1, ptr %l9, !tbaa !21
  %t20 = insertvalue %"compiler/types:body" %t18, i1 %t19, 4
  store %"compiler/types:body" %t20, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/types:body", ptr %l15
  store %"compiler/types:body" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:body", ptr %rv
  ret %"compiler/types:body" %rr
}

define dso_local %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/types:data"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/types:data"
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l12
  %t2 = load i32, ptr %l12
  store i32 %t2, ptr %l6
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l13, !tbaa !24
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l7, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l14, !tbaa !24
  %t6 = load i64, ptr %l14, !tbaa !24
  store i64 %t6, ptr %l8, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l15, !tbaa !24
  %t8 = load i64, ptr %l15, !tbaa !24
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l16, !tbaa !24
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %l17, !tbaa !24
  %t12 = load i64, ptr %l17, !tbaa !24
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load i32, ptr %l6
  %t14 = insertvalue %"compiler/types:data" undef, i32 %t13, 0
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = insertvalue %"compiler/types:data" %t14, i64 %t15, 1
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = insertvalue %"compiler/types:data" %t16, i64 %t17, 2
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = insertvalue %"compiler/types:data" %t18, i64 %t19, 3
  %t21 = load i64, ptr %l10, !tbaa !24
  %t22 = insertvalue %"compiler/types:data" %t20, i64 %t21, 4
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = insertvalue %"compiler/types:data" %t22, i64 %t23, 5
  store %"compiler/types:data" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/types:data", ptr %l18
  store %"compiler/types:data" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local %"compiler/types:decl" @compiler_2ftypes_3adecl_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca %"compiler/types:decl"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/types:decl"
  store i64 %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l10, !tbaa !24
  %t2 = load i64, ptr %l10, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i32, ptr %l1, !tbaa !23
  store i32 %t3, ptr %l11, !tbaa !23
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l12
  %t6 = load i32, ptr %l12
  store i32 %t6, ptr %l7
  %t7 = load i32, ptr %l3, !tbaa !23
  store i32 %t7, ptr %l13, !tbaa !23
  %t8 = load i32, ptr %l13, !tbaa !23
  store i32 %t8, ptr %l8, !tbaa !23
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l14, !tbaa !24
  %t10 = load i64, ptr %l14, !tbaa !24
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = insertvalue %"compiler/types:decl" undef, i64 %t11, 0
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = insertvalue %"compiler/types:decl" %t12, i32 %t13, 1
  %t15 = load i32, ptr %l7
  %t16 = insertvalue %"compiler/types:decl" %t14, i32 %t15, 2
  %t17 = load i32, ptr %l8, !tbaa !23
  %t18 = insertvalue %"compiler/types:decl" %t16, i32 %t17, 3
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = insertvalue %"compiler/types:decl" %t18, i64 %t19, 4
  store %"compiler/types:decl" %t20, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/types:decl", ptr %l15
  store %"compiler/types:decl" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:decl", ptr %rv
  ret %"compiler/types:decl" %rr
}

define dso_local void @olang_2einit_2ecompiler_2ftypes() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2ftypes_2eReadOnly_2einit()
  br label %bb1
bb1:
  call void @compiler_2ftypes_2eWritable_2einit()
  br label %bb2
bb2:
  call void @compiler_2ftypes_2eOwning_2einit()
  br label %bb3
bb3:
  call void @compiler_2ftypes_2eRoleFn_2einit()
  br label %bb4
bb4:
  call void @compiler_2ftypes_2eRoleCtor_2einit()
  br label %bb5
bb5:
  call void @compiler_2ftypes_2eRoleDtor_2einit()
  br label %bb6
bb6:
  call void @compiler_2ftypes_2eOwnScope_2einit()
  br label %bb7
bb7:
  call void @compiler_2ftypes_2eFromTypeVar_2einit()
  br label %bb8
bb8:
  call void @compiler_2ftypes_2eResultVar_2einit()
  br label %bb9
bb9:
  call void @compiler_2ftypes_2eClosingVar_2einit()
  br label %bb10
bb10:
  call void @compiler_2ftypes_2eNotLaidOut_2einit()
  br label %bb11
bb11:
  call void @compiler_2ftypes_2eLayingOut_2einit()
  br label %bb12
bb12:
  call void @compiler_2ftypes_2eLaidOut_2einit()
  br label %bb13
bb13:
  call void @compiler_2ftypes_2eNoLayout_2einit()
  br label %bb14
bb14:
  call void @compiler_2ftypes_2eUnknownT_2einit()
  br label %bb15
bb15:
  call void @compiler_2ftypes_2eVoidT_2einit()
  br label %bb16
bb16:
  call void @compiler_2ftypes_2eBoolT_2einit()
  br label %bb17
bb17:
  call void @compiler_2ftypes_2eNullT_2einit()
  br label %bb18
bb18:
  call void @compiler_2ftypes_2eDefaultErrT_2einit()
  br label %bb19
bb19:
  call void @compiler_2ftypes_2eNoreturnT_2einit()
  br label %bb20
bb20:
  call void @compiler_2ftypes_2eprimNames_2einit()
  br label %bb21
bb21:
  call void @compiler_2ftypes_2eprimLlvm_2einit()
  br label %bb22
bb22:
  call void @compiler_2ftypes_2eprimBits_2einit()
  br label %bb23
bb23:
  call void @compiler_2ftypes_2eBigAggregate_2einit()
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:186: array length out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.c1 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:187: array length out of range\0A\00"
@.c2 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:188: array length out of range\0A\00"
@.d3 = private constant [2 x i8] c"__"
@.c4 = private unnamed_addr constant [54 x i8] c"compiler/types.olang:1154: slice bounds out of range\0A\00"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d5 = private constant [2 x i8] c"_H"
declare void @__olang_sb_done(ptr)
@.c6 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:334: reached unreachable code\0A\00"
@.d7 = private constant [1 x i8] c":"
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.d8 = private constant [1 x i8] c","
@.d9 = private constant [1 x i8] c":"
@.c10 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:377: array length out of range\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c11 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:888: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c12 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:459: reached unreachable code\0A\00"
@.c13 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:833: reached unreachable code\0A\00"
@.c14 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:799: reached unreachable code\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<compiler/types:TypeId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/types:TypeId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/types:TypeId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/types:TypeId>" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/types:TypeId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/types:TypeId>", ptr %l0
  store %"std/prelude/list:List<compiler/types:TypeId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/types:TypeId>", ptr %rv
  ret %"std/prelude/list:List<compiler/types:TypeId>" %rr
}

@.c15 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:261: array length out of range\0A\00"
@.d16 = private constant [0 x i8] c""
@.c17 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:733: array length out of range\0A\00"
@.c18 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:307: array length out of range\0A\00"
@.c19 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:537: array length out of range\0A\00"
@.c20 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:519: array length out of range\0A\00"
@.c21 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:522: array length out of range\0A\00"
@.d22 = private constant [3 x i8] c"i32"
@.d23 = private constant [4 x i8] c"void"
@.d24 = private constant [3 x i8] c"i32"
@.d25 = private constant [7 x i8] c"{ i32, "
@.d26 = private constant [2 x i8] c" }"
define linkonce_odr %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<I64>", ptr %l0
  store %"std/prelude/list:List<I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<I64>", ptr %rv
  ret %"std/prelude/list:List<I64>" %rr
}

@.c27 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:488: array length out of range\0A\00"
@.c28 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:694: array length out of range\0A\00"
@.d29 = private constant [3 x i8] c"{ }"
@.d30 = private constant [2 x i8] c"{ "
@.d31 = private constant [2 x i8] c", "
@.d32 = private constant [2 x i8] c" }"
@.d33 = private constant [12 x i8] c"{ i64, ptr }"
@.d34 = private constant [1 x i8] c"["
@.d35 = private constant [3 x i8] c" x "
@.d36 = private constant [1 x i8] c"]"
@.d37 = private constant [1 x i8] c"?"
@.d38 = private constant [4 x i8] c"null"
@.d39 = private constant [7 x i8] c"default"
@.d40 = private constant [8 x i8] c"noreturn"
@.d41 = private constant [2 x i8] c".#"
declare i64 @__olang_fmt_u64(ptr, i64)
@.d42 = private constant [4 x i8] c"void"
@.d43 = private constant [2 x i8] c", "
@.d44 = private constant [6 x i8] c"Array<"
@.d45 = private constant [2 x i8] c", "
@.d46 = private constant [4 x i8] c"own "
@.d47 = private constant [4 x i8] c"mut "
@.d48 = private constant [3 x i8] c"fn("
@.d49 = private constant [2 x i8] c" ("
@.d50 = private constant [1 x i8] c" "
@.d51 = private constant [2 x i8] c" ?"
@.d52 = private constant [3 x i8] c" + "
@.d53 = private constant [1 x i8] c" "
@.d54 = private constant [3 x i8] c" ~["
@.d55 = private constant [7 x i8] c"struct("
@.d56 = private constant [5 x i8] c"enum{"
@.d57 = private constant [1 x i8] c"<"
@.d58 = private constant [1 x i8] c"."
@.d59 = private constant [1 x i8] c">"
@.d60 = private constant [4 x i8] c"true"
@.d61 = private constant [5 x i8] c"false"
@.d62 = private constant [1 x i8] c"<"
@.d63 = private constant [1 x i8] c">"
@.c64 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:1009: reached unreachable code\0A\00"
@.d65 = private constant [3 x i8] c"i32"
@.d66 = private constant [8 x i8] c"{ i64, ["
@.d67 = private constant [9 x i8] c" x i64] }"
@.c68 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:744: reached unreachable code\0A\00"
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [2 x i8] c", "
@.d71 = private constant [2 x i8] c"%\22"
@.d72 = private constant [1 x i8] c"\22"
@.d73 = private constant [3 x i8] c"i32"
@.d74 = private constant [1 x i8] c"?"
@.c75 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:939: reached unreachable code\0A\00"
@.d76 = private constant [3 x i8] c"i32"
@.d77 = private constant [4 x i8] c"void"
@.d78 = private constant [12 x i8] c"{ ptr, ptr }"
@.d79 = private constant [12 x i8] c"{ i64, ptr }"
@.d80 = private constant [3 x i8] c"ptr"
@.d81 = private constant [1 x i8] c"?"
@.c82 = private unnamed_addr constant [52 x i8] c"compiler/types.olang:913: reached unreachable code\0A\00"
@.c83 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:344: array length out of range\0A\00"
@.c84 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:1159: reached unreachable code\0A\00"
@.c85 = private unnamed_addr constant [53 x i8] c"compiler/types.olang:1157: reached unreachable code\0A\00"
@.d86 = private constant [0 x i8] c""
@.d87 = private constant [4 x i8] c"void"
@.d88 = private constant [2 x i8] c"i1"
@.d89 = private constant [2 x i8] c"i8"
@.d90 = private constant [3 x i8] c"i16"
@.d91 = private constant [3 x i8] c"i32"
@.d92 = private constant [3 x i8] c"i64"
@.d93 = private constant [2 x i8] c"i8"
@.d94 = private constant [3 x i8] c"i16"
@.d95 = private constant [3 x i8] c"i32"
@.d96 = private constant [3 x i8] c"i64"
@.d97 = private constant [4 x i8] c"half"
@.d98 = private constant [6 x i8] c"bfloat"
@.d99 = private constant [5 x i8] c"float"
@.d100 = private constant [6 x i8] c"double"
@.d101 = private constant [0 x i8] c""
@.d102 = private constant [0 x i8] c""
@.d103 = private constant [4 x i8] c"Bool"
@.d104 = private constant [2 x i8] c"I8"
@.d105 = private constant [3 x i8] c"I16"
@.d106 = private constant [3 x i8] c"I32"
@.d107 = private constant [3 x i8] c"I64"
@.d108 = private constant [2 x i8] c"U8"
@.d109 = private constant [3 x i8] c"U16"
@.d110 = private constant [3 x i8] c"U32"
@.d111 = private constant [3 x i8] c"U64"
@.d112 = private constant [3 x i8] c"F16"
@.d113 = private constant [4 x i8] c"BF16"
@.d114 = private constant [3 x i8] c"F32"
@.d115 = private constant [3 x i8] c"F64"
define linkonce_odr %"std/prelude/list:List<compiler/types:data>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/types:data>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/types:data>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/types:data>" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/types:data>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/types:data>", ptr %l0
  store %"std/prelude/list:List<compiler/types:data>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/types:data>", ptr %rv
  ret %"std/prelude/list:List<compiler/types:data>" %rr
}

define linkonce_odr %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>", ptr %l0
  store %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>", ptr %rv
  ret %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" %rr
}

define linkonce_odr %"std/prelude/list:List<I32>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<I32>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<I32>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<I32>" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<I32>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<I32>", ptr %l0
  store %"std/prelude/list:List<I32>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<I32>", ptr %rv
  ret %"std/prelude/list:List<I32>" %rr
}

define linkonce_odr %"std/prelude/list:List<Array<compiler/types:TypeId>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Array<compiler/types:TypeId>&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<Array<compiler/types:TypeId>&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Array<compiler/types:TypeId>&>" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<Array<compiler/types:TypeId>&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<Array<compiler/types:TypeId>&>", ptr %l0
  store %"std/prelude/list:List<Array<compiler/types:TypeId>&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<Array<compiler/types:TypeId>&>", ptr %rv
  ret %"std/prelude/list:List<Array<compiler/types:TypeId>&>" %rr
}

define linkonce_odr %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeI_He375cb5a1de17a5d01c6b8903f9691e1(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>", ptr %l0
  store %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>", ptr %rv
  ret %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" %rr
}

define linkonce_odr %"std/prelude/list:List<Array<compiler/source:NameId>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Array<compiler/source:NameId>&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<Array<compiler/source:NameId>&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Array<compiler/source:NameId>&>" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<Array<compiler/source:NameId>&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<Array<compiler/source:NameId>&>", ptr %l0
  store %"std/prelude/list:List<Array<compiler/source:NameId>&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<Array<compiler/source:NameId>&>", ptr %rv
  ret %"std/prelude/list:List<Array<compiler/source:NameId>&>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/types:ListId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/types:ListId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/types:ListId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/types:ListId>" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/types:ListId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/types:ListId>", ptr %l0
  store %"std/prelude/list:List<compiler/types:ListId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/types:ListId>", ptr %rv
  ret %"std/prelude/list:List<compiler/types:ListId>" %rr
}

define linkonce_odr %"std/prelude/map:Map<std/prelude/text:String&, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<std/prelude/text:String&, I64>" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %l0
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %rv
  ret %"std/prelude/map:Map<std/prelude/text:String&, I64>" %rr
}

define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/types:decl>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/types:decl>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/types:decl>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/types:decl>" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/types:decl>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/types:decl>", ptr %l0
  store %"std/prelude/list:List<compiler/types:decl>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/types:decl>", ptr %rv
  ret %"std/prelude/list:List<compiler/types:decl>" %rr
}

define linkonce_odr %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He0d7a5bfd18ae956abf945564c24098c(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>", ptr %l0
  store %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>", ptr %rv
  ret %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" %rr
}

define linkonce_odr %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>", ptr %l0
  store %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>", ptr %rv
  ret %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" %rr
}

define linkonce_odr %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20A_Hcfba385079b3349cc13047539d410cc3(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>", ptr %l0
  store %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>", ptr %rv
  ret %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" %rr
}

define linkonce_odr %"std/prelude/list:List<Array<I64>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Array<I64>&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<Array<I64>&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Array<I64>&>" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<Array<I64>&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<Array<I64>&>", ptr %l0
  store %"std/prelude/list:List<Array<I64>&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<Array<I64>&>", ptr %rv
  ret %"std/prelude/list:List<Array<I64>&>" %rr
}

define linkonce_odr %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>", ptr %l0
  store %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>", ptr %rv
  ret %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" %rr
}

define linkonce_odr %"std/prelude/map:Map<Array<I64>&, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<Array<I64>&, I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<Array<I64>&, I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<Array<I64>&, I64>" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<Array<I64>&, I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<Array<I64>&, I64>", ptr %l0
  store %"std/prelude/map:Map<Array<I64>&, I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<Array<I64>&, I64>", ptr %rv
  ret %"std/prelude/map:Map<Array<I64>&, I64>" %rr
}

define linkonce_odr %"std/prelude/map:Map<compiler/types:TypeId, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<compiler/types:TypeId, I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<compiler/types:TypeId, I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<compiler/types:TypeId, I64>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<compiler/types:TypeId, I64>", ptr %l0
  store %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<compiler/types:TypeId, I64>", ptr %rv
  ret %"std/prelude/map:Map<compiler/types:TypeId, I64>" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, %"compiler/types:decl" %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H9437066785f0bdbcfc17884fffb14a92(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H0a23e53200851bc31b5ac3bae3d00df4(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_H503e6d35c0db63145eb2ca8ce5f41f51(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %a0, i32 %a1, %"compiler/types:body" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/types:data" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %a0, %"compiler/types:data" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, %"compiler/types:data" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/list:List<compiler/types:TypeId>" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/types:data>" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<I32>" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Array<compiler/types:TypeId>&>" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Array<compiler/source:NameId>&>" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/types:ListId>" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<std/prelude/text:String&, I64>" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/types:decl>" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Array<I64>&>" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<Array<I64>&, I64>" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<compiler/types:TypeId, I64>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
