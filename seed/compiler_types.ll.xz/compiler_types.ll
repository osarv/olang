; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/types:data" = type { i32, i64, i64, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:decl" = type { i64, i32, i32, i32 }
%"compiler/types:body" = type { i32, i32, i32, i1, i1 }
@G_2ecompiler_2ftypes_2eAnySlotBase = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eBigAggregate = constant <{ [8 x i8] }> <{ [8 x i8] c"\80\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eBoolT = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eFromTypeVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eLaidOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eLayingOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoLayout = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNotLaidOut = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullT = constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eOwnScope = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eOwning = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eResultVar = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eRoleCtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eRoleDtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eRoleFn = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eUnknownT = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eWritable = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eprimBits = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ftypes_2eprimLlvm = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k1, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k2, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k7, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k11, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k12, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k13, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k14, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimLlvm.k15 }>, align 64
@G_2ecompiler_2ftypes_2eprimLlvm.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k2 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\76\6F\69\64" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k3 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\31" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k8 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k12 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\68\61\6C\66" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k13 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\62\66\6C\6F\61\74" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k14 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6C\6F\61\74" }>, align 8
@G_2ecompiler_2ftypes_2eprimLlvm.k15 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\64\6F\75\62\6C\65" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k2, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k7, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k12, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k13, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k14, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftypes_2eprimNames.k15 }>, align 64
@G_2ecompiler_2ftypes_2eprimNames.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k3 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\6F\6F\6C" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\49\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k8 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\55\38" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\36\34" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\46\31\36" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k14 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\33\32" }>, align 8
@G_2ecompiler_2ftypes_2eprimNames.k15 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\36\34" }>, align 8
define dso_local void @compiler_2ftypes_2eAnySlotBase_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eBigAggregate_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 128, ptr @G_2ecompiler_2ftypes_2eBigAggregate, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eBoolT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eClosingVar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -2, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eDefaultErrT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eFromTypeVar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -2, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eLaidOut_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eLayingOut_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ftypes_2eLayingOut, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNewTable(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca %"compiler/types:Table"
  %l8 = alloca ptr
  %l12 = alloca ptr
  %l16 = alloca ptr
  %l38 = alloca [18 x i32]
  %l49 = alloca ptr
  %l51 = alloca %"compiler/types:data"
  %l52 = alloca i32
  %l55 = alloca %"compiler/types:Table"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t2 = alloca %"compiler/types:Table", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftypes_3aTable_2ector(ptr %t2, ptr %v0, ptr %v1, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t2, i64 256, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 256, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l7, i64 256, i1 false)
  %t6 = load ptr, ptr %lp1
  %t7 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 5
  store ptr %t7, ptr %l8, !tbaa !29
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = icmp sle i64 0, 2305843009213693951
  br i1 %t10, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_350cf97603b2facf_69b011185289b33)
  unreachable
bb4:
  %t12 = mul i64 0, 4
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t16 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v1, ptr %v1, ptr %t16, { i64, ptr } %t15)
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_350cf97603b2facf_69b011185289b33)
  unreachable
bb6:
  %t18 = load ptr, ptr %lp1
  %t19 = getelementptr %"compiler/types:Table", ptr %t18, i32 0, i32 26
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_8b13046bbc59237a_a5831af19cea45fe)
  unreachable
bb9:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t28, { i64, ptr } %t27)
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8b13046bbc59237a_a5831af19cea45fe)
  unreachable
bb11:
  %t30 = load ptr, ptr %lp1
  %t31 = getelementptr %"compiler/types:Table", ptr %t30, i32 0, i32 28
  store ptr %t31, ptr %l16, !tbaa !29
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb12, label %bb13
bb12:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4622f22b1b9e72f9_4c12a3b980ae2b3d)
  unreachable
bb14:
  %t36 = mul i64 0, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t40 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t40, { i64, ptr } %t39)
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4622f22b1b9e72f9_4c12a3b980ae2b3d)
  unreachable
bb16:
  store %olang.scope zeroinitializer, ptr %s1
  %t60 = getelementptr [18 x i32], ptr %l38, i64 0, i64 0
  store i32 0, ptr %t60
  %t61 = getelementptr [18 x i32], ptr %l38, i64 0, i64 1
  store i32 1, ptr %t61
  %t62 = getelementptr [18 x i32], ptr %l38, i64 0, i64 2
  store i32 2, ptr %t62
  %t63 = getelementptr [18 x i32], ptr %l38, i64 0, i64 3
  store i32 3, ptr %t63
  %t64 = getelementptr [18 x i32], ptr %l38, i64 0, i64 4
  store i32 4, ptr %t64
  %t65 = getelementptr [18 x i32], ptr %l38, i64 0, i64 5
  store i32 5, ptr %t65
  %t66 = getelementptr [18 x i32], ptr %l38, i64 0, i64 6
  store i32 6, ptr %t66
  %t67 = getelementptr [18 x i32], ptr %l38, i64 0, i64 7
  store i32 7, ptr %t67
  %t68 = getelementptr [18 x i32], ptr %l38, i64 0, i64 8
  store i32 8, ptr %t68
  %t69 = getelementptr [18 x i32], ptr %l38, i64 0, i64 9
  store i32 9, ptr %t69
  %t70 = getelementptr [18 x i32], ptr %l38, i64 0, i64 10
  store i32 10, ptr %t70
  %t71 = getelementptr [18 x i32], ptr %l38, i64 0, i64 11
  store i32 11, ptr %t71
  %t72 = getelementptr [18 x i32], ptr %l38, i64 0, i64 12
  store i32 12, ptr %t72
  %t73 = getelementptr [18 x i32], ptr %l38, i64 0, i64 13
  store i32 13, ptr %t73
  %t74 = getelementptr [18 x i32], ptr %l38, i64 0, i64 14
  store i32 14, ptr %t74
  %t75 = getelementptr [18 x i32], ptr %l38, i64 0, i64 15
  store i32 15, ptr %t75
  %t76 = getelementptr [18 x i32], ptr %l38, i64 0, i64 16
  store i32 16, ptr %t76
  %t77 = getelementptr [18 x i32], ptr %l38, i64 0, i64 17
  store i32 17, ptr %t77
  %t78 = load [18 x i32], ptr %l38
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 72, i64 8)
  store [18 x i32] %t78, ptr %t79
  store ptr %t79, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t81 = load ptr, ptr %l2
  store i64 18, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t84 = load i64, ptr %l3, !tbaa !24
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l2
  %t93 = load i64, ptr %l3, !tbaa !24
  %t96 = getelementptr [18 x i32], ptr %t92, i64 0, i64 %t93
  %t97 = load i32, ptr %t96
  %t99 = load ptr, ptr %lp1
  store ptr %t99, ptr %l49, !tbaa !29
  %t102 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s2, i32 %t97, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t102, ptr %l51
  br label %bb21
bb21:
  %t103 = load ptr, ptr %l49, !tbaa !29
  %t104 = load %"compiler/types:data", ptr %l51
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v1, ptr %t103, %"compiler/types:data" %t104, i32 1)
  store i32 %t105, ptr %l52
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t106 = load i64, ptr %l3, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l3, !tbaa !24
  br label %bb17
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t110 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t110, i64 256, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l55, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNoLayout_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ftypes_2eNoLayout, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNoreturnT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 17, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNotLaidOut_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ftypes_2eNotLaidOut, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNullT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 15, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eNullable_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eOwnScope_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eOwning_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eReadOnly_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eResultVar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleCtor_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleDtor_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ftypes_2eRoleDtor, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eRoleFn_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, i64 }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l5, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l6, !tbaa !22
  %t27 = load i8, ptr %l6, !tbaa !22
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t27)
  store i1 %t29, ptr %l24
  br label %bb6
bb6:
  %t30 = load i1, ptr %l24, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb8:
  %t31 = load i8, ptr %l6, !tbaa !22
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t31)
  store i1 %t33, ptr %l27
  br label %bb9
bb9:
  %t34 = load i1, ptr %l27, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  store i1 %t37, ptr %l28, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l28, !tbaa !21
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load i8, ptr %l6, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t41)
  br label %bb16
bb15:
  %t44 = load i8, ptr %l6, !tbaa !22
  %t46 = icmp eq i8 %t44, 95
  br i1 %t46, label %bb17, label %bb18
bb16:
  br label %bb24
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr @.d0 })
  br label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb20:
  store ptr %l1, ptr %l37, !tbaa !29
  %t50 = load i8, ptr %l6, !tbaa !22
  %t53 = call { i64, ptr } @compiler_2ftypes_2ehex2(ptr %s6, i8 %t50)
  store { i64, ptr } %t53, ptr %l40
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t61 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t61, { i64, ptr } %t60)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb2
bb26:
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t68, ptr %l45
  br label %bb27
bb27:
  %t69 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t69, ptr %l7, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t74 = icmp sle i64 %t72, 120
  br i1 %t74, label %bb28, label %bb29
bb28:
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t76, ptr %l50, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l51, !tbaa !24
  %t80 = load i64, ptr %l51, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l52, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l51, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t91, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t93 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %t93)
  store { i64, i64 } %t95, ptr %l54
  br label %bb31
bb31:
  %t96 = load { i64, i64 }, ptr %l54
  store { i64, i64 } %t96, ptr %l8
  %t97 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t98 = load i64, ptr %t97, !tbaa !65
  store i64 %t98, ptr %l9, !tbaa !65
  %t100 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !65
  store i64 %t101, ptr %l10, !tbaa !65
  %t103 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t103, ptr %l57, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l58, !tbaa !24
  %t106 = icmp sge i64 0, 0
  br i1 %t106, label %bb32, label %bb33
bb32:
  %t108 = icmp sle i64 0, 88
  br i1 %t108, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb34:
  %t110 = load i64, ptr %l58, !tbaa !24
  %t111 = icmp sle i64 88, %t110
  br i1 %t111, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb36:
  %t113 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 0
  %t116 = sub i64 88, 0
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  store { i64, ptr } %t118, ptr %l62, !tbaa !27
  %t119 = load i64, ptr %l9, !tbaa !65
  %t121 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t119)
  store { i64, ptr } %t121, ptr %l64
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb38:
  %t122 = load i64, ptr %l10, !tbaa !65
  %t124 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t122)
  store { i64, ptr } %t124, ptr %l66
  br label %bb39
bb39:
  %t125 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } { i64 2, ptr @.d1 }, 1
  %t129 = extractvalue { i64, ptr } { i64 2, ptr @.d1 }, 0
  %t130 = add i64 %t127, %t129
  %t131 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t126, i64 %t127)
  %t140 = getelementptr i8, ptr %t139, i64 %t127
  call void @olang_textcopy(ptr %t140, ptr %t128, i64 %t129)
  %t141 = getelementptr i8, ptr %t140, i64 %t129
  call void @olang_textcopy(ptr %t141, ptr %t132, i64 %t133)
  %t142 = getelementptr i8, ptr %t141, i64 %t133
  call void @olang_textcopy(ptr %t142, ptr %t136, i64 %t137)
  %t143 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t139, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eUnknownT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %v0, i64 %a0) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l2, !tbaa !65
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !65
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t8, i64 %t9)
  store { i64, ptr } %t10, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_30e02956f84eec46_91b8152c5eb3aca)
  unreachable
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eVoidT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eWritable_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i64
  %l12 = alloca ptr
  %l17 = alloca %"compiler/types:decl"
  %l19 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l5, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/types:Table", ptr %t10, i32 0, i32 13
  store ptr %t12, ptr %l12, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = load i32, ptr %l2, !tbaa !23
  %t21 = call %"compiler/types:decl" @compiler_2ftypes_3adecl_2ector(ptr %s0, i64 %t13, i32 %t14, i32 %a3, i32 %a4)
  store %"compiler/types:decl" %t21, ptr %l17
  br label %bb2
bb2:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = load %"compiler/types:decl", ptr %l17
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t22, %"compiler/types:decl" %t23)
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/types:Table", ptr %t24, i32 0, i32 15
  store ptr %t26, ptr %l19, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/types:Table", ptr %t27, i32 0, i32 14
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t29, i64 %t30)
  store { i64, ptr } %t33, ptr %l23
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/types:Table", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l27
  br label %bb5
bb5:
  %t42 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 0
  %t47 = add i64 %t44, %t46
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t43, i64 %t44)
  %t53 = getelementptr i8, ptr %t52, i64 %t44
  call void @olang_textcopy(ptr %t53, ptr %t45, i64 %t46)
  %t54 = getelementptr i8, ptr %t53, i64 %t46
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t52, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = extractvalue { i64, ptr } %t56, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  %t64 = load i32, ptr %l5, !tbaa !23
  %t65 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v0, ptr %t65, { i64, ptr } %t63, i32 %t64)
  br label %bb6
bb6:
  %t68 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 14
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = extractvalue { i64, ptr } %t10, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t3, { i64, ptr } %t17)
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 14
  %t24 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l9
  br label %bb2
bb2:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = sub i64 %t25, 1
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 20
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i32
  %l29 = alloca %"std/prelude/text:StringBuilder"
  %l37 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l63 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l102 = alloca i64
  %l110 = alloca ptr
  %l123 = alloca i1
  %l127 = alloca { i64, ptr }
  %l131 = alloca i64
  %l140 = alloca i64
  %l143 = alloca i64
  %l161 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l175 = alloca %"compiler/types:data"
  %l178 = alloca i32
  %l180 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l28
  br label %bb1
bb1:
  %t6 = load i32, ptr %l28, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l29
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l29
  store %"std/prelude/text:StringBuilder" %t8, ptr %l5
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l8, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t23, ptr %l37, !tbaa !27
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  %t34 = sext i32 %t29 to i64
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t34)
  %t41 = getelementptr i8, ptr %t39, i64 %t35
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t50)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb3
bb9:
  %t57 = load i32, ptr %l4, !tbaa !23
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 0
  %t62 = sext i32 %t57 to i64
  %t63 = call i64 @__olang_fmt_i64(ptr null, i64 %t62)
  %t64 = add i64 %t60, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t59, i64 %t60)
  %t66 = getelementptr i8, ptr %t65, i64 %t60
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t62)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t76)
  br label %bb10
bb10:
  %t80 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t80, ptr %l53
  br label %bb11
bb11:
  %t81 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t81, ptr %l10, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/types:Table", ptr %t82, i32 0, i32 10
  %t85 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t88 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s0, ptr %t84, { i64, ptr } %t85)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l59
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb13, label %ok.92
ok.92:
  store i64 %t89, ptr %l58
  br label %bb12
bb12:
  %t93 = load i64, ptr %l58, !tbaa !24
  store i64 %t93, ptr %l54, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb15
bb15:
  %t94 = load i64, ptr %l54, !tbaa !24
  store i64 %t94, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb16, label %bb17
bb16:
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l63, !tbaa !24
  %t102 = load i64, ptr %l63, !tbaa !24
  %t103 = icmp sge i64 %t102, 0
  br i1 %t103, label %bb18, label %bb19
bb17:
  br label %bb43
bb18:
  %t105 = load i64, ptr %l63, !tbaa !24
  %t106 = icmp sle i64 %t105, 2305843009213693951
  br i1 %t106, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_363cc534119e1b58_f5bd72046473679c)
  unreachable
bb20:
  %t108 = load i64, ptr %l63, !tbaa !24
  %t109 = mul i64 %t108, 4
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t118 = load i64, ptr %l14, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_363cc534119e1b58_f5bd72046473679c)
  unreachable
bb22:
  %t124 = load i64, ptr %l15, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb27
bb24:
  %t128 = load i64, ptr %l14, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l15, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l15, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l75, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb26
bb26:
  %t144 = load i64, ptr %l75, !tbaa !24
  store i64 %t144, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t145 = load i64, ptr %l72, !tbaa !24
  store i64 %t145, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t146 = load i64, ptr %l17, !tbaa !24
  %t147 = load i64, ptr %l16, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l17, !tbaa !24
  %t156 = load i64, ptr %l15, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l18, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t164, ptr %l93, !tbaa !27
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t166, ptr %l95, !tbaa !27
  %t167 = load i64, ptr %l18, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i32, ptr %t170, i64 %t167
  %t172 = load i32, ptr %t171, !tbaa !33
  %t175 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i32, ptr %t176, i64 %t165
  store i32 %t172, ptr %t177, !tbaa !33
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb32:
  %t178 = load i64, ptr %l17, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l17, !tbaa !24
  br label %bb28
bb33:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/types:Table", ptr %t182, i32 0, i32 7
  %t186 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H9437066785f0bdbcfc17884fffb14a92(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l102
  br label %bb34
bb34:
  %t187 = load i64, ptr %l102, !tbaa !24
  store i64 %t187, ptr %l11, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/types:Table", ptr %t188, i32 0, i32 7
  %t191 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v0, ptr %t190, { i64, ptr } %t191)
  br label %bb35
bb35:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/types:Table", ptr %t194, i32 0, i32 8
  %t197 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t196, i32 %t197)
  br label %bb36
bb36:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/types:Table", ptr %t200, i32 0, i32 9
  store ptr %t202, ptr %l110, !tbaa !29
  %t203 = icmp sge i64 0, 0
  br i1 %t203, label %bb37, label %bb38
bb37:
  %t205 = icmp sle i64 0, 2305843009213693951
  br i1 %t205, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969)
  unreachable
bb39:
  %t207 = mul i64 0, 4
  %t208 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 0, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t211 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v0, ptr %t211, { i64, ptr } %t210)
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969)
  unreachable
bb41:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/types:Table", ptr %t213, i32 0, i32 10
  %t216 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t216, 1
  %t219 = extractvalue { i64, ptr } %t216, 0
  %t220 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t219)
  call void @olang_textcopy(ptr %t220, ptr %t218, i64 %t219)
  %t221 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = extractvalue { i64, ptr } %t222, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t230 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t215, { i64, ptr } %t229, i64 %t230)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t234 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t238 = icmp sgt i64 %t236, 0
  br i1 %t238, label %bb44, label %bb45
bb44:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/types:Table", ptr %t240, i32 0, i32 9
  %t243 = load i64, ptr %l11, !tbaa !24
  %t246 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %s0, ptr %t242, i64 %t243)
  store { i64, ptr } %t246, ptr %l127
  br label %bb46
bb45:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb47
bb46:
  %t247 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 0
  %t250 = icmp eq i64 %t248, 0
  store i1 %t250, ptr %l123, !tbaa !21
  br label %bb47
bb47:
  %t252 = load i1, ptr %l123, !tbaa !21
  br i1 %t252, label %bb48, label %bb49
bb48:
  %t253 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  store i64 %t255, ptr %l131, !tbaa !24
  %t256 = load i64, ptr %l131, !tbaa !24
  %t257 = icmp sge i64 %t256, 0
  br i1 %t257, label %bb50, label %bb51
bb49:
  br label %bb67
bb50:
  %t259 = load i64, ptr %l131, !tbaa !24
  %t260 = icmp sle i64 %t259, 2305843009213693951
  br i1 %t260, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a)
  unreachable
bb52:
  %t262 = load i64, ptr %l131, !tbaa !24
  %t263 = mul i64 %t262, 4
  %t264 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t263)
  %t265 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  store { i64, ptr } %t266, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t268 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t268, 0
  store i64 %t270, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t272 = load i64, ptr %l21, !tbaa !24
  %t273 = load i64, ptr %l20, !tbaa !24
  %t276 = icmp sgt i64 %t272, %t273
  br i1 %t276, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a)
  unreachable
bb54:
  %t278 = load i64, ptr %l22, !tbaa !24
  %t280 = icmp sgt i64 %t278, 0
  br i1 %t280, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb59
bb56:
  %t282 = load i64, ptr %l21, !tbaa !24
  %t283 = load i64, ptr %l20, !tbaa !24
  %t286 = sub i64 %t282, %t283
  %t287 = load i64, ptr %l22, !tbaa !24
  %t290 = add i64 %t286, %t287
  %t292 = sub i64 %t290, 1
  %t293 = load i64, ptr %l22, !tbaa !24
  %t296 = sdiv i64 %t292, %t293
  store i64 %t296, ptr %l143, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb58
bb58:
  %t298 = load i64, ptr %l143, !tbaa !24
  store i64 %t298, ptr %l140, !tbaa !24
  br label %bb59
bb59:
  %t299 = load i64, ptr %l140, !tbaa !24
  store i64 %t299, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s13
  %t300 = load i64, ptr %l24, !tbaa !24
  %t301 = load i64, ptr %l23, !tbaa !24
  %t304 = icmp slt i64 %t300, %t301
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb65
bb62:
  br label %bb63
bb63:
  %t308 = load i64, ptr %l20, !tbaa !24
  %t309 = load i64, ptr %l24, !tbaa !24
  %t310 = load i64, ptr %l22, !tbaa !24
  %t313 = mul i64 %t309, %t310
  %t316 = add i64 %t308, %t313
  store i64 %t316, ptr %l25, !tbaa !24
  %t318 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t318, ptr %l161, !tbaa !27
  %t319 = load i64, ptr %l25, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t320, ptr %l163, !tbaa !27
  %t321 = load i64, ptr %l25, !tbaa !24
  %t323 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr i32, ptr %t324, i64 %t321
  %t326 = load i32, ptr %t325, !tbaa !33
  %t329 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr i32, ptr %t330, i64 %t319
  store i32 %t326, ptr %t331, !tbaa !33
  call void @__olang_scope_close(ptr %s13)
  br label %bb64
bb64:
  %t332 = load i64, ptr %l24, !tbaa !24
  %t334 = add i64 %t332, 1
  store i64 %t334, ptr %l24, !tbaa !24
  br label %bb60
bb65:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/types:Table", ptr %t336, i32 0, i32 9
  %t339 = load i64, ptr %l11, !tbaa !24
  %t340 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hcaffdb9d24c80e421d58a725793b74fc(ptr %v0, ptr %v0, ptr %t338, i64 %t339, { i64, ptr } %t340)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l172, !tbaa !29
  %t345 = load i64, ptr %l11, !tbaa !24
  %t348 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 24, i64 %t345, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t348, ptr %l175
  br label %bb68
bb68:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr %l4, !tbaa !23
  %t353 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t349, i32 %t350)
  store i32 %t353, ptr %l178
  br label %bb69
bb69:
  %t354 = load i32, ptr %l178, !tbaa !23
  %t355 = add i32 %t354, 1
  %t356 = load ptr, ptr %l172, !tbaa !29
  %t357 = load %"compiler/types:data", ptr %l175
  %t359 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t356, %"compiler/types:data" %t357, i32 %t355)
  store i32 %t359, ptr %l180
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t360 = load i32, ptr %l180, !tbaa !23
  store i32 %t360, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l6 = alloca %"compiler/types:data"
  %l9 = alloca i32
  %l11 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 29, i64 %t4, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = add i32 %t13, 1
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l6
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t14)
  store i32 %t18, ptr %l11
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i32, ptr %l11, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l11
  br label %bb4
bb3:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l8, !tbaa !23
  br label %bb5
bb4:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %l8, !tbaa !23
  br label %bb5
bb5:
  %t19 = load i32, ptr %l8, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load i32, ptr %l15
  %t27 = trunc i64 29 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t30, i32 %t31)
  store i64 %t34, ptr %l21
  br label %bb9
bb8:
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t35, ptr %l18, !tbaa !23
  br label %bb10
bb9:
  %t37 = load i64, ptr %l21, !tbaa !24
  %t38 = trunc i64 %t37 to i32
  store i32 %t38, ptr %l18, !tbaa !23
  br label %bb10
bb10:
  %t41 = load i32, ptr %l18, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l10 = alloca %"compiler/types:data"
  %l13 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca i32
  %l30 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load i32, ptr %l2, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t11 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 19, i64 %t4, i64 %t7, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = add i32 %t17, 1
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load %"compiler/types:data", ptr %l10
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t19, %"compiler/types:data" %t20, i32 %t18)
  store i32 %t22, ptr %l15
  br label %bb3
bb3:
  %t23 = load i32, ptr %l15, !tbaa !23
  store i32 %t23, ptr %l3, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l18
  br label %bb4
bb4:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load i32, ptr %l18, !tbaa !23
  %t32 = icmp ne i32 %t30, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/types:Table", ptr %t34, i32 0, i32 25
  store ptr %t36, ptr %l22, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t39 = sext i32 %t37 to i64
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l28
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t46 = load i32, ptr %l2, !tbaa !23
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i32, ptr %l28, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t47, i32 %t48, i32 %t46)
  store i32 %t50, ptr %l30
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load i64, ptr %l24, !tbaa !24
  %t53 = load i32, ptr %l30, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t51, i64 %t52, i32 %t53)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t54 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t20, ptr %l13
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i32, ptr %l14
  %t26 = trunc i64 19 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l7, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 2
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sle i32 %t1, 14
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr [15 x i64], ptr @G_2ecompiler_2ftypes_2eprimBits, i64 0, i64 %t7
  %t10 = load i64, ptr %t9, !tbaa !34
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eByAddress(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l28 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i32, ptr %l9
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3
  %t15 = trunc i64 22 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load i32, ptr %l3
  %t20 = trunc i64 23 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb24
bb8:
  %t23 = load i32, ptr %l3
  %t25 = trunc i64 18 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l20
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l21
  br label %bb13
bb13:
  %t37 = load i32, ptr %l21
  %t39 = trunc i64 0 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l10, !tbaa !21
  br label %bb24
bb14:
  %t42 = load i32, ptr %l3
  %t44 = trunc i64 19 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l2, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l28
  br label %bb18
bb18:
  %t52 = load i32, ptr %l28, !tbaa !23
  %t53 = icmp ne i32 %t52, 0
  store i1 %t53, ptr %l10, !tbaa !21
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c5f0a3e3912a4ce3_83ad4b8f75c0f327)
  unreachable
bb24:
  %t55 = load i1, ptr %l10, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 3
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 3
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t9, ptr %lp2
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = load ptr, ptr %lp2
  store { i64, ptr } %t10, ptr %t11, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/types:Table", ptr %t12, i32 0, i32 3
  store i1 false, ptr %t14, !tbaa !21
  %t15 = load ptr, ptr %lp2
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 17
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = icmp sle i64 0, 2305843009213693951
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_b3c0df13ff143a95_992c52f0f53f0c49)
  unreachable
bb6:
  %t17 = mul i64 0, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b3c0df13ff143a95_992c52f0f53f0c49)
  unreachable
bb8:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l8 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i64
  %l31 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i32
  %l44 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i1
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  %t15 = load i32, ptr %l3
  %t17 = trunc i64 25 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  %t20 = load i32, ptr %l3
  %t22 = trunc i64 27 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  %t25 = load i32, ptr %l3
  %t27 = trunc i64 15 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb83
bb11:
  %t30 = load i32, ptr %l3
  %t32 = trunc i64 18 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t35 = load i32, ptr %l3
  %t37 = trunc i64 22 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t40 = load i32, ptr %l3
  %t42 = trunc i64 23 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t47 = load i32, ptr %t46
  %t49 = trunc i64 18 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb19, label %bb20
bb19:
  %t52 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l26, !tbaa !24
  br label %bb21
bb20:
  %t55 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l26, !tbaa !24
  br label %bb21
bb21:
  %t58 = load i64, ptr %l26, !tbaa !24
  %t59 = trunc i64 %t58 to i32
  %t61 = load ptr, ptr %l23, !tbaa !29
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t61, i32 %t59)
  store i1 %t63, ptr %l31
  br label %bb22
bb22:
  %t64 = load i1, ptr %l31, !tbaa !21
  store i1 %t64, ptr %l8, !tbaa !21
  br label %bb83
bb23:
  %t65 = load i32, ptr %l3
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb38
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l34, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l1, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l37
  br label %bb27
bb27:
  %t76 = load ptr, ptr %l34, !tbaa !29
  %t77 = load i32, ptr %l37, !tbaa !23
  %t78 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t78, ptr %l38
  br label %bb28
bb28:
  %t79 = load i1, ptr %l38, !tbaa !21
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l42
  br label %bb31
bb30:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb37
bb31:
  %t85 = load i32, ptr %l42, !tbaa !23
  %t86 = icmp eq i32 %t85, 0
  br i1 %t86, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb36
bb33:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l45, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i32, ptr %l48, !tbaa !23
  %t96 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t96, ptr %l49
  br label %bb35
bb35:
  %t97 = load i1, ptr %l49, !tbaa !21
  store i1 %t97, ptr %l44, !tbaa !21
  br label %bb36
bb36:
  %t98 = load i1, ptr %l44, !tbaa !21
  store i1 %t98, ptr %l39, !tbaa !21
  br label %bb37
bb37:
  %t99 = load i1, ptr %l39, !tbaa !21
  store i1 %t99, ptr %l8, !tbaa !21
  br label %bb83
bb38:
  %t100 = load i32, ptr %l3
  %t102 = trunc i64 20 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l52, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l55
  br label %bb42
bb42:
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load i32, ptr %l55, !tbaa !23
  %t113 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t113, ptr %l56
  br label %bb43
bb43:
  %t114 = load i1, ptr %l56, !tbaa !21
  store i1 %t114, ptr %l8, !tbaa !21
  br label %bb83
bb44:
  %t115 = load i32, ptr %l3
  %t117 = trunc i64 21 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb60
bb47:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l59, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l1, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l62
  br label %bb48
bb48:
  %t126 = load ptr, ptr %l59, !tbaa !29
  %t127 = load i32, ptr %l62, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l63
  br label %bb49
bb49:
  %t129 = load i1, ptr %l63, !tbaa !21
  br i1 %t129, label %bb50, label %bb51
bb50:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l68
  br label %bb52
bb51:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb54
bb52:
  %t136 = load ptr, ptr %l65, !tbaa !29
  %t137 = load i32, ptr %l68, !tbaa !23
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t138, ptr %l69
  br label %bb53
bb53:
  %t139 = load i1, ptr %l69, !tbaa !21
  store i1 %t139, ptr %l64, !tbaa !21
  br label %bb54
bb54:
  %t140 = load i1, ptr %l64, !tbaa !21
  br i1 %t140, label %bb55, label %bb56
bb55:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l71, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l74
  br label %bb57
bb56:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb59
bb57:
  %t147 = load ptr, ptr %l71, !tbaa !29
  %t148 = load i32, ptr %l74, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t147, i32 %t148)
  store i1 %t149, ptr %l75
  br label %bb58
bb58:
  %t150 = load i1, ptr %l75, !tbaa !21
  store i1 %t150, ptr %l70, !tbaa !21
  br label %bb59
bb59:
  %t151 = load i1, ptr %l70, !tbaa !21
  store i1 %t151, ptr %l8, !tbaa !21
  br label %bb83
bb60:
  %t152 = load i32, ptr %l3
  %t154 = trunc i64 24 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l78, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l1, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l81
  br label %bb64
bb64:
  %t163 = load ptr, ptr %l78, !tbaa !29
  %t164 = load i32, ptr %l81, !tbaa !23
  %t165 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t165, ptr %l82
  br label %bb65
bb65:
  %t166 = load i1, ptr %l82, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb83
bb66:
  %t167 = load i32, ptr %l3
  %t169 = trunc i64 26 to i32
  %t170 = icmp eq i32 %t167, %t169
  br i1 %t170, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l85, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l88
  br label %bb70
bb70:
  %t178 = load ptr, ptr %l85, !tbaa !29
  %t179 = load i32, ptr %l88, !tbaa !23
  %t180 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t178, i32 %t179)
  store i1 %t180, ptr %l89
  br label %bb71
bb71:
  %t181 = load i1, ptr %l89, !tbaa !21
  store i1 %t181, ptr %l8, !tbaa !21
  br label %bb83
bb72:
  %t182 = load i32, ptr %l3
  %t184 = trunc i64 29 to i32
  %t185 = icmp eq i32 %t182, %t184
  br i1 %t185, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l92, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l1, !tbaa !23
  %t192 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l95
  br label %bb76
bb76:
  %t193 = load ptr, ptr %l92, !tbaa !29
  %t194 = load i32, ptr %l95, !tbaa !23
  %t195 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t193, i32 %t194)
  store i1 %t195, ptr %l96
  br label %bb77
bb77:
  %t196 = load i1, ptr %l96, !tbaa !21
  store i1 %t196, ptr %l8, !tbaa !21
  br label %bb83
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_3a86b0904acb017a_fb1793104580b26e)
  unreachable
bb83:
  %t197 = load i1, ptr %l8, !tbaa !21
  store i1 %t197, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i64
  %l19 = alloca { i64, i64 }
  %l20 = alloca { i64, i64 }
  %l21 = alloca i32
  %l22 = alloca { i64, i64 }
  %l23 = alloca { i64, i64 }
  %l26 = alloca i32
  %l27 = alloca i64
  %l31 = alloca %"compiler/types:data"
  %l66 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca i32
  %l103 = alloca i32
  %l107 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca i32
  %l118 = alloca i32
  %l121 = alloca i64
  %l122 = alloca ptr
  %l125 = alloca i32
  %l126 = alloca i64
  %l130 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca i32
  %l141 = alloca i32
  %l142 = alloca { i64, i64 }
  %l147 = alloca ptr
  %l148 = alloca i32
  %l151 = alloca i32
  %l152 = alloca { i64, i64 }
  %l159 = alloca i1
  %l162 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca i32
  %l169 = alloca ptr
  %l170 = alloca i32
  %l173 = alloca i32
  %l174 = alloca { i64, i64 }
  %l179 = alloca ptr
  %l180 = alloca i32
  %l183 = alloca i32
  %l184 = alloca { i64, i64 }
  %l195 = alloca i32
  %l198 = alloca i64
  %l204 = alloca i64
  %l207 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l31
  store %"compiler/types:data" %t6, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l5
  %t10 = load i32, ptr %l5
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  %t15 = load i32, ptr %l5
  %t17 = trunc i64 17 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb141
bb7:
  %t20 = load i32, ptr %l5
  %t22 = trunc i64 2 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb8, label %bb9
bb8:
  br label %bb34
bb9:
  %t25 = load i32, ptr %l5
  %t27 = trunc i64 3 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb34
bb11:
  %t30 = load i32, ptr %l5
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb34
bb13:
  %t35 = load i32, ptr %l5
  %t37 = trunc i64 5 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb14, label %bb15
bb14:
  br label %bb34
bb15:
  %t40 = load i32, ptr %l5
  %t42 = trunc i64 6 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb34
bb17:
  %t45 = load i32, ptr %l5
  %t47 = trunc i64 7 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb18, label %bb19
bb18:
  br label %bb34
bb19:
  %t50 = load i32, ptr %l5
  %t52 = trunc i64 8 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb20, label %bb21
bb20:
  br label %bb34
bb21:
  %t55 = load i32, ptr %l5
  %t57 = trunc i64 9 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb34
bb23:
  %t60 = load i32, ptr %l5
  %t62 = trunc i64 10 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb24, label %bb25
bb24:
  br label %bb34
bb25:
  %t65 = load i32, ptr %l5
  %t67 = trunc i64 11 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  %t70 = load i32, ptr %l5
  %t72 = trunc i64 12 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  %t75 = load i32, ptr %l5
  %t77 = trunc i64 13 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t80 = load i32, ptr %l5
  %t82 = trunc i64 14 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = icmp ne i32 %t85, %t86
  br i1 %t89, label %bb35, label %bb36
bb35:
  %t91 = load i32, ptr %l1, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t95 = getelementptr [15 x i64], ptr @G_2ecompiler_2ftypes_2eprimBits, i64 0, i64 %t93
  %t96 = load i64, ptr %t95, !tbaa !34
  %t98 = sdiv i64 %t96, 8
  store i64 %t98, ptr %l66, !tbaa !24
  br label %bb37
bb36:
  store i64 1, ptr %l66, !tbaa !24
  br label %bb37
bb37:
  %t100 = load i64, ptr %l66, !tbaa !24
  store i64 %t100, ptr %l3, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb141
bb38:
  %t103 = load i32, ptr %l5
  %t105 = trunc i64 16 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb141
bb42:
  %t112 = load i32, ptr %l5
  %t114 = trunc i64 21 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb141
bb46:
  %t121 = load i32, ptr %l5
  %t123 = trunc i64 20 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l82, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l85
  br label %bb50
bb50:
  %t132 = load ptr, ptr %l82, !tbaa !29
  %t133 = load i32, ptr %l85, !tbaa !23
  %t134 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t132, i32 %t133)
  store i1 %t134, ptr %l86
  br label %bb51
bb51:
  %t135 = load i1, ptr %l86, !tbaa !21
  br i1 %t135, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb56
bb53:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l88, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l1, !tbaa !23
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l91
  br label %bb54
bb54:
  %t142 = load ptr, ptr %l88, !tbaa !29
  %t143 = load i32, ptr %l91, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t144, ptr %l92
  br label %bb55
bb55:
  %t145 = load i32, ptr %l92
  %t147 = trunc i64 29 to i32
  %t148 = icmp eq i32 %t145, %t147
  store i1 %t148, ptr %l87, !tbaa !21
  br label %bb56
bb56:
  %t150 = load i1, ptr %l87, !tbaa !21
  br i1 %t150, label %bb57, label %bb58
bb57:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb59
bb58:
  store i64 8, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb59
bb59:
  br label %bb141
bb60:
  %t159 = load i32, ptr %l5
  %t161 = trunc i64 19 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb78
bb63:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l1, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t164, i32 %t165)
  store i32 %t168, ptr %l103
  br label %bb64
bb64:
  %t169 = load i32, ptr %l103, !tbaa !23
  %t170 = icmp eq i32 %t169, 0
  br i1 %t170, label %bb65, label %bb66
bb65:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb77
bb66:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l107, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l1, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l110
  br label %bb67
bb67:
  %t182 = load ptr, ptr %l107, !tbaa !29
  %t183 = load i32, ptr %l110, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t184, ptr %l111
  br label %bb68
bb68:
  %t185 = load i32, ptr %l111
  %t187 = trunc i64 26 to i32
  %t188 = icmp eq i32 %t185, %t187
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb69, label %bb70
bb69:
  store i1 false, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l1, !tbaa !23
  %t197 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t193, i32 %t194)
  store i32 %t197, ptr %l118
  br label %bb72
bb72:
  %t198 = load i32, ptr %l118, !tbaa !23
  store i32 %t198, ptr %l16, !tbaa !23
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i32, ptr %l16, !tbaa !23
  %t203 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t199, i32 %t200)
  store i64 %t203, ptr %l121
  br label %bb73
bb73:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l122, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l1, !tbaa !23
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t205, i32 %t206)
  store i32 %t209, ptr %l125
  br label %bb74
bb74:
  %t210 = load ptr, ptr %l122, !tbaa !29
  %t211 = load i32, ptr %l125, !tbaa !23
  %t212 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t210, i32 %t211)
  store i64 %t212, ptr %l126
  br label %bb75
bb75:
  %t213 = load i64, ptr %l121, !tbaa !24
  %t214 = load i64, ptr %l126, !tbaa !24
  %t215 = mul i64 %t213, %t214
  store i64 %t215, ptr %l17, !tbaa !24
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l16, !tbaa !23
  %t221 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t217, i32 %t218)
  store i64 %t221, ptr %l130
  br label %bb76
bb76:
  %t222 = load i64, ptr %l130, !tbaa !24
  %t223 = load i64, ptr %l17, !tbaa !24
  store i64 %t223, ptr %l3, !tbaa !24
  store i64 %t222, ptr %l4, !tbaa !24
  br label %bb77
bb77:
  br label %bb141
bb78:
  %t227 = load i32, ptr %l5
  %t229 = trunc i64 22 to i32
  %t230 = icmp eq i32 %t227, %t229
  br i1 %t230, label %bb79, label %bb80
bb79:
  br label %bb83
bb80:
  %t232 = load i32, ptr %l5
  %t234 = trunc i64 23 to i32
  %t235 = icmp eq i32 %t232, %t234
  br i1 %t235, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l137, !tbaa !29
  %t238 = load i32, ptr %l1, !tbaa !23
  store i32 %t238, ptr %l138, !tbaa !23
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l1, !tbaa !23
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t243, ptr %l141
  br label %bb84
bb84:
  %t244 = load ptr, ptr %l137, !tbaa !29
  %t245 = load i32, ptr %l138, !tbaa !23
  %t246 = load i32, ptr %l141, !tbaa !23
  %t247 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t244, i32 %t245, i32 %t246)
  store { i64, i64 } %t247, ptr %l142
  br label %bb85
bb85:
  %t248 = load { i64, i64 }, ptr %l142
  store { i64, i64 } %t248, ptr %l19
  %t249 = getelementptr { i64, i64 }, ptr %l19, i32 0, i32 0
  %t250 = load i64, ptr %t249, !tbaa !24
  store i64 %t250, ptr %l3, !tbaa !24
  %t252 = getelementptr { i64, i64 }, ptr %l19, i32 0, i32 1
  %t253 = load i64, ptr %t252, !tbaa !24
  store i64 %t253, ptr %l4, !tbaa !24
  br label %bb141
bb86:
  %t255 = load i32, ptr %l5
  %t257 = trunc i64 24 to i32
  %t258 = icmp eq i32 %t255, %t257
  br i1 %t258, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb92
bb89:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l147, !tbaa !29
  %t261 = load i32, ptr %l1, !tbaa !23
  store i32 %t261, ptr %l148, !tbaa !23
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i32, ptr %l1, !tbaa !23
  %t266 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t262, i32 %t263)
  store i32 %t266, ptr %l151
  br label %bb90
bb90:
  %t267 = load ptr, ptr %l147, !tbaa !29
  %t268 = load i32, ptr %l148, !tbaa !23
  %t269 = load i32, ptr %l151, !tbaa !23
  %t270 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t267, i32 %t268, i32 %t269)
  store { i64, i64 } %t270, ptr %l152
  br label %bb91
bb91:
  %t271 = load { i64, i64 }, ptr %l152
  store { i64, i64 } %t271, ptr %l20
  %t272 = getelementptr { i64, i64 }, ptr %l20, i32 0, i32 0
  %t273 = load i64, ptr %t272, !tbaa !24
  store i64 %t273, ptr %l3, !tbaa !24
  %t275 = getelementptr { i64, i64 }, ptr %l20, i32 0, i32 1
  %t276 = load i64, ptr %t275, !tbaa !24
  store i64 %t276, ptr %l4, !tbaa !24
  br label %bb141
bb92:
  %t278 = load i32, ptr %l5
  %t280 = trunc i64 18 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb136
bb95:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i32, ptr %l1, !tbaa !23
  %t287 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t283, i32 %t284)
  store i1 %t287, ptr %l159
  br label %bb96
bb96:
  %t288 = load i1, ptr %l159, !tbaa !21
  %t289 = xor i1 %t288, true
  br i1 %t289, label %bb97, label %bb98
bb97:
  store i1 false, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l162, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i32, ptr %l1, !tbaa !23
  %t297 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t293, i32 %t294)
  store i32 %t297, ptr %l165
  br label %bb100
bb100:
  %t298 = load ptr, ptr %l162, !tbaa !29
  %t299 = load i32, ptr %l165, !tbaa !23
  %t300 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t298, i32 %t299)
  store i32 %t300, ptr %l166
  br label %bb101
bb101:
  %t301 = load i32, ptr %l166
  store i32 %t301, ptr %l21
  %t302 = load i32, ptr %l21
  %t304 = trunc i64 0 to i32
  %t305 = icmp eq i32 %t302, %t304
  br i1 %t305, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb107
bb104:
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l169, !tbaa !29
  %t308 = load i32, ptr %l1, !tbaa !23
  store i32 %t308, ptr %l170, !tbaa !23
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load i32, ptr %l1, !tbaa !23
  %t313 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t309, i32 %t310)
  store i32 %t313, ptr %l173
  br label %bb105
bb105:
  %t314 = load ptr, ptr %l169, !tbaa !29
  %t315 = load i32, ptr %l170, !tbaa !23
  %t316 = load i32, ptr %l173, !tbaa !23
  %t317 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t314, i32 %t315, i32 %t316)
  store { i64, i64 } %t317, ptr %l174
  br label %bb106
bb106:
  %t318 = load { i64, i64 }, ptr %l174
  store { i64, i64 } %t318, ptr %l22
  %t319 = getelementptr { i64, i64 }, ptr %l22, i32 0, i32 0
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l3, !tbaa !24
  %t322 = getelementptr { i64, i64 }, ptr %l22, i32 0, i32 1
  %t323 = load i64, ptr %t322, !tbaa !24
  store i64 %t323, ptr %l4, !tbaa !24
  br label %bb135
bb107:
  %t325 = load i32, ptr %l21
  %t327 = trunc i64 1 to i32
  %t328 = icmp eq i32 %t325, %t327
  br i1 %t328, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb113
bb110:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l179, !tbaa !29
  %t331 = load i32, ptr %l1, !tbaa !23
  store i32 %t331, ptr %l180, !tbaa !23
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i32, ptr %l1, !tbaa !23
  %t336 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t332, i32 %t333)
  store i32 %t336, ptr %l183
  br label %bb111
bb111:
  %t337 = load ptr, ptr %l179, !tbaa !29
  %t338 = load i32, ptr %l180, !tbaa !23
  %t339 = load i32, ptr %l183, !tbaa !23
  %t340 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t337, i32 %t338, i32 %t339)
  store { i64, i64 } %t340, ptr %l184
  br label %bb112
bb112:
  %t341 = load { i64, i64 }, ptr %l184
  store { i64, i64 } %t341, ptr %l23
  %t342 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 0
  %t343 = load i64, ptr %t342, !tbaa !24
  store i64 %t343, ptr %l3, !tbaa !24
  %t345 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 1
  %t346 = load i64, ptr %t345, !tbaa !24
  store i64 %t346, ptr %l4, !tbaa !24
  br label %bb135
bb113:
  %t348 = load i32, ptr %l21
  %t350 = trunc i64 2 to i32
  %t351 = icmp eq i32 %t348, %t350
  br i1 %t351, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb135
bb117:
  %t357 = load i32, ptr %l21
  %t359 = trunc i64 4 to i32
  %t360 = icmp eq i32 %t357, %t359
  br i1 %t360, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb128
bb120:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i32, ptr %l1, !tbaa !23
  %t366 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t362, i32 %t363)
  store i32 %t366, ptr %l195
  br label %bb121
bb121:
  %t367 = load i32, ptr %l195, !tbaa !23
  store i32 %t367, ptr %l26, !tbaa !23
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i32, ptr %l26, !tbaa !23
  %t372 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t368, i32 %t369)
  store i64 %t372, ptr %l198
  br label %bb122
bb122:
  %t373 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t374 = load i64, ptr %l198, !tbaa !24
  %t376 = icmp ne i64 %t374, %t373
  br i1 %t376, label %bb123, label %bb124
bb123:
  store i1 false, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load i32, ptr %l26, !tbaa !23
  %t383 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t379, i32 %t380)
  store i64 %t383, ptr %l204
  br label %bb126
bb126:
  %t384 = load i64, ptr %l204, !tbaa !24
  store i64 %t384, ptr %l27, !tbaa !24
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i32, ptr %l26, !tbaa !23
  %t389 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t385, i32 %t386)
  store i64 %t389, ptr %l207
  br label %bb127
bb127:
  %t390 = load i64, ptr %l207, !tbaa !24
  %t391 = load i64, ptr %l27, !tbaa !24
  store i64 %t391, ptr %l3, !tbaa !24
  store i64 %t390, ptr %l4, !tbaa !24
  br label %bb135
bb128:
  %t395 = load i32, ptr %l21
  %t397 = trunc i64 3 to i32
  %t398 = icmp eq i32 %t395, %t397
  br i1 %t398, label %bb129, label %bb130
bb129:
  br label %bb133
bb130:
  %t400 = load i32, ptr %l21
  %t402 = trunc i64 5 to i32
  %t403 = icmp eq i32 %t400, %t402
  br i1 %t403, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb134
bb133:
  store i1 false, ptr %rv
  br label %ret
bb134:
  call void @__olang_check_failed(ptr @olang_loc_448c58e2e97e944f_f556e6dbd0c75243)
  unreachable
bb135:
  br label %bb141
bb136:
  br i1 true, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  store i1 false, ptr %rv
  br label %ret
bb140:
  call void @__olang_check_failed(ptr @olang_loc_136e48f5d148640e_b95a40c005170ac2)
  unreachable
bb141:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/types:Table", ptr %t407, i32 0, i32 19
  %t410 = load i32, ptr %l1, !tbaa !23
  %t412 = sext i32 %t410 to i64
  %t413 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t409, i64 %t412, i64 %t413)
  br label %bb142
bb142:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/types:Table", ptr %t417, i32 0, i32 20
  %t420 = load i32, ptr %l1, !tbaa !23
  %t422 = sext i32 %t420 to i64
  %t423 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t419, i64 %t422, i64 %t423)
  br label %bb143
bb143:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  %t4 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 26, i64 %t4, i64 %a2, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l8
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t10, %"compiler/types:data" %t11, i32 1)
  store i32 %t12, ptr %l9
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l29 = alloca %"compiler/types:data"
  %l30 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 12
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/types:Table", ptr %t18, i32 0, i32 11
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l13
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t23 = load i64, ptr %l13, !tbaa !24
  store i64 %t23, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/types:Table", ptr %t24, i32 0, i32 11
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t29, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t26, { i64, ptr } %t40)
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/types:Table", ptr %t43, i32 0, i32 12
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/types:Table", ptr %t46, i32 0, i32 11
  %t49 = load i64, ptr %l2, !tbaa !24
  %t52 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load ptr, ptr %l20, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t55, i64 %t53)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l26, !tbaa !29
  %t58 = load i64, ptr %l2, !tbaa !24
  %t61 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 27, i64 %t58, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t61, ptr %l29
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l26, !tbaa !29
  %t63 = load %"compiler/types:data", ptr %l29
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t62, %"compiler/types:data" %t63, i32 1)
  store i32 %t64, ptr %l30
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i32, ptr %l30, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 2
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:decl"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 13
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:decl" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/types:decl", ptr %l6, i32 0, i32 3
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDepth(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = sext i32 %t6 to i64
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 3
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i32
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca i32
  %l84 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i32
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l117 = alloca i32
  %l118 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l21
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l2
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l24
  br label %bb2
bb2:
  %t9 = load i32, ptr %l24
  store i32 %t9, ptr %l3
  %t10 = load i32, ptr %l3
  %t12 = trunc i64 18 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb44
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l27, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l30
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l27, !tbaa !29
  %t22 = load i32, ptr %l30, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l31
  br label %bb7
bb7:
  %t24 = load i32, ptr %l31
  store i32 %t24, ptr %l4
  %t25 = load i32, ptr %l4
  %t27 = trunc i64 0 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l34, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l37
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l34, !tbaa !29
  %t37 = load i32, ptr %l37, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t38, ptr %l38
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t39, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t52, ptr %l45, !tbaa !27
  %t53 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 %t53
  %t58 = load i32, ptr %t57, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t58)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t63 = load i64, ptr %l6, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l6, !tbaa !24
  br label %bb13
bb19:
  br label %bb43
bb20:
  %t67 = load i32, ptr %l4
  %t69 = trunc i64 1 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb36
bb23:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l54, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l57
  br label %bb24
bb24:
  %t78 = load ptr, ptr %l54, !tbaa !29
  %t79 = load i32, ptr %l57, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l58
  br label %bb25
bb25:
  %t81 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t81, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t94, ptr %l65, !tbaa !27
  %t95 = load i64, ptr %l10, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  store i32 %t100, ptr %l12, !tbaa !23
  %t102 = load i32, ptr %l12, !tbaa !23
  %t104 = icmp ne i32 %t102, 0
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t106)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  %t109 = load i64, ptr %l10, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l10, !tbaa !24
  br label %bb26
bb35:
  br label %bb43
bb36:
  %t113 = load i32, ptr %l4
  %t115 = trunc i64 4 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb42
bb39:
  store ptr %l2, ptr %l76, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l1, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l79
  br label %bb40
bb40:
  %t123 = load ptr, ptr %l76, !tbaa !29
  %t124 = load i32, ptr %l79, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t123, i32 %t124)
  br label %bb41
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb86
bb44:
  %t125 = load i32, ptr %l3
  %t127 = trunc i64 19 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb54
bb47:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l84
  br label %bb48
bb48:
  %t135 = load i32, ptr %l84, !tbaa !23
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb49, label %bb50
bb49:
  store ptr %l2, ptr %l86, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l1, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l89
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t143 = load ptr, ptr %l86, !tbaa !29
  %t144 = load i32, ptr %l89, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t143, i32 %t144)
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb86
bb54:
  %t145 = load i32, ptr %l3
  %t147 = trunc i64 22 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  %t150 = load i32, ptr %l3
  %t152 = trunc i64 23 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb69
bb59:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l94, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l1, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l97
  br label %bb60
bb60:
  %t161 = load ptr, ptr %l94, !tbaa !29
  %t162 = load i32, ptr %l97, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t161, i32 %t162)
  store { i64, ptr } %t163, ptr %l98
  br label %bb61
bb61:
  %t164 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t164, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l15, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s17
  %t169 = load i64, ptr %l14, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s17)
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t177, ptr %l105, !tbaa !27
  %t178 = load i64, ptr %l14, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 %t178
  %t183 = load i32, ptr %t182, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t183)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s17)
  br label %bb67
bb67:
  %t188 = load i64, ptr %l14, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l14, !tbaa !24
  br label %bb62
bb68:
  br label %bb86
bb69:
  %t192 = load i32, ptr %l3
  %t194 = trunc i64 24 to i32
  %t195 = icmp eq i32 %t192, %t194
  br i1 %t195, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb85
bb72:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l114, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i32, ptr %l1, !tbaa !23
  %t202 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t198, i32 %t199)
  store i32 %t202, ptr %l117
  br label %bb73
bb73:
  %t203 = load ptr, ptr %l114, !tbaa !29
  %t204 = load i32, ptr %l117, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t203, i32 %t204)
  store { i64, ptr } %t205, ptr %l118
  br label %bb74
bb74:
  %t206 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t206, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  store i64 %t209, ptr %l19, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s21
  %t211 = load i64, ptr %l18, !tbaa !24
  %t212 = load i64, ptr %l19, !tbaa !24
  %t215 = icmp slt i64 %t211, %t212
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s21)
  br label %bb84
bb77:
  br label %bb78
bb78:
  %t219 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t219, ptr %l125, !tbaa !27
  %t220 = load i64, ptr %l18, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i32, ptr %t223, i64 %t220
  %t225 = load i32, ptr %t224, !tbaa !33
  store i32 %t225, ptr %l20, !tbaa !23
  %t227 = load i32, ptr %l20, !tbaa !23
  %t229 = icmp ne i32 %t227, 0
  br i1 %t229, label %bb79, label %bb80
bb79:
  %t231 = load i32, ptr %l20, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t231)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s21)
  br label %bb83
bb83:
  %t234 = load i64, ptr %l18, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l18, !tbaa !24
  br label %bb75
bb84:
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t239 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t239, ptr %l135
  br label %bb87
bb87:
  %t240 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t240, ptr %l136, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l137, !tbaa !24
  %t243 = load i64, ptr %l137, !tbaa !24
  %t244 = mul i64 %t243, 4
  %t245 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l138, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l137, !tbaa !24
  %t253 = mul i64 %t252, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t254, ptr %l136, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t255 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t255, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 28 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  %t16 = sub i64 0, 1
  store i64 %t16, ptr %l7, !tbaa !65
  br label %bb5
bb4:
  %t18 = load i64, ptr %l10, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !65
  br label %bb5
bb5:
  %t20 = load i64, ptr %l7, !tbaa !65
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 28 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = trunc i64 %t18 to i32
  store i32 %t19, ptr %l7, !tbaa !23
  br label %bb5
bb5:
  %t22 = load i32, ptr %l7, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  %t4 = sext i32 %a1 to i64
  %t10 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 28, i64 %t4, i64 %a2, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load %"compiler/types:data", ptr %l9
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t11, %"compiler/types:data" %t12, i32 1)
  store i32 %t13, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i32, ptr %l10, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eC(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFindDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 15
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H25f20ec7bc3952e7f71d4b5fc38b1e45(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  store i32 %t12, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, i32 } zeroinitializer, i32 %t21, 0
  store { i32, i32 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load i32, ptr %l2, !tbaa !23
  %t25 = insertvalue { i32, i32 } zeroinitializer, i32 %t24, 1
  store { i32, i32 } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load i32, ptr %l12, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load i32, ptr %l15
  %t27 = trunc i64 18 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb11
bb9:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i32, ptr %l22, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l23
  br label %bb10
bb10:
  %t39 = load i32, ptr %l23
  %t41 = trunc i64 5 to i32
  %t42 = icmp eq i32 %t39, %t41
  store i1 %t42, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l18, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l32 = alloca %"compiler/types:data"
  %l35 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i32
  %l44 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l56 = alloca ptr
  %l58 = alloca i64
  %l63 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i32, ptr %l12, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = load i32, ptr %l15, !tbaa !23
  %t15 = icmp sgt i32 %t13, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l20
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t22 = load i32, ptr %l20, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t27 = load i32, ptr %l2, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t30 = load i32, ptr %l3, !tbaa !23
  %t32 = sext i32 %t30 to i64
  %t33 = load i32, ptr %l4, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load i64, ptr %l5, !tbaa !24
  %t43 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 21, i64 %t26, i64 %t29, i64 %t32, i64 %t35, i64 %t36)
  store %"compiler/types:data" %t43, ptr %l32
  br label %bb7
bb7:
  %t44 = load i32, ptr %l6, !tbaa !23
  %t46 = add i32 %t44, 1
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load %"compiler/types:data", ptr %l32
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t47, %"compiler/types:data" %t48, i32 %t46)
  store i32 %t50, ptr %l35
  br label %bb8
bb8:
  %t51 = load i32, ptr %l35, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l38
  br label %bb9
bb9:
  %t57 = load i32, ptr %l38, !tbaa !23
  store i32 %t57, ptr %l8, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l41
  br label %bb10
bb10:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %l9, !tbaa !23
  %t64 = load i32, ptr %l4, !tbaa !23
  %t66 = icmp ne i32 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb13
bb12:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = icmp ne i64 %t68, 0
  store i1 %t70, ptr %l44, !tbaa !21
  br label %bb13
bb13:
  %t72 = load i1, ptr %l44, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i32, ptr %l8, !tbaa !23
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = icmp ne i32 %t73, %t74
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb19
bb18:
  %t80 = load i32, ptr %l9, !tbaa !23
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = icmp ne i32 %t80, %t81
  store i1 %t84, ptr %l51, !tbaa !21
  br label %bb19
bb19:
  %t86 = load i1, ptr %l51, !tbaa !21
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/types:Table", ptr %t87, i32 0, i32 25
  store ptr %t89, ptr %l56, !tbaa !29
  %t90 = load i32, ptr %l7, !tbaa !23
  %t92 = sext i32 %t90 to i64
  store i64 %t92, ptr %l58, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t95 = load i32, ptr %l9, !tbaa !23
  %t96 = load i32, ptr %l3, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t93, i32 %t94, i32 %t95, i32 %t96, i32 0, i64 0)
  store i32 %t101, ptr %l63
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t102 = load ptr, ptr %l56, !tbaa !29
  %t103 = load i64, ptr %l58, !tbaa !24
  %t104 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t102, i64 %t103, i32 %t104)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t105 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:body"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:body" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:body", ptr %l4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  %t29 = icmp ne i32 %t25, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb2
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l41 = alloca i1
  %l48 = alloca i1
  %l51 = alloca i1
  %l56 = alloca i8
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l75 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca i1
  %l82 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i1
  %l89 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i1
  %l96 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca i1
  %l105 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca i1
  %l112 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i32
  %l121 = alloca i8
  %l123 = alloca i8
  %l124 = alloca ptr
  %l127 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9
  store i32 %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i1, ptr %l12, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load i32, ptr %l2
  %t16 = trunc i64 20 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  %t19 = load i32, ptr %l2
  %t21 = trunc i64 21 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb11
bb10:
  %t25 = load i32, ptr %l2
  %t27 = trunc i64 25 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb14
bb13:
  %t31 = load i32, ptr %l2
  %t33 = trunc i64 29 to i32
  %t34 = icmp eq i32 %t31, %t33
  store i1 %t34, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t38 = load i32, ptr %l2
  %t40 = trunc i64 18 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb18, label %bb19
bb18:
  %t45 = load i32, ptr %l2
  %t47 = trunc i64 19 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb21, label %bb22
bb21:
  %t53 = load i32, ptr %l2
  %t55 = trunc i64 22 to i32
  %t56 = icmp eq i32 %t53, %t55
  %t58 = xor i1 %t56, true
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb23
bb23:
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb24, label %bb25
bb24:
  %t61 = load i32, ptr %l2
  %t63 = trunc i64 23 to i32
  %t64 = icmp eq i32 %t61, %t63
  %t66 = xor i1 %t64, true
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb26
bb26:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  %t69 = load i32, ptr %l2
  %t71 = trunc i64 24 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  store i1 %t74, ptr %l41, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t78 = load i32, ptr %l2
  %t80 = trunc i64 18 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb33, label %bb34
bb33:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l51
  br label %bb35
bb34:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb36
bb35:
  %t88 = load i1, ptr %l51, !tbaa !21
  %t89 = xor i1 %t88, true
  store i1 %t89, ptr %l48, !tbaa !21
  br label %bb36
bb36:
  %t91 = load i1, ptr %l48, !tbaa !21
  br i1 %t91, label %bb37, label %bb38
bb37:
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l1, !tbaa !23
  %t97 = call i8 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsState(ptr %v0, ptr %t93, i32 %t94)
  store i8 %t97, ptr %l56
  br label %bb40
bb40:
  %t98 = load i8, ptr %l56, !tbaa !22
  store i8 %t98, ptr %l3, !tbaa !22
  %t99 = load i8, ptr %l3, !tbaa !22
  %t101 = icmp ne i8 %t99, 0
  br i1 %t101, label %bb41, label %bb42
bb41:
  %t103 = load i8, ptr %l3, !tbaa !22
  %t105 = icmp eq i8 %t103, 3
  store i1 %t105, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %t107, i32 %t108, i8 1)
  br label %bb44
bb44:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/types:Table", ptr %t111, i32 0, i32 31
  %t114 = load i1, ptr %t113, !tbaa !21
  store i1 %t114, ptr %l4, !tbaa !21
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/types:Table", ptr %t116, i32 0, i32 31
  store i1 false, ptr %t118, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  %t119 = load i32, ptr %l2
  %t121 = trunc i64 18 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb69
bb47:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l68, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l1, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l71
  br label %bb48
bb48:
  %t130 = load ptr, ptr %l68, !tbaa !29
  %t131 = load i32, ptr %l71, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t132, ptr %l72
  br label %bb49
bb49:
  %t133 = load i32, ptr %l72
  store i32 %t133, ptr %l6
  %t134 = load i32, ptr %l6
  %t136 = trunc i64 0 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l75, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l1, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t144, ptr %l78
  br label %bb53
bb53:
  %t145 = load ptr, ptr %l75, !tbaa !29
  %t146 = load i32, ptr %l78, !tbaa !23
  %t147 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t145, i32 %t146, i1 false)
  store i1 %t147, ptr %l79
  br label %bb54
bb54:
  %t148 = load i1, ptr %l79, !tbaa !21
  store i1 %t148, ptr %l5, !tbaa !21
  br label %bb68
bb55:
  %t149 = load i32, ptr %l6
  %t151 = trunc i64 1 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l82, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l1, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l85
  br label %bb59
bb59:
  %t160 = load ptr, ptr %l82, !tbaa !29
  %t161 = load i32, ptr %l85, !tbaa !23
  %t162 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t160, i32 %t161, i1 true)
  store i1 %t162, ptr %l86
  br label %bb60
bb60:
  %t163 = load i1, ptr %l86, !tbaa !21
  store i1 %t163, ptr %l5, !tbaa !21
  br label %bb68
bb61:
  %t164 = load i32, ptr %l6
  %t166 = trunc i64 4 to i32
  %t167 = icmp eq i32 %t164, %t166
  br i1 %t167, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l89, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l1, !tbaa !23
  %t174 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t174, ptr %l92
  br label %bb65
bb65:
  %t175 = load ptr, ptr %l89, !tbaa !29
  %t176 = load i32, ptr %l92, !tbaa !23
  %t177 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t175, i32 %t176)
  store i1 %t177, ptr %l93
  br label %bb66
bb66:
  %t178 = load i1, ptr %l93, !tbaa !21
  store i1 %t178, ptr %l5, !tbaa !21
  br label %bb68
bb67:
  br label %bb68
bb68:
  br label %bb90
bb69:
  %t179 = load i32, ptr %l2
  %t181 = trunc i64 19 to i32
  %t182 = icmp eq i32 %t179, %t181
  br i1 %t182, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l96, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l99
  br label %bb73
bb73:
  %t190 = load ptr, ptr %l96, !tbaa !29
  %t191 = load i32, ptr %l99, !tbaa !23
  %t192 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t192, ptr %l100
  br label %bb74
bb74:
  %t193 = load i1, ptr %l100, !tbaa !21
  store i1 %t193, ptr %l5, !tbaa !21
  br label %bb90
bb75:
  %t194 = load i32, ptr %l2
  %t196 = trunc i64 22 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb76, label %bb77
bb76:
  br label %bb80
bb77:
  %t199 = load i32, ptr %l2
  %t201 = trunc i64 23 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l105, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l1, !tbaa !23
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t205, i32 %t206)
  store i32 %t209, ptr %l108
  br label %bb81
bb81:
  %t210 = load ptr, ptr %l105, !tbaa !29
  %t211 = load i32, ptr %l108, !tbaa !23
  %t212 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t210, i32 %t211, i1 false)
  store i1 %t212, ptr %l109
  br label %bb82
bb82:
  %t213 = load i1, ptr %l109, !tbaa !21
  store i1 %t213, ptr %l5, !tbaa !21
  br label %bb90
bb83:
  %t214 = load i32, ptr %l2
  %t216 = trunc i64 24 to i32
  %t217 = icmp eq i32 %t214, %t216
  br i1 %t217, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l112, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t220, i32 %t221)
  store i32 %t224, ptr %l115
  br label %bb87
bb87:
  %t225 = load ptr, ptr %l112, !tbaa !29
  %t226 = load i32, ptr %l115, !tbaa !23
  %t227 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t225, i32 %t226, i1 true)
  store i1 %t227, ptr %l116
  br label %bb88
bb88:
  %t228 = load i1, ptr %l116, !tbaa !21
  store i1 %t228, ptr %l5, !tbaa !21
  br label %bb90
bb89:
  br label %bb90
bb90:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l117, !tbaa !29
  %t230 = load i32, ptr %l1, !tbaa !23
  store i32 %t230, ptr %l118, !tbaa !23
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/types:Table", ptr %t231, i32 0, i32 31
  %t234 = load i1, ptr %t233, !tbaa !21
  br i1 %t234, label %bb91, label %bb92
bb91:
  store i8 0, ptr %l121, !tbaa !22
  br label %bb96
bb92:
  %t236 = load i1, ptr %l5, !tbaa !21
  br i1 %t236, label %bb93, label %bb94
bb93:
  store i8 3, ptr %l123, !tbaa !22
  br label %bb95
bb94:
  store i8 2, ptr %l123, !tbaa !22
  br label %bb95
bb95:
  %t238 = load i8, ptr %l123, !tbaa !22
  store i8 %t238, ptr %l121, !tbaa !22
  br label %bb96
bb96:
  %t239 = load ptr, ptr %l117, !tbaa !29
  %t240 = load i32, ptr %l118, !tbaa !23
  %t241 = load i8, ptr %l121, !tbaa !22
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %t239, i32 %t240, i8 %t241)
  br label %bb97
bb97:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l124, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/types:Table", ptr %t243, i32 0, i32 31
  %t246 = load i1, ptr %t245, !tbaa !21
  br i1 %t246, label %bb98, label %bb99
bb98:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb100
bb99:
  %t248 = load i1, ptr %l4, !tbaa !21
  store i1 %t248, ptr %l127, !tbaa !21
  br label %bb100
bb100:
  %t250 = load i1, ptr %l127, !tbaa !21
  %t251 = load ptr, ptr %l124, !tbaa !29
  %t252 = getelementptr %"compiler/types:Table", ptr %t251, i32 0, i32 31
  store i1 %t250, ptr %t252, !tbaa !21
  %t253 = load i1, ptr %l5, !tbaa !21
  store i1 %t253, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb4:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load i32, ptr %l11, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i32, ptr %l12
  %t22 = trunc i64 29 to i32
  %t23 = icmp eq i32 %t20, %t22
  store i1 %t23, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l7, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 11
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 14
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 3
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 10
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t19 = and i64 %t17, %t16
  %t21 = icmp ne i64 %t19, 0
  store i1 %t21, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l7, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 3
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 14
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 7
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp sle i32 %t5, 10
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 5
  %t6 = sext i32 %a1 to i64
  %t9 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store { i64, ptr } %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 0
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 18
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l24 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l63 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/types:Table", ptr %t8, i32 0, i32 6
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  %t15 = extractvalue { i32, i32 } %t14, 1
  %t16 = extractvalue { i32, i32 } %t14, 0
  store i32 %t16, ptr %l19
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18
ok.18:
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t19 = load i32, ptr %l18, !tbaa !23
  store i32 %t19, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t20 = load i32, ptr %l14, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  %t21 = load i32, ptr %l2, !tbaa !23
  %t23 = icmp sge i32 %t21, 0
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load i32, ptr %l2, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp sle i64 %t33, 2305843009213693951
  br i1 %t34, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_aca21d9f8d110f21_d35bd7e73631d7ed)
  unreachable
bb13:
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = mul i64 %t36, 4
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_aca21d9f8d110f21_d35bd7e73631d7ed)
  unreachable
bb15:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb20
bb17:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l36, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb19
bb19:
  %t72 = load i64, ptr %l36, !tbaa !24
  store i64 %t72, ptr %l33, !tbaa !24
  br label %bb20
bb20:
  %t73 = load i64, ptr %l33, !tbaa !24
  store i64 %t73, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t94, ptr %l56, !tbaa !27
  %t95 = load i64, ptr %l9, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t103 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i32, ptr %t104, i64 %t93
  store i32 %t100, ptr %t105, !tbaa !33
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb21
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/types:Table", ptr %t110, i32 0, i32 5
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_H503e6d35c0db63145eb2ca8ce5f41f51(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l63
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  %t116 = trunc i64 %t115 to i32
  store i32 %t116, ptr %l2, !tbaa !23
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/types:Table", ptr %t119, i32 0, i32 5
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v0, ptr %v0, ptr %t121, { i64, ptr } %t122)
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/types:Table", ptr %t125, i32 0, i32 6
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v0, ptr %t127, { i64, ptr } %t128, i32 %t129)
  br label %bb29
bb29:
  %t133 = load i32, ptr %l2, !tbaa !23
  store i32 %t133, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = mul i64 1, 4
  %t4 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t3)
  %t5 = insertvalue { i64, ptr } undef, i64 1, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t4, 1
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i32, ptr %t9, i64 0
  store i32 %a1, ptr %t10, !tbaa !33
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } %t12)
  store i32 %t13, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i32, ptr %l5, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/types:Table", ptr %t5, i32 0, i32 24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store { i64, ptr } %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr @.d5 })
  store i1 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l14
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/types:Table", ptr %t25, i32 0, i32 24
  store ptr %t27, ptr %l16, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l20
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t41 = load ptr, ptr %l16, !tbaa !29
  %t42 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v0, ptr %t41, i64 %t42, { i64, ptr } %t40)
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/types:Table", ptr %t44, i32 0, i32 24
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t46, i64 %t47)
  store { i64, ptr } %t50, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l13 = alloca %"compiler/types:data"
  %l16 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t10 = sext i32 %a1 to i64
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t17 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 18, i64 %t10, i64 %t13, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t17, ptr %l13
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l16
  br label %bb3
bb3:
  %t23 = load i32, ptr %l16, !tbaa !23
  %t24 = add i32 %t23, 1
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load %"compiler/types:data", ptr %l13
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t25, %"compiler/types:data" %t26, i32 %t24)
  store i32 %t28, ptr %l18
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l18, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i64
  %l10 = alloca %"compiler/types:data"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t11, i32 %t12)
  store %"compiler/types:data" %t15, ptr %l10
  br label %bb4
bb3:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb5
bb4:
  %t16 = getelementptr %"compiler/types:data", ptr %l10, i32 0, i32 5
  %t17 = load i64, ptr %t16, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t19 = load i64, ptr %l7, !tbaa !24
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l12 = alloca %"compiler/types:data"
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/types:Table", ptr %t11, i32 0, i32 28
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t14, i32 %t15)
  store %"compiler/types:data" %t18, ptr %l12
  br label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/types:Table", ptr %t19, i32 0, i32 28
  %t23 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t21, i64 0)
  store { i64, ptr } %t23, ptr %l17
  br label %bb6
bb4:
  %t24 = getelementptr %"compiler/types:data", ptr %l12, i32 0, i32 5
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load ptr, ptr %l9, !tbaa !29
  %t28 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t26, i64 %t25)
  store { i64, ptr } %t28, ptr %l14
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t29, ptr %l7, !tbaa !27
  br label %bb7
bb6:
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t30, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i64
  %l17 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i32, ptr %l1, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t24 = xor i64 %t22, -1
  %t25 = load i64, ptr %l13, !tbaa !24
  %t27 = and i64 %t25, %t24
  %t28 = load ptr, ptr %l7, !tbaa !29
  %t29 = load i32, ptr %l10, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t28, i32 %t29, i64 %t27)
  store i32 %t31, ptr %l17
  br label %bb7
bb7:
  %t32 = load i32, ptr %l17, !tbaa !23
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l25 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca i64
  %l60 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldList(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i32, ptr %l14, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l17, !tbaa !24
  %t14 = load i64, ptr %l17, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  br i1 %t18, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ecef2c1188620c25_f6c5d2506e285511)
  unreachable
bb5:
  %t20 = load i64, ptr %l17, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t25, ptr %lp3
  %t27 = load ptr, ptr %lp3
  store { i64, ptr } %t24, ptr %t27, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/types:Table", ptr %t28, i32 0, i32 21
  %t31 = load i32, ptr %l1, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t33)
  store i64 %t36, ptr %l25
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_ecef2c1188620c25_f6c5d2506e285511)
  unreachable
bb7:
  %t37 = load i64, ptr %l25, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t38, 0
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %lp3
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i64 0, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l2, !tbaa !24
  store i64 %t45, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb16
bb13:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = sub i64 %t57, %t58
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = add i64 %t61, %t62
  %t67 = sub i64 %t65, 1
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = sdiv i64 %t67, %t68
  store i64 %t71, ptr %l36, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb15
bb15:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t74 = load i64, ptr %l33, !tbaa !24
  store i64 %t74, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t83 = load i64, ptr %l5, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = mul i64 %t84, %t85
  %t91 = add i64 %t83, %t88
  store i64 %t91, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  store i64 %t93, ptr %l54, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/types:Table", ptr %t94, i32 0, i32 22
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t104 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t96, i64 %t101)
  store i64 %t104, ptr %l60
  br label %bb21
bb21:
  %t105 = load i64, ptr %l60, !tbaa !24
  %t106 = load ptr, ptr %lp3
  %t107 = load i64, ptr %l54, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i64, ptr %t109, i64 %t107
  store i64 %t105, ptr %t110, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t111 = load i64, ptr %l9, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l9, !tbaa !24
  br label %bb17
bb23:
  %t115 = load ptr, ptr %lp3
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca i64
  %l26 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l11
  br label %bb4
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load i1, ptr %l15, !tbaa !21
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l12, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l20
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l23
  br label %bb14
bb14:
  %t40 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t41 = load i64, ptr %l23, !tbaa !24
  %t43 = or i64 %t41, %t40
  %t44 = load ptr, ptr %l17, !tbaa !29
  %t45 = load i32, ptr %l20, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t44, i32 %t45, i64 %t43)
  store i32 %t47, ptr %l26
  br label %bb15
bb15:
  %t48 = load i32, ptr %l26, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i32
  %l63 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l15, !tbaa !24
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = icmp sle i64 %t14, 1152921504606846975
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6b6356ebbaa556b4_537d1793e4121070)
  unreachable
bb6:
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = mul i64 %t17, 8
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6b6356ebbaa556b4_537d1793e4121070)
  unreachable
bb8:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb13
bb10:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l27, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb12
bb12:
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l24, !tbaa !24
  br label %bb13
bb13:
  %t54 = load i64, ptr %l24, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l45, !tbaa !27
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l47, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i64, ptr %t79, i64 %t76
  %t81 = load i64, ptr %t80, !tbaa !34
  %t84 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t74
  store i64 %t81, ptr %t86, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb14
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/types:Table", ptr %t91, i32 0, i32 29
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t97 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t93, { i64, ptr } %t94)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l57
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb21, label %ok.101
ok.101:
  store i64 %t98, ptr %l56
  br label %bb20
bb20:
  %t102 = load i64, ptr %l56, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t103 = load i64, ptr %l52, !tbaa !24
  store i64 %t103, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = icmp sge i64 %t104, 0
  br i1 %t106, label %bb24, label %bb25
bb24:
  %t108 = load i64, ptr %l9, !tbaa !24
  store i64 %t108, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/types:Table", ptr %t110, i32 0, i32 28
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l63
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  store i64 %t115, ptr %l9, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/types:Table", ptr %t116, i32 0, i32 28
  %t119 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t118, { i64, ptr } %t119)
  br label %bb28
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/types:Table", ptr %t122, i32 0, i32 29
  %t125 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t126 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t124, { i64, ptr } %t125, i64 %t126)
  br label %bb29
bb29:
  %t130 = load i64, ptr %l9, !tbaa !24
  store i64 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l28 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 %t26
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l24
  br label %bb8
bb8:
  %t38 = load i1, ptr %l24, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 109)
  br label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l28
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t45 = load i32, ptr %l28
  %t47 = trunc i64 21 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 115)
  br label %bb15
bb14:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 118)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb4
bb20:
  %t57 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t57, ptr %l36
  br label %bb21
bb21:
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = mul i64 %t61, 1
  %t63 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l39, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = mul i64 %t70, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t72, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t73 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 23
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 25
  %t6 = sext i32 %a1 to i64
  %t9 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3, i64 %t6)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca i32
  %l40 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca i32
  %l80 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i1 true, ptr %l3, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  store i32 %t27, ptr %l7, !tbaa !23
  %t29 = load i1, ptr %l3, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l32
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i32, ptr %l7, !tbaa !23
  %t37 = load i32, ptr %l32, !tbaa !23
  %t39 = icmp eq i32 %t37, %t36
  store i1 %t39, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l29, !tbaa !21
  store i1 %t41, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb2
bb11:
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t48, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l40, !tbaa !24
  %t53 = load i64, ptr %l40, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load i64, ptr %l40, !tbaa !24
  %t57 = icmp sle i64 %t56, 2305843009213693951
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f884bd4f1b6015d_20014de591249a11)
  unreachable
bb17:
  %t59 = load i64, ptr %l40, !tbaa !24
  %t60 = mul i64 %t59, 4
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f884bd4f1b6015d_20014de591249a11)
  unreachable
bb19:
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb24
bb21:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l11, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l52, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t95 = load i64, ptr %l52, !tbaa !24
  store i64 %t95, ptr %l49, !tbaa !24
  br label %bb24
bb24:
  %t96 = load i64, ptr %l49, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  store i64 %t115, ptr %l70, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t117, ptr %l72, !tbaa !27
  %t118 = load i64, ptr %l14, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i32, ptr %t121, i64 %t118
  %t123 = load i32, ptr %t122, !tbaa !33
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t116, i32 %t123)
  store i32 %t126, ptr %l75
  br label %bb29
bb29:
  %t127 = load i32, ptr %l75, !tbaa !23
  %t128 = load i64, ptr %l70, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t128
  store i32 %t127, ptr %t131, !tbaa !33
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l13, !tbaa !24
  br label %bb25
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t136, { i64, ptr } %t137)
  store i32 %t140, ptr %l80
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l80, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l35 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l2, !tbaa !24
  store i64 15, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimNames, i64 0, i64 %t47
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !37
  %t52 = load ptr, ptr @__olang_prog_scope
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t52, ptr %v1, { i64, ptr } %t50, { i64, ptr } %a1)
  store i1 %t55, ptr %l35
  br label %bb11
bb11:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb12, label %bb13
bb12:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = trunc i64 %t57 to i32
  call void @__olang_scope_close(ptr %s2)
  store i32 %t59, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb7
bb16:
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l11 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 23, i64 %t4, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = add i32 %t13, 1
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l8
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t14)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 25
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t43, i64 %t44, i32 %t45)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l12 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load i64, ptr %l2, !tbaa !24
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 20, i64 %t4, i64 %t5, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = add i32 %t15, 1
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load %"compiler/types:data", ptr %l9
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t17, %"compiler/types:data" %t18, i32 %t16)
  store i32 %t20, ptr %l14
  br label %bb3
bb3:
  %t21 = load i32, ptr %l14, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb4
bb4:
  %t27 = load i32, ptr %l1, !tbaa !23
  %t28 = load i32, ptr %l17, !tbaa !23
  %t30 = icmp ne i32 %t28, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 25
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l27
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i32, ptr %l27, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t45, i32 %t46, i64 %t44)
  store i32 %t48, ptr %l29
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = load i32, ptr %l29, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t49, i64 %t50, i32 %t51)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t52 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l2, !tbaa !23
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i32, ptr %l6
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l10, !tbaa !29
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t21, ptr %l14
  br label %bb6
bb6:
  %t22 = load i32, ptr %l14
  %t24 = trunc i64 4 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l9, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l20
  br label %bb10
bb9:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t34 = load i1, ptr %l17, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb15
bb15:
  %t42 = load i32, ptr %l24, !tbaa !23
  store i32 %t42, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb1
bb17:
  %t43 = load i32, ptr %l2, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 26
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 1
  %t30 = load i64, ptr %t29, !tbaa !34
  %t32 = add i64 2, %t30
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t36, %t39
  store i1 %t42, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l17, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i64, ptr %t48, i64 1
  %t50 = load i64, ptr %t49, !tbaa !34
  %t52 = add i64 2, %t50
  %t53 = load i64, ptr %l2, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i64, ptr %t59, i64 %t56
  %t61 = load i64, ptr %t60, !tbaa !34
  store i64 %t61, ptr %l26, !tbaa !24
  br label %bb11
bb10:
  %t63 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t63, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l26, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i32
  %l22 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l62 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i32, ptr %l13, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t15 = icmp sle i64 0, 2305843009213693951
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f7b42ec29d1607_26e89eedc9b3128b)
  unreachable
bb6:
  %t17 = mul i64 0, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f7b42ec29d1607_26e89eedc9b3128b)
  unreachable
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l22
  br label %bb9
bb9:
  %t27 = load i32, ptr %l22
  %t29 = trunc i64 22 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l25, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l28
  br label %bb12
bb11:
  br label %bb30
bb12:
  %t38 = load ptr, ptr %l25, !tbaa !29
  %t39 = load i32, ptr %l28, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t38, i32 %t39)
  store { i64, ptr } %t40, ptr %l29
  br label %bb13
bb13:
  %t41 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t41, ptr %l3, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l31, !tbaa !24
  %t45 = load i64, ptr %l31, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load i64, ptr %l31, !tbaa !24
  %t49 = icmp sle i64 %t48, 2305843009213693951
  br i1 %t49, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2df495a001b30f12_f15d21f3e8677f6)
  unreachable
bb16:
  %t51 = load i64, ptr %l31, !tbaa !24
  %t52 = mul i64 %t51, 4
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t56, ptr %lp4
  %t58 = load ptr, ptr %lp4
  store { i64, ptr } %t55, ptr %t58, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2df495a001b30f12_f15d21f3e8677f6)
  unreachable
bb18:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb23
bb20:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l43, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb22
bb22:
  %t89 = load i64, ptr %l43, !tbaa !24
  store i64 %t89, ptr %l40, !tbaa !24
  br label %bb23
bb23:
  %t90 = load i64, ptr %l40, !tbaa !24
  store i64 %t90, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t91 = load i64, ptr %l9, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t99 = load i64, ptr %l5, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load i64, ptr %l10, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i32, ptr %t114, i64 %t111
  %t116 = load i32, ptr %t115, !tbaa !33
  %t118 = load ptr, ptr %lp4
  %t120 = getelementptr { i64, ptr }, ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i32, ptr %t121, i64 %t109
  store i32 %t116, ptr %t122, !tbaa !33
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t123 = load i64, ptr %l9, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l9, !tbaa !24
  br label %bb24
bb29:
  %t127 = load ptr, ptr %lp4
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %rv
  br label %ret
bb30:
  %t130 = load i32, ptr %l2, !tbaa !23
  %t131 = mul i64 1, 4
  %t132 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t131)
  %t133 = insertvalue { i64, ptr } undef, i64 1, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  store { i64, ptr } %t134, ptr %l69, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i32, ptr %t137, i64 0
  store i32 %t130, ptr %t138, !tbaa !33
  %t139 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t139, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t13, i32 %t14)
  store { i64, ptr } %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t19 = icmp sgt i64 %t17, 0
  store i1 %t19, ptr %l3, !tbaa !21
  %t21 = load i32, ptr %l2, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t25 = icmp ne i32 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l20
  br label %bb6
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l20, !tbaa !21
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load i1, ptr %l3, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  store { i64, ptr } { i64 3, ptr @.d6 }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr @.d7 }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l27, !tbaa !24
  %t42 = load i64, ptr %l27, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t53, ptr %l22, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
bb13:
  %t55 = load i1, ptr %l3, !tbaa !21
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l33
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t64 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb17:
  %t71 = load i32, ptr %l2, !tbaa !23
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t75 = icmp eq i32 %t71, %t72
  br i1 %t75, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 3, ptr @.d8 }, ptr %l38, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l40, !tbaa !24
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l41, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l40, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t91, ptr %l39, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l44
  br label %bb21
bb21:
  %t98 = extractvalue { i64, ptr } { i64 7, ptr @.d9 }, 1
  %t99 = extractvalue { i64, ptr } { i64 7, ptr @.d9 }, 0
  %t100 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 2, ptr @.d10 }, 1
  %t105 = extractvalue { i64, ptr } { i64 2, ptr @.d10 }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = getelementptr i8, ptr %t108, i64 %t102
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 26
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 0
  %t25 = load i64, ptr %t24, !tbaa !34
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb5
bb4:
  %t27 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t27, ptr %l13, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l13, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t6, i32 %a2)
  store i32 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l39 = alloca i64
  %l42 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca i1
  %l81 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l111 = alloca i64
  %l115 = alloca i1
  %l119 = alloca i1
  %l123 = alloca i1
  %l124 = alloca i1
  %l128 = alloca i1
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleDtor, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  %t14 = mul i64 1, 8
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 1, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l27, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i64, ptr %t20, i64 0
  store i64 %t13, ptr %t21, !tbaa !34
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l28
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l3
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l29, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l32
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l29, !tbaa !29
  %t33 = load i32, ptr %l32, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l33
  br label %bb7
bb7:
  %t35 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb13
bb10:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l42, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l42, !tbaa !24
  store i64 %t66, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l39, !tbaa !24
  store i64 %t67, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l10, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l1, !tbaa !23
  %t88 = load i64, ptr %l10, !tbaa !24
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t86, i32 %t87, i64 %t88)
  store i64 %t92, ptr %l63
  br label %bb18
bb18:
  %t93 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t94 = load i64, ptr %l63, !tbaa !24
  %t96 = icmp eq i64 %t94, %t93
  br i1 %t96, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l68, !tbaa !27
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t98, i32 %t105)
  store i1 %t108, ptr %l71
  br label %bb21
bb20:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb22
bb21:
  %t109 = load i1, ptr %l71, !tbaa !21
  store i1 %t109, ptr %l66, !tbaa !21
  br label %bb22
bb22:
  %t110 = load i1, ptr %l66, !tbaa !21
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t111 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t111)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l9, !tbaa !24
  br label %bb14
bb28:
  %t118 = load i64, ptr %l2, !tbaa !24
  %t119 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  store i1 %t122, ptr %l11, !tbaa !21
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l1, !tbaa !23
  %t128 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t124, i32 %t125)
  store { i64, ptr } %t128, ptr %l81
  br label %bb29
bb29:
  %t129 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t129, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb30, label %bb31
bb30:
  %t140 = load i64, ptr %l15, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb35
bb32:
  %t144 = load i64, ptr %l14, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l15, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l90, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb34
bb34:
  %t160 = load i64, ptr %l90, !tbaa !24
  store i64 %t160, ptr %l87, !tbaa !24
  br label %bb35
bb35:
  %t161 = load i64, ptr %l87, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t162 = load i64, ptr %l17, !tbaa !24
  %t163 = load i64, ptr %l16, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb38:
  br label %bb39
bb39:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t171 = load i64, ptr %l17, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l18, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i32, ptr %l1, !tbaa !23
  %t182 = load i64, ptr %l18, !tbaa !24
  %t186 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t180, i32 %t181, i64 %t182)
  store i64 %t186, ptr %l111
  br label %bb40
bb40:
  %t187 = load i64, ptr %l111, !tbaa !24
  store i64 %t187, ptr %l19, !tbaa !24
  %t188 = load i64, ptr %l19, !tbaa !24
  %t189 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t192 = icmp eq i64 %t188, %t189
  br i1 %t192, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb43
bb42:
  %t194 = load i64, ptr %l19, !tbaa !24
  %t195 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t198 = icmp eq i64 %t194, %t195
  store i1 %t198, ptr %l115, !tbaa !21
  br label %bb43
bb43:
  %t200 = load i1, ptr %l115, !tbaa !21
  br i1 %t200, label %bb44, label %bb45
bb44:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i64, ptr %l18, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t201, i32 %t207)
  store i1 %t210, ptr %l123
  br label %bb46
bb45:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb51
bb46:
  %t211 = load i1, ptr %l123, !tbaa !21
  br i1 %t211, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb50
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l18, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i32, ptr %t216, i64 %t213
  %t218 = load i32, ptr %t217, !tbaa !33
  %t221 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t212, i32 %t218)
  store i1 %t221, ptr %l128
  br label %bb49
bb49:
  %t222 = load i1, ptr %l128, !tbaa !21
  store i1 %t222, ptr %l124, !tbaa !21
  br label %bb50
bb50:
  %t223 = load i1, ptr %l124, !tbaa !21
  store i1 %t223, ptr %l119, !tbaa !21
  br label %bb51
bb51:
  %t224 = load i1, ptr %l119, !tbaa !21
  br i1 %t224, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb54
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  %t225 = load i64, ptr %l17, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l17, !tbaa !24
  br label %bb36
bb56:
  %t229 = load i1, ptr %l11, !tbaa !21
  br i1 %t229, label %bb57, label %bb58
bb57:
  %t231 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t231)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t235 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t235, ptr %l135
  br label %bb61
bb61:
  %t236 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t236, ptr %l136, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l137, !tbaa !24
  %t239 = load i64, ptr %l137, !tbaa !24
  %t240 = mul i64 %t239, 8
  %t241 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l138, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = load i64, ptr %l137, !tbaa !24
  %t249 = mul i64 %t248, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t245, ptr %t247, i64 %t249, i1 false)
  %t250 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t250, ptr %l136, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t251 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t251, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l56 = alloca { i64, ptr }
  %l60 = alloca i1
  %l73 = alloca i64
  %l80 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l89 = alloca i64
  %l92 = alloca i64
  %l110 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l123 = alloca i64
  %l126 = alloca i64
  %l144 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l155 = alloca i32
  %l159 = alloca i32
  %l160 = alloca i32
  %l166 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  store i1 %t5, ptr %l4, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l39, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i64, ptr %t25, i64 %t22
  %t27 = load i64, ptr %t26, !tbaa !34
  store i64 %t27, ptr %l8, !tbaa !24
  %t29 = load i1, ptr %l4, !tbaa !21
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  store i1 %t35, ptr %l43, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb7
bb7:
  %t37 = load i1, ptr %l43, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb1
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l56, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t57
  %t62 = load i64, ptr %t61, !tbaa !34
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = load i1, ptr %l4, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load i64, ptr %l12, !tbaa !24
  %t67 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t70 = icmp eq i64 %t66, %t67
  store i1 %t70, ptr %l60, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l60, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t73 = load i64, ptr %l10, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l10, !tbaa !24
  br label %bb10
bb18:
  %t77 = load i1, ptr %l4, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  store i32 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = add i64 2, %t82
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = add i64 %t84, %t87
  store i64 %t90, ptr %l73, !tbaa !24
  %t91 = load i64, ptr %l73, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = icmp sle i64 %t94, 1152921504606846975
  br i1 %t95, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_63e623ceae63df16_2a862fe3f0344bd2)
  unreachable
bb24:
  %t97 = load i64, ptr %l73, !tbaa !24
  %t98 = mul i64 %t97, 8
  %t99 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l13, !tbaa !27
  %t103 = load i64, ptr %l1, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t109 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t109, ptr %l80, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i64, ptr %t113, i64 0
  store i64 %t103, ptr %t114, !tbaa !34
  %t115 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t115, ptr %l82, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i64, ptr %t119, i64 1
  store i64 %t107, ptr %t120, !tbaa !34
  store i64 0, ptr %l16, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  store i64 %t123, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t125 = load i64, ptr %l17, !tbaa !24
  %t126 = load i64, ptr %l16, !tbaa !24
  %t129 = icmp sgt i64 %t125, %t126
  br i1 %t129, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_63e623ceae63df16_2a862fe3f0344bd2)
  unreachable
bb26:
  %t131 = load i64, ptr %l18, !tbaa !24
  %t133 = icmp sgt i64 %t131, 0
  br i1 %t133, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb31
bb28:
  %t135 = load i64, ptr %l17, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = sub i64 %t135, %t136
  %t140 = load i64, ptr %l18, !tbaa !24
  %t143 = add i64 %t139, %t140
  %t145 = sub i64 %t143, 1
  %t146 = load i64, ptr %l18, !tbaa !24
  %t149 = sdiv i64 %t145, %t146
  store i64 %t149, ptr %l92, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb30
bb30:
  %t151 = load i64, ptr %l92, !tbaa !24
  store i64 %t151, ptr %l89, !tbaa !24
  br label %bb31
bb31:
  %t152 = load i64, ptr %l89, !tbaa !24
  store i64 %t152, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t153 = load i64, ptr %l20, !tbaa !24
  %t154 = load i64, ptr %l19, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t161 = load i64, ptr %l16, !tbaa !24
  %t162 = load i64, ptr %l20, !tbaa !24
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = mul i64 %t162, %t163
  %t169 = add i64 %t161, %t166
  store i64 %t169, ptr %l21, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t171, ptr %l110, !tbaa !27
  %t172 = load i64, ptr %l21, !tbaa !24
  %t174 = add i64 2, %t172
  %t175 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t175, ptr %l113, !tbaa !27
  %t176 = load i64, ptr %l21, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i64, ptr %t179, i64 %t176
  %t181 = load i64, ptr %t180, !tbaa !34
  %t184 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t174
  store i64 %t181, ptr %t186, !tbaa !34
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  %t187 = load i64, ptr %l20, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l20, !tbaa !24
  br label %bb32
bb37:
  store i64 0, ptr %l22, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  store i64 %t193, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t195 = load i64, ptr %l23, !tbaa !24
  %t196 = load i64, ptr %l22, !tbaa !24
  %t199 = icmp sgt i64 %t195, %t196
  br i1 %t199, label %bb38, label %bb39
bb38:
  %t201 = load i64, ptr %l24, !tbaa !24
  %t203 = icmp sgt i64 %t201, 0
  br i1 %t203, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb43
bb40:
  %t205 = load i64, ptr %l23, !tbaa !24
  %t206 = load i64, ptr %l22, !tbaa !24
  %t209 = sub i64 %t205, %t206
  %t210 = load i64, ptr %l24, !tbaa !24
  %t213 = add i64 %t209, %t210
  %t215 = sub i64 %t213, 1
  %t216 = load i64, ptr %l24, !tbaa !24
  %t219 = sdiv i64 %t215, %t216
  store i64 %t219, ptr %l126, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb42
bb42:
  %t221 = load i64, ptr %l126, !tbaa !24
  store i64 %t221, ptr %l123, !tbaa !24
  br label %bb43
bb43:
  %t222 = load i64, ptr %l123, !tbaa !24
  store i64 %t222, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s12
  %t223 = load i64, ptr %l26, !tbaa !24
  %t224 = load i64, ptr %l25, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t231 = load i64, ptr %l22, !tbaa !24
  %t232 = load i64, ptr %l26, !tbaa !24
  %t233 = load i64, ptr %l24, !tbaa !24
  %t236 = mul i64 %t232, %t233
  %t239 = add i64 %t231, %t236
  store i64 %t239, ptr %l27, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t241, ptr %l144, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t246 = add i64 2, %t244
  %t247 = load i64, ptr %l27, !tbaa !24
  %t250 = add i64 %t246, %t247
  %t251 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t251, ptr %l150, !tbaa !27
  %t252 = load i64, ptr %l27, !tbaa !24
  %t254 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr i64, ptr %t255, i64 %t252
  %t257 = load i64, ptr %t256, !tbaa !34
  %t260 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr i64, ptr %t261, i64 %t250
  store i64 %t257, ptr %t262, !tbaa !34
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb48:
  %t263 = load i64, ptr %l26, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l26, !tbaa !24
  br label %bb44
bb49:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/types:Table", ptr %t267, i32 0, i32 27
  %t270 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t273 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v0, ptr %t269, { i64, ptr } %t270)
  %t274 = extractvalue { i32, i32 } %t273, 1
  %t275 = extractvalue { i32, i32 } %t273, 0
  store i32 %t275, ptr %l160
  %t276 = icmp ne i32 %t275, 0
  br i1 %t276, label %bb51, label %ok.277
ok.277:
  store i32 %t274, ptr %l159
  br label %bb50
bb50:
  %t278 = load i32, ptr %l159, !tbaa !23
  store i32 %t278, ptr %l155, !tbaa !23
  br label %bb53
bb51:
  br label %bb52
bb52:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l155, !tbaa !23
  br label %bb53
bb53:
  %t279 = load i32, ptr %l155, !tbaa !23
  store i32 %t279, ptr %l28, !tbaa !23
  %t280 = load i32, ptr %l28, !tbaa !23
  %t282 = icmp sge i32 %t280, 0
  br i1 %t282, label %bb54, label %bb55
bb54:
  %t284 = load i32, ptr %l28, !tbaa !23
  store i32 %t284, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/types:Table", ptr %t286, i32 0, i32 26
  %t290 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l166
  br label %bb57
bb57:
  %t291 = load i64, ptr %l166, !tbaa !24
  %t292 = trunc i64 %t291 to i32
  store i32 %t292, ptr %l28, !tbaa !23
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/types:Table", ptr %t295, i32 0, i32 26
  %t298 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t297, { i64, ptr } %t298)
  br label %bb58
bb58:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/types:Table", ptr %t301, i32 0, i32 27
  %t304 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t305 = load i32, ptr %l28, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v0, ptr %t303, { i64, ptr } %t304, i32 %t305)
  br label %bb59
bb59:
  %t309 = load i32, ptr %l28, !tbaa !23
  store i32 %t309, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i1
  %l36 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca i1
  %l47 = alloca i32
  %l52 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca i1
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l133 = alloca i64
  %l136 = alloca i64
  %l161 = alloca i64
  %l165 = alloca i64
  %l169 = alloca i1
  %l173 = alloca i1
  %l177 = alloca i1
  %l181 = alloca i1
  %l192 = alloca i1
  %l200 = alloca ptr
  %l203 = alloca i32
  %l206 = alloca i32
  %l207 = alloca i1
  %l210 = alloca ptr
  %l213 = alloca i32
  %l216 = alloca i32
  %l217 = alloca i1
  %l220 = alloca ptr
  %l223 = alloca i32
  %l224 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l228 = alloca i32
  %l229 = alloca { i64, ptr }
  %l235 = alloca i64
  %l238 = alloca i64
  %l260 = alloca i1
  %l262 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l268 = alloca i1
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb6
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l36
  br label %bb3
bb3:
  store ptr %l36, ptr %l37, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l40
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l37, !tbaa !29
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t17, ptr %l40)
  store i1 %t19, ptr %l42
  br label %bb5
bb5:
  %t20 = load i1, ptr %l42, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l33, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l33, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l47
  br label %bb10
bb10:
  %t30 = load i32, ptr %l47
  store i32 %t30, ptr %l3
  %t31 = load i32, ptr %l3
  %t33 = trunc i64 21 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb85
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t36, i32 %t37)
  store i64 %t40, ptr %l52
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l55
  br label %bb15
bb15:
  %t46 = load i64, ptr %l52, !tbaa !24
  %t47 = load i64, ptr %l55, !tbaa !24
  %t48 = icmp ne i64 %t46, %t47
  br i1 %t48, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l58, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l61
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l58, !tbaa !29
  %t58 = load i32, ptr %l61, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t57, i32 %t58)
  store { i64, ptr } %t59, ptr %l62
  br label %bb20
bb20:
  %t60 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l63, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l66
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l63, !tbaa !29
  %t68 = load i32, ptr %l66, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t69, ptr %l67
  br label %bb22
bb22:
  %t70 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t70, ptr %l5, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t79 = icmp ne i64 %t73, %t76
  br i1 %t79, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb31
bb28:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l82, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb30
bb30:
  %t112 = load i64, ptr %l82, !tbaa !24
  store i64 %t112, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t113 = load i64, ptr %l79, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb34:
  br label %bb35
bb35:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t134 = load i64, ptr %l11, !tbaa !24
  %t138 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t132, i32 %t133, i64 %t134)
  store i64 %t138, ptr %l103
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l2, !tbaa !23
  %t141 = load i64, ptr %l11, !tbaa !24
  %t145 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t139, i32 %t140, i64 %t141)
  store i64 %t145, ptr %l107
  br label %bb37
bb37:
  %t146 = load i64, ptr %l103, !tbaa !24
  %t147 = load i64, ptr %l107, !tbaa !24
  %t148 = icmp ne i64 %t146, %t147
  br i1 %t148, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb41
bb39:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t151, ptr %l111, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i32, ptr %t155, i64 %t152
  %t157 = load i32, ptr %t156, !tbaa !33
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t158, ptr %l114, !tbaa !27
  %t159 = load i64, ptr %l11, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t150, i32 %t157, i32 %t164)
  store i1 %t168, ptr %l117
  br label %bb40
bb40:
  %t169 = load i1, ptr %l117, !tbaa !21
  %t170 = xor i1 %t169, true
  store i1 %t170, ptr %l109, !tbaa !21
  br label %bb41
bb41:
  %t172 = load i1, ptr %l109, !tbaa !21
  br i1 %t172, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb45:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb32
bb46:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l1, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t178, i32 %t179)
  store { i64, ptr } %t182, ptr %l124
  br label %bb47
bb47:
  %t183 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t183, ptr %l12, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t184, i32 %t185)
  store { i64, ptr } %t188, ptr %l127
  br label %bb48
bb48:
  %t189 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t189, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l15, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb49, label %bb50
bb49:
  %t200 = load i64, ptr %l16, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb54
bb51:
  %t204 = load i64, ptr %l15, !tbaa !24
  %t205 = load i64, ptr %l14, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l16, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l16, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l136, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb53
bb53:
  %t220 = load i64, ptr %l136, !tbaa !24
  store i64 %t220, ptr %l133, !tbaa !24
  br label %bb54
bb54:
  %t221 = load i64, ptr %l133, !tbaa !24
  store i64 %t221, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load i64, ptr %l17, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb57:
  br label %bb58
bb58:
  %t230 = load i64, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l18, !tbaa !24
  %t232 = load i64, ptr %l16, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  store i64 %t238, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l19, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t246 = icmp sge i64 %t240, %t243
  br i1 %t246, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb60:
  br label %bb61
bb61:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l1, !tbaa !23
  %t250 = load i64, ptr %l19, !tbaa !24
  %t254 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t248, i32 %t249, i64 %t250)
  store i64 %t254, ptr %l161
  br label %bb62
bb62:
  %t255 = load i64, ptr %l161, !tbaa !24
  store i64 %t255, ptr %l20, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i32, ptr %l2, !tbaa !23
  %t258 = load i64, ptr %l19, !tbaa !24
  %t262 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t256, i32 %t257, i64 %t258)
  store i64 %t262, ptr %l165
  br label %bb63
bb63:
  %t263 = load i64, ptr %l165, !tbaa !24
  store i64 %t263, ptr %l21, !tbaa !24
  %t264 = load i64, ptr %l20, !tbaa !24
  %t265 = load i64, ptr %l21, !tbaa !24
  %t268 = icmp ne i64 %t264, %t265
  br i1 %t268, label %bb64, label %bb65
bb64:
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t274 = icmp eq i64 %t270, %t271
  br i1 %t274, label %bb66, label %bb67
bb65:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb75
bb66:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb68
bb67:
  %t276 = load i64, ptr %l20, !tbaa !24
  %t277 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t280 = icmp eq i64 %t276, %t277
  store i1 %t280, ptr %l173, !tbaa !21
  br label %bb68
bb68:
  %t282 = load i1, ptr %l173, !tbaa !21
  br i1 %t282, label %bb69, label %bb70
bb69:
  %t283 = load i64, ptr %l21, !tbaa !24
  %t284 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t287 = icmp eq i64 %t283, %t284
  br i1 %t287, label %bb71, label %bb72
bb70:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb74
bb71:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb73
bb72:
  %t289 = load i64, ptr %l21, !tbaa !24
  %t290 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t293 = icmp eq i64 %t289, %t290
  store i1 %t293, ptr %l181, !tbaa !21
  br label %bb73
bb73:
  %t295 = load i1, ptr %l181, !tbaa !21
  store i1 %t295, ptr %l177, !tbaa !21
  br label %bb74
bb74:
  %t296 = load i1, ptr %l177, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l169, !tbaa !21
  br label %bb75
bb75:
  %t299 = load i1, ptr %l169, !tbaa !21
  br i1 %t299, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i64, ptr %l19, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i32, ptr %t305, i64 %t302
  %t307 = load i32, ptr %t306, !tbaa !33
  %t308 = load i64, ptr %l19, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i32, ptr %t311, i64 %t308
  %t313 = load i32, ptr %t312, !tbaa !33
  %t317 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t301, i32 %t307, i32 %t313)
  store i1 %t317, ptr %l192
  br label %bb79
bb79:
  %t318 = load i1, ptr %l192, !tbaa !21
  %t319 = xor i1 %t318, true
  br i1 %t319, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb83
bb83:
  %t322 = load i64, ptr %l18, !tbaa !24
  %t324 = add i64 %t322, 1
  store i64 %t324, ptr %l18, !tbaa !24
  br label %bb55
bb84:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb85:
  %t327 = load i32, ptr %l3
  %t329 = trunc i64 19 to i32
  %t330 = icmp eq i32 %t327, %t329
  br i1 %t330, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l200, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l1, !tbaa !23
  %t337 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t337, ptr %l203
  br label %bb89
bb89:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l2, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t338, i32 %t339)
  store i32 %t342, ptr %l206
  br label %bb90
bb90:
  %t343 = load ptr, ptr %l200, !tbaa !29
  %t344 = load i32, ptr %l203, !tbaa !23
  %t345 = load i32, ptr %l206, !tbaa !23
  %t346 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t343, i32 %t344, i32 %t345)
  store i1 %t346, ptr %l207
  br label %bb91
bb91:
  %t347 = load i1, ptr %l207, !tbaa !21
  store i1 %t347, ptr %rv
  br label %ret
bb92:
  %t348 = load i32, ptr %l3
  %t350 = trunc i64 20 to i32
  %t351 = icmp eq i32 %t348, %t350
  br i1 %t351, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l210, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l1, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l213
  br label %bb96
bb96:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l2, !tbaa !23
  %t363 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t359, i32 %t360)
  store i32 %t363, ptr %l216
  br label %bb97
bb97:
  %t364 = load ptr, ptr %l210, !tbaa !29
  %t365 = load i32, ptr %l213, !tbaa !23
  %t366 = load i32, ptr %l216, !tbaa !23
  %t367 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t364, i32 %t365, i32 %t366)
  store i1 %t367, ptr %l217
  br label %bb98
bb98:
  %t368 = load i1, ptr %l217, !tbaa !21
  store i1 %t368, ptr %rv
  br label %ret
bb99:
  %t369 = load i32, ptr %l3
  %t371 = trunc i64 22 to i32
  %t372 = icmp eq i32 %t369, %t371
  br i1 %t372, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb126
bb102:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l220, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i32, ptr %l1, !tbaa !23
  %t379 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t375, i32 %t376)
  store i32 %t379, ptr %l223
  br label %bb103
bb103:
  %t380 = load ptr, ptr %l220, !tbaa !29
  %t381 = load i32, ptr %l223, !tbaa !23
  %t382 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t380, i32 %t381)
  store { i64, ptr } %t382, ptr %l224
  br label %bb104
bb104:
  %t383 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t383, ptr %l22, !tbaa !27
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l225, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i32, ptr %l2, !tbaa !23
  %t389 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t389, ptr %l228
  br label %bb105
bb105:
  %t390 = load ptr, ptr %l225, !tbaa !29
  %t391 = load i32, ptr %l228, !tbaa !23
  %t392 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t390, i32 %t391)
  store { i64, ptr } %t392, ptr %l229
  br label %bb106
bb106:
  %t393 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t393, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t394 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t394, 0
  store i64 %t396, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t398 = load i64, ptr %l25, !tbaa !24
  %t399 = load i64, ptr %l24, !tbaa !24
  %t402 = icmp sgt i64 %t398, %t399
  br i1 %t402, label %bb107, label %bb108
bb107:
  %t404 = load i64, ptr %l26, !tbaa !24
  %t406 = icmp sgt i64 %t404, 0
  br i1 %t406, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb112
bb109:
  %t408 = load i64, ptr %l25, !tbaa !24
  %t409 = load i64, ptr %l24, !tbaa !24
  %t412 = sub i64 %t408, %t409
  %t413 = load i64, ptr %l26, !tbaa !24
  %t416 = add i64 %t412, %t413
  %t418 = sub i64 %t416, 1
  %t419 = load i64, ptr %l26, !tbaa !24
  %t422 = sdiv i64 %t418, %t419
  store i64 %t422, ptr %l238, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb111
bb111:
  %t424 = load i64, ptr %l238, !tbaa !24
  store i64 %t424, ptr %l235, !tbaa !24
  br label %bb112
bb112:
  %t425 = load i64, ptr %l235, !tbaa !24
  store i64 %t425, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s19
  %t426 = load i64, ptr %l28, !tbaa !24
  %t427 = load i64, ptr %l27, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s19)
  br label %bb125
bb115:
  br label %bb116
bb116:
  %t434 = load i64, ptr %l24, !tbaa !24
  %t435 = load i64, ptr %l28, !tbaa !24
  %t436 = load i64, ptr %l26, !tbaa !24
  %t439 = mul i64 %t435, %t436
  %t442 = add i64 %t434, %t439
  store i64 %t442, ptr %l29, !tbaa !24
  %t444 = load i64, ptr %l29, !tbaa !24
  %t445 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t450 = icmp slt i64 %t444, %t447
  br i1 %t450, label %bb117, label %bb118
bb117:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t453, ptr %l262, !tbaa !27
  %t454 = load i64, ptr %l29, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i32, ptr %t457, i64 %t454
  %t459 = load i32, ptr %t458, !tbaa !33
  %t460 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t460, ptr %l265, !tbaa !27
  %t461 = load i64, ptr %l29, !tbaa !24
  %t463 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr i32, ptr %t464, i64 %t461
  %t466 = load i32, ptr %t465, !tbaa !33
  %t470 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t452, i32 %t459, i32 %t466)
  store i1 %t470, ptr %l268
  br label %bb119
bb118:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb120
bb119:
  %t471 = load i1, ptr %l268, !tbaa !21
  %t472 = xor i1 %t471, true
  store i1 %t472, ptr %l260, !tbaa !21
  br label %bb120
bb120:
  %t474 = load i1, ptr %l260, !tbaa !21
  br i1 %t474, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s19)
  store i1 false, ptr %rv
  br label %ret
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s19)
  br label %bb124
bb124:
  %t476 = load i64, ptr %l28, !tbaa !24
  %t478 = add i64 %t476, 1
  store i64 %t478, ptr %l28, !tbaa !24
  br label %bb113
bb125:
  store i1 true, ptr %rv
  br label %ret
bb126:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/types:data"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
  store %"compiler/types:data" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/types:data", ptr %l4, i32 0, i32 4
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = trunc i64 %t7 to i32
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEmptyBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l3, !tbaa !29
  store i32 %a1, ptr %l4, !tbaa !23
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t7 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t5, i1 false, i1 true)
  store %"compiler/types:body" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = load %"compiler/types:body", ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t8, i32 %t9, %"compiler/types:body" %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEnumBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_f7eaf3fe8a46d3da_9f187abb7d2da27e)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f7eaf3fe8a46d3da_9f187abb7d2da27e)
  unreachable
bb5:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l24, !tbaa !24
  store i64 %t46, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l21, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l44, !tbaa !27
  %t69 = load i64, ptr %l10, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t69
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t67
  store i32 %t74, ptr %t79, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb11
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/types:Table", ptr %t84, i32 0, i32 17
  %t87 = load i32, ptr %l1, !tbaa !23
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v0, ptr %t86, i32 %t87, { i64, ptr } %t88)
  br label %bb17
bb17:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/types:Table", ptr %t92, i32 0, i32 16
  store ptr %t94, ptr %l54, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  store i32 %t95, ptr %l55, !tbaa !23
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t100 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 %a3, i32 %t97, i1 false, i1 true)
  store %"compiler/types:body" %t100, ptr %l58
  br label %bb18
bb18:
  %t101 = load ptr, ptr %l54, !tbaa !29
  %t102 = load i32, ptr %l55, !tbaa !23
  %t103 = load %"compiler/types:body", ptr %l58
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t101, i32 %t102, %"compiler/types:body" %t103)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetLayoutState(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 18
  %t6 = sext i32 %a1 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6, i64 %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetOverBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i32
  %l7 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l4, !tbaa !29
  store i32 %a1, ptr %l5, !tbaa !23
  %t7 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %a2, i1 false, i1 true)
  store %"compiler/types:body" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = load %"compiler/types:body", ptr %l7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t8, i32 %t9, %"compiler/types:body" %t10)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l5 = alloca ptr
  %l6 = alloca i32
  %l10 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  store ptr %t3, ptr %l5, !tbaa !29
  store i32 %a1, ptr %l6, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 %a2, i32 0, i32 %t6, i1 %a3, i1 true)
  store %"compiler/types:body" %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = load %"compiler/types:body", ptr %l10
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %t12, i32 %t13, %"compiler/types:body" %t14)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t9, i64 %t10)
  store i32 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i32, ptr %l7, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 7
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca i1
  %l17 = alloca i1
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 26
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = sext i32 %t9 to i64
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t10)
  store { i64, ptr } %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = add i64 2, %t26
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t34 = icmp slt i64 %t28, %t31
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  %t40 = add i64 2, %t38
  %t42 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i64, ptr %t43, i64 %t40
  %t45 = load i64, ptr %t44, !tbaa !34
  store i64 %t45, ptr %l23, !tbaa !24
  br label %bb11
bb10:
  %t47 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t47, ptr %l23, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l23, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 19
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l5, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 3, ptr @.d11 }, ptr %l9, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l11, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l13, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l16
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l13, !tbaa !29
  %t38 = load i32, ptr %l16, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l17
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca %"compiler/types:data"
  %l11 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 22, i64 %t4, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = add i32 %t13, 1
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load %"compiler/types:data", ptr %l8
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t15, %"compiler/types:data" %t16, i32 %t14)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/types:Table", ptr %t32, i32 0, i32 25
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t43, i64 %t44, i32 %t45)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l36 = alloca i64
  %l37 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 21 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t21, ptr %l13
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l18
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l21
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l24
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l8, !tbaa !29
  %t42 = load i32, ptr %l13, !tbaa !23
  %t43 = load i32, ptr %l18, !tbaa !23
  %t44 = load i32, ptr %l21, !tbaa !23
  %t45 = load i32, ptr %l24, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t41, i32 %t42, i32 %t43, i32 %t44, i32 %t45, i64 0)
  store i32 %t46, ptr %l25
  br label %bb10
bb10:
  %t47 = load i32, ptr %l25, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb11:
  %t48 = load i32, ptr %l2
  %t50 = trunc i64 20 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l32
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t61 = load i32, ptr %l32, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t63, i32 %t64)
  store i64 %t67, ptr %l36
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l28, !tbaa !29
  %t69 = load i32, ptr %l33, !tbaa !23
  %t70 = load i64, ptr %l36, !tbaa !24
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t68, i32 %t69, i64 %t70)
  store i32 %t71, ptr %l37
  br label %bb17
bb17:
  %t72 = load i32, ptr %l37, !tbaa !23
  store i32 %t72, ptr %rv
  br label %ret
bb18:
  %t73 = load i32, ptr %l2
  %t75 = trunc i64 19 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb19, label %bb20
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l44
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t85 = load ptr, ptr %l41, !tbaa !29
  %t86 = load i32, ptr %l44, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t87, ptr %l45
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l1, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l48
  br label %bb23
bb23:
  %t93 = load ptr, ptr %l40, !tbaa !29
  %t94 = load i32, ptr %l45, !tbaa !23
  %t95 = load i32, ptr %l48, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t93, i32 %t94, i32 %t95)
  store i32 %t96, ptr %l49
  br label %bb24
bb24:
  %t97 = load i32, ptr %l49, !tbaa !23
  store i32 %t97, ptr %rv
  br label %ret
bb25:
  %t98 = load i32, ptr %l2
  %t100 = trunc i64 22 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb26, label %bb27
bb26:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l52, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l53, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l1, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l56
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t110 = load ptr, ptr %l53, !tbaa !29
  %t111 = load i32, ptr %l56, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t112, ptr %l57
  br label %bb29
bb29:
  %t113 = load ptr, ptr %l52, !tbaa !29
  %t114 = load i32, ptr %l57, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t115, ptr %l58
  br label %bb30
bb30:
  %t116 = load i32, ptr %l58, !tbaa !23
  store i32 %t116, ptr %rv
  br label %ret
bb31:
  %t117 = load i32, ptr %l1, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l9 = alloca %"compiler/types:data"
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  %t9 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 25, i64 %a1, i64 %a2, i64 %a3, i64 0, i64 0)
  store %"compiler/types:data" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load %"compiler/types:data", ptr %l9
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t10, %"compiler/types:data" %t11, i32 1)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l10, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eByAddress(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i64, ptr @G_2ecompiler_2ftypes_2eBigAggregate, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t13, %t12
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  %t8 = trunc i64 21 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i32, ptr %l1, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l13
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l19
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l10, !tbaa !29
  %t38 = load i32, ptr %l13, !tbaa !23
  %t39 = load i32, ptr %l16, !tbaa !23
  %t40 = load i32, ptr %l19, !tbaa !23
  %t41 = load i32, ptr %l22, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t37, i32 %t38, i32 %t39, i32 %t40, i32 %t41, i64 %a2)
  store i32 %t43, ptr %l24
  br label %bb9
bb9:
  %t44 = load i32, ptr %l24, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr @.d12 })
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l14
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb6:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l23, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr @.d13 })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  store ptr %l2, ptr %l44, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t66, ptr %l46, !tbaa !27
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i32, ptr %t70, i64 %t67
  %t72 = load i32, ptr %t71, !tbaa !33
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t65, i32 %t72)
  store { i64, ptr } %t75, ptr %l49
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t76, { i64, ptr } %t77)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb10
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 2, ptr @.d14 })
  br label %bb22
bb22:
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t84, ptr %l54
  br label %bb23
bb23:
  %t85 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t85, ptr %l55, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l56, !tbaa !24
  %t88 = load i64, ptr %l56, !tbaa !24
  %t89 = mul i64 %t88, 1
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l57, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l56, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  %t99 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp eq i32 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 12, ptr @.d15 }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l10, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l13
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l10, !tbaa !29
  %t32 = load i32, ptr %l13, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t33, ptr %l14
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l18
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l15, !tbaa !29
  %t41 = load i32, ptr %l18, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l19
  br label %bb8
bb8:
  %t43 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 0
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t47 = add i64 %t44, %t46
  %t48 = extractvalue { i64, ptr } { i64 3, ptr @.d17 }, 1
  %t49 = extractvalue { i64, ptr } { i64 3, ptr @.d17 }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t43, i64 %t44)
  %t59 = getelementptr i8, ptr %t58, i64 %t44
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t45)
  %t61 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t61, ptr %t48, i64 %t49)
  %t62 = getelementptr i8, ptr %t61, i64 %t49
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = getelementptr i8, ptr %t62, i64 %t53
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t58, 1
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/types:data"
  %rv = alloca %"compiler/types:data"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 1
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/types:data" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/types:data" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local %"compiler/types:body" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ebodyOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"compiler/types:body"
  %l6 = alloca %"compiler/types:body"
  %l7 = alloca i32
  %l9 = alloca %"compiler/types:body"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/types:body"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 16
  %t7 = call { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, %"compiler/types:body" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/types:body" } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store %"compiler/types:body" %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load %"compiler/types:body", ptr %l6
  store %"compiler/types:body" %t12, ptr %l2
  br label %bb5
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = call %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %s0, i32 0, i32 0, i32 %t13, i1 false, i1 false)
  store %"compiler/types:body" %t15, ptr %l9
  br label %bb4
bb4:
  %t16 = load %"compiler/types:body", ptr %l9
  store %"compiler/types:body" %t16, ptr %l2
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/types:body", ptr %l2
  store %"compiler/types:body" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:body", ptr %rv
  ret %"compiler/types:body" %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:data"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i32
  %l48 = alloca %"compiler/types:data"
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca i64
  %l103 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l115 = alloca i32
  %l116 = alloca ptr
  %l118 = alloca ptr
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca { i64, ptr }
  %l145 = alloca i64
  %l148 = alloca i64
  %l171 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l181 = alloca ptr
  %l184 = alloca i32
  %l187 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l194 = alloca i32
  %l200 = alloca i64
  %l211 = alloca ptr
  %l212 = alloca ptr
  %l215 = alloca i32
  %l216 = alloca ptr
  %l221 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l226 = alloca ptr
  %l229 = alloca i32
  %l233 = alloca i32
  %l239 = alloca i32
  %l242 = alloca ptr
  %l244 = alloca { i64, ptr }
  %l250 = alloca ptr
  %l253 = alloca i32
  %l254 = alloca { i64, ptr }
  %l262 = alloca i1
  %l263 = alloca { i64, ptr }
  %l273 = alloca i64
  %l276 = alloca i64
  %l294 = alloca ptr
  %l297 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l307 = alloca i1
  %l314 = alloca { i64, ptr }
  %l320 = alloca i64
  %l323 = alloca i64
  %l344 = alloca ptr
  %l347 = alloca { i64, ptr }
  %l352 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l368 = alloca i64
  %l371 = alloca i64
  %l393 = alloca { i64, ptr }
  %l404 = alloca ptr
  %l405 = alloca ptr
  %l408 = alloca i32
  %l413 = alloca ptr
  %l414 = alloca ptr
  %l417 = alloca i32
  %l424 = alloca { i64, ptr }
  %l425 = alloca ptr
  %l428 = alloca i32
  %l429 = alloca { i64, ptr }
  %l435 = alloca i64
  %l438 = alloca i64
  %l459 = alloca ptr
  %l462 = alloca { i64, ptr }
  %l465 = alloca { i64, ptr }
  %l466 = alloca { i64, ptr }
  %l471 = alloca ptr
  %l472 = alloca ptr
  %l474 = alloca { i64, ptr }
  %l477 = alloca i32
  %l493 = alloca i32
  %l497 = alloca ptr
  %l500 = alloca { i64, ptr }
  %l503 = alloca i1
  %l504 = alloca i1
  %l507 = alloca ptr
  %l509 = alloca { i64, ptr }
  %l517 = alloca ptr
  %l520 = alloca { i64, ptr }
  %l526 = alloca ptr
  %l527 = alloca ptr
  %l530 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l48
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l48
  store %"compiler/types:data" %t6, ptr %l3
  %t7 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4
  %t10 = load i32, ptr %l4
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t15, { i64, ptr } { i64 1, ptr @.d19 })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb325
bb6:
  %t17 = load i32, ptr %l4
  %t19 = trunc i64 15 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t22, { i64, ptr } { i64 4, ptr @.d20 })
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb325
bb11:
  %t24 = load i32, ptr %l4
  %t26 = trunc i64 16 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t29, { i64, ptr } { i64 7, ptr @.d21 })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb325
bb16:
  %t31 = load i32, ptr %l4
  %t33 = trunc i64 17 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t36, { i64, ptr } { i64 8, ptr @.d22 })
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb325
bb21:
  %t38 = load i32, ptr %l4
  %t40 = trunc i64 28 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l64, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l65, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l68
  br label %bb25
bb25:
  %t50 = load ptr, ptr %l64, !tbaa !29
  %t51 = load ptr, ptr %l65, !tbaa !29
  %t52 = load i32, ptr %l68, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t50, ptr %t51, i32 %t52)
  br label %bb26
bb26:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l69, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t54, i32 %t55)
  store i64 %t58, ptr %l72
  br label %bb27
bb27:
  %t59 = extractvalue { i64, ptr } { i64 2, ptr @.d23 }, 1
  %t60 = extractvalue { i64, ptr } { i64 2, ptr @.d23 }, 0
  %t61 = load i64, ptr %l72, !tbaa !65
  %t62 = call i64 @__olang_fmt_u64(ptr null, i64 %t61)
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = getelementptr i8, ptr %t64, i64 %t60
  %t66 = call i64 @__olang_fmt_u64(ptr %t65, i64 %t61)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t76, { i64, ptr } %t75)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb325
bb29:
  %t78 = load i32, ptr %l4
  %t80 = trunc i64 1 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  br label %bb58
bb31:
  %t83 = load i32, ptr %l4
  %t85 = trunc i64 2 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb32, label %bb33
bb32:
  br label %bb58
bb33:
  %t88 = load i32, ptr %l4
  %t90 = trunc i64 3 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb34, label %bb35
bb34:
  br label %bb58
bb35:
  %t93 = load i32, ptr %l4
  %t95 = trunc i64 4 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb36, label %bb37
bb36:
  br label %bb58
bb37:
  %t98 = load i32, ptr %l4
  %t100 = trunc i64 5 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  %t103 = load i32, ptr %l4
  %t105 = trunc i64 6 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb40, label %bb41
bb40:
  br label %bb58
bb41:
  %t108 = load i32, ptr %l4
  %t110 = trunc i64 7 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb42, label %bb43
bb42:
  br label %bb58
bb43:
  %t113 = load i32, ptr %l4
  %t115 = trunc i64 8 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb44, label %bb45
bb44:
  br label %bb58
bb45:
  %t118 = load i32, ptr %l4
  %t120 = trunc i64 9 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb46, label %bb47
bb46:
  br label %bb58
bb47:
  %t123 = load i32, ptr %l4
  %t125 = trunc i64 10 to i32
  %t126 = icmp eq i32 %t123, %t125
  br i1 %t126, label %bb48, label %bb49
bb48:
  br label %bb58
bb49:
  %t128 = load i32, ptr %l4
  %t130 = trunc i64 11 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  %t133 = load i32, ptr %l4
  %t135 = trunc i64 12 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb52, label %bb53
bb52:
  br label %bb58
bb53:
  %t138 = load i32, ptr %l4
  %t140 = trunc i64 13 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  %t143 = load i32, ptr %l4
  %t145 = trunc i64 14 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l103, !tbaa !29
  %t149 = load i32, ptr %l2, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 4, ptr @.d24 }, ptr %l107, !tbaa !27
  br label %bb61
bb60:
  %t155 = load i32, ptr %l2, !tbaa !23
  %t157 = sext i32 %t155 to i64
  %t159 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimNames, i64 0, i64 %t157
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !37
  store { i64, ptr } %t160, ptr %l107, !tbaa !27
  br label %bb61
bb61:
  %t162 = load ptr, ptr @__olang_prog_scope
  %t163 = load ptr, ptr %l103, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l107, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %t162, ptr %t163, { i64, ptr } %t164)
  br label %bb62
bb62:
  br label %bb325
bb63:
  %t165 = load i32, ptr %l4
  %t167 = trunc i64 18 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb99
bb66:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l2, !tbaa !23
  %t174 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t174, ptr %l115
  br label %bb67
bb67:
  %t175 = load i32, ptr %l115, !tbaa !23
  store i32 %t175, ptr %l5, !tbaa !23
  %t176 = load ptr, ptr %l1, !tbaa !29
  store ptr %t176, ptr %l116, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/types:Table", ptr %t177, i32 0, i32 14
  store ptr %t179, ptr %l118, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i32, ptr %l5, !tbaa !23
  %t184 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t180, i32 %t181)
  store i64 %t184, ptr %l121
  br label %bb68
bb68:
  %t185 = load ptr, ptr %l118, !tbaa !29
  %t186 = load i64, ptr %l121, !tbaa !24
  %t187 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t185, i64 %t186)
  store { i64, ptr } %t187, ptr %l122
  br label %bb69
bb69:
  %t188 = load ptr, ptr %l116, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l122, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t188, { i64, ptr } %t189)
  br label %bb70
bb70:
  %t190 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t190, i8 58)
  br label %bb71
bb71:
  %t192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t192, ptr %l124, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/types:Table", ptr %t193, i32 0, i32 0
  %t196 = load ptr, ptr %t195, !tbaa !29
  store ptr %t196, ptr %l126, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l5, !tbaa !23
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t197, i32 %t198)
  store i32 %t201, ptr %l129
  br label %bb72
bb72:
  %t202 = load ptr, ptr %l126, !tbaa !29
  %t203 = load i32, ptr %l129, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t202, i32 %t203)
  store { i64, ptr } %t204, ptr %l130
  br label %bb73
bb73:
  %t205 = load ptr, ptr %l124, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l130, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t205, { i64, ptr } %t206)
  br label %bb74
bb74:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l131, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i32, ptr %l2, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l134
  br label %bb75
bb75:
  %t213 = load ptr, ptr %l131, !tbaa !29
  %t214 = load i32, ptr %l134, !tbaa !23
  %t215 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t213, i32 %t214)
  store { i64, ptr } %t215, ptr %l135
  br label %bb76
bb76:
  %t216 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t216, ptr %l6, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb77, label %bb78
bb77:
  %t223 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t223, i8 60)
  br label %bb79
bb78:
  br label %bb98
bb79:
  store i64 0, ptr %l7, !tbaa !24
  %t225 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t225, 0
  store i64 %t227, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t229 = load i64, ptr %l8, !tbaa !24
  %t230 = load i64, ptr %l7, !tbaa !24
  %t233 = icmp sgt i64 %t229, %t230
  br i1 %t233, label %bb80, label %bb81
bb80:
  %t235 = load i64, ptr %l9, !tbaa !24
  %t237 = icmp sgt i64 %t235, 0
  br i1 %t237, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb85
bb82:
  %t239 = load i64, ptr %l8, !tbaa !24
  %t240 = load i64, ptr %l7, !tbaa !24
  %t243 = sub i64 %t239, %t240
  %t244 = load i64, ptr %l9, !tbaa !24
  %t247 = add i64 %t243, %t244
  %t249 = sub i64 %t247, 1
  %t250 = load i64, ptr %l9, !tbaa !24
  %t253 = sdiv i64 %t249, %t250
  store i64 %t253, ptr %l148, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb84
bb84:
  %t255 = load i64, ptr %l148, !tbaa !24
  store i64 %t255, ptr %l145, !tbaa !24
  br label %bb85
bb85:
  %t256 = load i64, ptr %l145, !tbaa !24
  store i64 %t256, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s11
  %t257 = load i64, ptr %l11, !tbaa !24
  %t258 = load i64, ptr %l10, !tbaa !24
  %t261 = icmp slt i64 %t257, %t258
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s11)
  br label %bb96
bb88:
  br label %bb89
bb89:
  %t265 = load i64, ptr %l7, !tbaa !24
  %t266 = load i64, ptr %l11, !tbaa !24
  %t267 = load i64, ptr %l9, !tbaa !24
  %t270 = mul i64 %t266, %t267
  %t273 = add i64 %t265, %t270
  store i64 %t273, ptr %l12, !tbaa !24
  %t275 = load i64, ptr %l12, !tbaa !24
  %t277 = icmp sgt i64 %t275, 0
  br i1 %t277, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s12
  %t279 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s12, ptr %t279, { i64, ptr } { i64 2, ptr @.d25 })
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb93:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l1, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t283, ptr %l171, !tbaa !27
  %t284 = load i64, ptr %l12, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr i32, ptr %t287, i64 %t284
  %t289 = load i32, ptr %t288, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t281, ptr %t282, i32 %t289)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb95:
  %t293 = load i64, ptr %l11, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l11, !tbaa !24
  br label %bb86
bb96:
  %t297 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t297, i8 62)
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb325
bb99:
  %t299 = load i32, ptr %l4
  %t301 = trunc i64 19 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb114
bb102:
  store %olang.scope zeroinitializer, ptr %s14
  %t304 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s14, ptr %t304, { i64, ptr } { i64 6, ptr @.d26 })
  br label %bb103
bb103:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l180, !tbaa !29
  %t307 = load ptr, ptr %l1, !tbaa !29
  store ptr %t307, ptr %l181, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i32, ptr %l2, !tbaa !23
  %t312 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t308, i32 %t309)
  store i32 %t312, ptr %l184
  br label %bb104
bb104:
  %t313 = load ptr, ptr %l180, !tbaa !29
  %t314 = load ptr, ptr %l181, !tbaa !29
  %t315 = load i32, ptr %l184, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t313, ptr %t314, i32 %t315)
  br label %bb105
bb105:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l2, !tbaa !23
  %t320 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t316, i32 %t317)
  store i32 %t320, ptr %l187
  br label %bb106
bb106:
  %t321 = load i32, ptr %l187, !tbaa !23
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s15
  %t324 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t324, { i64, ptr } { i64 2, ptr @.d27 })
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l190, !tbaa !29
  %t327 = load ptr, ptr %l1, !tbaa !29
  store ptr %t327, ptr %l191, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i32, ptr %l2, !tbaa !23
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t332, ptr %l194
  br label %bb110
bb110:
  %t333 = load ptr, ptr %l190, !tbaa !29
  %t334 = load ptr, ptr %l191, !tbaa !29
  %t335 = load i32, ptr %l194, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t333, ptr %t334, i32 %t335)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s15)
  br label %bb112
bb112:
  %t336 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t336, i8 62)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s14)
  br label %bb325
bb114:
  %t338 = load i32, ptr %l4
  %t340 = trunc i64 20 to i32
  %t341 = icmp eq i32 %t338, %t340
  br i1 %t341, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb133
bb117:
  store %olang.scope zeroinitializer, ptr %s16
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l2, !tbaa !23
  %t347 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t343, i32 %t344)
  store i64 %t347, ptr %l200
  br label %bb118
bb118:
  %t348 = load i64, ptr %l200, !tbaa !24
  store i64 %t348, ptr %l13, !tbaa !24
  %t349 = load i64, ptr %l13, !tbaa !24
  %t350 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t353 = and i64 %t349, %t350
  %t355 = icmp ne i64 %t353, 0
  br i1 %t355, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s17
  %t357 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s17, ptr %t357, { i64, ptr } { i64 4, ptr @.d28 })
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_scope_close(ptr %s17)
  br label %bb122
bb122:
  %t359 = load i64, ptr %l13, !tbaa !24
  %t360 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t363 = and i64 %t359, %t360
  %t365 = icmp ne i64 %t363, 0
  br i1 %t365, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s18
  %t367 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s18, ptr %t367, { i64, ptr } { i64 4, ptr @.d29 })
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s18)
  br label %bb126
bb126:
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l211, !tbaa !29
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l212, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l2, !tbaa !23
  %t375 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l215
  br label %bb127
bb127:
  %t376 = load ptr, ptr %l211, !tbaa !29
  %t377 = load ptr, ptr %l212, !tbaa !29
  %t378 = load i32, ptr %l215, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t376, ptr %t377, i32 %t378)
  br label %bb128
bb128:
  %t379 = load ptr, ptr %l1, !tbaa !29
  store ptr %t379, ptr %l216, !tbaa !29
  %t380 = load i64, ptr %l13, !tbaa !24
  %t381 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t384 = and i64 %t380, %t381
  %t386 = icmp ne i64 %t384, 0
  br i1 %t386, label %bb129, label %bb130
bb129:
  store { i64, ptr } { i64 2, ptr @.d30 }, ptr %l221, !tbaa !27
  br label %bb131
bb130:
  store { i64, ptr } { i64 1, ptr @.d31 }, ptr %l221, !tbaa !27
  br label %bb131
bb131:
  %t388 = load ptr, ptr %l216, !tbaa !29
  %t389 = load { i64, ptr }, ptr %l221, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s16, ptr %t388, { i64, ptr } %t389)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s16)
  br label %bb325
bb133:
  %t390 = load i32, ptr %l4
  %t392 = trunc i64 21 to i32
  %t393 = icmp eq i32 %t390, %t392
  br i1 %t393, label %bb134, label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb234
bb136:
  store %olang.scope zeroinitializer, ptr %s19
  %t395 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t395, { i64, ptr } { i64 3, ptr @.d32 })
  br label %bb137
bb137:
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l225, !tbaa !29
  %t398 = load ptr, ptr %l1, !tbaa !29
  store ptr %t398, ptr %l226, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load i32, ptr %l2, !tbaa !23
  %t403 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t399, i32 %t400)
  store i32 %t403, ptr %l229
  br label %bb138
bb138:
  %t404 = load ptr, ptr %l225, !tbaa !29
  %t405 = load ptr, ptr %l226, !tbaa !29
  %t406 = load i32, ptr %l229, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t404, ptr %t405, i32 %t406)
  br label %bb139
bb139:
  %t407 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t407, i8 41)
  br label %bb140
bb140:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load i32, ptr %l2, !tbaa !23
  %t413 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t409, i32 %t410)
  store i32 %t413, ptr %l233
  br label %bb141
bb141:
  %t414 = load i32, ptr %l233, !tbaa !23
  store i32 %t414, ptr %l14, !tbaa !23
  %t415 = load i32, ptr %l14, !tbaa !23
  %t416 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t419 = icmp ne i32 %t415, %t416
  br i1 %t419, label %bb142, label %bb143
bb142:
  store %olang.scope zeroinitializer, ptr %s20
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i32, ptr %l14, !tbaa !23
  %t425 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t421, i32 %t422)
  store i32 %t425, ptr %l239
  br label %bb144
bb143:
  br label %bb154
bb144:
  %t426 = load i32, ptr %l239
  %t428 = trunc i64 21 to i32
  %t429 = icmp eq i32 %t426, %t428
  store i1 %t429, ptr %l15, !tbaa !21
  %t431 = load ptr, ptr %l1, !tbaa !29
  store ptr %t431, ptr %l242, !tbaa !29
  %t432 = load i1, ptr %l15, !tbaa !21
  br i1 %t432, label %bb145, label %bb146
bb145:
  store { i64, ptr } { i64 2, ptr @.d33 }, ptr %l244, !tbaa !27
  br label %bb147
bb146:
  store { i64, ptr } { i64 1, ptr @.d34 }, ptr %l244, !tbaa !27
  br label %bb147
bb147:
  %t434 = load ptr, ptr %l242, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l244, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s20, ptr %t434, { i64, ptr } %t435)
  br label %bb148
bb148:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t438 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t436, ptr %t437, i32 %t438)
  br label %bb149
bb149:
  %t442 = load i1, ptr %l15, !tbaa !21
  br i1 %t442, label %bb150, label %bb151
bb150:
  %t444 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t444, i8 41)
  br label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s20)
  br label %bb154
bb154:
  %t446 = load ptr, ptr %l0, !tbaa !29
  store ptr %t446, ptr %l250, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load i32, ptr %l2, !tbaa !23
  %t451 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t447, i32 %t448)
  store i32 %t451, ptr %l253
  br label %bb155
bb155:
  %t452 = load ptr, ptr %l250, !tbaa !29
  %t453 = load i32, ptr %l253, !tbaa !23
  %t454 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t452, i32 %t453)
  store { i64, ptr } %t454, ptr %l254
  br label %bb156
bb156:
  %t455 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t455, ptr %l16, !tbaa !27
  %t456 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t460 = icmp sgt i64 %t458, 0
  br i1 %t460, label %bb157, label %bb158
bb157:
  store %olang.scope zeroinitializer, ptr %s22
  %t462 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s22, ptr %t462, { i64, ptr } { i64 2, ptr @.d35 })
  br label %bb159
bb158:
  br label %bb183
bb159:
  %t464 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t468 = icmp eq i64 %t466, 1
  br i1 %t468, label %bb160, label %bb161
bb160:
  %t470 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t470, ptr %l263, !tbaa !27
  %t471 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr i32, ptr %t472, i64 0
  %t474 = load i32, ptr %t473, !tbaa !33
  %t475 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t478 = icmp eq i32 %t474, %t475
  store i1 %t478, ptr %l262, !tbaa !21
  br label %bb162
bb161:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb162
bb162:
  %t480 = load i1, ptr %l262, !tbaa !21
  %t481 = xor i1 %t480, true
  br i1 %t481, label %bb163, label %bb164
bb163:
  store i64 0, ptr %l17, !tbaa !24
  %t483 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t483, 0
  store i64 %t485, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t487 = load i64, ptr %l18, !tbaa !24
  %t488 = load i64, ptr %l17, !tbaa !24
  %t491 = icmp sgt i64 %t487, %t488
  br i1 %t491, label %bb165, label %bb166
bb164:
  br label %bb182
bb165:
  %t493 = load i64, ptr %l19, !tbaa !24
  %t495 = icmp sgt i64 %t493, 0
  br i1 %t495, label %bb167, label %bb168
bb166:
  store i64 0, ptr %l273, !tbaa !24
  br label %bb170
bb167:
  %t497 = load i64, ptr %l18, !tbaa !24
  %t498 = load i64, ptr %l17, !tbaa !24
  %t501 = sub i64 %t497, %t498
  %t502 = load i64, ptr %l19, !tbaa !24
  %t505 = add i64 %t501, %t502
  %t507 = sub i64 %t505, 1
  %t508 = load i64, ptr %l19, !tbaa !24
  %t511 = sdiv i64 %t507, %t508
  store i64 %t511, ptr %l276, !tbaa !24
  br label %bb169
bb168:
  store i64 0, ptr %l276, !tbaa !24
  br label %bb169
bb169:
  %t513 = load i64, ptr %l276, !tbaa !24
  store i64 %t513, ptr %l273, !tbaa !24
  br label %bb170
bb170:
  %t514 = load i64, ptr %l273, !tbaa !24
  store i64 %t514, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb171
bb171:
  store %olang.scope zeroinitializer, ptr %s25
  %t515 = load i64, ptr %l21, !tbaa !24
  %t516 = load i64, ptr %l20, !tbaa !24
  %t519 = icmp slt i64 %t515, %t516
  %t521 = xor i1 %t519, true
  br i1 %t521, label %bb172, label %bb173
bb172:
  call void @__olang_scope_close(ptr %s25)
  br label %bb181
bb173:
  br label %bb174
bb174:
  %t523 = load i64, ptr %l17, !tbaa !24
  %t524 = load i64, ptr %l21, !tbaa !24
  %t525 = load i64, ptr %l19, !tbaa !24
  %t528 = mul i64 %t524, %t525
  %t531 = add i64 %t523, %t528
  store i64 %t531, ptr %l22, !tbaa !24
  %t533 = load ptr, ptr %l1, !tbaa !29
  store ptr %t533, ptr %l294, !tbaa !29
  %t534 = load i64, ptr %l22, !tbaa !24
  %t536 = icmp sgt i64 %t534, 0
  br i1 %t536, label %bb175, label %bb176
bb175:
  store { i64, ptr } { i64 3, ptr @.d36 }, ptr %l297, !tbaa !27
  br label %bb177
bb176:
  store { i64, ptr } { i64 1, ptr @.d37 }, ptr %l297, !tbaa !27
  br label %bb177
bb177:
  %t538 = load ptr, ptr %l294, !tbaa !29
  %t539 = load { i64, ptr }, ptr %l297, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s25, ptr %t538, { i64, ptr } %t539)
  br label %bb178
bb178:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load ptr, ptr %l1, !tbaa !29
  %t542 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t542, ptr %l300, !tbaa !27
  %t543 = load i64, ptr %l22, !tbaa !24
  %t545 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = getelementptr i32, ptr %t546, i64 %t543
  %t548 = load i32, ptr %t547, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t540, ptr %t541, i32 %t548)
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s25)
  br label %bb180
bb180:
  %t552 = load i64, ptr %l21, !tbaa !24
  %t554 = add i64 %t552, 1
  store i64 %t554, ptr %l21, !tbaa !24
  br label %bb171
bb181:
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s22)
  br label %bb183
bb183:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/types:Table", ptr %t556, i32 0, i32 3
  %t559 = load i1, ptr %t558, !tbaa !21
  br i1 %t559, label %bb184, label %bb185
bb184:
  %t561 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t562 = load i64, ptr %t561, !tbaa !24
  %t564 = icmp ne i64 %t562, 0
  store i1 %t564, ptr %l307, !tbaa !21
  br label %bb186
bb185:
  store i1 false, ptr %l307, !tbaa !21
  br label %bb186
bb186:
  %t566 = load i1, ptr %l307, !tbaa !21
  br i1 %t566, label %bb187, label %bb188
bb187:
  %t567 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t567, i8 123)
  br label %bb189
bb188:
  br label %bb210
bb189:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t571 = getelementptr %"compiler/types:Table", ptr %t569, i32 0, i32 28
  %t572 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t573 = load i64, ptr %t572, !tbaa !24
  %t576 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t571, i64 %t573)
  store { i64, ptr } %t576, ptr %l314
  br label %bb190
bb190:
  %t577 = load { i64, ptr }, ptr %l314, !tbaa !27
  store { i64, ptr } %t577, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t578 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t578, 0
  store i64 %t580, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t582 = load i64, ptr %l25, !tbaa !24
  %t583 = load i64, ptr %l24, !tbaa !24
  %t586 = icmp sgt i64 %t582, %t583
  br i1 %t586, label %bb191, label %bb192
bb191:
  %t588 = load i64, ptr %l26, !tbaa !24
  %t590 = icmp sgt i64 %t588, 0
  br i1 %t590, label %bb193, label %bb194
bb192:
  store i64 0, ptr %l320, !tbaa !24
  br label %bb196
bb193:
  %t592 = load i64, ptr %l25, !tbaa !24
  %t593 = load i64, ptr %l24, !tbaa !24
  %t596 = sub i64 %t592, %t593
  %t597 = load i64, ptr %l26, !tbaa !24
  %t600 = add i64 %t596, %t597
  %t602 = sub i64 %t600, 1
  %t603 = load i64, ptr %l26, !tbaa !24
  %t606 = sdiv i64 %t602, %t603
  store i64 %t606, ptr %l323, !tbaa !24
  br label %bb195
bb194:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb195
bb195:
  %t608 = load i64, ptr %l323, !tbaa !24
  store i64 %t608, ptr %l320, !tbaa !24
  br label %bb196
bb196:
  %t609 = load i64, ptr %l320, !tbaa !24
  store i64 %t609, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb197
bb197:
  store %olang.scope zeroinitializer, ptr %s29
  %t610 = load i64, ptr %l28, !tbaa !24
  %t611 = load i64, ptr %l27, !tbaa !24
  %t614 = icmp slt i64 %t610, %t611
  %t616 = xor i1 %t614, true
  br i1 %t616, label %bb198, label %bb199
bb198:
  call void @__olang_scope_close(ptr %s29)
  br label %bb208
bb199:
  br label %bb200
bb200:
  %t618 = load i64, ptr %l24, !tbaa !24
  %t619 = load i64, ptr %l28, !tbaa !24
  %t620 = load i64, ptr %l26, !tbaa !24
  %t623 = mul i64 %t619, %t620
  %t626 = add i64 %t618, %t623
  store i64 %t626, ptr %l29, !tbaa !24
  %t628 = load i64, ptr %l29, !tbaa !24
  %t630 = icmp sgt i64 %t628, 0
  br i1 %t630, label %bb201, label %bb202
bb201:
  %t632 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t632, i8 44)
  br label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb204
bb204:
  %t634 = load ptr, ptr %l1, !tbaa !29
  store ptr %t634, ptr %l344, !tbaa !29
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/types:Table", ptr %t635, i32 0, i32 0
  %t638 = load ptr, ptr %t637, !tbaa !29
  %t639 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t639, ptr %l347, !tbaa !27
  %t640 = load i64, ptr %l29, !tbaa !24
  %t642 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr i64, ptr %t643, i64 %t640
  %t645 = load i64, ptr %t644, !tbaa !34
  %t647 = trunc i64 %t645 to i32
  %t651 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t638, i32 %t647)
  store { i64, ptr } %t651, ptr %l352
  br label %bb205
bb205:
  %t652 = load ptr, ptr %l344, !tbaa !29
  %t653 = load { i64, ptr }, ptr %l352, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t652, { i64, ptr } %t653)
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s29)
  br label %bb207
bb207:
  %t654 = load i64, ptr %l28, !tbaa !24
  %t656 = add i64 %t654, 1
  store i64 %t656, ptr %l28, !tbaa !24
  br label %bb197
bb208:
  %t658 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t658, i8 125)
  br label %bb209
bb209:
  br label %bb210
bb210:
  %t660 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t661 = load i64, ptr %t660, !tbaa !24
  %t663 = icmp ne i64 %t661, 0
  br i1 %t663, label %bb211, label %bb212
bb211:
  store %olang.scope zeroinitializer, ptr %s32
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/types:Table", ptr %t665, i32 0, i32 26
  %t668 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t669 = load i64, ptr %t668, !tbaa !24
  %t672 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t667, i64 %t669)
  store { i64, ptr } %t672, ptr %l361
  br label %bb213
bb212:
  br label %bb233
bb213:
  %t673 = load { i64, ptr }, ptr %l361, !tbaa !27
  store { i64, ptr } %t673, ptr %l30, !tbaa !27
  %t674 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s32, ptr %t674, { i64, ptr } { i64 3, ptr @.d38 })
  br label %bb214
bb214:
  store i64 0, ptr %l31, !tbaa !24
  %t676 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t678 = extractvalue { i64, ptr } %t676, 0
  store i64 %t678, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t680 = load i64, ptr %l32, !tbaa !24
  %t681 = load i64, ptr %l31, !tbaa !24
  %t684 = icmp sgt i64 %t680, %t681
  br i1 %t684, label %bb215, label %bb216
bb215:
  %t686 = load i64, ptr %l33, !tbaa !24
  %t688 = icmp sgt i64 %t686, 0
  br i1 %t688, label %bb217, label %bb218
bb216:
  store i64 0, ptr %l368, !tbaa !24
  br label %bb220
bb217:
  %t690 = load i64, ptr %l32, !tbaa !24
  %t691 = load i64, ptr %l31, !tbaa !24
  %t694 = sub i64 %t690, %t691
  %t695 = load i64, ptr %l33, !tbaa !24
  %t698 = add i64 %t694, %t695
  %t700 = sub i64 %t698, 1
  %t701 = load i64, ptr %l33, !tbaa !24
  %t704 = sdiv i64 %t700, %t701
  store i64 %t704, ptr %l371, !tbaa !24
  br label %bb219
bb218:
  store i64 0, ptr %l371, !tbaa !24
  br label %bb219
bb219:
  %t706 = load i64, ptr %l371, !tbaa !24
  store i64 %t706, ptr %l368, !tbaa !24
  br label %bb220
bb220:
  %t707 = load i64, ptr %l368, !tbaa !24
  store i64 %t707, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb221
bb221:
  store %olang.scope zeroinitializer, ptr %s34
  %t708 = load i64, ptr %l35, !tbaa !24
  %t709 = load i64, ptr %l34, !tbaa !24
  %t712 = icmp slt i64 %t708, %t709
  %t714 = xor i1 %t712, true
  br i1 %t714, label %bb222, label %bb223
bb222:
  call void @__olang_scope_close(ptr %s34)
  br label %bb231
bb223:
  br label %bb224
bb224:
  %t716 = load i64, ptr %l31, !tbaa !24
  %t717 = load i64, ptr %l35, !tbaa !24
  %t718 = load i64, ptr %l33, !tbaa !24
  %t721 = mul i64 %t717, %t718
  %t724 = add i64 %t716, %t721
  store i64 %t724, ptr %l36, !tbaa !24
  %t726 = load i64, ptr %l36, !tbaa !24
  %t728 = icmp sgt i64 %t726, 0
  br i1 %t728, label %bb225, label %bb226
bb225:
  %t730 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t730, i8 44)
  br label %bb227
bb226:
  br label %bb228
bb227:
  br label %bb228
bb228:
  %t732 = load ptr, ptr %l1, !tbaa !29
  %t733 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t733, ptr %l393, !tbaa !27
  %t734 = load i64, ptr %l36, !tbaa !24
  %t736 = getelementptr { i64, ptr }, ptr %l393, i32 0, i32 1
  %t737 = load ptr, ptr %t736, !tbaa !27
  %t738 = getelementptr i64, ptr %t737, i64 %t734
  %t739 = load i64, ptr %t738, !tbaa !34
  %t741 = call i64 @__olang_fmt_i64(ptr null, i64 %t739)
  %t742 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t741)
  %t743 = call i64 @__olang_fmt_i64(ptr %t742, i64 %t739)
  %t744 = insertvalue { i64, ptr } undef, i64 %t741, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t742, 1
  %t747 = extractvalue { i64, ptr } %t745, 0
  %t748 = extractvalue { i64, ptr } %t745, 1
  %t749 = mul i64 %t747, 1
  %t750 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t749)
  call void @llvm.memcpy.p0.p0.i64(ptr %t750, ptr %t748, i64 %t749, i1 false)
  %t751 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t752 = insertvalue { i64, ptr } %t751, ptr %t750, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s34, ptr %t732, { i64, ptr } %t752)
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s34)
  br label %bb230
bb230:
  %t755 = load i64, ptr %l35, !tbaa !24
  %t757 = add i64 %t755, 1
  store i64 %t757, ptr %l35, !tbaa !24
  br label %bb221
bb231:
  %t759 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t759, i8 93)
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s32)
  br label %bb233
bb233:
  call void @__olang_scope_close(ptr %s19)
  br label %bb325
bb234:
  %t761 = load i32, ptr %l4
  %t763 = trunc i64 22 to i32
  %t764 = icmp eq i32 %t761, %t763
  br i1 %t764, label %bb235, label %bb236
bb235:
  br label %bb237
bb236:
  br label %bb242
bb237:
  %t766 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t766, i8 40)
  br label %bb238
bb238:
  %t768 = load ptr, ptr %l0, !tbaa !29
  store ptr %t768, ptr %l404, !tbaa !29
  %t769 = load ptr, ptr %l1, !tbaa !29
  store ptr %t769, ptr %l405, !tbaa !29
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t771 = load i32, ptr %l2, !tbaa !23
  %t774 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t770, i32 %t771)
  store i32 %t774, ptr %l408
  br label %bb239
bb239:
  %t775 = load ptr, ptr %l404, !tbaa !29
  %t776 = load ptr, ptr %l405, !tbaa !29
  %t777 = load i32, ptr %l408, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t775, ptr %t776, i32 %t777)
  br label %bb240
bb240:
  %t778 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t778, i8 41)
  br label %bb241
bb241:
  br label %bb325
bb242:
  %t780 = load i32, ptr %l4
  %t782 = trunc i64 23 to i32
  %t783 = icmp eq i32 %t780, %t782
  br i1 %t783, label %bb243, label %bb244
bb243:
  br label %bb245
bb244:
  br label %bb250
bb245:
  store %olang.scope zeroinitializer, ptr %s39
  %t785 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s39, ptr %t785, { i64, ptr } { i64 7, ptr @.d39 })
  br label %bb246
bb246:
  %t787 = load ptr, ptr %l0, !tbaa !29
  store ptr %t787, ptr %l413, !tbaa !29
  %t788 = load ptr, ptr %l1, !tbaa !29
  store ptr %t788, ptr %l414, !tbaa !29
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load i32, ptr %l2, !tbaa !23
  %t793 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t789, i32 %t790)
  store i32 %t793, ptr %l417
  br label %bb247
bb247:
  %t794 = load ptr, ptr %l413, !tbaa !29
  %t795 = load ptr, ptr %l414, !tbaa !29
  %t796 = load i32, ptr %l417, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t794, ptr %t795, i32 %t796)
  br label %bb248
bb248:
  %t797 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t797, i8 41)
  br label %bb249
bb249:
  call void @__olang_scope_close(ptr %s39)
  br label %bb325
bb250:
  %t799 = load i32, ptr %l4
  %t801 = trunc i64 24 to i32
  %t802 = icmp eq i32 %t799, %t801
  br i1 %t802, label %bb251, label %bb252
bb251:
  br label %bb253
bb252:
  br label %bb284
bb253:
  store %olang.scope zeroinitializer, ptr %s40
  %t804 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t804, { i64, ptr } { i64 5, ptr @.d40 })
  br label %bb254
bb254:
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load i32, ptr %l2, !tbaa !23
  %t810 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %t806, i32 %t807)
  store { i64, ptr } %t810, ptr %l424
  br label %bb255
bb255:
  %t811 = load { i64, ptr }, ptr %l424, !tbaa !27
  store { i64, ptr } %t811, ptr %l37, !tbaa !27
  %t812 = load ptr, ptr %l0, !tbaa !29
  store ptr %t812, ptr %l425, !tbaa !29
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t814 = load i32, ptr %l2, !tbaa !23
  %t817 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t813, i32 %t814)
  store i32 %t817, ptr %l428
  br label %bb256
bb256:
  %t818 = load ptr, ptr %l425, !tbaa !29
  %t819 = load i32, ptr %l428, !tbaa !23
  %t820 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t818, i32 %t819)
  store { i64, ptr } %t820, ptr %l429
  br label %bb257
bb257:
  %t821 = load { i64, ptr }, ptr %l429, !tbaa !27
  store { i64, ptr } %t821, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t822 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t824 = extractvalue { i64, ptr } %t822, 0
  store i64 %t824, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t826 = load i64, ptr %l40, !tbaa !24
  %t827 = load i64, ptr %l39, !tbaa !24
  %t830 = icmp sgt i64 %t826, %t827
  br i1 %t830, label %bb258, label %bb259
bb258:
  %t832 = load i64, ptr %l41, !tbaa !24
  %t834 = icmp sgt i64 %t832, 0
  br i1 %t834, label %bb260, label %bb261
bb259:
  store i64 0, ptr %l435, !tbaa !24
  br label %bb263
bb260:
  %t836 = load i64, ptr %l40, !tbaa !24
  %t837 = load i64, ptr %l39, !tbaa !24
  %t840 = sub i64 %t836, %t837
  %t841 = load i64, ptr %l41, !tbaa !24
  %t844 = add i64 %t840, %t841
  %t846 = sub i64 %t844, 1
  %t847 = load i64, ptr %l41, !tbaa !24
  %t850 = sdiv i64 %t846, %t847
  store i64 %t850, ptr %l438, !tbaa !24
  br label %bb262
bb261:
  store i64 0, ptr %l438, !tbaa !24
  br label %bb262
bb262:
  %t852 = load i64, ptr %l438, !tbaa !24
  store i64 %t852, ptr %l435, !tbaa !24
  br label %bb263
bb263:
  %t853 = load i64, ptr %l435, !tbaa !24
  store i64 %t853, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb264
bb264:
  store %olang.scope zeroinitializer, ptr %s42
  %t854 = load i64, ptr %l43, !tbaa !24
  %t855 = load i64, ptr %l42, !tbaa !24
  %t858 = icmp slt i64 %t854, %t855
  %t860 = xor i1 %t858, true
  br i1 %t860, label %bb265, label %bb266
bb265:
  call void @__olang_scope_close(ptr %s42)
  br label %bb282
bb266:
  br label %bb267
bb267:
  %t862 = load i64, ptr %l39, !tbaa !24
  %t863 = load i64, ptr %l43, !tbaa !24
  %t864 = load i64, ptr %l41, !tbaa !24
  %t867 = mul i64 %t863, %t864
  %t870 = add i64 %t862, %t867
  store i64 %t870, ptr %l44, !tbaa !24
  %t872 = load i64, ptr %l44, !tbaa !24
  %t874 = icmp sgt i64 %t872, 0
  br i1 %t874, label %bb268, label %bb269
bb268:
  %t876 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t876, i8 32)
  br label %bb270
bb269:
  br label %bb271
bb270:
  br label %bb271
bb271:
  %t878 = load ptr, ptr %l1, !tbaa !29
  store ptr %t878, ptr %l459, !tbaa !29
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t881 = getelementptr %"compiler/types:Table", ptr %t879, i32 0, i32 0
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t883 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t883, ptr %l462, !tbaa !27
  %t884 = load i64, ptr %l44, !tbaa !24
  %t886 = getelementptr { i64, ptr }, ptr %l462, i32 0, i32 1
  %t887 = load ptr, ptr %t886, !tbaa !27
  %t888 = getelementptr i32, ptr %t887, i64 %t884
  %t889 = load i32, ptr %t888, !tbaa !33
  %t892 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t882, i32 %t889)
  store { i64, ptr } %t892, ptr %l465
  br label %bb272
bb272:
  %t893 = load ptr, ptr %l459, !tbaa !29
  %t894 = load { i64, ptr }, ptr %l465, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t893, { i64, ptr } %t894)
  br label %bb273
bb273:
  %t895 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t895, ptr %l466, !tbaa !27
  %t896 = load i64, ptr %l44, !tbaa !24
  %t898 = getelementptr { i64, ptr }, ptr %l466, i32 0, i32 1
  %t899 = load ptr, ptr %t898, !tbaa !27
  %t900 = getelementptr i32, ptr %t899, i64 %t896
  %t901 = load i32, ptr %t900, !tbaa !33
  %t903 = icmp ne i32 %t901, 0
  br i1 %t903, label %bb274, label %bb275
bb274:
  %t905 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t905, i8 40)
  br label %bb276
bb275:
  br label %bb280
bb276:
  %t907 = load ptr, ptr %l0, !tbaa !29
  store ptr %t907, ptr %l471, !tbaa !29
  %t908 = load ptr, ptr %l1, !tbaa !29
  store ptr %t908, ptr %l472, !tbaa !29
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t910 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t910, ptr %l474, !tbaa !27
  %t911 = load i64, ptr %l44, !tbaa !24
  %t913 = getelementptr { i64, ptr }, ptr %l474, i32 0, i32 1
  %t914 = load ptr, ptr %t913, !tbaa !27
  %t915 = getelementptr i32, ptr %t914, i64 %t911
  %t916 = load i32, ptr %t915, !tbaa !33
  %t919 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t909, i32 %t916)
  store i32 %t919, ptr %l477
  br label %bb277
bb277:
  %t920 = load ptr, ptr %l471, !tbaa !29
  %t921 = load ptr, ptr %l472, !tbaa !29
  %t922 = load i32, ptr %l477, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %t920, ptr %t921, i32 %t922)
  br label %bb278
bb278:
  %t923 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t923, i8 41)
  br label %bb279
bb279:
  br label %bb280
bb280:
  call void @__olang_scope_close(ptr %s42)
  br label %bb281
bb281:
  %t925 = load i64, ptr %l43, !tbaa !24
  %t927 = add i64 %t925, 1
  store i64 %t927, ptr %l43, !tbaa !24
  br label %bb264
bb282:
  %t929 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t929, i8 125)
  br label %bb283
bb283:
  call void @__olang_scope_close(ptr %s40)
  br label %bb325
bb284:
  %t931 = load i32, ptr %l4
  %t933 = trunc i64 25 to i32
  %t934 = icmp eq i32 %t931, %t933
  br i1 %t934, label %bb285, label %bb286
bb285:
  br label %bb287
bb286:
  br label %bb289
bb287:
  store %olang.scope zeroinitializer, ptr %s46
  %t936 = load ptr, ptr %l1, !tbaa !29
  %t937 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 1
  %t938 = load i64, ptr %t937, !tbaa !24
  %t939 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t940 = load i64, ptr %t939, !tbaa !24
  %t941 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 1
  %t942 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 0
  %t944 = call i64 @__olang_fmt_i64(ptr null, i64 %t938)
  %t945 = add i64 %t942, %t944
  %t946 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 1
  %t947 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 0
  %t948 = add i64 %t945, %t947
  %t950 = call i64 @__olang_fmt_i64(ptr null, i64 %t940)
  %t951 = add i64 %t948, %t950
  %t952 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 1
  %t953 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 0
  %t954 = add i64 %t951, %t953
  %t955 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t954)
  call void @olang_textcopy(ptr %t955, ptr %t941, i64 %t942)
  %t956 = getelementptr i8, ptr %t955, i64 %t942
  %t957 = call i64 @__olang_fmt_i64(ptr %t956, i64 %t938)
  %t958 = getelementptr i8, ptr %t956, i64 %t944
  call void @olang_textcopy(ptr %t958, ptr %t946, i64 %t947)
  %t959 = getelementptr i8, ptr %t958, i64 %t947
  %t960 = call i64 @__olang_fmt_i64(ptr %t959, i64 %t940)
  %t961 = getelementptr i8, ptr %t959, i64 %t950
  call void @olang_textcopy(ptr %t961, ptr %t952, i64 %t953)
  %t962 = insertvalue { i64, ptr } undef, i64 %t954, 0
  %t963 = insertvalue { i64, ptr } %t962, ptr %t955, 1
  %t965 = extractvalue { i64, ptr } %t963, 0
  %t966 = extractvalue { i64, ptr } %t963, 1
  %t967 = mul i64 %t965, 1
  %t968 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t967)
  call void @llvm.memcpy.p0.p0.i64(ptr %t968, ptr %t966, i64 %t967, i1 false)
  %t969 = insertvalue { i64, ptr } undef, i64 %t965, 0
  %t970 = insertvalue { i64, ptr } %t969, ptr %t968, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s46, ptr %t936, { i64, ptr } %t970)
  br label %bb288
bb288:
  call void @__olang_scope_close(ptr %s46)
  br label %bb325
bb289:
  %t973 = load i32, ptr %l4
  %t975 = trunc i64 26 to i32
  %t976 = icmp eq i32 %t973, %t975
  br i1 %t976, label %bb290, label %bb291
bb290:
  br label %bb292
bb291:
  br label %bb311
bb292:
  %t978 = load ptr, ptr %l0, !tbaa !29
  %t979 = load i32, ptr %l2, !tbaa !23
  %t982 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t978, i32 %t979)
  store i32 %t982, ptr %l493
  br label %bb293
bb293:
  %t983 = load i32, ptr %l493, !tbaa !23
  store i32 %t983, ptr %l45, !tbaa !23
  %t984 = load i32, ptr %l45, !tbaa !23
  %t985 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t988 = icmp eq i32 %t984, %t985
  br i1 %t988, label %bb294, label %bb295
bb294:
  store %olang.scope zeroinitializer, ptr %s49
  %t990 = load ptr, ptr %l1, !tbaa !29
  store ptr %t990, ptr %l497, !tbaa !29
  %t991 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t992 = load i64, ptr %t991, !tbaa !24
  %t994 = icmp ne i64 %t992, 0
  br i1 %t994, label %bb296, label %bb297
bb295:
  %t996 = load ptr, ptr %l0, !tbaa !29
  %t997 = load i32, ptr %l45, !tbaa !23
  %t1000 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t996, i32 %t997)
  store i1 %t1000, ptr %l503
  br label %bb300
bb296:
  store { i64, ptr } { i64 4, ptr @.d44 }, ptr %l500, !tbaa !27
  br label %bb298
bb297:
  store { i64, ptr } { i64 5, ptr @.d45 }, ptr %l500, !tbaa !27
  br label %bb298
bb298:
  %t1001 = load ptr, ptr %l497, !tbaa !29
  %t1002 = load { i64, ptr }, ptr %l500, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s49, ptr %t1001, { i64, ptr } %t1002)
  br label %bb299
bb299:
  call void @__olang_scope_close(ptr %s49)
  br label %bb310
bb300:
  %t1003 = load i1, ptr %l503, !tbaa !21
  br i1 %t1003, label %bb301, label %bb302
bb301:
  %t1004 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1005 = load i64, ptr %t1004, !tbaa !24
  %t1007 = icmp slt i64 %t1005, 0
  store i1 %t1007, ptr %l504, !tbaa !21
  br label %bb303
bb302:
  store i1 false, ptr %l504, !tbaa !21
  br label %bb303
bb303:
  %t1009 = load i1, ptr %l504, !tbaa !21
  br i1 %t1009, label %bb304, label %bb305
bb304:
  store %olang.scope zeroinitializer, ptr %s51
  %t1010 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1010, ptr %l507, !tbaa !29
  %t1011 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1012 = load i64, ptr %t1011, !tbaa !24
  %t1014 = call { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %s51, i64 %t1012)
  store { i64, ptr } %t1014, ptr %l509
  br label %bb306
bb305:
  store %olang.scope zeroinitializer, ptr %s52
  %t1015 = load ptr, ptr %l1, !tbaa !29
  %t1016 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t1017 = load i64, ptr %t1016, !tbaa !24
  %t1019 = call i64 @__olang_fmt_i64(ptr null, i64 %t1017)
  %t1020 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1019)
  %t1021 = call i64 @__olang_fmt_i64(ptr %t1020, i64 %t1017)
  %t1022 = insertvalue { i64, ptr } undef, i64 %t1019, 0
  %t1023 = insertvalue { i64, ptr } %t1022, ptr %t1020, 1
  %t1025 = extractvalue { i64, ptr } %t1023, 0
  %t1026 = extractvalue { i64, ptr } %t1023, 1
  %t1027 = mul i64 %t1025, 1
  %t1028 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1027)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1028, ptr %t1026, i64 %t1027, i1 false)
  %t1029 = insertvalue { i64, ptr } undef, i64 %t1025, 0
  %t1030 = insertvalue { i64, ptr } %t1029, ptr %t1028, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s52, ptr %t1015, { i64, ptr } %t1030)
  br label %bb308
bb306:
  %t1033 = load { i64, ptr }, ptr %l509, !tbaa !27
  %t1034 = extractvalue { i64, ptr } %t1033, 0
  %t1035 = extractvalue { i64, ptr } %t1033, 1
  %t1036 = mul i64 %t1034, 1
  %t1037 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1036)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1037, ptr %t1035, i64 %t1036, i1 false)
  %t1038 = insertvalue { i64, ptr } undef, i64 %t1034, 0
  %t1039 = insertvalue { i64, ptr } %t1038, ptr %t1037, 1
  %t1040 = load ptr, ptr %l507, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s51, ptr %t1040, { i64, ptr } %t1039)
  br label %bb307
bb307:
  call void @__olang_scope_close(ptr %s51)
  br label %bb309
bb308:
  call void @__olang_scope_close(ptr %s52)
  br label %bb309
bb309:
  br label %bb310
bb310:
  br label %bb325
bb311:
  %t1042 = load i32, ptr %l4
  %t1044 = trunc i64 27 to i32
  %t1045 = icmp eq i32 %t1042, %t1044
  br i1 %t1045, label %bb312, label %bb313
bb312:
  br label %bb314
bb313:
  br label %bb317
bb314:
  store %olang.scope zeroinitializer, ptr %s54
  %t1047 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1047, ptr %l517, !tbaa !29
  %t1048 = load ptr, ptr %l0, !tbaa !29
  %t1049 = load i32, ptr %l2, !tbaa !23
  %t1052 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %t1048, i32 %t1049)
  store { i64, ptr } %t1052, ptr %l520
  br label %bb315
bb315:
  %t1053 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t1054 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  %t1055 = load { i64, ptr }, ptr %l520, !tbaa !27
  %t1056 = extractvalue { i64, ptr } %t1055, 1
  %t1057 = extractvalue { i64, ptr } %t1055, 0
  %t1058 = add i64 %t1054, %t1057
  %t1059 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 1
  %t1060 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 0
  %t1061 = add i64 %t1058, %t1060
  %t1062 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1061)
  call void @olang_textcopy(ptr %t1062, ptr %t1053, i64 %t1054)
  %t1063 = getelementptr i8, ptr %t1062, i64 %t1054
  call void @olang_textcopy(ptr %t1063, ptr %t1056, i64 %t1057)
  %t1064 = getelementptr i8, ptr %t1063, i64 %t1057
  call void @olang_textcopy(ptr %t1064, ptr %t1059, i64 %t1060)
  %t1065 = insertvalue { i64, ptr } undef, i64 %t1061, 0
  %t1066 = insertvalue { i64, ptr } %t1065, ptr %t1062, 1
  %t1068 = extractvalue { i64, ptr } %t1066, 0
  %t1069 = extractvalue { i64, ptr } %t1066, 1
  %t1070 = mul i64 %t1068, 1
  %t1071 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1070)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1071, ptr %t1069, i64 %t1070, i1 false)
  %t1072 = insertvalue { i64, ptr } undef, i64 %t1068, 0
  %t1073 = insertvalue { i64, ptr } %t1072, ptr %t1071, 1
  %t1074 = load ptr, ptr %l517, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s54, ptr %t1074, { i64, ptr } %t1073)
  br label %bb316
bb316:
  call void @__olang_scope_close(ptr %s54)
  br label %bb325
bb317:
  %t1076 = load i32, ptr %l4
  %t1078 = trunc i64 29 to i32
  %t1079 = icmp eq i32 %t1076, %t1078
  br i1 %t1079, label %bb318, label %bb319
bb318:
  br label %bb320
bb319:
  br label %bb324
bb320:
  store %olang.scope zeroinitializer, ptr %s56
  %t1081 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s56, ptr %t1081, { i64, ptr } { i64 4, ptr @.d48 })
  br label %bb321
bb321:
  %t1083 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1083, ptr %l526, !tbaa !29
  %t1084 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1084, ptr %l527, !tbaa !29
  %t1085 = load ptr, ptr %l0, !tbaa !29
  %t1086 = load i32, ptr %l2, !tbaa !23
  %t1089 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t1085, i32 %t1086)
  store i32 %t1089, ptr %l530
  br label %bb322
bb322:
  %t1090 = load ptr, ptr %l526, !tbaa !29
  %t1091 = load ptr, ptr %l527, !tbaa !29
  %t1092 = load i32, ptr %l530, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t1090, ptr %t1091, i32 %t1092)
  br label %bb323
bb323:
  call void @__olang_scope_close(ptr %s56)
  br label %bb325
bb324:
  call void @__olang_check_failed(ptr @olang_loc_bd4ce41e1f7e504b_596b58263987420f)
  unreachable
bb325:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l5, !tbaa !23
  %t27 = load i32, ptr %l5, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i32
  %l28 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 5
  %t6 = sext i32 %a1 to i64
  %t9 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store { i64, ptr } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l18, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  store i32 %t29, ptr %l6, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load i32, ptr %l2, !tbaa !23
  %t37 = load i32, ptr %l23, !tbaa !23
  %t39 = icmp sgt i32 %t37, %t36
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l28
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t46 = load i32, ptr %l28, !tbaa !23
  store i32 %t46, ptr %l2, !tbaa !23
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb2
bb12:
  %t51 = load i32, ptr %l2, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edepthOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/types:Table", ptr %a0, i32 0, i32 4
  %t6 = sext i32 %a1 to i64
  %t9 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t3, i64 %t6)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 3, ptr @.d49 }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l12
  br label %bb5
bb5:
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = sdiv i64 %t30, 8
  %t32 = extractvalue { i64, ptr } { i64 8, ptr @.d50 }, 1
  %t33 = extractvalue { i64, ptr } { i64 8, ptr @.d50 }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d51 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d51 }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t32, i64 %t33)
  %t41 = getelementptr i8, ptr %t40, i64 %t33
  %t42 = call i64 @__olang_fmt_i64(ptr %t41, i64 %t31)
  %t43 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l18 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 18 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load i32, ptr %l11, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  br label %bb18
bb6:
  %t18 = load i32, ptr %l2
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t23 = load i32, ptr %l2
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l18
  br label %bb12
bb12:
  %t33 = load i32, ptr %l18, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i32 0, ptr %l6, !tbaa !23
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_94d95030786c6de_dc670b9e390cf1a)
  unreachable
bb18:
  %t34 = load i32, ptr %l6, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i8 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsState(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i8
  %l14 = alloca i8
  %rv = alloca i8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 30
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/types:Table", ptr %t15, i32 0, i32 30
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t17, i64 %t18)
  store i8 %t21, ptr %l14
  br label %bb4
bb3:
  store i8 0, ptr %l10, !tbaa !22
  br label %bb5
bb4:
  %t22 = load i8, ptr %l14, !tbaa !22
  store i8 %t22, ptr %l10, !tbaa !22
  br label %bb5
bb5:
  %t23 = load i8, ptr %l10, !tbaa !22
  store i8 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l15 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/types:data" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 2
  %t4 = load %"compiler/types:data", ptr %l1
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %t3, %"compiler/types:data" %t4)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i32, ptr %l8, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l4, !tbaa !23
  br label %bb4
bb4:
  %t13 = load i32, ptr %l4, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t16 = icmp sge i32 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i32, ptr %l3, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 1
  %t24 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = trunc i64 %t25 to i32
  store i32 %t26, ptr %l3, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/types:Table", ptr %t29, i32 0, i32 1
  %t32 = load %"compiler/types:data", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %t31, %"compiler/types:data" %t32)
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/types:Table", ptr %t35, i32 0, i32 2
  %t38 = load %"compiler/types:data", ptr %l1
  %t39 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %t37, %"compiler/types:data" %t38, i32 %t39)
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/types:Table", ptr %t43, i32 0, i32 4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t45, i32 %a2)
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/types:Table", ptr %t49, i32 0, i32 18
  %t52 = load i64, ptr @G_2ecompiler_2ftypes_2eNotLaidOut, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t51, i64 %t52)
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/types:Table", ptr %t55, i32 0, i32 19
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t57, i64 0)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t59, i32 0, i32 20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t61, i64 1)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/types:Table", ptr %t63, i32 0, i32 21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 -1)
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/types:Table", ptr %t67, i32 0, i32 23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t69, i64 -1)
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t73, { i64, ptr } { i64 0, ptr @.d52 })
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/types:Table", ptr %t75, i32 0, i32 25
  %t78 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t77, i32 %t78)
  br label %bb18
bb18:
  %t81 = load i32, ptr %l3, !tbaa !23
  store i32 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca i64
  %l44 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %a2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t61, { i64, ptr } { i64 2, ptr @.d53 })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t65, ptr %l44, !tbaa !27
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 %t66
  %t71 = load i32, ptr %t70, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t71)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb8
bb18:
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l11 = alloca i1
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca i64
  %l36 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = insertvalue { i64, i64 } undef, i64 4, 0
  %t10 = insertvalue { i64, i64 } %t9, i64 4, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l16
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t31
  %t36 = load i32, ptr %t35, !tbaa !33
  store i32 %t36, ptr %l7, !tbaa !23
  %t38 = load i32, ptr %l7, !tbaa !23
  %t40 = icmp ne i32 %t38, 0
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l7, !tbaa !23
  %t46 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l31, !tbaa !24
  %t50 = icmp sgt i64 %t48, %t47
  store i1 %t50, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l7, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t57, ptr %l36
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t58 = load i64, ptr %l36, !tbaa !24
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb6
bb19:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 7
  %t67 = sdiv i64 %t65, 8
  %t69 = mul i64 %t67, 8
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 23
  %t76 = sext i32 %a1 to i64
  %t77 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t76, i64 %t77)
  br label %bb20
bb20:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t83 = add i64 8, %t81
  %t85 = insertvalue { i64, i64 } undef, i64 %t83, 0
  %t86 = insertvalue { i64, i64 } %t85, i64 8, 1
  store { i64, i64 } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l31 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 21
  store ptr %t3, ptr %l11, !tbaa !29
  %t6 = sext i32 %a1 to i64
  store i64 %t6, ptr %l13, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/types:Table", ptr %t7, i32 0, i32 22
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13, i64 %t14)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t15, i32 %a2)
  store { i64, ptr } %t19, ptr %l19
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  store i32 %t39, ptr %l8, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l8, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l31
  br label %bb8
bb8:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load i64, ptr %l9, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = mul i64 %t65, %t66
  store i64 %t69, ptr %l3, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 22
  %t74 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t73, i64 %t74)
  br label %bb12
bb12:
  %t77 = load i64, ptr %l3, !tbaa !24
  store i64 %t77, ptr %l47, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l8, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l50
  br label %bb13
bb13:
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = add i64 %t83, %t84
  store i64 %t85, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l6, !tbaa !24
  br label %bb4
bb15:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t92 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l4, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t106 = load i64, ptr %l4, !tbaa !24
  %t108 = insertvalue { i64, i64 } undef, i64 %t105, 0
  %t110 = insertvalue { i64, i64 } %t108, i64 %t106, 1
  store { i64, i64 } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l26 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l6, !tbaa !23
  %t29 = icmp eq i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t33 = xor i1 %a2, true
  br i1 %t33, label %bb8, label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l26
  br label %bb11
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/types:Table", ptr %t40, i32 0, i32 31
  store i1 true, ptr %t42, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb2
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7
  store i32 %t10, ptr %l2
  %t11 = load i32, ptr %l2
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2estructName(ptr %v0, ptr %v1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  br label %bb27
bb7:
  %t22 = load i32, ptr %l2
  %t24 = trunc i64 1 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l18
  br label %bb11
bb11:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l8, !tbaa !27
  br label %bb27
bb12:
  %t33 = load i32, ptr %l2
  %t35 = trunc i64 2 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr @.d54 }, ptr %l21, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  br label %bb27
bb16:
  %t40 = load i32, ptr %l2
  %t42 = trunc i64 4 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l25, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l28
  br label %bb20
bb20:
  %t51 = load ptr, ptr %l25, !tbaa !29
  %t52 = load i32, ptr %l28, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t51, i32 %t52)
  store { i64, ptr } %t53, ptr %l29
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l8, !tbaa !27
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 1, ptr @.d55 }, ptr %l31, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l8, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b0143a025c7cdb06_8f46c74feff323b2)
  unreachable
bb27:
  %t63 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l33, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l34, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l33, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t76, ptr %l8, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8
  %t14 = trunc i64 19 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i32, ptr %l14, !tbaa !23
  %t23 = icmp eq i32 %t22, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l11, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %a0, i32 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/types:Table", ptr %t5, i32 0, i32 30
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sle i64 %t11, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t19, i8 0)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb1
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/types:Table", ptr %t21, i32 0, i32 30
  %t24 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %t23, i64 %t24, i8 %a2)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l8 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  %t15 = load i32, ptr %l3
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  %t20 = load i32, ptr %l3
  %t22 = trunc i64 3 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb30
bb7:
  %t25 = load i32, ptr %l3
  %t27 = trunc i64 4 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb30
bb9:
  %t30 = load i32, ptr %l3
  %t32 = trunc i64 5 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %bb30
bb11:
  %t35 = load i32, ptr %l3
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb12, label %bb13
bb12:
  br label %bb30
bb13:
  %t40 = load i32, ptr %l3
  %t42 = trunc i64 7 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb30
bb15:
  %t45 = load i32, ptr %l3
  %t47 = trunc i64 8 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb16, label %bb17
bb16:
  br label %bb30
bb17:
  %t50 = load i32, ptr %l3
  %t52 = trunc i64 9 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb18, label %bb19
bb18:
  br label %bb30
bb19:
  %t55 = load i32, ptr %l3
  %t57 = trunc i64 10 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb20, label %bb21
bb20:
  br label %bb30
bb21:
  %t60 = load i32, ptr %l3
  %t62 = trunc i64 11 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  %t65 = load i32, ptr %l3
  %t67 = trunc i64 12 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  %t70 = load i32, ptr %l3
  %t72 = trunc i64 13 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t75 = load i32, ptr %l3
  %t77 = trunc i64 14 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t80 = load i32, ptr %l1, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t84 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimLlvm, i64 0, i64 %t82
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !37
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t87, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l8, !tbaa !27
  br label %bb85
bb31:
  %t93 = load i32, ptr %l3
  %t95 = trunc i64 16 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr @.d56 }, ptr %l43, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t98, ptr %l8, !tbaa !27
  br label %bb85
bb35:
  %t100 = load i32, ptr %l3
  %t102 = trunc i64 17 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr @.d57 }, ptr %l47, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l8, !tbaa !27
  br label %bb85
bb39:
  %t107 = load i32, ptr %l3
  %t109 = trunc i64 21 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store { i64, ptr } { i64 12, ptr @.d58 }, ptr %l51, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t112, ptr %l8, !tbaa !27
  br label %bb85
bb43:
  %t114 = load i32, ptr %l3
  %t116 = trunc i64 20 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb57
bb46:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l55, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l1, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l58
  br label %bb47
bb47:
  %t125 = load ptr, ptr %l55, !tbaa !29
  %t126 = load i32, ptr %l58, !tbaa !23
  %t127 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t127, ptr %l59
  br label %bb48
bb48:
  %t128 = load i1, ptr %l59, !tbaa !21
  br i1 %t128, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 12, ptr @.d59 }, ptr %l61, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t129, ptr %l60, !tbaa !27
  br label %bb56
bb50:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l63, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l66
  br label %bb51
bb51:
  %t137 = load ptr, ptr %l63, !tbaa !29
  %t138 = load i32, ptr %l66, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t139, ptr %l67
  br label %bb52
bb52:
  %t140 = load i32, ptr %l67
  %t142 = trunc i64 29 to i32
  %t143 = icmp eq i32 %t140, %t142
  br i1 %t143, label %bb53, label %bb54
bb53:
  store { i64, ptr } { i64 12, ptr @.d60 }, ptr %l71, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t145, ptr %l70, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 3, ptr @.d61 }, ptr %l73, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t147, ptr %l70, !tbaa !27
  br label %bb55
bb55:
  %t149 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t149, ptr %l60, !tbaa !27
  br label %bb56
bb56:
  %t150 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t150, ptr %l8, !tbaa !27
  br label %bb85
bb57:
  %t151 = load i32, ptr %l3
  %t153 = trunc i64 19 to i32
  %t154 = icmp eq i32 %t151, %t153
  br i1 %t154, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l1, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %t156, i32 %t157)
  store { i64, ptr } %t160, ptr %l79
  br label %bb61
bb61:
  %t161 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t161, ptr %l8, !tbaa !27
  br label %bb85
bb62:
  %t162 = load i32, ptr %l3
  %t164 = trunc i64 22 to i32
  %t165 = icmp eq i32 %t162, %t164
  br i1 %t165, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  %t167 = load i32, ptr %l3
  %t169 = trunc i64 23 to i32
  %t170 = icmp eq i32 %t167, %t169
  br i1 %t170, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l84, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l87
  br label %bb68
bb68:
  %t178 = load ptr, ptr %l84, !tbaa !29
  %t179 = load i32, ptr %l87, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %t178, i32 %t179)
  store { i64, ptr } %t180, ptr %l88
  br label %bb69
bb69:
  %t181 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t181, ptr %l8, !tbaa !27
  br label %bb85
bb70:
  %t182 = load i32, ptr %l3
  %t184 = trunc i64 24 to i32
  %t185 = icmp eq i32 %t182, %t184
  br i1 %t185, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l1, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t187, i32 %t188)
  store { i64, ptr } %t191, ptr %l93
  br label %bb74
bb74:
  %t192 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t192, ptr %l8, !tbaa !27
  br label %bb85
bb75:
  %t193 = load i32, ptr %l3
  %t195 = trunc i64 18 to i32
  %t196 = icmp eq i32 %t193, %t195
  br i1 %t196, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i32, ptr %l1, !tbaa !23
  %t202 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %t198, i32 %t199)
  store { i64, ptr } %t202, ptr %l98
  br label %bb79
bb79:
  %t203 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t203, ptr %l8, !tbaa !27
  br label %bb85
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store { i64, ptr } { i64 1, ptr @.d62 }, ptr %l99, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t204, ptr %l8, !tbaa !27
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_bbfcd5581dbe335b_bbf57adf6fe10b0f)
  unreachable
bb85:
  %t206 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  store i64 %t207, ptr %l101, !tbaa !24
  %t208 = load i64, ptr %l101, !tbaa !24
  %t209 = mul i64 %t208, 1
  %t210 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t209)
  %t211 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  store { i64, ptr } %t212, ptr %l102, !tbaa !27
  %t213 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = load i64, ptr %l101, !tbaa !24
  %t218 = mul i64 %t217, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t214, ptr %t216, i64 %t218, i1 false)
  %t219 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t219, ptr %l8, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t220, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2estructName(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i32
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, i64 }
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  %t13 = icmp eq i32 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d63 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d63 }, 0
  %t19 = extractvalue { i64, ptr } %t15, 1
  %t20 = extractvalue { i64, ptr } %t15, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 0
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t16, i64 %t17)
  %t26 = getelementptr i8, ptr %t25, i64 %t17
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = getelementptr i8, ptr %t26, i64 %t20
  call void @olang_textcopy(ptr %t27, ptr %t22, i64 %t23)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t25, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr @.d65 })
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l19
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37
ok.37:
  store i64 %t34, ptr %l18
  br label %bb6
bb6:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l16, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l16, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l16, !tbaa !24
  store i64 %t43, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %s0, ptr %t44, i32 %t45)
  store { i64, ptr } %t48, ptr %l24
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t57 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %s0, { i64, ptr } %t55)
  store { i64, i64 } %t57, ptr %l26
  br label %bb11
bb11:
  %t58 = load { i64, i64 }, ptr %l26
  store { i64, i64 } %t58, ptr %l4
  %t59 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 0
  %t60 = load i64, ptr %t59, !tbaa !65
  store i64 %t60, ptr %l5, !tbaa !65
  %t62 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !65
  store i64 %t63, ptr %l6, !tbaa !65
  %t65 = load i64, ptr %l3, !tbaa !24
  store i64 %t65, ptr %l29, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l30, !tbaa !24
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load i64, ptr %l29, !tbaa !24
  %t71 = icmp sle i64 0, %t70
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb14:
  %t73 = load i64, ptr %l29, !tbaa !24
  %t74 = load i64, ptr %l30, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb16:
  %t77 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l29, !tbaa !24
  %t80 = getelementptr i8, ptr %t78, i64 0
  %t81 = sub i64 %t79, 0
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  store { i64, ptr } %t83, ptr %l34, !tbaa !27
  %t84 = load i64, ptr %l5, !tbaa !65
  %t86 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t84)
  store { i64, ptr } %t86, ptr %l36
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb18:
  %t87 = load i64, ptr %l6, !tbaa !65
  %t89 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t87)
  store { i64, ptr } %t89, ptr %l38
  br label %bb19
bb19:
  %t90 = extractvalue { i64, ptr } { i64 2, ptr @.d66 }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr @.d66 }, 0
  %t92 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr @.d67 }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr @.d67 }, 0
  %t98 = add i64 %t95, %t97
  %t99 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = add i64 %t98, %t101
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t90, i64 %t91)
  %t111 = getelementptr i8, ptr %t110, i64 %t91
  call void @olang_textcopy(ptr %t111, ptr %t93, i64 %t94)
  %t112 = getelementptr i8, ptr %t111, i64 %t94
  call void @olang_textcopy(ptr %t112, ptr %t96, i64 %t97)
  %t113 = getelementptr i8, ptr %t112, i64 %t97
  call void @olang_textcopy(ptr %t113, ptr %t100, i64 %t101)
  %t114 = getelementptr i8, ptr %t113, i64 %t101
  call void @olang_textcopy(ptr %t114, ptr %t104, i64 %t105)
  %t115 = getelementptr i8, ptr %t114, i64 %t105
  call void @olang_textcopy(ptr %t115, ptr %t107, i64 %t108)
  %t116 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t110, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunnamedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l52 = alloca i1
  %l55 = alloca { i64, ptr }
  %l62 = alloca i32
  %l66 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp sle i64 %t13, 2305843009213693951
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_ebf284414dbafd61_1a8e1f26a2703ea5)
  unreachable
bb4:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = mul i64 %t16, 4
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store i1 true, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ebf284414dbafd61_1a8e1f26a2703ea5)
  unreachable
bb6:
  %t32 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l27, !tbaa !24
  store i64 %t52, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l24, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l45, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t74, ptr %l47, !tbaa !27
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t75
  %t80 = load i32, ptr %t79, !tbaa !33
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t73, i32 %t80)
  store i32 %t83, ptr %l50
  br label %bb16
bb16:
  %t84 = load i32, ptr %l50, !tbaa !23
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i32, ptr %t87, i64 %t85
  store i32 %t84, ptr %t88, !tbaa !33
  %t89 = load i1, ptr %l4, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t91 = load i64, ptr %l10, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t91
  %t96 = load i32, ptr %t95, !tbaa !33
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  %t106 = icmp eq i32 %t96, %t103
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb19
bb19:
  %t108 = load i1, ptr %l52, !tbaa !21
  store i1 %t108, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t109 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  %t113 = load i1, ptr %l4, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t115 = load i32, ptr %l1, !tbaa !23
  store i32 %t115, ptr %l62, !tbaa !23
  br label %bb25
bb23:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t117, { i64, ptr } %t118)
  store i32 %t121, ptr %l66
  br label %bb24
bb24:
  %t122 = load i32, ptr %l66, !tbaa !23
  store i32 %t122, ptr %l62, !tbaa !23
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i32, ptr %l62, !tbaa !23
  store i32 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store i64 -3750763034362895579, ptr %l1, !tbaa !65
  store i64 7809847782465536322, ptr %l2, !tbaa !65
  store i64 1099511628211, ptr %l3, !tbaa !65
  store { i64, ptr } %a0, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l7, !tbaa !22
  %t23 = load i64, ptr %l1, !tbaa !65
  %t24 = load i8, ptr %l7, !tbaa !22
  %t27 = zext i8 %t24 to i64
  %t30 = xor i64 %t23, %t27
  %t31 = load i64, ptr %l3, !tbaa !65
  %t34 = mul i64 %t30, %t31
  store i64 %t34, ptr %l1, !tbaa !65
  %t36 = load i64, ptr %l2, !tbaa !65
  %t37 = load i8, ptr %l7, !tbaa !22
  %t40 = zext i8 %t37 to i64
  %t43 = xor i64 %t36, %t40
  %t44 = load i64, ptr %l3, !tbaa !65
  %t47 = mul i64 %t43, %t44
  store i64 %t47, ptr %l2, !tbaa !65
  %t49 = load i64, ptr %l2, !tbaa !65
  %t50 = load i64, ptr %l2, !tbaa !65
  %t52 = lshr i64 %t50, 29
  %t55 = xor i64 %t49, %t52
  store i64 %t55, ptr %l2, !tbaa !65
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb1
bb6:
  %t61 = load i64, ptr %l1, !tbaa !65
  %t62 = load i64, ptr %l2, !tbaa !65
  %t64 = insertvalue { i64, i64 } undef, i64 %t61, 0
  %t66 = insertvalue { i64, i64 } %t64, i64 %t62, 1
  store { i64, i64 } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex16(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l1, !tbaa !65
  %t2 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t3 = extractvalue { i32, i64 } %t2, 1
  %t4 = extractvalue { i32, i64 } %t2, 0
  store i32 %t4, ptr %l3
  %t5 = icmp ne i32 %t4, 0
  br i1 %t5, label %bb2, label %ok.6
ok.6:
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  %t7 = load i64, ptr %l1, !tbaa !65
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t7, i64 %t8)
  store { i64, ptr } %t9, ptr %l4
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9d78c5c339795d98_5bda6918f751e21c)
  unreachable
bb3:
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  %t18 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t16, i64 16, i8 48)
  store { i64, ptr } %t18, ptr %l6
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex2(ptr %v0, i8 %a0) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = zext i8 %a0 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a384a4bbbe0ebea1_23bacf7041e0bcc5)
  unreachable
bb3:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t18, i64 2, i8 48)
  store { i64, ptr } %t20, ptr %l7
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eprimBits_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [15 x i64] undef, i64 0, 0
  %t2 = insertvalue [15 x i64] %t1, i64 0, 1
  %t3 = insertvalue [15 x i64] %t2, i64 1, 2
  %t4 = insertvalue [15 x i64] %t3, i64 8, 3
  %t5 = insertvalue [15 x i64] %t4, i64 16, 4
  %t6 = insertvalue [15 x i64] %t5, i64 32, 5
  %t7 = insertvalue [15 x i64] %t6, i64 64, 6
  %t8 = insertvalue [15 x i64] %t7, i64 8, 7
  %t9 = insertvalue [15 x i64] %t8, i64 16, 8
  %t10 = insertvalue [15 x i64] %t9, i64 32, 9
  %t11 = insertvalue [15 x i64] %t10, i64 64, 10
  %t12 = insertvalue [15 x i64] %t11, i64 16, 11
  %t13 = insertvalue [15 x i64] %t12, i64 16, 12
  %t14 = insertvalue [15 x i64] %t13, i64 32, 13
  %t15 = insertvalue [15 x i64] %t14, i64 64, 14
  store [15 x i64] %t15, ptr @G_2ecompiler_2ftypes_2eprimBits
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eprimLlvm_2einit() #0 {
entry:
  %l0 = alloca [15 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr @.d69 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 4, ptr @.d70 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 2, ptr @.d71 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr @.d72 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr @.d73 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr @.d74 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr @.d75 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr @.d76 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr @.d77 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr @.d78 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr @.d79 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 4, ptr @.d80 }, ptr %t12, !tbaa !37
  %t13 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 6, ptr @.d81 }, ptr %t13, !tbaa !37
  %t14 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 5, ptr @.d82 }, ptr %t14, !tbaa !37
  %t15 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 6, ptr @.d83 }, ptr %t15, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ftypes_2eprimLlvm, ptr %l0, i64 240, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2eprimNames_2einit() #0 {
entry:
  %l0 = alloca [15 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr @.d84 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 0, ptr @.d85 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 4, ptr @.d86 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr @.d87 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr @.d88 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr @.d89 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr @.d90 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr @.d91 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr @.d92 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr @.d93 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr @.d94 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr @.d95 }, ptr %t12, !tbaa !37
  %t13 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr @.d96 }, ptr %t13, !tbaa !37
  %t14 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 3, ptr @.d97 }, ptr %t14, !tbaa !37
  %t15 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 3, ptr @.d98 }, ptr %t15, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ftypes_2eprimNames, ptr %l0, i64 240, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_3aTable_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca %"compiler/types:Table"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l34
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %t6)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l35
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l36
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l5
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e(ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l37
  br label %bb4
bb4:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l6
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeI_He375cb5a1de17a5d01c6b8903f9691e1(ptr %t15)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l38
  br label %bb5
bb5:
  %t17 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l7
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l39
  br label %bb6
bb6:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l8
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e(ptr %t21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l40
  br label %bb7
bb7:
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l9
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l41
  br label %bb8
bb8:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l10
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t27)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l42
  br label %bb9
bb9:
  %t29 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l11
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l43
  br label %bb10
bb10:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l12
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t33)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l44
  br label %bb11
bb11:
  %t35 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l13
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e(ptr %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l45
  br label %bb12
bb12:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l14
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l46
  br label %bb13
bb13:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l15
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He0d7a5bfd18ae956abf945564c24098c(ptr %t42)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l47
  br label %bb14
bb14:
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l16
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %t45)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l48
  br label %bb15
bb15:
  %t47 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l17
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20A_Hcfba385079b3349cc13047539d410cc3(ptr %t48)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l49
  br label %bb16
bb16:
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l18
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t51)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l50
  br label %bb17
bb17:
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l19
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l51
  br label %bb18
bb18:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l20
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t57)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l52
  br label %bb19
bb19:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l21
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t60)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l53
  br label %bb20
bb20:
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l22
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t63)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l54
  br label %bb21
bb21:
  %t65 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l23
  %t66 = load ptr, ptr @__olang_prog_scope
  %t67 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t66)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l55
  br label %bb22
bb22:
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l24
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t69)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l56
  br label %bb23
bb23:
  %t71 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l25
  %t72 = load ptr, ptr @__olang_prog_scope
  %t73 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t72)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l57
  br label %bb24
bb24:
  %t74 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l26
  %t75 = load ptr, ptr @__olang_prog_scope
  %t76 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t75)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l58
  br label %bb25
bb25:
  %t77 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l27
  %t78 = load ptr, ptr @__olang_prog_scope
  %t79 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %t78)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l59
  br label %bb26
bb26:
  %t80 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l28
  %t81 = load ptr, ptr @__olang_prog_scope
  %t82 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t81)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l60
  br label %bb27
bb27:
  %t83 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l29
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %t84)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l61
  br label %bb28
bb28:
  %t86 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l30
  %t87 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l62
  br label %bb29
bb29:
  %t88 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  %t89 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 0
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %t89, !tbaa !29
  %t91 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 1
  %t92 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %t91
  %t93 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 2
  %t94 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %t93
  %t95 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 3
  %t96 = load i1, ptr %l4, !tbaa !21
  store i1 %t96, ptr %t95, !tbaa !21
  %t97 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 4
  %t98 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %t97
  %t99 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 5
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t99
  %t101 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 6
  %t102 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %t101
  %t103 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 7
  %t104 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %t103
  %t105 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 8
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %t105
  %t107 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 9
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %t107
  %t109 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 10
  %t110 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t109
  %t111 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 11
  %t112 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %t111
  %t113 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 12
  %t114 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %t113
  %t115 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 13
  %t116 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t115
  %t117 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 14
  %t118 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %t117
  %t119 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 15
  %t120 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %t119
  %t121 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 16
  %t122 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %t121
  %t123 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 17
  %t124 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t123
  %t125 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 18
  %t126 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %t125
  %t127 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 19
  %t128 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %t127
  %t129 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 20
  %t130 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t130, ptr %t129
  %t131 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 21
  %t132 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %t131
  %t133 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 22
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %t133
  %t135 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 23
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %t135
  %t137 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 24
  %t138 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %t137
  %t139 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 25
  %t140 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %t139
  %t141 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 26
  %t142 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %t141
  %t143 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 27
  %t144 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t143
  %t145 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 28
  %t146 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %t145
  %t147 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 29
  %t148 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %t147
  %t149 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 30
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %t149
  %t151 = getelementptr %"compiler/types:Table", ptr %l63, i32 0, i32 31
  store i1 false, ptr %t151, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l63, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/types:body" @compiler_2ftypes_3abody_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/types:body"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/types:body" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/types:body" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/types:body" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/types:body" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/types:body" %t18, i1 %a4, 4
  store %"compiler/types:body" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:body", ptr %rv
  ret %"compiler/types:body" %rr
}

define dso_local %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5) #0 {
entry:
  %rv = alloca %"compiler/types:data"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/types:data" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/types:data" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/types:data" %t16, i64 %a2, 2
  %t20 = insertvalue %"compiler/types:data" %t18, i64 %a3, 3
  %t22 = insertvalue %"compiler/types:data" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/types:data" %t22, i64 %a5, 5
  store %"compiler/types:data" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:data", ptr %rv
  ret %"compiler/types:data" %rr
}

define dso_local %"compiler/types:decl" @compiler_2ftypes_3adecl_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/types:decl"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/types:decl" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/types:decl" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/types:decl" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/types:decl" %t14, i32 %a3, 3
  store %"compiler/types:decl" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/types:decl", ptr %rv
  ret %"compiler/types:decl" %rr
}

define dso_local void @olang_2einit_2ecompiler_2ftypes() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftypes_2eReadOnly_2einit()
  br label %bb1
bb1:
  call void @compiler_2ftypes_2eWritable_2einit()
  br label %bb2
bb2:
  call void @compiler_2ftypes_2eOwning_2einit()
  br label %bb3
bb3:
  call void @compiler_2ftypes_2eNullable_2einit()
  br label %bb4
bb4:
  call void @compiler_2ftypes_2eRoleFn_2einit()
  br label %bb5
bb5:
  call void @compiler_2ftypes_2eRoleCtor_2einit()
  br label %bb6
bb6:
  call void @compiler_2ftypes_2eRoleDtor_2einit()
  br label %bb7
bb7:
  call void @compiler_2ftypes_2eOwnScope_2einit()
  br label %bb8
bb8:
  call void @compiler_2ftypes_2eFromTypeVar_2einit()
  br label %bb9
bb9:
  call void @compiler_2ftypes_2eResultVar_2einit()
  br label %bb10
bb10:
  call void @compiler_2ftypes_2eClosingVar_2einit()
  br label %bb11
bb11:
  call void @compiler_2ftypes_2eNotLaidOut_2einit()
  br label %bb12
bb12:
  call void @compiler_2ftypes_2eLayingOut_2einit()
  br label %bb13
bb13:
  call void @compiler_2ftypes_2eLaidOut_2einit()
  br label %bb14
bb14:
  call void @compiler_2ftypes_2eNoLayout_2einit()
  br label %bb15
bb15:
  call void @compiler_2ftypes_2eUnknownT_2einit()
  br label %bb16
bb16:
  call void @compiler_2ftypes_2eVoidT_2einit()
  br label %bb17
bb17:
  call void @compiler_2ftypes_2eBoolT_2einit()
  br label %bb18
bb18:
  call void @compiler_2ftypes_2eNullT_2einit()
  br label %bb19
bb19:
  call void @compiler_2ftypes_2eDefaultErrT_2einit()
  br label %bb20
bb20:
  call void @compiler_2ftypes_2eNoreturnT_2einit()
  br label %bb21
bb21:
  call void @compiler_2ftypes_2eprimNames_2einit()
  br label %bb22
bb22:
  call void @compiler_2ftypes_2eprimLlvm_2einit()
  br label %bb23
bb23:
  call void @compiler_2ftypes_2eprimBits_2einit()
  br label %bb24
bb24:
  call void @compiler_2ftypes_2eBigAggregate_2einit()
  br label %bb25
bb25:
  call void @compiler_2ftypes_2eAnySlotBase_2einit()
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant [2 x i8] c"__"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant [2 x i8] c"_H"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant [1 x i8] c":"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d3 = private constant [1 x i8] c","
@.d4 = private constant [1 x i8] c":"
declare void @__olang_ert_req_clear()
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d5 = private constant [0 x i8] c""
@.d6 = private constant [3 x i8] c"i32"
@.d7 = private constant [4 x i8] c"void"
@.d8 = private constant [3 x i8] c"i32"
@.d9 = private constant [7 x i8] c"{ i32, "
@.d10 = private constant [2 x i8] c" }"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d11 = private constant [3 x i8] c"{ }"
@.d12 = private constant [2 x i8] c"{ "
@.d13 = private constant [2 x i8] c", "
@.d14 = private constant [2 x i8] c" }"
@.d15 = private constant [12 x i8] c"{ i64, ptr }"
@.d16 = private constant [1 x i8] c"["
@.d17 = private constant [3 x i8] c" x "
@.d18 = private constant [1 x i8] c"]"
@.d19 = private constant [1 x i8] c"?"
@.d20 = private constant [4 x i8] c"null"
@.d21 = private constant [7 x i8] c"default"
@.d22 = private constant [8 x i8] c"noreturn"
@.d23 = private constant [2 x i8] c".#"
declare i64 @__olang_fmt_u64(ptr, i64)
@.d24 = private constant [4 x i8] c"void"
@.d25 = private constant [2 x i8] c", "
@.d26 = private constant [6 x i8] c"Array<"
@.d27 = private constant [2 x i8] c", "
@.d28 = private constant [4 x i8] c"own "
@.d29 = private constant [4 x i8] c"mut "
@.d30 = private constant [2 x i8] c"?&"
@.d31 = private constant [1 x i8] c"&"
@.d32 = private constant [3 x i8] c"fn("
@.d33 = private constant [2 x i8] c" ("
@.d34 = private constant [1 x i8] c" "
@.d35 = private constant [2 x i8] c" ?"
@.d36 = private constant [3 x i8] c" + "
@.d37 = private constant [1 x i8] c" "
@.d38 = private constant [3 x i8] c" ~["
@.d39 = private constant [7 x i8] c"struct("
@.d40 = private constant [5 x i8] c"enum{"
@.d41 = private constant [1 x i8] c"<"
@.d42 = private constant [1 x i8] c"."
@.d43 = private constant [1 x i8] c">"
@.d44 = private constant [4 x i8] c"true"
@.d45 = private constant [5 x i8] c"false"
@.d46 = private constant [1 x i8] c"<"
@.d47 = private constant [1 x i8] c">"
@.d48 = private constant [4 x i8] c"any "
@.d49 = private constant [3 x i8] c"i32"
@.d50 = private constant [8 x i8] c"{ i64, ["
@.d51 = private constant [9 x i8] c" x i64] }"
@.d52 = private constant [0 x i8] c""
@.d53 = private constant [2 x i8] c", "
@.d54 = private constant [3 x i8] c"i32"
@.d55 = private constant [1 x i8] c"?"
@.d56 = private constant [3 x i8] c"i32"
@.d57 = private constant [4 x i8] c"void"
@.d58 = private constant [12 x i8] c"{ ptr, ptr }"
@.d59 = private constant [12 x i8] c"{ i64, ptr }"
@.d60 = private constant [12 x i8] c"{ ptr, ptr }"
@.d61 = private constant [3 x i8] c"ptr"
@.d62 = private constant [1 x i8] c"?"
@.d63 = private constant [2 x i8] c"%\22"
@.d64 = private constant [1 x i8] c"\22"
@.d65 = private constant [1 x i8] c"<"
@.d66 = private constant [2 x i8] c"%\22"
@.d67 = private constant [1 x i8] c"."
@.d68 = private constant [1 x i8] c"\22"
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [4 x i8] c"void"
@.d71 = private constant [2 x i8] c"i1"
@.d72 = private constant [2 x i8] c"i8"
@.d73 = private constant [3 x i8] c"i16"
@.d74 = private constant [3 x i8] c"i32"
@.d75 = private constant [3 x i8] c"i64"
@.d76 = private constant [2 x i8] c"i8"
@.d77 = private constant [3 x i8] c"i16"
@.d78 = private constant [3 x i8] c"i32"
@.d79 = private constant [3 x i8] c"i64"
@.d80 = private constant [4 x i8] c"half"
@.d81 = private constant [6 x i8] c"bfloat"
@.d82 = private constant [5 x i8] c"float"
@.d83 = private constant [6 x i8] c"double"
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [0 x i8] c""
@.d86 = private constant [4 x i8] c"Bool"
@.d87 = private constant [2 x i8] c"I8"
@.d88 = private constant [3 x i8] c"I16"
@.d89 = private constant [3 x i8] c"I32"
@.d90 = private constant [3 x i8] c"I64"
@.d91 = private constant [2 x i8] c"U8"
@.d92 = private constant [3 x i8] c"U16"
@.d93 = private constant [3 x i8] c"U32"
@.d94 = private constant [3 x i8] c"U64"
@.d95 = private constant [3 x i8] c"F16"
@.d96 = private constant [4 x i8] c"BF16"
@.d97 = private constant [3 x i8] c"F32"
@.d98 = private constant [3 x i8] c"F64"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeI_He375cb5a1de17a5d01c6b8903f9691e1(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_He0d7a5bfd18ae956abf945564c24098c(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20A_Hcfba385079b3349cc13047539d410cc3(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@olang_loc_350cf97603b2facf_69b011185289b33 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_Hfe37b7e06e962429d54fa57b80e63073(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_8b13046bbc59237a_a5831af19cea45fe = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4622f22b1b9e72f9_4c12a3b980ae2b3d = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_30e02956f84eec46_91b8152c5eb3aca = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eLen_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ePush_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, %"compiler/types:decl" %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H4604c93a4aa22278631629833c26f586(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_363cc534119e1b58_f5bd72046473679c = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H9437066785f0bdbcfc17884fffb14a92(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Ha96ac7e1b060f2f8a9c35aa4bd1fc8d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hcaffdb9d24c80e421d58a725793b74fc(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_c5f0a3e3912a4ce3_83ad4b8f75c0f327 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6b4c62a37e5c57cb2d11c50f44a997f9(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b3c0df13ff143a95_992c52f0f53f0c49 = external constant [0 x i8]
@olang_loc_3a86b0904acb017a_fb1793104580b26e = external constant [0 x i8]
@olang_loc_448c58e2e97e944f_f556e6dbd0c75243 = external constant [0 x i8]
@olang_loc_136e48f5d148640e_b95a40c005170ac2 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/types:decl" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2eAt_3ccompiler_2ftypes_3adecl_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H25f20ec7bc3952e7f71d4b5fc38b1e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_He07f56466a5a9f826ee9e17dcb7906ae(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H0a665c2b4d7e237317fbcb46f7b513e7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_aca21d9f8d110f21_d35bd7e73631d7ed = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3_H503e6d35c0db63145eb2ca8ce5f41f51(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_He4e7022cb78ea4ca3380b08f831d7938(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ecef2c1188620c25_f6c5d2506e285511 = external constant [0 x i8]
@olang_loc_6b6356ebbaa556b4_537d1793e4121070 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f884bd4f1b6015d_20014de591249a11 = external constant [0 x i8]
@olang_loc_f7b42ec29d1607_26e89eedc9b3128b = external constant [0 x i8]
@olang_loc_2df495a001b30f12_f15d21f3e8677f6 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_63e623ceae63df16_2a862fe3f0344bd2 = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H00ad3ea0211b1c1ed775c1e06d3ea587(ptr %v0, ptr %a0, i32 %a1, %"compiler/types:body" %a2)
@olang_loc_f7eaf3fe8a46d3da_9f187abb7d2da27e = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hd895f0b253f779909e5758cb24860698(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2eAt_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/types:data" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eAt_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/types:body" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hede57d818a9c1e0bef22465b1936f190(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bd4ce41e1f7e504b_596b58263987420f = external constant [0 x i8]
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_94d95030786c6de_dc670b9e390cf1a = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hde6d536d7268ca732b315d911361d6aa(ptr %v0, ptr %a0, %"compiler/types:data" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2eLen_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ePush_3ccompiler_2ftypes_3adata_3e(ptr %v0, ptr %a0, %"compiler/types:data" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler__Hffc99e12659a835aff737c3e51f11f7b(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_b0143a025c7cdb06_8f46c74feff323b2 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
@olang_loc_bbfcd5581dbe335b_bbf57adf6fe10b0f = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077 = external constant [0 x i8]
@olang_loc_ebf284414dbafd61_1a8e1f26a2703ea5 = external constant [0 x i8]
@olang_loc_9d78c5c339795d98_5bda6918f751e21c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_a384a4bbbe0ebea1_23bacf7041e0bcc5 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
