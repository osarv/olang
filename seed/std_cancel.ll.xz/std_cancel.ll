; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
@G_2estd_2fcancel_2eClockMonotonic = global i32 zeroinitializer
@G_2estd_2fcancel_2eClockRealtime = global i32 zeroinitializer
@G_2estd_2fcancel_2ePollNs = global i64 zeroinitializer
define dso_local void @olang_2einit_2estd_2fcancel() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fcancel_2eClockRealtime_2einit()
  br label %bb1
bb1:
  call void @std_2fcancel_2eClockMonotonic_2einit()
  br label %bb2
bb2:
  call void @std_2fcancel_2ePollNs_2einit()
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2eClockMonotonic_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 1, ptr @G_2estd_2fcancel_2eClockMonotonic
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2eClockRealtime_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr @G_2estd_2fcancel_2eClockRealtime
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2ePollNs_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 10000000, ptr @G_2estd_2fcancel_2ePollNs
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_scope_close(ptr)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
