; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/cancel:Token" = type { i32, i64 }
%"std/cancel:spinCount" = type { i64 }
%"std/cancel:stopCount" = type { i64, i32 }
@G_2estd_2fcancel_2eClockMonotonic = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2fcancel_2eClockRealtime = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2estd_2fcancel_2ePollNs = constant <{ [8 x i8] }> <{ [8 x i8] c"\80\96\98\00\00\00\00\00" }>, align 8
define dso_local void @olang_2einit_2estd_2fcancel() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2fcancel_2eClockRealtime_2einit()
  br label %bb1
bb1:
  call void @std_2fcancel_2eClockMonotonic_2einit()
  br label %bb2
bb2:
  call void @std_2fcancel_2ePollNs_2einit()
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local ptr @std_2fcancel_2eAfter(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l5 = alloca %"std/cancel:Token"
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2fcancel_2eNowNs()
  store i64 %t1, ptr %l1
  br label %bb1
bb1:
  %t4 = mul i64 %a0, 1000000
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = add i64 %t5, %t4
  %t9 = call %"std/cancel:Token" @std_2fcancel_3aToken_2ector(ptr %v0, i64 %t7)
  store %"std/cancel:Token" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/cancel:Token", ptr %l5
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"std/cancel:Token" %t10, ptr %t11
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @std_2fcancel_2eClockMonotonic_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2estd_2fcancel_2eClockMonotonic, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2eClockRealtime_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2estd_2fcancel_2eClockRealtime, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fcancel_2eNowNs() #0 {
entry:
  %l0 = alloca [2 x i64]
  %l5 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store [2 x i64] zeroinitializer, ptr %l0
  %t1 = load i32, ptr @G_2estd_2fcancel_2eClockMonotonic, !tbaa !23
  %t3 = insertvalue { i64, ptr } undef, i64 2, 0
  %t4 = insertvalue { i64, ptr } %t3, ptr %l0, 1
  %t8 = extractvalue { i64, ptr } %t4, 1
  %t9 = extractvalue { i64, ptr } %t4, 0
  %t10 = call i32 @clock_gettime(i32 %t1, ptr %t8)
  store i32 %t10, ptr %l5
  br label %bb1
bb1:
  %t11 = getelementptr [2 x i64], ptr %l0, i64 0, i64 0
  %t12 = load i64, ptr %t11, !tbaa !34
  %t14 = mul i64 %t12, 1000000000
  %t15 = getelementptr [2 x i64], ptr %l0, i64 0, i64 1
  %t16 = load i64, ptr %t15, !tbaa !34
  %t19 = add i64 %t14, %t16
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fcancel_2ePollNs_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 10000000, ptr @G_2estd_2fcancel_2ePollNs, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fcancel_2ecancelOnExit(ptr %v0, i1 %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %jh1 = alloca ptr
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @std_2fcancel_2eAfter(ptr %s0, i64 5000)
  store ptr %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l2, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  store ptr null, ptr %jh1
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call ptr @__olang_standin(ptr %s0)
  %t8 = call ptr @__olang_standin(ptr %v0)
  %t9 = getelementptr { ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t10 = ptrtoint ptr %t9 to i64
  %t11 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 %t10, i64 8)
  %t12 = getelementptr { ptr, ptr, ptr, ptr }, ptr %t11, i32 0, i32 0
  store ptr %t3, ptr %t12
  %t13 = getelementptr { ptr, ptr, ptr, ptr }, ptr %t11, i32 0, i32 1
  store ptr %a1, ptr %t13
  %t14 = getelementptr { ptr, ptr, ptr, ptr }, ptr %t11, i32 0, i32 2
  store ptr %t7, ptr %t14
  %t15 = getelementptr { ptr, ptr, ptr, ptr }, ptr %t11, i32 0, i32 3
  store ptr %t8, ptr %t15
  %t16 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  %t17 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr null, ptr %t17
  %t18 = getelementptr { ptr, ptr }, ptr %t17, i32 0, i32 1
  store ptr %t7, ptr %t18
  %t19 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t17, ptr %t19
  %t20 = getelementptr { ptr, ptr }, ptr %t19, i32 0, i32 1
  store ptr %t8, ptr %t20
  %t21 = getelementptr { ptr, i64, ptr, i64 }, ptr %t16, i32 0, i32 2
  store ptr %t19, ptr %t21
  %t22 = getelementptr { ptr, i64, ptr, i64 }, ptr %t16, i32 0, i32 1
  store i64 0, ptr %t22
  %t23 = getelementptr { ptr, i64, ptr, i64 }, ptr %t16, i32 0, i32 3
  store i64 0, ptr %t23
  %t24 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t24, ptr @olang_task0, ptr %t11, ptr %t16)
  %t25 = load ptr, ptr %jh1
  store ptr %t25, ptr %t16
  store ptr %t16, ptr %jh1
  br i1 %a0, label %bb2, label %bb3
bb2:
  store i32 65536, ptr %l7, !tbaa !23
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fcancel_2estd_2fcancel_3aToken_2eCancel(ptr %s0, ptr %t28)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t30 = call i64 @__olang_join_tasks(ptr %jh1)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i32, ptr %l7, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
bb6:
  %t32 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fcancel_2estd_2fcancel_3aToken_2eCancel(ptr %s0, ptr %t32)
  br label %bb7
bb7:
  %t34 = call i64 @__olang_join_tasks(ptr %jh1)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fcancel_2espin(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l3 = alloca i1
  %l8 = alloca i64
  %s1 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l3
  br label %bb2
bb2:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb4:
  br label %bb5
bb5:
  %t11 = getelementptr %"std/cancel:spinCount", ptr %a1, i32 0, i32 0
  %t13 = atomicrmw add ptr %t11, i64 1 seq_cst
  store i64 %t13, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2espinRecord(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca i32
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l3
  br label %bb2
bb2:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb4:
  br label %bb5
bb5:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"std/cancel:stopCount", ptr %t10, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = add i64 %t12, 1
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t17 = getelementptr %"std/cancel:stopCount", ptr %t16, i32 0, i32 0
  store i64 %t14, ptr %t17, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  br label %bb1
bb7:
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l9, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %t19)
  store i32 %t21, ptr %l11
  br label %bb8
bb8:
  %t22 = load i32, ptr %l11, !tbaa !23
  %t23 = load ptr, ptr %l9, !tbaa !29
  %t24 = getelementptr %"std/cancel:stopCount", ptr %t23, i32 0, i32 1
  store i32 %t22, ptr %t24, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2estd_2fcancel_3aToken_2eCancel(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/cancel:Token", ptr %a0, i32 0, i32 0
  store atomic i32 1, ptr %t3 seq_cst, align 4
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp ne i32 %t4, 0
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t4, 1
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i32 65536, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i32 65537, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fcancel_2estd_2fcancel_3aToken_2eWakeAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l19 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr @G_2estd_2fcancel_2ePollNs, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/cancel:Token", ptr %t3, i32 0, i32 1
  %t6 = load i64, ptr %t5, !tbaa !24
  %t8 = icmp ne i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/cancel:Token", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = call i64 @std_2fcancel_2eNowNs()
  store i64 %t14, ptr %l11
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = load i64, ptr %l11, !tbaa !24
  %t17 = sub i64 %t15, %t16
  store i64 %t17, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load i64, ptr %l3, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb7:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t31 = call i64 @std_2fcancel_2ewallNs()
  store i64 %t31, ptr %l19
  br label %bb11
bb11:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l19, !tbaa !24
  %t35 = add i64 %t33, %t32
  store i64 %t35, ptr %l4, !tbaa !24
  %t37 = load ptr, ptr %l1
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = sdiv i64 %t38, 1000000000
  %t43 = getelementptr [2 x i64], ptr %t37, i64 0, i64 0
  store i64 %t40, ptr %t43, !tbaa !34
  %t44 = load ptr, ptr %l1
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = srem i64 %t45, 1000000000
  %t50 = getelementptr [2 x i64], ptr %t44, i64 0, i64 1
  store i64 %t47, ptr %t50, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/cancel:Token", ptr %t1, i32 0, i32 0
  %t5 = load atomic i32, ptr %t3 seq_cst, align 4
  %t7 = icmp ne i32 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i32 1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/cancel:Token", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp ne i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = call i64 @std_2fcancel_2eNowNs()
  store i64 %t17, ptr %l10
  br label %bb6
bb5:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/cancel:Token", ptr %t18, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t24 = icmp sge i64 %t22, %t21
  store i1 %t24, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l9, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i32 2, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fcancel_2ewallNs() #0 {
entry:
  %l0 = alloca [2 x i64]
  %l5 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store [2 x i64] zeroinitializer, ptr %l0
  %t1 = load i32, ptr @G_2estd_2fcancel_2eClockRealtime, !tbaa !23
  %t3 = insertvalue { i64, ptr } undef, i64 2, 0
  %t4 = insertvalue { i64, ptr } %t3, ptr %l0, 1
  %t8 = extractvalue { i64, ptr } %t4, 1
  %t9 = extractvalue { i64, ptr } %t4, 0
  %t10 = call i32 @clock_gettime(i32 %t1, ptr %t8)
  store i32 %t10, ptr %l5
  br label %bb1
bb1:
  %t11 = getelementptr [2 x i64], ptr %l0, i64 0, i64 0
  %t12 = load i64, ptr %t11, !tbaa !34
  %t14 = mul i64 %t12, 1000000000
  %t15 = getelementptr [2 x i64], ptr %l0, i64 0, i64 1
  %t16 = load i64, ptr %t15, !tbaa !34
  %t19 = add i64 %t14, %t16
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/cancel:Token" @std_2fcancel_3aToken_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/cancel:Token"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"std/cancel:Token" undef, i32 0, 0
  %t6 = insertvalue %"std/cancel:Token" %t4, i64 %a0, 1
  store %"std/cancel:Token" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"std/cancel:Token", ptr %rv
  ret %"std/cancel:Token" %rr
}

define dso_local %"std/cancel:spinCount" @std_2fcancel_3aspinCount_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"std/cancel:spinCount"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"std/cancel:spinCount" undef, i64 0, 0
  store %"std/cancel:spinCount" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/cancel:spinCount", ptr %rv
  ret %"std/cancel:spinCount" %rr
}

define dso_local %"std/cancel:stopCount" @std_2fcancel_3astopCount_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"std/cancel:stopCount"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"std/cancel:stopCount" undef, i64 0, 0
  %t4 = insertvalue %"std/cancel:stopCount" %t2, i32 0, 1
  store %"std/cancel:stopCount" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/cancel:stopCount", ptr %rv
  ret %"std/cancel:stopCount" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare i32 @clock_gettime(i32, ptr)
declare ptr @__olang_standin(ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task0(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %sc0 = load ptr, ptr %f2
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f3
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %a0 = load ptr, ptr %f0
  %a1 = load ptr, ptr %f1
  call void @std_2fcancel_2espinRecord(ptr %ss0, ptr %ss1, ptr %a0, ptr %a1)
  ret ptr null
}

declare i64 @__olang_join_tasks(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
