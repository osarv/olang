; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/cancel:waiter" = type { %"<pthread.h>:pthread_mutex_t", %"<pthread.h>:pthread_cond_t", i32, i1, i32 }
%"<pthread.h>:pthread_mutex_t" = type { [5 x i64] }
%"<pthread.h>:pthread_cond_t" = type { [6 x i64] }
%"std/cancel:Token" = type { i32, i64 }
%"std/cancel:spinCount" = type { i64 }
%"std/cancel:stopCount" = type { i64, i32 }
%"<fcntl.h>:timespec" = type { i64, i64 }
@G_2estd_2fcancel_2eClockMonotonic = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2fcancel_2eClockRealtime = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2estd_2fcancel_2etable = global <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2estd_2fcancel_2etableLock = global <{ [40 x i8] }> <{ [40 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
define dso_local void @std_2fcancel_2eDone(i64 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call i32 @pthread_mutex_lock(ptr @G_2estd_2fcancel_2etableLock)
  store i32 %t2, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = load ptr, ptr @__olang_prog_scope
  %t8 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eAt_He103f6cfcc0ae31001d1a5cf3ae5a6b0(ptr %t4, ptr %t5, ptr @G_2estd_2fcancel_2etable, i64 %a0)
  store ptr %t8, ptr %l6
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l6, !tbaa !29
  store ptr %t9, ptr %l1, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"std/cancel:waiter", ptr %t10, i32 0, i32 0
  %t14 = call i32 @pthread_mutex_lock(ptr %t12)
  store i32 %t14, ptr %l9
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"std/cancel:waiter", ptr %t15, i32 0, i32 4
  store i32 -1, ptr %t17, !tbaa !23
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"std/cancel:waiter", ptr %t18, i32 0, i32 0
  %t22 = call i32 @pthread_mutex_unlock(ptr %t20)
  store i32 %t22, ptr %l13
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"std/cancel:waiter", ptr %t23, i32 0, i32 3
  store i1 false, ptr %t25, !tbaa !21
  %t27 = call i32 @pthread_mutex_unlock(ptr @G_2estd_2fcancel_2etableLock)
  store i32 %t27, ptr %l16
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fcancel_2eNowNs() #0 {
entry:
  %l0 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i64, ptr %l0, !tbaa !24
  store i64 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fcancel_2ePark(i32 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l10 = alloca i32
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l39 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i64
  %l52 = alloca %"std/cancel:waiter"
  %l55 = alloca i64
  %l59 = alloca ptr
  %l63 = alloca i32
  %l69 = alloca i32
  %l71 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call i32 @pthread_mutex_lock(ptr @G_2estd_2fcancel_2etableLock)
  store i32 %t2, ptr %l10
  br label %bb1
bb1:
  store i64 -1, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr @__olang_prog_scope
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eLe_H1eb7a8791568179c0613fadbc6e23399(ptr %t3, ptr @G_2estd_2fcancel_2etable)
  store i64 %t5, ptr %l12
  br label %bb2
bb2:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb8
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eAt_He103f6cfcc0ae31001d1a5cf3ae5a6b0(ptr %t54, ptr %s2, ptr @G_2estd_2fcancel_2etable, i64 %t53)
  store ptr %t57, ptr %l39
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l39, !tbaa !29
  %t60 = getelementptr %"std/cancel:waiter", ptr %t58, i32 0, i32 3
  %t61 = load i1, ptr %t60, !tbaa !21
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = load i64, ptr %l7, !tbaa !24
  store i64 %t65, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t74 = icmp slt i64 %t72, 0
  br i1 %t74, label %bb19, label %bb20
bb19:
  store ptr @G_2estd_2fcancel_2etable, ptr %l49, !tbaa !29
  %t76 = load ptr, ptr @__olang_prog_scope
  %t77 = call ptr @__olang_scope_hold(ptr %t76)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l50, !tbaa !24
  %t79 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fcancel_3awaiter_26_3e_2e_2d1
  br i1 %t79, label %bb21, label %bb22
bb20:
  br label %bb26
bb21:
  %t81 = load ptr, ptr @__olang_prog_scope
  %t82 = call ptr @__olang_region_make(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l50, !tbaa !24
  br label %bb22
bb22:
  %t84 = load i64, ptr %l50
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call %"std/cancel:waiter" @std_2fcancel_3awaiter_2ector(ptr %t85)
  store %"std/cancel:waiter" %t86, ptr %l52
  br label %bb23
bb23:
  %t87 = load %"std/cancel:waiter", ptr %l52
  %t88 = load i64, ptr %l50
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = call ptr @__olang_scope_alloc_a(ptr %t89, i64 104, i64 8)
  store %"std/cancel:waiter" %t87, ptr %t90
  %t91 = load ptr, ptr @__olang_prog_scope
  %t92 = load ptr, ptr @__olang_prog_scope
  %t93 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2ePu_H1584e9b47b9d124582a35df88dc27260(ptr %t91, ptr %t92, ptr %t93, ptr %t90)
  br label %bb24
bb24:
  %t95 = load ptr, ptr @__olang_prog_scope
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eLe_H1eb7a8791568179c0613fadbc6e23399(ptr %t95, ptr @G_2estd_2fcancel_2etable)
  store i64 %t97, ptr %l55
  br label %bb25
bb25:
  %t98 = load i64, ptr %l55, !tbaa !24
  %t99 = sub i64 %t98, 1
  store i64 %t99, ptr %l1, !tbaa !24
  br label %bb26
bb26:
  %t101 = load i64, ptr %l1, !tbaa !24
  %t102 = load ptr, ptr @__olang_prog_scope
  %t103 = load ptr, ptr @__olang_prog_scope
  %t106 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eAt_He103f6cfcc0ae31001d1a5cf3ae5a6b0(ptr %t102, ptr %t103, ptr @G_2estd_2fcancel_2etable, i64 %t101)
  store ptr %t106, ptr %l59
  br label %bb27
bb27:
  %t107 = load ptr, ptr %l59, !tbaa !29
  store ptr %t107, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l8, !tbaa !29
  %t110 = getelementptr %"std/cancel:waiter", ptr %t108, i32 0, i32 3
  store i1 true, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l8, !tbaa !29
  %t113 = getelementptr %"std/cancel:waiter", ptr %t111, i32 0, i32 0
  %t115 = call i32 @pthread_mutex_lock(ptr %t113)
  store i32 %t115, ptr %l63
  br label %bb28
bb28:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr %"std/cancel:waiter", ptr %t116, i32 0, i32 2
  store i32 0, ptr %t118, !tbaa !23
  %t119 = load ptr, ptr %l8, !tbaa !29
  %t123 = getelementptr %"std/cancel:waiter", ptr %t119, i32 0, i32 4
  store i32 %a0, ptr %t123, !tbaa !23
  %t124 = load ptr, ptr %l8, !tbaa !29
  %t126 = getelementptr %"std/cancel:waiter", ptr %t124, i32 0, i32 0
  %t128 = call i32 @pthread_mutex_unlock(ptr %t126)
  store i32 %t128, ptr %l69
  br label %bb29
bb29:
  %t130 = call i32 @pthread_mutex_unlock(ptr @G_2estd_2fcancel_2etableLock)
  store i32 %t130, ptr %l71
  br label %bb30
bb30:
  %t131 = load i64, ptr %l1, !tbaa !24
  store i64 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fcancel_2eRearm(i64 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i32
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @std_2fcancel_2ewaiter_2eat(ptr %s0, i64 %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"std/cancel:waiter", ptr %t5, i32 0, i32 0
  %t9 = call i32 @pthread_mutex_lock(ptr %t7)
  store i32 %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"std/cancel:waiter", ptr %t10, i32 0, i32 2
  store i32 0, ptr %t12, !tbaa !23
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"std/cancel:waiter", ptr %t13, i32 0, i32 0
  %t17 = call i32 @pthread_mutex_unlock(ptr %t15)
  store i32 %t17, ptr %l10
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @std_2fcancel_2eToken_2eAfter(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l5 = alloca %"std/cancel:Token"
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2fcancel_2eNowNs()
  store i64 %t1, ptr %l1
  br label %bb1
bb1:
  %t4 = mul i64 %a0, 1000000
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = add i64 %t5, %t4
  %t9 = call %"std/cancel:Token" @std_2fcancel_3aToken_2ector(ptr %v0, i64 %t7)
  store %"std/cancel:Token" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/cancel:Token", ptr %l5
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"std/cancel:Token" %t10, ptr %t11
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @std_2fcancel_2eWake(i64 %a0) #0 {
entry:
  %l2 = alloca ptr
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @std_2fcancel_2ewaiter_2eat(ptr %s0, i64 %a0)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fcancel_2ewake(ptr %s0, ptr %t4)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fcancel_2ecancelOnExit(ptr %v0, i1 %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %jh1 = alloca ptr
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @std_2fcancel_2eToken_2eAfter(ptr %s0, i64 5000)
  store ptr %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l2, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  store ptr null, ptr %jh1
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr { ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t8 = ptrtoint ptr %t7 to i64
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 %t8, i64 8)
  %t10 = getelementptr { ptr, ptr, ptr, ptr }, ptr %t9, i32 0, i32 0
  store ptr %t3, ptr %t10
  %t11 = getelementptr { ptr, ptr, ptr, ptr }, ptr %t9, i32 0, i32 1
  store ptr %a1, ptr %t11
  %t12 = getelementptr { ptr, ptr, ptr, ptr }, ptr %t9, i32 0, i32 2
  store ptr null, ptr %t12
  %t13 = getelementptr { ptr, ptr, ptr, ptr }, ptr %t9, i32 0, i32 3
  store ptr null, ptr %t13
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 40, i64 8)
  %t15 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t14, i32 0, i32 2
  store ptr null, ptr %t15
  %t16 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t14, i32 0, i32 1
  store i64 0, ptr %t16
  %t17 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t14, i32 0, i32 3
  store i64 0, ptr %t17
  %t18 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t14, i32 0, i32 4
  store ptr null, ptr %t18
  %t19 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t19, ptr @olang_task0, ptr %t9, ptr %t14)
  %t20 = load ptr, ptr %jh1
  store ptr %t20, ptr %t14
  store ptr %t14, ptr %jh1
  br i1 %a0, label %bb2, label %bb3
bb2:
  store i32 65536, ptr %l7, !tbaa !23
  %t23 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fcancel_2estd_2fcancel_3aToken_2eCancel(ptr %s0, ptr %t23)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t25 = call i64 @__olang_join_tasks_keep(ptr %jh1, i1 false)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l7, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fcancel_2estd_2fcancel_3aToken_2eCancel(ptr %s0, ptr %t27)
  br label %bb7
bb7:
  %t29 = call i64 @__olang_join_tasks_keep(ptr %jh1, i1 false)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fcancel_2espin(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l3 = alloca i1
  %l8 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t3 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l3
  br label %bb2
bb2:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb5
bb5:
  %t11 = getelementptr %"std/cancel:spinCount", ptr %a1, i32 0, i32 0
  %t13 = atomicrmw add ptr %t11, i64 1 seq_cst
  store i64 %t13, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2espinRecord(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l3
  br label %bb2
bb2:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb5
bb5:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"std/cancel:stopCount", ptr %t10, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = add i64 %t12, 1
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = getelementptr %"std/cancel:stopCount", ptr %t17, i32 0, i32 0
  store i64 %t15, ptr %t18, !tbaa !24
  br label %bb6
bb6:
  br label %bb1
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l12
  br label %bb8
bb8:
  %t23 = load i32, ptr %l12, !tbaa !23
  %t24 = load ptr, ptr %l10, !tbaa !29
  %t25 = getelementptr %"std/cancel:stopCount", ptr %t24, i32 0, i32 1
  store i32 %t23, ptr %t25, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2estd_2fcancel_3aToken_2eCancel(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/cancel:Token", ptr %a0, i32 0, i32 0
  store atomic i32 1, ptr %t3 seq_cst, align 4
  call void @std_2fcancel_2ewakeAll()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp ne i32 %t4, 0
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2fcancel_2estd_2fcancel_3aToken_2eLeftNs(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/cancel:Token", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp ne i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call i1 @std_2ftime_2eIsVirtual()
  store i1 %t8, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb4
bb3:
  %t9 = load i1, ptr %l6, !tbaa !21
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/cancel:Token", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  call void @std_2ftime_2eReach(i64 %t14)
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 1000000, ptr %rv
  br label %ret
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/cancel:Token", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/cancel:Token", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l15, !tbaa !24
  %t29 = call i64 @std_2fcancel_2eNowNs()
  store i64 %t29, ptr %l16
  br label %bb12
bb12:
  %t30 = load i64, ptr %l15, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = sub i64 %t30, %t31
  store i64 %t32, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l20, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb15
bb15:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t4, 1
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i32 65536, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i32 65537, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fcancel_2estd_2fcancel_3aToken_2eSleep(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca [2 x i64]
  %l5 = alloca ptr
  %l9 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i64
  %l30 = alloca i32
  %l34 = alloca i32
  %l38 = alloca i1
  %l40 = alloca i32
  %l50 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l64 = alloca i32
  %l67 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @std_2fcancel_2ewaiter_2eat(ptr %s0, i64 %a1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = insertvalue [2 x i64] undef, i64 0, 0
  %t6 = insertvalue [2 x i64] %t5, i64 0, 1
  store [2 x i64] %t6, ptr %l3
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"std/cancel:waiter", ptr %t8, i32 0, i32 0
  %t12 = call i32 @pthread_mutex_lock(ptr %t10)
  store i32 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/cancel:Token", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp ne i64 %t16, 0
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = call i1 @std_2ftime_2eIsVirtual()
  store i1 %t20, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t21 = load i1, ptr %l14, !tbaa !21
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"std/cancel:Token", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  call void @std_2ftime_2eReach(i64 %t26)
  br label %bb9
bb8:
  br label %bb23
bb9:
  %t28 = call i64 @std_2fcancel_2ewallNs()
  store i64 %t28, ptr %l17
  br label %bb10
bb10:
  %t29 = load i64, ptr %l17, !tbaa !24
  %t30 = add i64 %t29, 1000000
  %t32 = insertvalue { i64, ptr } undef, i64 2, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %l3, 1
  call void @std_2fcancel_2ewallAt(ptr %s0, i64 %t30, { i64, ptr } %t33)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"std/cancel:waiter", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t41 = icmp eq i32 %t39, 0
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"std/cancel:waiter", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"std/cancel:waiter", ptr %t48, i32 0, i32 0
  %t54 = call i32 @pthread_cond_timedwait(ptr %t47, ptr %t50, ptr %l3)
  store i32 %t54, ptr %l30
  br label %bb16
bb16:
  %t55 = load i32, ptr %l30, !tbaa !23
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb12
bb21:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"std/cancel:waiter", ptr %t58, i32 0, i32 0
  %t62 = call i32 @pthread_mutex_unlock(ptr %t60)
  store i32 %t62, ptr %l34
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"std/cancel:waiter", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = icmp eq i32 %t66, 0
  br i1 %t68, label %bb25, label %bb26
bb25:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %t70)
  store i32 %t72, ptr %l40
  br label %bb27
bb26:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb28
bb27:
  %t73 = load i32, ptr %l40, !tbaa !23
  %t74 = icmp eq i32 %t73, 0
  store i1 %t74, ptr %l38, !tbaa !21
  br label %bb28
bb28:
  %t76 = load i1, ptr %l38, !tbaa !21
  %t77 = xor i1 %t76, true
  br i1 %t77, label %bb29, label %bb30
bb29:
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/cancel:Token", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = icmp eq i64 %t82, 0
  br i1 %t84, label %bb32, label %bb33
bb32:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"std/cancel:waiter", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = getelementptr %"std/cancel:waiter", ptr %t89, i32 0, i32 0
  %t94 = call i32 @pthread_cond_wait(ptr %t88, ptr %t91)
  store i32 %t94, ptr %l50
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb40
bb35:
  %t95 = call i64 @std_2fcancel_2ewallNs()
  store i64 %t95, ptr %l51
  br label %bb36
bb36:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/cancel:Token", ptr %t96, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = load i64, ptr %l51, !tbaa !24
  %t102 = add i64 %t100, %t99
  store i64 %t102, ptr %l54, !tbaa !24
  %t103 = call i64 @std_2fcancel_2eNowNs()
  store i64 %t103, ptr %l55
  br label %bb37
bb37:
  %t104 = load i64, ptr %l54, !tbaa !24
  %t105 = load i64, ptr %l55, !tbaa !24
  %t106 = sub i64 %t104, %t105
  %t108 = insertvalue { i64, ptr } undef, i64 2, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %l3, 1
  call void @std_2fcancel_2ewallAt(ptr %s0, i64 %t106, { i64, ptr } %t109)
  br label %bb38
bb38:
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t114 = getelementptr %"std/cancel:waiter", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = getelementptr %"std/cancel:waiter", ptr %t115, i32 0, i32 0
  %t121 = call i32 @pthread_cond_timedwait(ptr %t114, ptr %t117, ptr %l3)
  store i32 %t121, ptr %l64
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb24
bb41:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t124 = getelementptr %"std/cancel:waiter", ptr %t122, i32 0, i32 0
  %t126 = call i32 @pthread_mutex_unlock(ptr %t124)
  store i32 %t126, ptr %l67
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fcancel_2estd_2fcancel_3aToken_2eWhy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/cancel:Token", ptr %t1, i32 0, i32 0
  %t5 = load atomic i32, ptr %t3 seq_cst, align 4
  %t7 = icmp ne i32 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i32 1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/cancel:Token", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp ne i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = call i64 @std_2fcancel_2eNowNs()
  store i64 %t17, ptr %l10
  br label %bb6
bb5:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/cancel:Token", ptr %t18, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t24 = icmp sge i64 %t22, %t21
  store i1 %t24, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l9, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i32 2, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @std_2fcancel_2ewaiter_2eat(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l8 = alloca i32
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call i32 @pthread_mutex_lock(ptr @G_2estd_2fcancel_2etableLock)
  store i32 %t2, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr @__olang_prog_scope
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eAt_He103f6cfcc0ae31001d1a5cf3ae5a6b0(ptr %t4, ptr %v0, ptr @G_2estd_2fcancel_2etable, i64 %a0)
  store ptr %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l1, !tbaa !29
  %t10 = call i32 @pthread_mutex_unlock(ptr @G_2estd_2fcancel_2etableLock)
  store i32 %t10, ptr %l8
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @std_2fcancel_2ewake(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [1 x i64]
  %l4 = alloca i32
  %l8 = alloca i32
  %l16 = alloca i64
  %l19 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/cancel:waiter", ptr %t1, i32 0, i32 0
  %t5 = call i32 @pthread_mutex_lock(ptr %t3)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/cancel:waiter", ptr %t6, i32 0, i32 2
  store i32 1, ptr %t8, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/cancel:waiter", ptr %t9, i32 0, i32 1
  %t13 = call i32 @pthread_cond_signal(ptr %t11)
  store i32 %t13, ptr %l8
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"std/cancel:waiter", ptr %t14, i32 0, i32 4
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp sge i32 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = insertvalue [1 x i64] undef, i64 1, 0
  store [1 x i64] %t21, ptr %l1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"std/cancel:waiter", ptr %t23, i32 0, i32 4
  %t26 = load i32, ptr %t25, !tbaa !23
  %t29 = call i64 @write(i32 %t26, ptr %l1, i64 8)
  store i64 %t29, ptr %l16
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"std/cancel:waiter", ptr %t30, i32 0, i32 0
  %t34 = call i32 @pthread_mutex_unlock(ptr %t32)
  store i32 %t34, ptr %l19
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2ewakeAll() #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l24 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call i32 @pthread_mutex_lock(ptr @G_2estd_2fcancel_2etableLock)
  store i32 %t2, ptr %l4
  br label %bb1
bb1:
  store ptr @G_2estd_2fcancel_2etable, ptr %l0, !tbaa !29
  store i64 0, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr @__olang_prog_scope
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eLe_H1eb7a8791568179c0613fadbc6e23399(ptr %t6, ptr %t5)
  store i64 %t8, ptr %l8
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb15
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = load ptr, ptr @__olang_prog_scope
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eAt_He103f6cfcc0ae31001d1a5cf3ae5a6b0(ptr %t17, ptr %t18, ptr %t15, i64 %t16)
  store ptr %t21, ptr %l13
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l13, !tbaa !29
  store ptr %t22, ptr %l2, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"std/cancel:waiter", ptr %t23, i32 0, i32 3
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call ptr @__olang_scope_hold(ptr %t29)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l17, !tbaa !24
  %t32 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fcancel_3awaiter_26_3e_2e_2d1
  br i1 %t32, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = load ptr, ptr @__olang_prog_scope
  %t36 = call ptr @__olang_region_or(ptr %t34, ptr %t35)
  %t37 = call ptr @__olang_scope_hold(ptr %t36)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l17, !tbaa !24
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i64, ptr %l17
  %t41 = inttoptr i64 %t40 to ptr
  call void @std_2fcancel_2ewake(ptr %t41, ptr %t39)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = add i64 %t43, 1
  store i64 %t46, ptr %l1, !tbaa !24
  br label %bb2
bb15:
  %t49 = call i32 @pthread_mutex_unlock(ptr @G_2estd_2fcancel_2etableLock)
  store i32 %t49, ptr %l24
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fcancel_2ewallAt(ptr %v0, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load i64, ptr %l0, !tbaa !24
  %t4 = sdiv i64 %t2, 1000000000
  %t6 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr i64, ptr %t7, i64 0
  store i64 %t4, ptr %t8, !tbaa !34
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l5, !tbaa !27
  %t10 = load i64, ptr %l0, !tbaa !24
  %t12 = srem i64 %t10, 1000000000
  %t14 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i64, ptr %t15, i64 1
  store i64 %t12, ptr %t16, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fcancel_2ewallNs() #0 {
entry:
  %l0 = alloca %"<fcntl.h>:timespec"
  %l1 = alloca %"<fcntl.h>:timespec"
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %s0)
  store %"<fcntl.h>:timespec" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"<fcntl.h>:timespec", ptr %l1
  store %"<fcntl.h>:timespec" %t2, ptr %l0
  %t3 = load i32, ptr @G_2estd_2fcancel_2eClockRealtime, !tbaa !23
  %t6 = call i32 @clock_gettime(i32 %t3, ptr %l0)
  store i32 %t6, ptr %l4
  br label %bb2
bb2:
  %t7 = getelementptr %"<fcntl.h>:timespec", ptr %l0, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = mul i64 %t8, 1000000000
  %t11 = getelementptr %"<fcntl.h>:timespec", ptr %l0, i32 0, i32 1
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = add i64 %t10, %t12
  call void @__olang_scope_close(ptr %s0)
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/cancel:Token" @std_2fcancel_3aToken_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/cancel:Token"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"std/cancel:Token" undef, i32 0, 0
  %t6 = insertvalue %"std/cancel:Token" %t4, i64 %a0, 1
  store %"std/cancel:Token" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"std/cancel:Token", ptr %rv
  ret %"std/cancel:Token" %rr
}

define dso_local %"std/cancel:spinCount" @std_2fcancel_3aspinCount_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"std/cancel:spinCount"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"std/cancel:spinCount" undef, i64 0, 0
  store %"std/cancel:spinCount" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/cancel:spinCount", ptr %rv
  ret %"std/cancel:spinCount" %rr
}

define dso_local %"std/cancel:stopCount" @std_2fcancel_3astopCount_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"std/cancel:stopCount"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"std/cancel:stopCount" undef, i64 0, 0
  %t4 = insertvalue %"std/cancel:stopCount" %t2, i32 0, 1
  store %"std/cancel:stopCount" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/cancel:stopCount", ptr %rv
  ret %"std/cancel:stopCount" %rr
}

define dso_local %"std/cancel:waiter" @std_2fcancel_3awaiter_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"<pthread.h>:pthread_mutex_t"
  %l5 = alloca %"<pthread.h>:pthread_mutex_t"
  %l6 = alloca %"<pthread.h>:pthread_cond_t"
  %rv = alloca %"std/cancel:waiter"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"<pthread.h>:pthread_mutex_t" @olang_2emir_2eHelperKind_2eZero_2e_3cpthread_2eh_3e_3apthread__mutex__t()
  store %"<pthread.h>:pthread_mutex_t" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"<pthread.h>:pthread_mutex_t", ptr %l5
  store %"<pthread.h>:pthread_mutex_t" %t2, ptr %l0
  %t3 = call %"<pthread.h>:pthread_cond_t" @olang_2emir_2eHelperKind_2eZero_2e_3cpthread_2eh_3e_3apthread__cond__t()
  store %"<pthread.h>:pthread_cond_t" %t3, ptr %l6
  br label %bb2
bb2:
  %t4 = load %"<pthread.h>:pthread_cond_t", ptr %l6
  %t5 = load %"<pthread.h>:pthread_mutex_t", ptr %l0
  %t6 = insertvalue %"std/cancel:waiter" undef, %"<pthread.h>:pthread_mutex_t" %t5, 0
  %t8 = insertvalue %"std/cancel:waiter" %t6, %"<pthread.h>:pthread_cond_t" %t4, 1
  %t10 = insertvalue %"std/cancel:waiter" %t8, i32 0, 2
  %t12 = insertvalue %"std/cancel:waiter" %t10, i1 false, 3
  %t14 = insertvalue %"std/cancel:waiter" %t12, i32 -1, 4
  store %"std/cancel:waiter" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"std/cancel:waiter", ptr %rv
  ret %"std/cancel:waiter" %rr
}

declare i32 @pthread_mutex_lock(ptr)
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare i32 @pthread_mutex_unlock(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cmut_20std_2fcancel_3awaiter_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task0(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %sc0 = load ptr, ptr %f2
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f3
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %a0 = load ptr, ptr %f0
  %a1 = load ptr, ptr %f1
  call void @std_2fcancel_2espinRecord(ptr %ss0, ptr %ss1, ptr %a0, ptr %a1)
  ret ptr null
}

declare i64 @__olang_join_tasks_keep(ptr, i1)
declare i32 @pthread_cond_timedwait(ptr, ptr, ptr)
declare i32 @pthread_cond_wait(ptr, ptr)
declare i32 @pthread_cond_signal(ptr)
declare i64 @write(i32, ptr, i64)
declare ptr @__olang_region_or(ptr, ptr)
declare i32 @clock_gettime(i32, ptr)
define linkonce_odr %"<pthread.h>:pthread_mutex_t" @olang_2emir_2eHelperKind_2eZero_2e_3cpthread_2eh_3e_3apthread__mutex__t() #0 {
entry:
  %l0 = alloca %"<pthread.h>:pthread_mutex_t"
  %rv = alloca %"<pthread.h>:pthread_mutex_t"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<pthread.h>:pthread_mutex_t" @_3cpthread_2eh_3e_3apthread__mutex__t_2ector(ptr %t1)
  store %"<pthread.h>:pthread_mutex_t" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<pthread.h>:pthread_mutex_t", ptr %l0
  store %"<pthread.h>:pthread_mutex_t" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<pthread.h>:pthread_mutex_t", ptr %rv
  ret %"<pthread.h>:pthread_mutex_t" %rr
}

define linkonce_odr %"<pthread.h>:pthread_cond_t" @olang_2emir_2eHelperKind_2eZero_2e_3cpthread_2eh_3e_3apthread__cond__t() #0 {
entry:
  %l0 = alloca %"<pthread.h>:pthread_cond_t"
  %rv = alloca %"<pthread.h>:pthread_cond_t"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<pthread.h>:pthread_cond_t" @_3cpthread_2eh_3e_3apthread__cond__t_2ector(ptr %t1)
  store %"<pthread.h>:pthread_cond_t" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<pthread.h>:pthread_cond_t", ptr %l0
  store %"<pthread.h>:pthread_cond_t" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<pthread.h>:pthread_cond_t", ptr %rv
  ret %"<pthread.h>:pthread_cond_t" %rr
}

declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eAt_He103f6cfcc0ae31001d1a5cf3ae5a6b0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2ftime_2eNow()
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2eLe_H1eb7a8791568179c0613fadbc6e23399(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2ePu_H1584e9b47b9d124582a35df88dc27260(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2ftime_2eIsVirtual()
declare void @std_2ftime_2eReach(i64 %a0)
declare %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %v0)
declare %"<pthread.h>:pthread_mutex_t" @_3cpthread_2eh_3e_3apthread__mutex__t_2ector(ptr %v0)
declare %"<pthread.h>:pthread_cond_t" @_3cpthread_2eh_3e_3apthread__cond__t_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
