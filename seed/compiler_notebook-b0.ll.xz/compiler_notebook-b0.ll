; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/prompt:Session" = type { ptr, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/eval:Snapshot", { ptr, ptr }, i1, i1, %"compiler/cells:Worker", %"compiler/build:Config", { i64, ptr } }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/eval:Snapshot" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/cells:Worker" = type { i1, i32, i32, i32, i32, i32, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/jupyter:Capture" = type { i32, i32, i32 }
%"compiler/prompt:Reply" = type { i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i32 @compiler_2fnotebook_2eRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i32, { i64, [2 x i64] } }
  %l6 = alloca { i32, { i64, [2 x i64] } }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/prompt:Session"
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %lp18 = alloca ptr
  %l19 = alloca %"std/json:Object"
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i32, { i64, [2 x i64] } }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i1
  %l29 = alloca { i32, { i64, [2 x i64] } }
  %l30 = alloca { i32, { i64, [2 x i64] } }
  %l31 = alloca i32
  %l36 = alloca { i32, { i64, [2 x i64] } }
  %l37 = alloca { i32, { i64, [2 x i64] } }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i32, { i64, [2 x i64] } }
  %l43 = alloca { i32, { i64, [2 x i64] } }
  %l44 = alloca i32
  %l59 = alloca { i64, ptr }
  %l61 = alloca i32
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i32
  %l67 = alloca i1
  %l68 = alloca { i32, { i64, [2 x i64] } }
  %l69 = alloca { i32, { i64, [2 x i64] } }
  %l70 = alloca i32
  %l75 = alloca { i32, { i64, [2 x i64] } }
  %l76 = alloca { i32, { i64, [2 x i64] } }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i32, { i64, [2 x i64] } }
  %l82 = alloca { i32, { i64, [2 x i64] } }
  %l83 = alloca i32
  %l109 = alloca { i64, ptr }
  %l111 = alloca i32
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca i32
  %l119 = alloca i1
  %l122 = alloca { i64, ptr }
  %l123 = alloca i32
  %l125 = alloca i1
  %l131 = alloca i32
  %l133 = alloca %"compiler/prompt:Session"
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l149 = alloca i1
  %l154 = alloca i1
  %l157 = alloca ptr
  %l164 = alloca { i64, [2 x i64] }
  %l167 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l170 = alloca i1
  %l171 = alloca ptr
  %l178 = alloca { i64, [2 x i64] }
  %l183 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l188 = alloca { i64, [2 x i64] }
  %l190 = alloca i1
  %l192 = alloca i1
  %l193 = alloca ptr
  %l199 = alloca { i64, [2 x i64] }
  %l205 = alloca ptr
  %l207 = alloca ptr
  %l208 = alloca i32
  %l210 = alloca i1
  %l216 = alloca i32
  %l218 = alloca { i64, ptr }
  %l221 = alloca %"std/json:Object"
  %l222 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l227 = alloca i32
  %l229 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i32
  %l235 = alloca i1
  %l238 = alloca %"std/json:Object"
  %l241 = alloca ptr
  %l243 = alloca %"std/json:Object"
  %l247 = alloca %"std/json:Object"
  %l248 = alloca %"std/json:Object"
  %l252 = alloca i1
  %l254 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l266 = alloca i32
  %l268 = alloca i1
  %l269 = alloca { i32, { i64, [2 x i64] } }
  %l270 = alloca { i32, { i64, [2 x i64] } }
  %l271 = alloca i32
  %l276 = alloca { i32, { i64, [2 x i64] } }
  %l277 = alloca { i32, { i64, [2 x i64] } }
  %l280 = alloca { i64, ptr }
  %l281 = alloca { i32, { i64, [2 x i64] } }
  %l283 = alloca { i32, { i64, [2 x i64] } }
  %l284 = alloca i32
  %l299 = alloca { i64, ptr }
  %l301 = alloca i32
  %l303 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.builder
  %s21room = alloca [64 x i8], align 8
  %rv = alloca i32
  %t541 = alloca %"compiler/prompt:Session", align 8
  %t598 = alloca { i64, [2 x i64] }, align 8
  %t606 = alloca { i64, [2 x i64] }, align 8
  %t632 = alloca { i64, [2 x i64] }, align 8
  %t640 = alloca { i64, [2 x i64] }, align 8
  %t680 = alloca { i64, [2 x i64] }, align 8
  %t736 = alloca { i64, [2 x i64] }, align 8
  %t795 = alloca { i64, [2 x i64] }, align 8
  %t830 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l26
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l25
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t8, ptr %l23, !tbaa !27
  br label %bb26
bb2:
  %t9 = load i32, ptr %l26, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l28, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l4
  %t13 = load i32, ptr %l26, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t22 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l4, i32 0, i32 0
  store i32 %t21, ptr %t22, !tbaa !23
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t23, ptr %l29
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l30
  %t24 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l29, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  store i32 %t25, ptr %l31, !tbaa !23
  %t26 = load i32, ptr %l31, !tbaa !23
  %t27 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l30, i32 0, i32 0
  store i32 %t26, ptr %t27, !tbaa !23
  %t28 = load i32, ptr %l31, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = call ptr @__olang_errpay_top_get()
  %t35 = load { i64, [2 x i64] }, ptr %t33
  %t36 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l30, i32 0, i32 1
  store { i64, [2 x i64] } %t35, ptr %t36
  br label %bb5
bb5:
  %t38 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l30)
  store { i32, { i64, [2 x i64] } } %t38, ptr %l36
  br label %bb6
bb6:
  %t39 = load { i32, { i64, [2 x i64] } }, ptr %l36
  store { i32, { i64, [2 x i64] } } %t39, ptr %l4
  %t40 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t40, ptr %l37
  %t41 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l37, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  br i1 %t45, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l40, !tbaa !27
  %t48 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t48, ptr %l41
  %t50 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s1, ptr %l41)
  store { i32, { i64, [2 x i64] } } %t50, ptr %l43
  br label %bb9
bb9:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t51 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t51, i64 %t52)
  %t53 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  call void @__olang_sb_put(ptr %s2, ptr %t54, i64 %t55)
  %t56 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t56, i64 %t57)
  %t58 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l43, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  store i32 %t59, ptr %l44, !tbaa !23
  %t60 = load i32, ptr %l44, !tbaa !23
  %t61 = icmp eq i32 %t60, 0
  br i1 %t61, label %bb11, label %bb12
bb10:
  %t63 = load ptr, ptr %s2
  %t64 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t63, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l59, !tbaa !27
  %t69 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t70 = load ptr, ptr %t69
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %sbgrew.72, label %sbdone.73
sbgrew.72:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.73
sbdone.73:
  %t74 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t76 = call i32 @compiler_2fnotebook_2efail(ptr %s1, { i64, ptr } %t74)
  store i32 %t76, ptr %l61
  br label %bb25
bb11:
  %t77 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t77, i64 %t78)
  br label %bb10
bb12:
  %t79 = load i32, ptr %l44, !tbaa !23
  %t80 = icmp eq i32 %t79, 65536
  br i1 %t80, label %bb13, label %bb14
bb13:
  %t82 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t82, i64 %t83)
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t84, i64 %t85)
  %t86 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l43, i32 0, i32 1
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 1
  %t88 = getelementptr { { i64, ptr } }, ptr %t87, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t91, i64 %t92, i8 34)
  %t94 = call ptr @__olang_sb_room(ptr %s2, i64 %t93)
  %t95 = call i64 @__olang_rd_quote(ptr %t94, i64 0, ptr %t91, i64 %t92, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t93)
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t96, i64 %t97)
  br label %bb10
bb14:
  %t98 = load i32, ptr %l44, !tbaa !23
  %t99 = icmp eq i32 %t98, 65537
  br i1 %t99, label %bb15, label %bb16
bb15:
  %t101 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t101, i64 %t102)
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t103, i64 %t104)
  %t105 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l43, i32 0, i32 1
  %t106 = getelementptr { i64, [2 x i64] }, ptr %t105, i32 0, i32 1
  %t107 = getelementptr { { i64, ptr } }, ptr %t106, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t110, i64 %t111, i8 34)
  %t113 = call ptr @__olang_sb_room(ptr %s2, i64 %t112)
  %t114 = call i64 @__olang_rd_quote(ptr %t113, i64 0, ptr %t110, i64 %t111, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t112)
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t115, i64 %t116)
  br label %bb10
bb16:
  %t117 = load i32, ptr %l44, !tbaa !23
  %t118 = icmp eq i32 %t117, 65538
  br i1 %t118, label %bb17, label %bb18
bb17:
  %t120 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t120, i64 %t121)
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t122, i64 %t123)
  %t124 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l43, i32 0, i32 1
  %t125 = getelementptr { i64, [2 x i64] }, ptr %t124, i32 0, i32 1
  %t126 = getelementptr { { i64, ptr } }, ptr %t125, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t129, i64 %t130, i8 34)
  %t132 = call ptr @__olang_sb_room(ptr %s2, i64 %t131)
  %t133 = call i64 @__olang_rd_quote(ptr %t132, i64 0, ptr %t129, i64 %t130, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t131)
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t134, i64 %t135)
  br label %bb10
bb18:
  %t136 = load i32, ptr %l44, !tbaa !23
  %t137 = icmp eq i32 %t136, 65539
  br i1 %t137, label %bb19, label %bb20
bb19:
  %t139 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t139, i64 %t140)
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t141, i64 %t142)
  %t143 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l43, i32 0, i32 1
  %t144 = getelementptr { i64, [2 x i64] }, ptr %t143, i32 0, i32 1
  %t145 = getelementptr { { i64, ptr } }, ptr %t144, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = extractvalue { i64, ptr } %t146, 0
  %t150 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t148, i64 %t149, i8 34)
  %t151 = call ptr @__olang_sb_room(ptr %s2, i64 %t150)
  %t152 = call i64 @__olang_rd_quote(ptr %t151, i64 0, ptr %t148, i64 %t149, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t150)
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t153, i64 %t154)
  br label %bb10
bb20:
  %t155 = load i32, ptr %l44, !tbaa !23
  %t156 = icmp eq i32 %t155, 65540
  br i1 %t156, label %bb21, label %bb22
bb21:
  %t158 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t158, i64 %t159)
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t160, i64 %t161)
  %t162 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l43, i32 0, i32 1
  %t163 = getelementptr { i64, [2 x i64] }, ptr %t162, i32 0, i32 1
  %t164 = getelementptr { { i64, ptr } }, ptr %t163, i32 0, i32 0
  %t165 = load { i64, ptr }, ptr %t164
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t167, i64 %t168, i8 34)
  %t170 = call ptr @__olang_sb_room(ptr %s2, i64 %t169)
  %t171 = call i64 @__olang_rd_quote(ptr %t170, i64 0, ptr %t167, i64 %t168, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t169)
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t172, i64 %t173)
  br label %bb10
bb22:
  %t174 = load i32, ptr %l44, !tbaa !23
  %t175 = icmp eq i32 %t174, 65541
  br i1 %t175, label %bb23, label %bb24
bb23:
  %t177 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t177, i64 %t178)
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t179, i64 %t180)
  %t181 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l43, i32 0, i32 1
  %t182 = getelementptr { i64, [2 x i64] }, ptr %t181, i32 0, i32 1
  %t183 = getelementptr { { i64, ptr } }, ptr %t182, i32 0, i32 0
  %t184 = load { i64, ptr }, ptr %t183
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = extractvalue { i64, ptr } %t184, 0
  %t188 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t186, i64 %t187, i8 34)
  %t189 = call ptr @__olang_sb_room(ptr %s2, i64 %t188)
  %t190 = call i64 @__olang_rd_quote(ptr %t189, i64 0, ptr %t186, i64 %t187, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t188)
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t191, i64 %t192)
  br label %bb10
bb24:
  %t193 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t193, i64 %t194)
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t195, i64 %t196)
  %t197 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l43, i32 0, i32 1
  %t198 = getelementptr { i64, [2 x i64] }, ptr %t197, i32 0, i32 1
  %t199 = getelementptr { { i64, ptr } }, ptr %t198, i32 0, i32 0
  %t200 = load { i64, ptr }, ptr %t199
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = extractvalue { i64, ptr } %t200, 0
  %t204 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t202, i64 %t203, i8 34)
  %t205 = call ptr @__olang_sb_room(ptr %s2, i64 %t204)
  %t206 = call i64 @__olang_rd_quote(ptr %t205, i64 0, ptr %t202, i64 %t203, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t204)
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t207, i64 %t208)
  br label %bb10
bb25:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t209 = load i32, ptr %l61, !tbaa !23
  store i32 %t209, ptr %rv
  br label %ret
bb26:
  %t210 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t213 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %s0, ptr %s0, { i64, ptr } %t210)
  %t214 = extractvalue { i32, ptr } %t213, 1
  %t215 = extractvalue { i32, ptr } %t213, 0
  store i32 %t215, ptr %l65
  %t216 = icmp ne i32 %t215, 0
  br i1 %t216, label %bb28, label %ok.217, !prof !99
ok.217:
  store ptr %t214, ptr %l64
  br label %bb27
bb27:
  %t218 = load ptr, ptr %l64, !tbaa !29
  store ptr %t218, ptr %l62, !tbaa !29
  br label %bb58
bb28:
  %t219 = load i32, ptr %l65, !tbaa !23
  %t220 = ashr i32 %t219, 16
  %t222 = icmp eq i32 %t220, 1
  store i1 %t222, ptr %l67, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l6
  %t223 = load i32, ptr %l65, !tbaa !23
  %t224 = lshr i32 %t223, 16
  %t225 = and i32 %t223, 65535
  %t226 = icmp eq i32 %t224, 1
  %t227 = select i1 %t226, i32 1, i32 0
  %t228 = icmp eq i32 %t223, 0
  %t229 = shl i32 %t227, 16
  %t230 = or i32 %t229, %t225
  %t231 = select i1 %t228, i32 0, i32 %t230
  %t232 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l6, i32 0, i32 0
  store i32 %t231, ptr %t232, !tbaa !23
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t233 = load { i32, { i64, [2 x i64] } }, ptr %l6
  store { i32, { i64, [2 x i64] } } %t233, ptr %l68
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l69
  %t234 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l68, i32 0, i32 0
  %t235 = load i32, ptr %t234, !tbaa !23
  store i32 %t235, ptr %l70, !tbaa !23
  %t236 = load i32, ptr %l70, !tbaa !23
  %t237 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l69, i32 0, i32 0
  store i32 %t236, ptr %t237, !tbaa !23
  %t238 = load i32, ptr %l70, !tbaa !23
  %t239 = ashr i32 %t238, 16
  %t241 = icmp eq i32 %t239, 1
  br i1 %t241, label %bb30, label %bb31
bb30:
  %t243 = call ptr @__olang_errpay_top_get()
  %t245 = load { i64, [2 x i64] }, ptr %t243
  %t246 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l69, i32 0, i32 1
  store { i64, [2 x i64] } %t245, ptr %t246
  br label %bb31
bb31:
  %t248 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fjson_3aError_7d(ptr %s0, ptr %l69)
  store { i32, { i64, [2 x i64] } } %t248, ptr %l75
  br label %bb32
bb32:
  %t249 = load { i32, { i64, [2 x i64] } }, ptr %l75
  store { i32, { i64, [2 x i64] } } %t249, ptr %l6
  %t250 = load { i32, { i64, [2 x i64] } }, ptr %l6
  store { i32, { i64, [2 x i64] } } %t250, ptr %l76
  %t251 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l76, i32 0, i32 0
  %t252 = load i32, ptr %t251, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  br i1 %t255, label %bb33, label %bb34
bb33:
  call void @__olang_errpay_pop()
  br label %bb34
bb34:
  %t257 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t257, ptr %l79, !tbaa !27
  %t258 = load { i32, { i64, [2 x i64] } }, ptr %l6
  store { i32, { i64, [2 x i64] } } %t258, ptr %l80
  %t260 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fjson_3aError_7d(ptr %s3, ptr %l80)
  store { i32, { i64, [2 x i64] } } %t260, ptr %l82
  br label %bb35
bb35:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t261 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  call void @__olang_sb_put(ptr %s4, ptr %t262, i64 %t263)
  %t264 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t264, i64 %t265)
  %t266 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  store i32 %t267, ptr %l83, !tbaa !23
  %t268 = load i32, ptr %l83, !tbaa !23
  %t269 = icmp eq i32 %t268, 0
  br i1 %t269, label %bb37, label %bb38
bb36:
  %t271 = load ptr, ptr %s4
  %t272 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t273 = load i64, ptr %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t271, i64 %t273)
  %t275 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  store { i64, ptr } %t276, ptr %l109, !tbaa !27
  %t277 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t278 = load ptr, ptr %t277
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %sbgrew.280, label %sbdone.281
sbgrew.280:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.281
sbdone.281:
  %t282 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t284 = call i32 @compiler_2fnotebook_2efail(ptr %s3, { i64, ptr } %t282)
  store i32 %t284, ptr %l111
  br label %bb57
bb37:
  %t285 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t286 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t285, i64 %t286)
  br label %bb36
bb38:
  %t287 = load i32, ptr %l83, !tbaa !23
  %t288 = icmp eq i32 %t287, 65536
  br i1 %t288, label %bb39, label %bb40
bb39:
  %t290 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t290, i64 %t291)
  %t292 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t292, i64 %t293)
  %t294 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t295 = getelementptr { i64, [2 x i64] }, ptr %t294, i32 0, i32 1
  %t296 = getelementptr { i64, i64 }, ptr %t295, i32 0, i32 0
  %t297 = load i64, ptr %t296
  %t299 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t300 = call i64 @__olang_fmt_i64(ptr %t299, i64 %t297)
  call void @__olang_sb_add(ptr %s4, i64 %t300)
  %t301 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t301, i64 %t302)
  %t303 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t304 = getelementptr { i64, [2 x i64] }, ptr %t303, i32 0, i32 1
  %t305 = getelementptr { i64, i64 }, ptr %t304, i32 0, i32 1
  %t306 = load i64, ptr %t305
  %t308 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t309 = call i64 @__olang_fmt_i64(ptr %t308, i64 %t306)
  call void @__olang_sb_add(ptr %s4, i64 %t309)
  %t310 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t310, i64 %t311)
  br label %bb36
bb40:
  %t312 = load i32, ptr %l83, !tbaa !23
  %t313 = icmp eq i32 %t312, 65537
  br i1 %t313, label %bb41, label %bb42
bb41:
  %t315 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t315, i64 %t316)
  %t317 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t318 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t317, i64 %t318)
  %t319 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t320 = getelementptr { i64, [2 x i64] }, ptr %t319, i32 0, i32 1
  %t321 = getelementptr { i64, i64 }, ptr %t320, i32 0, i32 0
  %t322 = load i64, ptr %t321
  %t324 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t325 = call i64 @__olang_fmt_i64(ptr %t324, i64 %t322)
  call void @__olang_sb_add(ptr %s4, i64 %t325)
  %t326 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t327 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t326, i64 %t327)
  %t328 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t329 = getelementptr { i64, [2 x i64] }, ptr %t328, i32 0, i32 1
  %t330 = getelementptr { i64, i64 }, ptr %t329, i32 0, i32 1
  %t331 = load i64, ptr %t330
  %t333 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t334 = call i64 @__olang_fmt_i64(ptr %t333, i64 %t331)
  call void @__olang_sb_add(ptr %s4, i64 %t334)
  %t335 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t336 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t335, i64 %t336)
  br label %bb36
bb42:
  %t337 = load i32, ptr %l83, !tbaa !23
  %t338 = icmp eq i32 %t337, 65538
  br i1 %t338, label %bb43, label %bb44
bb43:
  %t340 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t340, i64 %t341)
  %t342 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t343 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t342, i64 %t343)
  %t344 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t345 = getelementptr { i64, [2 x i64] }, ptr %t344, i32 0, i32 1
  %t346 = getelementptr { i64, i64 }, ptr %t345, i32 0, i32 0
  %t347 = load i64, ptr %t346
  %t349 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t350 = call i64 @__olang_fmt_i64(ptr %t349, i64 %t347)
  call void @__olang_sb_add(ptr %s4, i64 %t350)
  %t351 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t352 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t351, i64 %t352)
  %t353 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t354 = getelementptr { i64, [2 x i64] }, ptr %t353, i32 0, i32 1
  %t355 = getelementptr { i64, i64 }, ptr %t354, i32 0, i32 1
  %t356 = load i64, ptr %t355
  %t358 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t359 = call i64 @__olang_fmt_i64(ptr %t358, i64 %t356)
  call void @__olang_sb_add(ptr %s4, i64 %t359)
  %t360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t360, i64 %t361)
  br label %bb36
bb44:
  %t362 = load i32, ptr %l83, !tbaa !23
  %t363 = icmp eq i32 %t362, 65539
  br i1 %t363, label %bb45, label %bb46
bb45:
  %t365 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t366 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t365, i64 %t366)
  %t367 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t368 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t367, i64 %t368)
  %t369 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t370 = getelementptr { i64, [2 x i64] }, ptr %t369, i32 0, i32 1
  %t371 = getelementptr { i64, i64 }, ptr %t370, i32 0, i32 0
  %t372 = load i64, ptr %t371
  %t374 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t375 = call i64 @__olang_fmt_i64(ptr %t374, i64 %t372)
  call void @__olang_sb_add(ptr %s4, i64 %t375)
  %t376 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t376, i64 %t377)
  %t378 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t379 = getelementptr { i64, [2 x i64] }, ptr %t378, i32 0, i32 1
  %t380 = getelementptr { i64, i64 }, ptr %t379, i32 0, i32 1
  %t381 = load i64, ptr %t380
  %t383 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t384 = call i64 @__olang_fmt_i64(ptr %t383, i64 %t381)
  call void @__olang_sb_add(ptr %s4, i64 %t384)
  %t385 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t385, i64 %t386)
  br label %bb36
bb46:
  %t387 = load i32, ptr %l83, !tbaa !23
  %t388 = icmp eq i32 %t387, 65540
  br i1 %t388, label %bb47, label %bb48
bb47:
  %t390 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t390, i64 %t391)
  %t392 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t393 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t392, i64 %t393)
  %t394 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t395 = getelementptr { i64, [2 x i64] }, ptr %t394, i32 0, i32 1
  %t396 = getelementptr { i64, i64 }, ptr %t395, i32 0, i32 0
  %t397 = load i64, ptr %t396
  %t399 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t400 = call i64 @__olang_fmt_i64(ptr %t399, i64 %t397)
  call void @__olang_sb_add(ptr %s4, i64 %t400)
  %t401 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t402 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t401, i64 %t402)
  %t403 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t404 = getelementptr { i64, [2 x i64] }, ptr %t403, i32 0, i32 1
  %t405 = getelementptr { i64, i64 }, ptr %t404, i32 0, i32 1
  %t406 = load i64, ptr %t405
  %t408 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t409 = call i64 @__olang_fmt_i64(ptr %t408, i64 %t406)
  call void @__olang_sb_add(ptr %s4, i64 %t409)
  %t410 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t411 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t410, i64 %t411)
  br label %bb36
bb48:
  %t412 = load i32, ptr %l83, !tbaa !23
  %t413 = icmp eq i32 %t412, 65541
  br i1 %t413, label %bb49, label %bb50
bb49:
  %t415 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t416 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t415, i64 %t416)
  %t417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t417, i64 %t418)
  %t419 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t420 = getelementptr { i64, [2 x i64] }, ptr %t419, i32 0, i32 1
  %t421 = getelementptr { i64, i64 }, ptr %t420, i32 0, i32 0
  %t422 = load i64, ptr %t421
  %t424 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t425 = call i64 @__olang_fmt_i64(ptr %t424, i64 %t422)
  call void @__olang_sb_add(ptr %s4, i64 %t425)
  %t426 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t427 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t426, i64 %t427)
  %t428 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t429 = getelementptr { i64, [2 x i64] }, ptr %t428, i32 0, i32 1
  %t430 = getelementptr { i64, i64 }, ptr %t429, i32 0, i32 1
  %t431 = load i64, ptr %t430
  %t433 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t434 = call i64 @__olang_fmt_i64(ptr %t433, i64 %t431)
  call void @__olang_sb_add(ptr %s4, i64 %t434)
  %t435 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t436 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t435, i64 %t436)
  br label %bb36
bb50:
  %t437 = load i32, ptr %l83, !tbaa !23
  %t438 = icmp eq i32 %t437, 65542
  br i1 %t438, label %bb51, label %bb52
bb51:
  %t440 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t441 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t440, i64 %t441)
  %t442 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t442, i64 %t443)
  %t444 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t445 = getelementptr { i64, [2 x i64] }, ptr %t444, i32 0, i32 1
  %t446 = getelementptr { i64, i64 }, ptr %t445, i32 0, i32 0
  %t447 = load i64, ptr %t446
  %t449 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t450 = call i64 @__olang_fmt_i64(ptr %t449, i64 %t447)
  call void @__olang_sb_add(ptr %s4, i64 %t450)
  %t451 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t451, i64 %t452)
  %t453 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t454 = getelementptr { i64, [2 x i64] }, ptr %t453, i32 0, i32 1
  %t455 = getelementptr { i64, i64 }, ptr %t454, i32 0, i32 1
  %t456 = load i64, ptr %t455
  %t458 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t459 = call i64 @__olang_fmt_i64(ptr %t458, i64 %t456)
  call void @__olang_sb_add(ptr %s4, i64 %t459)
  %t460 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t460, i64 %t461)
  br label %bb36
bb52:
  %t462 = load i32, ptr %l83, !tbaa !23
  %t463 = icmp eq i32 %t462, 65543
  br i1 %t463, label %bb53, label %bb54
bb53:
  %t465 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t466 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t465, i64 %t466)
  %t467 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t467, i64 %t468)
  %t469 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l82, i32 0, i32 1
  %t470 = getelementptr { i64, [2 x i64] }, ptr %t469, i32 0, i32 1
  %t471 = getelementptr { { i64, ptr } }, ptr %t470, i32 0, i32 0
  %t472 = load { i64, ptr }, ptr %t471
  %t474 = extractvalue { i64, ptr } %t472, 1
  %t475 = extractvalue { i64, ptr } %t472, 0
  %t476 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t474, i64 %t475, i8 34)
  %t477 = call ptr @__olang_sb_room(ptr %s4, i64 %t476)
  %t478 = call i64 @__olang_rd_quote(ptr %t477, i64 0, ptr %t474, i64 %t475, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t476)
  %t479 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t480 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t479, i64 %t480)
  br label %bb36
bb54:
  %t481 = load i32, ptr %l83, !tbaa !23
  %t482 = icmp eq i32 %t481, 65544
  br i1 %t482, label %bb55, label %bb56
bb55:
  %t484 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t484, i64 %t485)
  br label %bb36
bb56:
  %t486 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t487 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t486, i64 %t487)
  br label %bb36
bb57:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t488 = load i32, ptr %l111, !tbaa !23
  store i32 %t488, ptr %rv
  br label %ret
bb58:
  %t489 = load ptr, ptr %l62, !tbaa !29
  store ptr %t489, ptr %l7, !tbaa !29
  %t490 = load ptr, ptr %l7, !tbaa !29
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l114, !tbaa !27
  %t491 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t494 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t490, { i64, ptr } %t491)
  %t495 = extractvalue { i32, ptr } %t494, 1
  %t496 = extractvalue { i32, ptr } %t494, 0
  store i32 %t496, ptr %l117
  %t497 = icmp ne i32 %t496, 0
  br i1 %t497, label %bb60, label %ok.498, !prof !99
ok.498:
  store ptr %t495, ptr %l116
  br label %bb59
bb59:
  %t499 = load ptr, ptr %l116, !tbaa !29
  %t500 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s0, ptr %s0, ptr %t499)
  %t501 = extractvalue { i32, { i64, ptr } } %t500, 1
  %t502 = extractvalue { i32, { i64, ptr } } %t500, 0
  store i32 %t502, ptr %l123
  %t503 = icmp ne i32 %t502, 0
  br i1 %t503, label %bb65, label %ok.504, !prof !99
ok.504:
  store { i64, ptr } %t501, ptr %l122
  br label %bb64
bb60:
  %t505 = load i32, ptr %l117, !tbaa !23
  %t506 = ashr i32 %t505, 16
  %t508 = icmp eq i32 %t506, 1
  store i1 %t508, ptr %l119, !tbaa !21
  %t509 = load i32, ptr %l117, !tbaa !23
  %t510 = ashr i32 %t509, 16
  %t512 = icmp eq i32 %t510, 1
  br i1 %t512, label %bb61, label %bb62
bb61:
  call void @__olang_errpay_pop()
  br label %bb62
bb62:
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s5
  %t514 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t514, 1
  %t517 = extractvalue { i64, ptr } %t514, 0
  %t518 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t519 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t520 = add i64 %t517, %t519
  %t521 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t520)
  call void @olang_textcopy(ptr %t521, ptr %t516, i64 %t517)
  %t522 = getelementptr i8, ptr %t521, i64 %t517
  call void @olang_textcopy(ptr %t522, ptr %t518, i64 %t519)
  %t523 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t521, 1
  %t527 = call i32 @compiler_2fnotebook_2efail(ptr %s5, { i64, ptr } %t524)
  store i32 %t527, ptr %l131
  br label %bb68
bb64:
  %t528 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t528, ptr %l112, !tbaa !27
  br label %bb69
bb65:
  %t529 = load i32, ptr %l123, !tbaa !23
  %t530 = ashr i32 %t529, 16
  %t532 = icmp eq i32 %t530, 1
  store i1 %t532, ptr %l125, !tbaa !21
  %t533 = load i32, ptr %l123, !tbaa !23
  %t534 = ashr i32 %t533, 16
  %t536 = icmp eq i32 %t534, 1
  br i1 %t536, label %bb66, label %bb67
bb66:
  call void @__olang_errpay_pop()
  br label %bb67
bb67:
  br label %bb63
bb68:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t538 = load i32, ptr %l131, !tbaa !23
  store i32 %t538, ptr %rv
  br label %ret
bb69:
  %t539 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t539, ptr %l8, !tbaa !27
  call void @compiler_2fprompt_3aSession_2ector(ptr %t541, ptr %v0, ptr %s0, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l133, ptr %t541, i64 1152, i1 false)
  br label %bb70
bb70:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l133, i64 1152, i1 false)
  %t543 = getelementptr %"compiler/prompt:Session", ptr %l9, i32 0, i32 8
  store i1 true, ptr %t543, !tbaa !21
  store i64 0, ptr %l10, !tbaa !24
  store i1 false, ptr %l11, !tbaa !21
  %t544 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t544, ptr %l134
  br label %bb71
bb71:
  %t545 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l134
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t545, ptr %l12
  %t546 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t546, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t548, 0
  store i64 %t550, ptr %l15, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s8
  %t552 = load i64, ptr %l14, !tbaa !24
  %t553 = load i64, ptr %l15, !tbaa !24
  %t556 = icmp slt i64 %t552, %t553
  %t558 = xor i1 %t556, true
  br i1 %t558, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb107
bb74:
  br label %bb75
bb75:
  %t560 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t560, ptr %l142, !tbaa !27
  %t561 = load i64, ptr %l14, !tbaa !24
  %t563 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !27
  %t565 = getelementptr ptr, ptr %t564, i64 %t561
  %t566 = load ptr, ptr %t565, !tbaa !39
  store ptr %t566, ptr %l16, !tbaa !29
  %t568 = load ptr, ptr %l16, !tbaa !29
  %t570 = call { i64, ptr } @compiler_2fnotebook_2estr(ptr %s0, ptr %s8, ptr %s8, ptr %t568, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store { i64, ptr } %t570, ptr %l146
  br label %bb76
bb76:
  %t571 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 1
  %t573 = extractvalue { i64, ptr } %t571, 0
  %t574 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t573)
  call void @olang_textcopy(ptr %t574, ptr %t572, i64 %t573)
  %t575 = insertvalue { i64, ptr } undef, i64 %t573, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  %t580 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s8, { i64, ptr } %t576, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t580, ptr %l149
  br label %bb77
bb77:
  %t581 = load i1, ptr %l149, !tbaa !21
  %t582 = xor i1 %t581, true
  br i1 %t582, label %bb78, label %bb79
bb78:
  %t584 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2ePush_3cstd_2fjson_3aJson_26_3e(ptr %s0, ptr %s0, ptr %l12, ptr %t584)
  br label %bb80
bb79:
  %t587 = load i1, ptr %l11, !tbaa !21
  br i1 %t587, label %bb81, label %bb82
bb80:
  br label %bb105
bb81:
  %t591 = xor i1 %a3, true
  store i1 %t591, ptr %l154, !tbaa !21
  br label %bb83
bb82:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb83
bb83:
  %t593 = load i1, ptr %l154, !tbaa !21
  br i1 %t593, label %bb84, label %bb85
bb84:
  store ptr %l12, ptr %l157, !tbaa !29
  %t594 = load ptr, ptr %l16, !tbaa !29
  %t595 = mul i64 0, 8
  %t596 = insertvalue { i64, ptr } undef, i64 0, 0
  %t597 = insertvalue { i64, ptr } %t596, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t598
  %t599 = getelementptr { i64, [2 x i64] }, ptr %t598, i32 0, i32 0
  store i64 6, ptr %t599
  %t601 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t597, 0
  %t602 = getelementptr { i64, [2 x i64] }, ptr %t598, i32 0, i32 1
  store { { i64, ptr } } %t601, ptr %t602
  %t603 = load { i64, [2 x i64] }, ptr %t598
  %t605 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t603, ptr %t605
  store { i64, [2 x i64] } zeroinitializer, ptr %t606
  %t607 = getelementptr { i64, [2 x i64] }, ptr %t606, i32 0, i32 0
  store i64 0, ptr %t607
  %t608 = load { i64, [2 x i64] }, ptr %t606
  %t610 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t608, ptr %t610
  %t614 = call { i64, [2 x i64] } @compiler_2fnotebook_2ewith(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t594, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t605, ptr %t610)
  store { i64, [2 x i64] } %t614, ptr %l164
  br label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s13
  %t615 = load ptr, ptr %l16, !tbaa !29
  %t617 = call { i64, ptr } @compiler_2fnotebook_2esource(ptr %s0, ptr %s13, ptr %t615)
  store { i64, ptr } %t617, ptr %l167
  br label %bb88
bb86:
  %t618 = load { i64, [2 x i64] }, ptr %l164
  %t619 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t618, ptr %t619
  %t620 = load ptr, ptr %l157, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2ePush_3cstd_2fjson_3aJson_26_3e(ptr %s0, ptr %s0, ptr %t620, ptr %t619)
  br label %bb87
bb87:
  br label %bb104
bb88:
  %t622 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t624 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s13, ptr %s13, { i64, ptr } %t622)
  store { i64, ptr } %t624, ptr %l169
  br label %bb89
bb89:
  %t625 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t626 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s13, ptr %s13, { i64, ptr } %t625, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t626, ptr %l170
  br label %bb90
bb90:
  %t627 = load i1, ptr %l170, !tbaa !21
  br i1 %t627, label %bb91, label %bb92
bb91:
  store ptr %l12, ptr %l171, !tbaa !29
  %t628 = load ptr, ptr %l16, !tbaa !29
  %t629 = mul i64 0, 8
  %t630 = insertvalue { i64, ptr } undef, i64 0, 0
  %t631 = insertvalue { i64, ptr } %t630, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t632
  %t633 = getelementptr { i64, [2 x i64] }, ptr %t632, i32 0, i32 0
  store i64 6, ptr %t633
  %t635 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t631, 0
  %t636 = getelementptr { i64, [2 x i64] }, ptr %t632, i32 0, i32 1
  store { { i64, ptr } } %t635, ptr %t636
  %t637 = load { i64, [2 x i64] }, ptr %t632
  %t639 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t637, ptr %t639
  store { i64, [2 x i64] } zeroinitializer, ptr %t640
  %t641 = getelementptr { i64, [2 x i64] }, ptr %t640, i32 0, i32 0
  store i64 0, ptr %t641
  %t642 = load { i64, [2 x i64] }, ptr %t640
  %t644 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t642, ptr %t644
  %t648 = call { i64, [2 x i64] } @compiler_2fnotebook_2ewith(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t628, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t639, ptr %t644)
  store { i64, [2 x i64] } %t648, ptr %l178
  br label %bb93
bb92:
  %t649 = load i64, ptr %l10, !tbaa !24
  %t652 = add i64 %t649, 1
  store i64 %t652, ptr %l10, !tbaa !24
  store ptr %l9, ptr %l183, !tbaa !29
  %t654 = load ptr, ptr %l16, !tbaa !29
  %t656 = call { i64, ptr } @compiler_2fnotebook_2esource(ptr %s0, ptr %s0, ptr %t654)
  store { i64, ptr } %t656, ptr %l185
  br label %bb95
bb93:
  %t657 = load { i64, [2 x i64] }, ptr %l178
  %t658 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t657, ptr %t658
  %t659 = load ptr, ptr %l171, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2ePush_3cstd_2fjson_3aJson_26_3e(ptr %s0, ptr %s0, ptr %t659, ptr %t658)
  br label %bb94
bb94:
  br label %bb103
bb95:
  %t661 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t662 = load i64, ptr %l10, !tbaa !24
  %t663 = load ptr, ptr %l183, !tbaa !29
  %t666 = call { i64, [2 x i64] } @compiler_2fnotebook_2eexecute(ptr %s0, ptr %s0, ptr %s0, ptr %v0, ptr %t663, { i64, ptr } %t661, i64 %t662)
  store { i64, [2 x i64] } %t666, ptr %l188
  br label %bb96
bb96:
  %t667 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store ptr %t667, ptr %lp18
  %t668 = load { i64, [2 x i64] }, ptr %l188
  %t669 = load ptr, ptr %lp18
  store { i64, [2 x i64] } %t668, ptr %t669
  %t670 = load i1, ptr %l11, !tbaa !21
  br i1 %t670, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb100
bb98:
  %t672 = load ptr, ptr %lp18
  %t674 = call i1 @compiler_2fnotebook_2efailedWith(ptr %s0, ptr %t672)
  store i1 %t674, ptr %l192
  br label %bb99
bb99:
  %t675 = load i1, ptr %l192, !tbaa !21
  store i1 %t675, ptr %l190, !tbaa !21
  br label %bb100
bb100:
  %t676 = load i1, ptr %l190, !tbaa !21
  store i1 %t676, ptr %l11, !tbaa !21
  store ptr %l12, ptr %l193, !tbaa !29
  %t677 = load ptr, ptr %l16, !tbaa !29
  %t678 = load ptr, ptr %lp18
  %t679 = load i64, ptr %l10, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t680
  %t681 = getelementptr { i64, [2 x i64] }, ptr %t680, i32 0, i32 0
  store i64 3, ptr %t681
  %t683 = insertvalue { i64 } undef, i64 %t679, 0
  %t684 = getelementptr { i64, [2 x i64] }, ptr %t680, i32 0, i32 1
  store { i64 } %t683, ptr %t684
  %t685 = load { i64, [2 x i64] }, ptr %t680
  %t687 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t685, ptr %t687
  %t691 = call { i64, [2 x i64] } @compiler_2fnotebook_2ewith(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t677, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t678, ptr %t687)
  store { i64, [2 x i64] } %t691, ptr %l199
  br label %bb101
bb101:
  %t692 = load { i64, [2 x i64] }, ptr %l199
  %t693 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t692, ptr %t693
  %t694 = load ptr, ptr %l193, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2ePush_3cstd_2fjson_3aJson_26_3e(ptr %s0, ptr %s0, ptr %t694, ptr %t693)
  br label %bb102
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s13)
  br label %bb104
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s8)
  br label %bb106
bb106:
  %t696 = load i64, ptr %l14, !tbaa !24
  %t699 = add i64 %t696, 1
  store i64 %t699, ptr %l14, !tbaa !24
  br label %bb72
bb107:
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eEnd(ptr %s0, ptr %v0, ptr %l9)
  br label %bb108
bb108:
  %t702 = load ptr, ptr %l7, !tbaa !29
  %t704 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAsObj(ptr %s0, ptr %s0, ptr %t702)
  %t705 = extractvalue { i32, ptr } %t704, 1
  %t706 = extractvalue { i32, ptr } %t704, 0
  store i32 %t706, ptr %l208
  %t707 = icmp ne i32 %t706, 0
  br i1 %t707, label %bb110, label %ok.708, !prof !99
ok.708:
  store ptr %t705, ptr %l207
  br label %bb109
bb109:
  %t709 = load ptr, ptr %l207, !tbaa !29
  store ptr %t709, ptr %l205, !tbaa !29
  br label %bb115
bb110:
  %t710 = load i32, ptr %l208, !tbaa !23
  %t711 = ashr i32 %t710, 16
  %t713 = icmp eq i32 %t711, 1
  store i1 %t713, ptr %l210, !tbaa !21
  %t714 = load i32, ptr %l208, !tbaa !23
  %t715 = ashr i32 %t714, 16
  %t717 = icmp eq i32 %t715, 1
  br i1 %t717, label %bb111, label %bb112
bb111:
  call void @__olang_errpay_pop()
  br label %bb112
bb112:
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s17
  %t719 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t721 = extractvalue { i64, ptr } %t719, 1
  %t722 = extractvalue { i64, ptr } %t719, 0
  %t723 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t724 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t725 = add i64 %t722, %t724
  %t726 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t725)
  call void @olang_textcopy(ptr %t726, ptr %t721, i64 %t722)
  %t727 = getelementptr i8, ptr %t726, i64 %t722
  call void @olang_textcopy(ptr %t727, ptr %t723, i64 %t724)
  %t728 = insertvalue { i64, ptr } undef, i64 %t725, 0
  %t729 = insertvalue { i64, ptr } %t728, ptr %t726, 1
  %t732 = call i32 @compiler_2fnotebook_2efail(ptr %s17, { i64, ptr } %t729)
  store i32 %t732, ptr %l216
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t733 = load i32, ptr %l216, !tbaa !23
  store i32 %t733, ptr %rv
  br label %ret
bb115:
  %t735 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2eToArray_3cstd_2fjson_3aJson_26_3e(ptr %s0, ptr %s0, ptr %l12)
  store { i64, ptr } %t735, ptr %l218
  br label %bb116
bb116:
  store { i64, [2 x i64] } zeroinitializer, ptr %t736
  %t737 = getelementptr { i64, [2 x i64] }, ptr %t736, i32 0, i32 0
  store i64 6, ptr %t737
  %t738 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t739 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t738, 0
  %t740 = getelementptr { i64, [2 x i64] }, ptr %t736, i32 0, i32 1
  store { { i64, ptr } } %t739, ptr %t740
  %t741 = load { i64, [2 x i64] }, ptr %t736
  %t743 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t741, ptr %t743
  %t744 = load ptr, ptr %l205, !tbaa !29
  %t746 = call %"std/json:Object" @compiler_2fnotebook_2eset(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t744, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t743)
  store %"std/json:Object" %t746, ptr %l221
  br label %bb117
bb117:
  %t747 = load %"std/json:Object", ptr %l221
  store %"std/json:Object" %t747, ptr %l19
  %t748 = load ptr, ptr %l7, !tbaa !29
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l224, !tbaa !27
  %t749 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t752 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t748, { i64, ptr } %t749)
  %t753 = extractvalue { i32, ptr } %t752, 1
  %t754 = extractvalue { i32, ptr } %t752, 0
  store i32 %t754, ptr %l227
  %t755 = icmp ne i32 %t754, 0
  br i1 %t755, label %bb119, label %ok.756, !prof !99
ok.756:
  store ptr %t753, ptr %l226
  br label %bb118
bb118:
  %t757 = load ptr, ptr %l226, !tbaa !29
  %t758 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAsObj(ptr %s0, ptr %s0, ptr %t757)
  %t759 = extractvalue { i32, ptr } %t758, 1
  %t760 = extractvalue { i32, ptr } %t758, 0
  store i32 %t760, ptr %l233
  %t761 = icmp ne i32 %t760, 0
  br i1 %t761, label %bb124, label %ok.762, !prof !99
ok.762:
  store ptr %t759, ptr %l232
  br label %bb123
bb119:
  %t763 = load i32, ptr %l227, !tbaa !23
  %t764 = ashr i32 %t763, 16
  %t766 = icmp eq i32 %t764, 1
  store i1 %t766, ptr %l229, !tbaa !21
  %t767 = load i32, ptr %l227, !tbaa !23
  %t768 = ashr i32 %t767, 16
  %t770 = icmp eq i32 %t768, 1
  br i1 %t770, label %bb120, label %bb121
bb120:
  call void @__olang_errpay_pop()
  br label %bb121
bb121:
  br label %bb122
bb122:
  %t772 = call %"std/json:Object" @compiler_2fnotebook_2eempty(ptr %s0)
  store %"std/json:Object" %t772, ptr %l238
  br label %bb127
bb123:
  %t773 = load ptr, ptr %l232, !tbaa !29
  store ptr %t773, ptr %l222, !tbaa !29
  br label %bb128
bb124:
  %t774 = load i32, ptr %l233, !tbaa !23
  %t775 = ashr i32 %t774, 16
  %t777 = icmp eq i32 %t775, 1
  store i1 %t777, ptr %l235, !tbaa !21
  %t778 = load i32, ptr %l233, !tbaa !23
  %t779 = ashr i32 %t778, 16
  %t781 = icmp eq i32 %t779, 1
  br i1 %t781, label %bb125, label %bb126
bb125:
  call void @__olang_errpay_pop()
  br label %bb126
bb126:
  br label %bb122
bb127:
  %t783 = load %"std/json:Object", ptr %l238
  %t784 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 48, i64 8)
  store %"std/json:Object" %t783, ptr %t784
  store ptr %t784, ptr %l222, !tbaa !29
  br label %bb128
bb128:
  %t786 = load ptr, ptr %l222, !tbaa !29
  %t787 = load %"std/json:Object", ptr %l19
  %t789 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 48, i64 8)
  store %"std/json:Object" %t787, ptr %t789
  store ptr %t789, ptr %l241, !tbaa !29
  %t792 = call %"std/json:Object" @compiler_2fnotebook_2ekernelspec(ptr %s0, ptr %s0, ptr %t786)
  store %"std/json:Object" %t792, ptr %l243
  br label %bb129
bb129:
  %t793 = load %"std/json:Object", ptr %l243
  %t794 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 48, i64 8)
  store %"std/json:Object" %t793, ptr %t794
  store { i64, [2 x i64] } zeroinitializer, ptr %t795
  %t796 = getelementptr { i64, [2 x i64] }, ptr %t795, i32 0, i32 0
  store i64 7, ptr %t796
  %t798 = insertvalue { ptr } undef, ptr %t794, 0
  %t799 = getelementptr { i64, [2 x i64] }, ptr %t795, i32 0, i32 1
  store { ptr } %t798, ptr %t799
  %t800 = load { i64, [2 x i64] }, ptr %t795
  %t802 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t800, ptr %t802
  %t803 = load ptr, ptr %l241, !tbaa !29
  %t805 = call %"std/json:Object" @compiler_2fnotebook_2eset(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t803, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t802)
  store %"std/json:Object" %t805, ptr %l247
  br label %bb130
bb130:
  %t806 = load %"std/json:Object", ptr %l19
  store %"std/json:Object" %t806, ptr %l248
  %t807 = load %"std/json:Object", ptr %l247
  store %"std/json:Object" %t807, ptr %l19
  %t808 = load i1, ptr @olang_2esole_2estd_2fjson_3aObject_2e0
  br i1 %t808, label %bb131, label %bb132
bb131:
  %t810 = getelementptr %"std/json:Object", ptr %l248, i32 0, i32 0
  %t811 = load { i64, ptr }, ptr %t810
  %t812 = extractvalue { i64, ptr } %t811, 1
  call void @__olang_region_release(ptr %t812)
  store { i64, ptr } zeroinitializer, ptr %t810
  br label %bb132
bb132:
  %t813 = load i1, ptr @olang_2esole_2estd_2fjson_3aObject_2e2
  br i1 %t813, label %bb133, label %bb134
bb133:
  %t815 = getelementptr %"std/json:Object", ptr %l248, i32 0, i32 2
  %t816 = load { i64, ptr }, ptr %t815
  %t817 = extractvalue { i64, ptr } %t816, 1
  call void @__olang_region_release(ptr %t817)
  store { i64, ptr } zeroinitializer, ptr %t815
  br label %bb134
bb134:
  %t818 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t820 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t818, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t820, ptr %l252
  br label %bb135
bb135:
  %t821 = load i1, ptr %l252, !tbaa !21
  %t822 = xor i1 %t821, true
  br i1 %t822, label %bb136, label %bb137
bb136:
  %t824 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t824, ptr %l254, !tbaa !27
  br label %bb138
bb137:
  %t826 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t826, ptr %l254, !tbaa !27
  br label %bb138
bb138:
  %t828 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t828, ptr %l21, !tbaa !27
  %t829 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t829, ptr %l257, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t830
  %t831 = getelementptr { i64, [2 x i64] }, ptr %t830, i32 0, i32 0
  store i64 7, ptr %t831
  %t833 = insertvalue { ptr } undef, ptr %l19, 0
  %t834 = getelementptr { i64, [2 x i64] }, ptr %t830, i32 0, i32 1
  store { ptr } %t833, ptr %t834
  %t835 = load { i64, [2 x i64] }, ptr %t830
  %t838 = call { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_3e(ptr %s0, ptr %s0, ptr %s0, { i64, [2 x i64] } %t835, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, i32 0)
  store { i64, ptr } %t838, ptr %l261
  br label %bb139
bb139:
  %t839 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t840 = extractvalue { i64, ptr } %t839, 1
  %t841 = extractvalue { i64, ptr } %t839, 0
  %t842 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t843 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t844 = add i64 %t841, %t843
  %t845 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t844)
  call void @olang_textcopy(ptr %t845, ptr %t840, i64 %t841)
  %t846 = getelementptr i8, ptr %t845, i64 %t841
  call void @olang_textcopy(ptr %t846, ptr %t842, i64 %t843)
  %t847 = insertvalue { i64, ptr } undef, i64 %t844, 0
  %t848 = insertvalue { i64, ptr } %t847, ptr %t845, 1
  %t851 = extractvalue { i64, ptr } %t848, 0
  %t852 = extractvalue { i64, ptr } %t848, 1
  %t853 = mul i64 %t851, 1
  %t854 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t853)
  call void @llvm.memcpy.p0.p0.i64(ptr %t854, ptr %t852, i64 %t853, i1 false)
  %t855 = insertvalue { i64, ptr } undef, i64 %t851, 0
  %t856 = insertvalue { i64, ptr } %t855, ptr %t854, 1
  %t857 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t858 = extractvalue { i64, ptr } %t857, 1
  %t859 = call ptr @__olang_scope_of(ptr %t858, ptr null)
  %t860 = call ptr @__olang_scope_hold(ptr %t859)
  %t861 = ptrtoint ptr %t860 to i64
  %t863 = inttoptr i64 %t861 to ptr
  %t864 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t866 = call i32 @std_2fos_2eWriteFile(ptr %t863, ptr %s0, { i64, ptr } %t864, { i64, ptr } %t856)
  store i32 %t866, ptr %l266
  %t867 = icmp ne i32 %t866, 0
  br i1 %t867, label %bb141, label %ok.868, !prof !99
ok.868:
  br label %bb140
bb140:
  br label %bb165
bb141:
  %t869 = load i32, ptr %l266, !tbaa !23
  %t870 = ashr i32 %t869, 16
  %t872 = icmp eq i32 %t870, 1
  store i1 %t872, ptr %l268, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l22
  %t873 = load i32, ptr %l266, !tbaa !23
  %t874 = lshr i32 %t873, 16
  %t875 = and i32 %t873, 65535
  %t876 = icmp eq i32 %t874, 1
  %t877 = select i1 %t876, i32 1, i32 0
  %t878 = icmp eq i32 %t873, 0
  %t879 = shl i32 %t877, 16
  %t880 = or i32 %t879, %t875
  %t881 = select i1 %t878, i32 0, i32 %t880
  %t882 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l22, i32 0, i32 0
  store i32 %t881, ptr %t882, !tbaa !23
  br label %bb142
bb142:
  store %olang.scope zeroinitializer, ptr %s20
  %t883 = load { i32, { i64, [2 x i64] } }, ptr %l22
  store { i32, { i64, [2 x i64] } } %t883, ptr %l269
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l270
  %t884 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l269, i32 0, i32 0
  %t885 = load i32, ptr %t884, !tbaa !23
  store i32 %t885, ptr %l271, !tbaa !23
  %t886 = load i32, ptr %l271, !tbaa !23
  %t887 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l270, i32 0, i32 0
  store i32 %t886, ptr %t887, !tbaa !23
  %t888 = load i32, ptr %l271, !tbaa !23
  %t889 = ashr i32 %t888, 16
  %t891 = icmp eq i32 %t889, 1
  br i1 %t891, label %bb143, label %bb144
bb143:
  %t893 = call ptr @__olang_errpay_top_get()
  %t895 = load { i64, [2 x i64] }, ptr %t893
  %t896 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l270, i32 0, i32 1
  store { i64, [2 x i64] } %t895, ptr %t896
  br label %bb144
bb144:
  %t898 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l270)
  store { i32, { i64, [2 x i64] } } %t898, ptr %l276
  br label %bb145
bb145:
  %t899 = load { i32, { i64, [2 x i64] } }, ptr %l276
  store { i32, { i64, [2 x i64] } } %t899, ptr %l22
  %t900 = load { i32, { i64, [2 x i64] } }, ptr %l22
  store { i32, { i64, [2 x i64] } } %t900, ptr %l277
  %t901 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l277, i32 0, i32 0
  %t902 = load i32, ptr %t901, !tbaa !23
  %t903 = ashr i32 %t902, 16
  %t905 = icmp eq i32 %t903, 1
  br i1 %t905, label %bb146, label %bb147
bb146:
  call void @__olang_errpay_pop()
  br label %bb147
bb147:
  %t907 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t907, ptr %l280, !tbaa !27
  %t908 = load { i32, { i64, [2 x i64] } }, ptr %l22
  store { i32, { i64, [2 x i64] } } %t908, ptr %l281
  %t910 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s20, ptr %l281)
  store { i32, { i64, [2 x i64] } } %t910, ptr %l283
  br label %bb148
bb148:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s21
  store ptr %s21room, ptr %s21
  %t911 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t912 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t911, i64 %t912)
  %t913 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t914 = extractvalue { i64, ptr } %t913, 1
  %t915 = extractvalue { i64, ptr } %t913, 0
  call void @__olang_sb_put(ptr %s21, ptr %t914, i64 %t915)
  %t916 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t917 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t916, i64 %t917)
  %t918 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l283, i32 0, i32 0
  %t919 = load i32, ptr %t918, !tbaa !23
  store i32 %t919, ptr %l284, !tbaa !23
  %t920 = load i32, ptr %l284, !tbaa !23
  %t921 = icmp eq i32 %t920, 0
  br i1 %t921, label %bb150, label %bb151
bb149:
  %t923 = load ptr, ptr %s21
  %t924 = getelementptr %olang.builder, ptr %s21, i32 0, i32 1
  %t925 = load i64, ptr %t924
  %t926 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t925)
  call void @olang_textcopy(ptr %t926, ptr %t923, i64 %t925)
  %t927 = insertvalue { i64, ptr } undef, i64 %t925, 0
  %t928 = insertvalue { i64, ptr } %t927, ptr %t926, 1
  store { i64, ptr } %t928, ptr %l299, !tbaa !27
  %t929 = getelementptr %olang.builder, ptr %s21, i32 0, i32 3
  %t930 = load ptr, ptr %t929
  %t931 = icmp ne ptr %t930, null
  br i1 %t931, label %sbgrew.932, label %sbdone.933
sbgrew.932:
  call void @__olang_sb_done(ptr %s21)
  br label %sbdone.933
sbdone.933:
  %t934 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t936 = call i32 @compiler_2fnotebook_2efail(ptr %s20, { i64, ptr } %t934)
  store i32 %t936, ptr %l301
  br label %bb164
bb150:
  %t937 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t938 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t937, i64 %t938)
  br label %bb149
bb151:
  %t939 = load i32, ptr %l284, !tbaa !23
  %t940 = icmp eq i32 %t939, 65536
  br i1 %t940, label %bb152, label %bb153
bb152:
  %t942 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t943 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t942, i64 %t943)
  %t944 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t945 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t944, i64 %t945)
  %t946 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l283, i32 0, i32 1
  %t947 = getelementptr { i64, [2 x i64] }, ptr %t946, i32 0, i32 1
  %t948 = getelementptr { { i64, ptr } }, ptr %t947, i32 0, i32 0
  %t949 = load { i64, ptr }, ptr %t948
  %t951 = extractvalue { i64, ptr } %t949, 1
  %t952 = extractvalue { i64, ptr } %t949, 0
  %t953 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t951, i64 %t952, i8 34)
  %t954 = call ptr @__olang_sb_room(ptr %s21, i64 %t953)
  %t955 = call i64 @__olang_rd_quote(ptr %t954, i64 0, ptr %t951, i64 %t952, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t953)
  %t956 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t957 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t956, i64 %t957)
  br label %bb149
bb153:
  %t958 = load i32, ptr %l284, !tbaa !23
  %t959 = icmp eq i32 %t958, 65537
  br i1 %t959, label %bb154, label %bb155
bb154:
  %t961 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t962 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t961, i64 %t962)
  %t963 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t964 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t963, i64 %t964)
  %t965 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l283, i32 0, i32 1
  %t966 = getelementptr { i64, [2 x i64] }, ptr %t965, i32 0, i32 1
  %t967 = getelementptr { { i64, ptr } }, ptr %t966, i32 0, i32 0
  %t968 = load { i64, ptr }, ptr %t967
  %t970 = extractvalue { i64, ptr } %t968, 1
  %t971 = extractvalue { i64, ptr } %t968, 0
  %t972 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t970, i64 %t971, i8 34)
  %t973 = call ptr @__olang_sb_room(ptr %s21, i64 %t972)
  %t974 = call i64 @__olang_rd_quote(ptr %t973, i64 0, ptr %t970, i64 %t971, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t972)
  %t975 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t976 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t975, i64 %t976)
  br label %bb149
bb155:
  %t977 = load i32, ptr %l284, !tbaa !23
  %t978 = icmp eq i32 %t977, 65538
  br i1 %t978, label %bb156, label %bb157
bb156:
  %t980 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t981 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t980, i64 %t981)
  %t982 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t983 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t982, i64 %t983)
  %t984 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l283, i32 0, i32 1
  %t985 = getelementptr { i64, [2 x i64] }, ptr %t984, i32 0, i32 1
  %t986 = getelementptr { { i64, ptr } }, ptr %t985, i32 0, i32 0
  %t987 = load { i64, ptr }, ptr %t986
  %t989 = extractvalue { i64, ptr } %t987, 1
  %t990 = extractvalue { i64, ptr } %t987, 0
  %t991 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t989, i64 %t990, i8 34)
  %t992 = call ptr @__olang_sb_room(ptr %s21, i64 %t991)
  %t993 = call i64 @__olang_rd_quote(ptr %t992, i64 0, ptr %t989, i64 %t990, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t991)
  %t994 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t995 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t994, i64 %t995)
  br label %bb149
bb157:
  %t996 = load i32, ptr %l284, !tbaa !23
  %t997 = icmp eq i32 %t996, 65539
  br i1 %t997, label %bb158, label %bb159
bb158:
  %t999 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t1000 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t999, i64 %t1000)
  %t1001 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t1002 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1001, i64 %t1002)
  %t1003 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l283, i32 0, i32 1
  %t1004 = getelementptr { i64, [2 x i64] }, ptr %t1003, i32 0, i32 1
  %t1005 = getelementptr { { i64, ptr } }, ptr %t1004, i32 0, i32 0
  %t1006 = load { i64, ptr }, ptr %t1005
  %t1008 = extractvalue { i64, ptr } %t1006, 1
  %t1009 = extractvalue { i64, ptr } %t1006, 0
  %t1010 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t1008, i64 %t1009, i8 34)
  %t1011 = call ptr @__olang_sb_room(ptr %s21, i64 %t1010)
  %t1012 = call i64 @__olang_rd_quote(ptr %t1011, i64 0, ptr %t1008, i64 %t1009, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t1010)
  %t1013 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t1014 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1013, i64 %t1014)
  br label %bb149
bb159:
  %t1015 = load i32, ptr %l284, !tbaa !23
  %t1016 = icmp eq i32 %t1015, 65540
  br i1 %t1016, label %bb160, label %bb161
bb160:
  %t1018 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t1019 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1018, i64 %t1019)
  %t1020 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t1021 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1020, i64 %t1021)
  %t1022 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l283, i32 0, i32 1
  %t1023 = getelementptr { i64, [2 x i64] }, ptr %t1022, i32 0, i32 1
  %t1024 = getelementptr { { i64, ptr } }, ptr %t1023, i32 0, i32 0
  %t1025 = load { i64, ptr }, ptr %t1024
  %t1027 = extractvalue { i64, ptr } %t1025, 1
  %t1028 = extractvalue { i64, ptr } %t1025, 0
  %t1029 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t1027, i64 %t1028, i8 34)
  %t1030 = call ptr @__olang_sb_room(ptr %s21, i64 %t1029)
  %t1031 = call i64 @__olang_rd_quote(ptr %t1030, i64 0, ptr %t1027, i64 %t1028, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t1029)
  %t1032 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t1033 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1032, i64 %t1033)
  br label %bb149
bb161:
  %t1034 = load i32, ptr %l284, !tbaa !23
  %t1035 = icmp eq i32 %t1034, 65541
  br i1 %t1035, label %bb162, label %bb163
bb162:
  %t1037 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t1038 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1037, i64 %t1038)
  %t1039 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t1040 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1039, i64 %t1040)
  %t1041 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l283, i32 0, i32 1
  %t1042 = getelementptr { i64, [2 x i64] }, ptr %t1041, i32 0, i32 1
  %t1043 = getelementptr { { i64, ptr } }, ptr %t1042, i32 0, i32 0
  %t1044 = load { i64, ptr }, ptr %t1043
  %t1046 = extractvalue { i64, ptr } %t1044, 1
  %t1047 = extractvalue { i64, ptr } %t1044, 0
  %t1048 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t1046, i64 %t1047, i8 34)
  %t1049 = call ptr @__olang_sb_room(ptr %s21, i64 %t1048)
  %t1050 = call i64 @__olang_rd_quote(ptr %t1049, i64 0, ptr %t1046, i64 %t1047, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t1048)
  %t1051 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t1052 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1051, i64 %t1052)
  br label %bb149
bb163:
  %t1053 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t1054 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1053, i64 %t1054)
  %t1055 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t1056 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1055, i64 %t1056)
  %t1057 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l283, i32 0, i32 1
  %t1058 = getelementptr { i64, [2 x i64] }, ptr %t1057, i32 0, i32 1
  %t1059 = getelementptr { { i64, ptr } }, ptr %t1058, i32 0, i32 0
  %t1060 = load { i64, ptr }, ptr %t1059
  %t1062 = extractvalue { i64, ptr } %t1060, 1
  %t1063 = extractvalue { i64, ptr } %t1060, 0
  %t1064 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t1062, i64 %t1063, i8 34)
  %t1065 = call ptr @__olang_sb_room(ptr %s21, i64 %t1064)
  %t1066 = call i64 @__olang_rd_quote(ptr %t1065, i64 0, ptr %t1062, i64 %t1063, i8 34)
  call void @__olang_sb_add(ptr %s21, i64 %t1064)
  %t1067 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t1068 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t1067, i64 %t1068)
  br label %bb149
bb164:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t1069 = load i32, ptr %l301, !tbaa !23
  store i32 %t1069, ptr %rv
  br label %ret
bb165:
  %t1070 = load i1, ptr %l11, !tbaa !21
  br i1 %t1070, label %bb166, label %bb167
bb166:
  store i32 1, ptr %l303, !tbaa !23
  br label %bb168
bb167:
  store i32 0, ptr %l303, !tbaa !23
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s0)
  %t1072 = load i32, ptr %l303, !tbaa !23
  store i32 %t1072, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/json:Object" @compiler_2fnotebook_2eempty(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/json:Object"
  %l2 = alloca %"std/json:Object"
  %l3 = alloca i32
  %rv = alloca %"std/json:Object"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = mul i64 0, 8
  %t2 = insertvalue { i64, ptr } undef, i64 0, 0
  %t3 = insertvalue { i64, ptr } %t2, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t5 = call { i32, %"std/json:Object" } @std_2fjson_3aObject_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x { i64, ptr }] }>, ptr @.d54, i32 0, i32 1) }, { i64, ptr } %t3)
  %t6 = extractvalue { i32, %"std/json:Object" } %t5, 1
  %t7 = extractvalue { i32, %"std/json:Object" } %t5, 0
  store i32 %t7, ptr %l3
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store %"std/json:Object" %t6, ptr %l2
  br label %bb1
bb1:
  %t10 = load %"std/json:Object", ptr %l2
  store %"std/json:Object" %t10, ptr %l0
  br label %bb6
bb2:
  %t11 = load i32, ptr %l3, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_check_failed(ptr @olang_loc_45976cf57d825baf_761c405890d45b73)
  unreachable
bb6:
  %t16 = load %"std/json:Object", ptr %l0
  store %"std/json:Object" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"std/json:Object", ptr %rv
  ret %"std/json:Object" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fnotebook_2eexecute(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca %"compiler/jupyter:Capture"
  %l4 = alloca %"compiler/jupyter:Capture"
  %l5 = alloca %"compiler/prompt:Reply"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca %"compiler/jupyter:Capture"
  %l18 = alloca %"compiler/jupyter:Capture"
  %l24 = alloca %"compiler/prompt:Reply"
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l47 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l69 = alloca i1
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"std/prelude/text:LineIter"
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i64
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i64
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l102 = alloca i64
  %l105 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca i32
  %l111 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t23 = alloca %"compiler/prompt:Reply", align 8
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/jupyter:Capture" @compiler_2fjupyter_3aCapture_2ector(ptr %s0, i32 1)
  store %"compiler/jupyter:Capture" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = load %"compiler/jupyter:Capture", ptr %l17
  store %"compiler/jupyter:Capture" %t2, ptr %l3
  %t3 = call %"compiler/jupyter:Capture" @compiler_2fjupyter_3aCapture_2ector(ptr %s0, i32 2)
  store %"compiler/jupyter:Capture" %t3, ptr %l18
  br label %bb2
bb2:
  %t4 = load %"compiler/jupyter:Capture", ptr %l18
  store %"compiler/jupyter:Capture" %t4, ptr %l4
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t11 = call i64 @__olang_fmt_i64(ptr null, i64 %t7)
  %t12 = add i64 %t9, %t11
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t8, i64 %t9)
  %t17 = getelementptr i8, ptr %t16, i64 %t9
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t7)
  %t19 = getelementptr i8, ptr %t17, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eCell(ptr %t23, ptr %v0, ptr %v1, ptr %s0, ptr %v0, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t23, i64 144, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l24, i64 144, i1 false)
  %t28 = call { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3aCapture_2eEnd(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t28, ptr %l26
  br label %bb4
bb4:
  %t29 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t31 = call { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3aCapture_2eEnd(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t31, ptr %l28
  br label %bb5
bb5:
  %t32 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t32, ptr %l7, !tbaa !27
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l29
  br label %bb6
bb6:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l8
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t37, ptr %l31
  br label %bb7
bb7:
  %t38 = load i1, ptr %l31, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  store ptr %l8, ptr %l33, !tbaa !29
  %t41 = call ptr @__olang_scope_hold(ptr %s0)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l34, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t43, label %bb10, label %bb11
bb9:
  br label %bb14
bb10:
  %t45 = call ptr @__olang_region_make(ptr %s0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = load i64, ptr %l34
  %t49 = inttoptr i64 %t48 to ptr
  %t51 = call { i64, ptr } @compiler_2fnotebook_2estream(ptr %s2, ptr %s0, ptr %t49, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d58, i32 0, i32 1) }, { i64, ptr } %t47)
  store { i64, ptr } %t51, ptr %l37
  br label %bb12
bb12:
  %t52 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t53 = load ptr, ptr %l33, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t53, { i64, ptr } %t52)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t55 = getelementptr %"compiler/prompt:Reply", ptr %l5, i32 0, i32 0
  %t56 = load i1, ptr %t55, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t58 = getelementptr %"compiler/prompt:Reply", ptr %l5, i32 0, i32 1
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb17
bb17:
  %t61 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t64 = getelementptr %"compiler/prompt:Reply", ptr %l5, i32 0, i32 5
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t62, 1
  %t68 = extractvalue { i64, ptr } %t62, 0
  %t70 = extractvalue { i64, ptr } %t61, 1
  %t71 = extractvalue { i64, ptr } %t61, 0
  %t72 = add i64 %t68, %t71
  %t74 = extractvalue { i64, ptr } %t65, 1
  %t75 = extractvalue { i64, ptr } %t65, 0
  %t76 = add i64 %t72, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t67, i64 %t68)
  %t78 = getelementptr i8, ptr %t77, i64 %t68
  call void @olang_textcopy(ptr %t78, ptr %t70, i64 %t71)
  %t79 = getelementptr i8, ptr %t78, i64 %t71
  call void @olang_textcopy(ptr %t79, ptr %t74, i64 %t75)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t77, 1
  store { i64, ptr } %t81, ptr %l10, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t83, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t85, ptr %l47
  br label %bb18
bb18:
  %t86 = load i1, ptr %l47, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l8, ptr %l49, !tbaa !29
  %t89 = call ptr @__olang_scope_hold(ptr %s0)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l50, !tbaa !24
  %t91 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t91, label %bb21, label %bb22
bb20:
  br label %bb25
bb21:
  %t93 = call ptr @__olang_region_make(ptr %s0)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l50, !tbaa !24
  br label %bb22
bb22:
  %t95 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t96 = load i64, ptr %l50
  %t97 = inttoptr i64 %t96 to ptr
  %t99 = call { i64, ptr } @compiler_2fnotebook_2estream(ptr %s4, ptr %s0, ptr %t97, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, { i64, ptr } %t95)
  store { i64, ptr } %t99, ptr %l53
  br label %bb23
bb23:
  %t100 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t101 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t101, { i64, ptr } %t100)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t103 = getelementptr %"compiler/prompt:Reply", ptr %l5, i32 0, i32 2
  %t104 = load i1, ptr %t103, !tbaa !21
  br i1 %t104, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l8, ptr %l56, !tbaa !29
  %t106 = call ptr @__olang_scope_hold(ptr %s0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l57, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t108, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  %t110 = call ptr @__olang_region_make(ptr %s0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l57, !tbaa !24
  br label %bb29
bb29:
  %t113 = call { i64, ptr } @compiler_2fjupyter_2eData(ptr %v0, ptr %s5, ptr %l5)
  store { i64, ptr } %t113, ptr %l60
  br label %bb30
bb30:
  %t114 = load i64, ptr %l2, !tbaa !24
  %t115 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t117 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = add i64 %t116, %t119
  %t121 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t125 = call i64 @__olang_fmt_i64(ptr null, i64 %t114)
  %t126 = add i64 %t123, %t125
  %t127 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = load i64, ptr %l57
  %t131 = inttoptr i64 %t130 to ptr
  %t132 = call ptr @__olang_held_alloc(ptr %t131, i64 %t129)
  call void @olang_textcopy(ptr %t132, ptr %t115, i64 %t116)
  %t133 = getelementptr i8, ptr %t132, i64 %t116
  call void @olang_textcopy(ptr %t133, ptr %t118, i64 %t119)
  %t134 = getelementptr i8, ptr %t133, i64 %t119
  call void @olang_textcopy(ptr %t134, ptr %t121, i64 %t122)
  %t135 = getelementptr i8, ptr %t134, i64 %t122
  %t136 = call i64 @__olang_fmt_i64(ptr %t135, i64 %t114)
  %t137 = getelementptr i8, ptr %t135, i64 %t125
  call void @olang_textcopy(ptr %t137, ptr %t127, i64 %t128)
  %t138 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t132, 1
  %t141 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t141, { i64, ptr } %t139)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t143 = getelementptr %"compiler/prompt:Reply", ptr %l5, i32 0, i32 0
  %t144 = load i1, ptr %t143, !tbaa !21
  br i1 %t144, label %bb33, label %bb34
bb33:
  %t146 = getelementptr %"compiler/prompt:Reply", ptr %l5, i32 0, i32 4
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l65, !tbaa !27
  br label %bb35
bb34:
  %t149 = getelementptr %"compiler/prompt:Reply", ptr %l5, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l65, !tbaa !27
  br label %bb35
bb35:
  %t152 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t152, ptr %l11, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t155 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t153, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t155, ptr %l69
  br label %bb36
bb36:
  %t156 = load i1, ptr %l69, !tbaa !21
  %t157 = xor i1 %t156, true
  br i1 %t157, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t159 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l71
  br label %bb39
bb38:
  br label %bb62
bb39:
  %t160 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %l12
  %t161 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t163 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v0, { i64, ptr } %t161)
  store { i64, ptr } %t163, ptr %l73
  br label %bb40
bb40:
  %t164 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t165 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t164)
  store %"std/prelude/text:LineIter" %t165, ptr %l74
  br label %bb41
bb41:
  %t166 = load %"std/prelude/text:LineIter", ptr %l74
  store %"std/prelude/text:LineIter" %t166, ptr %l13
  br label %bb42
bb42:
  %t168 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l13)
  %t169 = extractvalue { i32, { i64, ptr } } %t168, 1
  %t170 = extractvalue { i32, { i64, ptr } } %t168, 0
  store i32 %t170, ptr %l78
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb44, label %ok.172, !prof !99
ok.172:
  store { i64, ptr } %t169, ptr %l77
  br label %bb43
bb43:
  %t173 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t173, ptr %l75, !tbaa !27
  br label %bb46
bb44:
  %t174 = load i32, ptr %l78, !tbaa !23
  %t175 = ashr i32 %t174, 16
  %t177 = icmp eq i32 %t175, 1
  store i1 %t177, ptr %l80, !tbaa !21
  br label %bb45
bb45:
  br label %bb52
bb46:
  %t178 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t178, ptr %l14, !tbaa !27
  store ptr %l12, ptr %l81, !tbaa !29
  %t179 = call ptr @__olang_scope_hold(ptr %s7)
  %t180 = ptrtoint ptr %t179 to i64
  store i64 %t180, ptr %l82, !tbaa !24
  %t181 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t181, label %bb47, label %bb48
bb47:
  %t183 = call ptr @__olang_region_make(ptr %s7)
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l82, !tbaa !24
  br label %bb48
bb48:
  %t185 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t186 = load i64, ptr %l82
  %t187 = inttoptr i64 %t186 to ptr
  %t189 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v0, ptr %t187, { i64, ptr } %t185)
  store { i64, ptr } %t189, ptr %l85
  br label %bb49
bb49:
  %t190 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t191 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s7, ptr %s7, ptr %t191, { i64, ptr } %t190)
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb42
bb52:
  %t193 = getelementptr %"compiler/prompt:Reply", ptr %l5, i32 0, i32 0
  %t194 = load i1, ptr %t193, !tbaa !21
  br i1 %t194, label %bb53, label %bb54
bb53:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l88, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l88, !tbaa !27
  br label %bb55
bb55:
  %t196 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t196, ptr %l15, !tbaa !27
  store ptr %l8, ptr %l89, !tbaa !29
  %t197 = call ptr @__olang_scope_hold(ptr %s0)
  %t198 = ptrtoint ptr %t197 to i64
  store i64 %t198, ptr %l90, !tbaa !24
  %t199 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t199, label %bb56, label %bb57
bb56:
  %t201 = call ptr @__olang_region_make(ptr %s0)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l90, !tbaa !24
  br label %bb57
bb57:
  %t203 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t203, ptr %l92, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t206 = call { i64, ptr } @compiler_2fjupyter_2eFirstLine(ptr %v0, ptr %s7, { i64, ptr } %t204)
  store { i64, ptr } %t206, ptr %l94
  br label %bb58
bb58:
  %t207 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t209 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %s7, ptr %s7, { i64, ptr } %t207)
  store { i64, ptr } %t209, ptr %l96
  br label %bb59
bb59:
  %t211 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s7, ptr %s7, ptr %s7, ptr %l12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store { i64, ptr } %t211, ptr %l98
  br label %bb60
bb60:
  %t212 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t214 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = add i64 %t213, %t216
  %t218 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t221 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = add i64 %t227, %t230
  %t232 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t234 = add i64 %t231, %t233
  %t235 = load i64, ptr %l90
  %t236 = inttoptr i64 %t235 to ptr
  %t237 = call ptr @__olang_held_alloc(ptr %t236, i64 %t234)
  call void @olang_textcopy(ptr %t237, ptr %t212, i64 %t213)
  %t238 = getelementptr i8, ptr %t237, i64 %t213
  call void @olang_textcopy(ptr %t238, ptr %t215, i64 %t216)
  %t239 = getelementptr i8, ptr %t238, i64 %t216
  call void @olang_textcopy(ptr %t239, ptr %t218, i64 %t219)
  %t240 = getelementptr i8, ptr %t239, i64 %t219
  call void @olang_textcopy(ptr %t240, ptr %t222, i64 %t223)
  %t241 = getelementptr i8, ptr %t240, i64 %t223
  call void @olang_textcopy(ptr %t241, ptr %t225, i64 %t226)
  %t242 = getelementptr i8, ptr %t241, i64 %t226
  call void @olang_textcopy(ptr %t242, ptr %t229, i64 %t230)
  %t243 = getelementptr i8, ptr %t242, i64 %t230
  call void @olang_textcopy(ptr %t243, ptr %t232, i64 %t233)
  %t244 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t237, 1
  %t247 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t247, { i64, ptr } %t245)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  br label %bb62
bb62:
  %t249 = call ptr @__olang_scope_hold(ptr %v2)
  %t250 = ptrtoint ptr %t249 to i64
  store i64 %t250, ptr %l102, !tbaa !24
  %t251 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e0
  br i1 %t251, label %bb63, label %bb64
bb63:
  %t253 = call ptr @__olang_region_make(ptr %v2)
  %t254 = ptrtoint ptr %t253 to i64
  store i64 %t254, ptr %l102, !tbaa !24
  br label %bb64
bb64:
  %t256 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l8, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store { i64, ptr } %t256, ptr %l105
  br label %bb65
bb65:
  %t257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t259 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = add i64 %t258, %t261
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t266 = load i64, ptr %l102
  %t267 = inttoptr i64 %t266 to ptr
  %t268 = call ptr @__olang_held_alloc(ptr %t267, i64 %t265)
  call void @olang_textcopy(ptr %t268, ptr %t257, i64 %t258)
  %t269 = getelementptr i8, ptr %t268, i64 %t258
  call void @olang_textcopy(ptr %t269, ptr %t260, i64 %t261)
  %t270 = getelementptr i8, ptr %t269, i64 %t261
  call void @olang_textcopy(ptr %t270, ptr %t263, i64 %t264)
  %t271 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t268, 1
  %t275 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v2, ptr %v2, { i64, ptr } %t272)
  %t276 = extractvalue { i32, ptr } %t275, 1
  %t277 = extractvalue { i32, ptr } %t275, 0
  store i32 %t277, ptr %l109
  %t278 = icmp ne i32 %t277, 0
  br i1 %t278, label %bb67, label %ok.279, !prof !99
ok.279:
  store ptr %t276, ptr %l108
  br label %bb66
bb66:
  %t280 = load ptr, ptr %l108, !tbaa !29
  store ptr %t280, ptr %l101, !tbaa !29
  br label %bb71
bb67:
  %t281 = load i32, ptr %l109, !tbaa !23
  %t282 = ashr i32 %t281, 16
  %t284 = icmp eq i32 %t282, 1
  store i1 %t284, ptr %l111, !tbaa !21
  %t285 = load i32, ptr %l109, !tbaa !23
  %t286 = ashr i32 %t285, 16
  %t288 = icmp eq i32 %t286, 1
  br i1 %t288, label %bb68, label %bb69
bb68:
  call void @__olang_errpay_pop()
  br label %bb69
bb69:
  br label %bb70
bb70:
  call void @__olang_check_failed(ptr @olang_loc_f3b5c17d9f2e0c51_2c0777e4fd110125)
  unreachable
bb71:
  %t290 = load ptr, ptr %l101, !tbaa !29
  %t293 = load { i64, [2 x i64] }, ptr %t290
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t293, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i32 @compiler_2fnotebook_2efail(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l3 = alloca i32
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = call i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t15)
  store i32 %t17, ptr %l3
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb2, label %ok.19, !prof !99
ok.19:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t20 = load i32, ptr %l3, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l5, !tbaa !21
  %t24 = load i32, ptr %l3, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fnotebook_2efailedWith(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v0, ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l1, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t26, ptr %l15, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = sub i64 %t29, 1
  %t33 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = call { i64, ptr } @compiler_2fnotebook_2estr(ptr %v0, ptr %s0, ptr %s0, ptr %t36, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store { i64, ptr } %t38, ptr %l20
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t40, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t47, ptr %l23
  br label %bb10
bb10:
  %t48 = load i1, ptr %l23, !tbaa !21
  store i1 %t48, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i1, ptr %l14, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fnotebook_2ejoined(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l30 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v0, ptr %v0, ptr %a0)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb4
bb3:
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t23, 0
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb4:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %l1, ptr %l20, !tbaa !29
  %t44 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v0, ptr %t40)
  %t45 = extractvalue { i32, { i64, ptr } } %t44, 1
  %t46 = extractvalue { i32, { i64, ptr } } %t44, 0
  store i32 %t46, ptr %l24
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb9, label %ok.48, !prof !99
ok.48:
  store { i64, ptr } %t45, ptr %l23
  br label %bb8
bb8:
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t49, ptr %l21, !tbaa !27
  br label %bb10
bb9:
  %t50 = load i32, ptr %l24, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t58, 0
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb10:
  %t61 = load ptr, ptr %l20, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t61, { i64, ptr } %t62)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t63, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  br label %bb14
bb14:
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t69, ptr %l30
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t71 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t70, 1
  store { i32, { i64, ptr } } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"std/json:Object" @compiler_2fnotebook_2ekernelspec(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca i1
  %l15 = alloca %"std/json:Object"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/json:Object"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @std_2fjson_2estd_2fjson_3aObject_2eHas(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = load %"std/json:Object", ptr %t5
  call void @__olang_scope_close(ptr %s0)
  store %"std/json:Object" %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v1, ptr %v1, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d81, i32 0, i32 1) })
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l8
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13, !prof !99
ok.13:
  store ptr %t10, ptr %l7
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l7, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  br label %bb10
bb6:
  %t15 = load i32, ptr %l8, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  store i1 %t18, ptr %l10, !tbaa !21
  %t19 = load i32, ptr %l8, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  br label %bb9
bb9:
  call void @__olang_check_failed(ptr @olang_loc_42c129d2d0d54abe_dd260ad4d97e6f8a)
  unreachable
bb10:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t29 = call %"std/json:Object" @compiler_2fnotebook_2eset(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t25, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %t24)
  store %"std/json:Object" %t29, ptr %l15
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load %"std/json:Object", ptr %l15
  store %"std/json:Object" %t30, ptr %rv
  br label %ret
ret:
  %rr = load %"std/json:Object", ptr %rv
  ret %"std/json:Object" %rr
}

define dso_local { i64, ptr } @compiler_2fnotebook_2esource(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i1
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l35 = alloca i1
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t20 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v0, ptr %a0, { i64, ptr } %t2)
  %t6 = extractvalue { i32, ptr } %t5, 1
  %t7 = extractvalue { i32, ptr } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store ptr %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  br label %bb6
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l9, !tbaa !21
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 0, ptr %t21
  %t22 = load { i64, [2 x i64] }, ptr %t20
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t22, ptr %t24
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l2, !tbaa !29
  store ptr %t26, ptr %l1, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l14, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t36, ptr %l19, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l20, !tbaa !24
  %t39 = load i64, ptr %l20, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l21, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l20, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t50, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %s0, ptr %t52)
  %t55 = extractvalue { i32, { i64, ptr } } %t54, 1
  %t56 = extractvalue { i32, { i64, ptr } } %t54, 0
  store i32 %t56, ptr %l25
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb13, label %ok.58, !prof !99
ok.58:
  store { i64, ptr } %t55, ptr %l24
  br label %bb12
bb12:
  %t59 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t59, ptr %l22, !tbaa !27
  br label %bb23
bb13:
  %t60 = load i32, ptr %l25, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  store i1 %t63, ptr %l27, !tbaa !21
  %t64 = load i32, ptr %l25, !tbaa !23
  %t65 = ashr i32 %t64, 16
  %t67 = icmp eq i32 %t65, 1
  br i1 %t67, label %bb14, label %bb15
bb14:
  call void @__olang_errpay_pop()
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call { i32, { i64, ptr } } @compiler_2fnotebook_2ejoined(ptr %v0, ptr %s0, ptr %t69)
  %t72 = extractvalue { i32, { i64, ptr } } %t71, 1
  %t73 = extractvalue { i32, { i64, ptr } } %t71, 0
  store i32 %t73, ptr %l33
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb18, label %ok.75, !prof !99
ok.75:
  store { i64, ptr } %t72, ptr %l32
  br label %bb17
bb17:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %l30, !tbaa !27
  br label %bb22
bb18:
  %t77 = load i32, ptr %l33, !tbaa !23
  %t78 = ashr i32 %t77, 16
  %t80 = icmp eq i32 %t78, 1
  store i1 %t80, ptr %l35, !tbaa !21
  %t81 = load i32, ptr %l33, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  br i1 %t84, label %bb19, label %bb20
bb19:
  call void @__olang_errpay_pop()
  br label %bb20
bb20:
  br label %bb21
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t86, ptr %l30, !tbaa !27
  br label %bb22
bb22:
  %t88 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t89, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l22, !tbaa !27
  br label %bb23
bb23:
  %t96 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t97, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t101, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fnotebook_2estream(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l35 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l47 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t29 = icmp ne i8 %t25, 10
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb19
bb7:
  br label %bb8
bb8:
  store ptr %l2, ptr %l23, !tbaa !29
  %t31 = call ptr @__olang_scope_hold(ptr %s0)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = call ptr @__olang_region_make(ptr %s0)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t37, ptr %l26, !tbaa !27
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l29, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load i64, ptr %l27, !tbaa !24
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_6bfe6c2298b565fb_3c4e4846256475e7)
  unreachable
bb13:
  %t51 = load i64, ptr %l29, !tbaa !24
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6bfe6c2298b565fb_3c4e4846256475e7)
  unreachable
bb15:
  %t55 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l27, !tbaa !24
  %t58 = load i64, ptr %l29, !tbaa !24
  %t59 = getelementptr i8, ptr %t56, i64 %t57
  %t60 = sub i64 %t58, %t57
  %t61 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t63 = load i64, ptr %l24
  %t64 = inttoptr i64 %t63 to ptr
  %t66 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v1, ptr %t64, { i64, ptr } %t62)
  store { i64, ptr } %t66, ptr %l35
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6bfe6c2298b565fb_3c4e4846256475e7)
  unreachable
bb17:
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = load ptr, ptr %l23, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t68, { i64, ptr } %t67)
  br label %bb18
bb18:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l3, !tbaa !24
  br label %bb19
bb19:
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l5, !tbaa !24
  br label %bb2
bb20:
  %t79 = load i64, ptr %l3, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t85 = icmp slt i64 %t79, %t82
  br i1 %t85, label %bb21, label %bb22
bb21:
  store ptr %l2, ptr %l46, !tbaa !29
  %t87 = call ptr @__olang_scope_hold(ptr %s0)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l47, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t89, label %bb23, label %bb24
bb22:
  br label %bb33
bb23:
  %t91 = call ptr @__olang_region_make(ptr %s0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l47, !tbaa !24
  br label %bb24
bb24:
  %t93 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t93, ptr %l49, !tbaa !27
  %t94 = load i64, ptr %l3, !tbaa !24
  store i64 %t94, ptr %l50, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t95, 0
  store i64 %t98, ptr %l53, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l54, !tbaa !24
  %t101 = load i64, ptr %l50, !tbaa !24
  %t102 = icmp sge i64 %t101, 0
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t104 = load i64, ptr %l50, !tbaa !24
  %t105 = load i64, ptr %l53, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c6df15e3ea9ee37e_5c1ebfad1a40e30a)
  unreachable
bb27:
  %t108 = load i64, ptr %l53, !tbaa !24
  %t109 = load i64, ptr %l54, !tbaa !24
  %t110 = icmp sle i64 %t108, %t109
  br i1 %t110, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_c6df15e3ea9ee37e_5c1ebfad1a40e30a)
  unreachable
bb29:
  %t112 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l50, !tbaa !24
  %t115 = load i64, ptr %l53, !tbaa !24
  %t116 = getelementptr i8, ptr %t113, i64 %t114
  %t117 = sub i64 %t115, %t114
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  %t120 = load i64, ptr %l47
  %t121 = inttoptr i64 %t120 to ptr
  %t123 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v1, ptr %t121, { i64, ptr } %t119)
  store { i64, ptr } %t123, ptr %l59
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_c6df15e3ea9ee37e_5c1ebfad1a40e30a)
  unreachable
bb31:
  %t124 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t125 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t125, { i64, ptr } %t124)
  br label %bb32
bb32:
  br label %bb33
bb33:
  store { i64, ptr } %a0, ptr %l61, !tbaa !27
  %t129 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store { i64, ptr } %t129, ptr %l63
  br label %bb34
bb34:
  %t130 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t132 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = add i64 %t131, %t134
  %t136 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t130, i64 %t131)
  %t147 = getelementptr i8, ptr %t146, i64 %t131
  call void @olang_textcopy(ptr %t147, ptr %t133, i64 %t134)
  %t148 = getelementptr i8, ptr %t147, i64 %t134
  call void @olang_textcopy(ptr %t148, ptr %t136, i64 %t137)
  %t149 = getelementptr i8, ptr %t148, i64 %t137
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t143, i64 %t144)
  %t151 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t146, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t152, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fnotebook_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca i1
  %l18 = alloca %"std/json:Object"
  %l21 = alloca %"std/json:Object"
  %rv = alloca { i64, [2 x i64] }
  %t38 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAsObj(ptr %v0, ptr %v4, ptr %t1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  br label %bb6
bb2:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l10, !tbaa !21
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t20, ptr %rv
  br label %ret
bb6:
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t29 = call %"std/json:Object" @compiler_2fnotebook_2eset(ptr %v4, ptr %v1, ptr %v2, ptr %v4, ptr %t22, { i64, ptr } %a1, ptr %a2)
  store %"std/json:Object" %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load %"std/json:Object", ptr %l18
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store %"std/json:Object" %t30, ptr %t31
  %t35 = call %"std/json:Object" @compiler_2fnotebook_2eset(ptr %v4, ptr %v4, ptr %v3, ptr %v4, ptr %t31, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %a3)
  store %"std/json:Object" %t35, ptr %l21
  br label %bb8
bb8:
  %t36 = load %"std/json:Object", ptr %l21
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store %"std/json:Object" %t36, ptr %t37
  store { i64, [2 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 0
  store i64 7, ptr %t39
  %t41 = insertvalue { ptr } undef, ptr %t37, 0
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  store { ptr } %t41, ptr %t42
  %t43 = load { i64, [2 x i64] }, ptr %t38
  store { i64, [2 x i64] } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare ptr @__olang_errpay_top_get()
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

declare void @__olang_errpay_pop()
@.d0 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"cannot read " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d3 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_rd_quote(ptr, i64, ptr, i64, i8)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d6 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d7 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d8 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d9 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d10 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d11 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fjson_3aError_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d12 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" is no JSON: " }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d14 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"json.Error.Unexpected" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d18 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"json.Error.Unterminated" }>, align 8
@.d19 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.BadEscape" }>, align 8
@.d20 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.BadNumber" }>, align 8
@.d21 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"json.Error.BadUtf8" }>, align 8
@.d22 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"json.Error.Trailing" }>, align 8
@.d23 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"json.Error.Depth" }>, align 8
@.d24 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"json.Error.Missing" }>, align 8
@.d25 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.WrongKind" }>, align 8
@.d26 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"json.Error.Uneven" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"cells" }>, align 8
@.d28 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" is no notebook: it has no cells" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d29 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"cell_type" }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d31 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"outputs" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"outputs" }>, align 8
@.d34 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"outputs" }>, align 8
@.d35 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is no notebook" }>, align 8
@.d36 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"cells" }>, align 8
@.d37 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"metadata" }>, align 8
@.d38 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"metadata" }>, align 8
@olang_2esole_2estd_2fjson_3aObject_2e0 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2estd_2fjson_3aObject_2e2 = weak hidden constant i1 false
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@.d42 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"cannot write " }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d45 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d48 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d49 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d50 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d51 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d52 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d53 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d54 = private constant <{ i64, [0 x { i64, ptr }] }> <{ i64 0, [0 x { i64, ptr }] [] }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"In[" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d58 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stdout" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stderr" }>, align 8
@.d62 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"{\22output_type\22:\22execute_result\22,\22data\22:" }>, align 8
@.d63 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c",\22execution_count\22:" }>, align 8
@.d64 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c",\22metadata\22:{}}" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"RuntimeError" }>, align 8
@.d67 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"CompileError" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d69 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"{\22output_type\22:\22error\22,\22ename\22:\22" }>, align 8
@.d70 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\22,\22evalue\22:" }>, align 8
@.d71 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c",\22traceback\22:[" }>, align 8
@.d72 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@olang_2esole_2estd_2fjson_3areader_2e0 = weak hidden constant i1 false
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d76 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d78 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"output_type" }>, align 8
@.d79 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d80 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"kernelspec" }>, align 8
@.d81 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"{\22display_name\22:\22olang\22,\22language\22:\22olang\22,\22name\22:\22olang\22}" }>, align 8
@.d82 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"kernelspec" }>, align 8
@.d83 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"source" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d87 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"{\22output_type\22:\22stream\22,\22name\22:\22" }>, align 8
@.d88 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22,\22text\22:[" }>, align 8
@.d89 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d90 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"execution_count" }>, align 8
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 7}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
bb4:
  %t44 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, ptr } }, ptr %t61, i32 0, i32 0
  store { i64, ptr } %t60, ptr %t62
  br label %bb1
bb5:
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { { i64, ptr } }, ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81
  br label %bb1
bb6:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l17, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, ptr } }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100
  br label %bb1
bb7:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l18, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l19, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l20, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, ptr } }, ptr %t118, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t119
  br label %bb1
bb8:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { { i64, ptr } }, ptr %t120, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l21, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l22, !tbaa !24
  %t125 = load i64, ptr %l22, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l23, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l22, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t137 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t138
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 10}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  br label %bb1
bb3:
  br label %bb1
bb4:
  br label %bb1
bb5:
  br label %bb1
bb6:
  br label %bb1
bb7:
  br label %bb1
bb8:
  br label %bb1
bb9:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fprompt_3aSession_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fnotebook_2estr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2ePush_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eEnd(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAsObj(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fjson_3aJson_26_3e_2eToArray_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/json:Object" @compiler_2fnotebook_2eset(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_3e(ptr %v0, ptr %v1, ptr %v2, { i64, [2 x i64] } %a0, { i64, ptr } %a1, i32 %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/json:Object" } @std_2fjson_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_45976cf57d825baf_761c405890d45b73 = external constant [0 x i8]
declare %"compiler/jupyter:Capture" @compiler_2fjupyter_3aCapture_2ector(ptr %v0, i32 %a0)
declare void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eCell(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3aCapture_2eEnd(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fjupyter_2eData(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fjupyter_2eFirstLine(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_f3b5c17d9f2e0c51_2c0777e4fd110125 = external constant [0 x i8]
declare i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fjson_2estd_2fjson_3aObject_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_42c129d2d0d54abe_dd260ad4d97e6f8a = external constant [0 x i8]
@olang_loc_6bfe6c2298b565fb_3c4e4846256475e7 = external constant [0 x i8]
@olang_loc_c6df15e3ea9ee37e_5c1ebfad1a40e30a = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
