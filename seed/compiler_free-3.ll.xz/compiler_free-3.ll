; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/free:feed" = type { i64, i64, i64, i64, { i64, [2 x i64] }, { i64, [2 x i64] }, i64 }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/mir:GenInfo", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Span" = type { i32, i32 }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/free:retire" = type { i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFeedCopy(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca i1
  %l22 = alloca %"compiler/free:feed"
  %l25 = alloca i64
  %l29 = alloca %"compiler/free:feed"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 115
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 111
  store ptr %t11, ptr %l10, !tbaa !29
  %t16 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t17, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t18)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l15
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb6, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l14
  br label %bb5
bb5:
  %t24 = load i64, ptr %l14, !tbaa !24
  store i64 %t24, ptr %l8, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t25 = load i64, ptr %l8, !tbaa !24
  store i64 %t25, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:Free", ptr %t30, i32 0, i32 110
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t32, i64 %t33)
  store %"compiler/free:feed" %t36, ptr %l22
  br label %bb11
bb10:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb12
bb11:
  %t37 = getelementptr %"compiler/free:feed", ptr %l22, i32 0, i32 6
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = icmp sge i64 %t38, 0
  store i1 %t40, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l18, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:Free", ptr %t43, i32 0, i32 110
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t45, i64 %t46)
  store %"compiler/free:feed" %t49, ptr %l29
  br label %bb15
bb14:
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb16
bb15:
  %t50 = getelementptr %"compiler/free:feed", ptr %l29, i32 0, i32 3
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l25, !tbaa !24
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i64, ptr %l25, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eGenBufNow(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 60
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eGuard(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb7
bb5:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 22
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l12
  br label %bb6
bb6:
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 22
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t23, i64 %t24)
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l14, !tbaa !21
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l2, !tbaa !24
  %t38 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t34, i64 %t35)
  store i1 %t38, ptr %l23
  br label %bb15
bb15:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb18
bb17:
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eNotSole, !tbaa !24
  store i64 %t40, ptr %l24, !tbaa !24
  br label %bb18
bb18:
  %t42 = load i64, ptr %l24, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 115
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 90
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 90
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l13, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufDecide(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l43 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i64
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca ptr
  %l80 = alloca i1
  %l82 = alloca ptr
  %l86 = alloca i1
  %l95 = alloca i64
  %l99 = alloca i64
  %l102 = alloca i64
  %l123 = alloca i64
  %l126 = alloca i1
  %l130 = alloca i1
  %l134 = alloca i1
  %l135 = alloca i1
  %l139 = alloca ptr
  %l143 = alloca i64
  %l144 = alloca i1
  %l145 = alloca ptr
  %l149 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i1
  %l159 = alloca ptr
  %l163 = alloca i64
  %l168 = alloca i64
  %l172 = alloca i64
  %l175 = alloca i64
  %l196 = alloca i64
  %l200 = alloca i64
  %l203 = alloca i1
  %l207 = alloca i1
  %l211 = alloca i1
  %l212 = alloca i1
  %l213 = alloca ptr
  %l217 = alloca ptr
  %l221 = alloca i64
  %l222 = alloca i1
  %l237 = alloca i64
  %l241 = alloca i64
  %l244 = alloca i64
  %l265 = alloca i64
  %l269 = alloca i64
  %l272 = alloca i1
  %l276 = alloca i1
  %l280 = alloca i1
  %l281 = alloca i1
  %l285 = alloca i1
  %l287 = alloca i1
  %l291 = alloca ptr
  %l299 = alloca ptr
  %l300 = alloca i64
  %l304 = alloca i64
  %l315 = alloca i32
  %l317 = alloca i1
  %l324 = alloca i64
  %l327 = alloca i64
  %l348 = alloca ptr
  %l353 = alloca i1
  %l357 = alloca i1
  %l360 = alloca { i64, ptr }
  %l364 = alloca i64
  %l368 = alloca i1
  %l371 = alloca i32
  %l373 = alloca i1
  %l382 = alloca i64
  %l384 = alloca i64
  %l389 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l393 = alloca i1
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l43
  br label %bb1
bb1:
  %t6 = load i64, ptr %l43, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l51, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l51, !tbaa !24
  store i64 %t35, ptr %l48, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l48, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:Free", ptr %t55, i32 0, i32 56
  store ptr %t57, ptr %l70, !tbaa !29
  %t58 = ptrtoint ptr %v0 to i64
  store i64 %t58, ptr %l71, !tbaa !24
  %t59 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t61 = call ptr @__olang_region_make(ptr %v0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l71, !tbaa !24
  br label %bb13
bb13:
  %t63 = load i64, ptr %l71
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t64, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l73
  br label %bb14
bb14:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  %t67 = load i64, ptr %l71
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_scope_alloc_a(ptr %t68, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t69
  %t70 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t70, ptr %t69)
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:Free", ptr %t72, i32 0, i32 57
  store ptr %t74, ptr %l76, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 37
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t78)
  store i1 %t81, ptr %l80
  br label %bb16
bb16:
  %t82 = load ptr, ptr %l76, !tbaa !29
  %t83 = load i1, ptr %l80, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t82, i1 %t83)
  br label %bb17
bb17:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:Free", ptr %t84, i32 0, i32 58
  store ptr %t86, ptr %l82, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 37
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l86
  br label %bb18
bb18:
  %t94 = load ptr, ptr %l82, !tbaa !29
  %t95 = load i1, ptr %l86, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t94, i1 %t95)
  br label %bb19
bb19:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t98, i64 -1)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb8
bb22:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb23
bb23:
  %t104 = load i1, ptr %l8, !tbaa !21
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb24, label %bb25
bb24:
  br label %bb67
bb25:
  br label %bb26
bb26:
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:Free", ptr %t108, i32 0, i32 49
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t110)
  store i64 %t112, ptr %l95
  br label %bb27
bb27:
  %t113 = load i64, ptr %l95, !tbaa !24
  store i64 %t113, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb33
bb30:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l102, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb32
bb32:
  %t140 = load i64, ptr %l102, !tbaa !24
  store i64 %t140, ptr %l99, !tbaa !24
  br label %bb33
bb33:
  %t141 = load i64, ptr %l99, !tbaa !24
  store i64 %t141, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb34
bb34:
  %t142 = load i64, ptr %l13, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb35, label %bb36
bb35:
  br label %bb65
bb36:
  br label %bb37
bb37:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t151 = load i64, ptr %l13, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l14, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/free:Free", ptr %t160, i32 0, i32 50
  %t163 = load i64, ptr %l14, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l123
  br label %bb38
bb38:
  %t167 = load i64, ptr %l123, !tbaa !24
  store i64 %t167, ptr %l15, !tbaa !24
  %t168 = load i64, ptr %l15, !tbaa !24
  %t170 = icmp slt i64 %t168, 0
  br i1 %t170, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb41
bb40:
  %t172 = load i64, ptr %l15, !tbaa !24
  %t173 = load i64, ptr %l1, !tbaa !24
  %t176 = icmp sge i64 %t172, %t173
  store i1 %t176, ptr %l126, !tbaa !21
  br label %bb41
bb41:
  %t178 = load i1, ptr %l126, !tbaa !21
  br i1 %t178, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb45
bb43:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/free:Free", ptr %t179, i32 0, i32 57
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t181, i64 %t182)
  store i1 %t185, ptr %l134
  br label %bb44
bb44:
  %t186 = load i1, ptr %l134, !tbaa !21
  store i1 %t186, ptr %l130, !tbaa !21
  br label %bb45
bb45:
  %t187 = load i1, ptr %l130, !tbaa !21
  br i1 %t187, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l135, !tbaa !21
  br label %bb51
bb47:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/free:Free", ptr %t188, i32 0, i32 56
  %t191 = load i64, ptr %l15, !tbaa !24
  %t194 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t190, i64 %t191)
  store ptr %t194, ptr %l139
  br label %bb48
bb48:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/free:Free", ptr %t195, i32 0, i32 51
  %t198 = load i64, ptr %l14, !tbaa !24
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t197, i64 %t198)
  store i64 %t201, ptr %l143
  br label %bb49
bb49:
  %t202 = load ptr, ptr %l139, !tbaa !29
  %t203 = load i64, ptr %l143, !tbaa !24
  %t204 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t202, i64 %t203)
  store i1 %t204, ptr %l144
  br label %bb50
bb50:
  %t205 = load i1, ptr %l144, !tbaa !21
  store i1 %t205, ptr %l135, !tbaa !21
  br label %bb51
bb51:
  %t206 = load i1, ptr %l135, !tbaa !21
  br i1 %t206, label %bb52, label %bb53
bb52:
  br label %bb64
bb53:
  br label %bb54
bb54:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l145, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/free:Free", ptr %t208, i32 0, i32 52
  %t211 = load i64, ptr %l14, !tbaa !24
  %t214 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t210, i64 %t211)
  store ptr %t214, ptr %l149
  br label %bb55
bb55:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:Free", ptr %t215, i32 0, i32 49
  %t218 = load i64, ptr %l14, !tbaa !24
  %t221 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t217, i64 %t218)
  store i64 %t221, ptr %l153
  br label %bb56
bb56:
  %t222 = load ptr, ptr %l145, !tbaa !29
  %t223 = load ptr, ptr %l149, !tbaa !29
  %t224 = load i64, ptr %l153, !tbaa !24
  %t225 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviews(ptr %v0, ptr %v0, ptr %t222, ptr %t223, i64 %t224)
  store i1 %t225, ptr %l154
  br label %bb57
bb57:
  %t226 = load i1, ptr %l154, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb58, label %bb59
bb58:
  br label %bb64
bb59:
  br label %bb60
bb60:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/free:Free", ptr %t229, i32 0, i32 56
  %t232 = load i64, ptr %l15, !tbaa !24
  %t235 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t231, i64 %t232)
  store ptr %t235, ptr %l159
  br label %bb61
bb61:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/free:Free", ptr %t236, i32 0, i32 51
  %t239 = load i64, ptr %l14, !tbaa !24
  %t242 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l163
  br label %bb62
bb62:
  %t243 = load ptr, ptr %l159, !tbaa !29
  %t244 = load i64, ptr %l163, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t243, i64 %t244)
  br label %bb63
bb63:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb64
bb64:
  %t245 = load i64, ptr %l13, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l13, !tbaa !24
  br label %bb34
bb65:
  br label %bb66
bb66:
  br label %bb23
bb67:
  store i64 0, ptr %l16, !tbaa !24
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/free:Free", ptr %t249, i32 0, i32 53
  %t253 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t251)
  store i64 %t253, ptr %l168
  br label %bb68
bb68:
  %t254 = load i64, ptr %l168, !tbaa !24
  store i64 %t254, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t255 = load i64, ptr %l17, !tbaa !24
  %t256 = load i64, ptr %l16, !tbaa !24
  %t259 = icmp sgt i64 %t255, %t256
  br i1 %t259, label %bb69, label %bb70
bb69:
  %t261 = load i64, ptr %l18, !tbaa !24
  %t263 = icmp sgt i64 %t261, 0
  br i1 %t263, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb74
bb71:
  %t265 = load i64, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l16, !tbaa !24
  %t269 = sub i64 %t265, %t266
  %t270 = load i64, ptr %l18, !tbaa !24
  %t273 = add i64 %t269, %t270
  %t275 = sub i64 %t273, 1
  %t276 = load i64, ptr %l18, !tbaa !24
  %t279 = sdiv i64 %t275, %t276
  store i64 %t279, ptr %l175, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb73
bb73:
  %t281 = load i64, ptr %l175, !tbaa !24
  store i64 %t281, ptr %l172, !tbaa !24
  br label %bb74
bb74:
  %t282 = load i64, ptr %l172, !tbaa !24
  store i64 %t282, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb75
bb75:
  %t283 = load i64, ptr %l20, !tbaa !24
  %t284 = load i64, ptr %l19, !tbaa !24
  %t287 = icmp slt i64 %t283, %t284
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb76, label %bb77
bb76:
  br label %bb100
bb77:
  br label %bb78
bb78:
  %t291 = load i64, ptr %l16, !tbaa !24
  %t292 = load i64, ptr %l20, !tbaa !24
  %t293 = load i64, ptr %l18, !tbaa !24
  %t296 = mul i64 %t292, %t293
  %t299 = add i64 %t291, %t296
  store i64 %t299, ptr %l21, !tbaa !24
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/free:Free", ptr %t301, i32 0, i32 53
  %t304 = load i64, ptr %l21, !tbaa !24
  %t307 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t303, i64 %t304)
  store i64 %t307, ptr %l196
  br label %bb79
bb79:
  %t308 = load i64, ptr %l196, !tbaa !24
  store i64 %t308, ptr %l22, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/free:Free", ptr %t309, i32 0, i32 30
  %t312 = load i64, ptr %l22, !tbaa !24
  %t315 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t311, i64 %t312)
  store i64 %t315, ptr %l200
  br label %bb80
bb80:
  %t316 = load i64, ptr %l200, !tbaa !24
  store i64 %t316, ptr %l23, !tbaa !24
  %t317 = load i64, ptr %l23, !tbaa !24
  %t319 = icmp slt i64 %t317, 0
  br i1 %t319, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l203, !tbaa !21
  br label %bb83
bb82:
  %t321 = load i64, ptr %l23, !tbaa !24
  %t322 = load i64, ptr %l1, !tbaa !24
  %t325 = icmp sge i64 %t321, %t322
  store i1 %t325, ptr %l203, !tbaa !21
  br label %bb83
bb83:
  %t327 = load i1, ptr %l203, !tbaa !21
  br i1 %t327, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb87
bb85:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/free:Free", ptr %t328, i32 0, i32 58
  %t331 = load i64, ptr %l23, !tbaa !24
  %t334 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t330, i64 %t331)
  store i1 %t334, ptr %l211
  br label %bb86
bb86:
  %t335 = load i1, ptr %l211, !tbaa !21
  store i1 %t335, ptr %l207, !tbaa !21
  br label %bb87
bb87:
  %t336 = load i1, ptr %l207, !tbaa !21
  br i1 %t336, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb93
bb89:
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l213, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/free:Free", ptr %t338, i32 0, i32 54
  %t341 = load i64, ptr %l21, !tbaa !24
  %t344 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t340, i64 %t341)
  store ptr %t344, ptr %l217
  br label %bb90
bb90:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/free:Free", ptr %t345, i32 0, i32 29
  %t348 = load i64, ptr %l22, !tbaa !24
  %t351 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t347, i64 %t348)
  store i64 %t351, ptr %l221
  br label %bb91
bb91:
  %t352 = load ptr, ptr %l213, !tbaa !29
  %t353 = load ptr, ptr %l217, !tbaa !29
  %t354 = load i64, ptr %l221, !tbaa !24
  %t355 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviews(ptr %v0, ptr %v0, ptr %t352, ptr %t353, i64 %t354)
  store i1 %t355, ptr %l222
  br label %bb92
bb92:
  %t356 = load i1, ptr %l222, !tbaa !21
  %t357 = xor i1 %t356, true
  store i1 %t357, ptr %l212, !tbaa !21
  br label %bb93
bb93:
  %t359 = load i1, ptr %l212, !tbaa !21
  br i1 %t359, label %bb94, label %bb95
bb94:
  br label %bb99
bb95:
  br label %bb96
bb96:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/free:Free", ptr %t360, i32 0, i32 58
  %t363 = load i64, ptr %l23, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t362, i64 %t363, i1 true)
  br label %bb97
bb97:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/free:Free", ptr %t366, i32 0, i32 59
  %t369 = load i64, ptr %l23, !tbaa !24
  %t370 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t368, i64 %t369, i64 %t370)
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t374 = load i64, ptr %l20, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l20, !tbaa !24
  br label %bb75
bb100:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb101
bb101:
  %t378 = load i1, ptr %l8, !tbaa !21
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb102, label %bb103
bb102:
  br label %bb142
bb103:
  br label %bb104
bb104:
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l24, !tbaa !24
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/free:Free", ptr %t382, i32 0, i32 29
  %t386 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t384)
  store i64 %t386, ptr %l237
  br label %bb105
bb105:
  %t387 = load i64, ptr %l237, !tbaa !24
  store i64 %t387, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t388 = load i64, ptr %l25, !tbaa !24
  %t389 = load i64, ptr %l24, !tbaa !24
  %t392 = icmp sgt i64 %t388, %t389
  br i1 %t392, label %bb106, label %bb107
bb106:
  %t394 = load i64, ptr %l26, !tbaa !24
  %t396 = icmp sgt i64 %t394, 0
  br i1 %t396, label %bb108, label %bb109
bb107:
  store i64 0, ptr %l241, !tbaa !24
  br label %bb111
bb108:
  %t398 = load i64, ptr %l25, !tbaa !24
  %t399 = load i64, ptr %l24, !tbaa !24
  %t402 = sub i64 %t398, %t399
  %t403 = load i64, ptr %l26, !tbaa !24
  %t406 = add i64 %t402, %t403
  %t408 = sub i64 %t406, 1
  %t409 = load i64, ptr %l26, !tbaa !24
  %t412 = sdiv i64 %t408, %t409
  store i64 %t412, ptr %l244, !tbaa !24
  br label %bb110
bb109:
  store i64 0, ptr %l244, !tbaa !24
  br label %bb110
bb110:
  %t414 = load i64, ptr %l244, !tbaa !24
  store i64 %t414, ptr %l241, !tbaa !24
  br label %bb111
bb111:
  %t415 = load i64, ptr %l241, !tbaa !24
  store i64 %t415, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb112
bb112:
  %t416 = load i64, ptr %l28, !tbaa !24
  %t417 = load i64, ptr %l27, !tbaa !24
  %t420 = icmp slt i64 %t416, %t417
  %t422 = xor i1 %t420, true
  br i1 %t422, label %bb113, label %bb114
bb113:
  br label %bb140
bb114:
  br label %bb115
bb115:
  %t424 = load i64, ptr %l24, !tbaa !24
  %t425 = load i64, ptr %l28, !tbaa !24
  %t426 = load i64, ptr %l26, !tbaa !24
  %t429 = mul i64 %t425, %t426
  %t432 = add i64 %t424, %t429
  store i64 %t432, ptr %l29, !tbaa !24
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/free:Free", ptr %t434, i32 0, i32 29
  %t437 = load i64, ptr %l29, !tbaa !24
  %t440 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t436, i64 %t437)
  store i64 %t440, ptr %l265
  br label %bb116
bb116:
  %t441 = load i64, ptr %l265, !tbaa !24
  store i64 %t441, ptr %l30, !tbaa !24
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/free:Free", ptr %t442, i32 0, i32 30
  %t445 = load i64, ptr %l29, !tbaa !24
  %t448 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t444, i64 %t445)
  store i64 %t448, ptr %l269
  br label %bb117
bb117:
  %t449 = load i64, ptr %l269, !tbaa !24
  store i64 %t449, ptr %l31, !tbaa !24
  %t450 = load i64, ptr %l31, !tbaa !24
  %t452 = icmp slt i64 %t450, 0
  br i1 %t452, label %bb118, label %bb119
bb118:
  store i1 true, ptr %l272, !tbaa !21
  br label %bb120
bb119:
  %t454 = load i64, ptr %l31, !tbaa !24
  %t455 = load i64, ptr %l1, !tbaa !24
  %t458 = icmp sge i64 %t454, %t455
  store i1 %t458, ptr %l272, !tbaa !21
  br label %bb120
bb120:
  %t460 = load i1, ptr %l272, !tbaa !21
  br i1 %t460, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb124
bb122:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/free:Free", ptr %t461, i32 0, i32 58
  %t464 = load i64, ptr %l31, !tbaa !24
  %t467 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t463, i64 %t464)
  store i1 %t467, ptr %l280
  br label %bb123
bb123:
  %t468 = load i1, ptr %l280, !tbaa !21
  store i1 %t468, ptr %l276, !tbaa !21
  br label %bb124
bb124:
  %t469 = load i1, ptr %l276, !tbaa !21
  br i1 %t469, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l281, !tbaa !21
  br label %bb128
bb126:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/free:Free", ptr %t470, i32 0, i32 58
  %t473 = load i64, ptr %l30, !tbaa !24
  %t476 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t472, i64 %t473)
  store i1 %t476, ptr %l285
  br label %bb127
bb127:
  %t477 = load i1, ptr %l285, !tbaa !21
  %t478 = xor i1 %t477, true
  store i1 %t478, ptr %l281, !tbaa !21
  br label %bb128
bb128:
  %t480 = load i1, ptr %l281, !tbaa !21
  br i1 %t480, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l287, !tbaa !21
  br label %bb132
bb130:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/free:Free", ptr %t481, i32 0, i32 1
  %t484 = load i64, ptr %l30, !tbaa !24
  %t487 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t483, i64 %t484)
  store ptr %t487, ptr %l291
  br label %bb131
bb131:
  %t488 = load ptr, ptr %l291, !tbaa !29
  %t490 = getelementptr %"compiler/typed:Body", ptr %t488, i32 0, i32 1
  %t491 = load { i64, [2 x i64] }, ptr %t490
  %t493 = extractvalue { i64, [2 x i64] } %t491, 0
  %t494 = icmp eq i64 %t493, 7
  store i1 %t494, ptr %l287, !tbaa !21
  br label %bb132
bb132:
  %t496 = load i1, ptr %l287, !tbaa !21
  br i1 %t496, label %bb133, label %bb134
bb133:
  br label %bb139
bb134:
  br label %bb135
bb135:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/free:Free", ptr %t497, i32 0, i32 58
  %t500 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t499, i64 %t500, i1 true)
  br label %bb136
bb136:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/free:Free", ptr %t503, i32 0, i32 59
  store ptr %t505, ptr %l299, !tbaa !29
  %t506 = load i64, ptr %l31, !tbaa !24
  store i64 %t506, ptr %l300, !tbaa !24
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/free:Free", ptr %t507, i32 0, i32 59
  %t510 = load i64, ptr %l30, !tbaa !24
  %t513 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t509, i64 %t510)
  store i64 %t513, ptr %l304
  br label %bb137
bb137:
  %t514 = load ptr, ptr %l299, !tbaa !29
  %t515 = load i64, ptr %l300, !tbaa !24
  %t516 = load i64, ptr %l304, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t514, i64 %t515, i64 %t516)
  br label %bb138
bb138:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb139
bb139:
  %t517 = load i64, ptr %l28, !tbaa !24
  %t519 = add i64 %t517, 1
  store i64 %t519, ptr %l28, !tbaa !24
  br label %bb112
bb140:
  br label %bb141
bb141:
  br label %bb101
bb142:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/free:Free", ptr %t521, i32 0, i32 116
  %t524 = load i1, ptr %t523, !tbaa !21
  br i1 %t524, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s19
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/free:Free", ptr %t526, i32 0, i32 47
  %t529 = load i1, ptr %t528, !tbaa !21
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t532 = getelementptr %"compiler/free:Free", ptr %t530, i32 0, i32 48
  %t533 = load { i64, ptr }, ptr %t532, !tbaa !27
  %t534 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t535 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t537 = select i1 %t529, ptr @.c1, ptr @.c2
  %t538 = select i1 %t529, i64 4, i64 5
  %t539 = add i64 %t535, %t538
  %t540 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t541 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t542 = add i64 %t539, %t541
  %t544 = extractvalue { i64, ptr } %t533, 1
  %t545 = extractvalue { i64, ptr } %t533, 0
  %t546 = add i64 %t542, %t545
  %t547 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t548 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t549 = add i64 %t546, %t548
  %t550 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t549)
  call void @olang_textcopy(ptr %t550, ptr %t534, i64 %t535)
  %t551 = getelementptr i8, ptr %t550, i64 %t535
  call void @olang_textcopy(ptr %t551, ptr %t537, i64 %t538)
  %t552 = getelementptr i8, ptr %t551, i64 %t538
  call void @olang_textcopy(ptr %t552, ptr %t540, i64 %t541)
  %t553 = getelementptr i8, ptr %t552, i64 %t541
  call void @olang_textcopy(ptr %t553, ptr %t544, i64 %t545)
  %t554 = getelementptr i8, ptr %t553, i64 %t545
  call void @olang_textcopy(ptr %t554, ptr %t547, i64 %t548)
  %t555 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t550, 1
  %t558 = extractvalue { i64, ptr } %t556, 0
  %t559 = extractvalue { i64, ptr } %t556, 1
  %t560 = mul i64 %t558, 1
  %t561 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t560)
  call void @llvm.memcpy.p0.p0.i64(ptr %t561, ptr %t559, i64 %t560, i1 false)
  %t562 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t563 = insertvalue { i64, ptr } %t562, ptr %t561, 1
  %t565 = call i32 @std_2fio_2ePutErr(ptr %s19, { i64, ptr } %t563)
  store i32 %t565, ptr %l315
  %t566 = icmp ne i32 %t565, 0
  br i1 %t566, label %bb146, label %ok.567, !prof !99
ok.567:
  br label %bb145
bb144:
  br label %bb180
bb145:
  br label %bb150
bb146:
  %t568 = load i32, ptr %l315, !tbaa !23
  %t569 = ashr i32 %t568, 16
  %t571 = icmp eq i32 %t569, 1
  store i1 %t571, ptr %l317, !tbaa !21
  %t572 = load i32, ptr %l315, !tbaa !23
  %t573 = ashr i32 %t572, 16
  %t575 = icmp eq i32 %t573, 1
  br i1 %t575, label %bb147, label %bb148
bb147:
  call void @__olang_errpay_pop()
  br label %bb148
bb148:
  br label %bb149
bb149:
  br label %bb150
bb150:
  store i64 0, ptr %l32, !tbaa !24
  %t577 = load i64, ptr %l1, !tbaa !24
  store i64 %t577, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t579 = load i64, ptr %l33, !tbaa !24
  %t580 = load i64, ptr %l32, !tbaa !24
  %t583 = icmp sgt i64 %t579, %t580
  br i1 %t583, label %bb151, label %bb152
bb151:
  %t585 = load i64, ptr %l34, !tbaa !24
  %t587 = icmp sgt i64 %t585, 0
  br i1 %t587, label %bb153, label %bb154
bb152:
  store i64 0, ptr %l324, !tbaa !24
  br label %bb156
bb153:
  %t589 = load i64, ptr %l33, !tbaa !24
  %t590 = load i64, ptr %l32, !tbaa !24
  %t593 = sub i64 %t589, %t590
  %t594 = load i64, ptr %l34, !tbaa !24
  %t597 = add i64 %t593, %t594
  %t599 = sub i64 %t597, 1
  %t600 = load i64, ptr %l34, !tbaa !24
  %t603 = sdiv i64 %t599, %t600
  store i64 %t603, ptr %l327, !tbaa !24
  br label %bb155
bb154:
  store i64 0, ptr %l327, !tbaa !24
  br label %bb155
bb155:
  %t605 = load i64, ptr %l327, !tbaa !24
  store i64 %t605, ptr %l324, !tbaa !24
  br label %bb156
bb156:
  %t606 = load i64, ptr %l324, !tbaa !24
  store i64 %t606, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb157
bb157:
  %t607 = load i64, ptr %l36, !tbaa !24
  %t608 = load i64, ptr %l35, !tbaa !24
  %t611 = icmp slt i64 %t607, %t608
  %t613 = xor i1 %t611, true
  br i1 %t613, label %bb158, label %bb159
bb158:
  br label %bb179
bb159:
  br label %bb160
bb160:
  %t615 = load i64, ptr %l32, !tbaa !24
  %t616 = load i64, ptr %l36, !tbaa !24
  %t617 = load i64, ptr %l34, !tbaa !24
  %t620 = mul i64 %t616, %t617
  %t623 = add i64 %t615, %t620
  store i64 %t623, ptr %l37, !tbaa !24
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/free:Free", ptr %t625, i32 0, i32 1
  %t628 = load i64, ptr %l37, !tbaa !24
  %t631 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t627, i64 %t628)
  store ptr %t631, ptr %l348
  br label %bb161
bb161:
  %t632 = load ptr, ptr %l348, !tbaa !29
  %t634 = getelementptr %"compiler/typed:Body", ptr %t632, i32 0, i32 11
  %t635 = load ptr, ptr %t634, !tbaa !29
  %t637 = icmp eq ptr %t635, null
  %t639 = xor i1 %t637, true
  br i1 %t639, label %bb162, label %bb163
bb162:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = getelementptr %"compiler/free:Free", ptr %t641, i32 0, i32 58
  %t644 = load i64, ptr %l37, !tbaa !24
  %t647 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t643, i64 %t644)
  store i1 %t647, ptr %l357
  br label %bb164
bb163:
  store i1 false, ptr %l353, !tbaa !21
  br label %bb165
bb164:
  %t648 = load i1, ptr %l357, !tbaa !21
  store i1 %t648, ptr %l353, !tbaa !21
  br label %bb165
bb165:
  %t649 = load i1, ptr %l353, !tbaa !21
  br i1 %t649, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s24
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load i64, ptr %l37, !tbaa !24
  %t654 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s24, ptr %t650, i64 %t651)
  store { i64, ptr } %t654, ptr %l360
  br label %bb168
bb167:
  br label %bb177
bb168:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t657 = getelementptr %"compiler/free:Free", ptr %t655, i32 0, i32 59
  %t658 = load i64, ptr %l37, !tbaa !24
  %t661 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t657, i64 %t658)
  store i64 %t661, ptr %l364
  br label %bb169
bb169:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/free:Free", ptr %t662, i32 0, i32 57
  %t665 = load i64, ptr %l37, !tbaa !24
  %t668 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t664, i64 %t665)
  store i1 %t668, ptr %l368
  br label %bb170
bb170:
  %t669 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t670 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t671 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t671, 1
  %t673 = extractvalue { i64, ptr } %t671, 0
  %t674 = add i64 %t670, %t673
  %t675 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t677 = add i64 %t674, %t676
  %t678 = load i64, ptr %l364, !tbaa !24
  %t679 = call i64 @__olang_fmt_i64(ptr null, i64 %t678)
  %t680 = add i64 %t677, %t679
  %t681 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t682 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t683 = add i64 %t680, %t682
  %t684 = load i1, ptr %l368, !tbaa !21
  %t685 = select i1 %t684, ptr @.c1, ptr @.c2
  %t686 = select i1 %t684, i64 4, i64 5
  %t687 = add i64 %t683, %t686
  %t688 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t691 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t690)
  call void @olang_textcopy(ptr %t691, ptr %t669, i64 %t670)
  %t692 = getelementptr i8, ptr %t691, i64 %t670
  call void @olang_textcopy(ptr %t692, ptr %t672, i64 %t673)
  %t693 = getelementptr i8, ptr %t692, i64 %t673
  call void @olang_textcopy(ptr %t693, ptr %t675, i64 %t676)
  %t694 = getelementptr i8, ptr %t693, i64 %t676
  %t695 = call i64 @__olang_fmt_i64(ptr %t694, i64 %t678)
  %t696 = getelementptr i8, ptr %t694, i64 %t679
  call void @olang_textcopy(ptr %t696, ptr %t681, i64 %t682)
  %t697 = getelementptr i8, ptr %t696, i64 %t682
  call void @olang_textcopy(ptr %t697, ptr %t685, i64 %t686)
  %t698 = getelementptr i8, ptr %t697, i64 %t686
  call void @olang_textcopy(ptr %t698, ptr %t688, i64 %t689)
  %t699 = insertvalue { i64, ptr } undef, i64 %t690, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr %t691, 1
  %t702 = extractvalue { i64, ptr } %t700, 0
  %t703 = extractvalue { i64, ptr } %t700, 1
  %t704 = mul i64 %t702, 1
  %t705 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t704)
  call void @llvm.memcpy.p0.p0.i64(ptr %t705, ptr %t703, i64 %t704, i1 false)
  %t706 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t705, 1
  %t709 = call i32 @std_2fio_2ePutErr(ptr %s24, { i64, ptr } %t707)
  store i32 %t709, ptr %l371
  %t710 = icmp ne i32 %t709, 0
  br i1 %t710, label %bb172, label %ok.711, !prof !99
ok.711:
  br label %bb171
bb171:
  br label %bb176
bb172:
  %t712 = load i32, ptr %l371, !tbaa !23
  %t713 = ashr i32 %t712, 16
  %t715 = icmp eq i32 %t713, 1
  store i1 %t715, ptr %l373, !tbaa !21
  %t716 = load i32, ptr %l371, !tbaa !23
  %t717 = ashr i32 %t716, 16
  %t719 = icmp eq i32 %t717, 1
  br i1 %t719, label %bb173, label %bb174
bb173:
  call void @__olang_errpay_pop()
  br label %bb174
bb174:
  br label %bb175
bb175:
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s24)
  br label %bb177
bb177:
  br label %bb178
bb178:
  %t721 = load i64, ptr %l36, !tbaa !24
  %t723 = add i64 %t721, 1
  store i64 %t723, ptr %l36, !tbaa !24
  br label %bb157
bb179:
  call void @__olang_scope_close(ptr %s19)
  br label %bb180
bb180:
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t727 = getelementptr %"compiler/free:Free", ptr %t725, i32 0, i32 47
  %t728 = load i1, ptr %t727, !tbaa !21
  br i1 %t728, label %bb181, label %bb182
bb181:
  br label %ret
bb182:
  br label %bb183
bb183:
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t732 = getelementptr %"compiler/free:Free", ptr %t730, i32 0, i32 42
  store ptr %t732, ptr %l38, !tbaa !29
  store i64 0, ptr %l39, !tbaa !24
  br label %bb184
bb184:
  %t734 = load i64, ptr %l39, !tbaa !24
  store i64 %t734, ptr %l382, !tbaa !24
  %t735 = load ptr, ptr %l38, !tbaa !29
  %t737 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H39bf208114dde5103bad7bf7476536d8(ptr %v0, ptr %t735)
  store i64 %t737, ptr %l384
  br label %bb185
bb185:
  %t738 = load i64, ptr %l382, !tbaa !24
  %t739 = load i64, ptr %l384, !tbaa !24
  %t740 = icmp slt i64 %t738, %t739
  %t742 = xor i1 %t740, true
  br i1 %t742, label %bb186, label %bb187
bb186:
  br label %bb196
bb187:
  br label %bb188
bb188:
  %t744 = load ptr, ptr %l38, !tbaa !29
  %t745 = load i64, ptr %l39, !tbaa !24
  %t748 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H6d56ff767ac7b72ad0cd898fedbf4594(ptr %v0, ptr %t744, i64 %t745)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t748, ptr %l389
  br label %bb189
bb189:
  %t749 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l389
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t749, ptr %l40
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t752 = getelementptr %"compiler/free:Free", ptr %t750, i32 0, i32 58
  %t753 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l40, i32 0, i32 0
  %t754 = load i64, ptr %t753, !tbaa !24
  %t757 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t752, i64 %t754)
  store i1 %t757, ptr %l393
  br label %bb190
bb190:
  %t758 = load i1, ptr %l393, !tbaa !21
  %t759 = xor i1 %t758, true
  br i1 %t759, label %bb191, label %bb192
bb191:
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t763 = getelementptr %"compiler/free:Free", ptr %t761, i32 0, i32 60
  %t764 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H6b631d225ad7497d2fe678f6450177ae(ptr %v0, ptr %t763, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t764)
  br label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb194
bb194:
  br label %bb195
bb195:
  %t767 = load i64, ptr %l39, !tbaa !24
  %t769 = add i64 %t767, 1
  store i64 %t769, ptr %l39, !tbaa !24
  br label %bb184
bb196:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l33 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 3
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l11, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr i64, ptr %t26, i64 %t23
  %t28 = load i64, ptr %t27, !tbaa !34
  %t30 = icmp eq i64 %t28, 1
  br i1 %t30, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Plan", ptr %t32, i32 0, i32 5
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i64, ptr %t39, i64 %t36
  %t41 = load i64, ptr %t40, !tbaa !34
  %t43 = icmp eq i64 %t41, 3
  store i1 %t43, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t45 = load i1, ptr %l20, !tbaa !21
  store i1 %t45, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t46 = load i1, ptr %l14, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Plan", ptr %t47, i32 0, i32 6
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l27, !tbaa !27
  %t51 = load i64, ptr %l3, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t54, i64 %t51
  %t56 = load { i64, [2 x i64] }, ptr %t55
  store { i64, [2 x i64] } %t56, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t64 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t58, i64 %t59, ptr %t60)
  store { i64, [2 x i64] } %t64, ptr %l33
  br label %bb12
bb12:
  %t65 = load { i64, [2 x i64] }, ptr %l33
  store { i64, [2 x i64] } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 11
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3a516a19293feeda_7f77204653e04cce)
  unreachable
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 11
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t31 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v1, ptr %v1, ptr %t27, i64 %a2)
  store ptr %t31, ptr %l18
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l18, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eclassifyHolders(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/free:store"
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/free:store"
  %l23 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i1
  %l51 = alloca ptr
  %l55 = alloca i32
  %l59 = alloca i64
  %l60 = alloca i1
  %l64 = alloca i32
  %l67 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca i32
  %l76 = alloca i32
  %l80 = alloca i1
  %l83 = alloca i1
  %l88 = alloca i1
  %l93 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l107 = alloca %"compiler/free:store"
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l118 = alloca { i64, ptr }
  %l121 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i32
  %l133 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 83
  store ptr %t7, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l12, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l14
  br label %bb3
bb3:
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = load i64, ptr %l14, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store %"compiler/free:store" %t23, ptr %l19
  br label %bb7
bb7:
  %t24 = load %"compiler/free:store", ptr %l19
  store %"compiler/free:store" %t24, ptr %l4
  %t25 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp slt i64 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb11
bb9:
  %t32 = load i64, ptr %l5, !tbaa !24
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 9
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l27
  br label %bb10
bb10:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l27, !tbaa !24
  %t40 = icmp sge i64 %t38, %t39
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb15
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:Free", ptr %t43, i32 0, i32 11
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l33
  br label %bb14
bb14:
  %t50 = load i1, ptr %l33, !tbaa !21
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t51 = load i1, ptr %l29, !tbaa !21
  br i1 %t51, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb19
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:Free", ptr %t52, i32 0, i32 12
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t54, i64 %t55)
  store i1 %t58, ptr %l38
  br label %bb18
bb18:
  %t59 = load i1, ptr %l38, !tbaa !21
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb23
bb21:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:Free", ptr %t61, i32 0, i32 13
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t67, ptr %l43
  br label %bb22
bb22:
  %t68 = load i1, ptr %l43, !tbaa !21
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l39, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb25:
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 10
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l47
  br label %bb27
bb27:
  %t77 = load i64, ptr %l47, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  br i1 %t78, label %bb28, label %bb29
bb28:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:Free", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l51, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:Free", ptr %t84, i32 0, i32 9
  %t87 = load i64, ptr %l5, !tbaa !24
  %t90 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t86, i64 %t87)
  store i32 %t90, ptr %l55
  br label %bb30
bb29:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb33
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/free:Free", ptr %t91, i32 0, i32 10
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t94)
  store i64 %t97, ptr %l59
  br label %bb31
bb31:
  %t98 = load ptr, ptr %l51, !tbaa !29
  %t99 = load i32, ptr %l55, !tbaa !23
  %t100 = load i64, ptr %l59, !tbaa !24
  %t101 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWeakField(ptr %v0, ptr %t98, i32 %t99, i64 %t100)
  store i1 %t101, ptr %l60
  br label %bb32
bb32:
  %t102 = load i1, ptr %l60, !tbaa !21
  store i1 %t102, ptr %l49, !tbaa !21
  br label %bb33
bb33:
  %t103 = load i1, ptr %l49, !tbaa !21
  br i1 %t103, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb35:
  br label %bb36
bb36:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/free:Free", ptr %t104, i32 0, i32 15
  %t107 = load i64, ptr %l5, !tbaa !24
  %t110 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t106, i64 %t107)
  store i32 %t110, ptr %l64
  br label %bb37
bb37:
  %t111 = load i32, ptr %l64, !tbaa !23
  store i32 %t111, ptr %l6, !tbaa !23
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load i32, ptr %l6, !tbaa !23
  %t116 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l67
  br label %bb38
bb38:
  %t117 = load i1, ptr %l67, !tbaa !21
  %t118 = xor i1 %t117, true
  br i1 %t118, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb40:
  br label %bb41
bb41:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l69, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t122 = load i32, ptr %l6, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l72
  br label %bb42
bb42:
  %t126 = load ptr, ptr %l69, !tbaa !29
  %t127 = load i32, ptr %l72, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t128, ptr %l73
  br label %bb43
bb43:
  %t129 = load i32, ptr %l73, !tbaa !23
  store i32 %t129, ptr %l7, !tbaa !23
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t131 = load i32, ptr %l7, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l76
  br label %bb44
bb44:
  %t135 = load i32, ptr %l76, !range !{i32 0, i32 33}
  %t137 = trunc i64 18 to i32
  %t138 = icmp eq i32 %t135, %t137
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb48
bb46:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l7, !tbaa !23
  %t146 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edeclaredHere(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l83
  br label %bb47
bb47:
  %t147 = load i1, ptr %l83, !tbaa !21
  %t148 = xor i1 %t147, true
  store i1 %t148, ptr %l80, !tbaa !21
  br label %bb48
bb48:
  %t150 = load i1, ptr %l80, !tbaa !21
  br i1 %t150, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb50:
  br label %bb51
bb51:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/free:Free", ptr %t151, i32 0, i32 24
  %t154 = load i32, ptr %l7, !tbaa !23
  %t157 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H2bb64fd79dc59453b9269b2696d6897f(ptr %v0, ptr %t153, i32 %t154)
  store i1 %t157, ptr %l88
  br label %bb52
bb52:
  %t158 = load i1, ptr %l88, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb53, label %bb54
bb53:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:Free", ptr %t161, i32 0, i32 24
  %t164 = load i32, ptr %l7, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l93, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l93, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H69db31e35a4e973edf5f90026da8d45a(ptr %v0, ptr %t163, i32 %t164, { i64, ptr } %t165)
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:Free", ptr %t169, i32 0, i32 25
  %t172 = load i32, ptr %l7, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t171, i32 %t172)
  br label %bb56
bb56:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 26
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load i64, ptr %l5, !tbaa !24
  %t179 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 1
  %t180 = load i64, ptr %t179, !tbaa !24
  %t181 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 2
  %t182 = load i64, ptr %t181, !tbaa !24
  %t183 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 3
  %t184 = load %"compiler/source:Span", ptr %t183
  %t185 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 4
  %t186 = load i64, ptr %t185, !tbaa !24
  %t187 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 5
  %t188 = load i64, ptr %t187, !tbaa !24
  %t189 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 6
  %t190 = load i64, ptr %t189, !tbaa !24
  %t198 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t178, i64 %t180, i64 %t182, %"compiler/source:Span" %t184, i64 %t186, i64 %t188, i64 %t190, ptr null, ptr null)
  store %"compiler/free:store" %t198, ptr %l107
  br label %bb57
bb57:
  %t199 = load ptr, ptr %l99, !tbaa !29
  %t200 = load %"compiler/free:store", ptr %l107
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t199, %"compiler/free:store" %t200)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t201 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 4
  %t202 = load i64, ptr %t201, !tbaa !24
  %t203 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t206 = icmp ne i64 %t202, %t203
  br i1 %t206, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb67
bb61:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/free:Free", ptr %t208, i32 0, i32 24
  %t211 = load i32, ptr %l7, !tbaa !23
  %t214 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hdc5ed4f57090b33f7a83fc7b2b1f05b3(ptr %v0, ptr %s2, ptr %t210, i32 %t211)
  %t215 = extractvalue { i32, { i64, ptr } } %t214, 1
  %t216 = extractvalue { i32, { i64, ptr } } %t214, 0
  store i32 %t216, ptr %l117
  %t217 = icmp ne i32 %t216, 0
  br i1 %t217, label %bb63, label %ok.218, !prof !99
ok.218:
  store { i64, ptr } %t215, ptr %l116
  br label %bb62
bb62:
  %t219 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t219, ptr %l112, !tbaa !27
  br label %bb65
bb63:
  br label %bb64
bb64:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l118, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t220, ptr %l112, !tbaa !27
  br label %bb65
bb65:
  %t222 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t230 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t228, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t230, ptr %l121
  br label %bb66
bb66:
  %t231 = load i1, ptr %l121, !tbaa !21
  %t232 = xor i1 %t231, true
  store i1 %t232, ptr %l111, !tbaa !21
  br label %bb67
bb67:
  %t234 = load i1, ptr %l111, !tbaa !21
  br i1 %t234, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb69:
  br label %bb70
bb70:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/free:Free", ptr %t235, i32 0, i32 24
  store ptr %t237, ptr %l124, !tbaa !29
  %t238 = load i32, ptr %l7, !tbaa !23
  store i32 %t238, ptr %l125, !tbaa !23
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 0
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/load:Loader", ptr %t245, i32 0, i32 4
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t249 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 2
  %t250 = load i64, ptr %t249, !tbaa !24
  %t251 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 3
  %t252 = getelementptr %"compiler/source:Span", ptr %t251, i32 0, i32 0
  %t253 = load i32, ptr %t252, !tbaa !23
  %t255 = sext i32 %t253 to i64
  %t259 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t248, i64 %t250, i64 %t255)
  store { i64, ptr } %t259, ptr %l133
  br label %bb71
bb71:
  %t260 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t266 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t265)
  call void @olang_textcopy(ptr %t266, ptr %t261, i64 %t262)
  %t267 = getelementptr i8, ptr %t266, i64 %t262
  call void @olang_textcopy(ptr %t267, ptr %t263, i64 %t264)
  %t268 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t266, 1
  %t270 = load ptr, ptr %l124, !tbaa !29
  %t271 = load i32, ptr %l125, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H69db31e35a4e973edf5f90026da8d45a(ptr %v0, ptr %t270, i32 %t271, { i64, ptr } %t269)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb73:
  %t273 = load i64, ptr %l3, !tbaa !24
  %t275 = add i64 %t273, 1
  store i64 %t275, ptr %l3, !tbaa !24
  br label %bb2
bb74:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePutErr(ptr %v1, { i64, ptr } %a1)
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i32, ptr %l3, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l5
  %t5 = getelementptr %"compiler/typed:Block", ptr %a2, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb75
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %l29, !tbaa !27
  %t21 = load i64, ptr %l7, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l9, !tbaa !29
  %t28 = load ptr, ptr %l9, !tbaa !29
  store ptr %t28, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t29 = load ptr, ptr %l32, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t32 = load ptr, ptr %l32, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l33, !tbaa !21
  br label %bb7
bb7:
  %t36 = load i1, ptr %l33, !tbaa !21
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l9, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l10, !tbaa !23
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l11, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t49 = load i32, ptr %l10, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t52 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %s0, ptr %v1, ptr %l5, i64 %t51, ptr %t52)
  br label %bb11
bb11:
  br label %bb73
bb12:
  %t56 = load ptr, ptr %l9, !tbaa !29
  store ptr %t56, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t57 = load ptr, ptr %l44, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l44, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 17}
  %t63 = icmp eq i64 %t61, 1
  store i1 %t63, ptr %l45, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l45, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l9, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t67, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l12, !tbaa !29
  %t71 = load ptr, ptr %l9, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l13, !tbaa !29
  br label %bb17
bb16:
  br label %bb36
bb17:
  %t77 = load ptr, ptr %l13, !tbaa !29
  %t79 = call i64 @compiler_2ffree_2ewholeCopySite(ptr %v1, ptr %t77)
  store i64 %t79, ptr %l53
  br label %bb18
bb18:
  %t80 = load i64, ptr %l53, !tbaa !24
  store i64 %t80, ptr %l14, !tbaa !24
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t82 = load i64, ptr %l14, !tbaa !24
  %t85 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v2, ptr %t81, i64 %t82)
  %t86 = extractvalue { i32, i64 } %t85, 1
  %t87 = extractvalue { i32, i64 } %t85, 0
  store i32 %t87, ptr %l58
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb20, label %ok.89, !prof !99
ok.89:
  store i64 %t86, ptr %l57
  br label %bb19
bb19:
  %t90 = load i64, ptr %l57, !tbaa !24
  store i64 %t90, ptr %l54, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb22
bb22:
  %t91 = load i64, ptr %l54, !tbaa !24
  store i64 %t91, ptr %l15, !tbaa !24
  %t92 = load i64, ptr %l15, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  br i1 %t94, label %bb23, label %bb24
bb23:
  %t96 = load i64, ptr %l15, !tbaa !24
  %t99 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %s0, ptr %l5, i64 %t96)
  store i1 %t99, ptr %l64
  br label %bb25
bb24:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb26
bb25:
  %t100 = load i1, ptr %l64, !tbaa !21
  store i1 %t100, ptr %l61, !tbaa !21
  br label %bb26
bb26:
  %t101 = load i1, ptr %l61, !tbaa !21
  br i1 %t101, label %bb27, label %bb28
bb27:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l65, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  store i64 %t103, ptr %l66, !tbaa !24
  %t104 = load i64, ptr %l15, !tbaa !24
  store i64 %t104, ptr %l67, !tbaa !24
  %t105 = load i64, ptr %l15, !tbaa !24
  %t108 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %s0, ptr %s0, ptr %l5, i64 %t105)
  %t109 = extractvalue { i32, ptr } %t108, 1
  %t110 = extractvalue { i32, ptr } %t108, 0
  store i32 %t110, ptr %l72
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb30, label %ok.112, !prof !99
ok.112:
  store ptr %t109, ptr %l71
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t113 = load ptr, ptr %l71, !tbaa !29
  store ptr %t113, ptr %l68, !tbaa !29
  br label %bb33
bb30:
  %t114 = load i32, ptr %l72, !tbaa !23
  %t115 = icmp eq i32 %t114, 65536
  br i1 %t115, label %bb31, label %bb32
bb31:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5e4bdb92ce033105_74c6fffa83d8f4b9)
  unreachable
bb32:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3c9da0e6d6f67483_45a341cc236b558f)
  unreachable
bb33:
  %t117 = load i64, ptr %l14, !tbaa !24
  %t118 = load ptr, ptr %l12, !tbaa !29
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t120 = load ptr, ptr %l65, !tbaa !29
  %t121 = load i64, ptr %l66, !tbaa !24
  %t122 = load i64, ptr %l67, !tbaa !24
  %t123 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedStore(ptr %v0, ptr %s0, ptr %v1, ptr %v3, ptr %t120, i64 %t121, i64 %t122, ptr %t123, i64 %t117, ptr %t118, ptr %t119)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb73
bb36:
  %t127 = load ptr, ptr %l9, !tbaa !29
  store ptr %t127, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t128 = load ptr, ptr %l77, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t131 = load ptr, ptr %l77, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 17}
  %t134 = icmp eq i64 %t132, 3
  store i1 %t134, ptr %l78, !tbaa !21
  br label %bb38
bb38:
  %t135 = load i1, ptr %l78, !tbaa !21
  br i1 %t135, label %bb39, label %bb40
bb39:
  %t136 = load ptr, ptr %l9, !tbaa !29
  %t138 = getelementptr { i64, [3 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr }, ptr %t138, i32 0, i32 1
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l16, !tbaa !29
  br label %bb41
bb40:
  br label %bb50
bb41:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l1, !tbaa !24
  %t144 = load ptr, ptr %l16, !tbaa !29
  %t146 = getelementptr %"compiler/typed:If", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t149 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t142, i64 %t143, ptr %t147, ptr %t148, ptr %t149)
  br label %bb42
bb42:
  %t155 = load ptr, ptr %l16, !tbaa !29
  %t157 = getelementptr %"compiler/typed:If", ptr %t155, i32 0, i32 2
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = icmp eq ptr %t158, null
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb43, label %bb44
bb43:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l93, !tbaa !29
  %t165 = load i64, ptr %l1, !tbaa !24
  store i64 %t165, ptr %l94, !tbaa !24
  %t166 = load ptr, ptr %l16, !tbaa !29
  %t168 = getelementptr %"compiler/typed:If", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = icmp eq ptr %t169, null
  br i1 %t171, label %bb45, label %bb46
bb44:
  br label %bb49
bb45:
  call void @__olang_check_failed(ptr @olang_loc_e18b9bec1e794c30_83d73385e9669d24)
  unreachable
bb46:
  br label %bb47
bb47:
  %t173 = load ptr, ptr %l16, !tbaa !29
  %t175 = getelementptr %"compiler/typed:If", ptr %t173, i32 0, i32 2
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t177 = load ptr, ptr %l3, !tbaa !29
  %t178 = load ptr, ptr %l4, !tbaa !29
  %t179 = load ptr, ptr %l93, !tbaa !29
  %t180 = load i64, ptr %l94, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t179, i64 %t180, ptr %t176, ptr %t177, ptr %t178)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb73
bb50:
  %t184 = load ptr, ptr %l9, !tbaa !29
  store ptr %t184, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t185 = load ptr, ptr %l102, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb51, label %bb52
bb51:
  %t188 = load ptr, ptr %l102, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 17}
  %t191 = icmp eq i64 %t189, 4
  store i1 %t191, ptr %l103, !tbaa !21
  br label %bb52
bb52:
  %t192 = load i1, ptr %l103, !tbaa !21
  br i1 %t192, label %bb53, label %bb54
bb53:
  %t193 = load ptr, ptr %l9, !tbaa !29
  %t195 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t195, i32 0, i32 1
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l17, !tbaa !29
  %t199 = load ptr, ptr %l9, !tbaa !29
  %t201 = getelementptr { i64, [3 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t201, i32 0, i32 2
  %t203 = load ptr, ptr %t202
  store ptr %t203, ptr %l18, !tbaa !29
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i64, ptr %l1, !tbaa !24
  %t207 = load ptr, ptr %l17, !tbaa !29
  %t208 = load ptr, ptr %l3, !tbaa !29
  %t209 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t205, i64 %t206, ptr %t207, ptr %t208, ptr %t209)
  br label %bb56
bb56:
  %t215 = load ptr, ptr %l18, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb57, label %bb58
bb57:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i64, ptr %l1, !tbaa !24
  %t223 = load ptr, ptr %l18, !tbaa !29
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t225 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t221, i64 %t222, ptr %t223, ptr %t224, ptr %t225)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb73
bb61:
  %t231 = load ptr, ptr %l9, !tbaa !29
  store ptr %t231, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t232 = load ptr, ptr %l123, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %bb62, label %bb63
bb62:
  %t235 = load ptr, ptr %l123, !tbaa !29
  %t236 = load i64, ptr %t235, !range !{i64 0, i64 17}
  %t238 = icmp eq i64 %t236, 11
  store i1 %t238, ptr %l124, !tbaa !21
  br label %bb63
bb63:
  %t239 = load i1, ptr %l124, !tbaa !21
  br i1 %t239, label %bb64, label %bb65
bb64:
  %t240 = load ptr, ptr %l9, !tbaa !29
  %t242 = getelementptr { i64, [3 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", ptr }, ptr %t242, i32 0, i32 1
  %t244 = load ptr, ptr %t243
  store ptr %t244, ptr %l19, !tbaa !29
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i64, ptr %l1, !tbaa !24
  %t248 = load ptr, ptr %l19, !tbaa !29
  %t249 = load ptr, ptr %l3, !tbaa !29
  %t250 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t246, i64 %t247, ptr %t248, ptr %t249, ptr %t250)
  br label %bb67
bb67:
  br label %bb73
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_51fe1291bf78cb56_b8b2e6162161098a)
  unreachable
bb73:
  br label %bb74
bb74:
  %t256 = load i64, ptr %l7, !tbaa !24
  %t258 = add i64 %t256, 1
  store i64 %t258, ptr %l7, !tbaa !24
  br label %bb2
bb75:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedStore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, ptr %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca %"compiler/typed:Local"
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l22 = alloca ptr
  %l26 = alloca %"compiler/typed:Local"
  %l28 = alloca ptr
  %l32 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i64
  %l52 = alloca i64
  %l57 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i1
  %l78 = alloca i64
  %l80 = alloca ptr
  %l84 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l85 = alloca i64
  %l86 = alloca i32
  %l89 = alloca i1
  %l93 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i64
  %l103 = alloca ptr
  %l107 = alloca { i64, [2 x i64] }
  %l109 = alloca { i64, ptr }
  %l113 = alloca i1
  %l115 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l121 = alloca { i64, ptr }
  %l123 = alloca { i64, [2 x i64] }
  %l125 = alloca { i64, [2 x i64] }
  %l127 = alloca i1
  %l129 = alloca i1
  %l131 = alloca { i64, ptr }
  %l135 = alloca i1
  %l137 = alloca i1
  %l139 = alloca { i64, [2 x i64] }
  %l141 = alloca { i64, [2 x i64] }
  %l143 = alloca i1
  %l145 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l156 = alloca i64
  %l158 = alloca ptr
  %l165 = alloca %"compiler/free:feed"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l22
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l22, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t11, i64 %t12)
  store %"compiler/typed:Local" %t15, ptr %l26
  br label %bb2
bb2:
  %t16 = load %"compiler/typed:Local", ptr %l26
  store %"compiler/typed:Local" %t16, ptr %l8
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t17)
  store ptr %t19, ptr %l28
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l28, !tbaa !29
  store ptr %t20, ptr %l9, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 4
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 7}
  %t24 = trunc i64 1 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb6
bb5:
  %t29 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 6
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l32, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l32, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb10
bb8:
  %t33 = load ptr, ptr %l9, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  %t38 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t33, i32 %t35)
  store i1 %t38, ptr %l37
  br label %bb9
bb9:
  %t39 = load i1, ptr %l37, !tbaa !21
  store i1 %t39, ptr %l34, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l34, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t43 = getelementptr %"compiler/typed:LocalUses", ptr %t41, i32 0, i32 4
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t43, i64 %t44)
  store i1 %t47, ptr %l42
  br label %bb13
bb13:
  %t48 = load i1, ptr %l42, !tbaa !21
  store i1 %t48, ptr %l38, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l38, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t52 = getelementptr %"compiler/typed:LocalUses", ptr %t50, i32 0, i32 6
  %t53 = load i64, ptr %l2, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t52, i64 %t53)
  store i1 %t56, ptr %l47
  br label %bb17
bb17:
  %t57 = load i1, ptr %l47, !tbaa !21
  store i1 %t57, ptr %l43, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l43, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  br label %bb21
bb21:
  %t59 = load ptr, ptr %l6, !tbaa !29
  %t61 = getelementptr %"compiler/typed:LocalUses", ptr %t59, i32 0, i32 8
  store ptr %t61, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  %t63 = load i64, ptr %l11, !tbaa !24
  store i64 %t63, ptr %l50, !tbaa !24
  %t64 = load ptr, ptr %l10, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t64)
  store i64 %t66, ptr %l52
  br label %bb23
bb23:
  %t67 = load i64, ptr %l50, !tbaa !24
  %t68 = load i64, ptr %l52, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb24, label %bb25
bb24:
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t73 = load ptr, ptr %l10, !tbaa !29
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t73, i64 %t74)
  store i64 %t77, ptr %l57
  br label %bb27
bb27:
  %t78 = load i64, ptr %l57, !tbaa !24
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = icmp eq i64 %t78, %t80
  br i1 %t83, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l11, !tbaa !24
  br label %bb22
bb32:
  store i64 -1, ptr %l13, !tbaa !24
  %t89 = load ptr, ptr %l5, !tbaa !29
  store ptr %t89, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t90 = load ptr, ptr %l63, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb33, label %bb34
bb33:
  %t93 = load ptr, ptr %l63, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 3
  store i1 %t96, ptr %l64, !tbaa !21
  br label %bb34
bb34:
  %t97 = load i1, ptr %l64, !tbaa !21
  br i1 %t97, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t102 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v2, ptr %t98, ptr %t99)
  store i64 %t102, ptr %l69
  br label %bb38
bb38:
  %t103 = load i64, ptr %l69, !tbaa !24
  store i64 %t103, ptr %l13, !tbaa !24
  br label %bb55
bb39:
  %t104 = load ptr, ptr %l5, !tbaa !29
  store ptr %t104, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t105 = load ptr, ptr %l70, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb40, label %bb41
bb40:
  %t108 = load ptr, ptr %l70, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 8}
  %t111 = icmp eq i64 %t109, 1
  store i1 %t111, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t112 = load i1, ptr %l71, !tbaa !21
  br i1 %t112, label %bb42, label %bb43
bb42:
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t115, i32 0, i32 2
  %t117 = load i64, ptr %t116
  store i64 %t117, ptr %l14, !tbaa !24
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t121, i32 0, i32 3
  %t123 = load i32, ptr %t122
  store i32 %t123, ptr %l15, !tbaa !23
  br label %bb44
bb43:
  br label %bb50
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 105
  store ptr %t127, ptr %l80, !tbaa !29
  %t128 = load i64, ptr %l14, !tbaa !24
  %t129 = load i32, ptr %l15, !tbaa !23
  %t131 = sext i32 %t129 to i64
  %t134 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t128, i64 %t131)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t134, ptr %l84
  br label %bb45
bb45:
  %t135 = load ptr, ptr %l80, !tbaa !29
  %t136 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l84
  %t137 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t135, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t136)
  %t138 = extractvalue { i32, i64 } %t137, 1
  %t139 = extractvalue { i32, i64 } %t137, 0
  store i32 %t139, ptr %l86
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb47, label %ok.141, !prof !99
ok.141:
  store i64 %t138, ptr %l85
  br label %bb46
bb46:
  %t142 = load i64, ptr %l85, !tbaa !24
  store i64 %t142, ptr %l78, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  store i64 -1, ptr %l78, !tbaa !24
  br label %bb49
bb49:
  %t143 = load i64, ptr %l78, !tbaa !24
  store i64 %t143, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_52b05c17772fc4a9_239015c769d5fa15)
  unreachable
bb55:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp slt i64 %t144, 0
  br i1 %t146, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb59
bb57:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/free:Free", ptr %t148, i32 0, i32 12
  %t151 = load i64, ptr %l13, !tbaa !24
  %t154 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t150, i64 %t151)
  store i1 %t154, ptr %l93
  br label %bb58
bb58:
  %t155 = load i1, ptr %l93, !tbaa !21
  %t156 = xor i1 %t155, true
  store i1 %t156, ptr %l89, !tbaa !21
  br label %bb59
bb59:
  %t158 = load i1, ptr %l89, !tbaa !21
  br i1 %t158, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb63
bb61:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t163 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t159, ptr %t160)
  store i64 %t163, ptr %l98
  br label %bb62
bb62:
  %t164 = load i64, ptr %l98, !tbaa !24
  %t165 = icmp slt i64 %t164, 0
  store i1 %t165, ptr %l95, !tbaa !21
  br label %bb63
bb63:
  %t167 = load i1, ptr %l95, !tbaa !21
  br i1 %t167, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb65:
  br label %bb66
bb66:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:Free", ptr %t168, i32 0, i32 3
  %t171 = load i64, ptr %l1, !tbaa !24
  %t174 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t170, i64 %t171)
  store ptr %t174, ptr %l103
  br label %bb67
bb67:
  %t175 = load ptr, ptr %l103, !tbaa !29
  store ptr %t175, ptr %l16, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i64, ptr %l1, !tbaa !24
  %t178 = load ptr, ptr %l3, !tbaa !29
  %t182 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t176, i64 %t177, ptr %t178)
  store { i64, [2 x i64] } %t182, ptr %l107
  br label %bb68
bb68:
  %t183 = load { i64, [2 x i64] }, ptr %l107
  store { i64, [2 x i64] } %t183, ptr %l17
  %t184 = load ptr, ptr %l16, !tbaa !29
  %t186 = getelementptr %"compiler/typed:Plan", ptr %t184, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l109, !tbaa !27
  %t188 = load i64, ptr %l4, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, [2 x i64] }, ptr %t191, i64 %t188
  %t193 = load { i64, [2 x i64] }, ptr %t192
  store { i64, [2 x i64] } %t193, ptr %l18
  %t195 = load { i64, [2 x i64] }, ptr %l17
  %t197 = call i1 @compiler_2ffree_2eruns({ i64, [2 x i64] } %t195)
  store i1 %t197, ptr %l113
  br label %bb69
bb69:
  %t198 = load i1, ptr %l113, !tbaa !21
  %t199 = xor i1 %t198, true
  br i1 %t199, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb73
bb71:
  %t201 = load { i64, [2 x i64] }, ptr %l18
  %t203 = call i1 @compiler_2ffree_2eruns({ i64, [2 x i64] } %t201)
  store i1 %t203, ptr %l117
  br label %bb72
bb72:
  %t204 = load i1, ptr %l117, !tbaa !21
  %t205 = xor i1 %t204, true
  store i1 %t205, ptr %l115, !tbaa !21
  br label %bb73
bb73:
  %t207 = load i1, ptr %l115, !tbaa !21
  br i1 %t207, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb84
bb75:
  %t208 = load ptr, ptr %l16, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Plan", ptr %t208, i32 0, i32 1
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l121, !tbaa !27
  %t212 = load i64, ptr %l2, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, [2 x i64] }, ptr %t215, i64 %t212
  %t217 = load { i64, [2 x i64] }, ptr %t216
  store { i64, [2 x i64] } %t217, ptr %l123
  %t218 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t218, ptr %l125
  %t221 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l123, ptr %l125)
  store i1 %t221, ptr %l127
  br label %bb76
bb76:
  %t222 = load i1, ptr %l127, !tbaa !21
  %t223 = xor i1 %t222, true
  br i1 %t223, label %bb77, label %bb78
bb77:
  %t225 = load ptr, ptr %l16, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Plan", ptr %t225, i32 0, i32 1
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l131, !tbaa !27
  %t229 = load i64, ptr %l2, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, [2 x i64] }, ptr %t232, i64 %t229
  %t234 = load { i64, [2 x i64] }, ptr %t233
  %t236 = extractvalue { i64, [2 x i64] } %t234, 0
  %t237 = icmp eq i64 %t236, 5
  br i1 %t237, label %bb79, label %bb80
bb78:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb83
bb79:
  %t239 = load { i64, [2 x i64] }, ptr %l17
  %t241 = call i1 @compiler_2ffree_2eisBlock({ i64, [2 x i64] } %t239)
  store i1 %t241, ptr %l137
  br label %bb81
bb80:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb82
bb81:
  %t242 = load i1, ptr %l137, !tbaa !21
  store i1 %t242, ptr %l135, !tbaa !21
  br label %bb82
bb82:
  %t243 = load i1, ptr %l135, !tbaa !21
  %t244 = xor i1 %t243, true
  store i1 %t244, ptr %l129, !tbaa !21
  br label %bb83
bb83:
  %t246 = load i1, ptr %l129, !tbaa !21
  store i1 %t246, ptr %l119, !tbaa !21
  br label %bb84
bb84:
  %t247 = load i1, ptr %l119, !tbaa !21
  br i1 %t247, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb86:
  br label %bb87
bb87:
  %t248 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t248, ptr %l139
  %t249 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t249, ptr %l141
  %t252 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l139, ptr %l141)
  store i1 %t252, ptr %l143
  br label %bb88
bb88:
  %t253 = load i1, ptr %l143, !tbaa !21
  %t254 = xor i1 %t253, true
  br i1 %t254, label %bb89, label %bb90
bb89:
  %t256 = load { i64, [2 x i64] }, ptr %l18
  %t258 = extractvalue { i64, [2 x i64] } %t256, 0
  %t259 = icmp eq i64 %t258, 3
  %t261 = xor i1 %t259, true
  store i1 %t261, ptr %l145, !tbaa !21
  br label %bb91
bb90:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb91
bb91:
  %t263 = load i1, ptr %l145, !tbaa !21
  br i1 %t263, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb93:
  br label %bb94
bb94:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/free:Free", ptr %t264, i32 0, i32 111
  store ptr %t266, ptr %l150, !tbaa !29
  %t267 = load i64, ptr %l1, !tbaa !24
  %t268 = load i64, ptr %l2, !tbaa !24
  %t271 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t267, i64 %t268)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t271, ptr %l153
  br label %bb95
bb95:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/free:Free", ptr %t272, i32 0, i32 110
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eLen_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t274)
  store i64 %t276, ptr %l156
  br label %bb96
bb96:
  %t277 = load ptr, ptr %l150, !tbaa !29
  %t278 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l153
  %t279 = load i64, ptr %l156, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t277, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t278, i64 %t279)
  br label %bb97
bb97:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/free:Free", ptr %t280, i32 0, i32 110
  store ptr %t282, ptr %l158, !tbaa !29
  %t283 = load i64, ptr %l1, !tbaa !24
  %t284 = load i64, ptr %l2, !tbaa !24
  %t285 = load i64, ptr %l13, !tbaa !24
  %t286 = load i64, ptr %l4, !tbaa !24
  %t287 = load { i64, [2 x i64] }, ptr %l17
  %t288 = load { i64, [2 x i64] }, ptr %l18
  %t295 = call %"compiler/free:feed" @compiler_2ffree_3afeed_2ector(ptr %s0, i64 %t283, i64 %t284, i64 %t285, i64 %t286, { i64, [2 x i64] } %t287, { i64, [2 x i64] } %t288)
  store %"compiler/free:feed" %t295, ptr %l165
  br label %bb98
bb98:
  %t296 = load ptr, ptr %l158, !tbaa !29
  %t297 = load %"compiler/free:feed", ptr %l165
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2ePush_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t296, %"compiler/free:feed" %t297)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l61 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownLocalCand(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobalCand(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t34, ptr %t35)
  br label %bb9
bb9:
  br label %bb90
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t39 = load ptr, ptr %l29, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t42 = load ptr, ptr %l29, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 17}
  %t45 = icmp eq i64 %t43, 0
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  br label %bb16
bb16:
  br label %bb90
bb17:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t58 = load ptr, ptr %l37, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l37, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 17}
  %t64 = icmp eq i64 %t62, 2
  store i1 %t64, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t65 = load i1, ptr %l38, !tbaa !21
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", ptr }, ptr %t68, i32 0, i32 1
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t72, ptr %t73)
  br label %bb23
bb23:
  br label %bb90
bb24:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t77 = load ptr, ptr %l45, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb25, label %bb26
bb25:
  %t80 = load ptr, ptr %l45, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 17}
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t84 = load i1, ptr %l46, !tbaa !21
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", ptr }, ptr %t87, i32 0, i32 1
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr %"compiler/typed:If", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb30
bb30:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l6, !tbaa !29
  %t101 = getelementptr %"compiler/typed:If", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t98, ptr %t102)
  br label %bb31
bb31:
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = getelementptr %"compiler/typed:If", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = icmp eq ptr %t108, null
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb32, label %bb33
bb32:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l61, !tbaa !29
  %t115 = load ptr, ptr %l6, !tbaa !29
  %t117 = getelementptr %"compiler/typed:If", ptr %t115, i32 0, i32 2
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = icmp eq ptr %t118, null
  br i1 %t120, label %bb34, label %bb35
bb33:
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_f0ef9f3a8cd9f24a_5f2afb921a19c616)
  unreachable
bb35:
  br label %bb36
bb36:
  %t122 = load ptr, ptr %l6, !tbaa !29
  %t124 = getelementptr %"compiler/typed:If", ptr %t122, i32 0, i32 2
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t126 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t126, ptr %t125)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb90
bb39:
  %t128 = load ptr, ptr %l1, !tbaa !29
  store ptr %t128, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t129 = load ptr, ptr %l67, !tbaa !29
  %t130 = icmp ne ptr %t129, null
  br i1 %t130, label %bb40, label %bb41
bb40:
  %t132 = load ptr, ptr %l67, !tbaa !29
  %t133 = load i64, ptr %t132, !range !{i64 0, i64 17}
  %t135 = icmp eq i64 %t133, 4
  store i1 %t135, ptr %l68, !tbaa !21
  br label %bb41
bb41:
  %t136 = load i1, ptr %l68, !tbaa !21
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr { i64, [3 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t139, i32 0, i32 1
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l7, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t145, i32 0, i32 2
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l8, !tbaa !29
  br label %bb44
bb43:
  br label %bb50
bb44:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  br label %bb45
bb45:
  %t153 = load ptr, ptr %l8, !tbaa !29
  %t155 = icmp eq ptr %t153, null
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb46, label %bb47
bb46:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t159, ptr %t160)
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb90
bb50:
  %t163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t163, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t164 = load ptr, ptr %l82, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb51, label %bb52
bb51:
  %t167 = load ptr, ptr %l82, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 17}
  %t170 = icmp eq i64 %t168, 6
  store i1 %t170, ptr %l83, !tbaa !21
  br label %bb52
bb52:
  %t171 = load i1, ptr %l83, !tbaa !21
  br i1 %t171, label %bb53, label %bb54
bb53:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [3 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", ptr }, ptr %t174, i32 0, i32 1
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l9, !tbaa !29
  br label %bb59
bb54:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t179 = load ptr, ptr %l88, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb55, label %bb56
bb55:
  %t182 = load ptr, ptr %l88, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 17}
  %t185 = icmp eq i64 %t183, 16
  store i1 %t185, ptr %l89, !tbaa !21
  br label %bb56
bb56:
  %t186 = load i1, ptr %l89, !tbaa !21
  br i1 %t186, label %bb57, label %bb58
bb57:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", ptr }, ptr %t189, i32 0, i32 1
  %t191 = load ptr, ptr %t190
  store ptr %t191, ptr %l9, !tbaa !29
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t193 = load ptr, ptr %l9, !tbaa !29
  %t195 = icmp eq ptr %t193, null
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb60, label %bb61
bb60:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t199, ptr %t200)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb90
bb64:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t204 = load ptr, ptr %l99, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb65, label %bb66
bb65:
  %t207 = load ptr, ptr %l99, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 17}
  %t210 = icmp eq i64 %t208, 11
  store i1 %t210, ptr %l100, !tbaa !21
  br label %bb66
bb66:
  %t211 = load i1, ptr %l100, !tbaa !21
  br i1 %t211, label %bb67, label %bb68
bb67:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", ptr }, ptr %t214, i32 0, i32 1
  %t216 = load ptr, ptr %t215
  store ptr %t216, ptr %l10, !tbaa !29
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t218, ptr %t219)
  br label %bb70
bb70:
  br label %bb90
bb71:
  %t222 = load ptr, ptr %l1, !tbaa !29
  store ptr %t222, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t223 = load ptr, ptr %l107, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb72, label %bb73
bb72:
  %t226 = load ptr, ptr %l107, !tbaa !29
  %t227 = load i64, ptr %t226, !range !{i64 0, i64 17}
  %t229 = icmp eq i64 %t227, 12
  store i1 %t229, ptr %l108, !tbaa !21
  br label %bb73
bb73:
  %t230 = load i1, ptr %l108, !tbaa !21
  br i1 %t230, label %bb74, label %bb75
bb74:
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", ptr }, ptr %t233, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l11, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t237, ptr %t238)
  br label %bb77
bb77:
  br label %bb90
bb78:
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t242 = load ptr, ptr %l115, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb79, label %bb80
bb79:
  %t245 = load ptr, ptr %l115, !tbaa !29
  %t246 = load i64, ptr %t245, !range !{i64 0, i64 17}
  %t248 = icmp eq i64 %t246, 13
  store i1 %t248, ptr %l116, !tbaa !21
  br label %bb80
bb80:
  %t249 = load i1, ptr %l116, !tbaa !21
  br i1 %t249, label %bb81, label %bb82
bb81:
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [3 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", ptr }, ptr %t252, i32 0, i32 1
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l12, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load ptr, ptr %l12, !tbaa !29
  %t259 = getelementptr %"compiler/typed:Join", ptr %t257, i32 0, i32 0
  %t260 = load ptr, ptr %t259, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t256, ptr %t260)
  br label %bb84
bb84:
  br label %bb90
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_1befe4f0760966d8_ea99a8b72a88b024)
  unreachable
bb90:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efuncTy(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t34 = trunc i64 21 to i32
  %t35 = icmp eq i32 %t32, %t34
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenLetsOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/free:letGo"
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/free:letGo"
  %l67 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i64
  %l73 = alloca i1
  %l80 = alloca i64
  %l82 = alloca i1
  %l84 = alloca ptr
  %l88 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i1
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l105 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l115 = alloca ptr
  %l117 = alloca i64
  %l126 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l154 = alloca i64
  %l156 = alloca i1
  %l157 = alloca ptr
  %l161 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l167 = alloca i64
  %l168 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l172 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l23
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 1
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l26
  br label %bb2
bb2:
  %t10 = load i64, ptr %l26, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l33, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l33, !tbaa !24
  store i64 %t37, ptr %l30, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l30, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l7, !tbaa !24
  %t57 = load ptr, ptr %lp1
  store ptr %t57, ptr %l51, !tbaa !29
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l52
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l51, !tbaa !29
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v1, ptr %s2, ptr %t59, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb9
bb16:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 84
  store ptr %t67, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t69 = load i64, ptr %l9, !tbaa !24
  store i64 %t69, ptr %l57, !tbaa !24
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l59
  br label %bb18
bb18:
  %t73 = load i64, ptr %l57, !tbaa !24
  %t74 = load i64, ptr %l59, !tbaa !24
  %t75 = icmp slt i64 %t73, %t74
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb20:
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t79, i64 %t80)
  store %"compiler/free:letGo" %t83, ptr %l64
  br label %bb22
bb22:
  %t84 = load %"compiler/free:letGo", ptr %l64
  store %"compiler/free:letGo" %t84, ptr %l10
  %t85 = getelementptr %"compiler/free:letGo", ptr %l10, i32 0, i32 0
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = icmp slt i64 %t86, 0
  br i1 %t88, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb26
bb24:
  %t90 = getelementptr %"compiler/free:letGo", ptr %l10, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l68, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:Free", ptr %t92, i32 0, i32 15
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l71
  br label %bb25
bb25:
  %t97 = load i64, ptr %l68, !tbaa !24
  %t98 = load i64, ptr %l71, !tbaa !24
  %t99 = icmp sge i64 %t97, %t98
  store i1 %t99, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t101 = load i1, ptr %l67, !tbaa !21
  br i1 %t101, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb29
bb28:
  %t102 = getelementptr %"compiler/free:letGo", ptr %l10, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = icmp slt i64 %t103, 0
  store i1 %t105, ptr %l73, !tbaa !21
  br label %bb29
bb29:
  %t107 = load i1, ptr %l73, !tbaa !21
  br i1 %t107, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb31:
  br label %bb32
bb32:
  %t108 = getelementptr %"compiler/free:letGo", ptr %l10, i32 0, i32 0
  %t109 = load i64, ptr %t108, !tbaa !24
  store i64 %t109, ptr %l11, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/free:Free", ptr %t111, i32 0, i32 10
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t113, i64 %t114)
  store i64 %t117, ptr %l80
  br label %bb33
bb33:
  %t118 = load i64, ptr %l80, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb34, label %bb35
bb34:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:Free", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l84, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 9
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t127, i64 %t128)
  store i32 %t131, ptr %l88
  br label %bb36
bb35:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb39
bb36:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/free:Free", ptr %t132, i32 0, i32 10
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t135)
  store i64 %t138, ptr %l92
  br label %bb37
bb37:
  %t139 = load ptr, ptr %l84, !tbaa !29
  %t140 = load i32, ptr %l88, !tbaa !23
  %t141 = load i64, ptr %l92, !tbaa !24
  %t142 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWeakField(ptr %v0, ptr %t139, i32 %t140, i64 %t141)
  store i1 %t142, ptr %l93
  br label %bb38
bb38:
  %t143 = load i1, ptr %l93, !tbaa !21
  store i1 %t143, ptr %l82, !tbaa !21
  br label %bb39
bb39:
  %t144 = load i1, ptr %l82, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb41:
  br label %bb42
bb42:
  %t145 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t145, ptr %l94
  br label %bb43
bb43:
  %t146 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %l12
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l95, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t148)
  store ptr %t150, ptr %l97
  br label %bb44
bb44:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/free:Free", ptr %t151, i32 0, i32 15
  %t154 = getelementptr %"compiler/free:letGo", ptr %l10, i32 0, i32 0
  %t155 = load i64, ptr %t154, !tbaa !24
  %t158 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t153, i64 %t155)
  store i32 %t158, ptr %l101
  br label %bb45
bb45:
  %t159 = load ptr, ptr %l97, !tbaa !29
  %t160 = load i32, ptr %l101, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t161, ptr %l102
  br label %bb46
bb46:
  %t162 = load ptr, ptr %l95, !tbaa !29
  %t163 = load i32, ptr %l102, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %s5, ptr %t162, i32 %t163, ptr %l12, i64 0)
  br label %bb47
bb47:
  store ptr %l12, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb48
bb48:
  %t166 = load i64, ptr %l14, !tbaa !24
  store i64 %t166, ptr %l105, !tbaa !24
  %t167 = load ptr, ptr %l13, !tbaa !29
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s5, ptr %t167)
  store i64 %t169, ptr %l107
  br label %bb49
bb49:
  %t170 = load i64, ptr %l105, !tbaa !24
  %t171 = load i64, ptr %l107, !tbaa !24
  %t172 = icmp slt i64 %t170, %t171
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb50, label %bb51
bb50:
  br label %bb57
bb51:
  br label %bb52
bb52:
  %t176 = load ptr, ptr %l13, !tbaa !29
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %t176, i64 %t177)
  store i64 %t180, ptr %l112
  br label %bb53
bb53:
  %t181 = load i64, ptr %l112, !tbaa !24
  store i64 %t181, ptr %l15, !tbaa !24
  %t182 = load ptr, ptr %lp1
  %t183 = getelementptr %"compiler/free:letGo", ptr %l10, i32 0, i32 1
  %t184 = load i64, ptr %t183, !tbaa !24
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v1, ptr %v1, ptr %t182, i64 %t184)
  store ptr %t187, ptr %l115
  br label %bb54
bb54:
  %t188 = load i64, ptr %l15, !tbaa !24
  %t189 = load ptr, ptr %l115, !tbaa !29
  %t191 = call i64 @compiler_2ffree_2eaddTo(ptr %v1, ptr %t189, i64 %t188)
  store i64 %t191, ptr %l117
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t192 = load i64, ptr %l14, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l14, !tbaa !24
  br label %bb48
bb57:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb58:
  %t196 = load i64, ptr %l9, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l9, !tbaa !24
  br label %bb17
bb59:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb60
bb60:
  %t200 = load i1, ptr %l16, !tbaa !21
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb61, label %bb62
bb61:
  br label %bb91
bb62:
  br label %bb63
bb63:
  store i1 false, ptr %l16, !tbaa !21
  store i64 0, ptr %l17, !tbaa !24
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/free:Free", ptr %t204, i32 0, i32 29
  %t208 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t206)
  store i64 %t208, ptr %l126
  br label %bb64
bb64:
  %t209 = load i64, ptr %l126, !tbaa !24
  store i64 %t209, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l17, !tbaa !24
  %t214 = icmp sgt i64 %t210, %t211
  br i1 %t214, label %bb65, label %bb66
bb65:
  %t216 = load i64, ptr %l19, !tbaa !24
  %t218 = icmp sgt i64 %t216, 0
  br i1 %t218, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb70
bb67:
  %t220 = load i64, ptr %l18, !tbaa !24
  %t221 = load i64, ptr %l17, !tbaa !24
  %t224 = sub i64 %t220, %t221
  %t225 = load i64, ptr %l19, !tbaa !24
  %t228 = add i64 %t224, %t225
  %t230 = sub i64 %t228, 1
  %t231 = load i64, ptr %l19, !tbaa !24
  %t234 = sdiv i64 %t230, %t231
  store i64 %t234, ptr %l133, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb69
bb69:
  %t236 = load i64, ptr %l133, !tbaa !24
  store i64 %t236, ptr %l130, !tbaa !24
  br label %bb70
bb70:
  %t237 = load i64, ptr %l130, !tbaa !24
  store i64 %t237, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s14
  %t238 = load i64, ptr %l21, !tbaa !24
  %t239 = load i64, ptr %l20, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb73:
  br label %bb74
bb74:
  %t246 = load i64, ptr %l17, !tbaa !24
  %t247 = load i64, ptr %l21, !tbaa !24
  %t248 = load i64, ptr %l19, !tbaa !24
  %t251 = mul i64 %t247, %t248
  %t254 = add i64 %t246, %t251
  store i64 %t254, ptr %l22, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/free:Free", ptr %t256, i32 0, i32 30
  %t259 = load i64, ptr %l22, !tbaa !24
  %t262 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t258, i64 %t259)
  store i64 %t262, ptr %l154
  br label %bb75
bb75:
  %t263 = load i64, ptr %l154, !tbaa !24
  %t264 = icmp sge i64 %t263, 0
  br i1 %t264, label %bb76, label %bb77
bb76:
  %t266 = load ptr, ptr %lp1
  store ptr %t266, ptr %l157, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/free:Free", ptr %t267, i32 0, i32 29
  %t270 = load i64, ptr %l22, !tbaa !24
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t269, i64 %t270)
  store i64 %t273, ptr %l161
  br label %bb78
bb77:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb84
bb78:
  %t274 = load ptr, ptr %l157, !tbaa !29
  %t275 = load i64, ptr %l161, !tbaa !24
  %t276 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v1, ptr %v1, ptr %t274, i64 %t275)
  store ptr %t276, ptr %l162
  br label %bb79
bb79:
  %t277 = load ptr, ptr %lp1
  store ptr %t277, ptr %l163, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/free:Free", ptr %t278, i32 0, i32 30
  %t281 = load i64, ptr %l22, !tbaa !24
  %t284 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t280, i64 %t281)
  store i64 %t284, ptr %l167
  br label %bb80
bb80:
  %t285 = load ptr, ptr %l163, !tbaa !29
  %t286 = load i64, ptr %l167, !tbaa !24
  %t287 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v1, ptr %v1, ptr %t285, i64 %t286)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t287, ptr %l168
  br label %bb81
bb81:
  %t289 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l168)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t289, ptr %l170
  br label %bb82
bb82:
  %t290 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170
  %t291 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t290, ptr %t291
  %t292 = load ptr, ptr %l162, !tbaa !29
  %t294 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v1, ptr %v1, ptr %t292, ptr %t291)
  store i64 %t294, ptr %l172
  br label %bb83
bb83:
  %t295 = load i64, ptr %l172, !tbaa !24
  %t296 = icmp sgt i64 %t295, 0
  store i1 %t296, ptr %l156, !tbaa !21
  br label %bb84
bb84:
  %t298 = load i1, ptr %l156, !tbaa !21
  br i1 %t298, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb87
bb86:
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s14)
  br label %bb88
bb88:
  %t299 = load i64, ptr %l21, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l21, !tbaa !24
  br label %bb71
bb89:
  br label %bb90
bb90:
  br label %bb60
bb91:
  %t303 = load ptr, ptr %lp1
  %t304 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t303
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t304, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenPlace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l9 = alloca i32
  %l13 = alloca i64
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 15
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7, i64 %t8)
  store i32 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i32, ptr %l9, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 10
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l13
  br label %bb3
bb3:
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = icmp sge i64 %t20, 0
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l17, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 9
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t29, i64 %t30)
  store i32 %t33, ptr %l21
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 10
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l25
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l17, !tbaa !29
  %t42 = load i32, ptr %l21, !tbaa !23
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWeakField(ptr %v0, ptr %t41, i32 %t42, i64 %t43)
  store i1 %t44, ptr %l26
  br label %bb8
bb8:
  %t45 = load i1, ptr %l26, !tbaa !21
  store i1 %t45, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l15, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l30
  br label %bb13
bb13:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:Free", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  store ptr %t58, ptr %l34, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb16:
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = load i32, ptr %l37, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t66, ptr %l38
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load i32, ptr %l38, !tbaa !23
  %t69 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t69, ptr %l39
  br label %bb18
bb18:
  %t70 = load i1, ptr %l39, !tbaa !21
  store i1 %t70, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l31, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobalCand(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l23 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l27 = alloca i1
  %l32 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l60 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t24, i32 0, i32 3
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb41
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i32, ptr %l4, !tbaa !23
  %t31 = sext i32 %t29 to i64
  %t34 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t28, i64 %t31)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l23
  br label %bb6
bb6:
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l23
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l5
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 105
  %t39 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t42 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t38, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t39)
  store i1 %t42, ptr %l27
  br label %bb7
bb7:
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/free:Free", ptr %t47, i32 0, i32 114
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t46, i64 %t50)
  store ptr %t53, ptr %l32
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 1
  %t57 = load { i64, [2 x i64] }, ptr %t56
  %t61 = extractvalue { i64, [2 x i64] } %t57, 0
  %t62 = icmp eq i64 %t61, 6
  br i1 %t62, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bb5f0dfb007b1fe9_f99f55ed89f1afa5)
  unreachable
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l39
  br label %bb21
bb21:
  %t69 = load i1, ptr %l39, !tbaa !21
  store i1 %t69, ptr %l7, !tbaa !21
  %t70 = load i1, ptr %l7, !tbaa !21
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t78, ptr %l45
  br label %bb24
bb23:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb25
bb24:
  %t79 = load i1, ptr %l45, !tbaa !21
  store i1 %t79, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t80 = load i1, ptr %l42, !tbaa !21
  store i1 %t80, ptr %l8, !tbaa !21
  %t81 = load i1, ptr %l7, !tbaa !21
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t85 = load i1, ptr %l8, !tbaa !21
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb28
bb28:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l2, !tbaa !23
  %t94 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l54
  br label %bb31
bb30:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb32
bb31:
  %t95 = load i1, ptr %l54, !tbaa !21
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t98 = load i1, ptr %l51, !tbaa !21
  br i1 %t98, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb34:
  br label %bb35
bb35:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l2, !tbaa !23
  %t101 = load i1, ptr %l8, !tbaa !21
  %t102 = load i32, ptr %l2, !tbaa !23
  %t107 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t99, i32 %t100, i64 -4, i1 %t101, i32 %t102, i1 false)
  store i64 %t107, ptr %l60
  br label %bb36
bb36:
  %t108 = load i64, ptr %l60, !tbaa !24
  store i64 %t108, ptr %l9, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:Free", ptr %t109, i32 0, i32 12
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load i1, ptr %l7, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t111, i64 %t112, i1 %t113)
  br label %bb37
bb37:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:Free", ptr %t117, i32 0, i32 106
  %t120 = load i64, ptr %l9, !tbaa !24
  %t121 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t119, i64 %t120, i64 %t121)
  br label %bb38
bb38:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 107
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load i32, ptr %l4, !tbaa !23
  %t131 = sext i32 %t129 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t127, i64 %t128, i64 %t131)
  br label %bb39
bb39:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:Free", ptr %t135, i32 0, i32 105
  %t138 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t139 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t137, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t138, i64 %t139)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s1)
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_4607beb6ac2e2918_142733ac3129574)
  unreachable
bb46:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eguard(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l6 = alloca i1
  %l7 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 22
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %a1)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb4
bb3:
  store i64 %a2, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehiddenCalls(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l11 = alloca ptr
  %l17 = alloca i64
  %l35 = alloca i1
  %l39 = alloca i1
  %l42 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca ptr
  %l57 = alloca i1
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l11, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 14
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 1
  %t18 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t18, ptr %l3
  %t20 = load { i64, [2 x i64] }, ptr %l3
  %t22 = extractvalue { i64, [2 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t26 = getelementptr { i64 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  store i64 %t27, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t29 = load i64, ptr %l4, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb27
bb8:
  %t31 = load { i64, [2 x i64] }, ptr %l3
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 1
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  %t36 = load { i64, [2 x i64] }, ptr %l3
  %t38 = extractvalue { i64, [2 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 5
  br i1 %t39, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i64 -2, ptr %l17, !tbaa !24
  br label %bb27
bb14:
  %t41 = load { i64, [2 x i64] }, ptr %l3
  %t43 = extractvalue { i64, [2 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 6
  br i1 %t44, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -2, ptr %l17, !tbaa !24
  br label %bb27
bb18:
  %t46 = load { i64, [2 x i64] }, ptr %l3
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 7
  br i1 %t49, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i64 -2, ptr %l17, !tbaa !24
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ac355660a49cb455_c717ad746a0ccd69)
  unreachable
bb27:
  %t51 = load i64, ptr %l17, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp eq i64 %t52, -2
  br i1 %t54, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = icmp slt i64 %t57, 0
  br i1 %t59, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb34
bb32:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:Free", ptr %t61, i32 0, i32 80
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t67, ptr %l39
  br label %bb33
bb33:
  %t68 = load i1, ptr %l39, !tbaa !21
  store i1 %t68, ptr %l35, !tbaa !21
  br label %bb34
bb34:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb35, label %bb36
bb35:
  store i1 true, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:Free", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  store ptr %t74, ptr %l42, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t78, i64 %t79)
  store i64 %t82, ptr %l46
  br label %bb38
bb38:
  %t83 = load ptr, ptr %l42, !tbaa !29
  %t84 = load i64, ptr %l46, !tbaa !24
  %t85 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t83, i64 %t84)
  store ptr %t85, ptr %l47
  br label %bb39
bb39:
  %t86 = load ptr, ptr %l47, !tbaa !29
  store ptr %t86, ptr %l6, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  %t89 = getelementptr %"compiler/ast:Func", ptr %t87, i32 0, i32 7
  %t90 = load i1, ptr %t89, !tbaa !21
  br i1 %t90, label %bb40, label %bb41
bb40:
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Func", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = icmp eq ptr %t96, null
  br i1 %t98, label %bb43, label %bb44
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eanyMethod(ptr %v0, ptr %t101, i64 %t102)
  store i1 %t105, ptr %l57
  br label %bb46
bb46:
  %t106 = load i1, ptr %l57, !tbaa !21
  br i1 %t106, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:Free", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/load:Loader", ptr %t114, i32 0, i32 3
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Func", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t117, i32 %t121)
  store { i64, ptr } %t124, ptr %l65
  br label %bb50
bb50:
  %t125 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t128 = call i1 @compiler_2ffree_2eprotocolName(ptr %v0, { i64, ptr } %t125)
  store i1 %t128, ptr %l67
  br label %bb51
bb51:
  %t129 = load i1, ptr %l67, !tbaa !21
  store i1 %t129, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDtor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb3
bb3:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l5, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l15
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  %t31 = extractvalue { i64, [2 x i64] } %t27, 0
  %t32 = icmp eq i64 %t31, 3
  br i1 %t32, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9eead29ed0644a31_3adf6a8ef4d2d8d5)
  unreachable
bb17:
  %t34 = load i1, ptr %l18, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisNamed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisGlobal(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l5, !tbaa !21
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l18 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l32 = alloca %"compiler/free:reason"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 85
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 85
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l18
  br label %bb7
bb7:
  %t23 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t26 = icmp ne i64 %t24, %t23
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 85
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t31, i64 %t32, i64 %t33)
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 87
  store ptr %t39, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t49 = call %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v1, ptr %v0, i64 %t41, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
  store %"compiler/free:reason" %t49, ptr %l32
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = load %"compiler/free:reason", ptr %l32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t50, i64 %t51, %"compiler/free:reason" %t52)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayFixedPoint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l29 = alloca { i64, ptr }
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l62 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i64
  %l70 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t16 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l18
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l4
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l19, !tbaa !24
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load i64, ptr %l19, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  store i64 0, ptr %t16
  br label %fill.17
fill.17:
  %t20 = load i64, ptr %t16
  %t21 = icmp slt i64 %t20, %t13
  br i1 %t21, label %fillb.18, label %filld.19
fillb.18:
  %t22 = getelementptr i1, ptr %t15, i64 %t20
  store i1 true, ptr %t22
  %t23 = add i64 %t20, 1
  store i64 %t23, ptr %t16
  br label %fill.17
filld.19:
  %t24 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t15, 1
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  store { i64, ptr } %a1, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l8, !tbaa !24
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_1888621446777a9a_f48dc3b4e7acb28e)
  unreachable
bb5:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i64, ptr %t45, i64 %t42
  %t47 = load i64, ptr %t46, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t47)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l7, !tbaa !24
  br label %bb5
bb11:
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l10, !tbaa !24
  store i64 %t56, ptr %l36, !tbaa !24
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t58, ptr %l38
  br label %bb13
bb13:
  %t59 = load i64, ptr %l36, !tbaa !24
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = icmp slt i64 %t59, %t60
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb40
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t65)
  store i64 %t68, ptr %l43
  br label %bb17
bb17:
  %t69 = load i64, ptr %l43, !tbaa !24
  store i64 %t69, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i1, ptr %t73, i64 %t70
  store i1 false, ptr %t74, !tbaa !31
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 77
  store i1 false, ptr %t77, !tbaa !21
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l3, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %t82, i64 %t83, i1 false)
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/free:Free", ptr %t86, i32 0, i32 77
  %t89 = load i1, ptr %t88, !tbaa !21
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb19, label %bb20
bb19:
  br label %bb39
bb20:
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 97
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store ptr %t99, ptr %l56
  br label %bb22
bb22:
  %t100 = load ptr, ptr %l56, !tbaa !29
  store ptr %t100, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  %t101 = load i64, ptr %l13, !tbaa !24
  store i64 %t101, ptr %l57, !tbaa !24
  %t102 = load ptr, ptr %l12, !tbaa !29
  store ptr %t102, ptr %l58, !tbaa !29
  %t103 = ptrtoint ptr %v0 to i64
  store i64 %t103, ptr %l59, !tbaa !24
  %t104 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t106 = load ptr, ptr %l58, !tbaa !29
  %t107 = call ptr @__olang_region_or(ptr %t106, ptr %v0)
  %t108 = ptrtoint ptr %t107 to i64
  store i64 %t108, ptr %l59, !tbaa !24
  br label %bb25
bb25:
  %t109 = load ptr, ptr %l12, !tbaa !29
  %t110 = load i64, ptr %l59
  %t111 = inttoptr i64 %t110 to ptr
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t111, ptr %t109)
  store i64 %t113, ptr %l62
  br label %bb26
bb26:
  %t114 = load i64, ptr %l57, !tbaa !24
  %t115 = load i64, ptr %l62, !tbaa !24
  %t116 = icmp slt i64 %t114, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb27, label %bb28
bb27:
  br label %bb38
bb28:
  br label %bb29
bb29:
  %t120 = load ptr, ptr %l12, !tbaa !29
  store ptr %t120, ptr %l65, !tbaa !29
  %t121 = ptrtoint ptr %v0 to i64
  store i64 %t121, ptr %l66, !tbaa !24
  %t122 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t122, label %bb30, label %bb31
bb30:
  %t124 = load ptr, ptr %l65, !tbaa !29
  %t125 = call ptr @__olang_region_or(ptr %t124, ptr %v0)
  %t126 = ptrtoint ptr %t125 to i64
  store i64 %t126, ptr %l66, !tbaa !24
  br label %bb31
bb31:
  %t127 = load ptr, ptr %l12, !tbaa !29
  %t128 = load i64, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l66
  %t130 = inttoptr i64 %t129 to ptr
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t130, ptr %t127, i64 %t128)
  store i64 %t133, ptr %l70
  br label %bb32
bb32:
  %t134 = load i64, ptr %l70, !tbaa !24
  store i64 %t134, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l14, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i1, ptr %t138, i64 %t135
  %t140 = load i1, ptr %t139, !tbaa !31
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb33, label %bb34
bb33:
  %t144 = load i64, ptr %l14, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i1, ptr %t147, i64 %t144
  store i1 true, ptr %t148, !tbaa !31
  %t149 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t149)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l13, !tbaa !24
  br label %bb23
bb38:
  br label %bb39
bb39:
  %t156 = load i64, ptr %l10, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l10, !tbaa !24
  br label %bb12
bb40:
  %t160 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t160, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustFixedPoint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l43 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i64
  %l72 = alloca i64
  %l93 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l106 = alloca i1
  %l112 = alloca ptr
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l119 = alloca i64
  %l129 = alloca { i64, ptr }
  %l136 = alloca i64
  %l138 = alloca i64
  %l143 = alloca i64
  %l155 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l159 = alloca i64
  %l161 = alloca i64
  %l166 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca i64
  %t183 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l34
  br label %bb1
bb1:
  %t6 = load i64, ptr %l34, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l35
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l43, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l43, !tbaa !24
  store i64 %t37, ptr %l40, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l40, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l9, !tbaa !24
  store ptr %l3, ptr %l61, !tbaa !29
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l62
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l61, !tbaa !29
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s0, ptr %s2, ptr %t58, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l8, !tbaa !24
  br label %bb9
bb16:
  store i64 0, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t66 = load i64, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t72 = load i64, ptr %l12, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb22
bb19:
  %t76 = load i64, ptr %l11, !tbaa !24
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l12, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l12, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l72, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t92 = load i64, ptr %l72, !tbaa !24
  store i64 %t92, ptr %l69, !tbaa !24
  br label %bb22
bb22:
  %t93 = load i64, ptr %l69, !tbaa !24
  store i64 %t93, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb23
bb23:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t95 = load i64, ptr %l13, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb24, label %bb25
bb24:
  br label %bb43
bb25:
  br label %bb26
bb26:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l14, !tbaa !24
  %t104 = load i64, ptr %l12, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l15, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s6
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/free:Free", ptr %t112, i32 0, i32 2
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t116 = load i64, ptr %l15, !tbaa !24
  %t119 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %s6, ptr %t115, i64 %t116)
  store { i64, ptr } %t119, ptr %l93
  br label %bb27
bb27:
  %t120 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 8
  %t124 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  store i64 %t130, ptr %l18, !tbaa !24
  br label %bb28
bb28:
  %t132 = load i64, ptr %l17, !tbaa !24
  %t133 = load i64, ptr %l18, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb29, label %bb30
bb29:
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t140 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t140, ptr %l101, !tbaa !27
  %t141 = load i64, ptr %l17, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i64, ptr %t144, i64 %t141
  %t146 = load i64, ptr %t145, !tbaa !34
  store i64 %t146, ptr %l19, !tbaa !24
  %t148 = load i64, ptr %l19, !tbaa !24
  %t150 = icmp sge i64 %t148, 0
  br i1 %t150, label %bb32, label %bb33
bb32:
  %t152 = load i64, ptr %l19, !tbaa !24
  %t153 = load i64, ptr %l2, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  store i1 %t156, ptr %l106, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb34
bb34:
  %t158 = load i1, ptr %l106, !tbaa !21
  br i1 %t158, label %bb35, label %bb36
bb35:
  %t159 = load i64, ptr %l19, !tbaa !24
  %t162 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %s0, ptr %s0, ptr %l3, i64 %t159)
  store ptr %t162, ptr %l112
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t163 = load i64, ptr %l15, !tbaa !24
  %t164 = load ptr, ptr %l112, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t164, i64 %t163)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t166 = load i64, ptr %l17, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l17, !tbaa !24
  br label %bb28
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb42:
  %t170 = load i64, ptr %l14, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l14, !tbaa !24
  br label %bb23
bb43:
  store i64 0, ptr %l20, !tbaa !24
  %t174 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %l118
  br label %bb44
bb44:
  %t175 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t175, ptr %l21
  %t176 = load i64, ptr %l2, !tbaa !24
  store i64 %t176, ptr %l119, !tbaa !24
  %t177 = load i64, ptr %l119, !tbaa !24
  %t178 = icmp sge i64 %t177, 0
  br i1 %t178, label %bb45, label %bb46
bb45:
  %t180 = load i64, ptr %l119, !tbaa !24
  %t181 = mul i64 %t180, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  store i64 0, ptr %t183
  br label %fill.184
fill.184:
  %t187 = load i64, ptr %t183
  %t188 = icmp slt i64 %t187, %t180
  br i1 %t188, label %fillb.185, label %filld.186
fillb.185:
  %t189 = getelementptr i1, ptr %t182, i64 %t187
  store i1 true, ptr %t189
  %t190 = add i64 %t187, 1
  store i64 %t190, ptr %t183
  br label %fill.184
filld.186:
  %t191 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t182, 1
  store { i64, ptr } %t192, ptr %l22, !tbaa !27
  store { i64, ptr } %a1, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l25, !tbaa !24
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_ed0a7c8afdb87cca_1f491858f5456086)
  unreachable
bb47:
  %t200 = load i64, ptr %l24, !tbaa !24
  %t201 = load i64, ptr %l25, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb48, label %bb49
bb48:
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t208 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t208, ptr %l129, !tbaa !27
  %t209 = load i64, ptr %l24, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i64, ptr %t212, i64 %t209
  %t214 = load i64, ptr %t213, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l21, i64 %t214)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t219 = load i64, ptr %l24, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l24, !tbaa !24
  br label %bb47
bb53:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb54
bb54:
  %t223 = load i64, ptr %l27, !tbaa !24
  store i64 %t223, ptr %l136, !tbaa !24
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l21)
  store i64 %t225, ptr %l138
  br label %bb55
bb55:
  %t226 = load i64, ptr %l136, !tbaa !24
  %t227 = load i64, ptr %l138, !tbaa !24
  %t228 = icmp slt i64 %t226, %t227
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb56, label %bb57
bb56:
  br label %bb79
bb57:
  br label %bb58
bb58:
  %t232 = load i64, ptr %l27, !tbaa !24
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l21, i64 %t232)
  store i64 %t235, ptr %l143
  br label %bb59
bb59:
  %t236 = load i64, ptr %l143, !tbaa !24
  store i64 %t236, ptr %l28, !tbaa !24
  %t237 = load i64, ptr %l28, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i1, ptr %t240, i64 %t237
  store i1 false, ptr %t241, !tbaa !31
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/free:Free", ptr %t242, i32 0, i32 77
  store i1 false, ptr %t244, !tbaa !21
  %t245 = load i64, ptr %l20, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l20, !tbaa !24
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i64, ptr %l28, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustOf(ptr %v0, ptr %t249, i64 %t250)
  br label %bb60
bb60:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/free:Free", ptr %t253, i32 0, i32 77
  %t256 = load i1, ptr %t255, !tbaa !21
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb61, label %bb62
bb61:
  br label %bb78
bb62:
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s17
  %t260 = load i64, ptr %l28, !tbaa !24
  %t263 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s17, ptr %l3, i64 %t260)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %l155
  br label %bb64
bb64:
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s17, ptr %l155)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l157
  br label %bb65
bb65:
  %t266 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  %t267 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %t267
  store ptr %t267, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb66
bb66:
  %t269 = load i64, ptr %l30, !tbaa !24
  store i64 %t269, ptr %l159, !tbaa !24
  %t270 = load ptr, ptr %l29, !tbaa !29
  %t272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s17, ptr %t270)
  store i64 %t272, ptr %l161
  br label %bb67
bb67:
  %t273 = load i64, ptr %l159, !tbaa !24
  %t274 = load i64, ptr %l161, !tbaa !24
  %t275 = icmp slt i64 %t273, %t274
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb68, label %bb69
bb68:
  br label %bb77
bb69:
  br label %bb70
bb70:
  %t279 = load ptr, ptr %l29, !tbaa !29
  %t280 = load i64, ptr %l30, !tbaa !24
  %t283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s17, ptr %t279, i64 %t280)
  store i64 %t283, ptr %l166
  br label %bb71
bb71:
  %t284 = load i64, ptr %l166, !tbaa !24
  store i64 %t284, ptr %l31, !tbaa !24
  %t285 = load i64, ptr %l31, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr i1, ptr %t288, i64 %t285
  %t290 = load i1, ptr %t289, !tbaa !31
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb72, label %bb73
bb72:
  %t294 = load i64, ptr %l31, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i1, ptr %t297, i64 %t294
  store i1 true, ptr %t298, !tbaa !31
  %t299 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l21, i64 %t299)
  br label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t302 = load i64, ptr %l30, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l30, !tbaa !24
  br label %bb66
bb77:
  call void @__olang_scope_close(ptr %s17)
  br label %bb78
bb78:
  %t306 = load i64, ptr %l27, !tbaa !24
  %t308 = add i64 %t306, 1
  store i64 %t308, ptr %l27, !tbaa !24
  br label %bb54
bb79:
  %t310 = load i64, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t310, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3, i32 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/free:reason"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9, i32 %a1)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t15, i64 %a2)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:Free", ptr %t19, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t21, i1 %a3)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:Free", ptr %t25, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t27, i1 false)
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t31, i1 false)
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t35, i32 %a4)
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 85
  %t42 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:Free", ptr %t45, i32 0, i32 86
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t47, i1 false)
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 87
  store ptr %t51, ptr %l32, !tbaa !29
  %t52 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  store i64 %t52, ptr %l33, !tbaa !24
  %t53 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t53, ptr %l34
  br label %bb10
bb10:
  %t54 = load i64, ptr %l33, !tbaa !24
  %t55 = load %"compiler/source:Span", ptr %l34
  %t56 = call %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v0, i64 %t54, i64 -1, %"compiler/source:Span" %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store %"compiler/free:reason" %t56, ptr %l35
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load %"compiler/free:reason", ptr %l35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t57, %"compiler/free:reason" %t58)
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 113
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t61, i1 %a5)
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 102
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 -1)
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 103
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t71, i64 -1)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 106
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 -1)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t77, i32 0, i32 107
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t79, i64 -1)
  br label %bb17
bb17:
  %t81 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2enoteDtor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l37 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca i32
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store ptr %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  store { i64, [2 x i64] } %t15, ptr %l3
  %t17 = load { i64, [2 x i64] }, ptr %l3
  %t19 = extractvalue { i64, [2 x i64] } %t17, 0
  %t20 = icmp eq i64 %t19, 3
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t23 = getelementptr { i32 }, ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 118
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l4, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l21
  br label %bb6
bb6:
  %t34 = load i32, ptr %l21, !tbaa !23
  %t35 = sext i32 %t34 to i64
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t37, i64 %t35, i64 %t36)
  br label %bb7
bb7:
  br label %bb33
bb8:
  %t40 = load { i64, [2 x i64] }, ptr %l3
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 1
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb28
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 1
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store ptr %t52, ptr %l30
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t57, i32 %t56)
  store { i64, ptr } %t59, ptr %l33
  br label %bb13
bb13:
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t60, ptr %l5, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t65 = icmp eq i64 %t63, 1
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 0
  %t71 = load i32, ptr %t70, !tbaa !33
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t67, i32 %t71)
  store i1 %t74, ptr %l40
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  %t75 = load i1, ptr %l40, !tbaa !21
  store i1 %t75, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l37, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l2, !tbaa !29
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 0
  %t82 = load i32, ptr %t81, !tbaa !33
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t78, i32 %t82)
  store i32 %t85, ptr %l45
  br label %bb20
bb19:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb20:
  %t86 = load ptr, ptr %l42, !tbaa !29
  %t87 = load i32, ptr %l45, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t88, ptr %l46
  br label %bb21
bb21:
  %t89 = load i1, ptr %l46, !tbaa !21
  store i1 %t89, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t90 = load i1, ptr %l41, !tbaa !21
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l47, !tbaa !29
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 0
  %t96 = load i32, ptr %t95, !tbaa !33
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t92, i32 %t96)
  store i32 %t99, ptr %l50
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t101 = load i32, ptr %l50, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %t100, i32 %t101)
  br label %bb26
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_4e10a6e17fa9b999_b873e8c9bb06b2fd)
  unreachable
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eonlyPath(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i32
  %l31 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca { i64, ptr }
  %l87 = alloca i1
  %l89 = alloca { i64, ptr }
  %l95 = alloca i1
  %l99 = alloca { i64, ptr }
  %l102 = alloca i1
  %l104 = alloca { i64, ptr }
  %l107 = alloca i1
  %l108 = alloca i1
  %l110 = alloca { i64, ptr }
  %l113 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l14, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l18
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = load i32, ptr %l18, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l19
  br label %bb3
bb3:
  %t14 = load i32, ptr %l19, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t21 = icmp sge i64 %t15, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load i32, ptr %l5, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l27
  br label %bb6
bb6:
  %t28 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t30 = trunc i64 18 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb11
bb9:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t37 = load i32, ptr %l5, !tbaa !23
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l34
  br label %bb10
bb10:
  %t41 = load i1, ptr %l34, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l31, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l31, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb16
bb13:
  %t45 = load ptr, ptr %l4, !tbaa !29
  store ptr %t45, ptr %l37, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t47 = load i32, ptr %l5, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l40
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l37, !tbaa !29
  %t52 = load i32, ptr %l40, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l41
  br label %bb15
bb15:
  %t54 = load i32, ptr %l41, !range !{i32 0, i32 6}
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l36, !tbaa !21
  br label %bb16
bb16:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t63 = load ptr, ptr %l4, !tbaa !29
  store ptr %t63, ptr %l46, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l49
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l46, !tbaa !29
  %t70 = load i32, ptr %l49, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l50
  br label %bb21
bb21:
  %t72 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t72, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb27
bb24:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l59, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb26
bb26:
  %t103 = load i64, ptr %l59, !tbaa !24
  store i64 %t103, ptr %l56, !tbaa !24
  br label %bb27
bb27:
  %t104 = load i64, ptr %l56, !tbaa !24
  store i64 %t104, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb29, label %bb30
bb29:
  br label %bb55
bb30:
  br label %bb31
bb31:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t124, ptr %l78, !tbaa !27
  %t125 = load i64, ptr %l3, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i64, ptr %t128, i64 %t125
  %t130 = load i64, ptr %t129, !tbaa !34
  %t133 = icmp eq i64 %t123, %t130
  br i1 %t133, label %bb32, label %bb33
bb32:
  %t135 = load i64, ptr %l3, !tbaa !24
  %t137 = add i64 %t135, 1
  %t138 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t143 = icmp slt i64 %t137, %t140
  br i1 %t143, label %bb34, label %bb35
bb33:
  br label %bb41
bb34:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t146, ptr %l89, !tbaa !27
  %t147 = load i64, ptr %l12, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i32, ptr %t150, i64 %t147
  %t152 = load i32, ptr %t151, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t154 = load i64, ptr %l3, !tbaa !24
  %t156 = add i64 %t154, 1
  %t161 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eonlyPath(ptr %v0, ptr %v1, ptr %t145, i32 %t152, { i64, ptr } %t153, i64 %t156)
  store i1 %t161, ptr %l95
  br label %bb36
bb35:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb37
bb36:
  %t162 = load i1, ptr %l95, !tbaa !21
  %t163 = xor i1 %t162, true
  store i1 %t163, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t165 = load i1, ptr %l87, !tbaa !21
  br i1 %t165, label %bb38, label %bb39
bb38:
  store i1 false, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb54
bb41:
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t168, ptr %l99, !tbaa !27
  %t169 = load i64, ptr %l12, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i32, ptr %t172, i64 %t169
  %t174 = load i32, ptr %t173, !tbaa !33
  %t177 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t167, i32 %t174)
  store i1 %t177, ptr %l102
  br label %bb42
bb42:
  %t178 = load i1, ptr %l102, !tbaa !21
  br i1 %t178, label %bb43, label %bb44
bb43:
  br label %bb54
bb44:
  br label %bb45
bb45:
  %t179 = load ptr, ptr %l4, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t180, ptr %l104, !tbaa !27
  %t181 = load i64, ptr %l12, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i32, ptr %t184, i64 %t181
  %t186 = load i32, ptr %t185, !tbaa !33
  %t189 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t179, i32 %t186)
  store i1 %t189, ptr %l107
  br label %bb46
bb46:
  %t190 = load i1, ptr %l107, !tbaa !21
  br i1 %t190, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb50
bb48:
  %t191 = load ptr, ptr %l4, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t192, ptr %l110, !tbaa !27
  %t193 = load i64, ptr %l12, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t193
  %t198 = load i32, ptr %t197, !tbaa !33
  %t201 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t191, i32 %t198)
  store i1 %t201, ptr %l113
  br label %bb49
bb49:
  %t202 = load i1, ptr %l113, !tbaa !21
  store i1 %t202, ptr %l108, !tbaa !21
  br label %bb50
bb50:
  %t203 = load i1, ptr %l108, !tbaa !21
  br i1 %t203, label %bb51, label %bb52
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l11, !tbaa !24
  br label %bb28
bb55:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_997f49c366488af5_93d2651ee5683809)
  unreachable
bb25:
  br label %bb26
bb26:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb30
bb28:
  %t82 = load i64, ptr %l2, !tbaa !24
  store i64 %t82, ptr %l44, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 10
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l49
  br label %bb29
bb29:
  %t94 = load i64, ptr %l44, !tbaa !24
  %t95 = load i64, ptr %l49, !tbaa !24
  %t96 = icmp sge i64 %t94, %t95
  store i1 %t96, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t98 = load i1, ptr %l43, !tbaa !21
  br i1 %t98, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/load:Loader", ptr %t106, i32 0, i32 10
  %t109 = load i64, ptr %l2, !tbaa !24
  %t112 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l57
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l57, !tbaa !29
  %t115 = getelementptr %"compiler/load:Module", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t118, ptr %l60
  br label %bb35
bb35:
  %t119 = load i1, ptr %l60, !tbaa !21
  %t120 = xor i1 %t119, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownLocalCand(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"compiler/typed:Local"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l24 = alloca ptr
  %l29 = alloca %"compiler/typed:Local"
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l47 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb29
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 114
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t25, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l19
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32, ptr %l4
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 114
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t35, i64 %t39)
  store ptr %t42, ptr %l24
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 7
  %t46 = load i32, ptr %l3, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t51 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t45, i64 %t48)
  store %"compiler/typed:Local" %t51, ptr %l29
  br label %bb8
bb8:
  %t52 = load %"compiler/typed:Local", ptr %l29
  store %"compiler/typed:Local" %t52, ptr %l5
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:Free", ptr %t53, i32 0, i32 101
  %t56 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t59 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t55, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t56)
  store i1 %t59, ptr %l33
  br label %bb9
bb9:
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb12
bb11:
  %t61 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 7}
  %t64 = trunc i64 1 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t69 = load i1, ptr %l34, !tbaa !21
  br i1 %t69, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb15
bb14:
  %t70 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 6
  %t71 = load i1, ptr %t70, !tbaa !21
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t73 = load i1, ptr %l38, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t78, ptr %l42
  br label %bb19
bb19:
  %t79 = load i1, ptr %l42, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb21:
  br label %bb22
bb22:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t84 = load i32, ptr %l2, !tbaa !23
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t82, i32 %t83, i64 -3, i1 false, i32 %t84, i1 false)
  store i64 %t88, ptr %l47
  br label %bb23
bb23:
  %t89 = load i64, ptr %l47, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 12
  %t93 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t92, i64 %t93, i1 true)
  br label %bb24
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 102
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 114
  %t103 = load i64, ptr %t102, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t98, i64 %t99, i64 %t103)
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/free:Free", ptr %t107, i32 0, i32 103
  %t110 = load i64, ptr %l6, !tbaa !24
  %t111 = load i32, ptr %l3, !tbaa !23
  %t113 = sext i32 %t111 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t109, i64 %t110, i64 %t113)
  br label %bb26
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:Free", ptr %t117, i32 0, i32 101
  %t120 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t121 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t119, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t120, i64 %t121)
  br label %bb27
bb27:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 104
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/free:Free", ptr %t128, i32 0, i32 114
  %t131 = load i64, ptr %t130, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t127, i64 %t131, i1 true)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_3f4c383e8983fca5_b7613254c9da681)
  unreachable
bb34:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i1
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %s0, ptr %t12, i32 %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l11
  br label %bb6
bb6:
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %l11)
  store i64 %t18, ptr %l13
  br label %bb7
bb7:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l18
  br label %bb10
bb9:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  %t27 = load i1, ptr %l18, !tbaa !21
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l15, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t47 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t47, ptr %l28
  br label %bb20
bb20:
  %t48 = load i1, ptr %l28, !tbaa !21
  store i1 %t48, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 8}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l30, !tbaa !21
  br label %bb23
bb23:
  %t57 = load i1, ptr %l30, !tbaa !21
  br i1 %t57, label %bb24, label %bb25
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  store i1 %t68, ptr %l37
  br label %bb27
bb27:
  %t69 = load i1, ptr %l37, !tbaa !21
  store i1 %t69, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb29, label %bb30
bb29:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 4
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb30
bb30:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb31, label %bb32
bb31:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t85, ptr %t89)
  store i1 %t92, ptr %l47
  br label %bb34
bb34:
  %t93 = load i1, ptr %l47, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb38
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Elem", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t101 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  store i1 %t101, ptr %l52
  br label %bb37
bb37:
  %t102 = load i1, ptr %l52, !tbaa !21
  store i1 %t102, ptr %l48, !tbaa !21
  br label %bb38
bb38:
  %t103 = load i1, ptr %l48, !tbaa !21
  store i1 %t103, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb40, label %bb41
bb40:
  %t108 = load ptr, ptr %l53, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 8}
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l54, !tbaa !21
  br label %bb41
bb41:
  %t112 = load i1, ptr %l54, !tbaa !21
  br i1 %t112, label %bb42, label %bb43
bb42:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Payload", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t126 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t119, ptr %t123)
  store i1 %t126, ptr %l62
  br label %bb45
bb45:
  %t127 = load i1, ptr %l62, !tbaa !21
  store i1 %t127, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t128 = load ptr, ptr %l1, !tbaa !29
  store ptr %t128, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t129 = load ptr, ptr %l63, !tbaa !29
  %t130 = icmp ne ptr %t129, null
  br i1 %t130, label %bb47, label %bb48
bb47:
  %t132 = load ptr, ptr %l63, !tbaa !29
  %t133 = load i64, ptr %t132, !range !{i64 0, i64 8}
  %t135 = icmp eq i64 %t133, 6
  store i1 %t135, ptr %l64, !tbaa !21
  br label %bb48
bb48:
  %t136 = load i1, ptr %l64, !tbaa !21
  br i1 %t136, label %bb49, label %bb50
bb49:
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t139, i32 0, i32 2
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l6, !tbaa !29
  %t147 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t143, ptr %t144)
  store i1 %t147, ptr %l71
  br label %bb52
bb52:
  %t148 = load i1, ptr %l71, !tbaa !21
  store i1 %t148, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a4118a366f7ca1d5_524409770a0878b9)
  unreachable
bb54:
  %t149 = load i1, ptr %l7, !tbaa !21
  store i1 %t149, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca i32
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l49 = alloca i64
  %l50 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 3
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = load i32, ptr %l18, !tbaa !23
  %t30 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t27, i32 %t28, i64 %t26)
  store i64 %t30, ptr %l20
  br label %bb7
bb7:
  %t31 = load i64, ptr %l20, !tbaa !24
  store i64 %t31, ptr %l7, !tbaa !24
  br label %bb33
bb8:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 8}
  %t39 = icmp eq i64 %t37, 4
  store i1 %t39, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l27, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l28, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t52)
  store i32 %t54, ptr %l31
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l28, !tbaa !29
  %t56 = load i32, ptr %l31, !tbaa !23
  %t57 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t57, ptr %l32
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l27, !tbaa !29
  %t59 = load i32, ptr %l32, !tbaa !23
  %t60 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t58, i32 %t59, i64 -1)
  store i64 %t60, ptr %l33
  br label %bb16
bb16:
  %t61 = load i64, ptr %l33, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  br label %bb33
bb17:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 8}
  %t69 = icmp eq i64 %t67, 1
  store i1 %t69, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t70 = load i1, ptr %l35, !tbaa !21
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t73, i32 0, i32 2
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l5, !tbaa !24
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t79, i32 0, i32 3
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l6, !tbaa !23
  br label %bb22
bb21:
  br label %bb28
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 105
  store ptr %t85, ptr %l44, !tbaa !29
  %t86 = load i64, ptr %l5, !tbaa !24
  %t87 = load i32, ptr %l6, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t92 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t86, i64 %t89)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t92, ptr %l48
  br label %bb23
bb23:
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l48
  %t95 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t93, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t94)
  %t96 = extractvalue { i32, i64 } %t95, 1
  %t97 = extractvalue { i32, i64 } %t95, 0
  store i32 %t97, ptr %l50
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb25, label %ok.99, !prof !99
ok.99:
  store i64 %t96, ptr %l49
  br label %bb24
bb24:
  %t100 = load i64, ptr %l49, !tbaa !24
  store i64 %t100, ptr %l42, !tbaa !24
  br label %bb27
bb25:
  br label %bb26
bb26:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb27
bb27:
  %t101 = load i64, ptr %l42, !tbaa !24
  store i64 %t101, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5c44d6b41b035ab1_55f561a861d07b6d)
  unreachable
bb33:
  %t102 = load i64, ptr %l7, !tbaa !24
  store i64 %t102, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 6
  %t5 = load %"compiler/source:Span", ptr %t4
  %t9 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %t3, %"compiler/source:Span" %t5)
  store { i64, ptr } %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca i32
  %l26 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca i32
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 116
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 119
  store ptr %t8, ptr %l9, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l11
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb3:
  %t12 = load i32, ptr %l1, !tbaa !23
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t12)
  store i32 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = sext i32 %t16 to i64
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t20 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t17)
  store i1 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i1, ptr %l15, !tbaa !21
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l7, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t25)
  store ptr %t27, ptr %l18
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t28 = load i32, ptr %l1, !tbaa !23
  %t30 = inttoptr i64 0 to ptr
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s1, ptr %t30, ptr %t31, i32 %t28)
  store { i64, ptr } %t33, ptr %l21
  br label %bb10
bb10:
  %t34 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t36 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t34, i64 %t35)
  %t44 = getelementptr i8, ptr %t43, i64 %t35
  call void @olang_textcopy(ptr %t44, ptr %t37, i64 %t38)
  %t45 = getelementptr i8, ptr %t44, i64 %t38
  call void @olang_textcopy(ptr %t45, ptr %t40, i64 %t41)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = call i32 @std_2fio_2ePutErr(ptr %s1, { i64, ptr } %t54)
  store i32 %t56, ptr %l24
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb12, label %ok.58, !prof !99
ok.58:
  br label %bb11
bb11:
  br label %bb16
bb12:
  %t59 = load i32, ptr %l24, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  store i1 %t62, ptr %l26, !tbaa !21
  %t63 = load i32, ptr %l24, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  br i1 %t66, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t68)
  store ptr %t70, ptr %l30
  br label %bb18
bb18:
  %t71 = load i32, ptr %l1, !tbaa !23
  %t72 = load ptr, ptr %l30, !tbaa !29
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eValueParts(ptr %v0, ptr %s4, ptr %t72, i32 %t71)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l32
  br label %bb19
bb19:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t76 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t76
  store ptr %t76, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb20
bb20:
  %t78 = load i64, ptr %l3, !tbaa !24
  store i64 %t78, ptr %l34, !tbaa !24
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s4, ptr %t79)
  store i64 %t81, ptr %l36
  br label %bb21
bb21:
  %t82 = load i64, ptr %l34, !tbaa !24
  %t83 = load i64, ptr %l36, !tbaa !24
  %t84 = icmp slt i64 %t82, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb22, label %bb23
bb22:
  br label %bb28
bb23:
  br label %bb24
bb24:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t89 = load i64, ptr %l3, !tbaa !24
  %t92 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s4, ptr %t88, i64 %t89)
  store i32 %t92, ptr %l41
  br label %bb25
bb25:
  %t93 = load i32, ptr %l41, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/free:Free", ptr %t94, i32 0, i32 119
  %t99 = sext i32 %t93 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t96, i64 %t99, i1 true)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t102 = load i64, ptr %l3, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l3, !tbaa !24
  br label %bb20
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l48 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l107 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i32
  %l130 = alloca i1
  %l140 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca i32
  %l149 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l165 = alloca i1
  %l168 = alloca i1
  %l174 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l189 = alloca i1
  %l192 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca i32
  %l203 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l25
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l25, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l28
  br label %bb2
bb2:
  %t10 = load i32, ptr %l28, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l31
  br label %bb3
bb3:
  %t16 = load i32, ptr %l31, !range !{i32 0, i32 33}
  store i32 %t16, ptr %l4
  %t17 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t24 = trunc i64 25 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l34, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l34, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb9
bb8:
  %t28 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t30 = trunc i64 29 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l37, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb12
bb11:
  %t34 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t36 = trunc i64 0 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l40, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t41 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t43 = trunc i64 20 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb16, label %bb17
bb16:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l48
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t51 = load i1, ptr %l48, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l50, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l53
  br label %bb22
bb22:
  %t59 = load ptr, ptr %l50, !tbaa !29
  %t60 = load i32, ptr %l53, !tbaa !23
  %t61 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t61, ptr %l54
  br label %bb23
bb23:
  %t62 = load i1, ptr %l54, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
bb24:
  %t63 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t65 = trunc i64 19 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb25, label %bb26
bb25:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l57, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i32, ptr %l3, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l60
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t74 = load ptr, ptr %l57, !tbaa !29
  %t75 = load i32, ptr %l60, !tbaa !23
  %t76 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t76, ptr %l61
  br label %bb28
bb28:
  %t77 = load i1, ptr %l61, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
bb29:
  %t78 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t80 = trunc i64 22 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb32
bb31:
  %t83 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t85 = trunc i64 23 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l64, !tbaa !21
  br label %bb32
bb32:
  %t88 = load i1, ptr %l64, !tbaa !21
  br i1 %t88, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l2, !tbaa !29
  store ptr %t89, ptr %l67, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l70
  br label %bb35
bb34:
  br label %bb47
bb35:
  %t95 = load ptr, ptr %l67, !tbaa !29
  %t96 = load i32, ptr %l70, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t95, i32 %t96)
  store { i64, ptr } %t97, ptr %l71
  br label %bb36
bb36:
  %t98 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t98, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb37
bb37:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb38, label %bb39
bb38:
  br label %bb46
bb39:
  br label %bb40
bb40:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t111, ptr %l78, !tbaa !27
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t112
  %t117 = load i32, ptr %t116, !tbaa !33
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t123 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t119, i32 %t117)
  store i1 %t123, ptr %l83
  br label %bb41
bb41:
  %t124 = load i1, ptr %l83, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l6, !tbaa !24
  br label %bb37
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  %t133 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t135 = trunc i64 24 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb48, label %bb49
bb48:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l91, !tbaa !29
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t140 = load i32, ptr %l3, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l94
  br label %bb50
bb49:
  br label %bb62
bb50:
  %t144 = load ptr, ptr %l91, !tbaa !29
  %t145 = load i32, ptr %l94, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t144, i32 %t145)
  store { i64, ptr } %t146, ptr %l95
  br label %bb51
bb51:
  %t147 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t147, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  %t152 = load i64, ptr %l10, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb53, label %bb54
bb53:
  br label %bb61
bb54:
  br label %bb55
bb55:
  %t160 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t160, ptr %l102, !tbaa !27
  %t161 = load i64, ptr %l10, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 %t161
  %t166 = load i32, ptr %t165, !tbaa !33
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t168, i32 %t166)
  store i1 %t172, ptr %l107
  br label %bb56
bb56:
  %t173 = load i1, ptr %l107, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb57, label %bb58
bb57:
  store i1 false, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l10, !tbaa !24
  br label %bb52
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  %t182 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t184 = trunc i64 18 to i32
  %t185 = icmp eq i32 %t182, %t184
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb63, label %bb64
bb63:
  store i1 true, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t191 = load i32, ptr %l3, !tbaa !23
  %t194 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t194, ptr %l119
  br label %bb66
bb66:
  %t195 = load i1, ptr %l119, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb67, label %bb68
bb67:
  store i1 false, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/free:Free", ptr %t199, i32 0, i32 18
  %t202 = load i32, ptr %l3, !tbaa !23
  %t205 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t201, i32 %t202)
  %t206 = extractvalue { i32, i64 } %t205, 1
  %t207 = extractvalue { i32, i64 } %t205, 0
  store i32 %t207, ptr %l127
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb71, label %ok.209, !prof !99
ok.209:
  store i64 %t206, ptr %l126
  br label %bb70
bb70:
  %t210 = load i64, ptr %l126, !tbaa !24
  store i64 %t210, ptr %l122, !tbaa !24
  br label %bb73
bb71:
  br label %bb72
bb72:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb73
bb73:
  %t211 = load i64, ptr %l122, !tbaa !24
  store i64 %t211, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t214 = icmp eq i64 %t212, 1
  br i1 %t214, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb76
bb75:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = icmp eq i64 %t216, 3
  store i1 %t218, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t220 = load i1, ptr %l130, !tbaa !21
  br i1 %t220, label %bb77, label %bb78
bb77:
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = icmp eq i64 %t222, 2
  br i1 %t224, label %bb80, label %bb81
bb80:
  store i1 false, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/free:Free", ptr %t227, i32 0, i32 18
  %t230 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t229, i32 %t230, i64 1)
  br label %bb83
bb83:
  store i1 true, ptr %l14, !tbaa !21
  %t233 = load ptr, ptr %l2, !tbaa !29
  store ptr %t233, ptr %l140, !tbaa !29
  %t234 = load ptr, ptr %l2, !tbaa !29
  %t235 = load i32, ptr %l3, !tbaa !23
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t234, i32 %t235)
  store i32 %t238, ptr %l143
  br label %bb84
bb84:
  %t239 = load ptr, ptr %l140, !tbaa !29
  %t240 = load i32, ptr %l143, !tbaa !23
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t241, ptr %l144
  br label %bb85
bb85:
  %t242 = load i32, ptr %l144, !range !{i32 0, i32 6}
  store i32 %t242, ptr %l15
  %t243 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t245 = trunc i64 0 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb86, label %bb87
bb86:
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t249 = load i32, ptr %l3, !tbaa !23
  %t252 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t248, i32 %t249)
  store i1 %t252, ptr %l149
  br label %bb88
bb87:
  %t253 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t255 = trunc i64 1 to i32
  %t256 = icmp eq i32 %t253, %t255
  br i1 %t256, label %bb107, label %bb108
bb88:
  %t258 = load i1, ptr %l149, !tbaa !21
  br i1 %t258, label %bb89, label %bb90
bb89:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb91
bb90:
  br label %bb91
bb91:
  %t259 = load ptr, ptr %l2, !tbaa !29
  store ptr %t259, ptr %l150, !tbaa !29
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t261 = load i32, ptr %l3, !tbaa !23
  %t264 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t264, ptr %l153
  br label %bb92
bb92:
  %t265 = load ptr, ptr %l150, !tbaa !29
  %t266 = load i32, ptr %l153, !tbaa !23
  %t267 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t265, i32 %t266)
  store { i64, ptr } %t267, ptr %l154
  br label %bb93
bb93:
  %t268 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t268, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  store i64 %t271, ptr %l18, !tbaa !24
  br label %bb94
bb94:
  %t273 = load i64, ptr %l17, !tbaa !24
  %t274 = load i64, ptr %l18, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb95, label %bb96
bb95:
  br label %bb106
bb96:
  br label %bb97
bb97:
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t281, ptr %l161, !tbaa !27
  %t282 = load i64, ptr %l17, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i32, ptr %t285, i64 %t282
  %t287 = load i32, ptr %t286, !tbaa !33
  store i32 %t287, ptr %l19, !tbaa !23
  %t289 = load i1, ptr %l14, !tbaa !21
  br i1 %t289, label %bb98, label %bb99
bb98:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l19, !tbaa !23
  %t295 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t291, i32 %t292)
  store i1 %t295, ptr %l168
  br label %bb100
bb99:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb101
bb100:
  %t296 = load i1, ptr %l168, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l165, !tbaa !21
  br label %bb101
bb101:
  %t299 = load i1, ptr %l165, !tbaa !21
  br i1 %t299, label %bb102, label %bb103
bb102:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb104
bb103:
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t300 = load i64, ptr %l17, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l17, !tbaa !24
  br label %bb94
bb106:
  br label %bb128
bb107:
  %t304 = load ptr, ptr %l2, !tbaa !29
  store ptr %t304, ptr %l174, !tbaa !29
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t306 = load i32, ptr %l3, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l177
  br label %bb109
bb108:
  %t310 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t312 = trunc i64 4 to i32
  %t313 = icmp eq i32 %t310, %t312
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb124, label %bb125
bb109:
  %t317 = load ptr, ptr %l174, !tbaa !29
  %t318 = load i32, ptr %l177, !tbaa !23
  %t319 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t317, i32 %t318)
  store { i64, ptr } %t319, ptr %l178
  br label %bb110
bb110:
  %t320 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t320, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  store i64 %t323, ptr %l22, !tbaa !24
  br label %bb111
bb111:
  %t325 = load i64, ptr %l21, !tbaa !24
  %t326 = load i64, ptr %l22, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb112, label %bb113
bb112:
  br label %bb123
bb113:
  br label %bb114
bb114:
  %t333 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t333, ptr %l185, !tbaa !27
  %t334 = load i64, ptr %l21, !tbaa !24
  %t336 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i32, ptr %t337, i64 %t334
  %t339 = load i32, ptr %t338, !tbaa !33
  store i32 %t339, ptr %l23, !tbaa !23
  %t341 = load i1, ptr %l14, !tbaa !21
  br i1 %t341, label %bb115, label %bb116
bb115:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l23, !tbaa !23
  %t347 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l192
  br label %bb117
bb116:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb118
bb117:
  %t348 = load i1, ptr %l192, !tbaa !21
  %t349 = xor i1 %t348, true
  store i1 %t349, ptr %l189, !tbaa !21
  br label %bb118
bb118:
  %t351 = load i1, ptr %l189, !tbaa !21
  br i1 %t351, label %bb119, label %bb120
bb119:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb121
bb120:
  br label %bb121
bb121:
  br label %bb122
bb122:
  %t352 = load i64, ptr %l21, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l21, !tbaa !24
  br label %bb111
bb123:
  br label %bb127
bb124:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb126
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/free:Free", ptr %t356, i32 0, i32 18
  store ptr %t358, ptr %l200, !tbaa !29
  %t359 = load i32, ptr %l3, !tbaa !23
  store i32 %t359, ptr %l201, !tbaa !23
  %t360 = load i1, ptr %l14, !tbaa !21
  br i1 %t360, label %bb129, label %bb130
bb129:
  store i64 3, ptr %l203, !tbaa !24
  br label %bb131
bb130:
  store i64 2, ptr %l203, !tbaa !24
  br label %bb131
bb131:
  %t362 = load ptr, ptr %l200, !tbaa !29
  %t363 = load i32, ptr %l201, !tbaa !23
  %t364 = load i64, ptr %l203, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t362, i32 %t363, i64 %t364)
  br label %bb132
bb132:
  %t365 = load i1, ptr %l14, !tbaa !21
  store i1 %t365, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esave(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l76 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i64
  %l88 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 3
  store ptr %t9, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l6, !tbaa !24
  store i64 %t11, ptr %l25, !tbaa !24
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l27
  br label %bb3
bb3:
  %t15 = load i64, ptr %l25, !tbaa !24
  %t16 = load i64, ptr %l27, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v1, ptr %v1, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l32
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l32, !tbaa !29
  store ptr %t26, ptr %l7, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l33, !tbaa !24
  %t28 = load ptr, ptr %l7, !tbaa !29
  store ptr %t28, ptr %l34, !tbaa !29
  %t29 = ptrtoint ptr %v1 to i64
  store i64 %t29, ptr %l35, !tbaa !24
  %t30 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l34, !tbaa !29
  %t33 = call ptr @__olang_region_or(ptr %t32, ptr %v1)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l35, !tbaa !24
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l7, !tbaa !29
  %t36 = load i64, ptr %l35
  %t37 = inttoptr i64 %t36 to ptr
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t37, ptr %t35)
  store i64 %t39, ptr %l38
  br label %bb10
bb10:
  %t40 = load i64, ptr %l33, !tbaa !24
  %t41 = load i64, ptr %l38, !tbaa !24
  %t42 = add i64 %t40, %t41
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l6, !tbaa !24
  br label %bb2
bb12:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l43, !tbaa !24
  %t51 = load i64, ptr %l43, !tbaa !24
  %t52 = icmp sge i64 %t51, 0
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load i64, ptr %l43, !tbaa !24
  %t55 = icmp sle i64 %t54, 1152921504606846975
  br i1 %t55, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_cba1607a5f8c25be_1da50212bb736ed2)
  unreachable
bb15:
  %t57 = load i64, ptr %l43, !tbaa !24
  %t58 = mul i64 %t57, 8
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l8, !tbaa !27
  %t63 = load i64, ptr %l4, !tbaa !24
  store i64 %t63, ptr %l47, !tbaa !24
  %t64 = load i64, ptr %l47, !tbaa !24
  %t65 = icmp sge i64 %t64, 0
  br i1 %t65, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_cba1607a5f8c25be_1da50212bb736ed2)
  unreachable
bb17:
  %t67 = load i64, ptr %l47, !tbaa !24
  %t68 = icmp sle i64 %t67, 1152921504606846975
  br i1 %t68, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7)
  unreachable
bb19:
  %t70 = load i64, ptr %l47, !tbaa !24
  %t71 = mul i64 %t70, 8
  %t72 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  store i64 %t76, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t78 = load i64, ptr %l12, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7)
  unreachable
bb21:
  %t84 = load i64, ptr %l13, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb26
bb23:
  %t88 = load i64, ptr %l12, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l13, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l58, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb25
bb25:
  %t104 = load i64, ptr %l58, !tbaa !24
  store i64 %t104, ptr %l55, !tbaa !24
  br label %bb26
bb26:
  %t105 = load i64, ptr %l55, !tbaa !24
  store i64 %t105, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb27
bb27:
  %t106 = load i64, ptr %l15, !tbaa !24
  %t107 = load i64, ptr %l14, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb28, label %bb29
bb28:
  br label %bb45
bb29:
  br label %bb30
bb30:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l16, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t124, ptr %l76, !tbaa !27
  %t125 = load i64, ptr %l16, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i64, ptr %t130, i64 %t125
  store i64 %t126, ptr %t131, !tbaa !34
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr %"compiler/free:walker", ptr %t132, i32 0, i32 3
  %t135 = load i64, ptr %l16, !tbaa !24
  %t138 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v1, ptr %v1, ptr %t134, i64 %t135)
  store ptr %t138, ptr %l82
  br label %bb31
bb31:
  %t139 = load ptr, ptr %l82, !tbaa !29
  store ptr %t139, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb32
bb32:
  %t140 = load i64, ptr %l18, !tbaa !24
  store i64 %t140, ptr %l83, !tbaa !24
  %t141 = load ptr, ptr %l17, !tbaa !29
  store ptr %t141, ptr %l84, !tbaa !29
  %t142 = ptrtoint ptr %v1 to i64
  store i64 %t142, ptr %l85, !tbaa !24
  %t143 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t143, label %bb33, label %bb34
bb33:
  %t145 = load ptr, ptr %l84, !tbaa !29
  %t146 = call ptr @__olang_region_or(ptr %t145, ptr %v1)
  %t147 = ptrtoint ptr %t146 to i64
  store i64 %t147, ptr %l85, !tbaa !24
  br label %bb34
bb34:
  %t148 = load ptr, ptr %l17, !tbaa !29
  %t149 = load i64, ptr %l85
  %t150 = inttoptr i64 %t149 to ptr
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t150, ptr %t148)
  store i64 %t152, ptr %l88
  br label %bb35
bb35:
  %t153 = load i64, ptr %l83, !tbaa !24
  %t154 = load i64, ptr %l88, !tbaa !24
  %t155 = icmp slt i64 %t153, %t154
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb36, label %bb37
bb36:
  br label %bb43
bb37:
  br label %bb38
bb38:
  %t159 = load ptr, ptr %l17, !tbaa !29
  store ptr %t159, ptr %l91, !tbaa !29
  %t160 = ptrtoint ptr %v1 to i64
  store i64 %t160, ptr %l92, !tbaa !24
  %t161 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t161, label %bb39, label %bb40
bb39:
  %t163 = load ptr, ptr %l91, !tbaa !29
  %t164 = call ptr @__olang_region_or(ptr %t163, ptr %v1)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l92, !tbaa !24
  br label %bb40
bb40:
  %t166 = load ptr, ptr %l17, !tbaa !29
  %t167 = load i64, ptr %l18, !tbaa !24
  %t168 = load i64, ptr %l92
  %t169 = inttoptr i64 %t168 to ptr
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t169, ptr %t166, i64 %t167)
  store i64 %t172, ptr %l96
  br label %bb41
bb41:
  %t173 = load i64, ptr %l96, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t174, ptr %l97, !tbaa !27
  %t175 = load i64, ptr %l10, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i64, ptr %t180, i64 %t175
  store i64 %t173, ptr %t181, !tbaa !34
  %t182 = load i64, ptr %l10, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l10, !tbaa !24
  br label %bb42
bb42:
  %t186 = load i64, ptr %l18, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l18, !tbaa !24
  br label %bb32
bb43:
  br label %bb44
bb44:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l15, !tbaa !24
  br label %bb27
bb45:
  %t194 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t194, ptr %l106, !tbaa !27
  %t195 = load i64, ptr %l3, !tbaa !24
  %t196 = load i64, ptr %l10, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i64, ptr %t200, i64 %t195
  store i64 %t196, ptr %t201, !tbaa !34
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:Free", ptr %t202, i32 0, i32 98
  %t205 = load i64, ptr %l2, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t204, i64 %t205, { i64, ptr } %t206)
  br label %bb46
bb46:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/free:Free", ptr %t210, i32 0, i32 99
  %t213 = load i64, ptr %l2, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t212, i64 %t213, { i64, ptr } %t214)
  br label %bb47
bb47:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eshown(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i1
  %l23 = alloca i1
  %l27 = alloca { i64, ptr }
  %l40 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 23
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 5
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t18 = icmp ne i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 23
  %t30 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t29, i64 %t31)
  store i1 %t34, ptr %l23
  br label %bb11
bb11:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s0, ptr %t37, i64 %t39)
  store { i64, ptr } %t42, ptr %l27
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store ptr @G_2ecompiler_2ffree_2eRemovalNames, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t45 = load ptr, ptr %l3
  store i64 9, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l3
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = getelementptr [9 x { i64, ptr }], ptr %t56, i64 0, i64 %t57
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = load ptr, ptr @__olang_prog_scope
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t65, ptr %s0, { i64, ptr } %t61, { i64, ptr } %t64)
  store i1 %t68, ptr %l40
  br label %bb20
bb20:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb16
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca { i64, [2 x i64] }
  %l39 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l64 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l78 = alloca { i64, [2 x i64] }
  %l79 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca { i64, [2 x i64] }
  %l88 = alloca ptr
  %l89 = alloca i1
  %l97 = alloca { i64, [2 x i64] }
  %l98 = alloca ptr
  %l99 = alloca i1
  %l108 = alloca { i64, [2 x i64] }
  %l109 = alloca ptr
  %l110 = alloca i64
  %l116 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t78 = alloca { i64, [2 x i64] }, align 8
  %t176 = alloca { i64, [2 x i64] }, align 8
  %t245 = alloca { i64, [2 x i64] }, align 8
  %t259 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l14, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l16, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 18}
  %t16 = icmp eq i64 %t14, 5
  store i1 %t16, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l17, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t20, i32 0, i32 2
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Plan", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Promote", ptr %t28, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i64 %t33
  %t38 = load { i64, [2 x i64] }, ptr %t37
  store { i64, [2 x i64] } %t38, ptr %l15
  br label %bb65
bb7:
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t41 = load ptr, ptr %l28, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load ptr, ptr %l28, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 7
  store i1 %t47, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l29, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Make", ptr %t55, i32 0, i32 4
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = icmp sge i32 %t58, 0
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Plan", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l39, !tbaa !27
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Make", ptr %t66, i32 0, i32 4
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = sext i32 %t69 to i64
  %t73 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i64 %t71
  %t76 = load { i64, [2 x i64] }, ptr %t75
  store { i64, [2 x i64] } %t76, ptr %l37
  br label %bb15
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [2 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t80 = load { i64, [2 x i64] }, ptr %t78
  store { i64, [2 x i64] } %t80, ptr %l37
  br label %bb15
bb15:
  %t82 = load { i64, [2 x i64] }, ptr %l37
  store { i64, [2 x i64] } %t82, ptr %l15
  br label %bb65
bb16:
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t84 = load ptr, ptr %l45, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb17, label %bb18
bb17:
  %t87 = load ptr, ptr %l45, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 16
  store i1 %t90, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t91 = load i1, ptr %l46, !tbaa !21
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l6, !tbaa !29
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Plan", ptr %t98, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l52, !tbaa !27
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Text", ptr %t102, i32 0, i32 1
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, [2 x i64] }, ptr %t110, i64 %t107
  %t112 = load { i64, [2 x i64] }, ptr %t111
  store { i64, [2 x i64] } %t112, ptr %l15
  br label %bb65
bb22:
  %t114 = load ptr, ptr %l2, !tbaa !29
  store ptr %t114, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t115 = load ptr, ptr %l57, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb23, label %bb24
bb23:
  %t118 = load ptr, ptr %l57, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 18}
  %t121 = icmp eq i64 %t119, 8
  store i1 %t121, ptr %l58, !tbaa !21
  br label %bb24
bb24:
  %t122 = load i1, ptr %l58, !tbaa !21
  br i1 %t122, label %bb25, label %bb26
bb25:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Plan", ptr %t129, i32 0, i32 0
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l64, !tbaa !27
  %t133 = load ptr, ptr %l7, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Collect", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %t135, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t140 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, [2 x i64] }, ptr %t141, i64 %t138
  %t143 = load { i64, [2 x i64] }, ptr %t142
  store { i64, [2 x i64] } %t143, ptr %l15
  br label %bb65
bb28:
  %t145 = load ptr, ptr %l2, !tbaa !29
  store ptr %t145, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t146 = load ptr, ptr %l69, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb29, label %bb30
bb29:
  %t149 = load ptr, ptr %l69, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 6
  store i1 %t152, ptr %l70, !tbaa !21
  br label %bb30
bb30:
  %t153 = load i1, ptr %l70, !tbaa !21
  br i1 %t153, label %bb31, label %bb32
bb31:
  %t154 = load ptr, ptr %l2, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb40
bb33:
  %t160 = load ptr, ptr %l8, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Call", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %t162, !tbaa !23
  %t165 = icmp sge i32 %t163, 0
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l3, !tbaa !29
  store ptr %t167, ptr %l79, !tbaa !29
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Call", ptr %t168, i32 0, i32 2
  %t171 = load i32, ptr %t170, !tbaa !23
  store i32 %t171, ptr %l81, !tbaa !23
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l82, !tbaa !29
  %t173 = load ptr, ptr %l8, !tbaa !29
  %t175 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t173)
  store i64 %t175, ptr %l84
  br label %bb36
bb35:
  store { i64, [2 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t178 = load { i64, [2 x i64] }, ptr %t176
  store { i64, [2 x i64] } %t178, ptr %l78
  br label %bb39
bb36:
  %t180 = load ptr, ptr %l82, !tbaa !29
  %t181 = load i64, ptr %l84, !tbaa !24
  %t182 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t180, i64 %t181)
  store i64 %t182, ptr %l85
  br label %bb37
bb37:
  %t183 = load ptr, ptr %l79, !tbaa !29
  %t184 = load i32, ptr %l81, !tbaa !23
  %t185 = load i64, ptr %l85, !tbaa !24
  %t186 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t183, i32 %t184, i64 %t185)
  store { i64, [2 x i64] } %t186, ptr %l86
  br label %bb38
bb38:
  %t187 = load { i64, [2 x i64] }, ptr %l86
  store { i64, [2 x i64] } %t187, ptr %l78
  br label %bb39
bb39:
  %t188 = load { i64, [2 x i64] }, ptr %l78
  store { i64, [2 x i64] } %t188, ptr %l15
  br label %bb65
bb40:
  %t189 = load ptr, ptr %l2, !tbaa !29
  store ptr %t189, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t190 = load ptr, ptr %l88, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb41, label %bb42
bb41:
  %t193 = load ptr, ptr %l88, !tbaa !29
  %t194 = load i64, ptr %t193, !range !{i64 0, i64 18}
  %t196 = icmp eq i64 %t194, 17
  store i1 %t196, ptr %l89, !tbaa !21
  br label %bb42
bb42:
  %t197 = load i1, ptr %l89, !tbaa !21
  br i1 %t197, label %bb43, label %bb44
bb43:
  %t198 = load ptr, ptr %l2, !tbaa !29
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t200, i32 0, i32 2
  %t202 = load ptr, ptr %t201
  store ptr %t202, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i64, ptr %l1, !tbaa !24
  %t206 = load ptr, ptr %l9, !tbaa !29
  %t210 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t204, i64 %t205, ptr %t206)
  store { i64, [2 x i64] } %t210, ptr %l97
  br label %bb46
bb46:
  %t211 = load { i64, [2 x i64] }, ptr %l97
  store { i64, [2 x i64] } %t211, ptr %l15
  br label %bb65
bb47:
  %t212 = load ptr, ptr %l2, !tbaa !29
  store ptr %t212, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t213 = load ptr, ptr %l98, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb48, label %bb49
bb48:
  %t216 = load ptr, ptr %l98, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 18}
  %t219 = icmp eq i64 %t217, 12
  store i1 %t219, ptr %l99, !tbaa !21
  br label %bb49
bb49:
  %t220 = load i1, ptr %l99, !tbaa !21
  br i1 %t220, label %bb50, label %bb51
bb50:
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t223, i32 0, i32 2
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l10, !tbaa !29
  br label %bb52
bb51:
  br label %bb60
bb52:
  %t227 = load ptr, ptr %l10, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Seq", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb53, label %bb54
bb53:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l109, !tbaa !29
  %t237 = load i64, ptr %l1, !tbaa !24
  store i64 %t237, ptr %l110, !tbaa !24
  %t238 = load ptr, ptr %l10, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Seq", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = icmp eq ptr %t241, null
  br i1 %t243, label %bb55, label %bb56
bb54:
  store { i64, [2 x i64] } zeroinitializer, ptr %t245
  %t246 = getelementptr { i64, [2 x i64] }, ptr %t245, i32 0, i32 0
  store i64 0, ptr %t246
  %t247 = load { i64, [2 x i64] }, ptr %t245
  store { i64, [2 x i64] } %t247, ptr %l108
  br label %bb59
bb55:
  call void @__olang_check_failed(ptr @olang_loc_ebe5ee6b39eee92e_4ec5471030d8b4f2)
  unreachable
bb56:
  br label %bb57
bb57:
  %t249 = load ptr, ptr %l10, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Seq", ptr %t249, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t253 = load ptr, ptr %l109, !tbaa !29
  %t254 = load i64, ptr %l110, !tbaa !24
  %t256 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t253, i64 %t254, ptr %t252)
  store { i64, [2 x i64] } %t256, ptr %l116
  br label %bb58
bb58:
  %t257 = load { i64, [2 x i64] }, ptr %l116
  store { i64, [2 x i64] } %t257, ptr %l108
  br label %bb59
bb59:
  %t258 = load { i64, [2 x i64] }, ptr %l108
  store { i64, [2 x i64] } %t258, ptr %l15
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store { i64, [2 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [2 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t261 = load { i64, [2 x i64] }, ptr %t259
  store { i64, [2 x i64] } %t261, ptr %l15
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_c32ca46bf6d65f0c_9a54b76873cd9ad0)
  unreachable
bb65:
  %t263 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t263, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b4c0d703fa684531_272a8f4f39064c15)
  unreachable
bb25:
  br label %bb26
bb26:
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l76 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l91 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l104 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb100
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 17}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb17
bb8:
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t39 = load ptr, ptr %l29, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l29, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 17}
  %t45 = icmp eq i64 %t43, 2
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l6, !tbaa !29
  br label %bb17
bb12:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 15
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l6, !tbaa !29
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t72 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i1 %t72, ptr %l43
  br label %bb18
bb18:
  %t73 = load i1, ptr %l43, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb98
bb22:
  %t75 = load ptr, ptr %l5, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t76 = load ptr, ptr %l45, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load ptr, ptr %l45, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 17}
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l7, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb36
bb27:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t100 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t100, ptr %l55
  br label %bb28
bb28:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb32
bb30:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t106 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l59
  br label %bb31
bb31:
  %t107 = load i1, ptr %l59, !tbaa !21
  store i1 %t107, ptr %l56, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l56, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb98
bb36:
  %t110 = load ptr, ptr %l5, !tbaa !29
  store ptr %t110, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t111 = load ptr, ptr %l61, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l61, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 17}
  %t117 = icmp eq i64 %t115, 3
  store i1 %t117, ptr %l62, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l62, !tbaa !21
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = getelementptr { i64, [3 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l9, !tbaa !29
  br label %bb41
bb40:
  br label %bb60
bb41:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l9, !tbaa !29
  %t128 = getelementptr %"compiler/typed:If", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t132 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t125, ptr %t129)
  store i1 %t132, ptr %l70
  br label %bb42
bb42:
  %t133 = load i1, ptr %l70, !tbaa !21
  br i1 %t133, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb46
bb44:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l9, !tbaa !29
  %t137 = getelementptr %"compiler/typed:If", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Block", ptr %t138, i32 0, i32 1
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t144 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t134, { i64, ptr } %t141)
  store i1 %t144, ptr %l76
  br label %bb45
bb45:
  %t145 = load i1, ptr %l76, !tbaa !21
  store i1 %t145, ptr %l71, !tbaa !21
  br label %bb46
bb46:
  %t146 = load i1, ptr %l71, !tbaa !21
  br i1 %t146, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t148 = load ptr, ptr %l9, !tbaa !29
  %t150 = getelementptr %"compiler/typed:If", ptr %t148, i32 0, i32 2
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb50, label %bb51
bb50:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l83, !tbaa !29
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t160 = getelementptr %"compiler/typed:If", ptr %t158, i32 0, i32 2
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb52, label %bb53
bb51:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb56
bb52:
  call void @__olang_check_failed(ptr @olang_loc_b71f5ffe7a4b5626_fc1be7c1ddcacd52)
  unreachable
bb53:
  br label %bb54
bb54:
  %t165 = load ptr, ptr %l9, !tbaa !29
  %t167 = getelementptr %"compiler/typed:If", ptr %t165, i32 0, i32 2
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Block", ptr %t168, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t173 = load ptr, ptr %l83, !tbaa !29
  %t175 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t173, { i64, ptr } %t172)
  store i1 %t175, ptr %l91
  br label %bb55
bb55:
  %t176 = load i1, ptr %l91, !tbaa !21
  store i1 %t176, ptr %l82, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l82, !tbaa !21
  br i1 %t177, label %bb57, label %bb58
bb57:
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb98
bb60:
  %t179 = load ptr, ptr %l5, !tbaa !29
  store ptr %t179, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t180 = load ptr, ptr %l93, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb61, label %bb62
bb61:
  %t183 = load ptr, ptr %l93, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 17}
  %t186 = icmp eq i64 %t184, 4
  store i1 %t186, ptr %l94, !tbaa !21
  br label %bb62
bb62:
  %t187 = load i1, ptr %l94, !tbaa !21
  br i1 %t187, label %bb63, label %bb64
bb63:
  %t188 = load ptr, ptr %l5, !tbaa !29
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l10, !tbaa !29
  %t194 = load ptr, ptr %l5, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t196, i32 0, i32 2
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l11, !tbaa !29
  br label %bb65
bb64:
  br label %bb77
bb65:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l10, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Block", ptr %t201, i32 0, i32 1
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t207 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t200, { i64, ptr } %t204)
  store i1 %t207, ptr %l104
  br label %bb66
bb66:
  %t208 = load i1, ptr %l104, !tbaa !21
  br i1 %t208, label %bb67, label %bb68
bb67:
  store i1 true, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t210 = load ptr, ptr %l11, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb70, label %bb71
bb70:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l11, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Block", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t223 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t216, { i64, ptr } %t220)
  store i1 %t223, ptr %l113
  br label %bb72
bb71:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb73
bb72:
  %t224 = load i1, ptr %l113, !tbaa !21
  store i1 %t224, ptr %l109, !tbaa !21
  br label %bb73
bb73:
  %t225 = load i1, ptr %l109, !tbaa !21
  br i1 %t225, label %bb74, label %bb75
bb74:
  store i1 true, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  br label %bb98
bb77:
  %t227 = load ptr, ptr %l5, !tbaa !29
  store ptr %t227, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t228 = load ptr, ptr %l115, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb78, label %bb79
bb78:
  %t231 = load ptr, ptr %l115, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 17}
  %t234 = icmp eq i64 %t232, 11
  store i1 %t234, ptr %l116, !tbaa !21
  br label %bb79
bb79:
  %t235 = load i1, ptr %l116, !tbaa !21
  br i1 %t235, label %bb80, label %bb81
bb80:
  %t236 = load ptr, ptr %l5, !tbaa !29
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", ptr }, ptr %t238, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l12, !tbaa !29
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l12, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Block", ptr %t243, i32 0, i32 1
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t249 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t242, { i64, ptr } %t246)
  store i1 %t249, ptr %l124
  br label %bb83
bb83:
  %t250 = load i1, ptr %l124, !tbaa !21
  br i1 %t250, label %bb84, label %bb85
bb84:
  store i1 true, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  br label %bb98
bb87:
  %t252 = load ptr, ptr %l5, !tbaa !29
  store ptr %t252, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t253 = load ptr, ptr %l126, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb88, label %bb89
bb88:
  %t256 = load ptr, ptr %l126, !tbaa !29
  %t257 = load i64, ptr %t256, !range !{i64 0, i64 17}
  %t259 = icmp eq i64 %t257, 5
  store i1 %t259, ptr %l127, !tbaa !21
  br label %bb89
bb89:
  %t260 = load i1, ptr %l127, !tbaa !21
  br i1 %t260, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb98
bb93:
  br i1 true, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  store i1 true, ptr %rv
  br label %ret
bb97:
  call void @__olang_check_failed(ptr @olang_loc_80901eaab4a643b4_757281eb5f4291b0)
  unreachable
bb98:
  br label %bb99
bb99:
  %t262 = load i64, ptr %l3, !tbaa !24
  %t264 = add i64 %t262, 1
  store i64 %t264, ptr %l3, !tbaa !24
  br label %bb1
bb100:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Text", ptr %a1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb15
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l16, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 2}
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { ptr }, ptr %t37, i32 0, i32 0
  %t39 = load ptr, ptr %t38
  %t45 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %t39)
  store i1 %t45, ptr %l28
  br label %bb9
bb8:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t46 = load i1, ptr %l28, !tbaa !21
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { ptr }, ptr %t50, i32 0, i32 0
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l7, !tbaa !29
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l3, !tbaa !24
  br label %bb1
bb15:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %s0 = alloca %olang.scope
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = call i64 @compiler_2ffree_2eokind(i64 %t1)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2ffree_2eoval(i64 %t5)
  store i64 %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load i64, ptr %l9, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t13 = icmp ne i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr @G_2ecompiler_2ffree_2eOParC, !tbaa !24
  %t19 = icmp ne i64 %t15, %t16
  store i1 %t19, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l19
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t27 = load i64, ptr %l5, !tbaa !24
  store i64 %t27, ptr %l20, !tbaa !24
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l22
  br label %bb10
bb10:
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = load i64, ptr %l22, !tbaa !24
  %t33 = icmp sge i64 %t31, %t32
  br i1 %t33, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %l24, !tbaa !29
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t40 = icmp eq i64 %t36, %t37
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v1, ptr %s0, ptr %t42, i64 %t43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l31
  br label %bb16
bb15:
  store ptr %a0, ptr %l35, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v1, ptr %v1, ptr %t48, i64 %t49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l38
  br label %bb18
bb16:
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l33
  br label %bb17
bb17:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t56 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  store ptr %t56, ptr %l28, !tbaa !29
  br label %bb21
bb18:
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l38)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l40
  br label %bb19
bb19:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  %t61 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = load ptr, ptr %l35, !tbaa !29
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %s0, ptr %t62, ptr %t61)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l42
  br label %bb20
bb20:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  %t66 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  store ptr %t66, ptr %l28, !tbaa !29
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l24, !tbaa !29
  %t69 = load ptr, ptr %l28, !tbaa !29
  %t70 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s0, ptr %t68, ptr %t69)
  store i64 %t70, ptr %l44
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i1
  %l74 = alloca { i64, [2 x i64] }
  %l76 = alloca { i64, [2 x i64] }
  %l78 = alloca i1
  %l79 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, [2 x i64] }
  %l88 = alloca { i64, [2 x i64] }
  %l90 = alloca i1
  %l92 = alloca i64
  %l100 = alloca { i64, ptr }
  %l104 = alloca i1
  %l106 = alloca i64
  %l111 = alloca i1
  %l112 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [2 x i64] } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sge i64 %t5, 63
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i64, ptr %l3, !tbaa !24
  %t17 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecopiedPlain(ptr %v0, ptr %v1, ptr %t11, ptr %t12, i64 %t13)
  store i1 %t17, ptr %l25
  br label %bb7
bb7:
  %t18 = load i1, ptr %l25, !tbaa !21
  br i1 %t18, label %bb8, label %bb9
bb8:
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l26, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = load i64, ptr %l26, !tbaa !24
  %t22 = shl i64 1, %t21
  call void @__olang_scope_close(ptr %s0)
  store i64 %t22, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:Free", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l31
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l31, !tbaa !29
  store ptr %t31, ptr %l6, !tbaa !29
  %t32 = load i64, ptr %l5, !tbaa !24
  store i64 %t32, ptr %l32, !tbaa !24
  %t33 = load i64, ptr %l32, !tbaa !24
  %t34 = load i64, ptr %l32, !tbaa !24
  %t35 = shl i64 1, %t34
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Call", ptr %t37, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp sgt i64 %t44, %t45
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t50 = load i64, ptr %l10, !tbaa !24
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb17
bb14:
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = sub i64 %t54, %t55
  %t59 = load i64, ptr %l10, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t64 = sub i64 %t62, 1
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = sdiv i64 %t64, %t65
  store i64 %t68, ptr %l43, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t70 = load i64, ptr %l43, !tbaa !24
  store i64 %t70, ptr %l40, !tbaa !24
  br label %bb17
bb17:
  %t71 = load i64, ptr %l40, !tbaa !24
  store i64 %t71, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l12, !tbaa !24
  %t73 = load i64, ptr %l11, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb19, label %bb20
bb19:
  br label %bb40
bb20:
  br label %bb21
bb21:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = mul i64 %t81, %t82
  %t88 = add i64 %t80, %t85
  store i64 %t88, ptr %l13, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l3, !tbaa !24
  %t92 = load i64, ptr %l13, !tbaa !24
  %t96 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t90, i64 %t91, i64 %t92)
  store i64 %t96, ptr %l64
  br label %bb22
bb22:
  %t97 = load i64, ptr %l64, !tbaa !24
  store i64 %t97, ptr %l14, !tbaa !24
  %t98 = load i64, ptr %l14, !tbaa !24
  %t100 = icmp slt i64 %t98, 0
  br i1 %t100, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb25
bb24:
  %t102 = load i64, ptr %l14, !tbaa !24
  %t104 = icmp sge i64 %t102, 63
  store i1 %t104, ptr %l67, !tbaa !21
  br label %bb25
bb25:
  %t106 = load i1, ptr %l67, !tbaa !21
  br i1 %t106, label %bb26, label %bb27
bb26:
  br label %bb39
bb27:
  br label %bb28
bb28:
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Call", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = load i64, ptr %l14, !tbaa !24
  %t116 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t107, i32 %t111, i64 %t112)
  store { i64, [2 x i64] } %t116, ptr %l74
  br label %bb29
bb29:
  %t117 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t117, ptr %l76
  %t120 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l74, ptr %l76)
  store i1 %t120, ptr %l78
  br label %bb30
bb30:
  %t121 = load i1, ptr %l78, !tbaa !21
  br i1 %t121, label %bb31, label %bb32
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Call", ptr %t124, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l83, !tbaa !27
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t128
  %t133 = load ptr, ptr %t132, !tbaa !39
  %t137 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltAt(ptr %v0, ptr %v1, ptr %t122, i64 %t123, ptr %t133)
  store { i64, [2 x i64] } %t137, ptr %l86
  br label %bb33
bb32:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb35
bb33:
  %t138 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t138, ptr %l88
  %t141 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l86, ptr %l88)
  store i1 %t141, ptr %l90
  br label %bb34
bb34:
  %t142 = load i1, ptr %l90, !tbaa !21
  store i1 %t142, ptr %l79, !tbaa !21
  br label %bb35
bb35:
  %t143 = load i1, ptr %l79, !tbaa !21
  br i1 %t143, label %bb36, label %bb37
bb36:
  %t144 = load i64, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  store i64 %t145, ptr %l92, !tbaa !24
  %t146 = load i64, ptr %l92, !tbaa !24
  %t147 = load i64, ptr %l92, !tbaa !24
  %t148 = shl i64 1, %t147
  %t151 = or i64 %t144, %t148
  store i64 %t151, ptr %l7, !tbaa !24
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t153 = load i64, ptr %l12, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l12, !tbaa !24
  br label %bb18
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:Free", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t161 = load i64, ptr %l3, !tbaa !24
  %t164 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %s0, ptr %t160, i64 %t161)
  store { i64, ptr } %t164, ptr %l100
  br label %bb41
bb41:
  %t165 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t165, ptr %l15, !tbaa !27
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t168 = load i64, ptr %l7, !tbaa !24
  %t172 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t166, { i64, ptr } %t167, i64 %t168)
  store i1 %t172, ptr %l104
  br label %bb42
bb42:
  %t173 = load i1, ptr %l104, !tbaa !21
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t174 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t174, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t176 = load i64, ptr %l5, !tbaa !24
  store i64 %t176, ptr %l106, !tbaa !24
  %t177 = load i64, ptr %l106, !tbaa !24
  %t178 = load i64, ptr %l106, !tbaa !24
  %t179 = shl i64 1, %t178
  store i64 %t179, ptr %l7, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t183 = load i64, ptr %l7, !tbaa !24
  %t187 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t181, { i64, ptr } %t182, i64 %t183)
  store i1 %t187, ptr %l111
  br label %bb46
bb46:
  %t188 = load i1, ptr %l111, !tbaa !21
  br i1 %t188, label %bb47, label %bb48
bb47:
  %t189 = load i64, ptr %l7, !tbaa !24
  store i64 %t189, ptr %l112, !tbaa !24
  br label %bb49
bb48:
  store i64 -1, ptr %l112, !tbaa !24
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t191 = load i64, ptr %l112, !tbaa !24
  store i64 %t191, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca i32
  %l38 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l83 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l15, !tbaa !29
  store ptr %t19, ptr %l4, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t20, i32 %t24)
  store i64 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t29 = load i64, ptr %l19, !tbaa !24
  %t31 = icmp eq i64 %t29, %t28
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t33, i32 %t37)
  store { i64, ptr } %t40, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t44 = icmp eq i64 %t42, 1
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l22, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l4, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l33
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t56 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 0
  %t59 = load i32, ptr %t58, !tbaa !33
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t60, i32 %t59)
  store i32 %t62, ptr %l35
  br label %bb14
bb14:
  %t63 = load i32, ptr %l35, !tbaa !23
  store i32 %t63, ptr %l5, !tbaa !23
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l38
  br label %bb15
bb15:
  %t69 = load i1, ptr %l38, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l4, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t72 = load i32, ptr %l5, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l42
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l43
  br label %bb19
bb19:
  %t79 = load i32, ptr %l43, !tbaa !23
  store i32 %t79, ptr %l5, !tbaa !23
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t81 = load i32, ptr %l5, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l46
  br label %bb21
bb21:
  %t85 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb24
bb23:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  %t95 = load i1, ptr %l52, !tbaa !21
  store i1 %t95, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t98 = load i32, ptr %l5, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb29
bb28:
  %t102 = load i1, ptr %l56, !tbaa !21
  store i1 %t102, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t103 = load i1, ptr %l53, !tbaa !21
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t104, i64 %t105)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l1, !tbaa !24
  %t112 = call ptr @compiler_2ffree_2ewalker_2enewWalker(ptr %v0, ptr %v0, ptr %t108, i64 %t109, i1 false)
  store ptr %t112, ptr %l61
  br label %bb35
bb35:
  %t113 = load ptr, ptr %l61, !tbaa !29
  store ptr %t113, ptr %l6, !tbaa !29
  br label %bb36
bb36:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/free:walker", ptr %t114, i32 0, i32 5
  store i1 false, ptr %t116, !tbaa !21
  %t117 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t117)
  br label %bb37
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l64, !tbaa !29
  %t120 = load ptr, ptr %l64, !tbaa !29
  %t121 = getelementptr %"compiler/free:Free", ptr %t120, i32 0, i32 4
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = load ptr, ptr %l64, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t126, i32 0, i32 4
  store i64 %t124, ptr %t127, !tbaa !24
  %t128 = load ptr, ptr %l6, !tbaa !29
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Body", ptr %t129, i32 0, i32 11
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_30cfd3b464a887aa_ca3830b5343a05a6)
  unreachable
bb39:
  br label %bb40
bb40:
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Body", ptr %t136, i32 0, i32 11
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t140 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v0, ptr %t140, ptr %t139)
  br label %bb41
bb41:
  %t142 = load ptr, ptr %l6, !tbaa !29
  %t144 = getelementptr %"compiler/free:walker", ptr %t142, i32 0, i32 5
  %t145 = load i1, ptr %t144, !tbaa !21
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb36
bb46:
  %t149 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %t149)
  br label %bb47
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l6, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esave(ptr %v0, ptr %v0, ptr %t151, ptr %t152, i64 %t153)
  br label %bb48
bb48:
  br i1 %a2, label %bb49, label %bb50
bb49:
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 2
  store i1 true, ptr %t161, !tbaa !21
  %t162 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t162)
  br label %bb51
bb50:
  br label %bb61
bb51:
  %t164 = load ptr, ptr %l6, !tbaa !29
  store ptr %t164, ptr %l83, !tbaa !29
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Body", ptr %t165, i32 0, i32 11
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  br i1 %t170, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_3a3557a9366273b1_8eafb121351cf8d)
  unreachable
bb53:
  br label %bb54
bb54:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Body", ptr %t172, i32 0, i32 11
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t176 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v0, ptr %t176, ptr %t175)
  br label %bb55
bb55:
  %t178 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %t178)
  br label %bb56
bb56:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/free:Free", ptr %t180, i32 0, i32 27
  %t183 = load i1, ptr %t182, !tbaa !21
  br i1 %t183, label %bb57, label %bb58
bb57:
  %t185 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egenCalls(ptr %v0, ptr %t185)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/free:store"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:store"
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca %"compiler/free:orStore"
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"compiler/free:orCall"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca { i64, [2 x i64] }
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca %"compiler/free:store"
  %l55 = alloca ptr
  %l59 = alloca i1
  %l62 = alloca i1
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca i64
  %l78 = alloca i1
  %l83 = alloca %"compiler/free:store"
  %l88 = alloca i1
  %l89 = alloca i1
  %l93 = alloca i1
  %l100 = alloca i64
  %l106 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l115 = alloca { i64, [2 x i64] }
  %l118 = alloca i1
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i64
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l135 = alloca { i64, [2 x i64] }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l142 = alloca i64
  %l153 = alloca i64
  %l155 = alloca i64
  %l160 = alloca %"compiler/free:orStore"
  %l164 = alloca i1
  %l165 = alloca i1
  %l169 = alloca i1
  %l171 = alloca i1
  %l174 = alloca i1
  %l177 = alloca i64
  %l183 = alloca ptr
  %l187 = alloca { i64, [2 x i64] }
  %l189 = alloca i1
  %l191 = alloca i1
  %l193 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i64
  %l218 = alloca i64
  %l220 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca i64
  %l242 = alloca i64
  %l244 = alloca { i64, ptr }
  %l245 = alloca i64
  %l249 = alloca i64
  %l259 = alloca i64
  %l261 = alloca i64
  %l266 = alloca %"compiler/free:orCall"
  %l270 = alloca i1
  %l271 = alloca i1
  %l275 = alloca i1
  %l277 = alloca i1
  %l280 = alloca i1
  %l284 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l293 = alloca i64
  %l302 = alloca { i64, [2 x i64] }
  %l304 = alloca i1
  %l309 = alloca ptr
  %l318 = alloca i64
  %l322 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l329 = alloca { i64, ptr }
  %l334 = alloca { i64, ptr }
  %l335 = alloca i64
  %l339 = alloca i64
  %l341 = alloca { i64, ptr }
  %l342 = alloca i64
  %l346 = alloca i64
  %l350 = alloca i64
  %l353 = alloca i64
  %l372 = alloca i64
  %l389 = alloca i64
  %l392 = alloca i64
  %l413 = alloca i64
  %l416 = alloca i1
  %l419 = alloca i1
  %l421 = alloca i64
  %l425 = alloca i1
  %l430 = alloca { i64, ptr }
  %l435 = alloca i64
  %l438 = alloca i1
  %l440 = alloca { i64, ptr }
  %l444 = alloca i1
  %l446 = alloca { i64, ptr }
  %l451 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t767 = alloca { i64, [2 x i64] }, align 8
  %t927 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l44
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/free:Free", ptr %t3, i32 0, i32 83
  store ptr %t5, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l47, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l49
  br label %bb3
bb3:
  %t11 = load i64, ptr %l47, !tbaa !24
  %t12 = load i64, ptr %l49, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store %"compiler/free:store" %t21, ptr %l54
  br label %bb7
bb7:
  %t22 = load %"compiler/free:store", ptr %l54
  store %"compiler/free:store" %t22, ptr %l4
  store ptr %l1, ptr %l55, !tbaa !29
  %t23 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 4
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t28 = icmp eq i64 %t24, %t25
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/free:store", ptr %l4
  %t34 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v0, ptr %t30, %"compiler/free:store" %t31)
  store i1 %t34, ptr %l62
  br label %bb10
bb9:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb11
bb10:
  %t35 = load i1, ptr %l62, !tbaa !21
  store i1 %t35, ptr %l59, !tbaa !21
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l55, !tbaa !29
  %t37 = load i1, ptr %l59, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t36, i1 %t37)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eouterFirst(ptr %v0, ptr %s4, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l66
  br label %bb15
bb15:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  %t46 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  store ptr %t46, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t48 = load i64, ptr %l6, !tbaa !24
  store i64 %t48, ptr %l68, !tbaa !24
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s4, ptr %t49)
  store i64 %t51, ptr %l70
  br label %bb17
bb17:
  %t52 = load i64, ptr %l68, !tbaa !24
  %t53 = load i64, ptr %l70, !tbaa !24
  %t54 = icmp slt i64 %t52, %t53
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb61
bb19:
  br label %bb20
bb20:
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s4, ptr %t58, i64 %t59)
  store i64 %t62, ptr %l75
  br label %bb21
bb21:
  %t63 = load i64, ptr %l75, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l1, i64 %t64)
  store i1 %t67, ptr %l78
  br label %bb22
bb22:
  %t68 = load i1, ptr %l78, !tbaa !21
  %t69 = xor i1 %t68, true
  br i1 %t69, label %bb23, label %bb24
bb23:
  br label %bb60
bb24:
  br label %bb25
bb25:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:Free", ptr %t71, i32 0, i32 83
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/free:store" %t77, ptr %l83
  br label %bb26
bb26:
  %t78 = load %"compiler/free:store", ptr %l83
  store %"compiler/free:store" %t78, ptr %l8
  %t79 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 0
  %t80 = load i64, ptr %t79, !tbaa !24
  store i64 %t80, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:Free", ptr %t82, i32 0, i32 22
  %t85 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t84, i64 %t86)
  store i1 %t89, ptr %l88
  br label %bb27
bb27:
  %t90 = load i1, ptr %l88, !tbaa !21
  br i1 %t90, label %bb28, label %bb29
bb28:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/free:Free", ptr %t91, i32 0, i32 90
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t93, i64 %t94)
  store i1 %t97, ptr %l93
  br label %bb30
bb29:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb31
bb30:
  %t98 = load i1, ptr %l93, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l89, !tbaa !21
  br label %bb31
bb31:
  %t101 = load i1, ptr %l89, !tbaa !21
  br i1 %t101, label %bb32, label %bb33
bb32:
  br label %bb60
bb33:
  br label %bb34
bb34:
  %t102 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 7
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_b0d58e2b07420cd2_669637d27520b416)
  unreachable
bb36:
  br label %bb37
bb37:
  %t107 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 7
  %t108 = load ptr, ptr %t107, !tbaa !29
  store ptr %t108, ptr %l10, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t114 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t110, ptr %t111)
  store i64 %t114, ptr %l100
  br label %bb38
bb38:
  %t115 = load i64, ptr %l100, !tbaa !24
  store i64 %t115, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb39, label %bb40
bb39:
  br label %bb60
bb40:
  br label %bb41
bb41:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/free:Free", ptr %t120, i32 0, i32 3
  %t123 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  %t127 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t122, i64 %t124)
  store ptr %t127, ptr %l106
  br label %bb42
bb42:
  %t128 = load ptr, ptr %l106, !tbaa !29
  store ptr %t128, ptr %l12, !tbaa !29
  %t129 = load ptr, ptr %l12, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Plan", ptr %t129, i32 0, i32 5
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l108, !tbaa !27
  %t133 = load i64, ptr %l11, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i64, ptr %t136, i64 %t133
  %t138 = load i64, ptr %t137, !tbaa !34
  %t140 = icmp ne i64 %t138, 0
  br i1 %t140, label %bb43, label %bb44
bb43:
  br label %bb60
bb44:
  br label %bb45
bb45:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 1
  %t144 = load i64, ptr %t143, !tbaa !24
  %t145 = load ptr, ptr %l10, !tbaa !29
  %t149 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t142, i64 %t144, ptr %t145)
  store { i64, [2 x i64] } %t149, ptr %l115
  br label %bb46
bb46:
  %t150 = load { i64, [2 x i64] }, ptr %l115
  store { i64, [2 x i64] } %t150, ptr %l13
  %t151 = load { i64, [2 x i64] }, ptr %l13
  %t153 = extractvalue { i64, [2 x i64] } %t151, 0
  %t154 = icmp eq i64 %t153, 7
  br i1 %t154, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb49
bb48:
  %t156 = load { i64, [2 x i64] }, ptr %l13
  %t158 = extractvalue { i64, [2 x i64] } %t156, 0
  %t159 = icmp eq i64 %t158, 8
  store i1 %t159, ptr %l118, !tbaa !21
  br label %bb49
bb49:
  %t161 = load i1, ptr %l118, !tbaa !21
  br i1 %t161, label %bb50, label %bb51
bb50:
  br label %bb60
bb51:
  br label %bb52
bb52:
  %t162 = load ptr, ptr %l12, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Plan", ptr %t162, i32 0, i32 5
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l122, !tbaa !27
  %t166 = load i64, ptr %l11, !tbaa !24
  store i64 %t166, ptr %l123, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %v0, ptr %t167, i64 %t168)
  store i1 %t171, ptr %l126
  br label %bb53
bb53:
  %t172 = load i1, ptr %l126, !tbaa !21
  br i1 %t172, label %bb54, label %bb55
bb54:
  store i64 3, ptr %l127, !tbaa !24
  br label %bb56
bb55:
  store i64 1, ptr %l127, !tbaa !24
  br label %bb56
bb56:
  %t173 = load i64, ptr %l127, !tbaa !24
  %t174 = load i64, ptr %l123, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i64, ptr %t176, i64 %t174
  store i64 %t173, ptr %t177, !tbaa !34
  %t178 = load ptr, ptr %l12, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Plan", ptr %t178, i32 0, i32 6
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l129, !tbaa !27
  %t182 = load i64, ptr %l11, !tbaa !24
  store i64 %t182, ptr %l130, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 1
  %t185 = load i64, ptr %t184, !tbaa !24
  %t186 = load i64, ptr %l11, !tbaa !24
  %t187 = load { i64, [2 x i64] }, ptr %l13
  %t192 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedDest(ptr %v0, ptr %t183, i64 %t185, i64 %t186, { i64, [2 x i64] } %t187)
  store { i64, [2 x i64] } %t192, ptr %l135
  br label %bb57
bb57:
  %t193 = load { i64, [2 x i64] }, ptr %l135
  %t194 = load i64, ptr %l130, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr { i64, [2 x i64] }, ptr %t196, i64 %t194
  store { i64, [2 x i64] } %t193, ptr %t197
  %t198 = load ptr, ptr %l12, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Plan", ptr %t198, i32 0, i32 8
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l137, !tbaa !27
  %t202 = load i64, ptr %l11, !tbaa !24
  store i64 %t202, ptr %l138, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 1
  %t205 = load i64, ptr %t204, !tbaa !24
  %t206 = load i64, ptr %l9, !tbaa !24
  %t210 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eguard(ptr %v0, ptr %t203, i64 %t205, i64 %t206)
  store i64 %t210, ptr %l142
  br label %bb58
bb58:
  %t211 = load i64, ptr %l142, !tbaa !24
  %t212 = load i64, ptr %l138, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr i64, ptr %t214, i64 %t212
  store i64 %t211, ptr %t215, !tbaa !34
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 1
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load ptr, ptr %l10, !tbaa !29
  %t220 = load i64, ptr %l11, !tbaa !24
  %t221 = load { i64, [2 x i64] }, ptr %l13
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t216, i64 %t218, ptr %t219, i64 %t220, { i64, [2 x i64] } %t221, i1 true, i1 false)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t227 = load i64, ptr %l6, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l6, !tbaa !24
  br label %bb16
bb61:
  call void @__olang_scope_close(ptr %s4)
  %t231 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewriteFeedCalls(ptr %v0, ptr %t231)
  br label %bb62
bb62:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/free:Free", ptr %t233, i32 0, i32 89
  store ptr %t235, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb63
bb63:
  %t237 = load i64, ptr %l15, !tbaa !24
  store i64 %t237, ptr %l153, !tbaa !24
  %t238 = load ptr, ptr %l14, !tbaa !29
  %t240 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %t238)
  store i64 %t240, ptr %l155
  br label %bb64
bb64:
  %t241 = load i64, ptr %l153, !tbaa !24
  %t242 = load i64, ptr %l155, !tbaa !24
  %t243 = icmp slt i64 %t241, %t242
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb65, label %bb66
bb65:
  br label %bb108
bb66:
  br label %bb67
bb67:
  %t247 = load ptr, ptr %l14, !tbaa !29
  %t248 = load i64, ptr %l15, !tbaa !24
  %t251 = call %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t247, i64 %t248)
  store %"compiler/free:orStore" %t251, ptr %l160
  br label %bb68
bb68:
  %t252 = load %"compiler/free:orStore", ptr %l160
  store %"compiler/free:orStore" %t252, ptr %l16
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/free:Free", ptr %t253, i32 0, i32 22
  %t256 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 0
  %t257 = load i64, ptr %t256, !tbaa !24
  %t260 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t255, i64 %t257)
  store i1 %t260, ptr %l164
  br label %bb69
bb69:
  %t261 = load i1, ptr %l164, !tbaa !21
  br i1 %t261, label %bb70, label %bb71
bb70:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/free:Free", ptr %t262, i32 0, i32 90
  %t265 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 1
  %t266 = load i64, ptr %t265, !tbaa !24
  %t269 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t264, i64 %t266)
  store i1 %t269, ptr %l169
  br label %bb72
bb71:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb73
bb72:
  %t270 = load i1, ptr %l169, !tbaa !21
  %t271 = xor i1 %t270, true
  store i1 %t271, ptr %l165, !tbaa !21
  br label %bb73
bb73:
  %t273 = load i1, ptr %l165, !tbaa !21
  br i1 %t273, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb77
bb75:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 1
  %t276 = load i64, ptr %t275, !tbaa !24
  %t279 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %v0, ptr %t274, i64 %t276)
  store i1 %t279, ptr %l174
  br label %bb76
bb76:
  %t280 = load i1, ptr %l174, !tbaa !21
  store i1 %t280, ptr %l171, !tbaa !21
  br label %bb77
bb77:
  %t281 = load i1, ptr %l171, !tbaa !21
  br i1 %t281, label %bb78, label %bb79
bb78:
  br label %bb107
bb79:
  br label %bb80
bb80:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 2
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t287 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t282, ptr %t284)
  store i64 %t287, ptr %l177
  br label %bb81
bb81:
  %t288 = load i64, ptr %l177, !tbaa !24
  store i64 %t288, ptr %l17, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t291 = icmp slt i64 %t289, 0
  br i1 %t291, label %bb82, label %bb83
bb82:
  br label %bb107
bb83:
  br label %bb84
bb84:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/free:Free", ptr %t293, i32 0, i32 3
  %t296 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 0
  %t297 = load i64, ptr %t296, !tbaa !24
  %t300 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t295, i64 %t297)
  store ptr %t300, ptr %l183
  br label %bb85
bb85:
  %t301 = load ptr, ptr %l183, !tbaa !29
  store ptr %t301, ptr %l18, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 0
  %t304 = load i64, ptr %t303, !tbaa !24
  %t305 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t310 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t302, i64 %t304, ptr %t306)
  store { i64, [2 x i64] } %t310, ptr %l187
  br label %bb86
bb86:
  %t311 = load { i64, [2 x i64] }, ptr %l187
  store { i64, [2 x i64] } %t311, ptr %l19
  %t312 = load { i64, [2 x i64] }, ptr %l19
  %t314 = call i1 @compiler_2ffree_2eruns({ i64, [2 x i64] } %t312)
  store i1 %t314, ptr %l189
  br label %bb87
bb87:
  %t315 = load i1, ptr %l189, !tbaa !21
  %t316 = xor i1 %t315, true
  br i1 %t316, label %bb88, label %bb89
bb88:
  %t318 = load ptr, ptr %l18, !tbaa !29
  %t320 = getelementptr %"compiler/typed:Plan", ptr %t318, i32 0, i32 5
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !27
  store { i64, ptr } %t321, ptr %l193, !tbaa !27
  %t322 = load i64, ptr %l17, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr i64, ptr %t325, i64 %t322
  %t327 = load i64, ptr %t326, !tbaa !34
  %t329 = icmp eq i64 %t327, 0
  store i1 %t329, ptr %l191, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb90
bb90:
  %t331 = load i1, ptr %l191, !tbaa !21
  br i1 %t331, label %bb91, label %bb92
bb91:
  br label %bb107
bb92:
  br label %bb93
bb93:
  %t332 = load ptr, ptr %l18, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Plan", ptr %t332, i32 0, i32 5
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l198, !tbaa !27
  %t336 = load i64, ptr %l17, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr i64, ptr %t339, i64 %t336
  %t341 = load i64, ptr %t340, !tbaa !34
  %t343 = icmp eq i64 %t341, 1
  br i1 %t343, label %bb94, label %bb95
bb94:
  %t345 = load ptr, ptr %l18, !tbaa !29
  %t347 = getelementptr %"compiler/typed:Plan", ptr %t345, i32 0, i32 7
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  store { i64, ptr } %t348, ptr %l203, !tbaa !27
  %t349 = load i64, ptr %l17, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr ptr, ptr %t352, i64 %t349
  %t354 = load ptr, ptr %t353, !tbaa !39
  %t356 = icmp eq ptr %t354, null
  br i1 %t356, label %bb96, label %bb97
bb95:
  br label %bb100
bb96:
  %t358 = load ptr, ptr %l18, !tbaa !29
  %t360 = getelementptr %"compiler/typed:Plan", ptr %t358, i32 0, i32 7
  %t361 = load { i64, ptr }, ptr %t360, !tbaa !27
  store { i64, ptr } %t361, ptr %l208, !tbaa !27
  %t362 = load i64, ptr %l17, !tbaa !24
  %t363 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 3
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t368 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr ptr, ptr %t369, i64 %t362
  store ptr %t364, ptr %t370, !tbaa !39
  %t371 = load ptr, ptr %l18, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Plan", ptr %t371, i32 0, i32 9
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  store { i64, ptr } %t374, ptr %l213, !tbaa !27
  %t375 = load i64, ptr %l17, !tbaa !24
  store i64 %t375, ptr %l214, !tbaa !24
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 0
  %t378 = load i64, ptr %t377, !tbaa !24
  %t379 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 1
  %t380 = load i64, ptr %t379, !tbaa !24
  %t384 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eguard(ptr %v0, ptr %t376, i64 %t378, i64 %t380)
  store i64 %t384, ptr %l218
  br label %bb98
bb97:
  br label %bb99
bb98:
  %t385 = load i64, ptr %l218, !tbaa !24
  %t386 = load i64, ptr %l214, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr i64, ptr %t388, i64 %t386
  store i64 %t385, ptr %t389, !tbaa !34
  br label %bb99
bb99:
  br label %bb107
bb100:
  %t390 = load ptr, ptr %l18, !tbaa !29
  %t392 = getelementptr %"compiler/typed:Plan", ptr %t390, i32 0, i32 5
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !27
  store { i64, ptr } %t393, ptr %l220, !tbaa !27
  %t394 = load i64, ptr %l17, !tbaa !24
  %t396 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr i64, ptr %t397, i64 %t394
  %t399 = load i64, ptr %t398, !tbaa !34
  %t401 = icmp ne i64 %t399, 0
  br i1 %t401, label %bb101, label %bb102
bb101:
  br label %bb107
bb102:
  br label %bb103
bb103:
  %t403 = load ptr, ptr %l18, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Plan", ptr %t403, i32 0, i32 5
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  store { i64, ptr } %t406, ptr %l225, !tbaa !27
  %t407 = load i64, ptr %l17, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i64, ptr %t410, i64 %t407
  store i64 2, ptr %t411, !tbaa !34
  %t412 = load ptr, ptr %l18, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Plan", ptr %t412, i32 0, i32 6
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  store { i64, ptr } %t415, ptr %l228, !tbaa !27
  %t416 = load i64, ptr %l17, !tbaa !24
  %t417 = load { i64, [2 x i64] }, ptr %l19
  %t420 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr { i64, [2 x i64] }, ptr %t421, i64 %t416
  store { i64, [2 x i64] } %t417, ptr %t422
  %t423 = load ptr, ptr %l18, !tbaa !29
  %t425 = getelementptr %"compiler/typed:Plan", ptr %t423, i32 0, i32 7
  %t426 = load { i64, ptr }, ptr %t425, !tbaa !27
  store { i64, ptr } %t426, ptr %l232, !tbaa !27
  %t427 = load i64, ptr %l17, !tbaa !24
  %t428 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 3
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t433 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr ptr, ptr %t434, i64 %t427
  store ptr %t429, ptr %t435, !tbaa !39
  %t436 = load ptr, ptr %l18, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Plan", ptr %t436, i32 0, i32 8
  %t439 = load { i64, ptr }, ptr %t438, !tbaa !27
  store { i64, ptr } %t439, ptr %l237, !tbaa !27
  %t440 = load i64, ptr %l17, !tbaa !24
  store i64 %t440, ptr %l238, !tbaa !24
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 0
  %t443 = load i64, ptr %t442, !tbaa !24
  %t444 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 1
  %t445 = load i64, ptr %t444, !tbaa !24
  %t449 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eguard(ptr %v0, ptr %t441, i64 %t443, i64 %t445)
  store i64 %t449, ptr %l242
  br label %bb104
bb104:
  %t450 = load i64, ptr %l242, !tbaa !24
  %t451 = load i64, ptr %l238, !tbaa !24
  %t452 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !27
  %t454 = getelementptr i64, ptr %t453, i64 %t451
  store i64 %t450, ptr %t454, !tbaa !34
  %t455 = load ptr, ptr %l18, !tbaa !29
  %t457 = getelementptr %"compiler/typed:Plan", ptr %t455, i32 0, i32 9
  %t458 = load { i64, ptr }, ptr %t457, !tbaa !27
  store { i64, ptr } %t458, ptr %l244, !tbaa !27
  %t459 = load i64, ptr %l17, !tbaa !24
  store i64 %t459, ptr %l245, !tbaa !24
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 0
  %t462 = load i64, ptr %t461, !tbaa !24
  %t463 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 1
  %t464 = load i64, ptr %t463, !tbaa !24
  %t468 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eguard(ptr %v0, ptr %t460, i64 %t462, i64 %t464)
  store i64 %t468, ptr %l249
  br label %bb105
bb105:
  %t469 = load i64, ptr %l249, !tbaa !24
  %t470 = load i64, ptr %l245, !tbaa !24
  %t471 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr i64, ptr %t472, i64 %t470
  store i64 %t469, ptr %t473, !tbaa !34
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 0
  %t476 = load i64, ptr %t475, !tbaa !24
  %t477 = getelementptr %"compiler/free:orStore", ptr %l16, i32 0, i32 2
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t479 = load i64, ptr %l17, !tbaa !24
  %t480 = load { i64, [2 x i64] }, ptr %l19
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t474, i64 %t476, ptr %t478, i64 %t479, { i64, [2 x i64] } %t480, i1 true, i1 false)
  br label %bb106
bb106:
  br label %bb107
bb107:
  %t486 = load i64, ptr %l15, !tbaa !24
  %t488 = add i64 %t486, 1
  store i64 %t488, ptr %l15, !tbaa !24
  br label %bb63
bb108:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/free:Free", ptr %t490, i32 0, i32 88
  store ptr %t492, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb109
bb109:
  %t494 = load i64, ptr %l21, !tbaa !24
  store i64 %t494, ptr %l259, !tbaa !24
  %t495 = load ptr, ptr %l20, !tbaa !29
  %t497 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t495)
  store i64 %t497, ptr %l261
  br label %bb110
bb110:
  %t498 = load i64, ptr %l259, !tbaa !24
  %t499 = load i64, ptr %l261, !tbaa !24
  %t500 = icmp slt i64 %t498, %t499
  %t502 = xor i1 %t500, true
  br i1 %t502, label %bb111, label %bb112
bb111:
  br label %bb203
bb112:
  br label %bb113
bb113:
  %t504 = load ptr, ptr %l20, !tbaa !29
  %t505 = load i64, ptr %l21, !tbaa !24
  %t508 = call %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t504, i64 %t505)
  store %"compiler/free:orCall" %t508, ptr %l266
  br label %bb114
bb114:
  %t509 = load %"compiler/free:orCall", ptr %l266
  store %"compiler/free:orCall" %t509, ptr %l22
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr %"compiler/free:Free", ptr %t510, i32 0, i32 22
  %t513 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 0
  %t514 = load i64, ptr %t513, !tbaa !24
  %t517 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t512, i64 %t514)
  store i1 %t517, ptr %l270
  br label %bb115
bb115:
  %t518 = load i1, ptr %l270, !tbaa !21
  br i1 %t518, label %bb116, label %bb117
bb116:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/free:Free", ptr %t519, i32 0, i32 90
  %t522 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 4
  %t523 = load i64, ptr %t522, !tbaa !24
  %t526 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t521, i64 %t523)
  store i1 %t526, ptr %l275
  br label %bb118
bb117:
  store i1 false, ptr %l271, !tbaa !21
  br label %bb119
bb118:
  %t527 = load i1, ptr %l275, !tbaa !21
  %t528 = xor i1 %t527, true
  store i1 %t528, ptr %l271, !tbaa !21
  br label %bb119
bb119:
  %t530 = load i1, ptr %l271, !tbaa !21
  br i1 %t530, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l277, !tbaa !21
  br label %bb123
bb121:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t532 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 4
  %t533 = load i64, ptr %t532, !tbaa !24
  %t536 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %v0, ptr %t531, i64 %t533)
  store i1 %t536, ptr %l280
  br label %bb122
bb122:
  %t537 = load i1, ptr %l280, !tbaa !21
  store i1 %t537, ptr %l277, !tbaa !21
  br label %bb123
bb123:
  %t538 = load i1, ptr %l277, !tbaa !21
  br i1 %t538, label %bb124, label %bb125
bb124:
  br label %bb202
bb125:
  br label %bb126
bb126:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = getelementptr %"compiler/free:Free", ptr %t539, i32 0, i32 3
  %t542 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 0
  %t543 = load i64, ptr %t542, !tbaa !24
  %t546 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t541, i64 %t543)
  store ptr %t546, ptr %l284
  br label %bb127
bb127:
  %t547 = load ptr, ptr %l284, !tbaa !29
  store ptr %t547, ptr %l23, !tbaa !29
  %t548 = load ptr, ptr %l23, !tbaa !29
  %t550 = getelementptr %"compiler/typed:Plan", ptr %t548, i32 0, i32 5
  %t551 = load { i64, ptr }, ptr %t550, !tbaa !27
  store { i64, ptr } %t551, ptr %l286, !tbaa !27
  %t552 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t553 = load i64, ptr %t552, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr i64, ptr %t556, i64 %t553
  %t558 = load i64, ptr %t557, !tbaa !34
  %t560 = icmp ne i64 %t558, 0
  br i1 %t560, label %bb128, label %bb129
bb128:
  br label %bb202
bb129:
  br label %bb130
bb130:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t563 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 2
  %t564 = load i64, ptr %t563, !tbaa !24
  %t565 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 3
  %t566 = load i64, ptr %t565, !tbaa !24
  %t570 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t562, i64 %t564, i64 %t566)
  store i64 %t570, ptr %l293
  br label %bb131
bb131:
  %t571 = load i64, ptr %l293, !tbaa !24
  store i64 %t571, ptr %l24, !tbaa !24
  %t572 = load i64, ptr %l24, !tbaa !24
  %t574 = icmp slt i64 %t572, 0
  br i1 %t574, label %bb132, label %bb133
bb132:
  br label %bb202
bb133:
  br label %bb134
bb134:
  %t576 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t577 = load i64, ptr %t576, !tbaa !24
  %t579 = trunc i64 %t577 to i32
  store i32 %t579, ptr %l25, !tbaa !23
  %t582 = load ptr, ptr %l23, !tbaa !29
  %t583 = load i32, ptr %l25, !tbaa !23
  %t584 = load i64, ptr %l24, !tbaa !24
  %t588 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t582, i32 %t583, i64 %t584)
  store { i64, [2 x i64] } %t588, ptr %l302
  br label %bb135
bb135:
  %t589 = load { i64, [2 x i64] }, ptr %l302
  store { i64, [2 x i64] } %t589, ptr %l26
  %t590 = load { i64, [2 x i64] }, ptr %l26
  %t592 = call i1 @compiler_2ffree_2eruns({ i64, [2 x i64] } %t590)
  store i1 %t592, ptr %l304
  br label %bb136
bb136:
  %t593 = load i1, ptr %l304, !tbaa !21
  %t594 = xor i1 %t593, true
  br i1 %t594, label %bb137, label %bb138
bb137:
  br label %bb202
bb138:
  br label %bb139
bb139:
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 0
  %t598 = load i64, ptr %t597, !tbaa !24
  %t599 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t600 = load i64, ptr %t599, !tbaa !24
  %t604 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v0, ptr %t596, i64 %t598, i64 %t600)
  store ptr %t604, ptr %l309
  br label %bb140
bb140:
  %t605 = load ptr, ptr %l309, !tbaa !29
  store ptr %t605, ptr %l27, !tbaa !29
  %t606 = load ptr, ptr %l27, !tbaa !29
  %t608 = icmp eq ptr %t606, null
  br i1 %t608, label %bb141, label %bb142
bb141:
  br label %bb202
bb142:
  br label %bb143
bb143:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 0
  %t612 = load i64, ptr %t611, !tbaa !24
  %t613 = load ptr, ptr %l27, !tbaa !29
  %t614 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 2
  %t615 = load i64, ptr %t614, !tbaa !24
  %t616 = load { i64, [2 x i64] }, ptr %l26
  %t617 = load i64, ptr %l24, !tbaa !24
  %t624 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v0, ptr %t610, i64 %t612, ptr %t613, i64 %t615, { i64, [2 x i64] } %t616, i64 %t617)
  store i64 %t624, ptr %l318
  br label %bb144
bb144:
  %t625 = load i64, ptr %l318, !tbaa !24
  store i64 %t625, ptr %l28, !tbaa !24
  %t626 = load i64, ptr %l28, !tbaa !24
  %t628 = icmp slt i64 %t626, 0
  br i1 %t628, label %bb145, label %bb146
bb145:
  br label %bb202
bb146:
  br label %bb147
bb147:
  %t630 = load ptr, ptr %l23, !tbaa !29
  %t632 = getelementptr %"compiler/typed:Plan", ptr %t630, i32 0, i32 5
  %t633 = load { i64, ptr }, ptr %t632, !tbaa !27
  store { i64, ptr } %t633, ptr %l322, !tbaa !27
  %t634 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t635 = load i64, ptr %t634, !tbaa !24
  %t637 = getelementptr { i64, ptr }, ptr %l322, i32 0, i32 1
  %t638 = load ptr, ptr %t637, !tbaa !27
  %t639 = getelementptr i64, ptr %t638, i64 %t635
  store i64 2, ptr %t639, !tbaa !34
  %t640 = load ptr, ptr %l23, !tbaa !29
  %t642 = getelementptr %"compiler/typed:Plan", ptr %t640, i32 0, i32 6
  %t643 = load { i64, ptr }, ptr %t642, !tbaa !27
  store { i64, ptr } %t643, ptr %l325, !tbaa !27
  %t644 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t645 = load i64, ptr %t644, !tbaa !24
  %t646 = load { i64, [2 x i64] }, ptr %l26
  %t649 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t650 = load ptr, ptr %t649, !tbaa !27
  %t651 = getelementptr { i64, [2 x i64] }, ptr %t650, i64 %t645
  store { i64, [2 x i64] } %t646, ptr %t651
  %t652 = load ptr, ptr %l23, !tbaa !29
  %t654 = getelementptr %"compiler/typed:Plan", ptr %t652, i32 0, i32 7
  %t655 = load { i64, ptr }, ptr %t654, !tbaa !27
  store { i64, ptr } %t655, ptr %l329, !tbaa !27
  %t656 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t657 = load i64, ptr %t656, !tbaa !24
  %t658 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 5
  %t659 = load ptr, ptr %t658, !tbaa !29
  %t663 = getelementptr { i64, ptr }, ptr %l329, i32 0, i32 1
  %t664 = load ptr, ptr %t663, !tbaa !27
  %t665 = getelementptr ptr, ptr %t664, i64 %t657
  store ptr %t659, ptr %t665, !tbaa !39
  %t666 = load ptr, ptr %l23, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Plan", ptr %t666, i32 0, i32 8
  %t669 = load { i64, ptr }, ptr %t668, !tbaa !27
  store { i64, ptr } %t669, ptr %l334, !tbaa !27
  %t670 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t671 = load i64, ptr %t670, !tbaa !24
  store i64 %t671, ptr %l335, !tbaa !24
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t673 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 0
  %t674 = load i64, ptr %t673, !tbaa !24
  %t675 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 4
  %t676 = load i64, ptr %t675, !tbaa !24
  %t680 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eguard(ptr %v0, ptr %t672, i64 %t674, i64 %t676)
  store i64 %t680, ptr %l339
  br label %bb148
bb148:
  %t681 = load i64, ptr %l339, !tbaa !24
  %t682 = load i64, ptr %l335, !tbaa !24
  %t683 = getelementptr { i64, ptr }, ptr %l334, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = getelementptr i64, ptr %t684, i64 %t682
  store i64 %t681, ptr %t685, !tbaa !34
  %t686 = load ptr, ptr %l23, !tbaa !29
  %t688 = getelementptr %"compiler/typed:Plan", ptr %t686, i32 0, i32 9
  %t689 = load { i64, ptr }, ptr %t688, !tbaa !27
  store { i64, ptr } %t689, ptr %l341, !tbaa !27
  %t690 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t691 = load i64, ptr %t690, !tbaa !24
  store i64 %t691, ptr %l342, !tbaa !24
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 0
  %t694 = load i64, ptr %t693, !tbaa !24
  %t695 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 4
  %t696 = load i64, ptr %t695, !tbaa !24
  %t700 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eguard(ptr %v0, ptr %t692, i64 %t694, i64 %t696)
  store i64 %t700, ptr %l346
  br label %bb149
bb149:
  %t701 = load i64, ptr %l346, !tbaa !24
  %t702 = load i64, ptr %l342, !tbaa !24
  %t703 = getelementptr { i64, ptr }, ptr %l341, i32 0, i32 1
  %t704 = load ptr, ptr %t703, !tbaa !27
  %t705 = getelementptr i64, ptr %t704, i64 %t702
  store i64 %t701, ptr %t705, !tbaa !34
  store i64 0, ptr %l29, !tbaa !24
  store i64 63, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t706 = load i64, ptr %l30, !tbaa !24
  %t707 = load i64, ptr %l29, !tbaa !24
  %t710 = icmp sgt i64 %t706, %t707
  br i1 %t710, label %bb150, label %bb151
bb150:
  %t712 = load i64, ptr %l31, !tbaa !24
  %t714 = icmp sgt i64 %t712, 0
  br i1 %t714, label %bb152, label %bb153
bb151:
  store i64 0, ptr %l350, !tbaa !24
  br label %bb155
bb152:
  %t716 = load i64, ptr %l30, !tbaa !24
  %t717 = load i64, ptr %l29, !tbaa !24
  %t720 = sub i64 %t716, %t717
  %t721 = load i64, ptr %l31, !tbaa !24
  %t724 = add i64 %t720, %t721
  %t726 = sub i64 %t724, 1
  %t727 = load i64, ptr %l31, !tbaa !24
  %t730 = sdiv i64 %t726, %t727
  store i64 %t730, ptr %l353, !tbaa !24
  br label %bb154
bb153:
  store i64 0, ptr %l353, !tbaa !24
  br label %bb154
bb154:
  %t732 = load i64, ptr %l353, !tbaa !24
  store i64 %t732, ptr %l350, !tbaa !24
  br label %bb155
bb155:
  %t733 = load i64, ptr %l350, !tbaa !24
  store i64 %t733, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb156
bb156:
  %t734 = load i64, ptr %l33, !tbaa !24
  %t735 = load i64, ptr %l32, !tbaa !24
  %t738 = icmp slt i64 %t734, %t735
  %t740 = xor i1 %t738, true
  br i1 %t740, label %bb157, label %bb158
bb157:
  br label %bb165
bb158:
  br label %bb159
bb159:
  %t742 = load i64, ptr %l29, !tbaa !24
  %t743 = load i64, ptr %l33, !tbaa !24
  %t744 = load i64, ptr %l31, !tbaa !24
  %t747 = mul i64 %t743, %t744
  %t750 = add i64 %t742, %t747
  store i64 %t750, ptr %l34, !tbaa !24
  %t752 = load i64, ptr %l28, !tbaa !24
  %t753 = load i64, ptr %l34, !tbaa !24
  store i64 %t753, ptr %l372, !tbaa !24
  %t754 = load i64, ptr %l372, !tbaa !24
  %t755 = load i64, ptr %l372, !tbaa !24
  %t756 = shl i64 1, %t755
  %t759 = and i64 %t752, %t756
  %t761 = icmp ne i64 %t759, 0
  br i1 %t761, label %bb160, label %bb161
bb160:
  %t763 = load ptr, ptr %l23, !tbaa !29
  %t764 = load i32, ptr %l25, !tbaa !23
  %t765 = load i64, ptr %l34, !tbaa !24
  %t766 = load i32, ptr %l25, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t767
  %t768 = getelementptr { i64, [2 x i64] }, ptr %t767, i32 0, i32 0
  store i64 4, ptr %t768
  %t770 = insertvalue { i32 } undef, i32 %t766, 0
  %t771 = getelementptr { i64, [2 x i64] }, ptr %t767, i32 0, i32 1
  store { i32 } %t770, ptr %t771
  %t772 = load { i64, [2 x i64] }, ptr %t767
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %t763, i32 %t764, i64 %t765, { i64, [2 x i64] } %t772)
  br label %bb162
bb161:
  br label %bb163
bb162:
  br label %bb163
bb163:
  br label %bb164
bb164:
  %t777 = load i64, ptr %l33, !tbaa !24
  %t779 = add i64 %t777, 1
  store i64 %t779, ptr %l33, !tbaa !24
  br label %bb156
bb165:
  store i64 0, ptr %l35, !tbaa !24
  %t781 = load ptr, ptr %l27, !tbaa !29
  %t783 = getelementptr %"compiler/typed:Call", ptr %t781, i32 0, i32 1
  %t784 = load { i64, ptr }, ptr %t783, !tbaa !27
  %t786 = extractvalue { i64, ptr } %t784, 0
  store i64 %t786, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t788 = load i64, ptr %l36, !tbaa !24
  %t789 = load i64, ptr %l35, !tbaa !24
  %t792 = icmp sgt i64 %t788, %t789
  br i1 %t792, label %bb166, label %bb167
bb166:
  %t794 = load i64, ptr %l37, !tbaa !24
  %t796 = icmp sgt i64 %t794, 0
  br i1 %t796, label %bb168, label %bb169
bb167:
  store i64 0, ptr %l389, !tbaa !24
  br label %bb171
bb168:
  %t798 = load i64, ptr %l36, !tbaa !24
  %t799 = load i64, ptr %l35, !tbaa !24
  %t802 = sub i64 %t798, %t799
  %t803 = load i64, ptr %l37, !tbaa !24
  %t806 = add i64 %t802, %t803
  %t808 = sub i64 %t806, 1
  %t809 = load i64, ptr %l37, !tbaa !24
  %t812 = sdiv i64 %t808, %t809
  store i64 %t812, ptr %l392, !tbaa !24
  br label %bb170
bb169:
  store i64 0, ptr %l392, !tbaa !24
  br label %bb170
bb170:
  %t814 = load i64, ptr %l392, !tbaa !24
  store i64 %t814, ptr %l389, !tbaa !24
  br label %bb171
bb171:
  %t815 = load i64, ptr %l389, !tbaa !24
  store i64 %t815, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb172
bb172:
  %t816 = load i64, ptr %l39, !tbaa !24
  %t817 = load i64, ptr %l38, !tbaa !24
  %t820 = icmp slt i64 %t816, %t817
  %t822 = xor i1 %t820, true
  br i1 %t822, label %bb173, label %bb174
bb173:
  br label %bb201
bb174:
  br label %bb175
bb175:
  %t824 = load i64, ptr %l35, !tbaa !24
  %t825 = load i64, ptr %l39, !tbaa !24
  %t826 = load i64, ptr %l37, !tbaa !24
  %t829 = mul i64 %t825, %t826
  %t832 = add i64 %t824, %t829
  store i64 %t832, ptr %l40, !tbaa !24
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t835 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 2
  %t836 = load i64, ptr %t835, !tbaa !24
  %t837 = load i64, ptr %l40, !tbaa !24
  %t841 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t834, i64 %t836, i64 %t837)
  store i64 %t841, ptr %l413
  br label %bb176
bb176:
  %t842 = load i64, ptr %l413, !tbaa !24
  store i64 %t842, ptr %l41, !tbaa !24
  %t843 = load i64, ptr %l41, !tbaa !24
  %t845 = icmp slt i64 %t843, 0
  br i1 %t845, label %bb177, label %bb178
bb177:
  store i1 true, ptr %l416, !tbaa !21
  br label %bb179
bb178:
  %t847 = load i64, ptr %l41, !tbaa !24
  %t849 = icmp sge i64 %t847, 63
  store i1 %t849, ptr %l416, !tbaa !21
  br label %bb179
bb179:
  %t851 = load i1, ptr %l416, !tbaa !21
  br i1 %t851, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l419, !tbaa !21
  br label %bb182
bb181:
  %t852 = load i64, ptr %l28, !tbaa !24
  %t853 = load i64, ptr %l41, !tbaa !24
  store i64 %t853, ptr %l421, !tbaa !24
  %t854 = load i64, ptr %l421, !tbaa !24
  %t855 = load i64, ptr %l421, !tbaa !24
  %t856 = shl i64 1, %t855
  %t859 = and i64 %t852, %t856
  %t861 = icmp eq i64 %t859, 0
  store i1 %t861, ptr %l419, !tbaa !21
  br label %bb182
bb182:
  %t863 = load i1, ptr %l419, !tbaa !21
  br i1 %t863, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l425, !tbaa !21
  br label %bb185
bb184:
  %t864 = load i64, ptr %l40, !tbaa !24
  %t865 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 3
  %t866 = load i64, ptr %t865, !tbaa !24
  %t869 = icmp eq i64 %t864, %t866
  store i1 %t869, ptr %l425, !tbaa !21
  br label %bb185
bb185:
  %t871 = load i1, ptr %l425, !tbaa !21
  br i1 %t871, label %bb186, label %bb187
bb186:
  br label %bb200
bb187:
  br label %bb188
bb188:
  %t872 = load ptr, ptr %l27, !tbaa !29
  %t874 = getelementptr %"compiler/typed:Call", ptr %t872, i32 0, i32 1
  %t875 = load { i64, ptr }, ptr %t874, !tbaa !27
  store { i64, ptr } %t875, ptr %l430, !tbaa !27
  %t876 = load i64, ptr %l40, !tbaa !24
  %t878 = getelementptr { i64, ptr }, ptr %l430, i32 0, i32 1
  %t879 = load ptr, ptr %t878, !tbaa !27
  %t880 = getelementptr ptr, ptr %t879, i64 %t876
  %t881 = load ptr, ptr %t880, !tbaa !39
  store ptr %t881, ptr %l42, !tbaa !29
  %t883 = load ptr, ptr %l0, !tbaa !29
  %t884 = load ptr, ptr %l42, !tbaa !29
  %t887 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t883, ptr %t884)
  store i64 %t887, ptr %l435
  br label %bb189
bb189:
  %t888 = load i64, ptr %l435, !tbaa !24
  store i64 %t888, ptr %l43, !tbaa !24
  %t889 = load i64, ptr %l43, !tbaa !24
  %t891 = icmp sge i64 %t889, 0
  br i1 %t891, label %bb190, label %bb191
bb190:
  %t893 = load ptr, ptr %l23, !tbaa !29
  %t895 = getelementptr %"compiler/typed:Plan", ptr %t893, i32 0, i32 5
  %t896 = load { i64, ptr }, ptr %t895, !tbaa !27
  store { i64, ptr } %t896, ptr %l440, !tbaa !27
  %t897 = load i64, ptr %l43, !tbaa !24
  %t899 = getelementptr { i64, ptr }, ptr %l440, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !27
  %t901 = getelementptr i64, ptr %t900, i64 %t897
  %t902 = load i64, ptr %t901, !tbaa !34
  %t904 = icmp eq i64 %t902, 1
  br i1 %t904, label %bb192, label %bb193
bb191:
  store i1 false, ptr %l438, !tbaa !21
  br label %bb195
bb192:
  store i1 true, ptr %l444, !tbaa !21
  br label %bb194
bb193:
  %t906 = load ptr, ptr %l23, !tbaa !29
  %t908 = getelementptr %"compiler/typed:Plan", ptr %t906, i32 0, i32 5
  %t909 = load { i64, ptr }, ptr %t908, !tbaa !27
  store { i64, ptr } %t909, ptr %l446, !tbaa !27
  %t910 = load i64, ptr %l43, !tbaa !24
  %t912 = getelementptr { i64, ptr }, ptr %l446, i32 0, i32 1
  %t913 = load ptr, ptr %t912, !tbaa !27
  %t914 = getelementptr i64, ptr %t913, i64 %t910
  %t915 = load i64, ptr %t914, !tbaa !34
  %t917 = icmp eq i64 %t915, 3
  store i1 %t917, ptr %l444, !tbaa !21
  br label %bb194
bb194:
  %t919 = load i1, ptr %l444, !tbaa !21
  store i1 %t919, ptr %l438, !tbaa !21
  br label %bb195
bb195:
  %t920 = load i1, ptr %l438, !tbaa !21
  br i1 %t920, label %bb196, label %bb197
bb196:
  %t921 = load ptr, ptr %l23, !tbaa !29
  %t923 = getelementptr %"compiler/typed:Plan", ptr %t921, i32 0, i32 6
  %t924 = load { i64, ptr }, ptr %t923, !tbaa !27
  store { i64, ptr } %t924, ptr %l451, !tbaa !27
  %t925 = load i64, ptr %l43, !tbaa !24
  %t926 = load i32, ptr %l25, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t927
  %t928 = getelementptr { i64, [2 x i64] }, ptr %t927, i32 0, i32 0
  store i64 4, ptr %t928
  %t930 = insertvalue { i32 } undef, i32 %t926, 0
  %t931 = getelementptr { i64, [2 x i64] }, ptr %t927, i32 0, i32 1
  store { i32 } %t930, ptr %t931
  %t932 = load { i64, [2 x i64] }, ptr %t927
  %t935 = getelementptr { i64, ptr }, ptr %l451, i32 0, i32 1
  %t936 = load ptr, ptr %t935, !tbaa !27
  %t937 = getelementptr { i64, [2 x i64] }, ptr %t936, i64 %t925
  store { i64, [2 x i64] } %t932, ptr %t937
  br label %bb199
bb197:
  %t938 = load ptr, ptr %l0, !tbaa !29
  %t939 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 0
  %t940 = load i64, ptr %t939, !tbaa !24
  %t941 = load ptr, ptr %l42, !tbaa !29
  %t942 = getelementptr %"compiler/free:orCall", ptr %l22, i32 0, i32 1
  %t943 = load i64, ptr %t942, !tbaa !24
  %t944 = load { i64, [2 x i64] }, ptr %l26
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t938, i64 %t940, ptr %t941, i64 %t943, { i64, [2 x i64] } %t944, i1 false, i1 false)
  br label %bb198
bb198:
  br label %bb199
bb199:
  br label %bb200
bb200:
  %t950 = load i64, ptr %l39, !tbaa !24
  %t952 = add i64 %t950, 1
  store i64 %t952, ptr %l39, !tbaa !24
  br label %bb172
bb201:
  br label %bb202
bb202:
  %t954 = load i64, ptr %l21, !tbaa !24
  %t956 = add i64 %t954, 1
  store i64 %t956, ptr %l21, !tbaa !24
  br label %bb109
bb203:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2ecallMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l12 = alloca ptr
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %a1)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:mustW", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l12
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l12, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 11
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  store i1 %t24, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l7, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:mustW", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 73
  %t35 = load i64, ptr %l2, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l21
  br label %bb9
bb9:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:mustW", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 5
  store ptr %t16, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l15
  br label %bb3
bb3:
  %t22 = load i64, ptr %l13, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l20
  br label %bb7
bb7:
  %t33 = load i32, ptr %l20, !tbaa !23
  %t36 = sext i32 %t33 to i64
  %t40 = icmp eq i64 %t36, %a1
  br i1 %t40, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb2
bb12:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2easRecord(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i64
  %l39 = alloca ptr
  %l42 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i64
  %l52 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l60 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i64
  %l70 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca i64
  %l99 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i1
  %l115 = alloca i64
  %l117 = alloca i64
  %l119 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l130 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca ptr
  %l141 = alloca i64
  %l142 = alloca ptr
  %l143 = alloca i64
  %l146 = alloca i64
  %l149 = alloca ptr
  %l150 = alloca i64
  %l154 = alloca i64
  %l159 = alloca i1
  %l162 = alloca i64
  %l164 = alloca i64
  %l166 = alloca ptr
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l181 = alloca ptr
  %l182 = alloca i64
  %l183 = alloca ptr
  %l184 = alloca i64
  %l187 = alloca i64
  %l190 = alloca ptr
  %l191 = alloca i64
  %l195 = alloca i64
  %l200 = alloca i1
  %l203 = alloca i64
  %l205 = alloca i64
  %l207 = alloca ptr
  %l208 = alloca ptr
  %l213 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l215 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l217 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l225 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca i64
  %l235 = alloca ptr
  %l236 = alloca i64
  %l239 = alloca i64
  %l242 = alloca ptr
  %l243 = alloca i64
  %l247 = alloca i64
  %l248 = alloca ptr
  %l249 = alloca i64
  %l250 = alloca i64
  %l251 = alloca %"compiler/source:Span"
  %l253 = alloca %"compiler/source:Span"
  %s5 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp slt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb4
bb2:
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l28, !tbaa !24
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l31
  br label %bb3
bb3:
  %t16 = load i64, ptr %l28, !tbaa !24
  %t17 = load i64, ptr %l31, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l27, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l27, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l6, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 97
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l39
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load ptr, ptr %l39, !tbaa !29
  %t41 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t39, i64 %t38)
  store i64 %t41, ptr %l42
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/free:Free", ptr %t42, i32 0, i32 63
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store ptr %t48, ptr %l46
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l46, !tbaa !29
  store ptr %t49, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t50 = load i64, ptr %l8, !tbaa !24
  store i64 %t50, ptr %l47, !tbaa !24
  %t51 = load ptr, ptr %l7, !tbaa !29
  store ptr %t51, ptr %l48, !tbaa !29
  %t52 = ptrtoint ptr %v0 to i64
  store i64 %t52, ptr %l49, !tbaa !24
  %t53 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l48, !tbaa !29
  %t56 = call ptr @__olang_region_or(ptr %t55, ptr %v0)
  %t57 = ptrtoint ptr %t56 to i64
  store i64 %t57, ptr %l49, !tbaa !24
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l7, !tbaa !29
  %t59 = load i64, ptr %l49
  %t60 = inttoptr i64 %t59 to ptr
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t60, ptr %t58)
  store i64 %t62, ptr %l52
  br label %bb17
bb17:
  %t63 = load i64, ptr %l47, !tbaa !24
  %t64 = load i64, ptr %l52, !tbaa !24
  %t65 = icmp slt i64 %t63, %t64
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb18, label %bb19
bb18:
  br label %bb35
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l7, !tbaa !29
  store ptr %t69, ptr %l55, !tbaa !29
  %t70 = ptrtoint ptr %v0 to i64
  store i64 %t70, ptr %l56, !tbaa !24
  %t71 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t73 = load ptr, ptr %l55, !tbaa !29
  %t74 = call ptr @__olang_region_or(ptr %t73, ptr %v0)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l56, !tbaa !24
  br label %bb22
bb22:
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l56
  %t79 = inttoptr i64 %t78 to ptr
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t79, ptr %t76, i64 %t77)
  store i64 %t82, ptr %l60
  br label %bb23
bb23:
  %t83 = load i64, ptr %l60, !tbaa !24
  store i64 %t83, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = ashr i64 %t84, 32
  %t87 = load i64, ptr %l3, !tbaa !24
  %t90 = sub i64 %t86, %t87
  store i64 %t90, ptr %l10, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = load i64, ptr %l10, !tbaa !24
  store i64 %t96, ptr %l68, !tbaa !24
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t97)
  store i64 %t99, ptr %l70
  br label %bb26
bb25:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb27
bb26:
  %t100 = load i64, ptr %l68, !tbaa !24
  %t101 = load i64, ptr %l70, !tbaa !24
  %t102 = icmp slt i64 %t100, %t101
  store i1 %t102, ptr %l67, !tbaa !21
  br label %bb27
bb27:
  %t104 = load i1, ptr %l67, !tbaa !21
  br i1 %t104, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l72, !tbaa !29
  %t106 = load i64, ptr %l9, !tbaa !24
  %t107 = shl i64 1, 32
  %t109 = sub i64 %t107, 1
  %t112 = and i64 %t106, %t109
  store i64 %t112, ptr %l76, !tbaa !24
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Call", ptr %t113, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l78, !tbaa !27
  %t117 = load i64, ptr %l10, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr ptr, ptr %t120, i64 %t117
  %t122 = load ptr, ptr %t121, !tbaa !39
  store ptr %t122, ptr %l80, !tbaa !29
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t124 = load i64, ptr %l10, !tbaa !24
  %t127 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t123, i64 %t124)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %l83
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t129 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l83)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l85
  br label %bb31
bb31:
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  %t131 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %t131
  %t132 = load %"compiler/source:Span", ptr %l5
  %t133 = load ptr, ptr %l72, !tbaa !29
  %t134 = load i64, ptr %l76, !tbaa !24
  %t135 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %s5, ptr %t133, i64 %t134, ptr %t135, ptr %t131, %"compiler/source:Span" %t132, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, i1 true, i1 false)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb14
bb35:
  %t142 = load ptr, ptr %l6, !tbaa !29
  %t144 = getelementptr %"compiler/free:Free", ptr %t142, i32 0, i32 67
  %t145 = load i64, ptr %l2, !tbaa !24
  %t148 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t144, i64 %t145)
  store ptr %t148, ptr %l93
  br label %bb36
bb36:
  %t149 = load ptr, ptr %l93, !tbaa !29
  store ptr %t149, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  %t150 = load i64, ptr %l12, !tbaa !24
  store i64 %t150, ptr %l94, !tbaa !24
  %t151 = load ptr, ptr %l11, !tbaa !29
  store ptr %t151, ptr %l95, !tbaa !29
  %t152 = ptrtoint ptr %v0 to i64
  store i64 %t152, ptr %l96, !tbaa !24
  %t153 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t153, label %bb38, label %bb39
bb38:
  %t155 = load ptr, ptr %l95, !tbaa !29
  %t156 = call ptr @__olang_region_or(ptr %t155, ptr %v0)
  %t157 = ptrtoint ptr %t156 to i64
  store i64 %t157, ptr %l96, !tbaa !24
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l11, !tbaa !29
  %t159 = load i64, ptr %l96
  %t160 = inttoptr i64 %t159 to ptr
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t160, ptr %t158)
  store i64 %t162, ptr %l99
  br label %bb40
bb40:
  %t163 = load i64, ptr %l94, !tbaa !24
  %t164 = load i64, ptr %l99, !tbaa !24
  %t165 = icmp slt i64 %t163, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb41, label %bb42
bb41:
  br label %bb58
bb42:
  br label %bb43
bb43:
  %t169 = load ptr, ptr %l11, !tbaa !29
  store ptr %t169, ptr %l102, !tbaa !29
  %t170 = ptrtoint ptr %v0 to i64
  store i64 %t170, ptr %l103, !tbaa !24
  %t171 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t171, label %bb44, label %bb45
bb44:
  %t173 = load ptr, ptr %l102, !tbaa !29
  %t174 = call ptr @__olang_region_or(ptr %t173, ptr %v0)
  %t175 = ptrtoint ptr %t174 to i64
  store i64 %t175, ptr %l103, !tbaa !24
  br label %bb45
bb45:
  %t176 = load ptr, ptr %l11, !tbaa !29
  %t177 = load i64, ptr %l12, !tbaa !24
  %t178 = load i64, ptr %l103
  %t179 = inttoptr i64 %t178 to ptr
  %t182 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t179, ptr %t176, i64 %t177)
  store i64 %t182, ptr %l107
  br label %bb46
bb46:
  %t183 = load i64, ptr %l107, !tbaa !24
  store i64 %t183, ptr %l13, !tbaa !24
  %t184 = load i64, ptr %l13, !tbaa !24
  %t185 = load i64, ptr %l3, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t190 = icmp sge i64 %t188, 0
  br i1 %t190, label %bb47, label %bb48
bb47:
  %t192 = load i64, ptr %l13, !tbaa !24
  %t193 = load i64, ptr %l3, !tbaa !24
  %t196 = sub i64 %t192, %t193
  store i64 %t196, ptr %l115, !tbaa !24
  %t197 = load ptr, ptr %l4, !tbaa !29
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t197)
  store i64 %t199, ptr %l117
  br label %bb49
bb48:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb50
bb49:
  %t200 = load i64, ptr %l115, !tbaa !24
  %t201 = load i64, ptr %l117, !tbaa !24
  %t202 = icmp slt i64 %t200, %t201
  store i1 %t202, ptr %l112, !tbaa !21
  br label %bb50
bb50:
  %t204 = load i1, ptr %l112, !tbaa !21
  br i1 %t204, label %bb51, label %bb52
bb51:
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l119, !tbaa !29
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Call", ptr %t206, i32 0, i32 1
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l121, !tbaa !27
  %t210 = load i64, ptr %l13, !tbaa !24
  %t211 = load i64, ptr %l3, !tbaa !24
  %t214 = sub i64 %t210, %t211
  %t216 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 %t214
  %t219 = load ptr, ptr %t218, !tbaa !39
  store ptr %t219, ptr %l125, !tbaa !29
  %t220 = load ptr, ptr %l4, !tbaa !29
  %t221 = load i64, ptr %l13, !tbaa !24
  %t222 = load i64, ptr %l3, !tbaa !24
  %t225 = sub i64 %t221, %t222
  %t228 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t220, i64 %t225)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l130
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t230 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l130)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %l132
  br label %bb54
bb54:
  %t231 = load %"compiler/source:Span", ptr %l5
  %t232 = load ptr, ptr %l119, !tbaa !29
  %t233 = load ptr, ptr %l125, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeArg(ptr %v0, ptr %v1, ptr %v2, ptr %t232, ptr %t233, ptr %l132, %"compiler/source:Span" %t231)
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t236 = load i64, ptr %l12, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l12, !tbaa !24
  br label %bb37
bb58:
  %t240 = load ptr, ptr %l6, !tbaa !29
  %t242 = getelementptr %"compiler/free:Free", ptr %t240, i32 0, i32 64
  %t243 = load i64, ptr %l2, !tbaa !24
  %t246 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t242, i64 %t243)
  store ptr %t246, ptr %l140
  br label %bb59
bb59:
  %t247 = load ptr, ptr %l140, !tbaa !29
  store ptr %t247, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb60
bb60:
  %t248 = load i64, ptr %l15, !tbaa !24
  store i64 %t248, ptr %l141, !tbaa !24
  %t249 = load ptr, ptr %l14, !tbaa !29
  store ptr %t249, ptr %l142, !tbaa !29
  %t250 = ptrtoint ptr %v0 to i64
  store i64 %t250, ptr %l143, !tbaa !24
  %t251 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t251, label %bb61, label %bb62
bb61:
  %t253 = load ptr, ptr %l142, !tbaa !29
  %t254 = call ptr @__olang_region_or(ptr %t253, ptr %v0)
  %t255 = ptrtoint ptr %t254 to i64
  store i64 %t255, ptr %l143, !tbaa !24
  br label %bb62
bb62:
  %t256 = load ptr, ptr %l14, !tbaa !29
  %t257 = load i64, ptr %l143
  %t258 = inttoptr i64 %t257 to ptr
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t258, ptr %t256)
  store i64 %t260, ptr %l146
  br label %bb63
bb63:
  %t261 = load i64, ptr %l141, !tbaa !24
  %t262 = load i64, ptr %l146, !tbaa !24
  %t263 = icmp slt i64 %t261, %t262
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb64, label %bb65
bb64:
  br label %bb81
bb65:
  br label %bb66
bb66:
  %t267 = load ptr, ptr %l14, !tbaa !29
  store ptr %t267, ptr %l149, !tbaa !29
  %t268 = ptrtoint ptr %v0 to i64
  store i64 %t268, ptr %l150, !tbaa !24
  %t269 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t269, label %bb67, label %bb68
bb67:
  %t271 = load ptr, ptr %l149, !tbaa !29
  %t272 = call ptr @__olang_region_or(ptr %t271, ptr %v0)
  %t273 = ptrtoint ptr %t272 to i64
  store i64 %t273, ptr %l150, !tbaa !24
  br label %bb68
bb68:
  %t274 = load ptr, ptr %l14, !tbaa !29
  %t275 = load i64, ptr %l15, !tbaa !24
  %t276 = load i64, ptr %l150
  %t277 = inttoptr i64 %t276 to ptr
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t277, ptr %t274, i64 %t275)
  store i64 %t280, ptr %l154
  br label %bb69
bb69:
  %t281 = load i64, ptr %l154, !tbaa !24
  store i64 %t281, ptr %l16, !tbaa !24
  %t282 = load i64, ptr %l16, !tbaa !24
  %t283 = load i64, ptr %l3, !tbaa !24
  %t286 = sub i64 %t282, %t283
  %t288 = icmp sge i64 %t286, 0
  br i1 %t288, label %bb70, label %bb71
bb70:
  %t290 = load i64, ptr %l16, !tbaa !24
  %t291 = load i64, ptr %l3, !tbaa !24
  %t294 = sub i64 %t290, %t291
  store i64 %t294, ptr %l162, !tbaa !24
  %t295 = load ptr, ptr %l4, !tbaa !29
  %t297 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t295)
  store i64 %t297, ptr %l164
  br label %bb72
bb71:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb73
bb72:
  %t298 = load i64, ptr %l162, !tbaa !24
  %t299 = load i64, ptr %l164, !tbaa !24
  %t300 = icmp slt i64 %t298, %t299
  store i1 %t300, ptr %l159, !tbaa !21
  br label %bb73
bb73:
  %t302 = load i1, ptr %l159, !tbaa !21
  br i1 %t302, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l166, !tbaa !29
  %t304 = load ptr, ptr %l4, !tbaa !29
  %t305 = load i64, ptr %l16, !tbaa !24
  %t306 = load i64, ptr %l3, !tbaa !24
  %t309 = sub i64 %t305, %t306
  %t312 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t304, i64 %t309)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t312, ptr %l171
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t314 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l171)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t314, ptr %l173
  br label %bb77
bb77:
  %t315 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  %t316 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t315, ptr %t316
  %t317 = load %"compiler/source:Span", ptr %l5
  %t318 = load ptr, ptr %l166, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v2, ptr %s13, ptr %t318, ptr %t316, %"compiler/source:Span" %t317, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t321 = load i64, ptr %l15, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l15, !tbaa !24
  br label %bb60
bb81:
  %t325 = load ptr, ptr %l6, !tbaa !29
  %t327 = getelementptr %"compiler/free:Free", ptr %t325, i32 0, i32 65
  %t328 = load i64, ptr %l2, !tbaa !24
  %t331 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t327, i64 %t328)
  store ptr %t331, ptr %l181
  br label %bb82
bb82:
  %t332 = load ptr, ptr %l181, !tbaa !29
  store ptr %t332, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb83
bb83:
  %t333 = load i64, ptr %l18, !tbaa !24
  store i64 %t333, ptr %l182, !tbaa !24
  %t334 = load ptr, ptr %l17, !tbaa !29
  store ptr %t334, ptr %l183, !tbaa !29
  %t335 = ptrtoint ptr %v0 to i64
  store i64 %t335, ptr %l184, !tbaa !24
  %t336 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t336, label %bb84, label %bb85
bb84:
  %t338 = load ptr, ptr %l183, !tbaa !29
  %t339 = call ptr @__olang_region_or(ptr %t338, ptr %v0)
  %t340 = ptrtoint ptr %t339 to i64
  store i64 %t340, ptr %l184, !tbaa !24
  br label %bb85
bb85:
  %t341 = load ptr, ptr %l17, !tbaa !29
  %t342 = load i64, ptr %l184
  %t343 = inttoptr i64 %t342 to ptr
  %t345 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t343, ptr %t341)
  store i64 %t345, ptr %l187
  br label %bb86
bb86:
  %t346 = load i64, ptr %l182, !tbaa !24
  %t347 = load i64, ptr %l187, !tbaa !24
  %t348 = icmp slt i64 %t346, %t347
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb87, label %bb88
bb87:
  br label %bb105
bb88:
  br label %bb89
bb89:
  %t352 = load ptr, ptr %l17, !tbaa !29
  store ptr %t352, ptr %l190, !tbaa !29
  %t353 = ptrtoint ptr %v0 to i64
  store i64 %t353, ptr %l191, !tbaa !24
  %t354 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t354, label %bb90, label %bb91
bb90:
  %t356 = load ptr, ptr %l190, !tbaa !29
  %t357 = call ptr @__olang_region_or(ptr %t356, ptr %v0)
  %t358 = ptrtoint ptr %t357 to i64
  store i64 %t358, ptr %l191, !tbaa !24
  br label %bb91
bb91:
  %t359 = load ptr, ptr %l17, !tbaa !29
  %t360 = load i64, ptr %l18, !tbaa !24
  %t361 = load i64, ptr %l191
  %t362 = inttoptr i64 %t361 to ptr
  %t365 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t362, ptr %t359, i64 %t360)
  store i64 %t365, ptr %l195
  br label %bb92
bb92:
  %t366 = load i64, ptr %l195, !tbaa !24
  store i64 %t366, ptr %l19, !tbaa !24
  %t367 = load i64, ptr %l19, !tbaa !24
  %t368 = load i64, ptr %l3, !tbaa !24
  %t371 = sub i64 %t367, %t368
  %t373 = icmp sge i64 %t371, 0
  br i1 %t373, label %bb93, label %bb94
bb93:
  %t375 = load i64, ptr %l19, !tbaa !24
  %t376 = load i64, ptr %l3, !tbaa !24
  %t379 = sub i64 %t375, %t376
  store i64 %t379, ptr %l203, !tbaa !24
  %t380 = load ptr, ptr %l4, !tbaa !29
  %t382 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t380)
  store i64 %t382, ptr %l205
  br label %bb95
bb94:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb96
bb95:
  %t383 = load i64, ptr %l203, !tbaa !24
  %t384 = load i64, ptr %l205, !tbaa !24
  %t385 = icmp slt i64 %t383, %t384
  store i1 %t385, ptr %l200, !tbaa !21
  br label %bb96
bb96:
  %t387 = load i1, ptr %l200, !tbaa !21
  br i1 %t387, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s17
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l207, !tbaa !29
  %t389 = load ptr, ptr %l6, !tbaa !29
  store ptr %t389, ptr %l208, !tbaa !29
  %t390 = load ptr, ptr %l4, !tbaa !29
  %t391 = load i64, ptr %l19, !tbaa !24
  %t392 = load i64, ptr %l3, !tbaa !24
  %t395 = sub i64 %t391, %t392
  %t398 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t390, i64 %t395)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t398, ptr %l213
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t400 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l213)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t400, ptr %l215
  br label %bb100
bb100:
  %t401 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215
  %t402 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t401, ptr %t402
  %t403 = load ptr, ptr %l208, !tbaa !29
  %t405 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v2, ptr %s17, ptr %t403, ptr %t402)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t405, ptr %l217
  br label %bb101
bb101:
  %t406 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l217
  %t407 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t406, ptr %t407
  %t408 = load %"compiler/source:Span", ptr %l5
  %t409 = load ptr, ptr %l207, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s17, ptr %s17, ptr %t409, ptr %t407, %"compiler/source:Span" %t408, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t412 = load i64, ptr %l18, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l18, !tbaa !24
  br label %bb83
bb105:
  %t416 = load ptr, ptr %l6, !tbaa !29
  %t418 = getelementptr %"compiler/free:Free", ptr %t416, i32 0, i32 69
  %t419 = load i64, ptr %l2, !tbaa !24
  %t422 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t418, i64 %t419)
  store i1 %t422, ptr %l225
  br label %bb106
bb106:
  %t423 = load i1, ptr %l225, !tbaa !21
  br i1 %t423, label %bb107, label %bb108
bb107:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load %"compiler/source:Span", ptr %l5
  %t426 = load ptr, ptr %l1, !tbaa !29
  %t427 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t424, %"compiler/source:Span" %t425, ptr %t426, i64 %t427)
  br label %bb109
bb108:
  %t432 = load ptr, ptr %l6, !tbaa !29
  %t434 = getelementptr %"compiler/free:Free", ptr %t432, i32 0, i32 68
  %t435 = load i64, ptr %l2, !tbaa !24
  %t438 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t434, i64 %t435)
  store ptr %t438, ptr %l233
  br label %bb110
bb109:
  br label %bb125
bb110:
  %t439 = load ptr, ptr %l233, !tbaa !29
  store ptr %t439, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb111
bb111:
  %t440 = load i64, ptr %l21, !tbaa !24
  store i64 %t440, ptr %l234, !tbaa !24
  %t441 = load ptr, ptr %l20, !tbaa !29
  store ptr %t441, ptr %l235, !tbaa !29
  %t442 = ptrtoint ptr %v0 to i64
  store i64 %t442, ptr %l236, !tbaa !24
  %t443 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t443, label %bb112, label %bb113
bb112:
  %t445 = load ptr, ptr %l235, !tbaa !29
  %t446 = call ptr @__olang_region_or(ptr %t445, ptr %v0)
  %t447 = ptrtoint ptr %t446 to i64
  store i64 %t447, ptr %l236, !tbaa !24
  br label %bb113
bb113:
  %t448 = load ptr, ptr %l20, !tbaa !29
  %t449 = load i64, ptr %l236
  %t450 = inttoptr i64 %t449 to ptr
  %t452 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t450, ptr %t448)
  store i64 %t452, ptr %l239
  br label %bb114
bb114:
  %t453 = load i64, ptr %l234, !tbaa !24
  %t454 = load i64, ptr %l239, !tbaa !24
  %t455 = icmp slt i64 %t453, %t454
  %t457 = xor i1 %t455, true
  br i1 %t457, label %bb115, label %bb116
bb115:
  br label %bb124
bb116:
  br label %bb117
bb117:
  %t459 = load ptr, ptr %l20, !tbaa !29
  store ptr %t459, ptr %l242, !tbaa !29
  %t460 = ptrtoint ptr %v0 to i64
  store i64 %t460, ptr %l243, !tbaa !24
  %t461 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t461, label %bb118, label %bb119
bb118:
  %t463 = load ptr, ptr %l242, !tbaa !29
  %t464 = call ptr @__olang_region_or(ptr %t463, ptr %v0)
  %t465 = ptrtoint ptr %t464 to i64
  store i64 %t465, ptr %l243, !tbaa !24
  br label %bb119
bb119:
  %t466 = load ptr, ptr %l20, !tbaa !29
  %t467 = load i64, ptr %l21, !tbaa !24
  %t468 = load i64, ptr %l243
  %t469 = inttoptr i64 %t468 to ptr
  %t472 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t469, ptr %t466, i64 %t467)
  store i64 %t472, ptr %l247
  br label %bb120
bb120:
  %t473 = load i64, ptr %l247, !tbaa !24
  %t474 = load ptr, ptr %l0, !tbaa !29
  store ptr %t474, ptr %l248, !tbaa !29
  store i64 %t473, ptr %l249, !tbaa !24
  %t476 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t476, ptr %l250, !tbaa !24
  %t477 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t477, ptr %l251
  %t478 = load ptr, ptr %l1, !tbaa !29
  %t480 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %t478)
  store %"compiler/source:Span" %t480, ptr %l253
  br label %bb121
bb121:
  %t481 = load i64, ptr %l2, !tbaa !24
  %t482 = load ptr, ptr %l248, !tbaa !29
  %t483 = load i64, ptr %l249, !tbaa !24
  %t484 = load i64, ptr %l250, !tbaa !24
  %t485 = load %"compiler/source:Span", ptr %l251
  %t486 = load %"compiler/source:Span", ptr %l253
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t482, i64 %t483, i64 %t484, %"compiler/source:Span" %t485, %"compiler/source:Span" %t486, i64 %t481)
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t488 = load i64, ptr %l21, !tbaa !24
  %t490 = add i64 %t488, 1
  store i64 %t490, ptr %l21, !tbaa !24
  br label %bb111
bb124:
  br label %bb125
bb125:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t494 = load i64, ptr %l2, !tbaa !24
  %t495 = load i64, ptr %l3, !tbaa !24
  %t496 = load ptr, ptr %l4, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviaCall(ptr %v0, ptr %v1, ptr %v2, ptr %t492, ptr %t493, i64 %t494, i64 %t495, ptr %t496, %"compiler/source:Span" %t497)
  br label %bb126
bb126:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/free:leaf"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l41 = alloca i64
  %l47 = alloca ptr
  %l51 = alloca i64
  %l55 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca i64
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca ptr
  %l104 = alloca i1
  %l108 = alloca i1
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca i32
  %l119 = alloca i1
  %l121 = alloca i1
  %l122 = alloca ptr
  %l124 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca i1
  %l136 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i32
  %l158 = alloca i64
  %l161 = alloca ptr
  %l162 = alloca i64
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l169 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l172 = alloca i64
  %l173 = alloca i64
  %l175 = alloca %"compiler/source:Span"
  %l176 = alloca %"compiler/source:Span"
  %l180 = alloca i64
  %l181 = alloca ptr
  %l184 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l193 = alloca ptr
  %l196 = alloca i64
  %l197 = alloca ptr
  %l201 = alloca i1
  %l202 = alloca i64
  %l205 = alloca i64
  %l208 = alloca i64
  %l214 = alloca ptr
  %l215 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i64
  %l222 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca ptr
  %l227 = alloca %"compiler/source:Span"
  %l228 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l235 = alloca i64
  %l236 = alloca i64
  %l238 = alloca %"compiler/source:Span"
  %l239 = alloca %"compiler/source:Span"
  %l241 = alloca ptr
  %l243 = alloca i32
  %l244 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l246 = alloca i64
  %l248 = alloca i64
  %l253 = alloca %"compiler/free:leaf"
  %l255 = alloca %"compiler/free:leaf"
  %l256 = alloca ptr
  %l257 = alloca i64
  %l258 = alloca i64
  %l260 = alloca %"compiler/source:Span"
  %l261 = alloca %"compiler/source:Span"
  %l265 = alloca i64
  %l267 = alloca i1
  %l271 = alloca i1
  %l273 = alloca ptr
  %l274 = alloca ptr
  %l276 = alloca i32
  %l282 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l284 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l285 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l287 = alloca ptr
  %l288 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca i64
  %l295 = alloca ptr
  %l296 = alloca ptr
  %l297 = alloca %"compiler/source:Span"
  %l298 = alloca ptr
  %l300 = alloca %"compiler/source:Span"
  %l301 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l306 = alloca i64
  %l307 = alloca i64
  %l309 = alloca %"compiler/source:Span"
  %l310 = alloca %"compiler/source:Span"
  %l311 = alloca ptr
  %l312 = alloca i1
  %l317 = alloca ptr
  %l318 = alloca i64
  %l319 = alloca ptr
  %l320 = alloca ptr
  %l321 = alloca %"compiler/source:Span"
  %l322 = alloca ptr
  %l324 = alloca %"compiler/source:Span"
  %l325 = alloca { i64, ptr }
  %l332 = alloca ptr
  %l334 = alloca i32
  %l335 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l337 = alloca i64
  %l339 = alloca i1
  %l343 = alloca i1
  %l345 = alloca ptr
  %l346 = alloca ptr
  %l348 = alloca i32
  %l354 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l356 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l357 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l361 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca %"compiler/source:Span"
  %l364 = alloca ptr
  %l366 = alloca %"compiler/source:Span"
  %l367 = alloca { i64, ptr }
  %l368 = alloca { i64, ptr }
  %l371 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 9
  %t4 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t10 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v2, ptr %v2, ptr %t7)
  store ptr %t10, ptr %l28
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l28, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:walker", ptr %t12, i32 0, i32 33
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l31, !tbaa !29
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t25 = load ptr, ptr %l36, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l36, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l37, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l37, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l35, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l35, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Call", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t41 = sext i32 %t39 to i64
  store i64 %t41, ptr %l41, !tbaa !24
  br label %bb10
bb9:
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l41, !tbaa !24
  %t44 = load ptr, ptr %l31, !tbaa !29
  %t45 = getelementptr %"compiler/free:walker", ptr %t44, i32 0, i32 33
  store i64 %t43, ptr %t45, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:walker", ptr %t46, i32 0, i32 34
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l47, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopiedCtorOf(ptr %v0, ptr %v1, ptr %v2, ptr %t52, ptr %t53, ptr %t54)
  store i64 %t58, ptr %l51
  br label %bb11
bb11:
  %t59 = load i64, ptr %l51, !tbaa !24
  %t60 = load ptr, ptr %l47, !tbaa !29
  %t61 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 34
  store i64 %t59, ptr %t61, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t68 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyStored(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t62, ptr %t63, ptr %t64)
  store ptr %t68, ptr %l55
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l55, !tbaa !29
  store ptr %t69, ptr %l7, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 36
  %t73 = load i64, ptr %t72, !tbaa !24
  store i64 %t73, ptr %l8, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:walker", ptr %t75, i32 0, i32 37
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb13, label %bb14
bb13:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l63, !tbaa !29
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = call i64 @compiler_2ffree_2eownCopySite(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l65
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t90 = load i64, ptr %l65, !tbaa !24
  %t91 = load ptr, ptr %l63, !tbaa !29
  %t92 = getelementptr %"compiler/free:walker", ptr %t91, i32 0, i32 36
  store i64 %t90, ptr %t92, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l66, !tbaa !29
  %t94 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v2, ptr %t94)
  store i64 %t96, ptr %l68
  br label %bb16
bb16:
  %t97 = load i64, ptr %l68, !tbaa !24
  %t98 = load ptr, ptr %l66, !tbaa !29
  %t99 = getelementptr %"compiler/free:walker", ptr %t98, i32 0, i32 37
  store i64 %t97, ptr %t99, !tbaa !24
  br label %bb17
bb17:
  %t100 = ptrtoint ptr %s0 to i64
  store i64 %t100, ptr %l69, !tbaa !24
  %t101 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eassign_2elocal_2e10
  br i1 %t101, label %bb18, label %bb19
bb18:
  %t103 = call ptr @__olang_region_make(ptr %s0)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l69, !tbaa !24
  br label %bb19
bb19:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t107 = load i64, ptr %l69
  %t108 = inttoptr i64 %t107 to ptr
  %t111 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %t108, ptr %t105, ptr %t106)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t111, ptr %l73
  br label %bb20
bb20:
  %t112 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eassign_2elocal_2e10
  br i1 %t112, label %bb21, label %bb22
bb21:
  %t114 = load i64, ptr %l69
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = call ptr @__olang_region_or(ptr %t118, ptr null)
  %t120 = icmp ne ptr %t119, null
  %t121 = select i1 %t120, ptr %t119, ptr null
  %t122 = icmp eq ptr %t121, %t115
  call void @__olang_region_settle(ptr %t115, i1 %t122)
  br label %bb22
bb22:
  %t123 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %l10
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb23, label %bb24
bb23:
  %t130 = ptrtoint ptr %s0 to i64
  store i64 %t130, ptr %l78, !tbaa !24
  %t131 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eassign_2elocal_2e10
  br i1 %t131, label %bb25, label %bb26
bb24:
  br label %bb32
bb25:
  %t133 = call ptr @__olang_region_make(ptr %s0)
  %t134 = ptrtoint ptr %t133 to i64
  store i64 %t134, ptr %l78, !tbaa !24
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t141 = load i64, ptr %l78
  %t142 = inttoptr i64 %t141 to ptr
  %t143 = call ptr @__olang_scope_alloc_a(ptr %t142, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %t143
  %t144 = load i64, ptr %l78
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = load i64, ptr %l78
  %t147 = inttoptr i64 %t146 to ptr
  %t150 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %t145, ptr %t147, ptr %t138, ptr %t143)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %l84
  br label %bb27
bb27:
  %t151 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eassign_2elocal_2e10
  br i1 %t151, label %bb28, label %bb29
bb28:
  %t153 = load i64, ptr %l78
  %t154 = inttoptr i64 %t153 to ptr
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = call ptr @__olang_region_or(ptr %t157, ptr null)
  %t159 = icmp ne ptr %t158, null
  %t160 = select i1 %t159, ptr %t158, ptr null
  %t161 = icmp eq ptr %t160, %t154
  call void @__olang_region_settle(ptr %t154, i1 %t161)
  br label %bb29
bb29:
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l86
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l10
  %t164 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eassign_2elocal_2e10
  br i1 %t164, label %bb30, label %bb31
bb30:
  %t166 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86, i32 0, i32 0
  %t167 = load { i64, ptr }, ptr %t166
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = call ptr @__olang_region_or(ptr %t168, ptr null)
  %t170 = icmp ne ptr %t169, null
  %t171 = select i1 %t170, ptr %t169, ptr null
  call void @__olang_region_drop(ptr %t171)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l86
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = load i64, ptr %l9, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/free:walker", ptr %t176, i32 0, i32 36
  store i64 %t172, ptr %t180, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 37
  store i64 %t174, ptr %t185, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l5, !tbaa !24
  %t190 = getelementptr %"compiler/free:walker", ptr %t186, i32 0, i32 33
  store i64 %t187, ptr %t190, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i64, ptr %l6, !tbaa !24
  %t195 = getelementptr %"compiler/free:walker", ptr %t191, i32 0, i32 34
  store i64 %t192, ptr %t195, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/free:walker", ptr %t196, i32 0, i32 9
  %t200 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %s0, ptr %t198)
  %t201 = extractvalue { i32, ptr } %t200, 1
  %t202 = extractvalue { i32, ptr } %t200, 0
  store i32 %t202, ptr %l102
  %t203 = icmp ne i32 %t202, 0
  br i1 %t203, label %bb34, label %ok.204, !prof !99
ok.204:
  store ptr %t201, ptr %l101
  br label %bb33
bb33:
  %t205 = load ptr, ptr %l101, !tbaa !29
  store ptr %t205, ptr %l98, !tbaa !29
  br label %bb36
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t206 = load ptr, ptr %l2, !tbaa !29
  store ptr %t206, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t207 = load ptr, ptr %l103, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb37, label %bb38
bb37:
  %t210 = load ptr, ptr %l103, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 8}
  %t213 = icmp eq i64 %t211, 0
  store i1 %t213, ptr %l104, !tbaa !21
  br label %bb38
bb38:
  %t214 = load i1, ptr %l104, !tbaa !21
  %t215 = xor i1 %t214, true
  br i1 %t215, label %bb39, label %bb40
bb39:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t217)
  store ptr %t219, ptr %l110
  br label %bb41
bb40:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb46
bb41:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t220)
  store ptr %t222, ptr %l112
  br label %bb42
bb42:
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t225 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t223)
  store i32 %t225, ptr %l114
  br label %bb43
bb43:
  %t226 = load ptr, ptr %l112, !tbaa !29
  %t227 = load i32, ptr %l114, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l115
  br label %bb44
bb44:
  %t229 = load ptr, ptr %l110, !tbaa !29
  %t230 = load i32, ptr %l115, !tbaa !23
  %t231 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t229, i32 %t230)
  store i32 %t231, ptr %l116
  br label %bb45
bb45:
  %t232 = load i32, ptr %l116, !range !{i32 0, i32 33}
  %t234 = trunc i64 19 to i32
  %t235 = icmp eq i32 %t232, %t234
  store i1 %t235, ptr %l108, !tbaa !21
  br label %bb46
bb46:
  %t237 = load i1, ptr %l108, !tbaa !21
  br i1 %t237, label %bb47, label %bb48
bb47:
  %t238 = load ptr, ptr %l3, !tbaa !29
  %t240 = call i1 @compiler_2ffree_2ecopiedStore(ptr %v2, ptr %t238)
  store i1 %t240, ptr %l121
  br label %bb49
bb48:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb50
bb49:
  %t241 = load i1, ptr %l121, !tbaa !21
  store i1 %t241, ptr %l119, !tbaa !21
  br label %bb50
bb50:
  %t242 = load i1, ptr %l119, !tbaa !21
  br i1 %t242, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s4
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l122, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t244)
  store i32 %t246, ptr %l124
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t247 = load %"compiler/source:Span", ptr %l1
  %t248 = load ptr, ptr %l122, !tbaa !29
  %t249 = load i32, ptr %l124, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %s4, ptr %t248, i32 %t249, %"compiler/source:Span" %t247, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb55:
  %t251 = load ptr, ptr %l2, !tbaa !29
  store ptr %t251, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t252 = load ptr, ptr %l126, !tbaa !29
  %t253 = icmp ne ptr %t252, null
  br i1 %t253, label %bb56, label %bb57
bb56:
  %t255 = load ptr, ptr %l126, !tbaa !29
  %t256 = load i64, ptr %t255, !range !{i64 0, i64 8}
  %t258 = icmp eq i64 %t256, 0
  store i1 %t258, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t259 = load i1, ptr %l127, !tbaa !21
  br i1 %t259, label %bb58, label %bb59
bb58:
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t262 = getelementptr { i64, [4 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t262, i32 0, i32 2
  %t264 = load i32, ptr %t263
  store i32 %t264, ptr %l13, !tbaa !23
  br label %bb60
bb59:
  br label %bb83
bb60:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l13, !tbaa !23
  %t269 = sext i32 %t267 to i64
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t266, i64 %t269, ptr %l10)
  br label %bb61
bb61:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/free:walker", ptr %t273, i32 0, i32 7
  %t276 = load i32, ptr %l13, !tbaa !23
  %t278 = sext i32 %t276 to i64
  %t281 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t275, i64 %t278)
  %t282 = extractvalue { i32, i64 } %t281, 1
  %t283 = extractvalue { i32, i64 } %t281, 0
  store i32 %t283, ptr %l142
  %t284 = icmp ne i32 %t283, 0
  br i1 %t284, label %bb63, label %ok.285, !prof !99
ok.285:
  store i64 %t282, ptr %l141
  br label %bb62
bb62:
  %t286 = load i64, ptr %l141, !tbaa !24
  store i64 %t286, ptr %l136, !tbaa !24
  br label %bb65
bb63:
  br label %bb64
bb64:
  store i64 -1, ptr %l136, !tbaa !24
  br label %bb65
bb65:
  %t287 = load i64, ptr %l136, !tbaa !24
  store i64 %t287, ptr %l14, !tbaa !24
  %t288 = load i64, ptr %l14, !tbaa !24
  %t290 = icmp sge i64 %t288, 0
  br i1 %t290, label %bb66, label %bb67
bb66:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load i64, ptr %l14, !tbaa !24
  %t294 = load ptr, ptr %l3, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v2, ptr %s0, ptr %t292, i64 %t293, ptr %t294, ptr %l10, %"compiler/source:Span" %t295)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  %t301 = load i64, ptr %l14, !tbaa !24
  %t303 = icmp sge i64 %t301, 0
  br i1 %t303, label %bb70, label %bb71
bb70:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i64, ptr %l14, !tbaa !24
  %t307 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeField(ptr %v0, ptr %v2, ptr %t305, i64 %t306, ptr %t307)
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i32, ptr %l13, !tbaa !23
  %t314 = sext i32 %t312 to i64
  %t317 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t311, i64 %t314)
  store i64 %t317, ptr %l158
  br label %bb74
bb74:
  %t318 = load i64, ptr %l158, !tbaa !24
  store i64 %t318, ptr %l15, !tbaa !24
  %t319 = load i64, ptr %l15, !tbaa !24
  %t321 = icmp sge i64 %t319, 0
  br i1 %t321, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s8
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l161, !tbaa !29
  %t324 = load i64, ptr %l15, !tbaa !24
  store i64 %t324, ptr %l162, !tbaa !24
  %t325 = load ptr, ptr %l3, !tbaa !29
  store ptr %t325, ptr %l163, !tbaa !29
  store ptr %l10, ptr %l164, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t326, ptr %l165
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i32, ptr %l13, !tbaa !23
  %t330 = sext i32 %t328 to i64
  %t333 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s8, ptr %t327, i64 %t330)
  store { i64, ptr } %t333, ptr %l169
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t334 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = extractvalue { i64, ptr } %t334, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  %t341 = load ptr, ptr %l161, !tbaa !29
  %t342 = load i64, ptr %l162, !tbaa !24
  %t343 = load ptr, ptr %l163, !tbaa !29
  %t344 = load ptr, ptr %l164, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l165
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s8, ptr %t341, i64 %t342, ptr %t343, ptr %t344, %"compiler/source:Span" %t345, { i64, ptr } %t340, i1 false)
  br label %bb78
bb78:
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l171, !tbaa !29
  %t348 = load i64, ptr %l15, !tbaa !24
  store i64 %t348, ptr %l172, !tbaa !24
  %t349 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t349, ptr %l173, !tbaa !24
  %t350 = load ptr, ptr %l2, !tbaa !29
  %t352 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t350)
  store %"compiler/source:Span" %t352, ptr %l175
  br label %bb79
bb79:
  %t353 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 0, i32 0)
  store %"compiler/source:Span" %t353, ptr %l176
  br label %bb80
bb80:
  %t354 = load ptr, ptr %l171, !tbaa !29
  %t355 = load i64, ptr %l172, !tbaa !24
  %t356 = load i64, ptr %l173, !tbaa !24
  %t357 = load %"compiler/source:Span", ptr %l175
  %t358 = load %"compiler/source:Span", ptr %l176
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t354, i64 %t355, i64 %t356, %"compiler/source:Span" %t357, %"compiler/source:Span" %t358, i64 -1)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s8)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb83:
  br i1 true, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_620cc86993d1ee05_2ed463b6a2f232e1)
  unreachable
bb88:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/free:walker", ptr %t359, i32 0, i32 0
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t363 = load ptr, ptr %l2, !tbaa !29
  %t366 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t362, ptr %t363)
  store i64 %t366, ptr %l180
  br label %bb89
bb89:
  %t367 = load i64, ptr %l180, !tbaa !24
  store i64 %t367, ptr %l16, !tbaa !24
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l181, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l2, !tbaa !29
  %t373 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %s0, ptr %t369, ptr %t370)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t373, ptr %l184
  br label %bb90
bb90:
  %t374 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l184
  %t375 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t374, ptr %t375
  %t376 = load i64, ptr %l16, !tbaa !24
  %t377 = load %"compiler/source:Span", ptr %l1
  %t378 = load ptr, ptr %l181, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %s0, ptr %s0, ptr %t378, ptr %t375, i64 %t376, %"compiler/source:Span" %t377, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb91
bb91:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/free:walker", ptr %t382, i32 0, i32 2
  %t385 = load i1, ptr %t384, !tbaa !21
  br i1 %t385, label %bb92, label %bb93
bb92:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l2, !tbaa !29
  %t389 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %t387, ptr %t388, ptr %t389)
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l193, !tbaa !29
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load ptr, ptr %l2, !tbaa !29
  %t398 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %t394, ptr %t395)
  store i64 %t398, ptr %l196
  br label %bb96
bb96:
  %t399 = load i64, ptr %l196, !tbaa !24
  %t400 = load ptr, ptr %l193, !tbaa !29
  %t401 = getelementptr %"compiler/free:walker", ptr %t400, i32 0, i32 31
  store i64 %t399, ptr %t401, !tbaa !24
  %t402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t402, ptr %l197, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load ptr, ptr %l3, !tbaa !29
  %t405 = load ptr, ptr %l2, !tbaa !29
  %t409 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v2, ptr %v1, ptr %t403, ptr %t404, ptr %t405)
  store i1 %t409, ptr %l201
  br label %bb97
bb97:
  %t410 = load i1, ptr %l201, !tbaa !21
  br i1 %t410, label %bb98, label %bb99
bb98:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load ptr, ptr %l2, !tbaa !29
  %t415 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %t411, ptr %t412)
  store i64 %t415, ptr %l205
  br label %bb100
bb99:
  store i64 -1, ptr %l202, !tbaa !24
  br label %bb101
bb100:
  %t416 = load i64, ptr %l205, !tbaa !24
  store i64 %t416, ptr %l202, !tbaa !24
  br label %bb101
bb101:
  %t417 = load i64, ptr %l202, !tbaa !24
  %t418 = load ptr, ptr %l197, !tbaa !29
  %t419 = getelementptr %"compiler/free:walker", ptr %t418, i32 0, i32 32
  store i64 %t417, ptr %t419, !tbaa !24
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load ptr, ptr %l2, !tbaa !29
  %t424 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t420, ptr %t421)
  store i64 %t424, ptr %l208
  br label %bb102
bb102:
  %t425 = load i64, ptr %l208, !tbaa !24
  store i64 %t425, ptr %l17, !tbaa !24
  %t426 = load i64, ptr %l17, !tbaa !24
  %t428 = icmp sge i64 %t426, 0
  br i1 %t428, label %bb103, label %bb104
bb103:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i64, ptr %l17, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t430, i64 %t431, ptr %l10)
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb106
bb106:
  %t435 = load ptr, ptr %l2, !tbaa !29
  store ptr %t435, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t436 = load ptr, ptr %l214, !tbaa !29
  %t437 = icmp ne ptr %t436, null
  br i1 %t437, label %bb107, label %bb108
bb107:
  %t439 = load ptr, ptr %l214, !tbaa !29
  %t440 = load i64, ptr %t439, !range !{i64 0, i64 8}
  %t442 = icmp eq i64 %t440, 3
  store i1 %t442, ptr %l215, !tbaa !21
  br label %bb108
bb108:
  %t443 = load i1, ptr %l215, !tbaa !21
  br i1 %t443, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb148
bb111:
  store %olang.scope zeroinitializer, ptr %s12
  %t444 = load i64, ptr %l16, !tbaa !24
  %t446 = icmp sge i64 %t444, 0
  br i1 %t446, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s13
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l220, !tbaa !29
  %t449 = load i64, ptr %l16, !tbaa !24
  store i64 %t449, ptr %l221, !tbaa !24
  %t450 = load ptr, ptr %l3, !tbaa !29
  store ptr %t450, ptr %l222, !tbaa !29
  store ptr %l10, ptr %l223, !tbaa !29
  %t451 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t451, ptr %l224
  %t452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t452, ptr %l225, !tbaa !29
  %t453 = load ptr, ptr %l2, !tbaa !29
  %t455 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t453)
  store %"compiler/source:Span" %t455, ptr %l227
  br label %bb114
bb113:
  br label %bb120
bb114:
  %t456 = load ptr, ptr %l225, !tbaa !29
  %t457 = load %"compiler/source:Span", ptr %l227
  %t458 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s13, ptr %t456, %"compiler/source:Span" %t457)
  store { i64, ptr } %t458, ptr %l228
  br label %bb115
bb115:
  %t459 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t459, 0
  %t461 = extractvalue { i64, ptr } %t459, 1
  %t462 = mul i64 %t460, 1
  %t463 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t462)
  call void @llvm.memcpy.p0.p0.i64(ptr %t463, ptr %t461, i64 %t462, i1 false)
  %t464 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t463, 1
  %t466 = load i64, ptr %l17, !tbaa !24
  %t468 = icmp sge i64 %t466, 0
  %t469 = load ptr, ptr %l220, !tbaa !29
  %t470 = load i64, ptr %l221, !tbaa !24
  %t471 = load ptr, ptr %l222, !tbaa !29
  %t472 = load ptr, ptr %l223, !tbaa !29
  %t473 = load %"compiler/source:Span", ptr %l224
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s13, ptr %t469, i64 %t470, ptr %t471, ptr %t472, %"compiler/source:Span" %t473, { i64, ptr } %t465, i1 %t468)
  br label %bb116
bb116:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/free:walker", ptr %t476, i32 0, i32 31
  store i64 -1, ptr %t478, !tbaa !24
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/free:walker", ptr %t479, i32 0, i32 32
  store i64 -1, ptr %t481, !tbaa !24
  %t482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t482, ptr %l234, !tbaa !29
  %t483 = load i64, ptr %l16, !tbaa !24
  store i64 %t483, ptr %l235, !tbaa !24
  %t484 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t484, ptr %l236, !tbaa !24
  %t485 = load ptr, ptr %l2, !tbaa !29
  %t487 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t485)
  store %"compiler/source:Span" %t487, ptr %l238
  br label %bb117
bb117:
  %t488 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s13, i32 0, i32 0)
  store %"compiler/source:Span" %t488, ptr %l239
  br label %bb118
bb118:
  %t489 = load ptr, ptr %l234, !tbaa !29
  %t490 = load i64, ptr %l235, !tbaa !24
  %t491 = load i64, ptr %l236, !tbaa !24
  %t492 = load %"compiler/source:Span", ptr %l238
  %t493 = load %"compiler/source:Span", ptr %l239
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t489, i64 %t490, i64 %t491, %"compiler/source:Span" %t492, %"compiler/source:Span" %t493, i64 -1)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb120:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/free:walker", ptr %t494, i32 0, i32 0
  %t497 = load ptr, ptr %t496, !tbaa !29
  store ptr %t497, ptr %l241, !tbaa !29
  %t498 = load ptr, ptr %l2, !tbaa !29
  %t500 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t498)
  store i32 %t500, ptr %l243
  br label %bb121
bb121:
  %t501 = load ptr, ptr %l241, !tbaa !29
  %t502 = load i32, ptr %l243, !tbaa !23
  %t503 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t501, i32 %t502)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t503, ptr %l244
  br label %bb122
bb122:
  %t504 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t504, ptr %l18
  store ptr %l18, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s15
  %t506 = load i64, ptr %l20, !tbaa !24
  store i64 %t506, ptr %l246, !tbaa !24
  %t507 = load ptr, ptr %l19, !tbaa !29
  %t509 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s12, ptr %t507)
  store i64 %t509, ptr %l248
  br label %bb124
bb124:
  %t510 = load i64, ptr %l246, !tbaa !24
  %t511 = load i64, ptr %l248, !tbaa !24
  %t512 = icmp slt i64 %t510, %t511
  %t514 = xor i1 %t512, true
  br i1 %t514, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s15)
  br label %bb134
bb126:
  br label %bb127
bb127:
  %t516 = load ptr, ptr %l19, !tbaa !29
  %t517 = load i64, ptr %l20, !tbaa !24
  %t520 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s12, ptr %s12, ptr %t516, i64 %t517)
  store %"compiler/free:leaf" %t520, ptr %l253
  br label %bb128
bb128:
  %t522 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s15, ptr %l253)
  store %"compiler/free:leaf" %t522, ptr %l255
  br label %bb129
bb129:
  %t523 = load %"compiler/free:leaf", ptr %l255
  store %"compiler/free:leaf" %t523, ptr %l21
  %t524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t524, ptr %l256, !tbaa !29
  %t525 = getelementptr %"compiler/free:leaf", ptr %l21, i32 0, i32 1
  %t526 = load i64, ptr %t525, !tbaa !24
  store i64 %t526, ptr %l257, !tbaa !24
  %t527 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  store i64 %t527, ptr %l258, !tbaa !24
  %t528 = load ptr, ptr %l2, !tbaa !29
  %t530 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t528)
  store %"compiler/source:Span" %t530, ptr %l260
  br label %bb130
bb130:
  %t531 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s15, i32 0, i32 0)
  store %"compiler/source:Span" %t531, ptr %l261
  br label %bb131
bb131:
  %t532 = load ptr, ptr %l256, !tbaa !29
  %t533 = load i64, ptr %l257, !tbaa !24
  %t534 = load i64, ptr %l258, !tbaa !24
  %t535 = load %"compiler/source:Span", ptr %l260
  %t536 = load %"compiler/source:Span", ptr %l261
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t532, i64 %t533, i64 %t534, %"compiler/source:Span" %t535, %"compiler/source:Span" %t536, i64 -1)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s15)
  br label %bb133
bb133:
  %t537 = load i64, ptr %l20, !tbaa !24
  %t539 = add i64 %t537, 1
  store i64 %t539, ptr %l20, !tbaa !24
  br label %bb123
bb134:
  %t542 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s12, ptr %l18)
  store i64 %t542, ptr %l265
  br label %bb135
bb135:
  %t543 = load i64, ptr %l265, !tbaa !24
  %t544 = icmp sgt i64 %t543, 0
  br i1 %t544, label %bb136, label %bb137
bb136:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load ptr, ptr %l3, !tbaa !29
  %t548 = load ptr, ptr %l7, !tbaa !29
  %t552 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoredWhole(ptr %v0, ptr %v2, ptr %v0, ptr %t546, ptr %t547, ptr %t548)
  store i1 %t552, ptr %l271
  br label %bb138
bb137:
  store i1 false, ptr %l267, !tbaa !21
  br label %bb139
bb138:
  %t553 = load i1, ptr %l271, !tbaa !21
  %t554 = xor i1 %t553, true
  store i1 %t554, ptr %l267, !tbaa !21
  br label %bb139
bb139:
  %t556 = load i1, ptr %l267, !tbaa !21
  br i1 %t556, label %bb140, label %bb141
bb140:
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l273, !tbaa !29
  store ptr %l18, ptr %l274, !tbaa !29
  %t558 = load ptr, ptr %l2, !tbaa !29
  %t560 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t558)
  store i32 %t560, ptr %l276
  br label %bb142
bb141:
  br label %bb147
bb142:
  %t561 = load ptr, ptr %l3, !tbaa !29
  %t562 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t564 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t562, ptr %t564
  %t565 = load %"compiler/source:Span", ptr %l1
  %t566 = load ptr, ptr %l7, !tbaa !29
  %t567 = load ptr, ptr %l273, !tbaa !29
  %t568 = load ptr, ptr %l274, !tbaa !29
  %t569 = load i32, ptr %l276, !tbaa !23
  %t574 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %s12, ptr %v2, ptr %s0, ptr %v0, ptr %s0, ptr %t567, ptr %t568, i32 %t569, ptr %t561, ptr %t564, %"compiler/source:Span" %t565, ptr %t566)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t574, ptr %l282
  br label %bb143
bb143:
  %t576 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l282)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t576, ptr %l284
  br label %bb144
bb144:
  %t577 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t577, ptr %l285
  %t578 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l284
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t578, ptr %l10
  %t579 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eassign_2elocal_2e10
  br i1 %t579, label %bb145, label %bb146
bb145:
  %t581 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t582 = load { i64, ptr }, ptr %t581
  %t583 = extractvalue { i64, ptr } %t582, 1
  %t584 = call ptr @__olang_region_or(ptr %t583, ptr null)
  %t585 = icmp ne ptr %t584, null
  %t586 = select i1 %t585, ptr %t584, ptr null
  call void @__olang_region_drop(ptr %t586)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l285
  br label %bb146
bb146:
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s12)
  br label %bb195
bb148:
  %t587 = load ptr, ptr %l2, !tbaa !29
  store ptr %t587, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t588 = load ptr, ptr %l287, !tbaa !29
  %t589 = icmp ne ptr %t588, null
  br i1 %t589, label %bb149, label %bb150
bb149:
  %t591 = load ptr, ptr %l287, !tbaa !29
  %t592 = load i64, ptr %t591, !range !{i64 0, i64 8}
  %t594 = icmp eq i64 %t592, 1
  store i1 %t594, ptr %l288, !tbaa !21
  br label %bb150
bb150:
  %t595 = load i1, ptr %l288, !tbaa !21
  br i1 %t595, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb163
bb153:
  %t596 = load i64, ptr %l16, !tbaa !24
  %t598 = icmp sge i64 %t596, 0
  br i1 %t598, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s19
  %t600 = load ptr, ptr %l0, !tbaa !29
  store ptr %t600, ptr %l293, !tbaa !29
  %t601 = load i64, ptr %l16, !tbaa !24
  store i64 %t601, ptr %l294, !tbaa !24
  %t602 = load ptr, ptr %l3, !tbaa !29
  store ptr %t602, ptr %l295, !tbaa !29
  store ptr %l10, ptr %l296, !tbaa !29
  %t603 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t603, ptr %l297
  %t604 = load ptr, ptr %l0, !tbaa !29
  store ptr %t604, ptr %l298, !tbaa !29
  %t605 = load ptr, ptr %l2, !tbaa !29
  %t607 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t605)
  store %"compiler/source:Span" %t607, ptr %l300
  br label %bb156
bb155:
  br label %bb162
bb156:
  %t608 = load ptr, ptr %l298, !tbaa !29
  %t609 = load %"compiler/source:Span", ptr %l300
  %t610 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s19, ptr %t608, %"compiler/source:Span" %t609)
  store { i64, ptr } %t610, ptr %l301
  br label %bb157
bb157:
  %t611 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t612 = extractvalue { i64, ptr } %t611, 0
  %t613 = extractvalue { i64, ptr } %t611, 1
  %t614 = mul i64 %t612, 1
  %t615 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t614)
  call void @llvm.memcpy.p0.p0.i64(ptr %t615, ptr %t613, i64 %t614, i1 false)
  %t616 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  %t618 = load ptr, ptr %l293, !tbaa !29
  %t619 = load i64, ptr %l294, !tbaa !24
  %t620 = load ptr, ptr %l295, !tbaa !29
  %t621 = load ptr, ptr %l296, !tbaa !29
  %t622 = load %"compiler/source:Span", ptr %l297
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s19, ptr %t618, i64 %t619, ptr %t620, ptr %t621, %"compiler/source:Span" %t622, { i64, ptr } %t617, i1 false)
  br label %bb158
bb158:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/free:walker", ptr %t624, i32 0, i32 31
  store i64 -1, ptr %t626, !tbaa !24
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = getelementptr %"compiler/free:walker", ptr %t627, i32 0, i32 32
  store i64 -1, ptr %t629, !tbaa !24
  %t630 = load ptr, ptr %l0, !tbaa !29
  store ptr %t630, ptr %l305, !tbaa !29
  %t631 = load i64, ptr %l16, !tbaa !24
  store i64 %t631, ptr %l306, !tbaa !24
  %t632 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t632, ptr %l307, !tbaa !24
  %t633 = load ptr, ptr %l2, !tbaa !29
  %t635 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t633)
  store %"compiler/source:Span" %t635, ptr %l309
  br label %bb159
bb159:
  %t636 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s19, i32 0, i32 0)
  store %"compiler/source:Span" %t636, ptr %l310
  br label %bb160
bb160:
  %t637 = load ptr, ptr %l305, !tbaa !29
  %t638 = load i64, ptr %l306, !tbaa !24
  %t639 = load i64, ptr %l307, !tbaa !24
  %t640 = load %"compiler/source:Span", ptr %l309
  %t641 = load %"compiler/source:Span", ptr %l310
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t637, i64 %t638, i64 %t639, %"compiler/source:Span" %t640, %"compiler/source:Span" %t641, i64 -1)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb162:
  br label %bb195
bb163:
  %t642 = load ptr, ptr %l2, !tbaa !29
  store ptr %t642, ptr %l311, !tbaa !29
  store i1 false, ptr %l312, !tbaa !21
  %t643 = load ptr, ptr %l311, !tbaa !29
  %t644 = icmp ne ptr %t643, null
  br i1 %t644, label %bb164, label %bb165
bb164:
  %t646 = load ptr, ptr %l311, !tbaa !29
  %t647 = load i64, ptr %t646, !range !{i64 0, i64 8}
  %t649 = icmp eq i64 %t647, 4
  store i1 %t649, ptr %l312, !tbaa !21
  br label %bb165
bb165:
  %t650 = load i1, ptr %l312, !tbaa !21
  br i1 %t650, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb190
bb168:
  store %olang.scope zeroinitializer, ptr %s20
  %t651 = load i64, ptr %l16, !tbaa !24
  %t653 = icmp sge i64 %t651, 0
  br i1 %t653, label %bb169, label %bb170
bb169:
  store %olang.scope zeroinitializer, ptr %s21
  %t655 = load ptr, ptr %l0, !tbaa !29
  store ptr %t655, ptr %l317, !tbaa !29
  %t656 = load i64, ptr %l16, !tbaa !24
  store i64 %t656, ptr %l318, !tbaa !24
  %t657 = load ptr, ptr %l3, !tbaa !29
  store ptr %t657, ptr %l319, !tbaa !29
  store ptr %l10, ptr %l320, !tbaa !29
  %t658 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t658, ptr %l321
  %t659 = load ptr, ptr %l0, !tbaa !29
  store ptr %t659, ptr %l322, !tbaa !29
  %t660 = load ptr, ptr %l2, !tbaa !29
  %t662 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t660)
  store %"compiler/source:Span" %t662, ptr %l324
  br label %bb171
bb170:
  br label %bb174
bb171:
  %t663 = load ptr, ptr %l322, !tbaa !29
  %t664 = load %"compiler/source:Span", ptr %l324
  %t665 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s21, ptr %t663, %"compiler/source:Span" %t664)
  store { i64, ptr } %t665, ptr %l325
  br label %bb172
bb172:
  %t666 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t666, 0
  %t668 = extractvalue { i64, ptr } %t666, 1
  %t669 = mul i64 %t667, 1
  %t670 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t669)
  call void @llvm.memcpy.p0.p0.i64(ptr %t670, ptr %t668, i64 %t669, i1 false)
  %t671 = insertvalue { i64, ptr } undef, i64 %t667, 0
  %t672 = insertvalue { i64, ptr } %t671, ptr %t670, 1
  %t673 = load i64, ptr %l17, !tbaa !24
  %t675 = icmp sge i64 %t673, 0
  %t676 = load ptr, ptr %l317, !tbaa !29
  %t677 = load i64, ptr %l318, !tbaa !24
  %t678 = load ptr, ptr %l319, !tbaa !29
  %t679 = load ptr, ptr %l320, !tbaa !29
  %t680 = load %"compiler/source:Span", ptr %l321
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s21, ptr %t676, i64 %t677, ptr %t678, ptr %t679, %"compiler/source:Span" %t680, { i64, ptr } %t672, i1 %t675)
  br label %bb173
bb173:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/free:walker", ptr %t683, i32 0, i32 31
  store i64 -1, ptr %t685, !tbaa !24
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/free:walker", ptr %t686, i32 0, i32 32
  store i64 -1, ptr %t688, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb174:
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t691 = getelementptr %"compiler/free:walker", ptr %t689, i32 0, i32 0
  %t692 = load ptr, ptr %t691, !tbaa !29
  store ptr %t692, ptr %l332, !tbaa !29
  %t693 = load ptr, ptr %l2, !tbaa !29
  %t695 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t693)
  store i32 %t695, ptr %l334
  br label %bb175
bb175:
  %t696 = load ptr, ptr %l332, !tbaa !29
  %t697 = load i32, ptr %l334, !tbaa !23
  %t698 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t696, i32 %t697)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t698, ptr %l335
  br label %bb176
bb176:
  %t699 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l335
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t699, ptr %l22
  %t701 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s20, ptr %l22)
  store i64 %t701, ptr %l337
  br label %bb177
bb177:
  %t702 = load i64, ptr %l337, !tbaa !24
  %t703 = icmp sgt i64 %t702, 0
  br i1 %t703, label %bb178, label %bb179
bb178:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load ptr, ptr %l3, !tbaa !29
  %t707 = load ptr, ptr %l7, !tbaa !29
  %t711 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoredWhole(ptr %v0, ptr %v2, ptr %v0, ptr %t705, ptr %t706, ptr %t707)
  store i1 %t711, ptr %l343
  br label %bb180
bb179:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb181
bb180:
  %t712 = load i1, ptr %l343, !tbaa !21
  %t713 = xor i1 %t712, true
  store i1 %t713, ptr %l339, !tbaa !21
  br label %bb181
bb181:
  %t715 = load i1, ptr %l339, !tbaa !21
  br i1 %t715, label %bb182, label %bb183
bb182:
  %t716 = load ptr, ptr %l0, !tbaa !29
  store ptr %t716, ptr %l345, !tbaa !29
  store ptr %l22, ptr %l346, !tbaa !29
  %t717 = load ptr, ptr %l2, !tbaa !29
  %t719 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t717)
  store i32 %t719, ptr %l348
  br label %bb184
bb183:
  br label %bb189
bb184:
  %t720 = load ptr, ptr %l3, !tbaa !29
  %t721 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t723 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t721, ptr %t723
  %t724 = load %"compiler/source:Span", ptr %l1
  %t725 = load ptr, ptr %l7, !tbaa !29
  %t726 = load ptr, ptr %l345, !tbaa !29
  %t727 = load ptr, ptr %l346, !tbaa !29
  %t728 = load i32, ptr %l348, !tbaa !23
  %t733 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %s20, ptr %v2, ptr %s0, ptr %v0, ptr %s0, ptr %t726, ptr %t727, i32 %t728, ptr %t720, ptr %t723, %"compiler/source:Span" %t724, ptr %t725)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t733, ptr %l354
  br label %bb185
bb185:
  %t735 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l354)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t735, ptr %l356
  br label %bb186
bb186:
  %t736 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t736, ptr %l357
  %t737 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l356
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t737, ptr %l10
  %t738 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eassign_2elocal_2e10
  br i1 %t738, label %bb187, label %bb188
bb187:
  %t740 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l357, i32 0, i32 0
  %t741 = load { i64, ptr }, ptr %t740
  %t742 = extractvalue { i64, ptr } %t741, 1
  %t743 = call ptr @__olang_region_or(ptr %t742, ptr null)
  %t744 = icmp ne ptr %t743, null
  %t745 = select i1 %t744, ptr %t743, ptr null
  call void @__olang_region_drop(ptr %t745)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l357
  br label %bb188
bb188:
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s20)
  br label %bb195
bb190:
  br i1 true, label %bb191, label %bb192
bb191:
  br label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb195
bb194:
  call void @__olang_check_failed(ptr @olang_loc_e251e9e241135754_793c210c71879d50)
  unreachable
bb195:
  %t746 = load i64, ptr %l17, !tbaa !24
  %t748 = icmp slt i64 %t746, 0
  br i1 %t748, label %bb196, label %bb197
bb196:
  store %olang.scope zeroinitializer, ptr %s24
  %t750 = load ptr, ptr %l0, !tbaa !29
  store ptr %t750, ptr %l361, !tbaa !29
  store ptr %l10, ptr %l362, !tbaa !29
  %t751 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t751, ptr %l363
  %t752 = load ptr, ptr %l0, !tbaa !29
  store ptr %t752, ptr %l364, !tbaa !29
  %t753 = load ptr, ptr %l2, !tbaa !29
  %t755 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t753)
  store %"compiler/source:Span" %t755, ptr %l366
  br label %bb198
bb197:
  br label %bb202
bb198:
  %t756 = load ptr, ptr %l364, !tbaa !29
  %t757 = load %"compiler/source:Span", ptr %l366
  %t758 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s24, ptr %t756, %"compiler/source:Span" %t757)
  store { i64, ptr } %t758, ptr %l367
  br label %bb199
bb199:
  %t759 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t760 = extractvalue { i64, ptr } %t759, 0
  %t761 = extractvalue { i64, ptr } %t759, 1
  %t762 = mul i64 %t760, 1
  %t763 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t762)
  call void @llvm.memcpy.p0.p0.i64(ptr %t763, ptr %t761, i64 %t762, i1 false)
  %t764 = insertvalue { i64, ptr } undef, i64 %t760, 0
  %t765 = insertvalue { i64, ptr } %t764, ptr %t763, 1
  store { i64, ptr } %t765, ptr %l368, !tbaa !27
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load ptr, ptr %l2, !tbaa !29
  %t770 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %t766, ptr %t767)
  store i64 %t770, ptr %l371
  br label %bb200
bb200:
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t773 = getelementptr %"compiler/free:walker", ptr %t771, i32 0, i32 32
  %t774 = load i64, ptr %t773, !tbaa !24
  %t775 = load ptr, ptr %l361, !tbaa !29
  %t776 = load ptr, ptr %l362, !tbaa !29
  %t777 = load %"compiler/source:Span", ptr %l363
  %t778 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t779 = load i64, ptr %l371, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s0, ptr %s24, ptr %t775, ptr %t776, %"compiler/source:Span" %t777, { i64, ptr } %t778, i1 true, i64 %t779, i64 %t774)
  br label %bb201
bb201:
  call void @__olang_scope_close(ptr %s24)
  br label %bb202
bb202:
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t783 = getelementptr %"compiler/free:walker", ptr %t781, i32 0, i32 31
  store i64 -1, ptr %t783, !tbaa !24
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t786 = getelementptr %"compiler/free:walker", ptr %t784, i32 0, i32 32
  store i64 -1, ptr %t786, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l26 = alloca i64
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l56 = alloca i1
  %l68 = alloca { i64, ptr }
  %l84 = alloca i64
  %l87 = alloca i64
  %l106 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca i1
  %l114 = alloca ptr
  %l117 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Block", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l23, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = add i64 %t56, 1
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Block", ptr %t59, i32 0, i32 1
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t67 = icmp slt i64 %t58, %t64
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Block", ptr %t69, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l52, !tbaa !27
  %t73 = load i64, ptr %l8, !tbaa !24
  %t75 = add i64 %t73, 1
  %t77 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  %t82 = call i1 @compiler_2ffree_2eleaves(ptr %v1, ptr %t80)
  store i1 %t82, ptr %l56
  br label %bb14
bb13:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb15
bb14:
  %t83 = load i1, ptr %l56, !tbaa !21
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb15
bb15:
  %t84 = load i1, ptr %l50, !tbaa !21
  br i1 %t84, label %bb16, label %bb17
bb16:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/free:walker", ptr %t88, i32 0, i32 11
  %t91 = load i64, ptr %t90, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t87, i64 %t91)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/free:walker", ptr %t94, i32 0, i32 2
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb20, label %bb21
bb20:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/free:walker", ptr %t99, i32 0, i32 11
  %t102 = load i64, ptr %t101, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t102)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Block", ptr %t106, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l68, !tbaa !27
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 %t110
  %t115 = load ptr, ptr %t114, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t105, ptr %t115)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l7, !tbaa !24
  br label %bb8
bb26:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecloseAt(ptr %v0, ptr %v1, ptr %t122, ptr %t123)
  br label %bb27
bb27:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:walker", ptr %t126, i32 0, i32 2
  %t129 = load i1, ptr %t128, !tbaa !21
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  store i64 0, ptr %l9, !tbaa !24
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Block", ptr %t133, i32 0, i32 1
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  store i64 %t138, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = icmp sgt i64 %t140, %t141
  br i1 %t144, label %bb31, label %bb32
bb31:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp sgt i64 %t146, 0
  br i1 %t148, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb36
bb33:
  %t150 = load i64, ptr %l10, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = sub i64 %t150, %t151
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = add i64 %t154, %t155
  %t160 = sub i64 %t158, 1
  %t161 = load i64, ptr %l11, !tbaa !24
  %t164 = sdiv i64 %t160, %t161
  store i64 %t164, ptr %l87, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb35
bb35:
  %t166 = load i64, ptr %l87, !tbaa !24
  store i64 %t166, ptr %l84, !tbaa !24
  br label %bb36
bb36:
  %t167 = load i64, ptr %l84, !tbaa !24
  store i64 %t167, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb37
bb37:
  %t168 = load i64, ptr %l13, !tbaa !24
  %t169 = load i64, ptr %l12, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb38, label %bb39
bb38:
  br label %bb55
bb39:
  br label %bb40
bb40:
  %t176 = load i64, ptr %l9, !tbaa !24
  %t177 = load i64, ptr %l13, !tbaa !24
  %t178 = load i64, ptr %l11, !tbaa !24
  %t181 = mul i64 %t177, %t178
  %t184 = add i64 %t176, %t181
  store i64 %t184, ptr %l14, !tbaa !24
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Block", ptr %t186, i32 0, i32 1
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l106, !tbaa !27
  %t190 = load i64, ptr %l14, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr ptr, ptr %t193, i64 %t190
  %t195 = load ptr, ptr %t194, !tbaa !39
  store ptr %t195, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t198 = load ptr, ptr %l109, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb41, label %bb42
bb41:
  %t201 = load ptr, ptr %l109, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 17}
  %t204 = icmp eq i64 %t202, 12
  store i1 %t204, ptr %l110, !tbaa !21
  br label %bb42
bb42:
  %t205 = load i1, ptr %l110, !tbaa !21
  br i1 %t205, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/free:walker", ptr %t206, i32 0, i32 66
  store ptr %t208, ptr %l114, !tbaa !29
  %t209 = load i64, ptr %l14, !tbaa !24
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t209)
  store i64 %t212, ptr %l117
  br label %bb46
bb46:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/free:walker", ptr %t213, i32 0, i32 11
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = sub i64 %t216, 1
  %t219 = load ptr, ptr %l114, !tbaa !29
  %t220 = load i64, ptr %l117, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t219, i64 %t220, i64 %t218)
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_2fa77e012092fd19_7ffe9e1eddadbc5d)
  unreachable
bb53:
  br label %bb54
bb54:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l13, !tbaa !24
  br label %bb37
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecloseAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i32
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i1
  %l27 = alloca ptr
  %l38 = alloca ptr
  %l44 = alloca %"compiler/typed:BlockInfo"
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 39
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Block", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c6ff733ce949281236b08418b935189(ptr %v0, ptr %v0, ptr %t3, i64 %t9)
  %t13 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t12, 1
  %t14 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t12, 0
  store i32 %t14, ptr %l16
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb2, label %ok.16, !prof !99
ok.16:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l15
  br label %bb1
bb1:
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l18
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l2
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 39
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Block", ptr %t24, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t32 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H48be4d072aa67a39865369f0fe94a62c(ptr %v0, ptr %t23, i64 %t29)
  store i1 %t32, ptr %l24
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:walker", ptr %t33, i32 0, i32 11
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l3, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l27, !tbaa !29
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 11
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = add i64 %t41, 1
  %t45 = load ptr, ptr %l27, !tbaa !29
  %t46 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 11
  store i64 %t43, ptr %t46, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/free:walker", ptr %t47, i32 0, i32 13
  %t50 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t49, i64 %t50)
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 12
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 12
  store i64 %t59, ptr %t62, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l38
  br label %bb8
bb8:
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Body", ptr %t66, i32 0, i32 8
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Block", ptr %t69, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t77 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t68, i64 %t74)
  store %"compiler/typed:BlockInfo" %t77, ptr %l44
  br label %bb9
bb9:
  %t78 = getelementptr %"compiler/typed:BlockInfo", ptr %l44, i32 0, i32 2
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l5
  store ptr %l2, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t82 = load i64, ptr %l7, !tbaa !24
  store i64 %t82, ptr %l47, !tbaa !24
  %t83 = load ptr, ptr %l6, !tbaa !29
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t83)
  store i64 %t85, ptr %l49
  br label %bb11
bb11:
  %t86 = load i64, ptr %l47, !tbaa !24
  %t87 = load i64, ptr %l49, !tbaa !24
  %t88 = icmp slt i64 %t86, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t92, i64 %t93)
  store i32 %t96, ptr %l54
  br label %bb15
bb15:
  %t97 = load i32, ptr %l54, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t97)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l7, !tbaa !24
  br label %bb10
bb18:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 13
  %t111 = load i64, ptr %l3, !tbaa !24
  %t112 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t111, i64 %t112)
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l4, !tbaa !24
  %t120 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 12
  store i64 %t117, ptr %t120, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:leaf"
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/free:leaf"
  %l14 = alloca i64
  %l20 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca %"compiler/free:leaf"
  %l35 = alloca %"compiler/free:leaf"
  %l38 = alloca i1
  %l39 = alloca i1
  %l43 = alloca i1
  %l49 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i1
  %l56 = alloca i1
  %l57 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i64
  %l62 = alloca i32
  %l63 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i1
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca %"compiler/free:leaf"
  %l77 = alloca %"compiler/free:leaf"
  %l81 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca i64
  %l88 = alloca ptr
  %l90 = alloca i64
  %l91 = alloca %"compiler/source:Span"
  %l93 = alloca i64
  %l97 = alloca i64
  %l101 = alloca %"compiler/free:store"
  %l104 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca i64
  %l108 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i64
  %l114 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l122 = alloca i64
  %l124 = alloca i64
  %l126 = alloca ptr
  %l133 = alloca %"compiler/free:store"
  %l134 = alloca ptr
  %l135 = alloca i64
  %l136 = alloca i64
  %l138 = alloca ptr
  %l140 = alloca i64
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca i64
  %l144 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 30
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  store i1 %t18, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l24
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l5
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  store i64 %t25, ptr %l26, !tbaa !24
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t26)
  store i64 %t28, ptr %l28
  br label %bb9
bb9:
  %t29 = load i64, ptr %l26, !tbaa !24
  %t30 = load i64, ptr %l28, !tbaa !24
  %t31 = icmp slt i64 %t29, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t35, i64 %t36)
  store %"compiler/free:leaf" %t39, ptr %l33
  br label %bb13
bb13:
  %t41 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s3, ptr %l33)
  store %"compiler/free:leaf" %t41, ptr %l35
  br label %bb14
bb14:
  %t42 = load %"compiler/free:leaf", ptr %l35
  store %"compiler/free:leaf" %t42, ptr %l8
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t43, i64 %t45)
  store i1 %t48, ptr %l38
  br label %bb15
bb15:
  %t49 = load i1, ptr %l38, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb19
bb17:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 13
  %t53 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t52, i64 %t54)
  store i1 %t57, ptr %l43
  br label %bb18
bb18:
  %t58 = load i1, ptr %l43, !tbaa !21
  store i1 %t58, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t61)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb8
bb25:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = call i64 @compiler_2ffree_2eownCopySite(ptr %v2, ptr %t68)
  store i64 %t70, ptr %l49
  br label %bb26
bb26:
  %t71 = load i64, ptr %l49, !tbaa !24
  store i64 %t71, ptr %l9, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t73, ptr %l51
  br label %bb27
bb27:
  %t74 = load i64, ptr %l51, !tbaa !24
  %t75 = icmp eq i64 %t74, 1
  br i1 %t75, label %bb28, label %bb29
bb28:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = icmp sge i64 %t77, 0
  store i1 %t79, ptr %l53, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t81 = load i1, ptr %l53, !tbaa !21
  br i1 %t81, label %bb31, label %bb32
bb31:
  %t82 = load ptr, ptr %l4, !tbaa !29
  store ptr %t82, ptr %l57, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:walker", ptr %t83, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  store i64 %t86, ptr %l59, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  store i64 %t87, ptr %l60, !tbaa !24
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t88)
  store i32 %t90, ptr %l62
  br label %bb33
bb32:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb36
bb33:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l63, !tbaa !29
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 0)
  store i64 %t93, ptr %l65
  br label %bb34
bb34:
  %t94 = load ptr, ptr %l57, !tbaa !29
  %t95 = load i64, ptr %l59, !tbaa !24
  %t96 = load i64, ptr %l60, !tbaa !24
  %t97 = load i32, ptr %l62, !tbaa !23
  %t98 = load ptr, ptr %l63, !tbaa !29
  %t99 = load i64, ptr %l65, !tbaa !24
  %t100 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitLeaf(ptr %v0, ptr %v1, ptr %t94, i64 %t95, i64 %t96, i32 %t97, ptr %t98, i64 %t99)
  store i1 %t100, ptr %l66
  br label %bb35
bb35:
  %t101 = load i1, ptr %l66, !tbaa !21
  store i1 %t101, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t102 = load i1, ptr %l56, !tbaa !21
  store i1 %t102, ptr %l10, !tbaa !21
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load i64, ptr %l12, !tbaa !24
  store i64 %t105, ptr %l68, !tbaa !24
  %t106 = load ptr, ptr %l11, !tbaa !29
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t106)
  store i64 %t108, ptr %l70
  br label %bb38
bb38:
  %t109 = load i64, ptr %l68, !tbaa !24
  %t110 = load i64, ptr %l70, !tbaa !24
  %t111 = icmp slt i64 %t109, %t110
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb40:
  br label %bb41
bb41:
  %t115 = load ptr, ptr %l11, !tbaa !29
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t115, i64 %t116)
  store %"compiler/free:leaf" %t119, ptr %l75
  br label %bb42
bb42:
  %t121 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s7, ptr %l75)
  store %"compiler/free:leaf" %t121, ptr %l77
  br label %bb43
bb43:
  %t122 = load %"compiler/free:leaf", ptr %l77
  store %"compiler/free:leaf" %t122, ptr %l13
  %t123 = getelementptr %"compiler/free:leaf", ptr %l13, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l5, i64 %t126)
  store i1 %t129, ptr %l81
  br label %bb44
bb44:
  %t130 = load i1, ptr %l81, !tbaa !21
  br i1 %t130, label %bb45, label %bb46
bb45:
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t133 = getelementptr %"compiler/free:Free", ptr %t131, i32 0, i32 83
  store ptr %t133, ptr %l83, !tbaa !29
  %t134 = load i64, ptr %l14, !tbaa !24
  store i64 %t134, ptr %l84, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t135, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l86, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t139)
  store ptr %t141, ptr %l88
  br label %bb47
bb46:
  br label %bb65
bb47:
  %t142 = load ptr, ptr %l88, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 3
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l90, !tbaa !24
  %t146 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t146, ptr %l91
  %t147 = load i1, ptr %l10, !tbaa !21
  br i1 %t147, label %bb48, label %bb49
bb48:
  %t149 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  store i64 %t149, ptr %l93, !tbaa !24
  br label %bb50
bb49:
  %t151 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t151, ptr %l93, !tbaa !24
  br label %bb50
bb50:
  %t153 = load i1, ptr %l10, !tbaa !21
  br i1 %t153, label %bb51, label %bb52
bb51:
  %t155 = load i64, ptr %l9, !tbaa !24
  store i64 %t155, ptr %l97, !tbaa !24
  br label %bb53
bb52:
  store i64 -1, ptr %l97, !tbaa !24
  br label %bb53
bb53:
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = load i64, ptr %l84, !tbaa !24
  %t160 = load i64, ptr %l86, !tbaa !24
  %t161 = load i64, ptr %l90, !tbaa !24
  %t162 = load %"compiler/source:Span", ptr %l91
  %t163 = load i64, ptr %l93, !tbaa !24
  %t164 = load i64, ptr %l97, !tbaa !24
  %t166 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t159, i64 %t160, i64 %t161, %"compiler/source:Span" %t162, i64 %t163, i64 -1, i64 %t164, ptr %t157, ptr null)
  store %"compiler/free:store" %t166, ptr %l101
  br label %bb54
bb54:
  %t167 = load ptr, ptr %l83, !tbaa !29
  %t168 = load %"compiler/free:store", ptr %l101
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t167, %"compiler/free:store" %t168)
  br label %bb55
bb55:
  %t169 = load i1, ptr %l10, !tbaa !21
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t173 = load ptr, ptr %l4, !tbaa !29
  store ptr %t173, ptr %l104, !tbaa !29
  %t174 = load i64, ptr %l14, !tbaa !24
  store i64 %t174, ptr %l105, !tbaa !24
  %t175 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t175, ptr %l106, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t176)
  store ptr %t178, ptr %l108
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t179 = load ptr, ptr %l108, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Body", ptr %t179, i32 0, i32 3
  %t182 = load i64, ptr %t181, !tbaa !24
  store i64 %t182, ptr %l110, !tbaa !24
  %t183 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t183, ptr %l111
  %t184 = ptrtoint ptr %v0 to i64
  store i64 %t184, ptr %l112, !tbaa !24
  %t185 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t185, label %bb59, label %bb60
bb59:
  %t187 = call ptr @__olang_region_make(ptr %v0)
  %t188 = ptrtoint ptr %t187 to i64
  store i64 %t188, ptr %l112, !tbaa !24
  br label %bb60
bb60:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l114, !tbaa !29
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t192 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t190)
  store %"compiler/source:Span" %t192, ptr %l116
  br label %bb61
bb61:
  %t193 = load ptr, ptr %l114, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l116
  %t195 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s9, ptr %t193, %"compiler/source:Span" %t194)
  store { i64, ptr } %t195, ptr %l117
  br label %bb62
bb62:
  %t196 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t198 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 1
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t201 = add i64 %t197, %t200
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t204 = add i64 %t201, %t203
  %t205 = load i64, ptr %l112
  %t206 = inttoptr i64 %t205 to ptr
  %t207 = call ptr @__olang_scope_alloc(ptr %t206, i64 %t204)
  call void @olang_textcopy(ptr %t207, ptr %t196, i64 %t197)
  %t208 = getelementptr i8, ptr %t207, i64 %t197
  call void @olang_textcopy(ptr %t208, ptr %t199, i64 %t200)
  %t209 = getelementptr i8, ptr %t208, i64 %t200
  call void @olang_textcopy(ptr %t209, ptr %t202, i64 %t203)
  %t210 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t207, 1
  %t213 = load i64, ptr %l112
  %t214 = inttoptr i64 %t213 to ptr
  %t215 = extractvalue { i64, ptr } %t211, 0
  %t216 = extractvalue { i64, ptr } %t211, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %t214, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  %t221 = load ptr, ptr %l104, !tbaa !29
  %t222 = load i64, ptr %l105, !tbaa !24
  %t223 = load i64, ptr %l106, !tbaa !24
  %t224 = load i64, ptr %l110, !tbaa !24
  %t225 = load %"compiler/source:Span", ptr %l111
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t221, i64 %t222, i64 %t223, i64 %t224, %"compiler/source:Span" %t225, { i64, ptr } %t220)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb65:
  %t227 = load ptr, ptr %l4, !tbaa !29
  %t229 = getelementptr %"compiler/free:Free", ptr %t227, i32 0, i32 83
  store ptr %t229, ptr %l121, !tbaa !29
  %t230 = load i64, ptr %l14, !tbaa !24
  store i64 %t230, ptr %l122, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/free:walker", ptr %t231, i32 0, i32 1
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l124, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t235)
  store ptr %t237, ptr %l126
  br label %bb66
bb66:
  %t238 = load ptr, ptr %l126, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Body", ptr %t238, i32 0, i32 3
  %t241 = load i64, ptr %t240, !tbaa !24
  %t242 = load %"compiler/source:Span", ptr %l3
  %t243 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = load i64, ptr %l122, !tbaa !24
  %t247 = load i64, ptr %l124, !tbaa !24
  %t252 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t246, i64 %t247, i64 %t241, %"compiler/source:Span" %t242, i64 %t243, i64 -1, i64 -1, ptr %t244, ptr null)
  store %"compiler/free:store" %t252, ptr %l133
  br label %bb67
bb67:
  %t253 = load ptr, ptr %l121, !tbaa !29
  %t254 = load %"compiler/free:store", ptr %l133
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t253, %"compiler/free:store" %t254)
  br label %bb68
bb68:
  %t255 = load ptr, ptr %l4, !tbaa !29
  store ptr %t255, ptr %l134, !tbaa !29
  %t256 = load i64, ptr %l14, !tbaa !24
  store i64 %t256, ptr %l135, !tbaa !24
  %t257 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t257, ptr %l136, !tbaa !24
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t258)
  store ptr %t260, ptr %l138
  br label %bb69
bb69:
  %t261 = load ptr, ptr %l138, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Body", ptr %t261, i32 0, i32 3
  %t264 = load i64, ptr %t263, !tbaa !24
  store i64 %t264, ptr %l140, !tbaa !24
  %t265 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t265, ptr %l141
  %t266 = ptrtoint ptr %v0 to i64
  store i64 %t266, ptr %l142, !tbaa !24
  %t267 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t267, label %bb70, label %bb71
bb70:
  %t269 = call ptr @__olang_region_make(ptr %v0)
  %t270 = ptrtoint ptr %t269 to i64
  store i64 %t270, ptr %l142, !tbaa !24
  br label %bb71
bb71:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l144, !tbaa !29
  %t272 = load ptr, ptr %l2, !tbaa !29
  %t274 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t272)
  store %"compiler/source:Span" %t274, ptr %l146
  br label %bb72
bb72:
  %t275 = load ptr, ptr %l144, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l146
  %t277 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s7, ptr %t275, %"compiler/source:Span" %t276)
  store { i64, ptr } %t277, ptr %l147
  br label %bb73
bb73:
  %t278 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t280 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 1
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t283 = add i64 %t279, %t282
  %t284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t286 = add i64 %t283, %t285
  %t287 = load i64, ptr %l142
  %t288 = inttoptr i64 %t287 to ptr
  %t289 = call ptr @__olang_scope_alloc(ptr %t288, i64 %t286)
  call void @olang_textcopy(ptr %t289, ptr %t278, i64 %t279)
  %t290 = getelementptr i8, ptr %t289, i64 %t279
  call void @olang_textcopy(ptr %t290, ptr %t281, i64 %t282)
  %t291 = getelementptr i8, ptr %t290, i64 %t282
  call void @olang_textcopy(ptr %t291, ptr %t284, i64 %t285)
  %t292 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t289, 1
  %t295 = load i64, ptr %l142
  %t296 = inttoptr i64 %t295 to ptr
  %t297 = extractvalue { i64, ptr } %t293, 0
  %t298 = extractvalue { i64, ptr } %t293, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %t296, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t303 = load ptr, ptr %l134, !tbaa !29
  %t304 = load i64, ptr %l135, !tbaa !24
  %t305 = load i64, ptr %l136, !tbaa !24
  %t306 = load i64, ptr %l140, !tbaa !24
  %t307 = load %"compiler/source:Span", ptr %l141
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t303, i64 %t304, i64 %t305, i64 %t306, %"compiler/source:Span" %t307, { i64, ptr } %t302)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb75:
  %t309 = load i64, ptr %l12, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l12, !tbaa !24
  br label %bb37
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeederArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i64 @compiler_2ffree_2efieldRootLocal(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l13
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %t20, i64 %t21)
  store i64 %t22, ptr %l14
  br label %bb7
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  br label %bb20
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 17
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeederArg(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  store i64 %t43, ptr %l23
  br label %bb14
bb14:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_555e391ca9f1c191_fbd79fc4fd463c05)
  unreachable
bb20:
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %t9, ptr %a2)
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sgt i64 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:walker", ptr %t15, i32 0, i32 4
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t17, i64 %t18)
  store i1 %t21, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:walker", ptr %t24, i32 0, i32 5
  store i1 true, ptr %t26, !tbaa !21
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 69
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t15, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t23 = load i1, ptr %l14, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 69
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t28, i64 %t32, i1 true)
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 77
  store i1 true, ptr %t37, !tbaa !21
  br label %bb7
bb7:
  br label %ret
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l21, !tbaa !29
  %t39 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  store %"compiler/source:Span" %a1, ptr %l24
  %t44 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %a2)
  store %"compiler/source:Span" %t44, ptr %l26
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = load i64, ptr %l23, !tbaa !24
  %t49 = load %"compiler/source:Span", ptr %l24
  %t50 = load %"compiler/source:Span", ptr %l26
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t46, i64 %t47, i64 %t48, %"compiler/source:Span" %t49, %"compiler/source:Span" %t50, i64 %a3)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca { i64, { i64, ptr } }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i1
  %l118 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca i64
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l140 = alloca i64
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, { i64, ptr } }
  %l148 = alloca { i64, ptr }
  %l150 = alloca i64
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l158 = alloca i1
  %l161 = alloca ptr
  %l165 = alloca i64
  %l167 = alloca i64
  %l170 = alloca i1
  %l174 = alloca ptr
  %l179 = alloca i1
  %l183 = alloca i64
  %l193 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l199 = alloca i64
  %l204 = alloca i1
  %l208 = alloca i1
  %l209 = alloca i1
  %l212 = alloca i1
  %l214 = alloca i1
  %l216 = alloca i1
  %l219 = alloca ptr
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l225 = alloca i64
  %l230 = alloca i1
  %l233 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l236 = alloca i64
  %l238 = alloca i64
  %l239 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l252 = alloca %"compiler/free:store"
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l31
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l31, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 3
  %t12 = load i64, ptr %t11, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  store i64 -1, ptr %l8, !tbaa !24
  store i64 -1, ptr %l9, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t16, ptr %l36, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l37, !tbaa !24
  %t19 = load i64, ptr %l37, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l38, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l37, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t30, ptr %lp10
  %t31 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t32 = load ptr, ptr %lp10
  store { i64, ptr } %t31, ptr %t32, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  store ptr %t33, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t34 = load ptr, ptr %l39, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb2, label %bb3
bb2:
  %t37 = load ptr, ptr %l39, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 0
  store i1 %t40, ptr %l40, !tbaa !21
  br label %bb3
bb3:
  %t41 = load i1, ptr %l40, !tbaa !21
  br i1 %t41, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t42 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb111
bb7:
  %t44 = load ptr, ptr %l2, !tbaa !29
  store ptr %t44, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t45 = load ptr, ptr %l44, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l44, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 1
  store i1 %t51, ptr %l45, !tbaa !21
  br label %bb9
bb9:
  %t52 = load i1, ptr %l45, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t53 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  br label %bb111
bb13:
  %t55 = load ptr, ptr %l2, !tbaa !29
  store ptr %t55, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t56 = load ptr, ptr %l49, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l49, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l50, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l50, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l11, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t71 = load ptr, ptr %l11, !tbaa !29
  %t74 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  store i64 %t74, ptr %l57
  br label %bb19
bb19:
  %t75 = load i64, ptr %l57, !tbaa !24
  store i64 %t75, ptr %l12, !tbaa !24
  %t76 = load i64, ptr %l12, !tbaa !24
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = icmp eq i64 %t76, %t77
  br i1 %t80, label %bb20, label %bb21
bb20:
  %t82 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t82, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb25
bb21:
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l63, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t86, ptr %l64, !tbaa !27
  %t87 = load ptr, ptr %lp10
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l66, !tbaa !24
  %t93 = load i64, ptr %l66, !tbaa !24
  %t94 = icmp eq i64 %t89, %t93
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t96 = load ptr, ptr %lp10
  %t97 = getelementptr { i64, ptr }, ptr %t96, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l66, !tbaa !24
  %t102 = mul i64 %t101, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t98, ptr %t100, i64 %t102, i1 false)
  br label %bb24
bb23:
  %t103 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l68, !tbaa !24
  %t105 = load i64, ptr %l68, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l69, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l68, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t117 = load ptr, ptr %lp10
  store { i64, ptr } %t116, ptr %t117, !tbaa !27
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb111
bb26:
  %t118 = load ptr, ptr %l2, !tbaa !29
  store ptr %t118, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t119 = load ptr, ptr %l70, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb27, label %bb28
bb27:
  %t122 = load ptr, ptr %l70, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 18}
  %t125 = icmp eq i64 %t123, 17
  store i1 %t125, ptr %l71, !tbaa !21
  br label %bb28
bb28:
  %t126 = load i1, ptr %l71, !tbaa !21
  br i1 %t126, label %bb29, label %bb30
bb29:
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l13, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  %t135 = load ptr, ptr %l13, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l3
  %t137 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t133, i64 %t134, ptr %t135, %"compiler/source:Span" %t136, i1 %t137)
  br label %bb32
bb32:
  br label %ret
bb33:
  %t143 = load ptr, ptr %l2, !tbaa !29
  store ptr %t143, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t144 = load ptr, ptr %l81, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb34, label %bb35
bb34:
  %t147 = load ptr, ptr %l81, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 18}
  %t150 = icmp eq i64 %t148, 12
  store i1 %t150, ptr %l82, !tbaa !21
  br label %bb35
bb35:
  %t151 = load i1, ptr %l82, !tbaa !21
  br i1 %t151, label %bb36, label %bb37
bb36:
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t154, i32 0, i32 2
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l14, !tbaa !29
  br label %bb38
bb37:
  br label %bb46
bb38:
  %t158 = load ptr, ptr %l14, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Seq", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb39, label %bb40
bb39:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l91, !tbaa !29
  %t168 = load i64, ptr %l1, !tbaa !24
  store i64 %t168, ptr %l92, !tbaa !24
  %t169 = load ptr, ptr %l14, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Seq", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  br i1 %t174, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  call void @__olang_check_failed(ptr @olang_loc_7676aaa4af173342_5bef0e3278c42ba6)
  unreachable
bb42:
  br label %bb43
bb43:
  %t176 = load ptr, ptr %l14, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Seq", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l3
  %t181 = load i1, ptr %l4, !tbaa !21
  %t182 = load ptr, ptr %l91, !tbaa !29
  %t183 = load i64, ptr %l92, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t182, i64 %t183, ptr %t179, %"compiler/source:Span" %t180, i1 %t181)
  br label %bb44
bb44:
  br label %ret
bb45:
  br label %bb111
bb46:
  %t187 = load ptr, ptr %l2, !tbaa !29
  store ptr %t187, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t188 = load ptr, ptr %l100, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb47, label %bb48
bb47:
  %t191 = load ptr, ptr %l100, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 14
  store i1 %t194, ptr %l101, !tbaa !21
  br label %bb48
bb48:
  %t195 = load i1, ptr %l101, !tbaa !21
  br i1 %t195, label %bb49, label %bb50
bb49:
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 2
  %t200 = load ptr, ptr %t199
  store ptr %t200, ptr %l15, !tbaa !29
  br label %bb51
bb50:
  br label %bb71
bb51:
  %t202 = load ptr, ptr %l15, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Try", ptr %t202, i32 0, i32 0
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = icmp eq ptr %t205, null
  %t209 = xor i1 %t207, true
  store i1 %t209, ptr %l16, !tbaa !21
  %t211 = load ptr, ptr %l15, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Try", ptr %t211, i32 0, i32 1
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t216 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t216, 0
  store i64 %t218, ptr %l19, !tbaa !24
  br label %bb52
bb52:
  %t220 = load i64, ptr %l18, !tbaa !24
  %t221 = load i64, ptr %l19, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb53, label %bb54
bb53:
  br label %bb60
bb54:
  br label %bb55
bb55:
  %t228 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t228, ptr %l118, !tbaa !27
  %t229 = load i64, ptr %l18, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr ptr, ptr %t232, i64 %t229
  %t234 = load ptr, ptr %t233, !tbaa !39
  %t238 = getelementptr %"compiler/typed:Clause", ptr %t234, i32 0, i32 4
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t243 = icmp sgt i64 %t241, 0
  br i1 %t243, label %bb56, label %bb57
bb56:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb58
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t245 = load i64, ptr %l18, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l18, !tbaa !24
  br label %bb52
bb60:
  %t249 = load i1, ptr %l16, !tbaa !21
  br i1 %t249, label %bb61, label %bb62
bb61:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l128, !tbaa !29
  %t252 = load i64, ptr %l1, !tbaa !24
  store i64 %t252, ptr %l129, !tbaa !24
  %t253 = load ptr, ptr %l15, !tbaa !29
  %t255 = getelementptr %"compiler/typed:Try", ptr %t253, i32 0, i32 0
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = icmp eq ptr %t256, null
  br i1 %t258, label %bb63, label %bb64
bb62:
  br label %bb67
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a47d70a6f4791f29_9aa1d88f57dbf58d)
  unreachable
bb64:
  br label %bb65
bb65:
  %t260 = load ptr, ptr %l15, !tbaa !29
  %t262 = getelementptr %"compiler/typed:Try", ptr %t260, i32 0, i32 0
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l3
  %t265 = load i1, ptr %l4, !tbaa !21
  %t266 = load ptr, ptr %l128, !tbaa !29
  %t267 = load i64, ptr %l129, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t266, i64 %t267, ptr %t263, %"compiler/source:Span" %t264, i1 %t265)
  br label %bb66
bb66:
  br label %ret
bb67:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l137, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t271, ptr %l138, !tbaa !27
  %t272 = load ptr, ptr %lp10
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  %t275 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 0
  store i64 %t276, ptr %l140, !tbaa !24
  %t278 = load i64, ptr %l140, !tbaa !24
  %t279 = icmp eq i64 %t274, %t278
  br i1 %t279, label %bb68, label %bb69
bb68:
  %t281 = load ptr, ptr %lp10
  %t282 = getelementptr { i64, ptr }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = load i64, ptr %l140, !tbaa !24
  %t287 = mul i64 %t286, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t283, ptr %t285, i64 %t287, i1 false)
  br label %bb70
bb69:
  %t288 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t288, 0
  store i64 %t289, ptr %l142, !tbaa !24
  %t290 = load i64, ptr %l142, !tbaa !24
  %t291 = mul i64 %t290, 1
  %t292 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t291)
  %t293 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  store { i64, ptr } %t294, ptr %l143, !tbaa !27
  %t295 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = load i64, ptr %l142, !tbaa !24
  %t300 = mul i64 %t299, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t296, ptr %t298, i64 %t300, i1 false)
  %t301 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t302 = load ptr, ptr %lp10
  store { i64, ptr } %t301, ptr %t302, !tbaa !27
  br label %bb70
bb70:
  br label %bb111
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb110
bb74:
  store %olang.scope zeroinitializer, ptr %s15
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t307 = call { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %s15, ptr %t303, ptr %t304)
  store { i64, { i64, ptr } } %t307, ptr %l146
  br label %bb75
bb75:
  %t308 = load { i64, { i64, ptr } }, ptr %l146
  store { i64, { i64, ptr } } %t308, ptr %l21
  %t309 = getelementptr { i64, { i64, ptr } }, ptr %l21, i32 0, i32 0
  %t310 = load i64, ptr %t309, !tbaa !24
  store i64 %t310, ptr %l9, !tbaa !24
  %t312 = getelementptr { i64, { i64, ptr } }, ptr %l21, i32 0, i32 1
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  store { i64, ptr } %t313, ptr %l148, !tbaa !27
  %t314 = load ptr, ptr %lp10
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  %t317 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  store i64 %t318, ptr %l150, !tbaa !24
  %t320 = load i64, ptr %l150, !tbaa !24
  %t321 = icmp eq i64 %t316, %t320
  br i1 %t321, label %bb76, label %bb77
bb76:
  %t323 = load ptr, ptr %lp10
  %t324 = getelementptr { i64, ptr }, ptr %t323, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = load i64, ptr %l150, !tbaa !24
  %t329 = mul i64 %t328, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t325, ptr %t327, i64 %t329, i1 false)
  br label %bb78
bb77:
  %t330 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 0
  store i64 %t331, ptr %l152, !tbaa !24
  %t332 = load i64, ptr %l152, !tbaa !24
  %t333 = mul i64 %t332, 1
  %t334 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t333)
  %t335 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  store { i64, ptr } %t336, ptr %l153, !tbaa !27
  %t337 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = load i64, ptr %l152, !tbaa !24
  %t342 = mul i64 %t341, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t338, ptr %t340, i64 %t342, i1 false)
  %t343 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t344 = load ptr, ptr %lp10
  store { i64, ptr } %t343, ptr %t344, !tbaa !27
  br label %bb78
bb78:
  %t345 = load i64, ptr %l9, !tbaa !24
  %t347 = icmp sge i64 %t345, 0
  br i1 %t347, label %bb79, label %bb80
bb79:
  %t349 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  store i64 %t349, ptr %l7, !tbaa !24
  br label %bb109
bb80:
  store %olang.scope zeroinitializer, ptr %s17
  %t351 = load ptr, ptr %lp10
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !27
  %t354 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s17, { i64, ptr } %t352, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t354, ptr %l158
  br label %bb81
bb81:
  %t355 = load i1, ptr %l158, !tbaa !21
  br i1 %t355, label %bb82, label %bb83
bb82:
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t359 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t356)
  store ptr %t359, ptr %l161
  br label %bb84
bb83:
  br label %bb108
bb84:
  %t360 = load ptr, ptr %l161, !tbaa !29
  store ptr %t360, ptr %l22, !tbaa !29
  %t361 = load ptr, ptr %l22, !tbaa !29
  %t363 = icmp eq ptr %t361, null
  %t365 = xor i1 %t363, true
  br i1 %t365, label %bb85, label %bb86
bb85:
  %t367 = load ptr, ptr %l22, !tbaa !29
  %t369 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t367)
  store i64 %t369, ptr %l167
  br label %bb87
bb86:
  store i64 -1, ptr %l165, !tbaa !24
  br label %bb88
bb87:
  %t370 = load i64, ptr %l167, !tbaa !24
  store i64 %t370, ptr %l165, !tbaa !24
  br label %bb88
bb88:
  %t371 = load i64, ptr %l165, !tbaa !24
  store i64 %t371, ptr %l23, !tbaa !24
  %t372 = load i64, ptr %l23, !tbaa !24
  %t374 = icmp sge i64 %t372, 0
  br i1 %t374, label %bb89, label %bb90
bb89:
  %t376 = load ptr, ptr %l5, !tbaa !29
  %t378 = getelementptr %"compiler/free:Free", ptr %t376, i32 0, i32 1
  %t379 = load i64, ptr %l23, !tbaa !24
  %t382 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t378, i64 %t379)
  store ptr %t382, ptr %l174
  br label %bb91
bb90:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb92
bb91:
  %t383 = load ptr, ptr %l174, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Body", ptr %t383, i32 0, i32 11
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t388 = icmp eq ptr %t386, null
  %t390 = xor i1 %t388, true
  store i1 %t390, ptr %l170, !tbaa !21
  br label %bb92
bb92:
  %t392 = load i1, ptr %l170, !tbaa !21
  br i1 %t392, label %bb93, label %bb94
bb93:
  %t393 = load ptr, ptr %l5, !tbaa !29
  %t395 = getelementptr %"compiler/free:Free", ptr %t393, i32 0, i32 73
  %t396 = load i64, ptr %l23, !tbaa !24
  %t399 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t395, i64 %t396)
  store i64 %t399, ptr %l183
  br label %bb95
bb94:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb96
bb95:
  %t400 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t401 = load i64, ptr %l1, !tbaa !24
  %t404 = add i64 %t400, %t401
  %t405 = load i64, ptr %l183, !tbaa !24
  %t407 = icmp eq i64 %t405, %t404
  store i1 %t407, ptr %l179, !tbaa !21
  br label %bb96
bb96:
  %t409 = load i1, ptr %l179, !tbaa !21
  br i1 %t409, label %bb97, label %bb98
bb97:
  %t410 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t410, ptr %l7, !tbaa !24
  %t412 = load i64, ptr %l1, !tbaa !24
  store i64 %t412, ptr %l8, !tbaa !24
  br label %bb99
bb98:
  br label %bb99
bb99:
  %t414 = load i64, ptr %l7, !tbaa !24
  %t415 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t418 = icmp eq i64 %t414, %t415
  br i1 %t418, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s20
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l193, !tbaa !29
  %t421 = load ptr, ptr %l2, !tbaa !29
  %t423 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t421)
  store %"compiler/source:Span" %t423, ptr %l195
  br label %bb102
bb101:
  br label %bb107
bb102:
  %t424 = load ptr, ptr %l193, !tbaa !29
  %t425 = load %"compiler/source:Span", ptr %l195
  %t426 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s20, ptr %t424, %"compiler/source:Span" %t425)
  store { i64, ptr } %t426, ptr %l196
  br label %bb103
bb103:
  %t427 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t428 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t429 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t429, 1
  %t431 = extractvalue { i64, ptr } %t429, 0
  %t432 = add i64 %t428, %t431
  %t433 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t434 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t435 = add i64 %t432, %t434
  %t436 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t435)
  call void @olang_textcopy(ptr %t436, ptr %t427, i64 %t428)
  %t437 = getelementptr i8, ptr %t436, i64 %t428
  call void @olang_textcopy(ptr %t437, ptr %t430, i64 %t431)
  %t438 = getelementptr i8, ptr %t437, i64 %t431
  call void @olang_textcopy(ptr %t438, ptr %t433, i64 %t434)
  %t439 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t436, 1
  store { i64, ptr } %t440, ptr %l197, !tbaa !27
  %t441 = load ptr, ptr %lp10
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t442, 0
  %t444 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  store i64 %t445, ptr %l199, !tbaa !24
  %t447 = load i64, ptr %l199, !tbaa !24
  %t448 = icmp eq i64 %t443, %t447
  br i1 %t448, label %bb104, label %bb105
bb104:
  %t450 = load ptr, ptr %lp10
  %t451 = getelementptr { i64, ptr }, ptr %t450, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = load i64, ptr %l199, !tbaa !24
  %t456 = mul i64 %t455, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t452, ptr %t454, i64 %t456, i1 false)
  br label %bb106
bb105:
  %t457 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t458 = load ptr, ptr %lp10
  store { i64, ptr } %t457, ptr %t458, !tbaa !27
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s20)
  br label %bb107
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s15)
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_c3165b793781225b_53a43f46ee99ca6f)
  unreachable
bb111:
  %t459 = load i64, ptr %l7, !tbaa !24
  %t460 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t463 = icmp eq i64 %t459, %t460
  br i1 %t463, label %bb112, label %bb113
bb112:
  %t465 = load ptr, ptr %l5, !tbaa !29
  %t467 = getelementptr %"compiler/free:Free", ptr %t465, i32 0, i32 13
  %t468 = load i64, ptr %l1, !tbaa !24
  %t471 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t467, i64 %t468)
  store i1 %t471, ptr %l208
  br label %bb114
bb113:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb115
bb114:
  %t472 = load i1, ptr %l208, !tbaa !21
  store i1 %t472, ptr %l204, !tbaa !21
  br label %bb115
bb115:
  %t473 = load i1, ptr %l204, !tbaa !21
  br i1 %t473, label %bb116, label %bb117
bb116:
  %t474 = load ptr, ptr %l5, !tbaa !29
  %t475 = load i64, ptr %l1, !tbaa !24
  %t478 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainElems(ptr %v0, ptr %t474, i64 %t475)
  store i1 %t478, ptr %l212
  br label %bb118
bb117:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb119
bb118:
  %t479 = load i1, ptr %l212, !tbaa !21
  %t480 = xor i1 %t479, true
  store i1 %t480, ptr %l209, !tbaa !21
  br label %bb119
bb119:
  %t482 = load i1, ptr %l209, !tbaa !21
  br i1 %t482, label %bb120, label %bb121
bb120:
  %t483 = load ptr, ptr %l2, !tbaa !29
  %t485 = call i1 @compiler_2ffree_2emovesOnly(ptr %v1, ptr %t483)
  store i1 %t485, ptr %l216
  br label %bb122
bb121:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb123
bb122:
  %t486 = load i1, ptr %l216, !tbaa !21
  %t487 = xor i1 %t486, true
  store i1 %t487, ptr %l214, !tbaa !21
  br label %bb123
bb123:
  %t489 = load i1, ptr %l214, !tbaa !21
  br i1 %t489, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s22
  %t490 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t490, ptr %l7, !tbaa !24
  %t492 = load ptr, ptr %l0, !tbaa !29
  store ptr %t492, ptr %l219, !tbaa !29
  %t493 = load ptr, ptr %l2, !tbaa !29
  %t495 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t493)
  store %"compiler/source:Span" %t495, ptr %l221
  br label %bb126
bb125:
  br label %bb131
bb126:
  %t496 = load ptr, ptr %l219, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l221
  %t498 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s22, ptr %t496, %"compiler/source:Span" %t497)
  store { i64, ptr } %t498, ptr %l222
  br label %bb127
bb127:
  %t499 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t500 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t501 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = add i64 %t500, %t503
  %t505 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t507 = add i64 %t504, %t506
  %t508 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t507)
  call void @olang_textcopy(ptr %t508, ptr %t499, i64 %t500)
  %t509 = getelementptr i8, ptr %t508, i64 %t500
  call void @olang_textcopy(ptr %t509, ptr %t502, i64 %t503)
  %t510 = getelementptr i8, ptr %t509, i64 %t503
  call void @olang_textcopy(ptr %t510, ptr %t505, i64 %t506)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t508, 1
  store { i64, ptr } %t512, ptr %l223, !tbaa !27
  %t513 = load ptr, ptr %lp10
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t514, 0
  %t516 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 0
  store i64 %t517, ptr %l225, !tbaa !24
  %t519 = load i64, ptr %l225, !tbaa !24
  %t520 = icmp eq i64 %t515, %t519
  br i1 %t520, label %bb128, label %bb129
bb128:
  %t522 = load ptr, ptr %lp10
  %t523 = getelementptr { i64, ptr }, ptr %t522, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !27
  %t525 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = load i64, ptr %l225, !tbaa !24
  %t528 = mul i64 %t527, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t524, ptr %t526, i64 %t528, i1 false)
  br label %bb130
bb129:
  %t529 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t530 = load ptr, ptr %lp10
  store { i64, ptr } %t529, ptr %t530, !tbaa !27
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s22)
  br label %bb131
bb131:
  %t531 = load i64, ptr %l7, !tbaa !24
  %t532 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t535 = icmp eq i64 %t531, %t532
  br i1 %t535, label %bb132, label %bb133
bb132:
  %t537 = load i1, ptr %l4, !tbaa !21
  store i1 %t537, ptr %l230, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb134
bb134:
  %t539 = load i1, ptr %l230, !tbaa !21
  br i1 %t539, label %bb135, label %bb136
bb135:
  %t540 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t540, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l233, !tbaa !27
  %t542 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t542, ptr %l234, !tbaa !27
  %t543 = load ptr, ptr %lp10
  %t544 = load { i64, ptr }, ptr %t543, !tbaa !27
  %t545 = extractvalue { i64, ptr } %t544, 0
  %t546 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 0
  store i64 %t547, ptr %l236, !tbaa !24
  %t549 = load i64, ptr %l236, !tbaa !24
  %t550 = icmp eq i64 %t545, %t549
  br i1 %t550, label %bb137, label %bb138
bb136:
  br label %bb140
bb137:
  %t552 = load ptr, ptr %lp10
  %t553 = getelementptr { i64, ptr }, ptr %t552, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !27
  %t555 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = load i64, ptr %l236, !tbaa !24
  %t558 = mul i64 %t557, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t554, ptr %t556, i64 %t558, i1 false)
  br label %bb139
bb138:
  %t559 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t560 = extractvalue { i64, ptr } %t559, 0
  store i64 %t560, ptr %l238, !tbaa !24
  %t561 = load i64, ptr %l238, !tbaa !24
  %t562 = mul i64 %t561, 1
  %t563 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t562)
  %t564 = insertvalue { i64, ptr } undef, i64 %t561, 0
  %t565 = insertvalue { i64, ptr } %t564, ptr %t563, 1
  store { i64, ptr } %t565, ptr %l239, !tbaa !27
  %t566 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t569 = load ptr, ptr %t568, !tbaa !27
  %t570 = load i64, ptr %l238, !tbaa !24
  %t571 = mul i64 %t570, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t567, ptr %t569, i64 %t571, i1 false)
  %t572 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t573 = load ptr, ptr %lp10
  store { i64, ptr } %t572, ptr %t573, !tbaa !27
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t574 = load ptr, ptr %l5, !tbaa !29
  %t576 = getelementptr %"compiler/free:Free", ptr %t574, i32 0, i32 83
  store ptr %t576, ptr %l241, !tbaa !29
  %t577 = load i64, ptr %l1, !tbaa !24
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t580 = getelementptr %"compiler/free:walker", ptr %t578, i32 0, i32 1
  %t581 = load i64, ptr %t580, !tbaa !24
  %t582 = load i64, ptr %l6, !tbaa !24
  %t583 = load %"compiler/source:Span", ptr %l3
  %t584 = load i64, ptr %l7, !tbaa !24
  %t585 = load i64, ptr %l8, !tbaa !24
  %t586 = load i64, ptr %l9, !tbaa !24
  %t587 = load ptr, ptr %l2, !tbaa !29
  %t597 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t577, i64 %t581, i64 %t582, %"compiler/source:Span" %t583, i64 %t584, i64 %t585, i64 %t586, ptr %t587, ptr null)
  store %"compiler/free:store" %t597, ptr %l252
  br label %bb141
bb141:
  %t598 = load ptr, ptr %l241, !tbaa !29
  %t599 = load %"compiler/free:store", ptr %l252
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t598, %"compiler/free:store" %t599)
  br label %bb142
bb142:
  %t600 = load i64, ptr %l7, !tbaa !24
  %t601 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t604 = icmp eq i64 %t600, %t601
  br i1 %t604, label %bb143, label %bb144
bb143:
  %t606 = load i64, ptr %l6, !tbaa !24
  store i64 %t606, ptr %l24, !tbaa !24
  %t608 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t608, ptr %l25
  %t610 = load ptr, ptr %l5, !tbaa !29
  %t612 = getelementptr %"compiler/free:Free", ptr %t610, i32 0, i32 91
  %t613 = load i64, ptr %t612, !tbaa !24
  %t615 = icmp sge i64 %t613, 0
  br i1 %t615, label %bb145, label %bb146
bb144:
  br label %bb149
bb145:
  %t617 = load ptr, ptr %l5, !tbaa !29
  %t619 = getelementptr %"compiler/free:Free", ptr %t617, i32 0, i32 92
  %t620 = load i64, ptr %t619, !tbaa !24
  %t622 = load ptr, ptr %l5, !tbaa !29
  %t624 = getelementptr %"compiler/free:Free", ptr %t622, i32 0, i32 93
  %t625 = load %"compiler/source:Span", ptr %t624
  store i64 %t620, ptr %l24, !tbaa !24
  store %"compiler/source:Span" %t625, ptr %l25
  %t631 = load ptr, ptr %l5, !tbaa !29
  %t633 = getelementptr %"compiler/free:Free", ptr %t631, i32 0, i32 91
  store i64 -1, ptr %t633, !tbaa !24
  br label %bb147
bb146:
  br label %bb147
bb147:
  %t634 = load ptr, ptr %l5, !tbaa !29
  %t635 = load i64, ptr %l1, !tbaa !24
  %t636 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t637 = load i64, ptr %l24, !tbaa !24
  %t638 = load %"compiler/source:Span", ptr %l25
  %t639 = load ptr, ptr %lp10
  %t640 = load { i64, ptr }, ptr %t639, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t634, i64 %t635, i64 %t636, i64 %t637, %"compiler/source:Span" %t638, { i64, ptr } %t640)
  br label %bb148
bb148:
  br label %bb149
bb149:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2enoteView(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i64
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 28
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t12)
  store i32 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load ptr, ptr %l9, !tbaa !29
  %t17 = load i32, ptr %l11, !tbaa !23
  %t18 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eViewOf(ptr %v0, ptr %v0, ptr %t15, ptr %t16, i32 %t17)
  store i64 %t18, ptr %l12
  br label %bb3
bb3:
  %t19 = load i64, ptr @G_2ecompiler_2fmir_2eViewNone, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t22 = icmp eq i64 %t20, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t28 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %v2, ptr %t24, ptr %t25)
  store i1 %t28, ptr %l18
  br label %bb6
bb6:
  %t29 = load i1, ptr %l18, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t32 = load i1, ptr %l15, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:walker", ptr %t33, i32 0, i32 62
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:walker", ptr %t36, i32 0, i32 12
  %t39 = load i64, ptr %t38, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t35, i64 %t39)
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/free:walker", ptr %t42, i32 0, i32 63
  store ptr %t44, ptr %l25, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l27
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t48, %"compiler/source:Span" %t49)
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/free:walker", ptr %t50, i32 0, i32 64
  store ptr %t52, ptr %l29, !tbaa !29
  %t53 = ptrtoint ptr %v0 to i64
  store i64 %t53, ptr %l30, !tbaa !24
  %t54 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = call ptr @__olang_region_make(ptr %v0)
  %t57 = ptrtoint ptr %t56 to i64
  store i64 %t57, ptr %l30, !tbaa !24
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i64, ptr %l30
  %t60 = inttoptr i64 %t59 to ptr
  %t62 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %v2, ptr %t60, ptr %t58)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l33
  br label %bb16
bb16:
  %t63 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t64 = load i64, ptr %l30
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = call ptr @__olang_scope_alloc_a(ptr %t65, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %t66
  %t67 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t67, ptr %t66)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2epromoteOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca i32
  %l25 = alloca ptr
  %l27 = alloca i32
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i1
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i64
  %l50 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca i64
  %l63 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca i64
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l93 = alloca %"compiler/typed:Plan"
  %l95 = alloca %"compiler/typed:Plan"
  %l96 = alloca { i64, ptr }
  %l101 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t198 = alloca %"compiler/typed:Plan", align 8
  %t201 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t7 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t4)
  store i1 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i1, ptr %l11, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb9
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t12)
  store ptr %t14, ptr %l16
  br label %bb6
bb6:
  %t15 = load i32, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l16, !tbaa !29
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t16, i32 %t15)
  store i32 %t18, ptr %l18
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t20 = load i32, ptr %l18, !tbaa !23
  %t21 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t21, ptr %l19
  br label %bb8
bb8:
  %t22 = load i1, ptr %l19, !tbaa !21
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %l3, !tbaa !21
  %t24 = load i1, ptr %l3, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Promote", ptr %t27, i32 0, i32 1
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l23, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t31)
  store ptr %t33, ptr %l25
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load i32, ptr %l1, !tbaa !23
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t35, i32 %t34)
  store i32 %t37, ptr %l27
  br label %bb13
bb13:
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = load i32, ptr %l23, !tbaa !23
  %t40 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eregisteredAt(ptr %v0, ptr %t38, i32 %t39, i32 %t40)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Promote", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t41, ptr %t45)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l31
  br label %bb16
bb16:
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t49, ptr %lp4
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t51 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  %t52 = load i1, ptr %l3, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:walker", ptr %t54, i32 0, i32 2
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %lp4
  store ptr %t60, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  br label %bb42
bb22:
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l37, !tbaa !24
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t63)
  store i64 %t65, ptr %l39
  br label %bb23
bb23:
  %t66 = load i64, ptr %l37, !tbaa !24
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = icmp slt i64 %t66, %t67
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb24, label %bb25
bb24:
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l44
  br label %bb27
bb27:
  %t77 = load i64, ptr %l44, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = call i64 @compiler_2ffree_2eokind(i64 %t78)
  store i64 %t80, ptr %l46
  br label %bb28
bb28:
  %t81 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t82 = load i64, ptr %l46, !tbaa !24
  %t84 = icmp eq i64 %t82, %t81
  br i1 %t84, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/free:walker", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = call i64 @compiler_2ffree_2eoval(i64 %t90)
  store i64 %t92, ptr %l52
  br label %bb31
bb30:
  br label %bb39
bb31:
  %t93 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t93, ptr %l53, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t94)
  store ptr %t96, ptr %l55
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l55, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Body", ptr %t97, i32 0, i32 3
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l57, !tbaa !24
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Promote", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t104)
  store %"compiler/source:Span" %t106, ptr %l60
  br label %bb33
bb33:
  %t107 = ptrtoint ptr %v0 to i64
  store i64 %t107, ptr %l61, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t108, label %bb34, label %bb35
bb34:
  %t110 = call ptr @__olang_region_make(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l61, !tbaa !24
  br label %bb35
bb35:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Promote", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t116)
  store %"compiler/source:Span" %t118, ptr %l66
  br label %bb36
bb36:
  %t119 = load ptr, ptr %l63, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l66
  %t121 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s5, ptr %t119, %"compiler/source:Span" %t120)
  store { i64, ptr } %t121, ptr %l67
  br label %bb37
bb37:
  %t122 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = add i64 %t123, %t126
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = load i64, ptr %l61
  %t132 = inttoptr i64 %t131 to ptr
  %t133 = call ptr @__olang_scope_alloc(ptr %t132, i64 %t130)
  call void @olang_textcopy(ptr %t133, ptr %t122, i64 %t123)
  %t134 = getelementptr i8, ptr %t133, i64 %t123
  call void @olang_textcopy(ptr %t134, ptr %t125, i64 %t126)
  %t135 = getelementptr i8, ptr %t134, i64 %t126
  call void @olang_textcopy(ptr %t135, ptr %t128, i64 %t129)
  %t136 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t133, 1
  %t139 = load i64, ptr %l61
  %t140 = inttoptr i64 %t139 to ptr
  %t141 = extractvalue { i64, ptr } %t137, 0
  %t142 = extractvalue { i64, ptr } %t137, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %t140, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  %t147 = load ptr, ptr %l50, !tbaa !29
  %t148 = load i64, ptr %l52, !tbaa !24
  %t149 = load i64, ptr %l53, !tbaa !24
  %t150 = load i64, ptr %l57, !tbaa !24
  %t151 = load %"compiler/source:Span", ptr %l60
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t147, i64 %t148, i64 %t149, i64 %t150, %"compiler/source:Span" %t151, { i64, ptr } %t146)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t153 = load i64, ptr %l6, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l6, !tbaa !24
  br label %bb22
bb41:
  br label %bb42
bb42:
  %t157 = load ptr, ptr %lp4
  store ptr %t157, ptr %l72, !tbaa !29
  %t158 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Promote", ptr %t159, i32 0, i32 1
  %t162 = load i32, ptr %t161, !tbaa !23
  %t164 = sext i32 %t162 to i64
  %t167 = call i64 @compiler_2ffree_2eorig(i64 %t158, i64 %t164)
  store i64 %t167, ptr %l77
  br label %bb43
bb43:
  %t168 = load ptr, ptr %l72, !tbaa !29
  %t169 = load i64, ptr %l77, !tbaa !24
  %t170 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t168, i64 %t169)
  store i64 %t170, ptr %l78
  br label %bb44
bb44:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/free:walker", ptr %t171, i32 0, i32 2
  %t174 = load i1, ptr %t173, !tbaa !21
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb45, label %bb46
bb45:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/free:walker", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t182 = load i32, ptr %l1, !tbaa !23
  %t185 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t181, i32 %t182)
  store i1 %t185, ptr %l86
  br label %bb47
bb46:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb48
bb47:
  %t186 = load i1, ptr %l86, !tbaa !21
  store i1 %t186, ptr %l82, !tbaa !21
  br label %bb48
bb48:
  %t187 = load i1, ptr %l82, !tbaa !21
  br i1 %t187, label %bb49, label %bb50
bb49:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/free:walker", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/free:Free", ptr %t191, i32 0, i32 3
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/free:walker", ptr %t194, i32 0, i32 1
  %t197 = load i64, ptr %t196, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t198, ptr %v0, ptr %v0, ptr %t193, i64 %t197)
  call void @llvm.memmove.p0.p0.i64(ptr %l93, ptr %t198, i64 568, i1 false)
  br label %bb51
bb50:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb54
bb51:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t201, ptr %v0, ptr %l93)
  call void @llvm.memmove.p0.p0.i64(ptr %l95, ptr %t201, i64 568, i1 false)
  br label %bb52
bb52:
  %t203 = getelementptr %"compiler/typed:Plan", ptr %l95, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l96, !tbaa !27
  %t205 = load ptr, ptr %l2, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Promote", ptr %t205, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = sext i32 %t208 to i64
  %t212 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr { i64, [2 x i64] }, ptr %t213, i64 %t210
  %t215 = load { i64, [2 x i64] }, ptr %t214
  %t217 = call i1 @compiler_2ffree_2eisVar({ i64, [2 x i64] } %t215)
  store i1 %t217, ptr %l101
  br label %bb53
bb53:
  %t218 = load i1, ptr %l101, !tbaa !21
  store i1 %t218, ptr %l87, !tbaa !21
  br label %bb54
bb54:
  %t219 = load i1, ptr %l87, !tbaa !21
  br i1 %t219, label %bb55, label %bb56
bb55:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/free:walker", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/free:walker", ptr %t224, i32 0, i32 1
  %t227 = load i64, ptr %t226, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t223, i64 %t227)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t230 = load ptr, ptr %lp4
  %t231 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t230
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca i32
  %lp13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/free:leaf"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i1
  %l36 = alloca i1
  %l47 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i32
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i64
  %l69 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca i64
  %l77 = alloca i1
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca i64
  %l90 = alloca %"compiler/free:leaf"
  %l91 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca i64
  %l100 = alloca i1
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l4
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l5, !tbaa !23
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t29, i32 0, i32 2
  %t31 = load i32, ptr %t30
  %t35 = sext i32 %t31 to i64
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:walker", ptr %t36, i32 0, i32 37
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp ne i64 %t35, %t39
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t47, i32 0, i32 0
  %t49 = load %"compiler/source:Span", ptr %t48
  store %"compiler/source:Span" %t49, ptr %l7
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t53, i32 0, i32 1
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l8, !tbaa !23
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t59, i32 0, i32 2
  %t61 = load i32, ptr %t60
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 35
  %t68 = sext i32 %t61 to i64
  %t71 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %t65, i64 %t68)
  store i1 %t71, ptr %l47
  br label %bb8
bb7:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb9
bb8:
  %t72 = load i1, ptr %l47, !tbaa !21
  store i1 %t72, ptr %l36, !tbaa !21
  br label %bb9
bb9:
  %t73 = load i1, ptr %l36, !tbaa !21
  br i1 %t73, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t76, i32 0, i32 0
  %t78 = load %"compiler/source:Span", ptr %t77
  store %"compiler/source:Span" %t78, ptr %l10
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t82, i32 0, i32 1
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l11, !tbaa !23
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t88, i32 0, i32 2
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l12, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l54, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l55, !tbaa !23
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t94)
  store %"compiler/source:Span" %t96, ptr %l57
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t97 = load ptr, ptr %l54, !tbaa !29
  %t98 = load i32, ptr %l55, !tbaa !23
  %t99 = load %"compiler/source:Span", ptr %l57
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %s1, ptr %t97, i32 %t98, %"compiler/source:Span" %t99, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t100, ptr %t101)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l60
  br label %bb15
bb15:
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t105, ptr %lp13
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  %t107 = load ptr, ptr %lp13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %t107
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t110 = load ptr, ptr %lp13
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %t108, ptr %t109, ptr %t110)
  br label %bb16
bb16:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t118 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  store i64 %t118, ptr %l66
  br label %bb17
bb17:
  %t119 = load i64, ptr %l66, !tbaa !24
  store i64 %t119, ptr %l14, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  %t122 = icmp sge i64 %t120, 0
  br i1 %t122, label %bb18, label %bb19
bb18:
  %t124 = load ptr, ptr %lp13
  store ptr %t124, ptr %l69, !tbaa !29
  %t125 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = call i64 @compiler_2ffree_2eorig(i64 %t125, i64 %t126)
  store i64 %t129, ptr %l72
  br label %bb20
bb19:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t136 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedRead(ptr %v0, ptr %v1, ptr %t130, ptr %t131, i32 %t132)
  store i1 %t136, ptr %l77
  br label %bb22
bb20:
  %t137 = load ptr, ptr %l69, !tbaa !29
  %t138 = load i64, ptr %l72, !tbaa !24
  %t139 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t137, i64 %t138)
  store i64 %t139, ptr %l73
  br label %bb21
bb21:
  br label %bb37
bb22:
  %t140 = load i1, ptr %l77, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s5, ptr %t143, i32 %t144)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %l81
  br label %bb25
bb24:
  br label %bb36
bb25:
  %t148 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  %t149 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t148, ptr %t149
  store ptr %t149, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb26
bb26:
  %t151 = load i64, ptr %l16, !tbaa !24
  store i64 %t151, ptr %l83, !tbaa !24
  %t152 = load ptr, ptr %l15, !tbaa !29
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s5, ptr %t152)
  store i64 %t154, ptr %l85
  br label %bb27
bb27:
  %t155 = load i64, ptr %l83, !tbaa !24
  %t156 = load i64, ptr %l85, !tbaa !24
  %t157 = icmp slt i64 %t155, %t156
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb28, label %bb29
bb28:
  br label %bb35
bb29:
  br label %bb30
bb30:
  %t161 = load ptr, ptr %l15, !tbaa !29
  %t162 = load i64, ptr %l16, !tbaa !24
  %t165 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s5, ptr %s5, ptr %t161, i64 %t162)
  store %"compiler/free:leaf" %t165, ptr %l90
  br label %bb31
bb31:
  %t166 = load %"compiler/free:leaf", ptr %l90
  store %"compiler/free:leaf" %t166, ptr %l17
  %t167 = load ptr, ptr %lp13
  store ptr %t167, ptr %l91, !tbaa !29
  %t168 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t169 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 1
  %t170 = load i64, ptr %t169, !tbaa !24
  %t173 = call i64 @compiler_2ffree_2eorig(i64 %t168, i64 %t170)
  store i64 %t173, ptr %l94
  br label %bb32
bb32:
  %t174 = load ptr, ptr %l91, !tbaa !29
  %t175 = load i64, ptr %l94, !tbaa !24
  %t176 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t174, i64 %t175)
  store i64 %t176, ptr %l95
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t177 = load i64, ptr %l16, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l16, !tbaa !24
  br label %bb26
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l2, !tbaa !23
  %t185 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t181, i32 %t182)
  store i1 %t185, ptr %l100
  br label %bb38
bb38:
  %t186 = load i1, ptr %l100, !tbaa !21
  br i1 %t186, label %bb39, label %bb40
bb39:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %lp13
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v2, ptr %t187, ptr %t188)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  %t191 = load ptr, ptr %lp13
  %t192 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t191
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t192, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eregisteredAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i64
  %l27 = alloca %"compiler/typed:Plan"
  %l29 = alloca %"compiler/typed:Plan"
  %l37 = alloca %"compiler/typed:Plan"
  %l39 = alloca %"compiler/typed:Plan"
  %l40 = alloca { i64, ptr }
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i32
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca i1
  %s0 = alloca %olang.scope
  %t6 = alloca { i64, [2 x i64] }, align 8
  %t38 = alloca %"compiler/typed:Plan", align 8
  %t41 = alloca %"compiler/typed:Plan", align 8
  %t59 = alloca %"compiler/typed:Plan", align 8
  %t62 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t6, i32 0, i32 0
  store i64 0, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t8, ptr %l4
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:walker", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l12, !tbaa !24
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 3
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l15
  br label %bb1
bb1:
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = icmp sge i32 %t23, 0
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb4
bb4:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l1, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store i64 %t30, ptr %l22, !tbaa !24
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t38, ptr %v0, ptr %v0, ptr %t33, i64 %t37)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t38, i64 568, i1 false)
  br label %bb7
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t41, ptr %v0, ptr %l27)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t41, i64 568, i1 false)
  br label %bb8
bb8:
  %t43 = getelementptr %"compiler/typed:Plan", ptr %l29, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = load i64, ptr %l22, !tbaa !24
  %t49 = icmp slt i64 %t47, %t46
  store i1 %t49, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t51 = load i1, ptr %l20, !tbaa !21
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/free:Free", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:walker", ptr %t55, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t59, ptr %v0, ptr %v0, ptr %t54, i64 %t58)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t59, i64 568, i1 false)
  br label %bb12
bb11:
  br label %bb14
bb12:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t62, ptr %v0, ptr %l37)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t62, i64 568, i1 false)
  br label %bb13
bb13:
  %t64 = getelementptr %"compiler/typed:Plan", ptr %l39, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l40, !tbaa !27
  %t66 = load i32, ptr %l1, !tbaa !23
  %t68 = sext i32 %t66 to i64
  %t70 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t71, i64 %t68
  %t73 = load { i64, [2 x i64] }, ptr %t72
  store { i64, [2 x i64] } %t73, ptr %l4
  br label %bb14
bb14:
  %t75 = load { i64, [2 x i64] }, ptr %l4
  %t77 = extractvalue { i64, [2 x i64] } %t75, 0
  %t78 = icmp eq i64 %t77, 1
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %t82, i32 %t83)
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  %t86 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t87 = getelementptr { i32 }, ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87
  %t92 = sext i32 %t88 to i64
  store i64 %t92, ptr %l6, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/free:walker", ptr %t94, i32 0, i32 39
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c6ff733ce949281236b08418b935189(ptr %v0, ptr %v0, ptr %t96, i64 %t97)
  %t101 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, 1
  %t102 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, 0
  store i32 %t102, ptr %l57
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb20, label %ok.104, !prof !99
ok.104:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l56
  br label %bb19
bb19:
  %t106 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l56)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l59
  br label %bb22
bb20:
  br label %bb21
bb21:
  %t107 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l60
  br label %bb23
bb22:
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l52
  br label %bb24
bb23:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l52
  br label %bb24
bb24:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %l7
  %t111 = load i32, ptr %l2, !tbaa !23
  %t114 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i32 %t111)
  store i1 %t114, ptr %l63
  br label %bb25
bb25:
  %t115 = load i1, ptr %l63, !tbaa !21
  %t116 = xor i1 %t115, true
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t118 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i32 %t118)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 39
  %t124 = load i64, ptr %l6, !tbaa !24
  %t125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4057097bf127937e673a7f89a723e29a(ptr %v0, ptr %s0, ptr %t123, i64 %t124, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2eremoves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l19 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l28 = alloca i1
  %l32 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca i64
  %l79 = alloca i64
  %l82 = alloca i1
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l91 = alloca %"compiler/source:Span"
  %l94 = alloca i1
  %l97 = alloca i1
  %l102 = alloca i1
  %l104 = alloca ptr
  %l106 = alloca ptr
  %l108 = alloca i64
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca { i64, ptr }
  %l119 = alloca i1
  %l122 = alloca i1
  %l123 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l135 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l150 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 51
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t11, ptr %l19
  br label %bb3
bb2:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb4
bb3:
  %t12 = load i64, ptr @G_2ecompiler_2ffree_2eCalleeValue, !tbaa !24
  %t13 = load i64, ptr %l19, !tbaa !24
  %t15 = icmp eq i64 %t13, %t12
  store i1 %t15, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l15, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t18, ptr %l23, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l24, !tbaa !24
  %t21 = load i64, ptr %l24, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l25, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t32, ptr %l23, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:walker", ptr %t38, i32 0, i32 51
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l32
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t45 = load i64, ptr @G_2ecompiler_2ffree_2eCalleeGiven, !tbaa !24
  %t46 = load i64, ptr %l32, !tbaa !24
  %t48 = icmp eq i64 %t46, %t45
  store i1 %t48, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 122, ptr getelementptr inbounds (<{ i64, [122 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t51, ptr %l36, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l37, !tbaa !24
  %t54 = load i64, ptr %l37, !tbaa !24
  %t55 = mul i64 %t54, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l38, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l37, !tbaa !24
  %t64 = mul i64 %t63, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t60, ptr %t62, i64 %t64, i1 false)
  %t65 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t65, ptr %l36, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t66, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t69 = icmp slt i64 %t67, 0
  br i1 %t69, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l43, !tbaa !24
  %t75 = mul i64 %t74, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l44, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l43, !tbaa !24
  %t84 = mul i64 %t83, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t80, ptr %t82, i64 %t84, i1 false)
  %t85 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t85, ptr %l42, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l3, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:walker", ptr %t87, i32 0, i32 46
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l47
  br label %bb18
bb18:
  %t92 = load i64, ptr %l47, !tbaa !24
  store i64 %t92, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t93 = load i64, ptr %l4, !tbaa !24
  %t94 = load i64, ptr %l3, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb19, label %bb20
bb19:
  %t99 = load i64, ptr %l5, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb24
bb21:
  %t103 = load i64, ptr %l4, !tbaa !24
  %t104 = load i64, ptr %l3, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l5, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l54, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l54, !tbaa !24
  store i64 %t119, ptr %l51, !tbaa !24
  br label %bb24
bb24:
  %t120 = load i64, ptr %l51, !tbaa !24
  store i64 %t120, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb76
bb27:
  br label %bb28
bb28:
  %t129 = load i64, ptr %l3, !tbaa !24
  %t130 = load i64, ptr %l7, !tbaa !24
  %t131 = load i64, ptr %l5, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l8, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/free:walker", ptr %t139, i32 0, i32 51
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t141, i64 %t142)
  store i64 %t145, ptr %l75
  br label %bb29
bb29:
  %t146 = load i64, ptr %l75, !tbaa !24
  store i64 %t146, ptr %l9, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:walker", ptr %t147, i32 0, i32 46
  %t150 = load i64, ptr %l8, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l79
  br label %bb30
bb30:
  %t154 = load i64, ptr %l1, !tbaa !24
  %t155 = load i64, ptr %l79, !tbaa !24
  %t157 = icmp ne i64 %t155, %t154
  br i1 %t157, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb35
bb32:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 50
  %t162 = load i64, ptr %l8, !tbaa !24
  %t165 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t161, i64 %t162)
  store %"compiler/source:Span" %t165, ptr %l86
  br label %bb33
bb33:
  %t166 = getelementptr %"compiler/source:Span", ptr %l86, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  store i32 %t167, ptr %l87, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:walker", ptr %t168, i32 0, i32 50
  %t171 = load i64, ptr %l8, !tbaa !24
  %t174 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t170, i64 %t171)
  store %"compiler/source:Span" %t174, ptr %l91
  br label %bb34
bb34:
  %t175 = getelementptr %"compiler/source:Span", ptr %l91, i32 0, i32 1
  %t176 = load i32, ptr %t175, !tbaa !23
  %t177 = load i32, ptr %l87, !tbaa !23
  %t179 = icmp sge i32 %t177, %t176
  store i1 %t179, ptr %l82, !tbaa !21
  br label %bb35
bb35:
  %t181 = load i1, ptr %l82, !tbaa !21
  br i1 %t181, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb38
bb37:
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = icmp slt i64 %t182, 0
  store i1 %t184, ptr %l94, !tbaa !21
  br label %bb38
bb38:
  %t186 = load i1, ptr %l94, !tbaa !21
  br i1 %t186, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb42
bb40:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/free:walker", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/free:Free", ptr %t190, i32 0, i32 23
  %t193 = load i64, ptr %l9, !tbaa !24
  %t196 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t192, i64 %t193)
  store i1 %t196, ptr %l102
  br label %bb41
bb41:
  %t197 = load i1, ptr %l102, !tbaa !21
  store i1 %t197, ptr %l97, !tbaa !21
  br label %bb42
bb42:
  %t198 = load i1, ptr %l97, !tbaa !21
  br i1 %t198, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb75
bb44:
  br label %bb45
bb45:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/free:walker", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  store ptr %t202, ptr %l104, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t203)
  store ptr %t205, ptr %l106
  br label %bb46
bb46:
  %t206 = load ptr, ptr %l106, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Body", ptr %t206, i32 0, i32 3
  %t209 = load i64, ptr %t208, !tbaa !24
  store i64 %t209, ptr %l108, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/free:walker", ptr %t210, i32 0, i32 50
  %t213 = load i64, ptr %l8, !tbaa !24
  %t216 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t212, i64 %t213)
  store %"compiler/source:Span" %t216, ptr %l112
  br label %bb47
bb47:
  %t217 = load ptr, ptr %l104, !tbaa !29
  %t218 = load i64, ptr %l108, !tbaa !24
  %t219 = load %"compiler/source:Span", ptr %l112
  %t220 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s5, ptr %t217, i64 %t218, %"compiler/source:Span" %t219)
  store { i64, ptr } %t220, ptr %l113
  br label %bb48
bb48:
  %t221 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t221, ptr %l10, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t226 = sub i64 %t224, 1
  store i64 %t226, ptr %l11, !tbaa !24
  br label %bb49
bb49:
  %t228 = load i64, ptr %l11, !tbaa !24
  %t230 = icmp sge i64 %t228, 0
  br i1 %t230, label %bb50, label %bb51
bb50:
  %t232 = load i64, ptr %l11, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i8, ptr %t235, i64 %t232
  %t237 = load i8, ptr %t236, !tbaa !32
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t237)
  store i1 %t239, ptr %l122
  br label %bb52
bb51:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb60
bb52:
  %t240 = load i1, ptr %l122, !tbaa !21
  br i1 %t240, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb56
bb54:
  %t241 = load i64, ptr %l11, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i8, ptr %t244, i64 %t241
  %t246 = load i8, ptr %t245, !tbaa !32
  %t248 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t246)
  store i1 %t248, ptr %l126
  br label %bb55
bb55:
  %t249 = load i1, ptr %l126, !tbaa !21
  store i1 %t249, ptr %l123, !tbaa !21
  br label %bb56
bb56:
  %t250 = load i1, ptr %l123, !tbaa !21
  br i1 %t250, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb59
bb58:
  %t251 = load i64, ptr %l11, !tbaa !24
  %t253 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr i8, ptr %t254, i64 %t251
  %t256 = load i8, ptr %t255, !tbaa !32
  %t258 = icmp eq i8 %t256, 95
  store i1 %t258, ptr %l127, !tbaa !21
  br label %bb59
bb59:
  %t260 = load i1, ptr %l127, !tbaa !21
  store i1 %t260, ptr %l119, !tbaa !21
  br label %bb60
bb60:
  %t261 = load i1, ptr %l119, !tbaa !21
  %t262 = xor i1 %t261, true
  br i1 %t262, label %bb61, label %bb62
bb61:
  br label %bb65
bb62:
  br label %bb63
bb63:
  %t264 = load i64, ptr %l11, !tbaa !24
  %t266 = sub i64 %t264, 1
  store i64 %t266, ptr %l11, !tbaa !24
  br label %bb64
bb64:
  br label %bb49
bb65:
  %t268 = load i64, ptr %l11, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l135, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  store i64 %t273, ptr %l137, !tbaa !24
  %t274 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l138, !tbaa !24
  %t276 = load i64, ptr %l135, !tbaa !24
  %t277 = icmp sge i64 %t276, 0
  br i1 %t277, label %bb66, label %bb67
bb66:
  %t279 = load i64, ptr %l135, !tbaa !24
  %t280 = load i64, ptr %l137, !tbaa !24
  %t281 = icmp sle i64 %t279, %t280
  br i1 %t281, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb68:
  %t283 = load i64, ptr %l137, !tbaa !24
  %t284 = load i64, ptr %l138, !tbaa !24
  %t285 = icmp sle i64 %t283, %t284
  br i1 %t285, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb70:
  %t287 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = load i64, ptr %l135, !tbaa !24
  %t290 = load i64, ptr %l137, !tbaa !24
  %t291 = getelementptr i8, ptr %t288, i64 %t289
  %t292 = sub i64 %t290, %t289
  %t293 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t291, 1
  store { i64, ptr } %t294, ptr %l12, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t300 = icmp sgt i64 %t298, 0
  br i1 %t300, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb72:
  %t302 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t303 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t306 = extractvalue { i64, ptr } %t302, 1
  %t307 = extractvalue { i64, ptr } %t302, 0
  %t308 = add i64 %t304, %t307
  %t309 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t308)
  call void @olang_textcopy(ptr %t309, ptr %t303, i64 %t304)
  %t310 = getelementptr i8, ptr %t309, i64 %t304
  call void @olang_textcopy(ptr %t310, ptr %t306, i64 %t307)
  %t311 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t309, 1
  call void @__olang_scope_close(ptr %s5)
  store { i64, ptr } %t312, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s5)
  br label %bb75
bb75:
  %t314 = load i64, ptr %l7, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l7, !tbaa !24
  br label %bb25
bb76:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l150, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t318, ptr %l151, !tbaa !27
  %t319 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 0
  store i64 %t320, ptr %l152, !tbaa !24
  %t321 = load i64, ptr %l152, !tbaa !24
  %t322 = mul i64 %t321, 1
  %t323 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t322)
  %t324 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  store { i64, ptr } %t325, ptr %l153, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = load i64, ptr %l152, !tbaa !24
  %t331 = mul i64 %t330, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t327, ptr %t329, i64 %t331, i1 false)
  %t332 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t332, ptr %l151, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t333, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l25 = alloca ptr
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l16
  br label %bb6
bb6:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l18
  br label %bb7
bb7:
  %t27 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t28 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp eq i64 %t28, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 62
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t34, i64 %t38)
  store ptr %t41, ptr %l25
  br label %bb11
bb11:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t45 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t43, i64 %t42)
  store i64 %t45, ptr %l27
  br label %bb12
bb12:
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 77
  store i1 true, ptr %t51, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb1
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereturnedOwnLocals(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = call i64 @compiler_2ffree_2eokind(i64 %t19)
  store i64 %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t25 = icmp eq i64 %t23, %t22
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:walker", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = call i64 @compiler_2ffree_2eoval(i64 %t31)
  store i64 %t33, ptr %l23
  br label %bb10
bb9:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %t34, i64 %t35)
  store i1 %t36, ptr %l24
  br label %bb11
bb11:
  %t37 = load i1, ptr %l24, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = call i64 @compiler_2ffree_2eoval(i64 %t43)
  store i64 %t45, ptr %l28
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t46 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t46, ptr %l29, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t47)
  store ptr %t49, ptr %l31
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 3
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %l28, !tbaa !24
  %t57 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t55, i64 %t56, i64 %t57, i64 %t53, %"compiler/source:Span" %a2, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l4, !tbaa !24
  br label %bb1
bb20:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb26
bb6:
  %t26 = load ptr, ptr %l4, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l22
  br label %bb12
bb12:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l26
  br label %bb15
bb14:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb16
bb15:
  %t46 = load i1, ptr %l26, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_311feee871305b59_d38294057dde4ced)
  unreachable
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb28
bb28:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb29, label %bb30
bb29:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %v2, ptr %t69)
  store ptr %t71, ptr %l38
  br label %bb32
bb32:
  %t72 = load ptr, ptr %l38, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store ptr null, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_421add8d063ee188_aab923ea260c413c)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 false, i1 %a6)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i1
  %l50 = alloca i64
  %l54 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l73 = alloca i64
  %l75 = alloca i64
  %l80 = alloca i64
  %l82 = alloca i64
  %l85 = alloca i1
  %l88 = alloca i1
  %l90 = alloca i64
  %l94 = alloca i1
  %l96 = alloca i64
  %l99 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca i64
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca %"compiler/source:Span"
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l119 = alloca i1
  %l120 = alloca ptr
  %l123 = alloca i64
  %l124 = alloca i1
  %l125 = alloca i1
  %l130 = alloca i1
  %l133 = alloca i64
  %l140 = alloca ptr
  %l141 = alloca i64
  %l142 = alloca i64
  %l144 = alloca ptr
  %l146 = alloca i64
  %l147 = alloca %"compiler/source:Span"
  %l149 = alloca i1
  %l151 = alloca { i64, ptr }
  %l157 = alloca i64
  %l167 = alloca ptr
  %l172 = alloca i64
  %l176 = alloca i1
  %l181 = alloca ptr
  %l183 = alloca i64
  %l201 = alloca i64
  %l203 = alloca i64
  %l208 = alloca i64
  %l210 = alloca i64
  %l213 = alloca i1
  %l215 = alloca i64
  %l219 = alloca i1
  %l224 = alloca ptr
  %l226 = alloca i64
  %l227 = alloca i64
  %l231 = alloca i64
  %l234 = alloca i1
  %l236 = alloca i64
  %l240 = alloca i1
  %l245 = alloca ptr
  %l247 = alloca i64
  %l248 = alloca i64
  %l253 = alloca ptr
  %l257 = alloca { i64, ptr }
  %l259 = alloca i64
  %l263 = alloca ptr
  %l265 = alloca ptr
  %l270 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 46
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l23, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l23, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 30
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l26, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l26, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i64 %t29, ptr %l33
  br label %bb9
bb8:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  %t30 = load i64, ptr %l33, !tbaa !24
  %t31 = icmp slt i64 %t30, 0
  store i1 %t31, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l30, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l3, !tbaa !29
  store ptr %t34, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb12:
  br label %bb37
bb13:
  %t36 = load i64, ptr %l10, !tbaa !24
  store i64 %t36, ptr %l36, !tbaa !24
  %t37 = load ptr, ptr %l9, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t37)
  store i64 %t39, ptr %l38
  br label %bb14
bb14:
  %t40 = load i64, ptr %l36, !tbaa !24
  %t41 = load i64, ptr %l38, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb15, label %bb16
bb15:
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t46 = load ptr, ptr %l9, !tbaa !29
  %t47 = load i64, ptr %l10, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l43
  br label %bb18
bb18:
  %t51 = load i64, ptr %l43, !tbaa !24
  store i64 %t51, ptr %l11, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t54 = call i64 @compiler_2ffree_2eokind(i64 %t52)
  store i64 %t54, ptr %l45
  br label %bb19
bb19:
  %t55 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t56 = load i64, ptr %l45, !tbaa !24
  %t58 = icmp eq i64 %t56, %t55
  br i1 %t58, label %bb20, label %bb21
bb20:
  %t60 = load i64, ptr %l11, !tbaa !24
  %t62 = call i64 @compiler_2ffree_2eoval(i64 %t60)
  store i64 %t62, ptr %l50
  br label %bb22
bb21:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb23
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 32
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load i64, ptr %l50, !tbaa !24
  %t69 = icmp ne i64 %t67, %t66
  store i1 %t69, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t71 = load i1, ptr %l48, !tbaa !21
  br i1 %t71, label %bb24, label %bb25
bb24:
  %t72 = load ptr, ptr %l8, !tbaa !29
  store ptr %t72, ptr %l55, !tbaa !29
  %t73 = load i64, ptr %l11, !tbaa !24
  %t75 = call i64 @compiler_2ffree_2eoval(i64 %t73)
  store i64 %t75, ptr %l57
  br label %bb26
bb25:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb28
bb26:
  %t76 = load ptr, ptr %l55, !tbaa !29
  %t77 = load i64, ptr %l57, !tbaa !24
  %t78 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufPlace(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t78, ptr %l58
  br label %bb27
bb27:
  %t79 = load i1, ptr %l58, !tbaa !21
  store i1 %t79, ptr %l54, !tbaa !21
  br label %bb28
bb28:
  %t80 = load i1, ptr %l54, !tbaa !21
  br i1 %t80, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load ptr, ptr %l8, !tbaa !29
  store ptr %t81, ptr %l59, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l4
  %t86 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s4, ptr %t82, %"compiler/source:Span" %t83)
  store { i64, ptr } %t86, ptr %l62
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t87 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t89 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = getelementptr i8, ptr %t97, i64 %t91
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l64, !tbaa !27
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t108)
  store ptr %t110, ptr %l66
  br label %bb32
bb32:
  %t111 = load ptr, ptr %l66, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 3
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load %"compiler/source:Span", ptr %l4
  %t116 = load ptr, ptr %l59, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l64, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufNot(ptr %v0, ptr %s4, ptr %t116, { i64, ptr } %t117, i64 %t114, %"compiler/source:Span" %t115)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l10, !tbaa !24
  br label %bb13
bb36:
  br label %bb37
bb37:
  %t124 = load ptr, ptr %l3, !tbaa !29
  store ptr %t124, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb38
bb38:
  %t126 = load i64, ptr %l13, !tbaa !24
  store i64 %t126, ptr %l73, !tbaa !24
  %t127 = load ptr, ptr %l12, !tbaa !29
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t127)
  store i64 %t129, ptr %l75
  br label %bb39
bb39:
  %t130 = load i64, ptr %l73, !tbaa !24
  %t131 = load i64, ptr %l75, !tbaa !24
  %t132 = icmp slt i64 %t130, %t131
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb40, label %bb41
bb40:
  br label %bb67
bb41:
  br label %bb42
bb42:
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t137 = load i64, ptr %l13, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l80
  br label %bb43
bb43:
  %t141 = load i64, ptr %l80, !tbaa !24
  store i64 %t141, ptr %l14, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  %t144 = call i64 @compiler_2ffree_2eokind(i64 %t142)
  store i64 %t144, ptr %l82
  br label %bb44
bb44:
  %t145 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t146 = load i64, ptr %l82, !tbaa !24
  %t148 = icmp eq i64 %t146, %t145
  br i1 %t148, label %bb45, label %bb46
bb45:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/free:walker", ptr %t150, i32 0, i32 2
  %t153 = load i1, ptr %t152, !tbaa !21
  store i1 %t153, ptr %l85, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t155 = load i1, ptr %l85, !tbaa !21
  br i1 %t155, label %bb48, label %bb49
bb48:
  %t156 = load i64, ptr %l14, !tbaa !24
  %t158 = call i64 @compiler_2ffree_2eoval(i64 %t156)
  store i64 %t158, ptr %l90
  br label %bb50
bb49:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb51
bb50:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 32
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr %l90, !tbaa !24
  %t165 = icmp ne i64 %t163, %t162
  store i1 %t165, ptr %l88, !tbaa !21
  br label %bb51
bb51:
  %t167 = load i1, ptr %l88, !tbaa !21
  br i1 %t167, label %bb52, label %bb53
bb52:
  %t168 = load i64, ptr %l14, !tbaa !24
  %t170 = call i64 @compiler_2ffree_2eoval(i64 %t168)
  store i64 %t170, ptr %l96
  br label %bb54
bb53:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb55
bb54:
  %t171 = load i64, ptr %l1, !tbaa !24
  %t172 = load i64, ptr %l96, !tbaa !24
  %t174 = icmp ne i64 %t172, %t171
  store i1 %t174, ptr %l94, !tbaa !21
  br label %bb55
bb55:
  %t176 = load i1, ptr %l94, !tbaa !21
  br i1 %t176, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load ptr, ptr %l8, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load i64, ptr %l14, !tbaa !24
  %t180 = call i64 @compiler_2ffree_2eoval(i64 %t178)
  store i64 %t180, ptr %l101
  br label %bb58
bb57:
  br label %bb65
bb58:
  %t181 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t181, ptr %l102, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t182)
  store ptr %t184, ptr %l104
  br label %bb59
bb59:
  %t185 = load ptr, ptr %l104, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Body", ptr %t185, i32 0, i32 3
  %t188 = load i64, ptr %t187, !tbaa !24
  store i64 %t188, ptr %l106, !tbaa !24
  %t189 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t189, ptr %l107
  %t190 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t192 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s9, { i64, ptr } %t190, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t192, ptr %l109
  br label %bb60
bb60:
  %t193 = load i1, ptr %l109, !tbaa !21
  %t194 = xor i1 %t193, true
  br i1 %t194, label %bb61, label %bb62
bb61:
  %t196 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t197 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t200 = extractvalue { i64, ptr } %t196, 1
  %t201 = extractvalue { i64, ptr } %t196, 0
  %t202 = add i64 %t198, %t201
  %t203 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t205 = add i64 %t202, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t197, i64 %t198)
  %t207 = getelementptr i8, ptr %t206, i64 %t198
  call void @olang_textcopy(ptr %t207, ptr %t200, i64 %t201)
  %t208 = getelementptr i8, ptr %t207, i64 %t201
  call void @olang_textcopy(ptr %t208, ptr %t203, i64 %t204)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t206, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = extractvalue { i64, ptr } %t210, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  store { i64, ptr } %t217, ptr %l111, !tbaa !27
  br label %bb63
bb62:
  store { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l111, !tbaa !27
  br label %bb63
bb63:
  %t219 = load ptr, ptr %l99, !tbaa !29
  %t220 = load i64, ptr %l101, !tbaa !24
  %t221 = load i64, ptr %l102, !tbaa !24
  %t222 = load i64, ptr %l106, !tbaa !24
  %t223 = load %"compiler/source:Span", ptr %l107
  %t224 = load { i64, ptr }, ptr %l111, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t219, i64 %t220, i64 %t221, i64 %t222, %"compiler/source:Span" %t223, { i64, ptr } %t224)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t225 = load i64, ptr %l13, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l13, !tbaa !24
  br label %bb38
bb67:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/free:walker", ptr %t229, i32 0, i32 2
  %t232 = load i1, ptr %t231, !tbaa !21
  br i1 %t232, label %bb68, label %bb69
bb68:
  %t234 = load ptr, ptr %l3, !tbaa !29
  store ptr %t234, ptr %l120, !tbaa !29
  %t235 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t236 = load i64, ptr %l1, !tbaa !24
  %t239 = call i64 @compiler_2ffree_2eorig(i64 %t235, i64 %t236)
  store i64 %t239, ptr %l123
  br label %bb70
bb69:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb72
bb70:
  %t240 = load ptr, ptr %l120, !tbaa !29
  %t241 = load i64, ptr %l123, !tbaa !24
  %t242 = call i1 @compiler_2ffree_2ehas(ptr %v2, ptr %t240, i64 %t241)
  store i1 %t242, ptr %l124
  br label %bb71
bb71:
  %t243 = load i1, ptr %l124, !tbaa !21
  store i1 %t243, ptr %l119, !tbaa !21
  br label %bb72
bb72:
  %t244 = load i1, ptr %l119, !tbaa !21
  br i1 %t244, label %bb73, label %bb74
bb73:
  %t245 = load i64, ptr %l1, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/free:walker", ptr %t246, i32 0, i32 32
  %t249 = load i64, ptr %t248, !tbaa !24
  %t252 = icmp ne i64 %t245, %t249
  store i1 %t252, ptr %l125, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb75
bb75:
  %t254 = load i1, ptr %l125, !tbaa !21
  br i1 %t254, label %bb76, label %bb77
bb76:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t259 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t255, ptr %t256)
  store i64 %t259, ptr %l133
  br label %bb78
bb77:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb79
bb78:
  %t260 = load i64, ptr %l133, !tbaa !24
  %t261 = icmp slt i64 %t260, 0
  store i1 %t261, ptr %l130, !tbaa !21
  br label %bb79
bb79:
  %t263 = load i1, ptr %l130, !tbaa !21
  br i1 %t263, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i64, ptr %l1, !tbaa !24
  %t266 = load ptr, ptr %l2, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l4
  %t268 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t264, i64 %t265, ptr %t266, %"compiler/source:Span" %t267, i1 %t268)
  br label %bb82
bb81:
  br label %bb89
bb82:
  %t274 = load ptr, ptr %l8, !tbaa !29
  store ptr %t274, ptr %l140, !tbaa !29
  %t275 = load i64, ptr %l1, !tbaa !24
  store i64 %t275, ptr %l141, !tbaa !24
  %t276 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t276, ptr %l142, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t277)
  store ptr %t279, ptr %l144
  br label %bb83
bb83:
  %t280 = load ptr, ptr %l144, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Body", ptr %t280, i32 0, i32 3
  %t283 = load i64, ptr %t282, !tbaa !24
  store i64 %t283, ptr %l146, !tbaa !24
  %t284 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t284, ptr %l147
  %t285 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t287 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s12, { i64, ptr } %t285, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t287, ptr %l149
  br label %bb84
bb84:
  %t288 = load i1, ptr %l149, !tbaa !21
  %t289 = xor i1 %t288, true
  br i1 %t289, label %bb85, label %bb86
bb85:
  %t291 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t292 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t295 = extractvalue { i64, ptr } %t291, 1
  %t296 = extractvalue { i64, ptr } %t291, 0
  %t297 = add i64 %t293, %t296
  %t298 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t300 = add i64 %t297, %t299
  %t301 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t300)
  call void @olang_textcopy(ptr %t301, ptr %t292, i64 %t293)
  %t302 = getelementptr i8, ptr %t301, i64 %t293
  call void @olang_textcopy(ptr %t302, ptr %t295, i64 %t296)
  %t303 = getelementptr i8, ptr %t302, i64 %t296
  call void @olang_textcopy(ptr %t303, ptr %t298, i64 %t299)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t301, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = extractvalue { i64, ptr } %t305, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  store { i64, ptr } %t312, ptr %l151, !tbaa !27
  br label %bb87
bb86:
  store { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l151, !tbaa !27
  br label %bb87
bb87:
  %t314 = load ptr, ptr %l140, !tbaa !29
  %t315 = load i64, ptr %l141, !tbaa !24
  %t316 = load i64, ptr %l142, !tbaa !24
  %t317 = load i64, ptr %l146, !tbaa !24
  %t318 = load %"compiler/source:Span", ptr %l147
  %t319 = load { i64, ptr }, ptr %l151, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t314, i64 %t315, i64 %t316, i64 %t317, %"compiler/source:Span" %t318, { i64, ptr } %t319)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb89:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load ptr, ptr %l2, !tbaa !29
  %t324 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t320, ptr %t321)
  store i64 %t324, ptr %l157
  br label %bb90
bb90:
  %t325 = load i64, ptr %l157, !tbaa !24
  store i64 %t325, ptr %l15, !tbaa !24
  %t326 = load i64, ptr %l15, !tbaa !24
  %t328 = icmp sge i64 %t326, 0
  br i1 %t328, label %bb91, label %bb92
bb91:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/free:walker", ptr %t330, i32 0, i32 2
  %t333 = load i1, ptr %t332, !tbaa !21
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb93, label %bb94
bb92:
  br label %bb112
bb93:
  %t337 = load ptr, ptr %l8, !tbaa !29
  %t339 = getelementptr %"compiler/free:Free", ptr %t337, i32 0, i32 63
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/free:walker", ptr %t340, i32 0, i32 1
  %t343 = load i64, ptr %t342, !tbaa !24
  %t346 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t339, i64 %t343)
  store ptr %t346, ptr %l167
  br label %bb95
bb94:
  br label %bb108
bb95:
  %t347 = load i64, ptr %l15, !tbaa !24
  %t349 = shl i64 %t347, 32
  %t350 = load i64, ptr %l1, !tbaa !24
  %t353 = or i64 %t349, %t350
  %t354 = load ptr, ptr %l167, !tbaa !29
  %t356 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t354, i64 %t353)
  store i64 %t356, ptr %l172
  br label %bb96
bb96:
  %t357 = load i64, ptr %l172, !tbaa !24
  %t358 = icmp sgt i64 %t357, 0
  br i1 %t358, label %bb97, label %bb98
bb97:
  %t360 = load ptr, ptr %l8, !tbaa !29
  %t362 = getelementptr %"compiler/free:Free", ptr %t360, i32 0, i32 77
  store i1 true, ptr %t362, !tbaa !21
  br label %bb99
bb98:
  br label %bb99
bb99:
  %t363 = load i1, ptr %l6, !tbaa !21
  br i1 %t363, label %bb100, label %bb101
bb100:
  %t365 = load ptr, ptr %l8, !tbaa !29
  %t367 = getelementptr %"compiler/free:Free", ptr %t365, i32 0, i32 66
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/free:walker", ptr %t368, i32 0, i32 1
  %t371 = load i64, ptr %t370, !tbaa !24
  %t374 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t367, i64 %t371)
  store ptr %t374, ptr %l181
  br label %bb102
bb101:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb104
bb102:
  %t375 = load i64, ptr %l15, !tbaa !24
  %t376 = load ptr, ptr %l181, !tbaa !29
  %t378 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t376, i64 %t375)
  store i64 %t378, ptr %l183
  br label %bb103
bb103:
  %t379 = load i64, ptr %l183, !tbaa !24
  %t380 = icmp sgt i64 %t379, 0
  store i1 %t380, ptr %l176, !tbaa !21
  br label %bb104
bb104:
  %t382 = load i1, ptr %l176, !tbaa !21
  br i1 %t382, label %bb105, label %bb106
bb105:
  %t383 = load ptr, ptr %l8, !tbaa !29
  %t385 = getelementptr %"compiler/free:Free", ptr %t383, i32 0, i32 77
  store i1 true, ptr %t385, !tbaa !21
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/free:walker", ptr %t386, i32 0, i32 53
  %t389 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t388, i64 %t389)
  br label %bb109
bb109:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/free:walker", ptr %t392, i32 0, i32 54
  %t395 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t394, i64 %t395)
  br label %bb110
bb110:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/free:walker", ptr %t398, i32 0, i32 55
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/free:walker", ptr %t401, i32 0, i32 12
  %t404 = load i64, ptr %t403, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t400, i64 %t404)
  br label %bb111
bb111:
  br label %ret
bb112:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/free:walker", ptr %t407, i32 0, i32 2
  %t410 = load i1, ptr %t409, !tbaa !21
  %t412 = xor i1 %t410, true
  br i1 %t412, label %bb113, label %bb114
bb113:
  br i1 %a7, label %bb115, label %bb116
bb114:
  br label %bb162
bb115:
  br label %ret
bb116:
  br label %bb117
bb117:
  %t416 = load ptr, ptr %l3, !tbaa !29
  store ptr %t416, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb118
bb118:
  %t418 = load i64, ptr %l17, !tbaa !24
  store i64 %t418, ptr %l201, !tbaa !24
  %t419 = load ptr, ptr %l16, !tbaa !29
  %t421 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t419)
  store i64 %t421, ptr %l203
  br label %bb119
bb119:
  %t422 = load i64, ptr %l201, !tbaa !24
  %t423 = load i64, ptr %l203, !tbaa !24
  %t424 = icmp slt i64 %t422, %t423
  %t426 = xor i1 %t424, true
  br i1 %t426, label %bb120, label %bb121
bb120:
  br label %bb161
bb121:
  br label %bb122
bb122:
  %t428 = load ptr, ptr %l16, !tbaa !29
  %t429 = load i64, ptr %l17, !tbaa !24
  %t432 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t428, i64 %t429)
  store i64 %t432, ptr %l208
  br label %bb123
bb123:
  %t433 = load i64, ptr %l208, !tbaa !24
  store i64 %t433, ptr %l18, !tbaa !24
  %t434 = load i64, ptr %l18, !tbaa !24
  %t436 = call i64 @compiler_2ffree_2eokind(i64 %t434)
  store i64 %t436, ptr %l210
  br label %bb124
bb124:
  %t437 = load i64, ptr @G_2ecompiler_2ffree_2eOParC, !tbaa !24
  %t438 = load i64, ptr %l210, !tbaa !24
  %t440 = icmp eq i64 %t438, %t437
  br i1 %t440, label %bb125, label %bb126
bb125:
  %t442 = load i64, ptr %l18, !tbaa !24
  %t444 = call i64 @compiler_2ffree_2eoval(i64 %t442)
  store i64 %t444, ptr %l215
  br label %bb127
bb126:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb128
bb127:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/free:walker", ptr %t445, i32 0, i32 31
  %t448 = load i64, ptr %t447, !tbaa !24
  %t449 = load i64, ptr %l215, !tbaa !24
  %t451 = icmp ne i64 %t449, %t448
  store i1 %t451, ptr %l213, !tbaa !21
  br label %bb128
bb128:
  %t453 = load i1, ptr %l213, !tbaa !21
  br i1 %t453, label %bb129, label %bb130
bb129:
  %t454 = load ptr, ptr %l8, !tbaa !29
  %t456 = getelementptr %"compiler/free:Free", ptr %t454, i32 0, i32 65
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/free:walker", ptr %t457, i32 0, i32 1
  %t460 = load i64, ptr %t459, !tbaa !24
  %t463 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t456, i64 %t460)
  store ptr %t463, ptr %l224
  br label %bb131
bb130:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb134
bb131:
  %t464 = load i64, ptr %l18, !tbaa !24
  %t466 = call i64 @compiler_2ffree_2eoval(i64 %t464)
  store i64 %t466, ptr %l226
  br label %bb132
bb132:
  %t467 = load ptr, ptr %l224, !tbaa !29
  %t468 = load i64, ptr %l226, !tbaa !24
  %t469 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t467, i64 %t468)
  store i64 %t469, ptr %l227
  br label %bb133
bb133:
  %t470 = load i64, ptr %l227, !tbaa !24
  %t471 = icmp sgt i64 %t470, 0
  store i1 %t471, ptr %l219, !tbaa !21
  br label %bb134
bb134:
  %t473 = load i1, ptr %l219, !tbaa !21
  br i1 %t473, label %bb135, label %bb136
bb135:
  %t474 = load ptr, ptr %l8, !tbaa !29
  %t476 = getelementptr %"compiler/free:Free", ptr %t474, i32 0, i32 77
  store i1 true, ptr %t476, !tbaa !21
  br label %bb137
bb136:
  br label %bb137
bb137:
  %t477 = load i64, ptr %l18, !tbaa !24
  %t479 = call i64 @compiler_2ffree_2eokind(i64 %t477)
  store i64 %t479, ptr %l231
  br label %bb138
bb138:
  %t480 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t481 = load i64, ptr %l231, !tbaa !24
  %t483 = icmp eq i64 %t481, %t480
  br i1 %t483, label %bb139, label %bb140
bb139:
  %t485 = load i64, ptr %l18, !tbaa !24
  %t487 = call i64 @compiler_2ffree_2eoval(i64 %t485)
  store i64 %t487, ptr %l236
  br label %bb141
bb140:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb142
bb141:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr %"compiler/free:walker", ptr %t488, i32 0, i32 31
  %t491 = load i64, ptr %t490, !tbaa !24
  %t492 = load i64, ptr %l236, !tbaa !24
  %t494 = icmp ne i64 %t492, %t491
  store i1 %t494, ptr %l234, !tbaa !21
  br label %bb142
bb142:
  %t496 = load i1, ptr %l234, !tbaa !21
  br i1 %t496, label %bb143, label %bb144
bb143:
  %t497 = load ptr, ptr %l8, !tbaa !29
  %t499 = getelementptr %"compiler/free:Free", ptr %t497, i32 0, i32 64
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/free:walker", ptr %t500, i32 0, i32 1
  %t503 = load i64, ptr %t502, !tbaa !24
  %t506 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t499, i64 %t503)
  store ptr %t506, ptr %l245
  br label %bb145
bb144:
  store i1 false, ptr %l240, !tbaa !21
  br label %bb148
bb145:
  %t507 = load i64, ptr %l18, !tbaa !24
  %t509 = call i64 @compiler_2ffree_2eoval(i64 %t507)
  store i64 %t509, ptr %l247
  br label %bb146
bb146:
  %t510 = load ptr, ptr %l245, !tbaa !29
  %t511 = load i64, ptr %l247, !tbaa !24
  %t512 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t510, i64 %t511)
  store i64 %t512, ptr %l248
  br label %bb147
bb147:
  %t513 = load i64, ptr %l248, !tbaa !24
  %t514 = icmp sgt i64 %t513, 0
  store i1 %t514, ptr %l240, !tbaa !21
  br label %bb148
bb148:
  %t516 = load i1, ptr %l240, !tbaa !21
  br i1 %t516, label %bb149, label %bb150
bb149:
  %t517 = load ptr, ptr %l8, !tbaa !29
  %t519 = getelementptr %"compiler/free:Free", ptr %t517, i32 0, i32 77
  store i1 true, ptr %t519, !tbaa !21
  %t520 = load ptr, ptr %l8, !tbaa !29
  %t522 = getelementptr %"compiler/free:Free", ptr %t520, i32 0, i32 116
  %t523 = load i1, ptr %t522, !tbaa !21
  br i1 %t523, label %bb151, label %bb152
bb150:
  br label %bb159
bb151:
  store %olang.scope zeroinitializer, ptr %s24
  %t525 = load ptr, ptr %l8, !tbaa !29
  store ptr %t525, ptr %l253, !tbaa !29
  %t526 = load ptr, ptr %l8, !tbaa !29
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/free:walker", ptr %t527, i32 0, i32 1
  %t530 = load i64, ptr %t529, !tbaa !24
  %t533 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s24, ptr %t526, i64 %t530)
  store { i64, ptr } %t533, ptr %l257
  br label %bb153
bb152:
  br label %bb158
bb153:
  %t534 = load i64, ptr %l18, !tbaa !24
  %t536 = call i64 @compiler_2ffree_2eoval(i64 %t534)
  store i64 %t536, ptr %l259
  br label %bb154
bb154:
  %t537 = load ptr, ptr %l8, !tbaa !29
  %t539 = getelementptr %"compiler/free:Free", ptr %t537, i32 0, i32 0
  %t540 = load ptr, ptr %t539, !tbaa !29
  %t542 = getelementptr %"compiler/generic:Program", ptr %t540, i32 0, i32 0
  %t543 = load ptr, ptr %t542, !tbaa !29
  %t545 = getelementptr %"compiler/load:Loader", ptr %t543, i32 0, i32 4
  %t546 = load ptr, ptr %t545, !tbaa !29
  store ptr %t546, ptr %l263, !tbaa !29
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t547)
  store ptr %t549, ptr %l265
  br label %bb155
bb155:
  %t550 = load ptr, ptr %l265, !tbaa !29
  %t552 = getelementptr %"compiler/typed:Body", ptr %t550, i32 0, i32 3
  %t553 = load i64, ptr %t552, !tbaa !24
  %t554 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t555 = load i32, ptr %t554, !tbaa !23
  %t557 = sext i32 %t555 to i64
  %t558 = load ptr, ptr %l263, !tbaa !29
  %t561 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s24, ptr %t558, i64 %t553, i64 %t557)
  store { i64, ptr } %t561, ptr %l270
  br label %bb156
bb156:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/free:walker", ptr %t562, i32 0, i32 31
  %t565 = load i64, ptr %t564, !tbaa !24
  %t566 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t567 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t568 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 1
  %t570 = extractvalue { i64, ptr } %t568, 0
  %t571 = add i64 %t567, %t570
  %t572 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t574 = add i64 %t571, %t573
  %t575 = load i64, ptr %l259, !tbaa !24
  %t576 = call i64 @__olang_fmt_i64(ptr null, i64 %t575)
  %t577 = add i64 %t574, %t576
  %t578 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t579 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t580 = add i64 %t577, %t579
  %t581 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t582 = extractvalue { i64, ptr } %t581, 1
  %t583 = extractvalue { i64, ptr } %t581, 0
  %t584 = add i64 %t580, %t583
  %t585 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t586 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t587 = add i64 %t584, %t586
  %t589 = call i64 @__olang_fmt_i64(ptr null, i64 %t565)
  %t590 = add i64 %t587, %t589
  %t591 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t592 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t593 = add i64 %t590, %t592
  %t594 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t593)
  call void @olang_textcopy(ptr %t594, ptr %t566, i64 %t567)
  %t595 = getelementptr i8, ptr %t594, i64 %t567
  call void @olang_textcopy(ptr %t595, ptr %t569, i64 %t570)
  %t596 = getelementptr i8, ptr %t595, i64 %t570
  call void @olang_textcopy(ptr %t596, ptr %t572, i64 %t573)
  %t597 = getelementptr i8, ptr %t596, i64 %t573
  %t598 = call i64 @__olang_fmt_i64(ptr %t597, i64 %t575)
  %t599 = getelementptr i8, ptr %t597, i64 %t576
  call void @olang_textcopy(ptr %t599, ptr %t578, i64 %t579)
  %t600 = getelementptr i8, ptr %t599, i64 %t579
  call void @olang_textcopy(ptr %t600, ptr %t582, i64 %t583)
  %t601 = getelementptr i8, ptr %t600, i64 %t583
  call void @olang_textcopy(ptr %t601, ptr %t585, i64 %t586)
  %t602 = getelementptr i8, ptr %t601, i64 %t586
  %t603 = call i64 @__olang_fmt_i64(ptr %t602, i64 %t565)
  %t604 = getelementptr i8, ptr %t602, i64 %t589
  call void @olang_textcopy(ptr %t604, ptr %t591, i64 %t592)
  %t605 = insertvalue { i64, ptr } undef, i64 %t593, 0
  %t606 = insertvalue { i64, ptr } %t605, ptr %t594, 1
  %t608 = extractvalue { i64, ptr } %t606, 0
  %t609 = extractvalue { i64, ptr } %t606, 1
  %t610 = mul i64 %t608, 1
  %t611 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t610)
  call void @llvm.memcpy.p0.p0.i64(ptr %t611, ptr %t609, i64 %t610, i1 false)
  %t612 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t611, 1
  %t614 = load ptr, ptr %l253, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %s24, ptr %t614, { i64, ptr } %t613)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s24)
  br label %bb158
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t616 = load i64, ptr %l17, !tbaa !24
  %t618 = add i64 %t616, 1
  store i64 %t618, ptr %l17, !tbaa !24
  br label %bb118
bb161:
  br label %ret
bb162:
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t621 = load i64, ptr %l1, !tbaa !24
  %t622 = load ptr, ptr %l2, !tbaa !29
  %t623 = load %"compiler/source:Span", ptr %l4
  %t624 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t620, i64 %t621, ptr %t622, %"compiler/source:Span" %t623, i1 %t624)
  br label %bb163
bb163:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l40 = alloca i64
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca i64
  %l79 = alloca i1
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i1
  %l91 = alloca i64
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i1
  %l113 = alloca i64
  %l117 = alloca i64
  %l127 = alloca i1
  %l128 = alloca i1
  %l130 = alloca i64
  %l133 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l20, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l3, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l5, !tbaa !24
  store i64 %t16, ptr %l25, !tbaa !24
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l27
  br label %bb6
bb6:
  %t20 = load i64, ptr %l25, !tbaa !24
  %t21 = load i64, ptr %l27, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l32
  br label %bb10
bb10:
  %t31 = load i64, ptr %l32, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 26
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l36
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 13
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l40
  br label %bb12
bb12:
  %t46 = load i64, ptr %l36, !tbaa !24
  %t47 = load i64, ptr %l40, !tbaa !24
  %t48 = icmp sgt i64 %t46, %t47
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load i64, ptr %l6, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb5
bb17:
  store i64 0, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:walker", ptr %t56, i32 0, i32 14
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l47
  br label %bb18
bb18:
  %t61 = load i64, ptr %l47, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb24
bb21:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l54, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l54, !tbaa !24
  store i64 %t88, ptr %l51, !tbaa !24
  br label %bb24
bb24:
  %t89 = load i64, ptr %l51, !tbaa !24
  store i64 %t89, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb26, label %bb27
bb26:
  br label %bb59
bb27:
  br label %bb28
bb28:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l12, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 14
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  store i64 %t114, ptr %l75
  br label %bb29
bb29:
  %t115 = load i64, ptr %l75, !tbaa !24
  store i64 %t115, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l2, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  br i1 %t120, label %bb30, label %bb31
bb30:
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %l80, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 15
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l84
  br label %bb32
bb31:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb33
bb32:
  %t130 = load i64, ptr %l80, !tbaa !24
  %t131 = load i64, ptr %l84, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  store i1 %t132, ptr %l79, !tbaa !21
  br label %bb33
bb33:
  %t134 = load i1, ptr %l79, !tbaa !21
  %t135 = xor i1 %t134, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb37
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 20
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t139, i64 %t140)
  store i64 %t143, ptr %l91
  br label %bb36
bb36:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l91, !tbaa !24
  %t147 = icmp sgt i64 %t145, %t144
  store i1 %t147, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t149 = load i1, ptr %l87, !tbaa !21
  br i1 %t149, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l3, !tbaa !29
  store ptr %t150, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t152 = load i64, ptr %l15, !tbaa !24
  store i64 %t152, ptr %l95, !tbaa !24
  %t153 = load ptr, ptr %l14, !tbaa !29
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t153)
  store i64 %t155, ptr %l97
  br label %bb42
bb42:
  %t156 = load i64, ptr %l95, !tbaa !24
  %t157 = load i64, ptr %l97, !tbaa !24
  %t158 = icmp slt i64 %t156, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb43, label %bb44
bb43:
  br label %bb57
bb44:
  br label %bb45
bb45:
  %t162 = load ptr, ptr %l14, !tbaa !29
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l102
  br label %bb46
bb46:
  %t167 = load i64, ptr %l102, !tbaa !24
  store i64 %t167, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  store i64 %t168, ptr %l103, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 26
  %t172 = load i64, ptr %l16, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l107
  br label %bb47
bb47:
  %t176 = load i64, ptr %l103, !tbaa !24
  %t177 = load i64, ptr %l107, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  br i1 %t178, label %bb48, label %bb49
bb48:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/free:walker", ptr %t180, i32 0, i32 26
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t182, i64 %t183)
  store i64 %t186, ptr %l113
  br label %bb50
bb49:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb52
bb50:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/free:walker", ptr %t187, i32 0, i32 15
  %t190 = load i64, ptr %l12, !tbaa !24
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t189, i64 %t190)
  store i64 %t193, ptr %l117
  br label %bb51
bb51:
  %t194 = load i64, ptr %l113, !tbaa !24
  %t195 = load i64, ptr %l117, !tbaa !24
  %t196 = icmp sle i64 %t194, %t195
  store i1 %t196, ptr %l109, !tbaa !21
  br label %bb52
bb52:
  %t198 = load i1, ptr %l109, !tbaa !21
  br i1 %t198, label %bb53, label %bb54
bb53:
  %t199 = load i64, ptr %l16, !tbaa !24
  store i64 %t199, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t201 = load i64, ptr %l15, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l15, !tbaa !24
  br label %bb41
bb57:
  br label %bb58
bb58:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l11, !tbaa !24
  br label %bb25
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:walker", ptr %t209, i32 0, i32 28
  %t212 = load i64, ptr %l1, !tbaa !24
  %t215 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t211, i64 %t212)
  store i1 %t215, ptr %l127
  br label %bb60
bb60:
  %t216 = load i1, ptr %l127, !tbaa !21
  br i1 %t216, label %bb61, label %bb62
bb61:
  %t217 = load ptr, ptr %l3, !tbaa !29
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t217)
  store i64 %t219, ptr %l130
  br label %bb63
bb62:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb64
bb63:
  %t220 = load i64, ptr %l130, !tbaa !24
  %t221 = icmp sgt i64 %t220, 0
  store i1 %t221, ptr %l128, !tbaa !21
  br label %bb64
bb64:
  %t223 = load i1, ptr %l128, !tbaa !21
  br i1 %t223, label %bb65, label %bb66
bb65:
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t226 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t224, i64 0)
  store i64 %t226, ptr %l133
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t227 = load i64, ptr %l133, !tbaa !24
  store i64 %t227, ptr %rv
  br label %ret
bb68:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2evalueCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l25 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l38 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l45 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i32
  %l91 = alloca i64
  %l101 = alloca i64
  %l103 = alloca i64
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l117 = alloca ptr
  %l119 = alloca i1
  %l120 = alloca i1
  %l123 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l23, !tbaa !24
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v3, ptr %t9)
  store i64 %t11, ptr %l25
  br label %bb2
bb2:
  %t12 = load i64, ptr %l23, !tbaa !24
  %t13 = load i64, ptr %l25, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = load i64, ptr %l8, !tbaa !24
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v3, ptr %v3, ptr %t18, i64 %t19)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l30
  br label %bb6
bb6:
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l30)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l32
  br label %bb7
bb7:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l9
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t29 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v4, ptr %s2, ptr %t26, ptr %l9)
  store i64 %t29, ptr %l35
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l8, !tbaa !24
  br label %bb1
bb10:
  %t34 = load ptr, ptr %l5, !tbaa !29
  store ptr %t34, ptr %l38, !tbaa !29
  %t35 = load i64, ptr @G_2ecompiler_2ffree_2eOUnk, !tbaa !24
  %t37 = call i64 @compiler_2ffree_2eorig(i64 %t35, i64 0)
  store i64 %t37, ptr %l40
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l38, !tbaa !29
  %t39 = load i64, ptr %l40, !tbaa !24
  %t40 = call i64 @compiler_2ffree_2eaddTo(ptr %v4, ptr %t38, i64 %t39)
  store i64 %t40, ptr %l41
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Call", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp sge i32 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Call", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t65 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueRecsAt(ptr %v0, ptr %s0, ptr %t51, i64 %t55, i64 %t61)
  store { i64, ptr } %t65, ptr %l53
  br label %bb15
bb14:
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb16, label %bb17
bb15:
  %t68 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l54, !tbaa !24
  %t70 = load i64, ptr %l54, !tbaa !24
  %t71 = mul i64 %t70, 8
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l55, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l54, !tbaa !24
  %t80 = mul i64 %t79, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %t78, i64 %t80, i1 false)
  %t81 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t81, ptr %l45, !tbaa !27
  br label %bb20
bb16:
  %t82 = icmp sle i64 0, 1152921504606846975
  br i1 %t82, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_afd3b4561806d30e_4841abb84b9127fa)
  unreachable
bb18:
  %t84 = mul i64 0, 8
  %t85 = insertvalue { i64, ptr } undef, i64 0, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t86, ptr %l45, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_afd3b4561806d30e_4841abb84b9127fa)
  unreachable
bb20:
  %t88 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l59, !tbaa !24
  %t90 = load i64, ptr %l59, !tbaa !24
  %t91 = mul i64 %t90, 8
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l60, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l59, !tbaa !24
  %t100 = mul i64 %t99, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %t98, i64 %t100, i1 false)
  %t101 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t102, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t116 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t116, ptr %l68, !tbaa !27
  %t117 = load i64, ptr %l12, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i64, ptr %t120, i64 %t117
  %t122 = load i64, ptr %t121, !tbaa !34
  store i64 %t122, ptr %l14, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t126 = load i64, ptr %l14, !tbaa !24
  %t128 = ashr i64 %t126, 1
  %t129 = load i64, ptr %l14, !tbaa !24
  %t131 = and i64 %t129, 1
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2easRecord(ptr %v0, ptr %v1, ptr %v3, ptr %t124, ptr %t125, i64 %t128, i64 %t131, ptr %t132, %"compiler/source:Span" %t133)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l12, !tbaa !24
  br label %bb21
bb27:
  %t144 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t148 = icmp sgt i64 %t146, 0
  br i1 %t148, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t150)
  store ptr %t152, ptr %l85
  br label %bb31
bb31:
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t153)
  store i32 %t155, ptr %l87
  br label %bb32
bb32:
  %t156 = load ptr, ptr %l85, !tbaa !29
  %t157 = load i32, ptr %l87, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t158, ptr %l88
  br label %bb33
bb33:
  %t159 = load i32, ptr %l88, !tbaa !23
  store i32 %t159, ptr %l15, !tbaa !23
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t164 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efixedParam(ptr %v0, ptr %v2, ptr %t160, ptr %t161)
  store i64 %t164, ptr %l91
  br label %bb34
bb34:
  %t165 = load i64, ptr %l91, !tbaa !24
  store i64 %t165, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t168 = icmp sge i64 %t166, 0
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t172 = load i32, ptr %l15, !tbaa !23
  %t173 = load i64, ptr %l16, !tbaa !24
  %t174 = load ptr, ptr %l3, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ethroughParam(ptr %v0, ptr %v1, ptr %v3, ptr %t170, ptr %t171, i32 %t172, i64 %t173, ptr %t174, %"compiler/source:Span" %t175)
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb38:
  %t182 = load ptr, ptr %l3, !tbaa !29
  store ptr %t182, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t184 = load i64, ptr %l18, !tbaa !24
  store i64 %t184, ptr %l101, !tbaa !24
  %t185 = load ptr, ptr %l17, !tbaa !29
  %t187 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v3, ptr %t185)
  store i64 %t187, ptr %l103
  br label %bb40
bb40:
  %t188 = load i64, ptr %l101, !tbaa !24
  %t189 = load i64, ptr %l103, !tbaa !24
  %t190 = icmp slt i64 %t188, %t189
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb42:
  br label %bb43
bb43:
  %t194 = load ptr, ptr %l17, !tbaa !29
  %t195 = load i64, ptr %l18, !tbaa !24
  %t198 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v3, ptr %v3, ptr %t194, i64 %t195)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %l108
  br label %bb44
bb44:
  %t200 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s10, ptr %l108)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %l110
  br label %bb45
bb45:
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %l19
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s10, ptr %s10, ptr %t202, ptr %l19, %"compiler/source:Span" %t203, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  %t207 = load i64, ptr %l18, !tbaa !24
  %t209 = add i64 %t207, 1
  store i64 %t209, ptr %l18, !tbaa !24
  br label %bb39
bb48:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t211)
  store ptr %t213, ptr %l117
  br label %bb49
bb49:
  %t214 = load i32, ptr %l15, !tbaa !23
  %t215 = load ptr, ptr %l117, !tbaa !29
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %t215, i32 %t214)
  store i1 %t217, ptr %l119
  br label %bb50
bb50:
  %t218 = load i1, ptr %l119, !tbaa !21
  br i1 %t218, label %bb51, label %bb52
bb51:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t223 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emayWrite(ptr %v0, ptr %v1, ptr %t219, ptr %t220)
  store i1 %t223, ptr %l123
  br label %bb53
bb52:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb54
bb53:
  %t224 = load i1, ptr %l123, !tbaa !21
  %t225 = xor i1 %t224, true
  store i1 %t225, ptr %l120, !tbaa !21
  br label %bb54
bb54:
  %t227 = load i1, ptr %l120, !tbaa !21
  %t228 = xor i1 %t227, true
  br i1 %t228, label %bb55, label %bb56
bb55:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l4
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t233 = load i64, ptr @G_2ecompiler_2ffree_2eCalleeValue, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t230, %"compiler/source:Span" %t231, ptr %t232, i64 %t233)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i1
  %l14 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 34
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t10 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 34
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = icmp ne i64 %t13, %t17
  store i1 %t20, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t22 = load i1, ptr %l7, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t27 = icmp sge i64 %t23, %t24
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t38 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t34, i64 %a2)
  store i64 %t38, ptr %l22
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  %t40 = load i64, ptr %l23, !tbaa !24
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = shl i64 1, %t41
  %t43 = load i64, ptr %l22, !tbaa !24
  %t45 = and i64 %t43, %t42
  %t47 = icmp ne i64 %t45, 0
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"compiler/typed:Local"
  %l60 = alloca i1
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca %"compiler/typed:Local"
  %l71 = alloca i64
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i1
  %l117 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l19, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Body", ptr %t5, i32 0, i32 7
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l22
  br label %bb2
bb2:
  %t10 = load i64, ptr %l22, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l30, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l30, !tbaa !24
  store i64 %t39, ptr %l27, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l27, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l10, !tbaa !24
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l48, !tbaa !29
  %t60 = ptrtoint ptr %v2 to i64
  store i64 %t60, ptr %l49, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t61, label %bb13, label %bb14
bb13:
  %t63 = call ptr @__olang_region_make(ptr %v2)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l49, !tbaa !24
  br label %bb14
bb14:
  %t65 = load i64, ptr %l49
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t66, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l51
  br label %bb15
bb15:
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  %t69 = load i64, ptr %l49
  %t70 = inttoptr i64 %t69 to ptr
  %t71 = call ptr @__olang_scope_alloc_a(ptr %t70, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %t71
  %t72 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v2, ptr %v2, ptr %t72, ptr %t71)
  br label %bb16
bb16:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l56
  br label %bb17
bb17:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l56, i32 0, i32 4
  %t82 = load i32, ptr %t81, !range !{i32 0, i32 7}
  %t84 = trunc i64 5 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:walker", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/free:Free", ptr %t92, i32 0, i32 28
  store ptr %t94, ptr %l63, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t95)
  store ptr %t97, ptr %l65
  br label %bb20
bb19:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb23
bb20:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 7
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t100, i64 %t101)
  store %"compiler/typed:Local" %t104, ptr %l69
  br label %bb21
bb21:
  %t105 = getelementptr %"compiler/typed:Local", ptr %l69, i32 0, i32 2
  %t106 = load i32, ptr %t105, !tbaa !23
  %t107 = load ptr, ptr %l63, !tbaa !29
  %t108 = load ptr, ptr %l65, !tbaa !29
  %t110 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eViewOf(ptr %v0, ptr %v0, ptr %t107, ptr %t108, i32 %t106)
  store i64 %t110, ptr %l71
  br label %bb22
bb22:
  %t111 = load i64, ptr @G_2ecompiler_2fmir_2eViewNone, !tbaa !24
  %t112 = load i64, ptr %l71, !tbaa !24
  %t114 = icmp ne i64 %t112, %t111
  store i1 %t114, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t116 = load i1, ptr %l60, !tbaa !21
  br i1 %t116, label %bb24, label %bb25
bb24:
  %t118 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %a1, i64 %t118)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l9, !tbaa !24
  br label %bb9
bb29:
  store i64 0, ptr %l11, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 25
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t127)
  store i64 %t129, ptr %l80
  br label %bb30
bb30:
  %t130 = load i64, ptr %l80, !tbaa !24
  store i64 %t130, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = icmp sgt i64 %t131, %t132
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load i64, ptr %l13, !tbaa !24
  %t139 = icmp sgt i64 %t137, 0
  br i1 %t139, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb36
bb33:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t142 = load i64, ptr %l11, !tbaa !24
  %t145 = sub i64 %t141, %t142
  %t146 = load i64, ptr %l13, !tbaa !24
  %t149 = add i64 %t145, %t146
  %t151 = sub i64 %t149, 1
  %t152 = load i64, ptr %l13, !tbaa !24
  %t155 = sdiv i64 %t151, %t152
  store i64 %t155, ptr %l87, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb35
bb35:
  %t157 = load i64, ptr %l87, !tbaa !24
  store i64 %t157, ptr %l84, !tbaa !24
  br label %bb36
bb36:
  %t158 = load i64, ptr %l84, !tbaa !24
  store i64 %t158, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb37
bb37:
  %t159 = load i64, ptr %l15, !tbaa !24
  %t160 = load i64, ptr %l14, !tbaa !24
  %t163 = icmp slt i64 %t159, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb38, label %bb39
bb38:
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t167 = load i64, ptr %l11, !tbaa !24
  %t168 = load i64, ptr %l15, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  %t172 = mul i64 %t168, %t169
  %t175 = add i64 %t167, %t172
  store i64 %t175, ptr %l16, !tbaa !24
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 25
  %t180 = load i64, ptr %l16, !tbaa !24
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t179, i64 %t180)
  store i64 %t183, ptr %l108
  br label %bb41
bb41:
  %t184 = load i64, ptr %l108, !tbaa !24
  store i64 %t184, ptr %l17, !tbaa !24
  %t185 = load i64, ptr %l17, !tbaa !24
  %t187 = icmp sge i64 %t185, 0
  br i1 %t187, label %bb42, label %bb43
bb42:
  %t189 = load i64, ptr %l17, !tbaa !24
  %t190 = load i64, ptr %l4, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  store i1 %t193, ptr %l111, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb44
bb44:
  %t195 = load i1, ptr %l111, !tbaa !21
  br i1 %t195, label %bb45, label %bb46
bb45:
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v2, ptr %v2, ptr %t196, i64 %t197)
  store ptr %t200, ptr %l117
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t201 = load i64, ptr %l16, !tbaa !24
  %t202 = load ptr, ptr %l117, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t202, i64 %t201)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t204 = load i64, ptr %l15, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l15, !tbaa !24
  br label %bb37
bb51:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 30
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 40
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l18, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t27)
  store i64 %t29, ptr %l20
  br label %bb11
bb11:
  %t30 = load i64, ptr %l18, !tbaa !24
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb12, label %bb13
bb12:
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l25
  br label %bb15
bb15:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = call i64 @compiler_2ffree_2eokind(i64 %t42)
  store i64 %t44, ptr %l27
  br label %bb16
bb16:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t50 = icmp eq i64 %t46, %t47
  br i1 %t50, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t56 = icmp eq i64 %t52, %t53
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb20, label %bb21
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:walker", ptr %t59, i32 0, i32 44
  store ptr %t61, ptr %l36, !tbaa !29
  %t62 = load i64, ptr %l4, !tbaa !24
  %t64 = call i64 @compiler_2ffree_2eoval(i64 %t62)
  store i64 %t64, ptr %l38
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:walker", ptr %t67, i32 0, i32 45
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 12
  %t73 = load i64, ptr %t72, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t69, i64 %t73)
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l3, !tbaa !24
  br label %bb10
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l19 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca i32
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  store i64 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i64, ptr %l13, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb3:
  br label %bb12
bb4:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 67
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:walker", ptr %t26, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t25, i64 %t29)
  store ptr %t32, ptr %l24
  br label %bb6
bb5:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb8
bb6:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l24, !tbaa !29
  %t36 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t34, i64 %t33)
  store i64 %t36, ptr %l26
  br label %bb7
bb7:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp sgt i64 %t37, 0
  store i1 %t38, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t43 = getelementptr %"compiler/free:Free", ptr %t41, i32 0, i32 77
  store i1 true, ptr %t43, !tbaa !21
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t44 = load ptr, ptr %l4, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t45)
  store i32 %t47, ptr %l31
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l29, !tbaa !29
  %t49 = load i32, ptr %l31, !tbaa !23
  %t50 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t48, i32 %t49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l32
  br label %bb14
bb14:
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l6
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s0, ptr %l6)
  store i64 %t53, ptr %l34
  br label %bb15
bb15:
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = icmp eq i64 %t54, 0
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i64 @compiler_2ffree_2eownCopySite(ptr %v1, ptr %t57)
  store i64 %t59, ptr %l37
  br label %bb19
bb19:
  %t60 = load i64, ptr %l37, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  br label %bb22
bb21:
  store ptr null, ptr %l39, !tbaa !29
  br label %bb22
bb22:
  %t66 = load ptr, ptr %l39, !tbaa !29
  store ptr %t66, ptr %l7, !tbaa !29
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l43
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l45
  br label %bb23
bb23:
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l8
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l46, !tbaa !29
  store ptr %l6, ptr %l47, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t74)
  store i32 %t76, ptr %l49
  br label %bb24
bb24:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = load i32, ptr %l49, !tbaa !23
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t80, ptr %t81, i32 %t82, ptr %t77, ptr %l8, %"compiler/source:Span" %a3, ptr %t79)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l54
  br label %bb25
bb25:
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l54)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l56
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeField(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l18 = alloca i64
  %l20 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l34 = alloca ptr
  %l36 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:walker", ptr %t11, i32 0, i32 2
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 8
  %t24 = load i32, ptr %t23, !tbaa !23
  %t29 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t20, i32 %t24, i64 %a1)
  store i64 %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load i64, ptr %l18, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  store i1 %t31, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l12, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l22, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t38)
  store i32 %t40, ptr %l24
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = load i32, ptr %l24, !tbaa !23
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t41, i32 %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l25
  br label %bb12
bb12:
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l25)
  store i64 %t45, ptr %l27
  br label %bb13
bb13:
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = icmp eq i64 %t46, 0
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/free:walker", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/free:Free", ptr %t53, i32 0, i32 67
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:walker", ptr %t56, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t62 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t55, i64 %t59)
  store ptr %t62, ptr %l34
  br label %bb18
bb18:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t66 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t64, i64 %t63)
  store i64 %t66, ptr %l36
  br label %bb19
bb19:
  %t67 = load i64, ptr %l36, !tbaa !24
  %t68 = icmp sgt i64 %t67, 0
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 77
  store i1 true, ptr %t75, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ectorCall(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_546be3fdfb2e7861_5a4791e17fa5075d)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l5, !tbaa !29
  br label %bb32
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %t34)
  store ptr %t36, ptr %l21
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l21, !tbaa !29
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb32
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 8}
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Elem", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %t56)
  store ptr %t58, ptr %l30
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l30, !tbaa !29
  store ptr %t59, ptr %l5, !tbaa !29
  br label %bb32
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l31, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 8}
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Payload", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %t78)
  store ptr %t80, ptr %l39
  br label %bb26
bb26:
  %t81 = load ptr, ptr %l39, !tbaa !29
  store ptr %t81, ptr %l5, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_5891e56eddc46c99_f944b0e713971375)
  unreachable
bb32:
  %t82 = load ptr, ptr %l5, !tbaa !29
  store ptr %t82, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l20 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t30 = call ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %v1, ptr %t24, i64 %a1)
  store ptr %t30, ptr %l20
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l20, !tbaa !29
  store ptr %t31, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l6, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t23 = icmp eq i64 %t18, %a1
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2emovesOnly(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 8
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Collect", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t19)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l4, !tbaa !21
  br label %bb32
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 12
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Seq", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Seq", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_66111a817c7bb1ea_259ee9d6b37f7fd6)
  unreachable
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Seq", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i1 @compiler_2ffree_2emovesOnly(ptr %v0, ptr %t57)
  store i1 %t59, ptr %l30
  br label %bb18
bb18:
  %t60 = load i1, ptr %l30, !tbaa !21
  store i1 %t60, ptr %l24, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l24, !tbaa !21
  store i1 %t61, ptr %l4, !tbaa !21
  br label %bb32
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t63 = load ptr, ptr %l31, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 17
  store i1 %t69, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t70 = load i1, ptr %l32, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i1 @compiler_2ffree_2emovesOnly(ptr %v0, ptr %t77)
  store i1 %t79, ptr %l38
  br label %bb26
bb26:
  %t80 = load i1, ptr %l38, !tbaa !21
  store i1 %t80, ptr %l4, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_7a6e1b2179b57278_bd7dcc1897dee1e4)
  unreachable
bb32:
  %t81 = load i1, ptr %l4, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2epastAway(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call ptr @compiler_2ffree_2epastAway(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l10, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_53d04893e2c3ae6d_69f8ecc7fab20da9)
  unreachable
bb12:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2eruns({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9c97567f05482d15_e6d42a2535d66e1)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2estmtMoves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l65 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 2
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_c5daa4e55685553d_6576efec0cd8f099)
  unreachable
bb20:
  %t34 = load i1, ptr %l13, !tbaa !21
  store i1 %t34, ptr %l6, !tbaa !21
  br label %bb64
bb21:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb22, label %bb23
bb22:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 17}
  %t42 = icmp eq i64 %t40, 4
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb23
bb23:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb24, label %bb25
bb24:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t56)
  store i1 %t58, ptr %l31
  br label %bb27
bb27:
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb28, label %bb29
bb28:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  br i1 %t62, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb34
bb30:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb33
bb31:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t64)
  store i1 %t66, ptr %l37
  br label %bb32
bb32:
  %t67 = load i1, ptr %l37, !tbaa !21
  store i1 %t67, ptr %l35, !tbaa !21
  br label %bb33
bb33:
  %t68 = load i1, ptr %l35, !tbaa !21
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb34
bb34:
  %t69 = load i1, ptr %l32, !tbaa !21
  store i1 %t69, ptr %l6, !tbaa !21
  br label %bb64
bb35:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb36, label %bb37
bb36:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 17}
  %t77 = icmp eq i64 %t75, 11
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb37
bb37:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb38, label %bb39
bb38:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t85)
  store i1 %t87, ptr %l45
  br label %bb41
bb41:
  %t88 = load i1, ptr %l45, !tbaa !21
  store i1 %t88, ptr %l6, !tbaa !21
  br label %bb64
bb42:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb43, label %bb44
bb43:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 17}
  %t96 = icmp eq i64 %t94, 3
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb44
bb44:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb45, label %bb46
bb45:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr { i64, [3 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t100, i32 0, i32 1
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l5, !tbaa !29
  br label %bb47
bb46:
  br label %bb59
bb47:
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = getelementptr %"compiler/typed:If", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t107)
  store i1 %t109, ptr %l54
  br label %bb48
bb48:
  %t110 = load i1, ptr %l54, !tbaa !21
  br i1 %t110, label %bb49, label %bb50
bb49:
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr %"compiler/typed:If", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb58
bb51:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb57
bb52:
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t120 = getelementptr %"compiler/typed:If", ptr %t118, i32 0, i32 2
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = icmp eq ptr %t121, null
  br i1 %t123, label %bb53, label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_d17276f5db7535d5_c56bc4e021877641)
  unreachable
bb54:
  br label %bb55
bb55:
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t127 = getelementptr %"compiler/typed:If", ptr %t125, i32 0, i32 2
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t128)
  store i1 %t130, ptr %l65
  br label %bb56
bb56:
  %t131 = load i1, ptr %l65, !tbaa !21
  store i1 %t131, ptr %l59, !tbaa !21
  br label %bb57
bb57:
  %t132 = load i1, ptr %l59, !tbaa !21
  store i1 %t132, ptr %l55, !tbaa !21
  br label %bb58
bb58:
  %t133 = load i1, ptr %l55, !tbaa !21
  store i1 %t133, ptr %l6, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_3f14ee3b5ae87b07_81e960a9339250a3)
  unreachable
bb64:
  %t134 = load i1, ptr %l6, !tbaa !21
  store i1 %t134, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ewalker_2enewWalker(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, [2 x i64] }
  %l34 = alloca i32
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca %"compiler/free:walker"
  %l87 = alloca ptr
  %l90 = alloca i64
  %l106 = alloca i64
  %l109 = alloca i64
  %l129 = alloca i64
  %l132 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i64
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l149 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l155 = alloca i64
  %l159 = alloca i64
  %l162 = alloca i64
  %l183 = alloca i32
  %l192 = alloca ptr
  %l195 = alloca i64
  %l196 = alloca i64
  %l202 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l216 = alloca i64
  %l219 = alloca i64
  %l237 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l247 = alloca i64
  %l250 = alloca i64
  %l271 = alloca ptr
  %l272 = alloca { i64, ptr }
  %l275 = alloca i64
  %l289 = alloca i64
  %l293 = alloca i64
  %l296 = alloca i64
  %l315 = alloca ptr
  %l319 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t12 = alloca %"compiler/free:walker", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 6
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l44, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2ffree_3awalker_2ector(ptr %t12, ptr %v0, ptr %v0, ptr %t9, i64 %t10, i1 %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t12, i64 1952, i1 false)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 1952, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %l48, i64 1952, i1 false)
  %t18 = load ptr, ptr %l44, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t18, i32 0, i32 6
  store ptr %t16, ptr %t19, !tbaa !29
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:Free", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4f4bebe43ccb3632_b2d0ff49dc2f09b6)
  unreachable
bb6:
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 6
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l3, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 1
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i1, ptr %l2, !tbaa !21
  %t41 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 2
  store i1 %t38, ptr %t41, !tbaa !21
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/free:walker", ptr %t42, i32 0, i32 5
  store i1 false, ptr %t44, !tbaa !21
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t47)
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/free:walker", ptr %t49, i32 0, i32 7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t51)
  br label %bb9
bb9:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 8
  store i32 %t54, ptr %t57, !tbaa !23
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %t60)
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t64)
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Hca84839cdf395382408370342cfafe64(ptr %v0, ptr %t68)
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 24
  store i64 0, ptr %t72, !tbaa !24
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 29
  store i64 0, ptr %t75, !tbaa !24
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/free:walker", ptr %t76, i32 0, i32 30
  store i64 0, ptr %t78, !tbaa !24
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 31
  store i64 -1, ptr %t81, !tbaa !24
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 32
  store i64 -1, ptr %t84, !tbaa !24
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 35
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %t87)
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/free:walker", ptr %t89, i32 0, i32 41
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t91)
  br label %bb14
bb14:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 36
  store i64 -1, ptr %t95, !tbaa !24
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/free:walker", ptr %t96, i32 0, i32 37
  store i64 -1, ptr %t98, !tbaa !24
  %t99 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t99)
  br label %bb15
bb15:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:Free", ptr %t101, i32 0, i32 1
  %t104 = load i64, ptr %l1, !tbaa !24
  %t107 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t103, i64 %t104)
  store ptr %t107, ptr %l87
  br label %bb16
bb16:
  %t108 = load ptr, ptr %l87, !tbaa !29
  store ptr %t108, ptr %l4, !tbaa !29
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Body", ptr %t109, i32 0, i32 7
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t111)
  store i64 %t113, ptr %l90
  br label %bb17
bb17:
  %t114 = load i64, ptr %l90, !tbaa !24
  store i64 %t114, ptr %l5, !tbaa !24
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t117 = getelementptr %"compiler/free:walker", ptr %t115, i32 0, i32 3
  %t118 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H2ad576503181bd1b8552368bfa2352a6(ptr %v0, ptr %t117, i64 %t118)
  br label %bb18
bb18:
  %t121 = load ptr, ptr %l3, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t123)
  br label %bb19
bb19:
  %t125 = load ptr, ptr %l3, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t127)
  br label %bb20
bb20:
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t131)
  br label %bb21
bb21:
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t135)
  br label %bb22
bb22:
  store i64 0, ptr %l6, !tbaa !24
  %t137 = load i64, ptr %l5, !tbaa !24
  store i64 %t137, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t139 = load i64, ptr %l7, !tbaa !24
  %t140 = load i64, ptr %l6, !tbaa !24
  %t143 = icmp sgt i64 %t139, %t140
  br i1 %t143, label %bb23, label %bb24
bb23:
  %t145 = load i64, ptr %l8, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb28
bb25:
  %t149 = load i64, ptr %l7, !tbaa !24
  %t150 = load i64, ptr %l6, !tbaa !24
  %t153 = sub i64 %t149, %t150
  %t154 = load i64, ptr %l8, !tbaa !24
  %t157 = add i64 %t153, %t154
  %t159 = sub i64 %t157, 1
  %t160 = load i64, ptr %l8, !tbaa !24
  %t163 = sdiv i64 %t159, %t160
  store i64 %t163, ptr %l109, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb27
bb27:
  %t165 = load i64, ptr %l109, !tbaa !24
  store i64 %t165, ptr %l106, !tbaa !24
  br label %bb28
bb28:
  %t166 = load i64, ptr %l106, !tbaa !24
  store i64 %t166, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t167 = load i64, ptr %l10, !tbaa !24
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb31:
  br label %bb32
bb32:
  %t175 = load i64, ptr %l6, !tbaa !24
  %t176 = load i64, ptr %l10, !tbaa !24
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = mul i64 %t176, %t177
  %t183 = add i64 %t175, %t180
  store i64 %t183, ptr %l11, !tbaa !24
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t185, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t187, i1 false)
  br label %bb33
bb33:
  %t189 = load i64, ptr %l11, !tbaa !24
  store i64 %t189, ptr %l129, !tbaa !24
  %t190 = load ptr, ptr %l3, !tbaa !29
  %t192 = getelementptr %"compiler/free:walker", ptr %t190, i32 0, i32 3
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t192)
  store i64 %t194, ptr %l132
  br label %bb34
bb34:
  %t195 = load i64, ptr %l129, !tbaa !24
  %t196 = load i64, ptr %l132, !tbaa !24
  %t197 = icmp slt i64 %t195, %t196
  br i1 %t197, label %bb35, label %bb36
bb35:
  %t199 = load ptr, ptr %l3, !tbaa !29
  %t201 = getelementptr %"compiler/free:walker", ptr %t199, i32 0, i32 3
  %t202 = load i64, ptr %l11, !tbaa !24
  %t205 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t201, i64 %t202)
  store ptr %t205, ptr %l137
  br label %bb37
bb36:
  %t206 = load ptr, ptr %l3, !tbaa !29
  %t208 = getelementptr %"compiler/free:walker", ptr %t206, i32 0, i32 3
  store ptr %t208, ptr %l139, !tbaa !29
  %t209 = ptrtoint ptr %v0 to i64
  store i64 %t209, ptr %l140, !tbaa !24
  %t210 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t210, label %bb39, label %bb40
bb37:
  %t212 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t212)
  br label %bb38
bb38:
  br label %bb43
bb39:
  %t213 = call ptr @__olang_region_make(ptr %v0)
  %t214 = ptrtoint ptr %t213 to i64
  store i64 %t214, ptr %l140, !tbaa !24
  br label %bb40
bb40:
  %t215 = load i64, ptr %l140
  %t216 = inttoptr i64 %t215 to ptr
  %t217 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t216, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t217, ptr %l142
  br label %bb41
bb41:
  %t218 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  %t219 = load i64, ptr %l140
  %t220 = inttoptr i64 %t219 to ptr
  %t221 = call ptr @__olang_scope_alloc_a(ptr %t220, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %t221
  %t222 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t222, ptr %t221)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t226 = getelementptr %"compiler/free:walker", ptr %t224, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t226, i64 0)
  br label %bb44
bb44:
  %t228 = load ptr, ptr %l3, !tbaa !29
  %t230 = getelementptr %"compiler/free:walker", ptr %t228, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t230, i1 false)
  br label %bb45
bb45:
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t234 = getelementptr %"compiler/free:walker", ptr %t232, i32 0, i32 22
  store ptr %t234, ptr %l149, !tbaa !29
  %t235 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t235, ptr %l150
  br label %bb46
bb46:
  %t236 = load ptr, ptr %l149, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l150
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t236, %"compiler/source:Span" %t237)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb48:
  %t238 = load i64, ptr %l10, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l10, !tbaa !24
  br label %bb29
bb49:
  store i64 0, ptr %l12, !tbaa !24
  %t242 = load ptr, ptr %l4, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Body", ptr %t242, i32 0, i32 5
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t244)
  store i64 %t246, ptr %l155
  br label %bb50
bb50:
  %t247 = load i64, ptr %l155, !tbaa !24
  store i64 %t247, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t248 = load i64, ptr %l13, !tbaa !24
  %t249 = load i64, ptr %l12, !tbaa !24
  %t252 = icmp sgt i64 %t248, %t249
  br i1 %t252, label %bb51, label %bb52
bb51:
  %t254 = load i64, ptr %l14, !tbaa !24
  %t256 = icmp sgt i64 %t254, 0
  br i1 %t256, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l159, !tbaa !24
  br label %bb56
bb53:
  %t258 = load i64, ptr %l13, !tbaa !24
  %t259 = load i64, ptr %l12, !tbaa !24
  %t262 = sub i64 %t258, %t259
  %t263 = load i64, ptr %l14, !tbaa !24
  %t266 = add i64 %t262, %t263
  %t268 = sub i64 %t266, 1
  %t269 = load i64, ptr %l14, !tbaa !24
  %t272 = sdiv i64 %t268, %t269
  store i64 %t272, ptr %l162, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l162, !tbaa !24
  br label %bb55
bb55:
  %t274 = load i64, ptr %l162, !tbaa !24
  store i64 %t274, ptr %l159, !tbaa !24
  br label %bb56
bb56:
  %t275 = load i64, ptr %l159, !tbaa !24
  store i64 %t275, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb57
bb57:
  %t276 = load i64, ptr %l16, !tbaa !24
  %t277 = load i64, ptr %l15, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb58, label %bb59
bb58:
  br label %bb67
bb59:
  br label %bb60
bb60:
  %t284 = load i64, ptr %l12, !tbaa !24
  %t285 = load i64, ptr %l16, !tbaa !24
  %t286 = load i64, ptr %l14, !tbaa !24
  %t289 = mul i64 %t285, %t286
  %t292 = add i64 %t284, %t289
  store i64 %t292, ptr %l17, !tbaa !24
  %t294 = load ptr, ptr %l4, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Body", ptr %t294, i32 0, i32 5
  %t297 = load i64, ptr %l17, !tbaa !24
  %t300 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t296, i64 %t297)
  store i32 %t300, ptr %l183
  br label %bb61
bb61:
  %t301 = load i32, ptr %l183, !tbaa !23
  %t302 = sext i32 %t301 to i64
  store i64 %t302, ptr %l18, !tbaa !24
  %t304 = load ptr, ptr %l3, !tbaa !29
  %t306 = getelementptr %"compiler/free:walker", ptr %t304, i32 0, i32 6
  %t307 = load i64, ptr %l18, !tbaa !24
  %t308 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t306, i64 %t307, i64 %t308)
  br label %bb62
bb62:
  %t312 = load ptr, ptr %l3, !tbaa !29
  %t314 = getelementptr %"compiler/free:walker", ptr %t312, i32 0, i32 3
  %t315 = load i64, ptr %l18, !tbaa !24
  %t318 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t314, i64 %t315)
  store ptr %t318, ptr %l192
  br label %bb63
bb63:
  %t319 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t320 = load i64, ptr %l17, !tbaa !24
  %t323 = call i64 @compiler_2ffree_2eorig(i64 %t319, i64 %t320)
  store i64 %t323, ptr %l195
  br label %bb64
bb64:
  %t324 = load ptr, ptr %l192, !tbaa !29
  %t325 = load i64, ptr %l195, !tbaa !24
  %t326 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t324, i64 %t325)
  store i64 %t326, ptr %l196
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t327 = load i64, ptr %l16, !tbaa !24
  %t329 = add i64 %t327, 1
  store i64 %t329, ptr %l16, !tbaa !24
  br label %bb57
bb67:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/free:Free", ptr %t331, i32 0, i32 99
  %t334 = load i64, ptr %l1, !tbaa !24
  %t337 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t333, i64 %t334)
  store { i64, ptr } %t337, ptr %l202
  br label %bb68
bb68:
  %t338 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t338, ptr %l19, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t342 = load i64, ptr %l5, !tbaa !24
  %t344 = add i64 %t342, 1
  %t347 = icmp eq i64 %t341, %t344
  br i1 %t347, label %bb69, label %bb70
bb69:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/free:Free", ptr %t349, i32 0, i32 98
  %t352 = load i64, ptr %l1, !tbaa !24
  %t355 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t351, i64 %t352)
  store { i64, ptr } %t355, ptr %l211
  br label %bb71
bb70:
  br label %bb98
bb71:
  %t356 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t356, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t357 = load i64, ptr %l5, !tbaa !24
  store i64 %t357, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t359 = load i64, ptr %l22, !tbaa !24
  %t360 = load i64, ptr %l21, !tbaa !24
  %t363 = icmp sgt i64 %t359, %t360
  br i1 %t363, label %bb72, label %bb73
bb72:
  %t365 = load i64, ptr %l23, !tbaa !24
  %t367 = icmp sgt i64 %t365, 0
  br i1 %t367, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb77
bb74:
  %t369 = load i64, ptr %l22, !tbaa !24
  %t370 = load i64, ptr %l21, !tbaa !24
  %t373 = sub i64 %t369, %t370
  %t374 = load i64, ptr %l23, !tbaa !24
  %t377 = add i64 %t373, %t374
  %t379 = sub i64 %t377, 1
  %t380 = load i64, ptr %l23, !tbaa !24
  %t383 = sdiv i64 %t379, %t380
  store i64 %t383, ptr %l219, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l219, !tbaa !24
  br label %bb76
bb76:
  %t385 = load i64, ptr %l219, !tbaa !24
  store i64 %t385, ptr %l216, !tbaa !24
  br label %bb77
bb77:
  %t386 = load i64, ptr %l216, !tbaa !24
  store i64 %t386, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb78
bb78:
  %t387 = load i64, ptr %l25, !tbaa !24
  %t388 = load i64, ptr %l24, !tbaa !24
  %t391 = icmp slt i64 %t387, %t388
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb79, label %bb80
bb79:
  br label %bb97
bb80:
  br label %bb81
bb81:
  %t395 = load i64, ptr %l21, !tbaa !24
  %t396 = load i64, ptr %l25, !tbaa !24
  %t397 = load i64, ptr %l23, !tbaa !24
  %t400 = mul i64 %t396, %t397
  %t403 = add i64 %t395, %t400
  store i64 %t403, ptr %l26, !tbaa !24
  %t405 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t405, ptr %l237, !tbaa !27
  %t406 = load i64, ptr %l26, !tbaa !24
  %t408 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr i64, ptr %t409, i64 %t406
  %t411 = load i64, ptr %t410, !tbaa !34
  store i64 %t411, ptr %l27, !tbaa !24
  %t413 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t413, ptr %l240, !tbaa !27
  %t414 = load i64, ptr %l26, !tbaa !24
  %t416 = add i64 %t414, 1
  %t418 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !27
  %t420 = getelementptr i64, ptr %t419, i64 %t416
  %t421 = load i64, ptr %t420, !tbaa !34
  store i64 %t421, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t423 = load i64, ptr %l28, !tbaa !24
  %t424 = load i64, ptr %l27, !tbaa !24
  %t427 = icmp sgt i64 %t423, %t424
  br i1 %t427, label %bb82, label %bb83
bb82:
  %t429 = load i64, ptr %l29, !tbaa !24
  %t431 = icmp sgt i64 %t429, 0
  br i1 %t431, label %bb84, label %bb85
bb83:
  store i64 0, ptr %l247, !tbaa !24
  br label %bb87
bb84:
  %t433 = load i64, ptr %l28, !tbaa !24
  %t434 = load i64, ptr %l27, !tbaa !24
  %t437 = sub i64 %t433, %t434
  %t438 = load i64, ptr %l29, !tbaa !24
  %t441 = add i64 %t437, %t438
  %t443 = sub i64 %t441, 1
  %t444 = load i64, ptr %l29, !tbaa !24
  %t447 = sdiv i64 %t443, %t444
  store i64 %t447, ptr %l250, !tbaa !24
  br label %bb86
bb85:
  store i64 0, ptr %l250, !tbaa !24
  br label %bb86
bb86:
  %t449 = load i64, ptr %l250, !tbaa !24
  store i64 %t449, ptr %l247, !tbaa !24
  br label %bb87
bb87:
  %t450 = load i64, ptr %l247, !tbaa !24
  store i64 %t450, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb88
bb88:
  %t451 = load i64, ptr %l31, !tbaa !24
  %t452 = load i64, ptr %l30, !tbaa !24
  %t455 = icmp slt i64 %t451, %t452
  %t457 = xor i1 %t455, true
  br i1 %t457, label %bb89, label %bb90
bb89:
  br label %bb95
bb90:
  br label %bb91
bb91:
  %t459 = load i64, ptr %l27, !tbaa !24
  %t460 = load i64, ptr %l31, !tbaa !24
  %t461 = load i64, ptr %l29, !tbaa !24
  %t464 = mul i64 %t460, %t461
  %t467 = add i64 %t459, %t464
  store i64 %t467, ptr %l32, !tbaa !24
  %t469 = load ptr, ptr %l3, !tbaa !29
  %t471 = getelementptr %"compiler/free:walker", ptr %t469, i32 0, i32 3
  %t472 = load i64, ptr %l26, !tbaa !24
  %t475 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t471, i64 %t472)
  store ptr %t475, ptr %l271
  br label %bb92
bb92:
  %t476 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t476, ptr %l272, !tbaa !27
  %t477 = load i64, ptr %l32, !tbaa !24
  %t479 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !27
  %t481 = getelementptr i64, ptr %t480, i64 %t477
  %t482 = load i64, ptr %t481, !tbaa !34
  %t483 = load ptr, ptr %l271, !tbaa !29
  %t485 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t483, i64 %t482)
  store i64 %t485, ptr %l275
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t486 = load i64, ptr %l31, !tbaa !24
  %t488 = add i64 %t486, 1
  store i64 %t488, ptr %l31, !tbaa !24
  br label %bb88
bb95:
  br label %bb96
bb96:
  %t490 = load i64, ptr %l25, !tbaa !24
  %t492 = add i64 %t490, 1
  store i64 %t492, ptr %l25, !tbaa !24
  br label %bb78
bb97:
  br label %bb98
bb98:
  %t494 = load ptr, ptr %l4, !tbaa !29
  %t496 = getelementptr %"compiler/typed:Body", ptr %t494, i32 0, i32 1
  %t497 = load { i64, [2 x i64] }, ptr %t496
  store { i64, [2 x i64] } %t497, ptr %l33
  %t499 = load { i64, [2 x i64] }, ptr %l33
  %t501 = extractvalue { i64, [2 x i64] } %t499, 0
  %t502 = icmp eq i64 %t501, 1
  br i1 %t502, label %bb99, label %bb100
bb99:
  %t504 = getelementptr { i64, [2 x i64] }, ptr %l33, i32 0, i32 1
  %t505 = getelementptr { i32, i32 }, ptr %t504, i32 0, i32 0
  %t506 = load i32, ptr %t505
  store i32 %t506, ptr %l34, !tbaa !23
  br label %bb101
bb100:
  br label %bb117
bb101:
  %t508 = load ptr, ptr %l3, !tbaa !29
  %t509 = load i32, ptr %l34, !tbaa !23
  %t512 = getelementptr %"compiler/free:walker", ptr %t508, i32 0, i32 8
  store i32 %t509, ptr %t512, !tbaa !23
  store i64 0, ptr %l35, !tbaa !24
  %t513 = load ptr, ptr %l4, !tbaa !29
  %t515 = getelementptr %"compiler/typed:Body", ptr %t513, i32 0, i32 10
  %t517 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t515)
  store i64 %t517, ptr %l289
  br label %bb102
bb102:
  %t518 = load i64, ptr %l289, !tbaa !24
  store i64 %t518, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t519 = load i64, ptr %l36, !tbaa !24
  %t520 = load i64, ptr %l35, !tbaa !24
  %t523 = icmp sgt i64 %t519, %t520
  br i1 %t523, label %bb103, label %bb104
bb103:
  %t525 = load i64, ptr %l37, !tbaa !24
  %t527 = icmp sgt i64 %t525, 0
  br i1 %t527, label %bb105, label %bb106
bb104:
  store i64 0, ptr %l293, !tbaa !24
  br label %bb108
bb105:
  %t529 = load i64, ptr %l36, !tbaa !24
  %t530 = load i64, ptr %l35, !tbaa !24
  %t533 = sub i64 %t529, %t530
  %t534 = load i64, ptr %l37, !tbaa !24
  %t537 = add i64 %t533, %t534
  %t539 = sub i64 %t537, 1
  %t540 = load i64, ptr %l37, !tbaa !24
  %t543 = sdiv i64 %t539, %t540
  store i64 %t543, ptr %l296, !tbaa !24
  br label %bb107
bb106:
  store i64 0, ptr %l296, !tbaa !24
  br label %bb107
bb107:
  %t545 = load i64, ptr %l296, !tbaa !24
  store i64 %t545, ptr %l293, !tbaa !24
  br label %bb108
bb108:
  %t546 = load i64, ptr %l293, !tbaa !24
  store i64 %t546, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb109
bb109:
  %t547 = load i64, ptr %l39, !tbaa !24
  %t548 = load i64, ptr %l38, !tbaa !24
  %t551 = icmp slt i64 %t547, %t548
  %t553 = xor i1 %t551, true
  br i1 %t553, label %bb110, label %bb111
bb110:
  br label %bb116
bb111:
  br label %bb112
bb112:
  %t555 = load i64, ptr %l35, !tbaa !24
  %t556 = load i64, ptr %l39, !tbaa !24
  %t557 = load i64, ptr %l37, !tbaa !24
  %t560 = mul i64 %t556, %t557
  %t563 = add i64 %t555, %t560
  store i64 %t563, ptr %l40, !tbaa !24
  %t565 = load ptr, ptr %l3, !tbaa !29
  %t567 = getelementptr %"compiler/free:walker", ptr %t565, i32 0, i32 7
  store ptr %t567, ptr %l315, !tbaa !29
  %t568 = load ptr, ptr %l4, !tbaa !29
  %t570 = getelementptr %"compiler/typed:Body", ptr %t568, i32 0, i32 10
  %t571 = load i64, ptr %l40, !tbaa !24
  %t574 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t570, i64 %t571)
  store i32 %t574, ptr %l319
  br label %bb113
bb113:
  %t575 = load i32, ptr %l319, !tbaa !23
  %t576 = sext i32 %t575 to i64
  %t577 = load i64, ptr %l40, !tbaa !24
  %t578 = load ptr, ptr %l315, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t578, i64 %t576, i64 %t577)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t581 = load i64, ptr %l39, !tbaa !24
  %t583 = add i64 %t581, 1
  store i64 %t583, ptr %l39, !tbaa !24
  br label %bb109
bb116:
  br label %bb122
bb117:
  br i1 true, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_47453ae46be9b210_439bef1cf54c0f44)
  unreachable
bb122:
  %t585 = load ptr, ptr %l3, !tbaa !29
  store ptr %t585, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca i32
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i32
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i1
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca ptr
  %l70 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca i1
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca { i64, ptr }
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i32
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %t16)
  %t19 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t18, 1
  %t20 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t18, 0
  store i32 %t20, ptr %l20
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb7, label %ok.22, !prof !99
ok.22:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l19
  br label %bb6
bb6:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l17
  br label %bb8
bb7:
  %t24 = load i32, ptr %l20, !tbaa !23
  %t25 = lshr i32 %t24, 16
  %t26 = and i32 %t24, 65535
  %t27 = icmp eq i32 %t25, 1
  %t28 = select i1 %t27, i32 1, i32 0
  %t29 = icmp eq i32 %t24, 0
  %t30 = shl i32 %t28, 16
  %t31 = or i32 %t30, %t26
  %t32 = select i1 %t29, i32 0, i32 %t31
  %t34 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t32, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t34, ptr %rv
  br label %ret
bb8:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t36 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t36, ptr %rv
  br label %ret
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 11
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb36
bb14:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Cond", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t60 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t60, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Cond", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = icmp eq ptr %t64, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9500bd9cb83e9e6a_a32a388bbeb50dae)
  unreachable
bb19:
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Cond", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %t71)
  %t74 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t73, 1
  %t75 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t73, 0
  store i32 %t75, ptr %l39
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb22, label %ok.77, !prof !99
ok.77:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l38
  br label %bb21
bb21:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l32
  br label %bb23
bb22:
  %t79 = load i32, ptr %l39, !tbaa !23
  %t80 = lshr i32 %t79, 16
  %t81 = and i32 %t79, 65535
  %t82 = icmp eq i32 %t80, 1
  %t83 = select i1 %t82, i32 1, i32 0
  %t84 = icmp eq i32 %t79, 0
  %t85 = shl i32 %t83, 16
  %t86 = or i32 %t85, %t81
  %t87 = select i1 %t84, i32 0, i32 %t86
  %t89 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t87, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t89, ptr %rv
  br label %ret
bb23:
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t90, ptr %lp3
  %t91 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t92 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %t92
  store %olang.scope zeroinitializer, ptr %s4
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Cond", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %s4, ptr %t96)
  %t99 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t98, 1
  %t100 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t98, 0
  store i32 %t100, ptr %l44
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb25, label %ok.102, !prof !99
ok.102:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l43
  br label %bb24
bb24:
  %t103 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t104 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %t104
  store ptr %t104, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb26
bb25:
  %t106 = load i32, ptr %l44, !tbaa !23
  %t107 = lshr i32 %t106, 16
  %t108 = and i32 %t106, 65535
  %t109 = icmp eq i32 %t107, 1
  %t110 = select i1 %t109, i32 1, i32 0
  %t111 = icmp eq i32 %t106, 0
  %t112 = shl i32 %t110, 16
  %t113 = or i32 %t112, %t108
  %t114 = select i1 %t111, i32 0, i32 %t113
  call void @__olang_scope_close(ptr %s4)
  %t116 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t114, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t116, ptr %rv
  br label %ret
bb26:
  %t117 = load i64, ptr %l5, !tbaa !24
  store i64 %t117, ptr %l47, !tbaa !24
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s4, ptr %t118)
  store i64 %t120, ptr %l49
  br label %bb27
bb27:
  %t121 = load i64, ptr %l47, !tbaa !24
  %t122 = load i64, ptr %l49, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  br label %bb30
bb30:
  %t127 = load ptr, ptr %l4, !tbaa !29
  %t128 = load i64, ptr %l5, !tbaa !24
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s4, ptr %t127, i64 %t128)
  store i64 %t131, ptr %l54
  br label %bb31
bb31:
  %t132 = load i64, ptr %l54, !tbaa !24
  %t133 = load ptr, ptr %lp3
  %t137 = call i64 @compiler_2ffree_2eaddTo(ptr %v1, ptr %t133, i64 %t132)
  store i64 %t137, ptr %l57
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t138 = load i64, ptr %l5, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l5, !tbaa !24
  br label %bb26
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t142 = load ptr, ptr %lp3
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t142
  %t145 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t145, ptr %rv
  br label %ret
bb36:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t147 = load ptr, ptr %l61, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb37, label %bb38
bb37:
  %t150 = load ptr, ptr %l61, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 18}
  %t153 = icmp eq i64 %t151, 15
  store i1 %t153, ptr %l62, !tbaa !21
  br label %bb38
bb38:
  %t154 = load i1, ptr %l62, !tbaa !21
  br i1 %t154, label %bb39, label %bb40
bb39:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr { i64, [5 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t161 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %l67
  br label %bb42
bb42:
  %t162 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t162, ptr %lp8
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  %t164 = load ptr, ptr %lp8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %t164
  %t165 = load ptr, ptr %lp8
  store ptr %t165, ptr %l68, !tbaa !29
  %t166 = load ptr, ptr %l7, !tbaa !29
  %t168 = call i64 @compiler_2ffree_2efnRecOf(ptr %v0, ptr %t166)
  store i64 %t168, ptr %l70
  br label %bb43
bb43:
  %t169 = load ptr, ptr %l68, !tbaa !29
  %t170 = load i64, ptr %l70, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t169, i64 %t170)
  br label %bb44
bb44:
  %t171 = load ptr, ptr %lp8
  %t172 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t171
  %t174 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t174, ptr %rv
  br label %ret
bb45:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t176 = load ptr, ptr %l72, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb46, label %bb47
bb46:
  %t179 = load ptr, ptr %l72, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 18}
  %t182 = icmp eq i64 %t180, 9
  store i1 %t182, ptr %l73, !tbaa !21
  br label %bb47
bb47:
  %t183 = load i1, ptr %l73, !tbaa !21
  br i1 %t183, label %bb48, label %bb49
bb48:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr { i64, [5 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t186, i32 0, i32 2
  %t188 = load i32, ptr %t187, !range !{i32 0, i32 52}
  store i32 %t188, ptr %l9
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t192, i32 0, i32 4
  %t194 = load { i64, ptr }, ptr %t193
  store { i64, ptr } %t194, ptr %l10, !tbaa !27
  br label %bb50
bb49:
  br label %bb60
bb50:
  %t196 = load i32, ptr %l9, !range !{i32 0, i32 52}
  %t198 = trunc i64 20 to i32
  %t199 = icmp eq i32 %t196, %t198
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb53
bb52:
  %t203 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t207 = icmp ne i64 %t205, 1
  store i1 %t207, ptr %l83, !tbaa !21
  br label %bb53
bb53:
  %t209 = load i1, ptr %l83, !tbaa !21
  br i1 %t209, label %bb54, label %bb55
bb54:
  %t211 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t211, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t212 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t212, ptr %l89, !tbaa !27
  %t213 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr ptr, ptr %t214, i64 0
  %t216 = load ptr, ptr %t215, !tbaa !39
  %t218 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %t216)
  %t219 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t218, 1
  %t220 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t218, 0
  store i32 %t220, ptr %l92
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb58, label %ok.222, !prof !99
ok.222:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t219, ptr %l91
  br label %bb57
bb57:
  %t223 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l88
  br label %bb59
bb58:
  %t224 = load i32, ptr %l92, !tbaa !23
  %t225 = lshr i32 %t224, 16
  %t226 = and i32 %t224, 65535
  %t227 = icmp eq i32 %t225, 1
  %t228 = select i1 %t227, i32 1, i32 0
  %t229 = icmp eq i32 %t224, 0
  %t230 = shl i32 %t228, 16
  %t231 = or i32 %t230, %t226
  %t232 = select i1 %t229, i32 0, i32 %t231
  %t234 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t232, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t234, ptr %rv
  br label %ret
bb59:
  %t235 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  %t236 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t236, ptr %rv
  br label %ret
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t238 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t238, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_624ae5f0ecf6c3f8_e9900904abc8988c)
  unreachable
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, %"compiler/source:Span" %a6, i64 %a7, i1 %a8) #0 {
entry:
  %rv = alloca %"compiler/free:letGo"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:letGo" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:letGo" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:letGo" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:letGo" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:letGo" %t26, %"compiler/source:Span" %a4, 4
  %t30 = insertvalue %"compiler/free:letGo" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:letGo" %t30, %"compiler/source:Span" %a6, 6
  %t34 = insertvalue %"compiler/free:letGo" %t32, i64 %a7, 7
  %t36 = insertvalue %"compiler/free:letGo" %t34, i1 %a8, 8
  store %"compiler/free:letGo" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:letGo", ptr %rv
  ret %"compiler/free:letGo" %rr
}

define dso_local %"compiler/free:retire" @compiler_2ffree_3aretire_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %rv = alloca %"compiler/free:retire"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/free:retire" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/free:retire" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/free:retire" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, 2
  store %"compiler/free:retire" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:retire", ptr %rv
  ret %"compiler/free:retire" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d0 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"buf never " }>, align 8
@.c1 = private unnamed_addr constant [5 x i8] c"true\00"
@.c2 = private unnamed_addr constant [6 x i8] c"false\00"
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_errpay_pop()
@.d5 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"buf all " }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" by " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d7 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" taintAll " }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c": note: an existing one is stored into an owning place here, which another may still hold" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 9}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 i64 8, label %bb8 ]
bb3:
  br label %bb15
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb11, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb13, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb14, label %bb1
bb14:
  br label %bb3
bb15:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare ptr @__olang_region_or(ptr, ptr)
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d15 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"free: registered " }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eassign_2elocal_2e10 = weak hidden constant i1 false
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
@.d20 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"a whole array of them stored" }>, align 8
@.d21 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a store into it" }>, align 8
define linkonce_odr %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2ecompiler_2ffree_3areason_2e3 = weak hidden constant i1 false
@.d22 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"its new value is a copy holding other owners too: '" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d24 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"its new value is existing storage a copy shares: '" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d27 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"its new value is moved out of another place" }>, align 8
@.d28 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"its new value has a default" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d31 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"'; give it new storage - a constructor call, '$...', 'Copy()'" }>, align 8
@.d32 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"its elements may hold storage built with it: '" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d34 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"its new value is kept in another place too" }>, align 8
@.d35 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c"a value moved out of it is held where its call lands (O16), where nothing releases it: '" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 568, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 10
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 15
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %t27)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  %t31 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t31
  %t32 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 568, i1 false)
  br label %ret
ret:
  ret void
}

@.d37 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"a copy of a value holding it" }>, align 8
@.d38 = private constant <{ i64, [105 x i8] }> <{ i64 0, [105 x i8] c"may let go of anything: it calls through a function value not followed whose type does not promise 'pure'" }>, align 8
@.d39 = private constant <{ i64, [122 x i8] }> <{ i64 0, [122 x i8] c"may let go of anything: it is given a function value not followed whose type does not promise 'pure', and calls through it" }>, align 8
@.d40 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"may let go of anything" }>, align 8
@.d41 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"removes " }>, align 8
@.d42 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"lets go of it" }>, align 8
@.d43 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"its value is handed back here" }>, align 8
@.d44 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"a view that may be into an array a generational instance holds in place is stored here: '" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d48 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d49 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a reference into it is stored here; store a copy, '$(...)'" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d52 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d53 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a reference into it is stored here; store a copy, '$(...)'" }>, align 8
@.d54 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"esc-store " }>, align 8
@.d55 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" par " }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d57 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" within " }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = mul i64 %t13, 8
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = mul i64 %t22, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t42 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %t15)
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t22, i64 %t20
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %a0
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %rv
  ret %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eNotSole = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviews(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fio_2ePutErr(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H39bf208114dde5103bad7bf7476536d8(ptr %v0, ptr %a0)
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H6d56ff767ac7b72ad0cd898fedbf4594(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H6b631d225ad7497d2fe678f6450177ae(ptr %v0, ptr %a0, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_3a516a19293feeda_7f77204653e04cce = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWeakField(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edeclaredHere(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H2bb64fd79dc59453b9269b2696d6897f(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H69db31e35a4e973edf5f90026da8d45a(ptr %v0, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, ptr %a8)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
@G_2ecompiler_2ffree_2eSFail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hdc5ed4f57090b33f7a83fc7b2b1f05b3(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2ffree_2ewholeCopySite(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_5e4bdb92ce033105_74c6fffa83d8f4b9 = external constant [0 x i8]
@olang_loc_3c9da0e6d6f67483_45a341cc236b558f = external constant [0 x i8]
@olang_loc_e18b9bec1e794c30_83d73385e9669d24 = external constant [0 x i8]
@olang_loc_51fe1291bf78cb56_b8b2e6162161098a = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_52b05c17772fc4a9_239015c769d5fa15 = external constant [0 x i8]
declare i1 @compiler_2ffree_2eisBlock({ i64, [2 x i64] } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eLen_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare %"compiler/free:feed" @compiler_2ffree_3afeed_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, { i64, [2 x i64] } %a4, { i64, [2 x i64] } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2ePush_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0, %"compiler/free:feed" %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f0ef9f3a8cd9f24a_5f2afb921a19c616 = external constant [0 x i8]
@olang_loc_1befe4f0760966d8_ea99a8b72a88b024 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_bb5f0dfb007b1fe9_f99f55ed89f1afa5 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4607beb6ac2e2918_142733ac3129574 = external constant [0 x i8]
@olang_loc_ac355660a49cb455_c717ad746a0ccd69 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eanyMethod(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2eprotocolName(ptr %v0, { i64, ptr } %a0)
@olang_loc_9eead29ed0644a31_3adf6a8ef4d2d8d5 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisGlobal(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/free:reason" %a2)
@olang_loc_1888621446777a9a_f48dc3b4e7acb28e = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ed0a7c8afdb87cca_1f491858f5456086 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustOf(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:reason" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4e10a6e17fa9b999_b873e8c9bb06b2fd = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_997f49c366488af5_93d2651ee5683809 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_3f4c383e8983fca5_b7613254c9da681 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a4118a366f7ca1d5_524409770a0878b9 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5c44d6b41b035ab1_55f561a861d07b6d = external constant [0 x i8]
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eValueParts(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %a0)
@olang_loc_cba1607a5f8c25be_1da50212bb736ed2 = external constant [0 x i8]
@olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_ebe5ee6b39eee92e_4ec5471030d8b4f2 = external constant [0 x i8]
@olang_loc_c32ca46bf6d65f0c_9a54b76873cd9ad0 = external constant [0 x i8]
@olang_loc_b4c0d703fa684531_272a8f4f39064c15 = external constant [0 x i8]
@olang_loc_b71f5ffe7a4b5626_fc1be7c1ddcacd52 = external constant [0 x i8]
@olang_loc_80901eaab4a643b4_757281eb5f4291b0 = external constant [0 x i8]
declare i64 @compiler_2ffree_2eokind(i64 %a0)
declare i64 @compiler_2ffree_2eoval(i64 %a0)
@G_2ecompiler_2ffree_2eOPar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOParC = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecopiedPlain(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %a0)
@olang_loc_30cfd3b464a887aa_ca3830b5343a05a6 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %a0)
@olang_loc_3a3557a9366273b1_8eafb121351cf8d = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egenCalls(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2ffree_2eSFresh = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eouterFirst(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_b0d58e2b07420cd2_669637d27520b416 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedDest(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [2 x i64] } %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i1 %a5, i1 %a6)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewriteFeedCalls(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [2 x i64] } %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eMustNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6)
declare %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviaCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, %"compiler/source:Span" %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopiedCtorOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyStored(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ffree_2eownCopySite(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
@olang_loc_620cc86993d1ee05_2ed463b6a2f232e1 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoredWhole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, ptr %a6)
@olang_loc_e251e9e241135754_793c210c71879d50 = external constant [0 x i8]
declare i1 @compiler_2ffree_2eleaves(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2fa77e012092fd19_7ffe9e1eddadbc5d = external constant [0 x i8]
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c6ff733ce949281236b08418b935189(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H48be4d072aa67a39865369f0fe94a62c(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitLeaf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, ptr %a4, i64 %a5)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2efieldRootLocal(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_555e391ca9f1c191_fbd79fc4fd463c05 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eAnyPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eSOk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSMove = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@olang_loc_7676aaa4af173342_5bef0e3278c42ba6 = external constant [0 x i8]
@olang_loc_a47d70a6f4791f29_9aa1d88f57dbf58d = external constant [0 x i8]
declare { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eMovBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
@olang_loc_c3165b793781225b_53a43f46ee99ca6f = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainElems(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eViewOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fmir_2eViewNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ffree_2eOMov = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eONew = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2eisVar({ i64, [2 x i64] } %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4057097bf127937e673a7f89a723e29a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
@G_2ecompiler_2ffree_2eCalleeValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eCalleeGiven = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_3f338d8afa9da51a_e8058e9e002c9166 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eRStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_311feee871305b59_d38294057dde4ced = external constant [0 x i8]
@olang_loc_421add8d063ee188_aab923ea260c413c = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufPlace(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufNot(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2ffree_2eOUnk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueRecsAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_afd3b4561806d30e_4841abb84b9127fa = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efixedParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ethroughParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3, ptr %a4, %"compiler/source:Span" %a5)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emayWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_546be3fdfb2e7861_5a4791e17fa5075d = external constant [0 x i8]
@olang_loc_5891e56eddc46c99_f944b0e713971375 = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %a0)
@olang_loc_66111a817c7bb1ea_259ee9d6b37f7fd6 = external constant [0 x i8]
@olang_loc_7a6e1b2179b57278_bd7dcc1897dee1e4 = external constant [0 x i8]
@olang_loc_53d04893e2c3ae6d_69f8ecc7fab20da9 = external constant [0 x i8]
@olang_loc_9c97567f05482d15_e6d42a2535d66e1 = external constant [0 x i8]
@olang_loc_c5daa4e55685553d_6576efec0cd8f099 = external constant [0 x i8]
@olang_loc_d17276f5db7535d5_c56bc4e021877641 = external constant [0 x i8]
@olang_loc_3f14ee3b5ae87b07_81e960a9339250a3 = external constant [0 x i8]
declare void @compiler_2ffree_3awalker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_4f4bebe43ccb3632_b2d0ff49dc2f09b6 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Hca84839cdf395382408370342cfafe64(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H2ad576503181bd1b8552368bfa2352a6(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_47453ae46be9b210_439bef1cf54c0f44 = external constant [0 x i8]
@olang_loc_9500bd9cb83e9e6a_a32a388bbeb50dae = external constant [0 x i8]
declare i64 @compiler_2ffree_2efnRecOf(ptr %v0, ptr %a0)
@olang_loc_624ae5f0ecf6c3f8_e9900904abc8988c = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
