; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1fa2fbb95b4b7e4_869acc68af28bb00 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_5277d2faf3b5ce1_edfb16655fc6fb7d = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_632d91669af894ef_d53305abf610efbb = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_ddb0b7dc6f11d570_7d81fcc194d1ac0c = weak_odr constant [41 x i8] c"std/prelude/map.olang:273: null reached\0A\00"
@olang_loc_e42ae58d52e9e5a5_dbe74f88adf4c211 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_f5e2e9e0059e15b6_7e90b7c4671f0b12 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
