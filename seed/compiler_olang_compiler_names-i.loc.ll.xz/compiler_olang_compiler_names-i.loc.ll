; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_14b18470251c9af9_5988a49bb6bdd1bd = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_69c3ff6286fa4bf2_a8939ad25ae4d55e = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_69fa9ca79eb1b92d_eed2c70bafc08a79 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_a3754bc014943a98_6c238aad58a9328c = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_ddb0b7dc6f11d570_7d81fcc194d1ac0c = weak_odr constant [41 x i8] c"std/prelude/map.olang:273: null reached\0A\00"
@olang_loc_e15ef0eba7c48a4f_eac21e630a9f2f03 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_e16919bcd8ec4935_78c17cdafa916ff9 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_e42ae58d52e9e5a5_dbe74f88adf4c211 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_e98c49f7fe1437c_4629e8d95a215130 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_ed068ef3ab38a3e3_12e5e2269d7b5adf = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_f5e2e9e0059e15b6_7e90b7c4671f0b12 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
