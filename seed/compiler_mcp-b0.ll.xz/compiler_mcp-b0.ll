; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Item" = type { i1, { i64, ptr }, i64, i64, i64, i64, { i64, ptr }, i1 }
%"compiler/session:Positions" = type { { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/session:Analysis" = type { ptr, { i64, ptr }, ptr, ptr, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
define dso_local { i64, ptr } @compiler_2fmcp_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca [3 x { i64, ptr }]
  %l6 = alloca %"std/os:Output"
  %l8 = alloca [3 x { i64, ptr }]
  %l9 = alloca %"std/os:Output"
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l13 = alloca { { i64, ptr }, i32 }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l17 = alloca { i64, ptr }
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/os:Output"
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"std/os:Output"
  %l31 = alloca i32
  %l33 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"std/os:Output"
  %l58 = alloca { i64, ptr }
  %l59 = alloca %"std/os:Output"
  %l60 = alloca i32
  %l62 = alloca i1
  %l65 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i1
  %l82 = alloca i1
  %l84 = alloca i1
  %l86 = alloca i1
  %l91 = alloca { i64, ptr }
  %l93 = alloca i1
  %l97 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca i32
  %l105 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l116 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l126 = alloca { { i64, ptr }, i32 }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t224 = alloca { i64, [2 x i64] }, align 8
  %t257 = alloca { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %s0, ptr %v1, ptr %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i1, ptr %l19, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t9, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t11, ptr %l21
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t12 = load i1, ptr %l21, !tbaa !21
  br i1 %t12, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %s2, ptr %v4, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store { i64, ptr } %t13, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t14 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb9:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t15, 0
  %t19 = insertvalue [3 x { i64, ptr }] %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t21 = insertvalue [3 x { i64, ptr }] %t19, { i64, ptr } %t16, 2
  store [3 x { i64, ptr }] %t21, ptr %l5
  %t24 = insertvalue { i64, ptr } undef, i64 3, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %l5, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t28 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t25, { i64, ptr } %t27, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t29 = extractvalue { i32, %"std/os:Output" } %t28, 1
  %t30 = extractvalue { i32, %"std/os:Output" } %t28, 0
  store i32 %t30, ptr %l31
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb11, label %ok.32, !prof !99
ok.32:
  store %"std/os:Output" %t29, ptr %l30
  br label %bb10
bb10:
  %t33 = load %"std/os:Output", ptr %l30
  store %"std/os:Output" %t33, ptr %l23
  br label %bb16
bb11:
  %t34 = load i32, ptr %l31, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  store i1 %t37, ptr %l33, !tbaa !21
  %t38 = load i32, ptr %l31, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %s3, ptr %v4, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store { i64, ptr } %t43, ptr %l36
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb16:
  %t45 = load %"std/os:Output", ptr %l23
  store %"std/os:Output" %t45, ptr %l6
  %t46 = call ptr @__olang_scope_hold(ptr %s1)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l37, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t50 = call ptr @__olang_region_make(ptr %s1)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l37, !tbaa !24
  br label %bb18
bb18:
  %t52 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t54 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t53, 1
  %t58 = extractvalue { i64, ptr } %t53, 0
  %t60 = extractvalue { i64, ptr } %t55, 1
  %t61 = extractvalue { i64, ptr } %t55, 0
  %t62 = add i64 %t58, %t61
  %t63 = load i64, ptr %l37
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call ptr @__olang_held_alloc(ptr %t64, i64 %t62)
  call void @olang_textcopy(ptr %t65, ptr %t57, i64 %t58)
  %t66 = getelementptr i8, ptr %t65, i64 %t58
  call void @olang_textcopy(ptr %t66, ptr %t60, i64 %t61)
  %t67 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t70 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2fmcp_2etestResult(ptr %s1, ptr %v4, { i64, ptr } %t68, i32 %t71)
  store { i64, ptr } %t74, ptr %l44
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb20:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t78, ptr %l46
  br label %bb21
bb21:
  %t79 = load i1, ptr %l46, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t80, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t82, ptr %l49
  br label %bb24
bb23:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb25
bb24:
  %t83 = load i1, ptr %l49, !tbaa !21
  store i1 %t83, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t84 = load i1, ptr %l47, !tbaa !21
  br i1 %t84, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %s5, ptr %v1, ptr %t85, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store { i64, ptr } %t87, ptr %l51
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t88 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t92 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t89, 0
  %t93 = insertvalue [3 x { i64, ptr }] %t92, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t95 = insertvalue [3 x { i64, ptr }] %t93, { i64, ptr } %t88, 2
  store [3 x { i64, ptr }] %t95, ptr %l8
  %t98 = insertvalue { i64, ptr } undef, i64 3, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %l8, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t102 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s5, ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t99, { i64, ptr } %t101, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t103 = extractvalue { i32, %"std/os:Output" } %t102, 1
  %t104 = extractvalue { i32, %"std/os:Output" } %t102, 0
  store i32 %t104, ptr %l60
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb30, label %ok.106, !prof !99
ok.106:
  store %"std/os:Output" %t103, ptr %l59
  br label %bb29
bb29:
  %t107 = load %"std/os:Output", ptr %l59
  store %"std/os:Output" %t107, ptr %l52
  br label %bb35
bb30:
  %t108 = load i32, ptr %l60, !tbaa !23
  %t109 = ashr i32 %t108, 16
  %t111 = icmp eq i32 %t109, 1
  store i1 %t111, ptr %l62, !tbaa !21
  %t112 = load i32, ptr %l60, !tbaa !23
  %t113 = ashr i32 %t112, 16
  %t115 = icmp eq i32 %t113, 1
  br i1 %t115, label %bb31, label %bb32
bb31:
  call void @__olang_errpay_pop()
  br label %bb32
bb32:
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t117 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %s6, ptr %v4, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store { i64, ptr } %t117, ptr %l65
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t118 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
bb35:
  %t119 = load %"std/os:Output", ptr %l52
  store %"std/os:Output" %t119, ptr %l9
  %t120 = getelementptr %"std/os:Output", ptr %l9, i32 0, i32 1
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t122 = getelementptr %"std/os:Output", ptr %l9, i32 0, i32 2
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t121, 1
  %t126 = extractvalue { i64, ptr } %t121, 0
  %t128 = extractvalue { i64, ptr } %t123, 1
  %t129 = extractvalue { i64, ptr } %t123, 0
  %t130 = add i64 %t126, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t125, i64 %t126)
  %t132 = getelementptr i8, ptr %t131, i64 %t126
  call void @olang_textcopy(ptr %t132, ptr %t128, i64 %t129)
  %t133 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t131, 1
  %t136 = getelementptr %"std/os:Output", ptr %l9, i32 0, i32 0
  %t137 = load i32, ptr %t136, !tbaa !23
  %t139 = icmp ne i32 %t137, 0
  %t142 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s5, ptr %v4, { i64, ptr } %t134, i1 %t139)
  store { i64, ptr } %t142, ptr %l72
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t143 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t143, ptr %rv
  br label %ret
bb37:
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t146 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t144, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t146, ptr %l74
  br label %bb38
bb38:
  %t147 = load i1, ptr %l74, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb39, label %bb40
bb39:
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t150, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t152, ptr %l78
  br label %bb41
bb40:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb42
bb41:
  %t153 = load i1, ptr %l78, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l76, !tbaa !21
  br label %bb42
bb42:
  %t156 = load i1, ptr %l76, !tbaa !21
  br i1 %t156, label %bb43, label %bb44
bb43:
  %t157 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t157, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t159, ptr %l82
  br label %bb45
bb44:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb46
bb45:
  %t160 = load i1, ptr %l82, !tbaa !21
  %t161 = xor i1 %t160, true
  store i1 %t161, ptr %l80, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l80, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t164, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t166, ptr %l86
  br label %bb49
bb48:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb50
bb49:
  %t167 = load i1, ptr %l86, !tbaa !21
  %t168 = xor i1 %t167, true
  store i1 %t168, ptr %l84, !tbaa !21
  br label %bb50
bb50:
  %t170 = load i1, ptr %l84, !tbaa !21
  br i1 %t170, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t172 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t175 = extractvalue { i64, ptr } %t171, 1
  %t176 = extractvalue { i64, ptr } %t171, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t172, i64 %t173)
  %t179 = getelementptr i8, ptr %t178, i64 %t173
  call void @olang_textcopy(ptr %t179, ptr %t175, i64 %t176)
  %t180 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t178, 1
  %t184 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %s8, ptr %v4, { i64, ptr } %t181)
  store { i64, ptr } %t184, ptr %l91
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t185 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t185, ptr %rv
  br label %ret
bb54:
  %t186 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t188, ptr %l93
  br label %bb55
bb55:
  %t189 = load i1, ptr %l93, !tbaa !21
  br i1 %t189, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t190 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = extractvalue { i64, ptr } %t190, 0
  %t194 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t192, i64 %t193)
  %t198 = getelementptr i8, ptr %t197, i64 %t193
  call void @olang_textcopy(ptr %t198, ptr %t194, i64 %t195)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t197, 1
  %t203 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %s10, ptr %v4, { i64, ptr } %t200)
  store { i64, ptr } %t203, ptr %l97
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t204 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t204, ptr %rv
  br label %ret
bb59:
  %t205 = load ptr, ptr %l1, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t209 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t205, { i64, ptr } %t206)
  %t210 = extractvalue { i32, ptr } %t209, 1
  %t211 = extractvalue { i32, ptr } %t209, 0
  store i32 %t211, ptr %l103
  %t212 = icmp ne i32 %t211, 0
  br i1 %t212, label %bb61, label %ok.213, !prof !99
ok.213:
  store ptr %t210, ptr %l102
  br label %bb60
bb60:
  %t214 = load ptr, ptr %l102, !tbaa !29
  store ptr %t214, ptr %l98, !tbaa !29
  br label %bb65
bb61:
  %t215 = load i32, ptr %l103, !tbaa !23
  %t216 = ashr i32 %t215, 16
  %t218 = icmp eq i32 %t216, 1
  store i1 %t218, ptr %l105, !tbaa !21
  %t219 = load i32, ptr %l103, !tbaa !23
  %t220 = ashr i32 %t219, 16
  %t222 = icmp eq i32 %t220, 1
  br i1 %t222, label %bb62, label %bb63
bb62:
  call void @__olang_errpay_pop()
  br label %bb63
bb63:
  br label %bb64
bb64:
  store { i64, [2 x i64] } zeroinitializer, ptr %t224
  %t225 = getelementptr { i64, [2 x i64] }, ptr %t224, i32 0, i32 0
  store i64 0, ptr %t225
  %t226 = load { i64, [2 x i64] }, ptr %t224
  %t228 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t226, ptr %t228
  store ptr %t228, ptr %l98, !tbaa !29
  br label %bb65
bb65:
  %t230 = load ptr, ptr %l98, !tbaa !29
  store ptr %t230, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t231 = load ptr, ptr %l110, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb66, label %bb67
bb66:
  %t234 = load ptr, ptr %l110, !tbaa !29
  %t235 = load i64, ptr %t234, !range !{i64 0, i64 8}
  %t237 = icmp eq i64 %t235, 0
  store i1 %t237, ptr %l111, !tbaa !21
  br label %bb67
bb67:
  %t238 = load i1, ptr %l111, !tbaa !21
  %t239 = xor i1 %t238, true
  store i1 %t239, ptr %l10, !tbaa !21
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %s0, ptr %v1, ptr %t241, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store { i64, ptr } %t243, ptr %l116
  br label %bb68
bb68:
  %t244 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t244, ptr %l11, !tbaa !27
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %s0, ptr %v1, ptr %t245, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store { i64, ptr } %t247, ptr %l118
  br label %bb69
bb69:
  %t248 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t251 = load i1, ptr %l10, !tbaa !21
  %t252 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t255 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t256 = ptrtoint ptr %t255 to i64
  %t258 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 0
  store { i64, ptr } %t249, ptr %t258, !tbaa !28
  %t260 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 1
  store { i64, ptr } %t250, ptr %t260, !tbaa !28
  %t262 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 2
  store i1 %t251, ptr %t262, !tbaa !28
  %t264 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 3
  store { i64, ptr } %t252, ptr %t264, !tbaa !28
  %t266 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 4
  store { i64, ptr } %t248, ptr %t266, !tbaa !28
  %t268 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 5
  store ptr %a2, ptr %t268, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t270 = call ptr @__olang_scope_hold(ptr %v0)
  %t271 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 6
  store ptr %t270, ptr %t271, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t272 = call ptr @__olang_scope_hold(ptr %v1)
  %t273 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 7
  store ptr %t272, ptr %t273, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t274 = call ptr @__olang_scope_hold(ptr %v1)
  %t275 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 8
  store ptr %t274, ptr %t275, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t276 = call ptr @__olang_scope_hold(ptr %v1)
  %t277 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 9
  store ptr %t276, ptr %t277, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t278 = call ptr @__olang_scope_hold(ptr %v2)
  %t279 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t257, i32 0, i32 10
  store ptr %t278, ptr %t279, !tbaa !28
  %t280 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_23, 0
  %t281 = insertvalue { ptr, ptr } %t280, ptr %t257, 1
  %t283 = extractvalue { ptr, ptr } %t281, 0
  %t284 = extractvalue { ptr, ptr } %t281, 1
  %t285 = call { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %s0, ptr %v4, ptr %t283, ptr %t284)
  store { { i64, ptr }, i32 } %t285, ptr %l126
  br label %bb70
bb70:
  %t286 = load { { i64, ptr }, i32 }, ptr %l126
  store { { i64, ptr }, i32 } %t286, ptr %l13
  %t287 = getelementptr { { i64, ptr }, i32 }, ptr %l13, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l127, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  store i64 %t290, ptr %l128, !tbaa !24
  %t291 = load i64, ptr %l128, !tbaa !24
  %t292 = mul i64 %t291, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  store { i64, ptr } %t295, ptr %l129, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = load i64, ptr %l128, !tbaa !24
  %t301 = mul i64 %t300, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t297, ptr %t299, i64 %t301, i1 false)
  %t302 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t302, ptr %l14, !tbaa !27
  %t303 = getelementptr { { i64, ptr }, i32 }, ptr %l13, i32 0, i32 1
  %t304 = load i32, ptr %t303, !tbaa !23
  store i32 %t304, ptr %l15, !tbaa !23
  %t306 = load i32, ptr %l15, !tbaa !23
  %t308 = icmp ne i32 %t306, 0
  br i1 %t308, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t310 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t311 = load i32, ptr %l15, !tbaa !23
  %t312 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t315 = extractvalue { i64, ptr } %t310, 1
  %t316 = extractvalue { i64, ptr } %t310, 0
  %t317 = add i64 %t313, %t316
  %t318 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t320 = add i64 %t317, %t319
  %t322 = sext i32 %t311 to i64
  %t323 = call i64 @__olang_fmt_i64(ptr null, i64 %t322)
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t328 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t327)
  call void @olang_textcopy(ptr %t328, ptr %t312, i64 %t313)
  %t329 = getelementptr i8, ptr %t328, i64 %t313
  call void @olang_textcopy(ptr %t329, ptr %t315, i64 %t316)
  %t330 = getelementptr i8, ptr %t329, i64 %t316
  call void @olang_textcopy(ptr %t330, ptr %t318, i64 %t319)
  %t331 = getelementptr i8, ptr %t330, i64 %t319
  %t332 = call i64 @__olang_fmt_i64(ptr %t331, i64 %t322)
  %t333 = getelementptr i8, ptr %t331, i64 %t323
  call void @olang_textcopy(ptr %t333, ptr %t325, i64 %t326)
  %t334 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t328, 1
  %t338 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %s12, ptr %v4, { i64, ptr } %t335)
  store { i64, ptr } %t338, ptr %l137
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t339 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t339, ptr %rv
  br label %ret
bb74:
  %t340 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t340, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2echeckResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/diag:Item"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"compiler/diag:Item"
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca %"compiler/diag:Item"
  %l71 = alloca i64
  %l75 = alloca i64
  %l78 = alloca i64
  %l98 = alloca %"compiler/diag:Item"
  %l126 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l133 = alloca %"std/prelude/text:StringBuilder"
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v1, ptr %s0, ptr %t1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l24
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l24
  store %"std/prelude/text:StringBuilder" %t6, ptr %l3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb3
bb3:
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %l2)
  store i64 %t9, ptr %l27
  br label %bb4
bb4:
  %t10 = load i64, ptr %l27, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l34, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l34, !tbaa !24
  store i64 %t37, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l31, !tbaa !24
  store i64 %t38, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t60 = call %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %s0, ptr %l2, i64 %t57)
  store %"compiler/diag:Item" %t60, ptr %l54
  br label %bb15
bb15:
  %t61 = load %"compiler/diag:Item", ptr %l54
  store %"compiler/diag:Item" %t61, ptr %l11
  %t62 = getelementptr %"compiler/diag:Item", ptr %l11, i32 0, i32 0
  %t63 = load i1, ptr %t62, !tbaa !21
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb19, label %bb20
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 44)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l4, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fmcp_2elocated(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t77, ptr %t78, ptr %l11)
  br label %bb23
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l3, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb24
bb24:
  store i64 0, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l10, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l13, !tbaa !24
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %l2)
  store i64 %t89, ptr %l71
  br label %bb25
bb25:
  %t90 = load i64, ptr %l71, !tbaa !24
  store i64 %t90, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t91 = load i64, ptr %l14, !tbaa !24
  %t92 = load i64, ptr %l13, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb26, label %bb27
bb26:
  %t97 = load i64, ptr %l15, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb31
bb28:
  %t101 = load i64, ptr %l14, !tbaa !24
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l15, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l15, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l78, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb30
bb30:
  %t117 = load i64, ptr %l78, !tbaa !24
  store i64 %t117, ptr %l75, !tbaa !24
  br label %bb31
bb31:
  %t118 = load i64, ptr %l75, !tbaa !24
  store i64 %t118, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb32
bb32:
  %t119 = load i64, ptr %l17, !tbaa !24
  %t120 = load i64, ptr %l16, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb33, label %bb34
bb33:
  br label %bb51
bb34:
  br label %bb35
bb35:
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l17, !tbaa !24
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  %t140 = call %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %s0, ptr %l2, i64 %t135)
  store %"compiler/diag:Item" %t140, ptr %l98
  br label %bb36
bb36:
  %t141 = load %"compiler/diag:Item", ptr %l98
  store %"compiler/diag:Item" %t141, ptr %l19
  %t142 = getelementptr %"compiler/diag:Item", ptr %l19, i32 0, i32 0
  %t143 = load i1, ptr %t142, !tbaa !21
  br i1 %t143, label %bb37, label %bb38
bb37:
  br label %bb51
bb38:
  br label %bb39
bb39:
  %t145 = load i64, ptr %l12, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb40, label %bb41
bb40:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 44)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = add i64 %t150, 1
  store i64 %t153, ptr %l12, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fmcp_2elocated(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t155, ptr %t156, ptr %l19)
  br label %bb44
bb44:
  %t161 = getelementptr %"compiler/diag:Item", ptr %l19, i32 0, i32 7
  %t162 = load i1, ptr %t161, !tbaa !21
  br i1 %t162, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l3, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb48:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 125)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t166 = load i64, ptr %l17, !tbaa !24
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %l17, !tbaa !24
  br label %bb32
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb53:
  %t172 = load i64, ptr %l9, !tbaa !24
  %t175 = add i64 %t172, 1
  store i64 %t175, ptr %l9, !tbaa !24
  br label %bb11
bb54:
  %t177 = load i64, ptr %l4, !tbaa !24
  %t178 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t181 = call i64 @__olang_fmt_i64(ptr null, i64 %t177)
  %t182 = add i64 %t179, %t181
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t178, i64 %t179)
  %t187 = getelementptr i8, ptr %t186, i64 %t179
  %t188 = call i64 @__olang_fmt_i64(ptr %t187, i64 %t177)
  %t189 = getelementptr i8, ptr %t187, i64 %t181
  call void @olang_textcopy(ptr %t189, ptr %t183, i64 %t184)
  %t190 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t186, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t191)
  br label %bb55
bb55:
  %t195 = load i64, ptr %l4, !tbaa !24
  %t197 = icmp eq i64 %t195, 0
  br i1 %t197, label %bb56, label %bb57
bb56:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l126, !tbaa !27
  br label %bb60
bb57:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v1, ptr %s0, ptr %t199)
  store { i64, ptr } %t201, ptr %l128
  br label %bb58
bb58:
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v1, ptr %s0, ptr %t202)
  store { i64, ptr } %t204, ptr %l130
  br label %bb59
bb59:
  %t205 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = add i64 %t207, %t210
  %t212 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t211)
  call void @olang_textcopy(ptr %t212, ptr %t206, i64 %t207)
  %t213 = getelementptr i8, ptr %t212, i64 %t207
  call void @olang_textcopy(ptr %t213, ptr %t209, i64 %t210)
  %t214 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t212, 1
  store { i64, ptr } %t215, ptr %l126, !tbaa !27
  br label %bb60
bb60:
  %t218 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t218, ptr %l20, !tbaa !27
  %t219 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t219, ptr %l133
  br label %bb61
bb61:
  %t220 = load %"std/prelude/text:StringBuilder", ptr %l133
  store %"std/prelude/text:StringBuilder" %t220, ptr %l21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb62
bb62:
  %t222 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } %t222)
  br label %bb63
bb63:
  store ptr %l21, ptr %l137, !tbaa !29
  %t226 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t226, ptr %l139
  br label %bb64
bb64:
  %t227 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t229 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = add i64 %t228, %t231
  %t233 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t227, i64 %t228)
  %t237 = getelementptr i8, ptr %t236, i64 %t228
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = getelementptr i8, ptr %t237, i64 %t231
  call void @olang_textcopy(ptr %t238, ptr %t233, i64 %t234)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t236, 1
  %t242 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t242, { i64, ptr } %t240)
  br label %bb65
bb65:
  %t245 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l21)
  store { i64, ptr } %t245, ptr %l143
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t246 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t246, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t16 = add i64 %t13, %t15
  %t17 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t5, i64 %t6)
  %t21 = getelementptr i8, ptr %t20, i64 %t6
  call void @olang_textcopy(ptr %t21, ptr %t8, i64 %t9)
  %t22 = getelementptr i8, ptr %t21, i64 %t9
  call void @olang_textcopy(ptr %t22, ptr %t11, i64 %t12)
  %t23 = getelementptr i8, ptr %t22, i64 %t12
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a1)
  %t25 = getelementptr i8, ptr %t23, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t17, i64 %t18)
  %t26 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t20, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t27)
  br label %bb2
bb2:
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v1, ptr %l3, { i64, ptr } %a2)
  br label %bb3
bb3:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb4
bb4:
  %t36 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t36, ptr %l14
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2ehandle(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i32
  %l34 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i32
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l49 = alloca i1
  %l52 = alloca %"std/prelude/text:StringBuilder"
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca { i64, ptr }
  %l77 = alloca i1
  %l82 = alloca { i64, ptr }
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l92 = alloca i32
  %l94 = alloca i1
  %l98 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l101 = alloca i32
  %l103 = alloca i1
  %l106 = alloca { i64, ptr }
  %l107 = alloca i32
  %l109 = alloca i1
  %l112 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca i32
  %l120 = alloca i1
  %l124 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i32
  %l129 = alloca i1
  %l134 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t257 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v0, ptr %s0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l13
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  store ptr %t8, ptr %l10, !tbaa !29
  br label %bb8
bb2:
  %t9 = load i32, ptr %l13, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l15, !tbaa !21
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = call { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, i64 -32700, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store { i64, ptr } %t18, ptr %l18
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2fmcp_2esend(ptr %s1, { i64, ptr } %t19)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t21 = load ptr, ptr %l10, !tbaa !29
  store ptr %t21, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %s0, ptr %s0, ptr %s0, ptr %t22, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store { i64, ptr } %t24, ptr %l21
  br label %bb9
bb9:
  %t25 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2fmcp_2eidOf(ptr %s0, ptr %s0, ptr %t26)
  store { i64, ptr } %t28, ptr %l23
  br label %bb10
bb10:
  %t29 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t32, ptr %l25
  br label %bb11
bb11:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t39 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t34, { i64, ptr } %t36)
  %t40 = extractvalue { i32, ptr } %t39, 1
  %t41 = extractvalue { i32, ptr } %t39, 0
  store i32 %t41, ptr %l32
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb15, label %ok.43, !prof !99
ok.43:
  store ptr %t40, ptr %l31
  br label %bb14
bb13:
  br label %bb37
bb14:
  %t44 = load ptr, ptr %l31, !tbaa !29
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t48 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s2, ptr %t44, { i64, ptr } %t45)
  %t49 = extractvalue { i32, ptr } %t48, 1
  %t50 = extractvalue { i32, ptr } %t48, 0
  store i32 %t50, ptr %l41
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb20, label %ok.52, !prof !99
ok.52:
  store ptr %t49, ptr %l40
  br label %bb19
bb15:
  %t53 = load i32, ptr %l32, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  store i1 %t56, ptr %l34, !tbaa !21
  %t57 = load i32, ptr %l32, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  br i1 %t60, label %bb16, label %bb17
bb16:
  call void @__olang_errpay_pop()
  br label %bb17
bb17:
  br label %bb18
bb18:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb27
bb19:
  %t62 = load ptr, ptr %l40, !tbaa !29
  %t63 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s2, ptr %s2, ptr %t62)
  %t64 = extractvalue { i32, { i64, ptr } } %t63, 1
  %t65 = extractvalue { i32, { i64, ptr } } %t63, 0
  store i32 %t65, ptr %l47
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb24, label %ok.67, !prof !99
ok.67:
  store { i64, ptr } %t64, ptr %l46
  br label %bb23
bb20:
  %t68 = load i32, ptr %l41, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 1
  store i1 %t71, ptr %l43, !tbaa !21
  %t72 = load i32, ptr %l41, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb21, label %bb22
bb21:
  call void @__olang_errpay_pop()
  br label %bb22
bb22:
  br label %bb18
bb23:
  %t77 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t77, ptr %l26, !tbaa !27
  br label %bb27
bb24:
  %t78 = load i32, ptr %l47, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  store i1 %t81, ptr %l49, !tbaa !21
  %t82 = load i32, ptr %l47, !tbaa !23
  %t83 = ashr i32 %t82, 16
  %t85 = icmp eq i32 %t83, 1
  br i1 %t85, label %bb25, label %bb26
bb25:
  call void @__olang_errpay_pop()
  br label %bb26
bb26:
  br label %bb18
bb27:
  %t87 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t87, ptr %l6, !tbaa !27
  %t88 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t88, ptr %l52
  br label %bb28
bb28:
  %t89 = load %"std/prelude/text:StringBuilder", ptr %l52
  store %"std/prelude/text:StringBuilder" %t89, ptr %l7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb29
bb29:
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } %t91)
  br label %bb30
bb30:
  %t94 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t96 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t94, i64 %t95)
  %t100 = getelementptr i8, ptr %t99, i64 %t95
  call void @olang_textcopy(ptr %t100, ptr %t96, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } %t102)
  br label %bb31
bb31:
  %t106 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t108 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t111 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t106, i64 %t107)
  %t115 = getelementptr i8, ptr %t114, i64 %t107
  call void @olang_textcopy(ptr %t115, ptr %t108, i64 %t109)
  %t116 = getelementptr i8, ptr %t115, i64 %t109
  call void @olang_textcopy(ptr %t116, ptr %t111, i64 %t112)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t114, 1
  call void @compiler_2fsession_2eJsonStr(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } %t118)
  br label %bb32
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %l7, i8 125)
  br label %bb33
bb33:
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t125 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l7)
  store { i64, ptr } %t125, ptr %l65
  br label %bb34
bb34:
  %t126 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t129 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t127, { i64, ptr } %t126)
  store { i64, ptr } %t129, ptr %l67
  br label %bb35
bb35:
  %t130 = load { i64, ptr }, ptr %l67, !tbaa !27
  call void @compiler_2fmcp_2esend(ptr %s2, { i64, ptr } %t130)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  %t132 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t132, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t134, ptr %l70
  br label %bb38
bb38:
  %t135 = load i1, ptr %l70, !tbaa !21
  br i1 %t135, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb40:
  br label %bb41
bb41:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t136, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t138, ptr %l72
  br label %bb42
bb42:
  %t139 = load i1, ptr %l72, !tbaa !21
  br i1 %t139, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t142 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s6, ptr %s6, { i64, ptr } %t140, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store { i64, ptr } %t142, ptr %l74
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t143 = load { i64, ptr }, ptr %l74, !tbaa !27
  call void @compiler_2fmcp_2esend(ptr %s6, { i64, ptr } %t143)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb47:
  %t145 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t145, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t147, ptr %l77
  br label %bb48
bb48:
  %t148 = load i1, ptr %l77, !tbaa !21
  br i1 %t148, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = load { i64, ptr }, ptr @G_2ecompiler_2fmcp_2eTools, !tbaa !27
  %t151 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t154 = extractvalue { i64, ptr } %t150, 1
  %t155 = extractvalue { i64, ptr } %t150, 0
  %t156 = add i64 %t152, %t155
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t151, i64 %t152)
  %t161 = getelementptr i8, ptr %t160, i64 %t152
  call void @olang_textcopy(ptr %t161, ptr %t154, i64 %t155)
  %t162 = getelementptr i8, ptr %t161, i64 %t155
  call void @olang_textcopy(ptr %t162, ptr %t157, i64 %t158)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t160, 1
  %t168 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s7, ptr %s7, { i64, ptr } %t149, { i64, ptr } %t164)
  store { i64, ptr } %t168, ptr %l82
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t169 = load { i64, ptr }, ptr %l82, !tbaa !27
  call void @compiler_2fmcp_2esend(ptr %s7, { i64, ptr } %t169)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  %t171 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t171, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t173, ptr %l85
  br label %bb54
bb54:
  %t174 = load i1, ptr %l85, !tbaa !21
  br i1 %t174, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t175 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l89, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t180 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t175, { i64, ptr } %t177)
  %t181 = extractvalue { i32, ptr } %t180, 1
  %t182 = extractvalue { i32, ptr } %t180, 0
  store i32 %t182, ptr %l92
  %t183 = icmp ne i32 %t182, 0
  br i1 %t183, label %bb58, label %ok.184, !prof !99
ok.184:
  store ptr %t181, ptr %l91
  br label %bb57
bb56:
  br label %bb84
bb57:
  %t185 = load ptr, ptr %l91, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l98, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t189 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s9, ptr %t185, { i64, ptr } %t186)
  %t190 = extractvalue { i32, ptr } %t189, 1
  %t191 = extractvalue { i32, ptr } %t189, 0
  store i32 %t191, ptr %l101
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb63, label %ok.193, !prof !99
ok.193:
  store ptr %t190, ptr %l100
  br label %bb62
bb58:
  %t194 = load i32, ptr %l92, !tbaa !23
  %t195 = ashr i32 %t194, 16
  %t197 = icmp eq i32 %t195, 1
  store i1 %t197, ptr %l94, !tbaa !21
  %t198 = load i32, ptr %l92, !tbaa !23
  %t199 = ashr i32 %t198, 16
  %t201 = icmp eq i32 %t199, 1
  br i1 %t201, label %bb59, label %bb60
bb59:
  call void @__olang_errpay_pop()
  br label %bb60
bb60:
  br label %bb61
bb61:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb70
bb62:
  %t203 = load ptr, ptr %l100, !tbaa !29
  %t204 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s9, ptr %s9, ptr %t203)
  %t205 = extractvalue { i32, { i64, ptr } } %t204, 1
  %t206 = extractvalue { i32, { i64, ptr } } %t204, 0
  store i32 %t206, ptr %l107
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb67, label %ok.208, !prof !99
ok.208:
  store { i64, ptr } %t205, ptr %l106
  br label %bb66
bb63:
  %t209 = load i32, ptr %l101, !tbaa !23
  %t210 = ashr i32 %t209, 16
  %t212 = icmp eq i32 %t210, 1
  store i1 %t212, ptr %l103, !tbaa !21
  %t213 = load i32, ptr %l101, !tbaa !23
  %t214 = ashr i32 %t213, 16
  %t216 = icmp eq i32 %t214, 1
  br i1 %t216, label %bb64, label %bb65
bb64:
  call void @__olang_errpay_pop()
  br label %bb65
bb65:
  br label %bb61
bb66:
  %t218 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t218, ptr %l86, !tbaa !27
  br label %bb70
bb67:
  %t219 = load i32, ptr %l107, !tbaa !23
  %t220 = ashr i32 %t219, 16
  %t222 = icmp eq i32 %t220, 1
  store i1 %t222, ptr %l109, !tbaa !21
  %t223 = load i32, ptr %l107, !tbaa !23
  %t224 = ashr i32 %t223, 16
  %t226 = icmp eq i32 %t224, 1
  br i1 %t226, label %bb68, label %bb69
bb68:
  call void @__olang_errpay_pop()
  br label %bb69
bb69:
  br label %bb61
bb70:
  %t228 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t228, ptr %l8, !tbaa !27
  %t229 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l115, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t234 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t229, { i64, ptr } %t231)
  %t235 = extractvalue { i32, ptr } %t234, 1
  %t236 = extractvalue { i32, ptr } %t234, 0
  store i32 %t236, ptr %l118
  %t237 = icmp ne i32 %t236, 0
  br i1 %t237, label %bb72, label %ok.238, !prof !99
ok.238:
  store ptr %t235, ptr %l117
  br label %bb71
bb71:
  %t239 = load ptr, ptr %l117, !tbaa !29
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t243 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t239, { i64, ptr } %t240)
  %t244 = extractvalue { i32, ptr } %t243, 1
  %t245 = extractvalue { i32, ptr } %t243, 0
  store i32 %t245, ptr %l127
  %t246 = icmp ne i32 %t245, 0
  br i1 %t246, label %bb77, label %ok.247, !prof !99
ok.247:
  store ptr %t244, ptr %l126
  br label %bb76
bb72:
  %t248 = load i32, ptr %l118, !tbaa !23
  %t249 = ashr i32 %t248, 16
  %t251 = icmp eq i32 %t249, 1
  store i1 %t251, ptr %l120, !tbaa !21
  %t252 = load i32, ptr %l118, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  br i1 %t255, label %bb73, label %bb74
bb73:
  call void @__olang_errpay_pop()
  br label %bb74
bb74:
  br label %bb75
bb75:
  store { i64, [2 x i64] } zeroinitializer, ptr %t257
  %t258 = getelementptr { i64, [2 x i64] }, ptr %t257, i32 0, i32 0
  store i64 0, ptr %t258
  %t259 = load { i64, [2 x i64] }, ptr %t257
  %t261 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t259, ptr %t261
  store ptr %t261, ptr %l112, !tbaa !29
  br label %bb80
bb76:
  %t263 = load ptr, ptr %l126, !tbaa !29
  store ptr %t263, ptr %l112, !tbaa !29
  br label %bb80
bb77:
  %t264 = load i32, ptr %l127, !tbaa !23
  %t265 = ashr i32 %t264, 16
  %t267 = icmp eq i32 %t265, 1
  store i1 %t267, ptr %l129, !tbaa !21
  %t268 = load i32, ptr %l127, !tbaa !23
  %t269 = ashr i32 %t268, 16
  %t271 = icmp eq i32 %t269, 1
  br i1 %t271, label %bb78, label %bb79
bb78:
  call void @__olang_errpay_pop()
  br label %bb79
bb79:
  br label %bb75
bb80:
  %t273 = load ptr, ptr %l112, !tbaa !29
  %t274 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t274, ptr %l134, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t283 = call { i64, ptr } @compiler_2fmcp_2ecall(ptr %s9, ptr %s0, ptr %v1, ptr %v2, ptr %s9, { i64, ptr } %t275, ptr %t273, ptr %a1, { i64, ptr } %a2)
  store { i64, ptr } %t283, ptr %l139
  br label %bb81
bb81:
  %t284 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t287 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s9, ptr %s9, { i64, ptr } %t285, { i64, ptr } %t284)
  store { i64, ptr } %t287, ptr %l141
  br label %bb82
bb82:
  %t288 = load { i64, ptr }, ptr %l141, !tbaa !27
  call void @compiler_2fmcp_2esend(ptr %s9, { i64, ptr } %t288)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb84:
  %t290 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t291 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t292 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t295 = extractvalue { i64, ptr } %t291, 1
  %t296 = extractvalue { i64, ptr } %t291, 0
  %t297 = add i64 %t293, %t296
  %t298 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t297)
  call void @olang_textcopy(ptr %t298, ptr %t292, i64 %t293)
  %t299 = getelementptr i8, ptr %t298, i64 %t293
  call void @olang_textcopy(ptr %t299, ptr %t295, i64 %t296)
  %t300 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t298, 1
  %t305 = call { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t290, i64 -32601, { i64, ptr } %t301)
  store { i64, ptr } %t305, ptr %l147
  br label %bb85
bb85:
  %t306 = load { i64, ptr }, ptr %l147, !tbaa !27
  call void @compiler_2fmcp_2esend(ptr %s0, { i64, ptr } %t306)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2eidOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v0, ptr %a0, { i64, ptr } %t2)
  %t6 = extractvalue { i32, ptr } %t5, 1
  %t7 = extractvalue { i32, ptr } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store ptr %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  br label %bb6
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l9, !tbaa !21
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l13, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = mul i64 %t23, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t34, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t35 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t35, ptr %rv
  br label %ret
bb6:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t40 = call { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %s0, ptr %v1, ptr %t36, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, i32 0)
  store { i64, ptr } %t40, ptr %l18
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t41, ptr %l19, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l20, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = mul i64 %t44, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l21, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = mul i64 %t53, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t55, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/session:Positions"
  %l5 = alloca { i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l12 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/session:Positions"
  %l33 = alloca { i64, i64 }
  %l36 = alloca ptr
  %l42 = alloca i64
  %l47 = alloca { i64, i64 }
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l12, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/diag:Item", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/diag:Item", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v2, ptr %s0, ptr %t11, i64 %t15)
  store { i64, ptr } %t18, ptr %l20
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb5
bb4:
  %t19 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %s0, ptr %t21, { i64, ptr } %t22)
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/diag:Item", ptr %t23, i32 0, i32 3
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/diag:Item", ptr %t31, i32 0, i32 2
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v2, ptr %v2, ptr %t30, i64 %t34)
  store { i64, ptr } %t37, ptr %l28
  br label %bb9
bb8:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/diag:Item", ptr %t38, i32 0, i32 5
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb17, label %bb18
bb9:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t46 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v2, ptr %s1, { i64, ptr } %t45, i1 true)
  store %"compiler/session:Positions" %t46, ptr %l29
  br label %bb10
bb10:
  %t47 = load %"compiler/session:Positions", ptr %l29
  store %"compiler/session:Positions" %t47, ptr %l4
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t50 = getelementptr %"compiler/diag:Item", ptr %t48, i32 0, i32 3
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %s1, ptr %l4, i64 %t51)
  store { i64, i64 } %t54, ptr %l33
  br label %bb11
bb11:
  %t55 = load { i64, i64 }, ptr %l33
  store { i64, i64 } %t55, ptr %l5
  %t56 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  %t59 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  store i64 %t60, ptr %l7, !tbaa !24
  store ptr %l4, ptr %l36, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/diag:Item", ptr %t62, i32 0, i32 4
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/diag:Item", ptr %t66, i32 0, i32 3
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = icmp sgt i64 %t65, %t69
  br i1 %t72, label %bb12, label %bb13
bb12:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/diag:Item", ptr %t74, i32 0, i32 4
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l42, !tbaa !24
  br label %bb14
bb13:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/diag:Item", ptr %t79, i32 0, i32 3
  %t82 = load i64, ptr %t81, !tbaa !24
  store i64 %t82, ptr %l42, !tbaa !24
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l36, !tbaa !29
  %t85 = load i64, ptr %l42, !tbaa !24
  %t86 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %s1, ptr %t84, i64 %t85)
  store { i64, i64 } %t86, ptr %l47
  br label %bb15
bb15:
  %t87 = load { i64, i64 }, ptr %l47
  store { i64, i64 } %t87, ptr %l8
  %t88 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = add i64 %t95, 1
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  %t103 = add i64 %t89, 1
  %t106 = add i64 %t92, 1
  %t107 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t110 = call i64 @__olang_fmt_i64(ptr null, i64 %t97)
  %t111 = add i64 %t108, %t110
  %t112 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t100)
  %t117 = add i64 %t114, %t116
  %t118 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t106)
  %t129 = add i64 %t126, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t107, i64 %t108)
  %t131 = getelementptr i8, ptr %t130, i64 %t108
  %t132 = call i64 @__olang_fmt_i64(ptr %t131, i64 %t97)
  %t133 = getelementptr i8, ptr %t131, i64 %t110
  call void @olang_textcopy(ptr %t133, ptr %t112, i64 %t113)
  %t134 = getelementptr i8, ptr %t133, i64 %t113
  %t135 = call i64 @__olang_fmt_i64(ptr %t134, i64 %t100)
  %t136 = getelementptr i8, ptr %t134, i64 %t116
  call void @olang_textcopy(ptr %t136, ptr %t118, i64 %t119)
  %t137 = getelementptr i8, ptr %t136, i64 %t119
  %t138 = call i64 @__olang_fmt_i64(ptr %t137, i64 %t103)
  %t139 = getelementptr i8, ptr %t137, i64 %t122
  call void @olang_textcopy(ptr %t139, ptr %t124, i64 %t125)
  %t140 = getelementptr i8, ptr %t139, i64 %t125
  %t141 = call i64 @__olang_fmt_i64(ptr %t140, i64 %t106)
  %t142 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t130, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t94, { i64, ptr } %t143)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/diag:Item", ptr %t148, i32 0, i32 5
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t155 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t152, i64 %t153)
  %t158 = getelementptr i8, ptr %t157, i64 %t153
  %t159 = call i64 @__olang_fmt_i64(ptr %t158, i64 %t151)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t157, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t147, { i64, ptr } %t161)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/diag:Item", ptr %t165, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t168, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t170, ptr %l71
  br label %bb22
bb22:
  %t171 = load i1, ptr %l71, !tbaa !21
  %t172 = xor i1 %t171, true
  br i1 %t172, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t174 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t174, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d78, i32 0, i32 1) })
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l3, !tbaa !29
  %t179 = getelementptr %"compiler/diag:Item", ptr %t177, i32 0, i32 1
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v3, ptr %t176, { i64, ptr } %t180)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t183 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t183, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d79, i32 0, i32 1) })
  br label %bb28
bb28:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l3, !tbaa !29
  %t188 = getelementptr %"compiler/diag:Item", ptr %t186, i32 0, i32 6
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v3, ptr %t185, { i64, ptr } %t189)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2ereply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l22 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i32
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca %"compiler/diag:Diagnostics"
  %l67 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l74 = alloca i1
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l81 = alloca i1
  %l85 = alloca i1
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l108 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca i32
  %l121 = alloca i1
  %l126 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca i1
  %l132 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l142 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l153 = alloca i32
  %l155 = alloca i1
  %l160 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l172 = alloca ptr
  %l181 = alloca %"compiler/doc:Module"
  %l183 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t138 = alloca %"compiler/diag:Diagnostics", align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i1, ptr %l16, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t9, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  %t10 = load i1, ptr %l19, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v1, ptr %s1, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t17 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t18, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t25 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l25
  br label %bb10
bb10:
  %t26 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t26, ptr %l7
  %t27 = load i1, ptr %l2, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store ptr %l7, ptr %l27, !tbaa !29
  %t29 = call ptr @__olang_scope_hold(ptr %s0)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l28, !tbaa !24
  %t31 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t31, label %bb13, label %bb14
bb12:
  br label %bb17
bb13:
  %t33 = call ptr @__olang_region_make(ptr %s0)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l28, !tbaa !24
  br label %bb14
bb14:
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t35, ptr %l30, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = call ptr @__olang_scope_of(ptr %t37, ptr null)
  %t39 = call ptr @__olang_scope_hold(ptr %t38)
  %t40 = ptrtoint ptr %t39 to i64
  %t42 = inttoptr i64 %t40 to ptr
  %t43 = load i64, ptr %l28
  %t44 = inttoptr i64 %t43 to ptr
  %t45 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t46 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %t42, ptr %t44, { i64, ptr } %t45)
  store { i64, ptr } %t46, ptr %l32
  br label %bb15
bb15:
  %t47 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s0, ptr %s0, ptr %v2, ptr %t49, { i64, ptr } %t47, { i64, ptr } %t48)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t52 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store i1 %t54, ptr %l36
  br label %bb18
bb18:
  %t55 = load i1, ptr %l36, !tbaa !21
  br i1 %t55, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i1, ptr %l2, !tbaa !21
  br i1 %t56, label %bb21, label %bb22
bb20:
  br label %bb37
bb21:
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %l38, !tbaa !27
  br label %bb30
bb22:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l41, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = call ptr @__olang_scope_of(ptr %t62, ptr null)
  %t64 = call ptr @__olang_scope_hold(ptr %t63)
  %t65 = ptrtoint ptr %t64 to i64
  %t67 = inttoptr i64 %t65 to ptr
  %t68 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t69 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %t67, ptr %v2, { i64, ptr } %t68)
  %t70 = extractvalue { i32, { i64, ptr } } %t69, 1
  %t71 = extractvalue { i32, { i64, ptr } } %t69, 0
  store i32 %t71, ptr %l44
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb24, label %ok.73, !prof !99
ok.73:
  store { i64, ptr } %t70, ptr %l43
  br label %bb23
bb23:
  %t74 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  br label %bb29
bb24:
  %t75 = load i32, ptr %l44, !tbaa !23
  %t76 = ashr i32 %t75, 16
  %t78 = icmp eq i32 %t76, 1
  store i1 %t78, ptr %l46, !tbaa !21
  %t79 = load i32, ptr %l44, !tbaa !23
  %t80 = ashr i32 %t79, 16
  %t82 = icmp eq i32 %t80, 1
  br i1 %t82, label %bb25, label %bb26
bb25:
  call void @__olang_errpay_pop()
  br label %bb26
bb26:
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t88 = extractvalue { i64, ptr } %t84, 1
  %t89 = extractvalue { i64, ptr } %t84, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t85, i64 %t86)
  %t92 = getelementptr i8, ptr %t91, i64 %t86
  call void @olang_textcopy(ptr %t92, ptr %t88, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  %t97 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %s5, ptr %v5, { i64, ptr } %t94)
  store { i64, ptr } %t97, ptr %l52
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
bb29:
  %t99 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t99, ptr %l38, !tbaa !27
  br label %bb30
bb30:
  %t100 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t101, ptr %l54, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = call ptr @__olang_scope_of(ptr %t104, ptr null)
  %t106 = call ptr @__olang_scope_hold(ptr %t105)
  %t107 = ptrtoint ptr %t106 to i64
  %t109 = inttoptr i64 %t107 to ptr
  %t110 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t112 = call { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %t109, ptr %v2, ptr %s4, { i64, ptr } %t110, { i64, ptr } %t100)
  %t113 = extractvalue { i32, { i64, ptr } } %t112, 1
  %t114 = extractvalue { i32, { i64, ptr } } %t112, 0
  store i32 %t114, ptr %l58
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb32, label %ok.116, !prof !99
ok.116:
  store { i64, ptr } %t113, ptr %l57
  br label %bb31
bb31:
  %t117 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t117, ptr %l53, !tbaa !27
  br label %bb35
bb32:
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t118 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t120, i64 %t121)
  %t126 = getelementptr i8, ptr %t125, i64 %t121
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  %t131 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s7, ptr %v5, { i64, ptr } %t128, i1 true)
  store { i64, ptr } %t131, ptr %l62
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t132 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t132, ptr %rv
  br label %ret
bb35:
  %t133 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t136 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s4, ptr %v5, { i64, ptr } %t133, i1 false)
  store { i64, ptr } %t136, ptr %l64
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
bb37:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t138, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t138, i64 704, i1 false)
  br label %bb38
bb38:
  %t139 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 704, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %l65, i64 704, i1 false)
  store ptr %t139, ptr %l10, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t141, ptr %l67, !tbaa !27
  %t143 = load ptr, ptr %l10, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = call ptr @__olang_scope_of(ptr %t145, ptr null)
  %t147 = call ptr @__olang_scope_hold(ptr %t146)
  %t148 = ptrtoint ptr %t147 to i64
  %t150 = inttoptr i64 %t148 to ptr
  %t151 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t155 = call ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %t150, ptr %v4, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t151, ptr %a5, ptr %t143, ptr %l7, i1 true, i1 true)
  store ptr %t155, ptr %l72
  br label %bb39
bb39:
  %t156 = load ptr, ptr %l72, !tbaa !29
  store ptr %t156, ptr %l11, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t157, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t159, ptr %l74
  br label %bb40
bb40:
  %t160 = load i1, ptr %l74, !tbaa !21
  br i1 %t160, label %bb41, label %bb42
bb41:
  %t161 = load ptr, ptr %l11, !tbaa !29
  %t162 = load ptr, ptr %l10, !tbaa !29
  %t165 = call { i64, ptr } @compiler_2fmcp_2echeckResult(ptr %s0, ptr %s0, ptr %v5, ptr %t161, ptr %t162)
  store { i64, ptr } %t165, ptr %l77
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t166 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t166, ptr %rv
  br label %ret
bb44:
  %t167 = load ptr, ptr %l10, !tbaa !29
  %t169 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %s0, ptr %t167)
  store i64 %t169, ptr %l79
  br label %bb45
bb45:
  %t170 = load i64, ptr %l79, !tbaa !24
  %t171 = icmp sgt i64 %t170, 0
  br i1 %t171, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb48
bb47:
  %t173 = load ptr, ptr %l11, !tbaa !29
  %t175 = getelementptr %"compiler/session:Analysis", ptr %t173, i32 0, i32 2
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = icmp eq ptr %t176, null
  store i1 %t178, ptr %l81, !tbaa !21
  br label %bb48
bb48:
  %t180 = load i1, ptr %l81, !tbaa !21
  br i1 %t180, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb51
bb50:
  %t181 = load ptr, ptr %l11, !tbaa !29
  %t183 = getelementptr %"compiler/session:Analysis", ptr %t181, i32 0, i32 3
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t186 = icmp eq ptr %t184, null
  store i1 %t186, ptr %l85, !tbaa !21
  br label %bb51
bb51:
  %t188 = load i1, ptr %l85, !tbaa !21
  br i1 %t188, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t189 = load ptr, ptr %l10, !tbaa !29
  %t191 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %s10, ptr %t189)
  store { i64, ptr } %t191, ptr %l90
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t192 = load ptr, ptr %l10, !tbaa !29
  %t194 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %s0, ptr %s10, ptr %t192)
  store { i64, ptr } %t194, ptr %l92
  br label %bb55
bb55:
  %t195 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 1
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t201 = add i64 %t197, %t200
  %t202 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t201)
  call void @olang_textcopy(ptr %t202, ptr %t196, i64 %t197)
  %t203 = getelementptr i8, ptr %t202, i64 %t197
  call void @olang_textcopy(ptr %t203, ptr %t199, i64 %t200)
  %t204 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t202, 1
  %t208 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s10, ptr %v5, { i64, ptr } %t205, i1 true)
  store { i64, ptr } %t208, ptr %l95
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t209 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t209, ptr %rv
  br label %ret
bb57:
  %t210 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t210, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t212, ptr %l97
  br label %bb58
bb58:
  %t213 = load i1, ptr %l97, !tbaa !21
  br i1 %t213, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s12
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/session:Analysis", ptr %t214, i32 0, i32 2
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  br i1 %t219, label %bb61, label %bb62
bb60:
  br label %bb76
bb61:
  call void @__olang_check_failed(ptr @olang_loc_308bbd8a0e283fc3_2a8ec4cf6bdf47df)
  unreachable
bb62:
  br label %bb63
bb63:
  %t221 = load ptr, ptr %l11, !tbaa !29
  %t223 = getelementptr %"compiler/session:Analysis", ptr %t221, i32 0, i32 2
  %t224 = load ptr, ptr %t223, !tbaa !29
  store ptr %t224, ptr %l103, !tbaa !29
  %t225 = load ptr, ptr %l11, !tbaa !29
  %t227 = getelementptr %"compiler/session:Analysis", ptr %t225, i32 0, i32 3
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = icmp eq ptr %t228, null
  br i1 %t230, label %bb64, label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_308bbd8a0e283fc3_2a8ec4cf6bdf47df)
  unreachable
bb65:
  br label %bb66
bb66:
  %t232 = load ptr, ptr %l11, !tbaa !29
  %t234 = getelementptr %"compiler/session:Analysis", ptr %t232, i32 0, i32 3
  %t235 = load ptr, ptr %t234, !tbaa !29
  store ptr %t235, ptr %l108, !tbaa !29
  %t236 = load ptr, ptr %l11, !tbaa !29
  %t238 = getelementptr %"compiler/session:Analysis", ptr %t236, i32 0, i32 4
  %t239 = load ptr, ptr %t238, !tbaa !29
  %t241 = icmp eq ptr %t239, null
  br i1 %t241, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_308bbd8a0e283fc3_2a8ec4cf6bdf47df)
  unreachable
bb68:
  br label %bb69
bb69:
  %t243 = load ptr, ptr %l11, !tbaa !29
  %t245 = getelementptr %"compiler/session:Analysis", ptr %t243, i32 0, i32 4
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t247 = load ptr, ptr %l11, !tbaa !29
  %t249 = getelementptr %"compiler/session:Analysis", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/load:Loader", ptr %t250, i32 0, i32 12
  %t253 = load i64, ptr %t252, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t255 = load ptr, ptr %l103, !tbaa !29
  %t256 = load ptr, ptr %l108, !tbaa !29
  %t260 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %s0, ptr %s0, ptr %s0, ptr %v3, ptr %s12, ptr %t255, ptr %t256, ptr %t246, i64 %t253, { i64, ptr } %t254)
  %t261 = extractvalue { i32, { i64, ptr } } %t260, 1
  %t262 = extractvalue { i32, { i64, ptr } } %t260, 0
  store i32 %t262, ptr %l119
  %t263 = icmp ne i32 %t262, 0
  br i1 %t263, label %bb71, label %ok.264, !prof !99
ok.264:
  store { i64, ptr } %t261, ptr %l118
  br label %bb70
bb70:
  %t265 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t265, ptr %l98, !tbaa !27
  br label %bb74
bb71:
  %t266 = load i32, ptr %l119, !tbaa !23
  %t267 = ashr i32 %t266, 16
  %t269 = icmp eq i32 %t267, 1
  store i1 %t269, ptr %l121, !tbaa !21
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s13
  %t270 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t275 = extractvalue { i64, ptr } %t270, 1
  %t276 = extractvalue { i64, ptr } %t270, 0
  %t277 = add i64 %t273, %t276
  %t278 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t280 = add i64 %t277, %t279
  %t282 = extractvalue { i64, ptr } %t271, 1
  %t283 = extractvalue { i64, ptr } %t271, 0
  %t284 = add i64 %t280, %t283
  %t285 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t272, i64 %t273)
  %t286 = getelementptr i8, ptr %t285, i64 %t273
  call void @olang_textcopy(ptr %t286, ptr %t275, i64 %t276)
  %t287 = getelementptr i8, ptr %t286, i64 %t276
  call void @olang_textcopy(ptr %t287, ptr %t278, i64 %t279)
  %t288 = getelementptr i8, ptr %t287, i64 %t279
  call void @olang_textcopy(ptr %t288, ptr %t282, i64 %t283)
  %t289 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t285, 1
  %t293 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s13, ptr %v5, { i64, ptr } %t290, i1 true)
  store { i64, ptr } %t293, ptr %l126
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t294 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t294, ptr %rv
  br label %ret
bb74:
  %t295 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t298 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s12, ptr %v5, { i64, ptr } %t295, i1 false)
  store { i64, ptr } %t298, ptr %l128
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t299 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t299, ptr %rv
  br label %ret
bb76:
  %t300 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t302 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t300, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t302, ptr %l130
  br label %bb77
bb77:
  %t303 = load i1, ptr %l130, !tbaa !21
  %t304 = xor i1 %t303, true
  br i1 %t304, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s15
  %t306 = load ptr, ptr %l11, !tbaa !29
  %t308 = getelementptr %"compiler/session:Analysis", ptr %t306, i32 0, i32 2
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t311 = icmp eq ptr %t309, null
  br i1 %t311, label %bb80, label %bb81
bb79:
  br label %bb95
bb80:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb81:
  br label %bb82
bb82:
  %t313 = load ptr, ptr %l11, !tbaa !29
  %t315 = getelementptr %"compiler/session:Analysis", ptr %t313, i32 0, i32 2
  %t316 = load ptr, ptr %t315, !tbaa !29
  store ptr %t316, ptr %l137, !tbaa !29
  %t317 = load ptr, ptr %l11, !tbaa !29
  %t319 = getelementptr %"compiler/session:Analysis", ptr %t317, i32 0, i32 3
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  br i1 %t322, label %bb83, label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb84:
  br label %bb85
bb85:
  %t324 = load ptr, ptr %l11, !tbaa !29
  %t326 = getelementptr %"compiler/session:Analysis", ptr %t324, i32 0, i32 3
  %t327 = load ptr, ptr %t326, !tbaa !29
  store ptr %t327, ptr %l142, !tbaa !29
  %t328 = load ptr, ptr %l11, !tbaa !29
  %t330 = getelementptr %"compiler/session:Analysis", ptr %t328, i32 0, i32 4
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  br i1 %t333, label %bb86, label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb87:
  br label %bb88
bb88:
  %t335 = load ptr, ptr %l11, !tbaa !29
  %t337 = getelementptr %"compiler/session:Analysis", ptr %t335, i32 0, i32 4
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t339 = load ptr, ptr %l11, !tbaa !29
  %t341 = getelementptr %"compiler/session:Analysis", ptr %t339, i32 0, i32 0
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t344 = getelementptr %"compiler/load:Loader", ptr %t342, i32 0, i32 12
  %t345 = load i64, ptr %t344, !tbaa !24
  %t346 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t347 = load ptr, ptr %l137, !tbaa !29
  %t348 = load ptr, ptr %l142, !tbaa !29
  %t352 = call { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %s0, ptr %s0, ptr %s0, ptr %v3, ptr %s15, ptr %t347, ptr %t348, ptr %t338, i64 %t345, { i64, ptr } %t346)
  %t353 = extractvalue { i32, { i64, ptr } } %t352, 1
  %t354 = extractvalue { i32, { i64, ptr } } %t352, 0
  store i32 %t354, ptr %l153
  %t355 = icmp ne i32 %t354, 0
  br i1 %t355, label %bb90, label %ok.356, !prof !99
ok.356:
  store { i64, ptr } %t353, ptr %l152
  br label %bb89
bb89:
  %t357 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t357, ptr %l132, !tbaa !27
  br label %bb93
bb90:
  %t358 = load i32, ptr %l153, !tbaa !23
  %t359 = ashr i32 %t358, 16
  %t361 = icmp eq i32 %t359, 1
  store i1 %t361, ptr %l155, !tbaa !21
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s16
  %t362 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t363 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t364 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t367 = extractvalue { i64, ptr } %t362, 1
  %t368 = extractvalue { i64, ptr } %t362, 0
  %t369 = add i64 %t365, %t368
  %t370 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t372 = add i64 %t369, %t371
  %t374 = extractvalue { i64, ptr } %t363, 1
  %t375 = extractvalue { i64, ptr } %t363, 0
  %t376 = add i64 %t372, %t375
  %t377 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t376)
  call void @olang_textcopy(ptr %t377, ptr %t364, i64 %t365)
  %t378 = getelementptr i8, ptr %t377, i64 %t365
  call void @olang_textcopy(ptr %t378, ptr %t367, i64 %t368)
  %t379 = getelementptr i8, ptr %t378, i64 %t368
  call void @olang_textcopy(ptr %t379, ptr %t370, i64 %t371)
  %t380 = getelementptr i8, ptr %t379, i64 %t371
  call void @olang_textcopy(ptr %t380, ptr %t374, i64 %t375)
  %t381 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t377, 1
  %t385 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s16, ptr %v5, { i64, ptr } %t382, i1 true)
  store { i64, ptr } %t385, ptr %l160
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t386 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t386, ptr %rv
  br label %ret
bb93:
  %t387 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t390 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s15, ptr %v5, { i64, ptr } %t387, i1 false)
  store { i64, ptr } %t390, ptr %l162
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t391 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t391, ptr %rv
  br label %ret
bb95:
  %t392 = load ptr, ptr %l11, !tbaa !29
  %t394 = getelementptr %"compiler/session:Analysis", ptr %t392, i32 0, i32 2
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t397 = icmp eq ptr %t395, null
  br i1 %t397, label %bb96, label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_bf544a52d5413c29_9c9e72e4a09cc655)
  unreachable
bb97:
  br label %bb98
bb98:
  %t399 = load ptr, ptr %l11, !tbaa !29
  %t401 = getelementptr %"compiler/session:Analysis", ptr %t399, i32 0, i32 2
  %t402 = load ptr, ptr %t401, !tbaa !29
  store ptr %t402, ptr %l167, !tbaa !29
  %t403 = load ptr, ptr %l11, !tbaa !29
  %t405 = getelementptr %"compiler/session:Analysis", ptr %t403, i32 0, i32 3
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = icmp eq ptr %t406, null
  br i1 %t408, label %bb99, label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_bf544a52d5413c29_9c9e72e4a09cc655)
  unreachable
bb100:
  br label %bb101
bb101:
  %t410 = load ptr, ptr %l11, !tbaa !29
  %t412 = getelementptr %"compiler/session:Analysis", ptr %t410, i32 0, i32 3
  %t413 = load ptr, ptr %t412, !tbaa !29
  store ptr %t413, ptr %l172, !tbaa !29
  %t414 = load ptr, ptr %l11, !tbaa !29
  %t416 = getelementptr %"compiler/session:Analysis", ptr %t414, i32 0, i32 4
  %t417 = load ptr, ptr %t416, !tbaa !29
  %t419 = icmp eq ptr %t417, null
  br i1 %t419, label %bb102, label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_bf544a52d5413c29_9c9e72e4a09cc655)
  unreachable
bb103:
  br label %bb104
bb104:
  %t421 = load ptr, ptr %l11, !tbaa !29
  %t423 = getelementptr %"compiler/session:Analysis", ptr %t421, i32 0, i32 4
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t425 = load ptr, ptr %l11, !tbaa !29
  %t427 = getelementptr %"compiler/session:Analysis", ptr %t425, i32 0, i32 0
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t430 = getelementptr %"compiler/load:Loader", ptr %t428, i32 0, i32 12
  %t431 = load i64, ptr %t430, !tbaa !24
  %t432 = load ptr, ptr %l167, !tbaa !29
  %t433 = load ptr, ptr %l172, !tbaa !29
  %t436 = call %"compiler/doc:Module" @compiler_2fdoc_2eModule_2eOf(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t432, ptr %t433, ptr %t424, i64 %t431, i1 false)
  store %"compiler/doc:Module" %t436, ptr %l181
  br label %bb105
bb105:
  %t437 = load %"compiler/doc:Module", ptr %l181
  %t438 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 80, i64 8)
  store %"compiler/doc:Module" %t437, ptr %t438
  %t440 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %s0, ptr %s0, ptr %t438)
  store { i64, ptr } %t440, ptr %l183
  br label %bb106
bb106:
  %t441 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t443 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s0, ptr %v5, { i64, ptr } %t441, i1 false)
  store { i64, ptr } %t443, ptr %l185
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  %t444 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t444, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2esend(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca i32
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = extractvalue { i64, ptr } %t11, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = call i32 @std_2fio_2eWrite(ptr %s0, i32 1, { i64, ptr } %t19)
  store i32 %t21, ptr %l5
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb2, label %ok.23, !prof !99
ok.23:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  store i1 %t27, ptr %l7, !tbaa !21
  %t28 = load i32, ptr %l5, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2etestResult(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca %"std/prelude/text:LineIter"
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l50 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l59 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l72 = alloca %"std/prelude/text:StringBuilder"
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d96, i32 0, i32 1) })
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t4)
  store %"std/prelude/text:LineIter" %t6, ptr %l12
  br label %bb3
bb3:
  %t7 = load %"std/prelude/text:LineIter", ptr %l12
  store %"std/prelude/text:LineIter" %t7, ptr %l5
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l5)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l16
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l15
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  br label %bb8
bb6:
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  store i1 %t18, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb8:
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t20, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t22, ptr %l20
  br label %bb9
bb9:
  %t23 = load i1, ptr %l20, !tbaa !21
  store i1 %t23, ptr %l7, !tbaa !21
  %t24 = load i1, ptr %l7, !tbaa !21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t28, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t30, ptr %l25
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t31 = load i1, ptr %l25, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb15:
  br label %bb16
bb16:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb17, label %bb18
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 44)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l3, !tbaa !24
  %t45 = load i1, ptr %l7, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb23
bb22:
  br label %bb23
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb24
bb24:
  store ptr %l2, ptr %l38, !tbaa !29
  %t53 = load i1, ptr %l7, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l41, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t56, 0
  store i64 %t59, ptr %l44, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l45, !tbaa !24
  %t62 = icmp sge i64 5, 0
  br i1 %t62, label %bb27, label %bb28
bb26:
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t64, ptr %l50, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t65, 0
  store i64 %t68, ptr %l53, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l54, !tbaa !24
  %t71 = icmp sge i64 7, 0
  br i1 %t71, label %bb33, label %bb34
bb27:
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = icmp sle i64 5, %t73
  br i1 %t74, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb29:
  %t76 = load i64, ptr %l44, !tbaa !24
  %t77 = load i64, ptr %l45, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb31:
  %t80 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l44, !tbaa !24
  %t83 = getelementptr i8, ptr %t81, i64 5
  %t84 = sub i64 %t82, 5
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  store { i64, ptr } %t86, ptr %l40, !tbaa !27
  br label %bb39
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb33:
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = icmp sle i64 7, %t88
  br i1 %t89, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb35:
  %t91 = load i64, ptr %l53, !tbaa !24
  %t92 = load i64, ptr %l54, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb37:
  %t95 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l53, !tbaa !24
  %t98 = getelementptr i8, ptr %t96, i64 7
  %t99 = sub i64 %t97, 7
  %t100 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t98, 1
  store { i64, ptr } %t101, ptr %l40, !tbaa !27
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb39:
  %t103 = load ptr, ptr %l38, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l40, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %t103, { i64, ptr } %t104)
  br label %bb40
bb40:
  store ptr %l2, ptr %l59, !tbaa !29
  %t105 = load i1, ptr %l7, !tbaa !21
  br i1 %t105, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l61, !tbaa !27
  br label %bb43
bb42:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l61, !tbaa !27
  br label %bb43
bb43:
  %t107 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t109 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = add i64 %t108, %t111
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t115 = add i64 %t112, %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t107, i64 %t108)
  %t117 = getelementptr i8, ptr %t116, i64 %t108
  call void @olang_textcopy(ptr %t117, ptr %t110, i64 %t111)
  %t118 = getelementptr i8, ptr %t117, i64 %t111
  call void @olang_textcopy(ptr %t118, ptr %t113, i64 %t114)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t116, 1
  %t122 = load ptr, ptr %l59, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t122, { i64, ptr } %t120)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  br label %bb4
bb46:
  %t124 = load i64, ptr %l4, !tbaa !24
  %t125 = load i64, ptr %l3, !tbaa !24
  %t126 = load i64, ptr %l4, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i32, ptr %l1, !tbaa !23
  %t131 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t124)
  %t135 = add i64 %t132, %t134
  %t136 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t129)
  %t141 = add i64 %t138, %t140
  %t142 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = sext i32 %t130 to i64
  %t147 = call i64 @__olang_fmt_i64(ptr null, i64 %t146)
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t131, i64 %t132)
  %t153 = getelementptr i8, ptr %t152, i64 %t132
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t124)
  %t155 = getelementptr i8, ptr %t153, i64 %t134
  call void @olang_textcopy(ptr %t155, ptr %t136, i64 %t137)
  %t156 = getelementptr i8, ptr %t155, i64 %t137
  %t157 = call i64 @__olang_fmt_i64(ptr %t156, i64 %t129)
  %t158 = getelementptr i8, ptr %t156, i64 %t140
  call void @olang_textcopy(ptr %t158, ptr %t142, i64 %t143)
  %t159 = getelementptr i8, ptr %t158, i64 %t143
  %t160 = call i64 @__olang_fmt_i64(ptr %t159, i64 %t146)
  %t161 = getelementptr i8, ptr %t159, i64 %t147
  call void @olang_textcopy(ptr %t161, ptr %t149, i64 %t150)
  %t162 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t152, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t163)
  br label %bb47
bb47:
  %t167 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t167, ptr %l72
  br label %bb48
bb48:
  %t168 = load %"std/prelude/text:StringBuilder", ptr %l72
  store %"std/prelude/text:StringBuilder" %t168, ptr %l8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb49
bb49:
  %t170 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %l8, { i64, ptr } %t170)
  br label %bb50
bb50:
  store ptr %l8, ptr %l76, !tbaa !29
  %t174 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t174, ptr %l78
  br label %bb51
bb51:
  %t175 = load i32, ptr %l1, !tbaa !23
  %t177 = icmp ne i32 %t175, 0
  br i1 %t177, label %bb52, label %bb53
bb52:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d109, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb54
bb53:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d110, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb54
bb54:
  %t179 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t181 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = add i64 %t180, %t183
  %t185 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t187 = add i64 %t184, %t186
  %t188 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t179, i64 %t180)
  %t196 = getelementptr i8, ptr %t195, i64 %t180
  call void @olang_textcopy(ptr %t196, ptr %t182, i64 %t183)
  %t197 = getelementptr i8, ptr %t196, i64 %t183
  call void @olang_textcopy(ptr %t197, ptr %t185, i64 %t186)
  %t198 = getelementptr i8, ptr %t197, i64 %t186
  call void @olang_textcopy(ptr %t198, ptr %t189, i64 %t190)
  %t199 = getelementptr i8, ptr %t198, i64 %t190
  call void @olang_textcopy(ptr %t199, ptr %t192, i64 %t193)
  %t200 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t195, 1
  %t203 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t203, { i64, ptr } %t201)
  br label %bb55
bb55:
  %t206 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l8)
  store { i64, ptr } %t206, ptr %l85
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t207 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t207, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"file" }>, align 8
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"test needs a file" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
@.d7 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"the compiler could not be run" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d11 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
@.d12 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"the compiler could not be run" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d13 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"check" }>, align 8
@.d14 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"doc" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"format" }>, align 8
@.d17 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no tool " }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" needs a file" }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i64, ptr } @olang_lambda_23(ptr %env, ptr %v0) #0 {
entry:
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load i1, ptr %cp2, !tbaa !28
  %cp3 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load { i64, ptr }, ptr %cp3, !tbaa !28
  %cp4 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load { i64, ptr }, ptr %cp4, !tbaa !28
  %cp5 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %cv5 = load ptr, ptr %cp5, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 8
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  %vq3 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 9
  %vr3 = load ptr, ptr %vq3, !tbaa !28
  %vc3 = call ptr @__olang_capture_scope(ptr %vr3)
  %vq4 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 10
  %vr4 = load ptr, ptr %vq4, !tbaa !28
  %vc4 = call ptr @__olang_capture_scope(ptr %vr4)
  br label %start
start:
  br label %bb0
bb0:
  %t13 = call { i64, ptr } @compiler_2fmcp_2erun(ptr %vc0, ptr %vc1, ptr %vc2, ptr %vc3, ptr %vc4, ptr %v0, { i64, ptr } %cv0, { i64, ptr } %cv1, i1 %cv2, { i64, ptr } %cv3, { i64, ptr } %cv4, ptr %cv5)
  store { i64, ptr } %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d24 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"the compiler ended while running " }>, align 8
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" (status " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d26 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c") - a bug in the compiler" }>, align 8
@.d27 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"{\22diagnostics\22:[" }>, align 8
@.d28 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22notes\22:[" }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c",\22kind\22:\22help\22" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d31 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"],\22errors\22:" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d33 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"no errors" }>, align 8
@.d34 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"{\22content\22:[{\22type\22:\22text\22,\22text\22:" }>, align 8
@.d35 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"}],\22structuredContent\22:" }>, align 8
@.d36 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c",\22isError\22:false}" }>, align 8
@.d37 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:" }>, align 8
@.d38 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c",\22error\22:{\22code\22:" }>, align 8
@.d39 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22message\22:" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}}" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d42 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"the message is not JSON" }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d44 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"initialize" }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d46 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"protocolVersion" }>, align 8
@.d47 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"2025-06-18" }>, align 8
@.d48 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"{\22protocolVersion\22:" }>, align 8
@.d49 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c",\22capabilities\22:{\22tools\22:{\22listChanged\22:false}},\22serverInfo\22:{\22name\22:\22olang\22,\22version\22:\220\22}," }>, align 8
@.d50 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"\22instructions\22:" }>, align 8
@.d51 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"Tools for the olang language: check a file's diagnostics, explain an item or a rule, a " }>, align 8
@.d52 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c"module's documentation, format, and run a file's tests. Paths are relative to the server's " }>, align 8
@.d53 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"working directory." }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ping" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{}" }>, align 8
@.d57 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"tools/list" }>, align 8
@.d58 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22tools\22:" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d60 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"tools/call" }>, align 8
@.d61 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d62 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d65 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"arguments" }>, align 8
@.d66 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang serve mcp has no " }>, align 8
@.d67 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"{\22file\22:" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22line\22:" }>, align 8
@.d73 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22column\22:" }>, align 8
@.d74 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22endLine\22:" }>, align 8
@.d75 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c",\22endColumn\22:" }>, align 8
@.d76 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22line\22:" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22rule\22:" }>, align 8
@.d79 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22message\22:" }>, align 8
@.d80 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:" }>, align 8
@.d81 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22result\22:" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d83 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"doc" }>, align 8
@.d84 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670 = weak hidden constant i1 false
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d85 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"format" }>, align 8
@.d86 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"cannot read " }>, align 8
@.d87 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c" does not parse - check it for its diagnostics" }>, align 8
@.d88 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"check" }>, align 8
@.d89 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d91 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' is no top-level item of " }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d94 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"' is no item of " }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d96 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"{\22tests\22:[" }>, align 8
@.d97 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ok - " }>, align 8
@.d98 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"FAIL - " }>, align 8
@.d99 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"{\22name\22:" }>, align 8
@.d100 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d101 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d102 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22passed\22:" }>, align 8
@.d103 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d104 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"],\22passed\22:" }>, align 8
@.d105 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22failed\22:" }>, align 8
@.d106 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22status\22:" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d108 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"{\22content\22:[{\22type\22:\22text\22,\22text\22:" }>, align 8
@.d109 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d110 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d111 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"}],\22structuredContent\22:" }>, align 8
@.d112 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22isError\22:" }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i64, ptr } @compiler_2fmcp_2estr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2fmcp_2eTools = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4, i1 %a5)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
@olang_loc_308bbd8a0e283fc3_2a8ec4cf6bdf47df = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_bf544a52d5413c29_9c9e72e4a09cc655 = external constant [0 x i8]
declare %"compiler/doc:Module" @compiler_2fdoc_2eModule_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
