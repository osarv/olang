; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/check:unsetCand" = type { i64, i64, i64, i1, i64, %"compiler/source:Span", i32, i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i64, i1, i64 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, { i64, ptr }, i64, i1, i64 }
%"compiler/check:errNarrow" = type { { i64, ptr }, i32, i64, i64, i1, i64 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/check:rangeIndex" = type { i64, %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i64, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:weakPlace" = type { { i64, [3 x i64] }, { i64, ptr }, i64 }
define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l26 = alloca i1
  %l28 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l6, !tbaa !23
  %t32 = load i32, ptr %l6, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l26
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = add i64 %a2, 1
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t45, i32 %t46, i64 %t49)
  store i1 %t53, ptr %l33
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = add i64 %t57, 1
  store i64 %t60, ptr %l4, !tbaa !24
  br label %bb2
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/check:ownerAt"
  %l6 = alloca i64
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca %"compiler/check:ownerAt"
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l34 = alloca i64
  %l43 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i32
  %l77 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l89 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i64
  %l98 = alloca ptr
  %l107 = alloca ptr
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t123 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t1, ptr %a3)
  store %"compiler/check:ownerAt" %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load %"compiler/check:ownerAt", ptr %l15
  store %"compiler/check:ownerAt" %t6, ptr %l5
  %t7 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t12 = icmp eq i32 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t15, i32 %t17)
  store i1 %t20, ptr %l22
  br label %bb5
bb5:
  %t21 = load i1, ptr %l22, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load i32, ptr %l4, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t22, i32 %t24, i32 %t25)
  store i1 %t29, ptr %l27
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i1, ptr %l27, !tbaa !21
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l23, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load i32, ptr %l4, !tbaa !23
  %t40 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 1
  %t41 = load i1, ptr %t40, !tbaa !21
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t36, i32 %t38, i32 %t39, i1 %t41)
  store i64 %t46, ptr %l34
  br label %bb13
bb13:
  %t47 = load i64, ptr %l34, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp slt i64 %t48, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load %"compiler/source:Span", ptr %l2
  %t56 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %t53, i64 %t54, %"compiler/source:Span" %t55, i32 %t57)
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l43, !tbaa !29
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t66)
  store i64 %t68, ptr %l45
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = load i64, ptr %l45, !tbaa !24
  %t71 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t69, i64 %t70)
  store i64 %t71, ptr %l46
  br label %bb19
bb19:
  %t72 = load i64, ptr %l46, !tbaa !24
  store i64 %t72, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp eq i64 %t73, 0
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l49, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t78, ptr %l50
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l51, !tbaa !24
  %t80 = icmp sge i64 0, 0
  br i1 %t80, label %bb22, label %bb23
bb21:
  br label %bb27
bb22:
  %t82 = icmp sle i64 0, 2305843009213693951
  br i1 %t82, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_82b0d2a61edf3c68_78216e4ccea776dc)
  unreachable
bb24:
  %t84 = mul i64 0, 4
  %t85 = insertvalue { i64, ptr } undef, i64 0, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l50
  %t89 = load i64, ptr %l51, !tbaa !24
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v2, ptr %v2, ptr %t87, %"compiler/source:Span" %t88, i64 %t89, { i64, ptr } %t86)
  store ptr %t91, ptr %l55
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_82b0d2a61edf3c68_78216e4ccea776dc)
  unreachable
bb26:
  %t92 = load ptr, ptr %l55, !tbaa !29
  store ptr %t92, ptr %rv
  br label %ret
bb27:
  %t94 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 1
  %t95 = load i1, ptr %t94, !tbaa !21
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb28, label %bb29
bb28:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerBinding(ptr %v0, ptr %v2, ptr %t102, i64 %t103, i32 %t105)
  store { i64, ptr } %t109, ptr %l64
  br label %bb30
bb29:
  %t110 = load i64, ptr %l7, !tbaa !24
  store i64 %t110, ptr %l65, !tbaa !24
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t111, ptr %l66, !tbaa !23
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  br i1 %t113, label %bb31, label %bb32
bb30:
  %t115 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t115, ptr %l59, !tbaa !27
  br label %bb35
bb31:
  %t116 = load i64, ptr %l65, !tbaa !24
  %t117 = icmp sle i64 %t116, 2305843009213693951
  br i1 %t117, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9)
  unreachable
bb33:
  %t119 = load i64, ptr %l65, !tbaa !24
  %t120 = mul i64 %t119, 4
  %t121 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t120)
  %t122 = load i32, ptr %l66, !tbaa !23
  store i64 0, ptr %t123
  br label %fill.124
fill.124:
  %t127 = load i64, ptr %t123
  %t128 = icmp slt i64 %t127, %t119
  br i1 %t128, label %fillb.125, label %filld.126
fillb.125:
  %t129 = getelementptr i32, ptr %t121, i64 %t127
  store i32 %t122, ptr %t129
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %t123
  br label %fill.124
filld.126:
  %t131 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t121, 1
  store { i64, ptr } %t132, ptr %l59, !tbaa !27
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9)
  unreachable
bb35:
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t134, ptr %lp8
  %t135 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t136 = load ptr, ptr %lp8
  store { i64, ptr } %t135, ptr %t136, !tbaa !27
  %t137 = load ptr, ptr %lp8
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l11, !tbaa !24
  br label %bb36
bb36:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb37, label %bb38
bb37:
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t152 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t152, ptr %l77, !tbaa !27
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t153
  %t158 = load i32, ptr %t157, !tbaa !33
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t164 = icmp eq i32 %t158, %t161
  br i1 %t164, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t167, ptr %l84
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l85, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load i64, ptr %l6, !tbaa !24
  %t176 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s7, ptr %t172, i64 %t173)
  store ptr %t176, ptr %l89
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t177 = load ptr, ptr %l89, !tbaa !29
  %t179 = getelementptr %"compiler/ast:Func", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %t179, !tbaa !23
  %t181 = load ptr, ptr %l85, !tbaa !29
  %t183 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t181, i32 %t180)
  store { i64, ptr } %t183, ptr %l92
  br label %bb43
bb43:
  %t184 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t186 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderNotValue(ptr %s7, ptr %v0, { i64, ptr } %t184)
  store %"compiler/diagmsg:Msg" %t186, ptr %l94
  br label %bb44
bb44:
  %t187 = load ptr, ptr %l83, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l84
  %t189 = load %"compiler/diagmsg:Msg", ptr %l94
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t187, %"compiler/source:Span" %t188, %"compiler/diagmsg:Msg" %t189)
  store i64 %t190, ptr %l95
  br label %bb45
bb45:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t191, %"compiler/source:Span" %a1)
  store ptr %t195, ptr %l98
  br label %bb46
bb46:
  %t196 = load ptr, ptr %l98, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  store ptr %t196, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t198 = load i64, ptr %l10, !tbaa !24
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %l10, !tbaa !24
  br label %bb36
bb49:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l2
  %t205 = load i64, ptr %l6, !tbaa !24
  %t206 = load ptr, ptr %lp8
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t212 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v2, ptr %v2, ptr %t203, %"compiler/source:Span" %t204, i64 %t205, { i64, ptr } %t207)
  store ptr %t212, ptr %l107
  br label %bb50
bb50:
  %t213 = load ptr, ptr %l107, !tbaa !29
  store ptr %t213, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l7 = alloca i64
  %l14 = alloca i64
  %l18 = alloca ptr
  %l26 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  %t11 = alloca { i64, [3 x i64] }, align 8
  %t46 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledInst(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, [3 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load { i64, [3 x i64] }, ptr %t11
  store { i64, [3 x i64] } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i64, ptr %l14, !tbaa !24
  store i64 %t23, ptr %l3, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Func", ptr %t32, i32 0, i32 3
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Sig", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t44 = icmp eq i64 %t42, 0
  br i1 %t44, label %bb7, label %bb8
bb7:
  store { i64, [3 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load { i64, [3 x i64] }, ptr %t46
  store { i64, [3 x i64] } %t48, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t54, i64 %t55)
  store i64 %t58, ptr %l30
  br label %bb10
bb10:
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t59, ptr %l31, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 0
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = load ptr, ptr %l26, !tbaa !29
  %t66 = load i64, ptr %l30, !tbaa !24
  %t68 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t65, i64 %t66, ptr %t63)
  store { i64, [3 x i64] } %t68, ptr %l34
  br label %bb11
bb11:
  %t69 = load { i64, [3 x i64] }, ptr %l34
  store { i64, [3 x i64] } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l44 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca %"compiler/typed:Local"
  %l75 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i32
  %l83 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l101 = alloca i32
  %l114 = alloca i1
  %l116 = alloca i1
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca ptr
  %l135 = alloca %"compiler/typed:Local"
  %l136 = alloca i32
  %l143 = alloca ptr
  %l146 = alloca i32
  %l150 = alloca %"compiler/typed:Capture"
  %l154 = alloca i1
  %l155 = alloca i1
  %l160 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t115 = alloca { i64, [4 x i64] }, align 8
  %t189 = alloca { i64, [5 x i64] }, align 8
  %t212 = alloca { i64, [5 x i64] }, align 8
  %t259 = alloca { i64, [1 x i64] }, align 8
  %t326 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 21
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 19
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 19
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 19
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 14
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = icmp eq i64 %t57, %t61
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load i32, ptr %l2, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 15
  %t70 = load i32, ptr %t69, !tbaa !23
  %t73 = icmp eq i32 %t66, %t70
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t75 = load i1, ptr %l44, !tbaa !21
  br i1 %t75, label %bb19, label %bb20
bb19:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 17
  store i1 true, ptr %t78, !tbaa !21
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 19
  store ptr %t81, ptr %l51, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 21
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 19
  %t88 = load i64, ptr %t87, !tbaa !24
  %t91 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t84, i64 %t88)
  store ptr %t91, ptr %l56
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l56, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load ptr, ptr %l51, !tbaa !29
  %t98 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t96, i64 %t95)
  store ptr %t98, ptr %l59
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l59, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t99, i32 0, i32 7
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t101, i64 %t102)
  store %"compiler/typed:Local" %t105, ptr %l63
  br label %bb24
bb24:
  %t106 = getelementptr %"compiler/typed:Local", ptr %l63, i32 0, i32 2
  %t107 = load i32, ptr %t106, !tbaa !23
  store i32 %t107, ptr %l7, !tbaa !23
  %t109 = load %"compiler/source:Span", ptr %l3
  %t110 = load i32, ptr %l7, !tbaa !23
  %t111 = load i64, ptr %l6, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 0
  store i64 0, ptr %t116
  %t118 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t109, 0
  %t120 = insertvalue { %"compiler/source:Span", i32, i32 } %t118, i32 %t110, 1
  %t122 = insertvalue { %"compiler/source:Span", i32, i32 } %t120, i32 %t113, 2
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t122, ptr %t123
  %t124 = load { i64, [4 x i64] }, ptr %t115
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t124, ptr %t126
  store ptr %t126, ptr %l8, !tbaa !29
  %t128 = load i32, ptr %l7, !tbaa !23
  store i32 %t128, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l7, !tbaa !23
  %t134 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t130, i32 %t131)
  store i1 %t134, ptr %l75
  br label %bb25
bb25:
  %t135 = load i1, ptr %l75, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb26, label %bb27
bb26:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l7, !tbaa !23
  %t142 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l80
  br label %bb28
bb27:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb37
bb28:
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = load i32, ptr %l80, !tbaa !23
  %t146 = icmp ne i32 %t144, %t143
  br i1 %t146, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb32
bb30:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t152 = load i32, ptr %l7, !tbaa !23
  %t155 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t155, ptr %l87
  br label %bb31
bb31:
  %t156 = load i1, ptr %l87, !tbaa !21
  store i1 %t156, ptr %l83, !tbaa !21
  br label %bb32
bb32:
  %t157 = load i1, ptr %l83, !tbaa !21
  br i1 %t157, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb36
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l7, !tbaa !23
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %t158, i32 %t159)
  store i1 %t162, ptr %l91
  br label %bb35
bb35:
  %t163 = load i1, ptr %l91, !tbaa !21
  store i1 %t163, ptr %l88, !tbaa !21
  br label %bb36
bb36:
  %t164 = load i1, ptr %l88, !tbaa !21
  store i1 %t164, ptr %l77, !tbaa !21
  br label %bb37
bb37:
  %t165 = load i1, ptr %l77, !tbaa !21
  br i1 %t165, label %bb38, label %bb39
bb38:
  %t166 = load ptr, ptr %l4, !tbaa !29
  %t168 = getelementptr %"compiler/check:frame", ptr %t166, i32 0, i32 20
  %t169 = load i1, ptr %t168, !tbaa !21
  %t171 = xor i1 %t169, true
  store i1 %t171, ptr %l92, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb40
bb40:
  %t173 = load i1, ptr %l92, !tbaa !21
  br i1 %t173, label %bb41, label %bb42
bb41:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %l7, !tbaa !23
  %t181 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t179, i32 %t180, i64 %t181)
  store i32 %t185, ptr %l101
  br label %bb43
bb42:
  %t186 = load %"compiler/source:Span", ptr %l3
  %t187 = load i32, ptr %l7, !tbaa !23
  %t188 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 0
  store i64 2, ptr %t190
  %t192 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t186, 0
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t192, i32 %t187, 1
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t194, ptr %t188, 2
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t196, i32 -1, 3
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t197, ptr %t198
  %t199 = load { i64, [5 x i64] }, ptr %t189
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t199, ptr %t201
  store ptr %t201, ptr %l10, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l7, !tbaa !23
  %t207 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t203, i32 %t204)
  store i1 %t207, ptr %l114
  br label %bb44
bb43:
  %t208 = load i32, ptr %l101, !tbaa !23
  store i32 %t208, ptr %l9, !tbaa !23
  %t209 = load %"compiler/source:Span", ptr %l3
  %t210 = load i32, ptr %l9, !tbaa !23
  %t211 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 0
  store i64 3, ptr %t213
  %t215 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t209, 0
  %t217 = insertvalue { %"compiler/source:Span", i32, ptr } %t215, i32 %t210, 1
  %t219 = insertvalue { %"compiler/source:Span", i32, ptr } %t217, ptr %t211, 2
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t219, ptr %t220
  %t221 = load { i64, [5 x i64] }, ptr %t212
  %t223 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t221, ptr %t223
  store ptr %t223, ptr %l10, !tbaa !29
  br label %bb53
bb44:
  %t225 = load i1, ptr %l114, !tbaa !21
  %t226 = xor i1 %t225, true
  br i1 %t226, label %bb45, label %bb46
bb45:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %l7, !tbaa !23
  %t237 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t233, i32 %t234)
  store i1 %t237, ptr %l121
  br label %bb47
bb46:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb48
bb47:
  %t238 = load i1, ptr %l121, !tbaa !21
  store i1 %t238, ptr %l116, !tbaa !21
  br label %bb48
bb48:
  %t239 = load i1, ptr %l116, !tbaa !21
  br i1 %t239, label %bb49, label %bb50
bb49:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t240, i32 %t241, i64 0)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 19
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t249 = getelementptr %"compiler/check:frame", ptr %t247, i32 0, i32 0
  %t250 = load i64, ptr %t249, !tbaa !24
  %t253 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t246, i64 %t250)
  store ptr %t253, ptr %l128
  br label %bb54
bb54:
  %t254 = load ptr, ptr %l128, !tbaa !29
  store ptr %t254, ptr %l11, !tbaa !29
  %t255 = load ptr, ptr %l11, !tbaa !29
  store ptr %t255, ptr %l129, !tbaa !29
  %t256 = load i32, ptr %l2, !tbaa !23
  %t257 = load %"compiler/source:Span", ptr %l3
  %t258 = load i32, ptr %l9, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [1 x i64] }, ptr %t259, i32 0, i32 0
  store i64 4, ptr %t260
  %t261 = load { i64, [1 x i64] }, ptr %t259
  %t267 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t256, %"compiler/source:Span" %t257, i32 %t258, i32 0, i32 5, { i64, [1 x i64] } %t261)
  store %"compiler/typed:Local" %t267, ptr %l135
  br label %bb55
bb55:
  %t268 = load ptr, ptr %l129, !tbaa !29
  %t269 = load %"compiler/typed:Local", ptr %l135
  %t270 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t268, %"compiler/typed:Local" %t269)
  store i32 %t270, ptr %l136
  br label %bb56
bb56:
  %t271 = load i32, ptr %l136, !tbaa !23
  %t272 = sext i32 %t271 to i64
  store i64 %t272, ptr %l12, !tbaa !24
  %t274 = load ptr, ptr %l4, !tbaa !29
  %t276 = getelementptr %"compiler/check:frame", ptr %t274, i32 0, i32 8
  %t277 = load i32, ptr %l2, !tbaa !23
  %t278 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t276, i32 %t277, i64 %t278)
  br label %bb57
bb57:
  %t282 = load ptr, ptr %l4, !tbaa !29
  %t284 = getelementptr %"compiler/check:frame", ptr %t282, i32 0, i32 30
  store ptr %t284, ptr %l143, !tbaa !29
  %t285 = load i64, ptr %l12, !tbaa !24
  %t287 = trunc i64 %t285 to i32
  store i32 %t287, ptr %l146, !tbaa !23
  %t289 = load ptr, ptr %l10, !tbaa !29
  %t291 = icmp eq ptr %t289, null
  br i1 %t291, label %bb58, label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb59:
  br label %bb60
bb60:
  %t293 = load ptr, ptr %l10, !tbaa !29
  %t294 = load i32, ptr %l146, !tbaa !23
  %t296 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t294, ptr %t293)
  store %"compiler/typed:Capture" %t296, ptr %l150
  br label %bb61
bb61:
  %t297 = load %"compiler/typed:Capture", ptr %l150
  %t298 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t297, ptr %t298
  %t299 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v0, ptr %t299, ptr %t298)
  br label %bb62
bb62:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l9, !tbaa !23
  %t305 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t301, i32 %t302)
  store i1 %t305, ptr %l154
  br label %bb63
bb63:
  %t306 = load i1, ptr %l154, !tbaa !21
  br i1 %t306, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb67
bb65:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = getelementptr %"compiler/generic:Program", ptr %t310, i32 0, i32 2
  %t313 = load i32, ptr %l9, !tbaa !23
  %t316 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t312, i32 %t313)
  store i1 %t316, ptr %l160
  br label %bb66
bb66:
  %t317 = load i1, ptr %l160, !tbaa !21
  store i1 %t317, ptr %l155, !tbaa !21
  br label %bb67
bb67:
  %t318 = load i1, ptr %l155, !tbaa !21
  br i1 %t318, label %bb68, label %bb69
bb68:
  %t319 = load ptr, ptr %l11, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Body", ptr %t319, i32 0, i32 6
  %t322 = load i64, ptr %l12, !tbaa !24
  %t324 = trunc i64 %t322 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [1 x i64] }, ptr %t326, i32 0, i32 0
  store i64 4, ptr %t327
  %t329 = insertvalue { i32 } undef, i32 %t324, 0
  %t330 = getelementptr { i64, [1 x i64] }, ptr %t326, i32 0, i32 1
  store { i32 } %t329, ptr %t330
  %t331 = load { i64, [1 x i64] }, ptr %t326
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t321, { i64, [1 x i64] } %t331)
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t334 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t334, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/check:litv"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/diagmsg:Msg"
  %l24 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l67 = alloca i32
  %l71 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/diagmsg:Msg"
  %l97 = alloca i64
  %l100 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l111 = alloca %"compiler/source:Span"
  %l118 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t7, %"compiler/source:Span" %t8, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t11, %"compiler/source:Span" %t12)
  store ptr %t15, ptr %l15
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load ptr, ptr %l15, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp ne i64 %t19, 1
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l20
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s2, ptr %v0, i64 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, i64 %t27)
  store %"compiler/diagmsg:Msg" %t29, ptr %l23
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l20
  %t32 = load %"compiler/diagmsg:Msg", ptr %l23
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, %"compiler/diagmsg:Msg" %t32)
  store i64 %t33, ptr %l24
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t34, %"compiler/source:Span" %t35)
  store ptr %t38, ptr %l27
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load ptr, ptr %l27, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t49 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t40, ptr %t45)
  store %"compiler/check:litv" %t49, ptr %l32
  br label %bb12
bb12:
  %t50 = load %"compiler/check:litv", ptr %l32
  store %"compiler/check:litv" %t50, ptr %l4
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t53 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/check:litv", ptr %l4
  %t58 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t56, %"compiler/check:litv" %t57, i32 %t58)
  store i1 %t62, ptr %l39
  br label %bb15
bb14:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb16
bb15:
  %t63 = load i1, ptr %l39, !tbaa !21
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l35, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb18:
  %t65 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t66 = load i1, ptr %t65, !tbaa !21
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l45, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 0
  %t75 = load ptr, ptr %t74, !tbaa !39
  %t78 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t70, ptr %t75)
  store i1 %t78, ptr %l47
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb26
bb21:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb25
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 0
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t80, ptr %t85)
  store i1 %t88, ptr %l52
  br label %bb24
bb24:
  %t89 = load i1, ptr %l52, !tbaa !21
  store i1 %t89, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l48, !tbaa !21
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l43, !tbaa !21
  store i1 %t91, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l40, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l54, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l56, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = load i32, ptr %l5, !tbaa !23
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t96, ptr %t101, i32 %t103)
  store ptr %t107, ptr %l60
  br label %bb31
bb31:
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t108, ptr %l61, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l63
  br label %bb32
bb32:
  %t115 = load ptr, ptr %l54, !tbaa !29
  %t116 = load ptr, ptr %l60, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l63
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t115, ptr %t116, %"compiler/source:Span" %t117)
  store ptr %t118, ptr %l64
  br label %bb33
bb33:
  %t119 = load ptr, ptr %l64, !tbaa !29
  store ptr %t119, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t123 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t120)
  store i32 %t123, ptr %l67
  br label %bb34
bb34:
  %t124 = load i32, ptr %l67, !tbaa !23
  store i32 %t124, ptr %l7, !tbaa !23
  %t125 = load i32, ptr %l7, !tbaa !23
  %t126 = load i32, ptr %l2, !tbaa !23
  %t129 = icmp eq i32 %t125, %t126
  br i1 %t129, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb37
bb36:
  %t131 = load i32, ptr %l7, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  store i1 %t135, ptr %l71, !tbaa !21
  br label %bb37
bb37:
  %t137 = load i1, ptr %l71, !tbaa !21
  br i1 %t137, label %bb38, label %bb39
bb38:
  %t138 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l7, !tbaa !23
  %t144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l78
  br label %bb41
bb41:
  %t145 = load i1, ptr %l78, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l2, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l82
  br label %bb44
bb43:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  %t151 = load i1, ptr %l82, !tbaa !21
  store i1 %t151, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t152 = load i1, ptr %l79, !tbaa !21
  %t153 = xor i1 %t152, true
  br i1 %t153, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l84, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t156, ptr %l85, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr ptr, ptr %t158, i64 0
  %t160 = load ptr, ptr %t159, !tbaa !39
  %t162 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t160)
  store %"compiler/source:Span" %t162, ptr %l87
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t163, i32 %t164)
  store { i64, ptr } %t167, ptr %l90
  br label %bb49
bb49:
  %t168 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t168, ptr %l91, !tbaa !27
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l7, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t169, i32 %t170)
  store { i64, ptr } %t173, ptr %l94
  br label %bb50
bb50:
  %t174 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t177 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s5, ptr %s5, ptr %v0, { i64, ptr } %t175, { i64, ptr } %t174)
  store %"compiler/diagmsg:Msg" %t177, ptr %l96
  br label %bb51
bb51:
  %t178 = load ptr, ptr %l84, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l87
  %t180 = load %"compiler/diagmsg:Msg", ptr %l96
  %t181 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t178, %"compiler/source:Span" %t179, %"compiler/diagmsg:Msg" %t180)
  store i64 %t181, ptr %l97
  br label %bb52
bb52:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l1
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t182, %"compiler/source:Span" %t183)
  store ptr %t186, ptr %l100
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t187 = load ptr, ptr %l100, !tbaa !29
  store ptr %t187, ptr %rv
  br label %ret
bb54:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l7, !tbaa !23
  %t190 = load i32, ptr %l2, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t188, i32 %t189, i32 %t190)
  store { i64, ptr } %t194, ptr %l104
  br label %bb55
bb55:
  %t195 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb56, label %bb57
bb56:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l107, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l108
  %t202 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t202, ptr %l109, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 0
  %t206 = load ptr, ptr %t205, !tbaa !39
  %t208 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t206)
  store %"compiler/source:Span" %t208, ptr %l111
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t209 = load ptr, ptr %l6, !tbaa !29
  %t210 = load i32, ptr %l2, !tbaa !23
  %t211 = load ptr, ptr %l107, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l108
  %t213 = load %"compiler/source:Span", ptr %l111
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %v2, ptr %t211, %"compiler/source:Span" %t212, %"compiler/source:Span" %t213, ptr %t209, i32 %t210)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l1
  %t218 = load ptr, ptr %l6, !tbaa !29
  %t219 = load i32, ptr %l2, !tbaa !23
  %t224 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t216, %"compiler/source:Span" %t217, ptr %t218, i32 %t219)
  store ptr %t224, ptr %l118
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t225 = load ptr, ptr %l118, !tbaa !29
  store ptr %t225, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, { i64, [1 x i64] } %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca %"compiler/check:unsetCand"
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, [3 x i64] }
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca { ptr, %"compiler/check:unsetCand" }
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l46 = alloca %"compiler/check:unsetCand"
  %l48 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i32
  %l71 = alloca i32
  %l74 = alloca i1
  %l79 = alloca i32
  %l84 = alloca i1
  %l89 = alloca i1
  %l93 = alloca i1
  %l100 = alloca ptr
  %l102 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l111 = alloca i32
  %l114 = alloca i1
  %l120 = alloca i1
  %l124 = alloca i1
  %l129 = alloca i1
  %l133 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i1
  %l139 = alloca { i64, ptr }
  %l142 = alloca i1
  %l145 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca i32
  %l156 = alloca i32
  %l157 = alloca i32
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca i32
  %l163 = alloca { i64, ptr }
  %l166 = alloca %"compiler/source:Span"
  %l167 = alloca ptr
  %l170 = alloca i1
  %l176 = alloca i1
  %l180 = alloca i1
  %l185 = alloca i1
  %l189 = alloca i1
  %l194 = alloca i32
  %l197 = alloca i1
  %l198 = alloca ptr
  %l203 = alloca i32
  %l204 = alloca i1
  %l207 = alloca { i64, ptr }
  %l212 = alloca ptr
  %l215 = alloca ptr
  %l217 = alloca i32
  %l219 = alloca i1
  %l220 = alloca i1
  %l223 = alloca ptr
  %l225 = alloca i32
  %l226 = alloca i32
  %l230 = alloca i32
  %l231 = alloca ptr
  %l234 = alloca ptr
  %l235 = alloca i32
  %l237 = alloca { i64, ptr }
  %l240 = alloca %"compiler/source:Span"
  %l241 = alloca ptr
  %l245 = alloca i1
  %l253 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l260 = alloca i32
  %l272 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca ptr
  %l283 = alloca { i64, [3 x i64] }
  %l287 = alloca i1
  %l292 = alloca i1
  %l295 = alloca { i64, ptr }
  %l299 = alloca { i64, ptr }
  %l302 = alloca i1
  %l310 = alloca i1
  %l312 = alloca { i64, ptr }
  %l314 = alloca ptr
  %l315 = alloca i1
  %l320 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l339 = alloca i1
  %l342 = alloca ptr
  %l344 = alloca { i64, ptr }
  %l346 = alloca ptr
  %l351 = alloca i32
  %l355 = alloca ptr
  %l359 = alloca i1
  %l360 = alloca ptr
  %l363 = alloca i32
  %l364 = alloca i1
  %l369 = alloca i32
  %l375 = alloca i1
  %l380 = alloca ptr
  %l387 = alloca %"compiler/source:Span"
  %l390 = alloca ptr
  %l391 = alloca %"compiler/source:Span"
  %l394 = alloca { i64, ptr }
  %l396 = alloca %"compiler/diagmsg:Msg"
  %l397 = alloca i64
  %l400 = alloca ptr
  %l403 = alloca i32
  %l404 = alloca i32
  %l407 = alloca i1
  %l410 = alloca ptr
  %l411 = alloca i32
  %l413 = alloca i32
  %l414 = alloca i1
  %l416 = alloca ptr
  %l419 = alloca ptr
  %l420 = alloca i32
  %l422 = alloca { i64, ptr }
  %l425 = alloca %"compiler/source:Span"
  %l426 = alloca ptr
  %l432 = alloca { ptr, %"compiler/check:unsetCand" }
  %l439 = alloca i1
  %l443 = alloca i1
  %l447 = alloca i1
  %l453 = alloca i1
  %l458 = alloca i1
  %l461 = alloca i1
  %l462 = alloca i1
  %l463 = alloca ptr
  %l465 = alloca i32
  %l466 = alloca i1
  %l467 = alloca i1
  %l470 = alloca i1
  %l472 = alloca i1
  %l476 = alloca i1
  %l478 = alloca i1
  %l481 = alloca { i64, ptr }
  %l484 = alloca i1
  %l487 = alloca { i64, ptr }
  %l490 = alloca %"compiler/source:Span"
  %l493 = alloca ptr
  %l495 = alloca i32
  %l496 = alloca i1
  %l497 = alloca ptr
  %l498 = alloca %"compiler/source:Span"
  %l501 = alloca { i64, ptr }
  %l502 = alloca ptr
  %l504 = alloca i32
  %l505 = alloca { i64, ptr }
  %l506 = alloca { i64, ptr }
  %l509 = alloca { i64, ptr }
  %l510 = alloca { i64, ptr }
  %l511 = alloca i64
  %l512 = alloca { i64, ptr }
  %l514 = alloca %"compiler/diagmsg:Msg"
  %l515 = alloca i64
  %l516 = alloca ptr
  %l517 = alloca %"compiler/source:Span"
  %l518 = alloca %"compiler/source:Span"
  %l521 = alloca ptr
  %l523 = alloca i32
  %l524 = alloca i32
  %l530 = alloca ptr
  %l534 = alloca { i64, ptr }
  %l539 = alloca i32
  %l544 = alloca i32
  %l547 = alloca i1
  %l550 = alloca ptr
  %l551 = alloca i32
  %l553 = alloca i32
  %l554 = alloca i1
  %l556 = alloca ptr
  %l562 = alloca ptr
  %l564 = alloca i32
  %l566 = alloca i32
  %l568 = alloca i1
  %l569 = alloca ptr
  %l571 = alloca i32
  %l572 = alloca i1
  %l573 = alloca ptr
  %l574 = alloca %"compiler/source:Span"
  %l575 = alloca %"compiler/source:Span"
  %l576 = alloca i32
  %l582 = alloca ptr
  %l589 = alloca i1
  %l593 = alloca i1
  %l601 = alloca i1
  %l604 = alloca i1
  %l606 = alloca i1
  %l607 = alloca ptr
  %l611 = alloca i1
  %l613 = alloca i1
  %l617 = alloca ptr
  %l620 = alloca ptr
  %l622 = alloca { i64, ptr }
  %l625 = alloca %"compiler/source:Span"
  %l626 = alloca ptr
  %l630 = alloca i32
  %l631 = alloca ptr
  %l635 = alloca i1
  %l636 = alloca ptr
  %l639 = alloca ptr
  %l642 = alloca { i64, ptr }
  %l645 = alloca { i64, ptr }
  %l648 = alloca ptr
  %l655 = alloca i1
  %l657 = alloca i1
  %l661 = alloca i1
  %l664 = alloca i1
  %l666 = alloca i1
  %l670 = alloca i1
  %l671 = alloca ptr
  %l674 = alloca ptr
  %l676 = alloca { i64, ptr }
  %l679 = alloca %"compiler/source:Span"
  %l680 = alloca ptr
  %l684 = alloca i32
  %l687 = alloca i1
  %l693 = alloca i1
  %l698 = alloca i1
  %l704 = alloca i1
  %l707 = alloca { i64, ptr }
  %l710 = alloca i32
  %l714 = alloca ptr
  %l716 = alloca { i64, ptr }
  %l719 = alloca %"compiler/source:Span"
  %l722 = alloca { i64, ptr }
  %l724 = alloca %"compiler/diagmsg:Msg"
  %l725 = alloca i64
  %l727 = alloca i1
  %l730 = alloca i1
  %l731 = alloca i1
  %l736 = alloca i64
  %l740 = alloca i1
  %l743 = alloca ptr
  %l746 = alloca i32
  %l747 = alloca i32
  %l751 = alloca i1
  %l754 = alloca i1
  %l757 = alloca ptr
  %l762 = alloca i32
  %l767 = alloca i64
  %l771 = alloca i32
  %l777 = alloca i1
  %l780 = alloca i1
  %l783 = alloca i1
  %l785 = alloca ptr
  %l786 = alloca ptr
  %l788 = alloca { i64, ptr }
  %l791 = alloca %"compiler/source:Span"
  %l793 = alloca i1
  %l796 = alloca { i64, ptr }
  %l803 = alloca i64
  %l807 = alloca ptr
  %l811 = alloca ptr
  %l819 = alloca i1
  %l823 = alloca i1
  %l828 = alloca i1
  %l831 = alloca ptr
  %l836 = alloca i32
  %l837 = alloca i32
  %l840 = alloca i1
  %l843 = alloca ptr
  %l848 = alloca i32
  %l849 = alloca i32
  %l851 = alloca i1
  %l854 = alloca i1
  %l857 = alloca ptr
  %l861 = alloca ptr
  %l867 = alloca ptr
  %l876 = alloca %"compiler/check:unsetCand"
  %l881 = alloca i1
  %l886 = alloca ptr
  %l888 = alloca ptr
  %l889 = alloca i64
  %l890 = alloca ptr
  %l896 = alloca { i64, [3 x i64] }
  %l898 = alloca ptr
  %l899 = alloca i64
  %l904 = alloca i1
  %l908 = alloca i1
  %l911 = alloca i1
  %l912 = alloca i1
  %l915 = alloca { i64, ptr }
  %l918 = alloca i1
  %l920 = alloca ptr
  %l922 = alloca ptr
  %l926 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l930 = alloca i1
  %l936 = alloca i1
  %l939 = alloca i1
  %l941 = alloca ptr
  %l943 = alloca ptr
  %l947 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l949 = alloca { i64, ptr }
  %l953 = alloca %"compiler/check:fixedInit"
  %l959 = alloca i1
  %l962 = alloca i1
  %l964 = alloca i1
  %l969 = alloca i1
  %l970 = alloca i1
  %l973 = alloca ptr
  %l977 = alloca ptr
  %l979 = alloca ptr
  %l980 = alloca %"compiler/source:Span"
  %l983 = alloca i32
  %l992 = alloca ptr
  %l998 = alloca ptr
  %l999 = alloca i64
  %l1000 = alloca %"compiler/source:Span"
  %l1003 = alloca i1
  %s0 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %t1061 = alloca { i64, [4 x i64] }, align 8
  %t1172 = alloca { i64, [4 x i64] }, align 8
  %t2030 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l32, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i64 %t5
  %t10 = load %"compiler/source:Span", ptr %t9
  store %"compiler/source:Span" %t10, ptr %l6
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:VarDecl", ptr %t12, i32 0, i32 5
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:VarDecl", ptr %t18, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l39, !tbaa !27
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  %t28 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldNotParam(ptr %v0, ptr %t17, i32 %t27, %"compiler/source:Span" %t28)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t32 = load i32, ptr %l3, !tbaa !23
  store i32 %t32, ptr %l7, !tbaa !23
  store ptr null, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t34 = load %"compiler/source:Span", ptr %l6
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t38 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s0, i64 -1, i64 -1, i64 -1, i1 false, i64 -1, %"compiler/source:Span" %t34, i32 %t35, i1 false)
  store %"compiler/check:unsetCand" %t38, ptr %l46
  br label %bb5
bb5:
  %t39 = load %"compiler/check:unsetCand", ptr %l46
  store %"compiler/check:unsetCand" %t39, ptr %l10
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t40)
  store ptr %t42, ptr %l48
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l48, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 43
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:VarDecl", ptr %t46, i32 0, i32 0
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l52, !tbaa !27
  %t50 = load i64, ptr %l2, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i32, ptr %t53, i64 %t50
  %t55 = load i32, ptr %t54, !tbaa !33
  %t58 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t45, i32 %t55)
  store i1 %t58, ptr %l55
  br label %bb7
bb7:
  %t59 = load i1, ptr %l55, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l11, !tbaa !21
  %t62 = load i32, ptr %l3, !tbaa !23
  store i32 %t62, ptr %l12, !tbaa !23
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 5
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l11, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l60, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t70)
  store ptr %t72, ptr %l62
  br label %bb10
bb9:
  %t73 = load i1, ptr %l11, !tbaa !21
  br i1 %t73, label %bb21, label %bb22
bb10:
  %t75 = load ptr, ptr %l62, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Body", ptr %t75, i32 0, i32 10
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t77)
  store i64 %t79, ptr %l65
  br label %bb11
bb11:
  %t80 = load ptr, ptr %l60, !tbaa !29
  %t81 = load i64, ptr %l65, !tbaa !24
  %t82 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %t80, i64 %t81)
  store i32 %t82, ptr %l66
  br label %bb12
bb12:
  %t83 = load i32, ptr %l66, !tbaa !23
  store i32 %t83, ptr %l13, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l13, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l71
  br label %bb13
bb13:
  %t94 = load i32, ptr %l71, !range !{i32 0, i32 33}
  %t96 = trunc i64 19 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb14, label %bb15
bb14:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l13, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l79
  br label %bb16
bb15:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb17
bb16:
  %t109 = load i32, ptr %l79, !tbaa !23
  %t110 = icmp ne i32 %t109, 0
  store i1 %t110, ptr %l74, !tbaa !21
  br label %bb17
bb17:
  %t112 = load i1, ptr %l74, !tbaa !21
  br i1 %t112, label %bb18, label %bb19
bb18:
  %t113 = load i32, ptr %l13, !tbaa !23
  store i32 %t113, ptr %l12, !tbaa !23
  %t115 = load i32, ptr %l13, !tbaa !23
  store i32 %t115, ptr %l7, !tbaa !23
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb35
bb21:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/ast:VarDecl", ptr %t117, i32 0, i32 2
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  %t124 = xor i1 %t122, true
  store i1 %t124, ptr %l84, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb23
bb23:
  %t126 = load i1, ptr %l84, !tbaa !21
  br i1 %t126, label %bb24, label %bb25
bb24:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/ast:VarDecl", ptr %t127, i32 0, i32 4
  %t130 = load i1, ptr %t129, !tbaa !21
  %t132 = xor i1 %t130, true
  store i1 %t132, ptr %l89, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb26
bb26:
  %t134 = load i1, ptr %l89, !tbaa !21
  br i1 %t134, label %bb27, label %bb28
bb27:
  %t135 = load i64, ptr %l2, !tbaa !24
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr %"compiler/ast:VarDecl", ptr %t136, i32 0, i32 3
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t144 = icmp slt i64 %t135, %t141
  store i1 %t144, ptr %l93, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb29
bb29:
  %t146 = load i1, ptr %l93, !tbaa !21
  br i1 %t146, label %bb30, label %bb31
bb30:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  store ptr %t150, ptr %l100, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t151)
  store ptr %t153, ptr %l102
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t154 = load ptr, ptr %l102, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 4
  %t157 = load i32, ptr %l3, !tbaa !23
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr %"compiler/ast:VarDecl", ptr %t158, i32 0, i32 3
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l107, !tbaa !27
  %t162 = load i64, ptr %l2, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr ptr, ptr %t165, i64 %t162
  %t167 = load ptr, ptr %t166, !tbaa !39
  %t169 = load ptr, ptr %l100, !tbaa !29
  %t173 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v0, ptr %v1, ptr %t169, ptr %t156, i32 %t157, ptr %t167)
  store i32 %t173, ptr %l111
  br label %bb33
bb33:
  %t174 = load i32, ptr %l111, !tbaa !23
  store i32 %t174, ptr %l12, !tbaa !23
  %t175 = load i32, ptr %l12, !tbaa !23
  store i32 %t175, ptr %l7, !tbaa !23
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t177 = load i1, ptr %l11, !tbaa !21
  br i1 %t177, label %bb36, label %bb37
bb36:
  %t179 = load i64, ptr %l2, !tbaa !24
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr %"compiler/ast:VarDecl", ptr %t180, i32 0, i32 3
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t188 = icmp slt i64 %t179, %t185
  store i1 %t188, ptr %l114, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb38
bb38:
  %t190 = load i1, ptr %l114, !tbaa !21
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr %"compiler/ast:VarDecl", ptr %t191, i32 0, i32 5
  %t194 = load i1, ptr %t193, !tbaa !21
  %t196 = xor i1 %t194, true
  store i1 %t196, ptr %l120, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb41
bb41:
  %t198 = load i1, ptr %l120, !tbaa !21
  br i1 %t198, label %bb42, label %bb43
bb42:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/ast:VarDecl", ptr %t199, i32 0, i32 2
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  %t206 = xor i1 %t204, true
  store i1 %t206, ptr %l124, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb44
bb44:
  %t208 = load i1, ptr %l124, !tbaa !21
  br i1 %t208, label %bb45, label %bb46
bb45:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr %"compiler/ast:VarDecl", ptr %t209, i32 0, i32 4
  %t212 = load i1, ptr %t211, !tbaa !21
  %t214 = xor i1 %t212, true
  store i1 %t214, ptr %l129, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb47
bb47:
  %t216 = load i1, ptr %l129, !tbaa !21
  br i1 %t216, label %bb48, label %bb49
bb48:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l3, !tbaa !23
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsRef(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t221, ptr %l136
  br label %bb50
bb49:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb51
bb50:
  %t222 = load i1, ptr %l136, !tbaa !21
  store i1 %t222, ptr %l133, !tbaa !21
  br label %bb51
bb51:
  %t223 = load i1, ptr %l133, !tbaa !21
  br i1 %t223, label %bb52, label %bb53
bb52:
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr %"compiler/ast:VarDecl", ptr %t224, i32 0, i32 3
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  store { i64, ptr } %t227, ptr %l139, !tbaa !27
  %t228 = load i64, ptr %l2, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr ptr, ptr %t231, i64 %t228
  %t233 = load ptr, ptr %t232, !tbaa !39
  %t235 = call i1 @compiler_2fcheck_2eplaceLike(ptr %v1, ptr %t233)
  store i1 %t235, ptr %l142
  br label %bb54
bb53:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb55
bb54:
  %t236 = load i1, ptr %l142, !tbaa !21
  store i1 %t236, ptr %l137, !tbaa !21
  br label %bb55
bb55:
  %t237 = load i1, ptr %l137, !tbaa !21
  br i1 %t237, label %bb56, label %bb57
bb56:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr %"compiler/ast:VarDecl", ptr %t239, i32 0, i32 3
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l145, !tbaa !27
  %t243 = load i64, ptr %l2, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr ptr, ptr %t246, i64 %t243
  %t248 = load ptr, ptr %t247, !tbaa !39
  %t250 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t254 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t238, ptr %t248, i32 %t250)
  store ptr %t254, ptr %l150
  br label %bb58
bb57:
  %t255 = load i1, ptr %l11, !tbaa !21
  br i1 %t255, label %bb63, label %bb64
bb58:
  %t257 = load ptr, ptr %l150, !tbaa !29
  store ptr %t257, ptr %l8, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l152, !tbaa !29
  %t260 = load i32, ptr %l3, !tbaa !23
  store i32 %t260, ptr %l153, !tbaa !23
  %t261 = load ptr, ptr %l8, !tbaa !29
  %t264 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t261)
  store i32 %t264, ptr %l156
  br label %bb59
bb59:
  %t265 = load ptr, ptr %l152, !tbaa !29
  %t266 = load i32, ptr %l153, !tbaa !23
  %t267 = load i32, ptr %l156, !tbaa !23
  %t268 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefRows(ptr %v0, ptr %t265, i32 %t266, i32 %t267)
  store i32 %t268, ptr %l157
  br label %bb60
bb60:
  %t269 = load i32, ptr %l157, !tbaa !23
  store i32 %t269, ptr %l7, !tbaa !23
  %t270 = load i32, ptr %l7, !tbaa !23
  store i32 %t270, ptr %l12, !tbaa !23
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l159, !tbaa !29
  %t273 = load ptr, ptr %l8, !tbaa !29
  store ptr %t273, ptr %l160, !tbaa !29
  %t274 = load i32, ptr %l7, !tbaa !23
  store i32 %t274, ptr %l161, !tbaa !23
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr %"compiler/ast:VarDecl", ptr %t275, i32 0, i32 3
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  store { i64, ptr } %t278, ptr %l163, !tbaa !27
  %t279 = load i64, ptr %l2, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr ptr, ptr %t282, i64 %t279
  %t284 = load ptr, ptr %t283, !tbaa !39
  %t286 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t284)
  store %"compiler/source:Span" %t286, ptr %l166
  br label %bb61
bb61:
  %t287 = load ptr, ptr %l159, !tbaa !29
  %t288 = load ptr, ptr %l160, !tbaa !29
  %t289 = load i32, ptr %l161, !tbaa !23
  %t290 = load %"compiler/source:Span", ptr %l166
  %t291 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t287, ptr %t288, i32 %t289, %"compiler/source:Span" %t290)
  store ptr %t291, ptr %l167
  br label %bb62
bb62:
  %t292 = load ptr, ptr %l167, !tbaa !29
  store ptr %t292, ptr %l8, !tbaa !29
  br label %bb196
bb63:
  %t294 = load i64, ptr %l2, !tbaa !24
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr %"compiler/ast:VarDecl", ptr %t295, i32 0, i32 3
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t303 = icmp slt i64 %t294, %t300
  store i1 %t303, ptr %l170, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb65
bb65:
  %t305 = load i1, ptr %l170, !tbaa !21
  br i1 %t305, label %bb66, label %bb67
bb66:
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr %"compiler/ast:VarDecl", ptr %t306, i32 0, i32 5
  %t309 = load i1, ptr %t308, !tbaa !21
  %t311 = xor i1 %t309, true
  store i1 %t311, ptr %l176, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb68
bb68:
  %t313 = load i1, ptr %l176, !tbaa !21
  br i1 %t313, label %bb69, label %bb70
bb69:
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = getelementptr %"compiler/ast:VarDecl", ptr %t314, i32 0, i32 2
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = icmp eq ptr %t317, null
  %t321 = xor i1 %t319, true
  store i1 %t321, ptr %l180, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb71
bb71:
  %t323 = load i1, ptr %l180, !tbaa !21
  br i1 %t323, label %bb72, label %bb73
bb72:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr %"compiler/ast:VarDecl", ptr %t324, i32 0, i32 4
  %t327 = load i1, ptr %t326, !tbaa !21
  %t329 = xor i1 %t327, true
  store i1 %t329, ptr %l185, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb74
bb74:
  %t331 = load i1, ptr %l185, !tbaa !21
  br i1 %t331, label %bb75, label %bb76
bb75:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t337 = getelementptr %"compiler/generic:Program", ptr %t335, i32 0, i32 2
  %t338 = load i32, ptr %l12, !tbaa !23
  %t341 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t337, i32 %t338)
  store i32 %t341, ptr %l194
  br label %bb77
bb76:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb78
bb77:
  %t342 = load i32, ptr %l194, !range !{i32 0, i32 33}
  %t344 = trunc i64 19 to i32
  %t345 = icmp eq i32 %t342, %t344
  store i1 %t345, ptr %l189, !tbaa !21
  br label %bb78
bb78:
  %t347 = load i1, ptr %l189, !tbaa !21
  br i1 %t347, label %bb79, label %bb80
bb79:
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l198, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = getelementptr %"compiler/generic:Program", ptr %t352, i32 0, i32 2
  %t355 = load i32, ptr %l12, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l203
  br label %bb81
bb80:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb83
bb81:
  %t359 = load ptr, ptr %l198, !tbaa !29
  %t360 = load i32, ptr %l203, !tbaa !23
  %t361 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t359, i32 %t360)
  store i1 %t361, ptr %l204
  br label %bb82
bb82:
  %t362 = load i1, ptr %l204, !tbaa !21
  store i1 %t362, ptr %l197, !tbaa !21
  br label %bb83
bb83:
  %t363 = load i1, ptr %l197, !tbaa !21
  br i1 %t363, label %bb84, label %bb85
bb84:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr %"compiler/ast:VarDecl", ptr %t365, i32 0, i32 3
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  store { i64, ptr } %t368, ptr %l207, !tbaa !27
  %t369 = load i64, ptr %l2, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr ptr, ptr %t372, i64 %t369
  %t374 = load ptr, ptr %t373, !tbaa !39
  %t376 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t380 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t364, ptr %t374, i32 %t376)
  store ptr %t380, ptr %l212
  br label %bb86
bb85:
  %t381 = load ptr, ptr %l1, !tbaa !29
  %t383 = getelementptr %"compiler/ast:VarDecl", ptr %t381, i32 0, i32 6
  %t384 = load i1, ptr %t383, !tbaa !21
  br i1 %t384, label %bb103, label %bb104
bb86:
  %t386 = load ptr, ptr %l212, !tbaa !29
  store ptr %t386, ptr %l8, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !29
  store ptr %t391, ptr %l215, !tbaa !29
  %t392 = load ptr, ptr %l8, !tbaa !29
  %t394 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t392)
  store i32 %t394, ptr %l217
  br label %bb87
bb87:
  %t395 = load i32, ptr %l12, !tbaa !23
  %t396 = load ptr, ptr %l215, !tbaa !29
  %t397 = load i32, ptr %l217, !tbaa !23
  %t399 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t396, i32 %t397, i32 %t395)
  store i1 %t399, ptr %l219
  br label %bb88
bb88:
  %t400 = load i1, ptr %l219, !tbaa !21
  br i1 %t400, label %bb89, label %bb90
bb89:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/check:Checker", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 2
  store ptr %t406, ptr %l223, !tbaa !29
  %t407 = load ptr, ptr %l8, !tbaa !29
  %t409 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t407)
  store i32 %t409, ptr %l225
  br label %bb91
bb90:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb93
bb91:
  %t410 = load ptr, ptr %l223, !tbaa !29
  %t411 = load i32, ptr %l225, !tbaa !23
  %t412 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t410, i32 %t411)
  store i32 %t412, ptr %l226
  br label %bb92
bb92:
  %t413 = load i32, ptr %l226, !range !{i32 0, i32 33}
  %t415 = trunc i64 19 to i32
  %t416 = icmp eq i32 %t413, %t415
  store i1 %t416, ptr %l220, !tbaa !21
  br label %bb93
bb93:
  %t418 = load i1, ptr %l220, !tbaa !21
  br i1 %t418, label %bb94, label %bb95
bb94:
  %t419 = load ptr, ptr %l8, !tbaa !29
  %t421 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t419)
  store i32 %t421, ptr %l230
  br label %bb96
bb95:
  %t422 = load ptr, ptr %l0, !tbaa !29
  store ptr %t422, ptr %l231, !tbaa !29
  %t423 = load ptr, ptr %l8, !tbaa !29
  %t425 = icmp eq ptr %t423, null
  br i1 %t425, label %bb97, label %bb98
bb96:
  %t427 = load i32, ptr %l230, !tbaa !23
  store i32 %t427, ptr %l7, !tbaa !23
  br label %bb102
bb97:
  call void @__olang_check_failed(ptr @olang_loc_d5eb4bc83317f0cf_8c7e90b31a67a25b)
  unreachable
bb98:
  br label %bb99
bb99:
  %t428 = load ptr, ptr %l8, !tbaa !29
  store ptr %t428, ptr %l234, !tbaa !29
  %t429 = load i32, ptr %l12, !tbaa !23
  store i32 %t429, ptr %l235, !tbaa !23
  %t430 = load ptr, ptr %l1, !tbaa !29
  %t432 = getelementptr %"compiler/ast:VarDecl", ptr %t430, i32 0, i32 3
  %t433 = load { i64, ptr }, ptr %t432, !tbaa !27
  store { i64, ptr } %t433, ptr %l237, !tbaa !27
  %t434 = load i64, ptr %l2, !tbaa !24
  %t436 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = getelementptr ptr, ptr %t437, i64 %t434
  %t439 = load ptr, ptr %t438, !tbaa !39
  %t441 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t439)
  store %"compiler/source:Span" %t441, ptr %l240
  br label %bb100
bb100:
  %t442 = load ptr, ptr %l231, !tbaa !29
  %t443 = load ptr, ptr %l234, !tbaa !29
  %t444 = load i32, ptr %l235, !tbaa !23
  %t445 = load %"compiler/source:Span", ptr %l240
  %t446 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t442, ptr %t443, i32 %t444, %"compiler/source:Span" %t445)
  store ptr %t446, ptr %l241
  br label %bb101
bb101:
  %t447 = load ptr, ptr %l241, !tbaa !29
  store ptr %t447, ptr %l8, !tbaa !29
  br label %bb102
bb102:
  br label %bb195
bb103:
  %t449 = load i64, ptr %l2, !tbaa !24
  %t450 = load ptr, ptr %l1, !tbaa !29
  %t452 = getelementptr %"compiler/ast:VarDecl", ptr %t450, i32 0, i32 3
  %t453 = load { i64, ptr }, ptr %t452, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t453, 0
  %t458 = icmp slt i64 %t449, %t455
  store i1 %t458, ptr %l245, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb105
bb105:
  %t460 = load i1, ptr %l245, !tbaa !21
  br i1 %t460, label %bb106, label %bb107
bb106:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t464 = getelementptr %"compiler/ast:VarDecl", ptr %t462, i32 0, i32 3
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !27
  store { i64, ptr } %t465, ptr %l253, !tbaa !27
  %t466 = load i64, ptr %l2, !tbaa !24
  %t468 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !27
  %t470 = getelementptr ptr, ptr %t469, i64 %t466
  %t471 = load ptr, ptr %t470, !tbaa !39
  %t474 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elinkTo(ptr %v0, ptr %v1, ptr %v0, ptr %t461, ptr %t471)
  store ptr %t474, ptr %l256
  br label %bb108
bb107:
  %t475 = load i64, ptr %l2, !tbaa !24
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr %"compiler/ast:VarDecl", ptr %t476, i32 0, i32 3
  %t479 = load { i64, ptr }, ptr %t478, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t484 = icmp slt i64 %t475, %t481
  br i1 %t484, label %bb110, label %bb111
bb108:
  %t486 = load ptr, ptr %l256, !tbaa !29
  store ptr %t486, ptr %l8, !tbaa !29
  %t488 = load ptr, ptr %l8, !tbaa !29
  %t491 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t488)
  store i32 %t491, ptr %l260
  br label %bb109
bb109:
  %t492 = load i32, ptr %l260, !tbaa !23
  store i32 %t492, ptr %l7, !tbaa !23
  br label %bb194
bb110:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t495 = getelementptr %"compiler/check:Checker", ptr %t493, i32 0, i32 18
  %t496 = load { i64, [3 x i64] }, ptr %t495
  store { i64, [3 x i64] } %t496, ptr %l14
  %t498 = load ptr, ptr %l1, !tbaa !29
  %t500 = getelementptr %"compiler/ast:VarDecl", ptr %t498, i32 0, i32 2
  %t501 = load ptr, ptr %t500, !tbaa !29
  %t503 = icmp eq ptr %t501, null
  %t505 = xor i1 %t503, true
  br i1 %t505, label %bb112, label %bb113
bb111:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t509 = load %"compiler/source:Span", ptr %l6
  %t510 = load i32, ptr %l7, !tbaa !23
  %t515 = call { ptr, %"compiler/check:unsetCand" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroDecl(ptr %v0, ptr %v1, ptr %v0, ptr %t507, ptr %t508, %"compiler/source:Span" %t509, i32 %t510)
  store { ptr, %"compiler/check:unsetCand" } %t515, ptr %l432
  br label %bb192
bb112:
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr %"compiler/ast:VarDecl", ptr %t516, i32 0, i32 4
  %t519 = load i1, ptr %t518, !tbaa !21
  %t521 = xor i1 %t519, true
  store i1 %t521, ptr %l272, !tbaa !21
  br label %bb114
bb113:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb114
bb114:
  %t523 = load i1, ptr %l272, !tbaa !21
  br i1 %t523, label %bb115, label %bb116
bb115:
  %t524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t524, ptr %l276, !tbaa !29
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l277, !tbaa !29
  %t526 = load ptr, ptr %l1, !tbaa !29
  %t528 = getelementptr %"compiler/ast:VarDecl", ptr %t526, i32 0, i32 2
  %t529 = load ptr, ptr %t528, !tbaa !29
  %t531 = icmp eq ptr %t529, null
  br i1 %t531, label %bb117, label %bb118
bb116:
  br label %bb121
bb117:
  call void @__olang_check_failed(ptr @olang_loc_9d7ece6248e2c3f0_c2c00bd4e16cd76c)
  unreachable
bb118:
  br label %bb119
bb119:
  %t533 = load ptr, ptr %l1, !tbaa !29
  %t535 = getelementptr %"compiler/ast:VarDecl", ptr %t533, i32 0, i32 2
  %t536 = load ptr, ptr %t535, !tbaa !29
  %t537 = load ptr, ptr %l277, !tbaa !29
  %t539 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t537, ptr %t536)
  store { i64, [3 x i64] } %t539, ptr %l283
  br label %bb120
bb120:
  %t540 = load { i64, [3 x i64] }, ptr %l283
  %t541 = load ptr, ptr %l276, !tbaa !29
  %t542 = getelementptr %"compiler/check:Checker", ptr %t541, i32 0, i32 18
  store { i64, [3 x i64] } %t540, ptr %t542
  br label %bb121
bb121:
  %t543 = load ptr, ptr %l1, !tbaa !29
  %t545 = getelementptr %"compiler/ast:VarDecl", ptr %t543, i32 0, i32 5
  %t546 = load i1, ptr %t545, !tbaa !21
  %t548 = xor i1 %t546, true
  br i1 %t548, label %bb122, label %bb123
bb122:
  %t550 = load ptr, ptr %l1, !tbaa !29
  %t552 = getelementptr %"compiler/ast:VarDecl", ptr %t550, i32 0, i32 0
  %t553 = load { i64, ptr }, ptr %t552, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t553, 0
  %t557 = icmp eq i64 %t555, 1
  store i1 %t557, ptr %l287, !tbaa !21
  br label %bb124
bb123:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb124
bb124:
  %t559 = load i1, ptr %l287, !tbaa !21
  br i1 %t559, label %bb125, label %bb126
bb125:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load ptr, ptr %l1, !tbaa !29
  %t563 = getelementptr %"compiler/ast:VarDecl", ptr %t561, i32 0, i32 0
  %t564 = load { i64, ptr }, ptr %t563, !tbaa !27
  store { i64, ptr } %t564, ptr %l295, !tbaa !27
  %t565 = load i64, ptr %l2, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr i32, ptr %t568, i64 %t565
  %t570 = load i32, ptr %t569, !tbaa !33
  %t571 = load ptr, ptr %l1, !tbaa !29
  %t573 = getelementptr %"compiler/ast:VarDecl", ptr %t571, i32 0, i32 3
  %t574 = load { i64, ptr }, ptr %t573, !tbaa !27
  store { i64, ptr } %t574, ptr %l299, !tbaa !27
  %t575 = load i64, ptr %l2, !tbaa !24
  %t577 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr ptr, ptr %t578, i64 %t575
  %t580 = load ptr, ptr %t579, !tbaa !39
  %t584 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efilledNext(ptr %v0, ptr %v1, ptr %t560, i32 %t570, ptr %t580)
  store i1 %t584, ptr %l302
  br label %bb127
bb126:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb128
bb127:
  %t585 = load i1, ptr %l302, !tbaa !21
  store i1 %t585, ptr %l292, !tbaa !21
  br label %bb128
bb128:
  %t586 = load i1, ptr %l292, !tbaa !21
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/check:Checker", ptr %t587, i32 0, i32 148
  store i1 %t586, ptr %t591, !tbaa !21
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t594 = getelementptr %"compiler/check:Checker", ptr %t592, i32 0, i32 16
  %t595 = load i32, ptr %t594, !tbaa !23
  store i32 %t595, ptr %l16, !tbaa !23
  %t597 = load ptr, ptr %l1, !tbaa !29
  %t599 = getelementptr %"compiler/ast:VarDecl", ptr %t597, i32 0, i32 5
  %t600 = load i1, ptr %t599, !tbaa !21
  %t602 = xor i1 %t600, true
  br i1 %t602, label %bb129, label %bb130
bb129:
  %t604 = load ptr, ptr %l1, !tbaa !29
  %t606 = getelementptr %"compiler/ast:VarDecl", ptr %t604, i32 0, i32 3
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !27
  store { i64, ptr } %t607, ptr %l312, !tbaa !27
  %t608 = load i64, ptr %l2, !tbaa !24
  %t610 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = getelementptr ptr, ptr %t611, i64 %t608
  %t613 = load ptr, ptr %t612, !tbaa !39
  store ptr %t613, ptr %l314, !tbaa !29
  store i1 false, ptr %l315, !tbaa !21
  %t614 = load ptr, ptr %l314, !tbaa !29
  %t615 = icmp ne ptr %t614, null
  br i1 %t615, label %bb131, label %bb132
bb130:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb133
bb131:
  %t617 = load ptr, ptr %l314, !tbaa !29
  %t618 = load i64, ptr %t617, !range !{i64 0, i64 28}
  %t620 = icmp eq i64 %t618, 20
  store i1 %t620, ptr %l315, !tbaa !21
  br label %bb132
bb132:
  %t621 = load i1, ptr %l315, !tbaa !21
  store i1 %t621, ptr %l310, !tbaa !21
  br label %bb133
bb133:
  %t622 = load i1, ptr %l310, !tbaa !21
  br i1 %t622, label %bb134, label %bb135
bb134:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load ptr, ptr %l1, !tbaa !29
  %t626 = getelementptr %"compiler/ast:VarDecl", ptr %t624, i32 0, i32 0
  %t627 = load { i64, ptr }, ptr %t626, !tbaa !27
  store { i64, ptr } %t627, ptr %l320, !tbaa !27
  %t628 = load i64, ptr %l2, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l320, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr i32, ptr %t631, i64 %t628
  %t633 = load i32, ptr %t632, !tbaa !33
  %t636 = getelementptr %"compiler/check:Checker", ptr %t623, i32 0, i32 16
  store i32 %t633, ptr %t636, !tbaa !23
  br label %bb136
bb135:
  br label %bb136
bb136:
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load ptr, ptr %l1, !tbaa !29
  %t640 = getelementptr %"compiler/ast:VarDecl", ptr %t638, i32 0, i32 3
  %t641 = load { i64, ptr }, ptr %t640, !tbaa !27
  store { i64, ptr } %t641, ptr %l325, !tbaa !27
  %t642 = load i64, ptr %l2, !tbaa !24
  %t644 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !27
  %t646 = getelementptr ptr, ptr %t645, i64 %t642
  %t647 = load ptr, ptr %t646, !tbaa !39
  %t648 = load i32, ptr %l12, !tbaa !23
  %t652 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t637, ptr %t647, i32 %t648)
  store ptr %t652, ptr %l329
  br label %bb137
bb137:
  %t653 = load ptr, ptr %l329, !tbaa !29
  store ptr %t653, ptr %l8, !tbaa !29
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t656 = load i32, ptr %l16, !tbaa !23
  %t659 = getelementptr %"compiler/check:Checker", ptr %t655, i32 0, i32 16
  store i32 %t656, ptr %t659, !tbaa !23
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t662 = getelementptr %"compiler/check:Checker", ptr %t660, i32 0, i32 148
  store i1 false, ptr %t662, !tbaa !21
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load { i64, [3 x i64] }, ptr %l14
  %t667 = getelementptr %"compiler/check:Checker", ptr %t663, i32 0, i32 18
  store { i64, [3 x i64] } %t664, ptr %t667
  %t668 = load ptr, ptr %l1, !tbaa !29
  %t670 = getelementptr %"compiler/ast:VarDecl", ptr %t668, i32 0, i32 2
  %t671 = load ptr, ptr %t670, !tbaa !29
  %t673 = icmp eq ptr %t671, null
  br i1 %t673, label %bb138, label %bb139
bb138:
  store i1 true, ptr %l339, !tbaa !21
  br label %bb140
bb139:
  %t675 = load ptr, ptr %l1, !tbaa !29
  %t677 = getelementptr %"compiler/ast:VarDecl", ptr %t675, i32 0, i32 4
  %t678 = load i1, ptr %t677, !tbaa !21
  store i1 %t678, ptr %l339, !tbaa !21
  br label %bb140
bb140:
  %t680 = load i1, ptr %l339, !tbaa !21
  br i1 %t680, label %bb141, label %bb142
bb141:
  %t681 = load ptr, ptr %l0, !tbaa !29
  store ptr %t681, ptr %l342, !tbaa !29
  %t682 = load ptr, ptr %l1, !tbaa !29
  %t684 = getelementptr %"compiler/ast:VarDecl", ptr %t682, i32 0, i32 3
  %t685 = load { i64, ptr }, ptr %t684, !tbaa !27
  store { i64, ptr } %t685, ptr %l344, !tbaa !27
  %t686 = load i64, ptr %l2, !tbaa !24
  %t688 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !27
  %t690 = getelementptr ptr, ptr %t689, i64 %t686
  %t691 = load ptr, ptr %t690, !tbaa !39
  store ptr %t691, ptr %l346, !tbaa !29
  %t692 = load ptr, ptr %l8, !tbaa !29
  %t694 = icmp eq ptr %t692, null
  br i1 %t694, label %bb143, label %bb144
bb142:
  br label %bb191
bb143:
  call void @__olang_check_failed(ptr @olang_loc_ba7201cf019a5b45_d1ff0f9e11a3d721)
  unreachable
bb144:
  br label %bb145
bb145:
  %t696 = load ptr, ptr %l8, !tbaa !29
  %t697 = load i1, ptr %l11, !tbaa !21
  %t698 = load ptr, ptr %l342, !tbaa !29
  %t699 = load ptr, ptr %l346, !tbaa !29
  %t702 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t698, ptr %t699, ptr %t696, i1 %t697)
  store i32 %t702, ptr %l351
  br label %bb146
bb146:
  %t703 = load i32, ptr %l351, !tbaa !23
  store i32 %t703, ptr %l7, !tbaa !23
  %t704 = load ptr, ptr %l8, !tbaa !29
  %t706 = icmp eq ptr %t704, null
  br i1 %t706, label %bb147, label %bb148
bb147:
  call void @__olang_check_failed(ptr @olang_loc_670b6c8fdf0e169e_19408787ee47819a)
  unreachable
bb148:
  br label %bb149
bb149:
  %t708 = load ptr, ptr %l8, !tbaa !29
  %t710 = call ptr @compiler_2fcheck_2eheldValue(ptr %v0, ptr %v0, ptr %t708)
  store ptr %t710, ptr %l355
  br label %bb150
bb150:
  %t711 = load ptr, ptr %l355, !tbaa !29
  store ptr %t711, ptr %l17, !tbaa !29
  %t712 = load ptr, ptr %l17, !tbaa !29
  %t714 = icmp eq ptr %t712, null
  %t716 = xor i1 %t714, true
  br i1 %t716, label %bb151, label %bb152
bb151:
  %t718 = load ptr, ptr %l0, !tbaa !29
  store ptr %t718, ptr %l360, !tbaa !29
  %t719 = load ptr, ptr %l17, !tbaa !29
  %t722 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t719)
  store i32 %t722, ptr %l363
  br label %bb153
bb152:
  store i1 false, ptr %l359, !tbaa !21
  br label %bb155
bb153:
  %t723 = load ptr, ptr %l360, !tbaa !29
  %t724 = load i32, ptr %l363, !tbaa !23
  %t725 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %t723, i32 %t724)
  store i1 %t725, ptr %l364
  br label %bb154
bb154:
  %t726 = load i1, ptr %l364, !tbaa !21
  store i1 %t726, ptr %l359, !tbaa !21
  br label %bb155
bb155:
  %t727 = load i1, ptr %l359, !tbaa !21
  br i1 %t727, label %bb156, label %bb157
bb156:
  %t728 = load ptr, ptr %l17, !tbaa !29
  store ptr %t728, ptr %l8, !tbaa !29
  %t731 = load ptr, ptr %l17, !tbaa !29
  %t734 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t731)
  store i32 %t734, ptr %l369
  br label %bb158
bb157:
  br label %bb159
bb158:
  %t735 = load i32, ptr %l369, !tbaa !23
  store i32 %t735, ptr %l7, !tbaa !23
  %t736 = load ptr, ptr %l1, !tbaa !29
  %t738 = getelementptr %"compiler/ast:VarDecl", ptr %t736, i32 0, i32 5
  %t739 = load i1, ptr %t738, !tbaa !21
  %t741 = xor i1 %t739, true
  store i1 %t741, ptr %l9, !tbaa !21
  br label %bb159
bb159:
  %t743 = load ptr, ptr %l1, !tbaa !29
  %t745 = getelementptr %"compiler/ast:VarDecl", ptr %t743, i32 0, i32 5
  %t746 = load i1, ptr %t745, !tbaa !21
  br i1 %t746, label %bb160, label %bb161
bb160:
  %t748 = load ptr, ptr %l1, !tbaa !29
  %t750 = getelementptr %"compiler/ast:VarDecl", ptr %t748, i32 0, i32 2
  %t751 = load ptr, ptr %t750, !tbaa !29
  %t753 = icmp eq ptr %t751, null
  %t755 = xor i1 %t753, true
  store i1 %t755, ptr %l375, !tbaa !21
  br label %bb162
bb161:
  store i1 false, ptr %l375, !tbaa !21
  br label %bb162
bb162:
  %t757 = load i1, ptr %l375, !tbaa !21
  br i1 %t757, label %bb163, label %bb164
bb163:
  %t758 = load ptr, ptr %l0, !tbaa !29
  store ptr %t758, ptr %l380, !tbaa !29
  %t759 = load ptr, ptr %l1, !tbaa !29
  %t761 = getelementptr %"compiler/ast:VarDecl", ptr %t759, i32 0, i32 2
  %t762 = load ptr, ptr %t761, !tbaa !29
  %t764 = icmp eq ptr %t762, null
  br i1 %t764, label %bb165, label %bb166
bb164:
  br label %bb175
bb165:
  call void @__olang_check_failed(ptr @olang_loc_416f5d97ab935603_252f7809267b087)
  unreachable
bb166:
  br label %bb167
bb167:
  %t766 = load ptr, ptr %l1, !tbaa !29
  %t768 = getelementptr %"compiler/ast:VarDecl", ptr %t766, i32 0, i32 2
  %t769 = load ptr, ptr %t768, !tbaa !29
  %t770 = load i32, ptr %l7, !tbaa !23
  %t771 = load ptr, ptr %l380, !tbaa !29
  %t774 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t771, ptr %t769, i32 %t770)
  store %"compiler/source:Span" %t774, ptr %l387
  br label %bb168
bb168:
  %t775 = load %"compiler/source:Span", ptr %l387
  store %"compiler/source:Span" %t775, ptr %l18
  %t776 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t777 = load i32, ptr %t776, !tbaa !23
  %t779 = icmp sge i32 %t777, 0
  br i1 %t779, label %bb169, label %bb170
bb169:
  store %olang.scope zeroinitializer, ptr %s20
  %t781 = load ptr, ptr %l0, !tbaa !29
  store ptr %t781, ptr %l390, !tbaa !29
  %t782 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t782, ptr %l391
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load i32, ptr %l7, !tbaa !23
  %t787 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s20, ptr %t783, i32 %t784)
  store { i64, ptr } %t787, ptr %l394
  br label %bb171
bb170:
  br label %bb174
bb171:
  %t788 = load { i64, ptr }, ptr %l394, !tbaa !27
  %t790 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %s20, ptr %v0, { i64, ptr } %t788)
  store %"compiler/diagmsg:Msg" %t790, ptr %l396
  br label %bb172
bb172:
  %t791 = load ptr, ptr %l390, !tbaa !29
  %t792 = load %"compiler/source:Span", ptr %l391
  %t793 = load %"compiler/diagmsg:Msg", ptr %l396
  %t794 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t791, %"compiler/source:Span" %t792, %"compiler/diagmsg:Msg" %t793)
  store i64 %t794, ptr %l397
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s20)
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = getelementptr %"compiler/check:Checker", ptr %t795, i32 0, i32 1
  %t798 = load ptr, ptr %t797, !tbaa !29
  %t800 = getelementptr %"compiler/generic:Program", ptr %t798, i32 0, i32 2
  store ptr %t800, ptr %l400, !tbaa !29
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t802 = load i32, ptr %l7, !tbaa !23
  %t805 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t801, i32 %t802)
  store i32 %t805, ptr %l403
  br label %bb176
bb176:
  %t806 = load ptr, ptr %l400, !tbaa !29
  %t807 = load i32, ptr %l403, !tbaa !23
  %t808 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t806, i32 %t807)
  store i32 %t808, ptr %l404
  br label %bb177
bb177:
  %t809 = load i32, ptr %l404, !range !{i32 0, i32 33}
  %t811 = trunc i64 19 to i32
  %t812 = icmp eq i32 %t809, %t811
  br i1 %t812, label %bb178, label %bb179
bb178:
  %t814 = load ptr, ptr %l0, !tbaa !29
  %t816 = getelementptr %"compiler/check:Checker", ptr %t814, i32 0, i32 1
  %t817 = load ptr, ptr %t816, !tbaa !29
  %t819 = getelementptr %"compiler/generic:Program", ptr %t817, i32 0, i32 2
  store ptr %t819, ptr %l410, !tbaa !29
  %t820 = load i32, ptr %l7, !tbaa !23
  store i32 %t820, ptr %l411, !tbaa !23
  %t821 = load ptr, ptr %l8, !tbaa !29
  %t823 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t821)
  store i32 %t823, ptr %l413
  br label %bb180
bb179:
  store i1 false, ptr %l407, !tbaa !21
  br label %bb182
bb180:
  %t824 = load ptr, ptr %l410, !tbaa !29
  %t825 = load i32, ptr %l411, !tbaa !23
  %t826 = load i32, ptr %l413, !tbaa !23
  %t827 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t824, i32 %t825, i32 %t826)
  store i1 %t827, ptr %l414
  br label %bb181
bb181:
  %t828 = load i1, ptr %l414, !tbaa !21
  %t829 = xor i1 %t828, true
  store i1 %t829, ptr %l407, !tbaa !21
  br label %bb182
bb182:
  %t831 = load i1, ptr %l407, !tbaa !21
  br i1 %t831, label %bb183, label %bb184
bb183:
  %t832 = load ptr, ptr %l0, !tbaa !29
  store ptr %t832, ptr %l416, !tbaa !29
  %t833 = load ptr, ptr %l8, !tbaa !29
  %t835 = icmp eq ptr %t833, null
  br i1 %t835, label %bb185, label %bb186
bb184:
  br label %bb190
bb185:
  call void @__olang_check_failed(ptr @olang_loc_31a8bd4d82790674_3781f3f0c2055368)
  unreachable
bb186:
  br label %bb187
bb187:
  %t837 = load ptr, ptr %l8, !tbaa !29
  store ptr %t837, ptr %l419, !tbaa !29
  %t838 = load i32, ptr %l7, !tbaa !23
  store i32 %t838, ptr %l420, !tbaa !23
  %t839 = load ptr, ptr %l1, !tbaa !29
  %t841 = getelementptr %"compiler/ast:VarDecl", ptr %t839, i32 0, i32 3
  %t842 = load { i64, ptr }, ptr %t841, !tbaa !27
  store { i64, ptr } %t842, ptr %l422, !tbaa !27
  %t843 = load i64, ptr %l2, !tbaa !24
  %t845 = getelementptr { i64, ptr }, ptr %l422, i32 0, i32 1
  %t846 = load ptr, ptr %t845, !tbaa !27
  %t847 = getelementptr ptr, ptr %t846, i64 %t843
  %t848 = load ptr, ptr %t847, !tbaa !39
  %t850 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t848)
  store %"compiler/source:Span" %t850, ptr %l425
  br label %bb188
bb188:
  %t851 = load ptr, ptr %l416, !tbaa !29
  %t852 = load ptr, ptr %l419, !tbaa !29
  %t853 = load i32, ptr %l420, !tbaa !23
  %t854 = load %"compiler/source:Span", ptr %l425
  %t855 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t851, ptr %t852, i32 %t853, %"compiler/source:Span" %t854)
  store ptr %t855, ptr %l426
  br label %bb189
bb189:
  %t856 = load ptr, ptr %l426, !tbaa !29
  store ptr %t856, ptr %l8, !tbaa !29
  br label %bb190
bb190:
  br label %bb191
bb191:
  br label %bb193
bb192:
  %t858 = load { ptr, %"compiler/check:unsetCand" }, ptr %l432
  store { ptr, %"compiler/check:unsetCand" } %t858, ptr %l19
  %t859 = getelementptr { ptr, %"compiler/check:unsetCand" }, ptr %l19, i32 0, i32 0
  %t860 = load ptr, ptr %t859, !tbaa !29
  store ptr %t860, ptr %l8, !tbaa !29
  %t863 = getelementptr { ptr, %"compiler/check:unsetCand" }, ptr %l19, i32 0, i32 1
  %t864 = load %"compiler/check:unsetCand", ptr %t863
  store %"compiler/check:unsetCand" %t864, ptr %l10
  br label %bb193
bb193:
  br label %bb194
bb194:
  br label %bb195
bb195:
  br label %bb196
bb196:
  %t866 = load ptr, ptr %l1, !tbaa !29
  %t868 = getelementptr %"compiler/ast:VarDecl", ptr %t866, i32 0, i32 6
  %t869 = load i1, ptr %t868, !tbaa !21
  %t871 = xor i1 %t869, true
  br i1 %t871, label %bb197, label %bb198
bb197:
  %t873 = load ptr, ptr %l1, !tbaa !29
  %t875 = getelementptr %"compiler/ast:VarDecl", ptr %t873, i32 0, i32 5
  %t876 = load i1, ptr %t875, !tbaa !21
  %t878 = xor i1 %t876, true
  store i1 %t878, ptr %l439, !tbaa !21
  br label %bb199
bb198:
  store i1 false, ptr %l439, !tbaa !21
  br label %bb199
bb199:
  %t880 = load i1, ptr %l439, !tbaa !21
  br i1 %t880, label %bb200, label %bb201
bb200:
  %t881 = load ptr, ptr %l1, !tbaa !29
  %t883 = getelementptr %"compiler/ast:VarDecl", ptr %t881, i32 0, i32 2
  %t884 = load ptr, ptr %t883, !tbaa !29
  %t886 = icmp eq ptr %t884, null
  store i1 %t886, ptr %l443, !tbaa !21
  br label %bb202
bb201:
  store i1 false, ptr %l443, !tbaa !21
  br label %bb202
bb202:
  %t888 = load i1, ptr %l443, !tbaa !21
  br i1 %t888, label %bb203, label %bb204
bb203:
  %t889 = load i64, ptr %l2, !tbaa !24
  %t890 = load ptr, ptr %l1, !tbaa !29
  %t892 = getelementptr %"compiler/ast:VarDecl", ptr %t890, i32 0, i32 3
  %t893 = load { i64, ptr }, ptr %t892, !tbaa !27
  %t895 = extractvalue { i64, ptr } %t893, 0
  %t898 = icmp slt i64 %t889, %t895
  store i1 %t898, ptr %l447, !tbaa !21
  br label %bb205
bb204:
  store i1 false, ptr %l447, !tbaa !21
  br label %bb205
bb205:
  %t900 = load i1, ptr %l447, !tbaa !21
  br i1 %t900, label %bb206, label %bb207
bb206:
  %t901 = load ptr, ptr %l1, !tbaa !29
  %t903 = getelementptr %"compiler/ast:VarDecl", ptr %t901, i32 0, i32 0
  %t904 = load { i64, ptr }, ptr %t903, !tbaa !27
  %t906 = extractvalue { i64, ptr } %t904, 0
  %t908 = icmp eq i64 %t906, 1
  store i1 %t908, ptr %l453, !tbaa !21
  br label %bb208
bb207:
  store i1 false, ptr %l453, !tbaa !21
  br label %bb208
bb208:
  %t910 = load i1, ptr %l453, !tbaa !21
  br i1 %t910, label %bb209, label %bb210
bb209:
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t912 = load i32, ptr %l7, !tbaa !23
  %t915 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t911, i32 %t912)
  store i1 %t915, ptr %l461
  br label %bb211
bb210:
  store i1 false, ptr %l458, !tbaa !21
  br label %bb212
bb211:
  %t916 = load i1, ptr %l461, !tbaa !21
  store i1 %t916, ptr %l458, !tbaa !21
  br label %bb212
bb212:
  %t917 = load i1, ptr %l458, !tbaa !21
  br i1 %t917, label %bb213, label %bb214
bb213:
  %t918 = load ptr, ptr %l0, !tbaa !29
  store ptr %t918, ptr %l463, !tbaa !29
  %t919 = load ptr, ptr %l8, !tbaa !29
  %t921 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t919)
  store i32 %t921, ptr %l465
  br label %bb215
bb214:
  store i1 false, ptr %l462, !tbaa !21
  br label %bb217
bb215:
  %t922 = load ptr, ptr %l463, !tbaa !29
  %t923 = load i32, ptr %l465, !tbaa !23
  %t924 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t922, i32 %t923)
  store i1 %t924, ptr %l466
  br label %bb216
bb216:
  %t925 = load i1, ptr %l466, !tbaa !21
  store i1 %t925, ptr %l462, !tbaa !21
  br label %bb217
bb217:
  %t926 = load i1, ptr %l462, !tbaa !21
  br i1 %t926, label %bb218, label %bb219
bb218:
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t928 = load i32, ptr %l7, !tbaa !23
  %t931 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargRef(ptr %v0, ptr %t927, i32 %t928)
  store i1 %t931, ptr %l470
  br label %bb220
bb219:
  store i1 false, ptr %l467, !tbaa !21
  br label %bb221
bb220:
  %t932 = load i1, ptr %l470, !tbaa !21
  %t933 = xor i1 %t932, true
  store i1 %t933, ptr %l467, !tbaa !21
  br label %bb221
bb221:
  %t935 = load i1, ptr %l467, !tbaa !21
  br i1 %t935, label %bb222, label %bb223
bb222:
  %t936 = load ptr, ptr %l8, !tbaa !29
  %t938 = icmp eq ptr %t936, null
  br i1 %t938, label %bb224, label %bb225
bb223:
  store i1 false, ptr %l472, !tbaa !21
  br label %bb228
bb224:
  call void @__olang_check_failed(ptr @olang_loc_d0d18e793a787969_e89e213e76d783d)
  unreachable
bb225:
  br label %bb226
bb226:
  %t940 = load ptr, ptr %l8, !tbaa !29
  %t942 = call i1 @compiler_2fcheck_2efreshValue(ptr %v0, ptr %t940)
  store i1 %t942, ptr %l476
  br label %bb227
bb227:
  %t943 = load i1, ptr %l476, !tbaa !21
  %t944 = xor i1 %t943, true
  store i1 %t944, ptr %l472, !tbaa !21
  br label %bb228
bb228:
  %t946 = load i1, ptr %l472, !tbaa !21
  br i1 %t946, label %bb229, label %bb230
bb229:
  %t947 = load ptr, ptr %l0, !tbaa !29
  %t948 = load ptr, ptr %l1, !tbaa !29
  %t950 = getelementptr %"compiler/ast:VarDecl", ptr %t948, i32 0, i32 3
  %t951 = load { i64, ptr }, ptr %t950, !tbaa !27
  store { i64, ptr } %t951, ptr %l481, !tbaa !27
  %t952 = load i64, ptr %l2, !tbaa !24
  %t954 = getelementptr { i64, ptr }, ptr %l481, i32 0, i32 1
  %t955 = load ptr, ptr %t954, !tbaa !27
  %t956 = getelementptr ptr, ptr %t955, i64 %t952
  %t957 = load ptr, ptr %t956, !tbaa !39
  %t960 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efreshWritten(ptr %v0, ptr %v1, ptr %t947, ptr %t957)
  store i1 %t960, ptr %l484
  br label %bb231
bb230:
  store i1 false, ptr %l478, !tbaa !21
  br label %bb232
bb231:
  %t961 = load i1, ptr %l484, !tbaa !21
  %t962 = xor i1 %t961, true
  store i1 %t962, ptr %l478, !tbaa !21
  br label %bb232
bb232:
  %t964 = load i1, ptr %l478, !tbaa !21
  br i1 %t964, label %bb233, label %bb234
bb233:
  %t965 = load ptr, ptr %l1, !tbaa !29
  %t967 = getelementptr %"compiler/ast:VarDecl", ptr %t965, i32 0, i32 3
  %t968 = load { i64, ptr }, ptr %t967, !tbaa !27
  store { i64, ptr } %t968, ptr %l487, !tbaa !27
  %t969 = load i64, ptr %l2, !tbaa !24
  %t971 = getelementptr { i64, ptr }, ptr %l487, i32 0, i32 1
  %t972 = load ptr, ptr %t971, !tbaa !27
  %t973 = getelementptr ptr, ptr %t972, i64 %t969
  %t974 = load ptr, ptr %t973, !tbaa !39
  %t976 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t974)
  store %"compiler/source:Span" %t976, ptr %l490
  br label %bb235
bb234:
  br label %bb268
bb235:
  %t977 = load %"compiler/source:Span", ptr %l490
  store %"compiler/source:Span" %t977, ptr %l20
  %t978 = load ptr, ptr %l0, !tbaa !29
  %t980 = getelementptr %"compiler/check:Checker", ptr %t978, i32 0, i32 1
  %t981 = load ptr, ptr %t980, !tbaa !29
  %t983 = getelementptr %"compiler/generic:Program", ptr %t981, i32 0, i32 2
  store ptr %t983, ptr %l493, !tbaa !29
  %t984 = load ptr, ptr %l8, !tbaa !29
  %t986 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t984)
  store i32 %t986, ptr %l495
  br label %bb236
bb236:
  %t987 = load ptr, ptr %l493, !tbaa !29
  %t988 = load i32, ptr %l495, !tbaa !23
  %t989 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t987, i32 %t988)
  store i1 %t989, ptr %l496
  br label %bb237
bb237:
  %t990 = load i1, ptr %l496, !tbaa !21
  br i1 %t990, label %bb238, label %bb239
bb238:
  store %olang.scope zeroinitializer, ptr %s24
  %t991 = load ptr, ptr %l0, !tbaa !29
  store ptr %t991, ptr %l497, !tbaa !29
  %t992 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t992, ptr %l498
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load %"compiler/source:Span", ptr %l20
  %t997 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t993, %"compiler/source:Span" %t994)
  store { i64, ptr } %t997, ptr %l501
  br label %bb240
bb239:
  %t998 = load ptr, ptr %l0, !tbaa !29
  store ptr %t998, ptr %l516, !tbaa !29
  %t999 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t999, ptr %l517
  %t1000 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t1000, ptr %l518
  %t1001 = load ptr, ptr %l0, !tbaa !29
  %t1003 = getelementptr %"compiler/check:Checker", ptr %t1001, i32 0, i32 1
  %t1004 = load ptr, ptr %t1003, !tbaa !29
  %t1006 = getelementptr %"compiler/generic:Program", ptr %t1004, i32 0, i32 2
  store ptr %t1006, ptr %l521, !tbaa !29
  %t1007 = load ptr, ptr %l8, !tbaa !29
  %t1009 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1007)
  store i32 %t1009, ptr %l523
  br label %bb247
bb240:
  %t1010 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1010, ptr %l502, !tbaa !29
  %t1011 = load ptr, ptr %l8, !tbaa !29
  %t1013 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1011)
  store i32 %t1013, ptr %l504
  br label %bb241
bb241:
  %t1014 = load ptr, ptr %l502, !tbaa !29
  %t1015 = load i32, ptr %l504, !tbaa !23
  %t1016 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t1014, i32 %t1015)
  store { i64, ptr } %t1016, ptr %l505
  br label %bb242
bb242:
  %t1017 = load { i64, ptr }, ptr %l505, !tbaa !27
  store { i64, ptr } %t1017, ptr %l506, !tbaa !27
  %t1018 = load ptr, ptr %l0, !tbaa !29
  %t1019 = load %"compiler/source:Span", ptr %l20
  %t1022 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t1018, %"compiler/source:Span" %t1019)
  store { i64, ptr } %t1022, ptr %l509
  br label %bb243
bb243:
  %t1023 = load { i64, ptr }, ptr %l509, !tbaa !27
  %t1024 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s24, { i64, ptr } %t1023)
  store { i64, ptr } %t1024, ptr %l510
  br label %bb244
bb244:
  %t1025 = load { i64, ptr }, ptr %l510, !tbaa !27
  %t1026 = extractvalue { i64, ptr } %t1025, 0
  store i64 %t1026, ptr %l511, !tbaa !24
  %t1027 = load i64, ptr %l511, !tbaa !24
  %t1028 = mul i64 %t1027, 1
  %t1029 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t1028)
  %t1030 = insertvalue { i64, ptr } undef, i64 %t1027, 0
  %t1031 = insertvalue { i64, ptr } %t1030, ptr %t1029, 1
  store { i64, ptr } %t1031, ptr %l512, !tbaa !27
  %t1032 = getelementptr { i64, ptr }, ptr %l512, i32 0, i32 1
  %t1033 = load ptr, ptr %t1032, !tbaa !27
  %t1034 = getelementptr { i64, ptr }, ptr %l510, i32 0, i32 1
  %t1035 = load ptr, ptr %t1034, !tbaa !27
  %t1036 = load i64, ptr %l511, !tbaa !24
  %t1037 = mul i64 %t1036, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1033, ptr %t1035, i64 %t1037, i1 false)
  %t1038 = load { i64, ptr }, ptr %l512, !tbaa !27
  %t1039 = extractvalue { i64, ptr } %t1038, 0
  %t1040 = extractvalue { i64, ptr } %t1038, 1
  %t1041 = mul i64 %t1039, 1
  %t1042 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t1041)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1042, ptr %t1040, i64 %t1041, i1 false)
  %t1043 = insertvalue { i64, ptr } undef, i64 %t1039, 0
  %t1044 = insertvalue { i64, ptr } %t1043, ptr %t1042, 1
  %t1045 = load { i64, ptr }, ptr %l501, !tbaa !27
  %t1046 = load { i64, ptr }, ptr %l506, !tbaa !27
  %t1048 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s24, ptr %s24, ptr %v0, ptr %v0, { i64, ptr } %t1045, { i64, ptr } %t1046, { i64, ptr } %t1044, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t1048, ptr %l514
  br label %bb245
bb245:
  %t1049 = load ptr, ptr %l497, !tbaa !29
  %t1050 = load %"compiler/source:Span", ptr %l498
  %t1051 = load %"compiler/diagmsg:Msg", ptr %l514
  %t1052 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1049, %"compiler/source:Span" %t1050, %"compiler/diagmsg:Msg" %t1051)
  store i64 %t1052, ptr %l515
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s24)
  br label %bb267
bb247:
  %t1053 = load ptr, ptr %l521, !tbaa !29
  %t1054 = load i32, ptr %l523, !tbaa !23
  %t1055 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1053, i32 %t1054)
  store i32 %t1055, ptr %l524
  br label %bb248
bb248:
  %t1056 = load ptr, ptr %l8, !tbaa !29
  %t1058 = icmp eq ptr %t1056, null
  br i1 %t1058, label %bb249, label %bb250
bb249:
  call void @__olang_check_failed(ptr @olang_loc_78d0351a8836f282_d675d63765080c56)
  unreachable
bb250:
  br label %bb251
bb251:
  %t1060 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t1061
  %t1062 = getelementptr { i64, [4 x i64] }, ptr %t1061, i32 0, i32 0
  store i64 2, ptr %t1062
  %t1063 = load %"compiler/source:Span", ptr %l518
  %t1064 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1063, 0
  %t1065 = load i32, ptr %l524, !tbaa !23
  %t1066 = insertvalue { %"compiler/source:Span", i32, ptr } %t1064, i32 %t1065, 1
  %t1068 = insertvalue { %"compiler/source:Span", i32, ptr } %t1066, ptr %t1060, 2
  %t1069 = getelementptr { i64, [4 x i64] }, ptr %t1061, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1068, ptr %t1069
  %t1070 = load { i64, [4 x i64] }, ptr %t1061
  %t1072 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1070, ptr %t1072
  %t1073 = load ptr, ptr %l516, !tbaa !29
  %t1074 = load %"compiler/source:Span", ptr %l517
  %t1076 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t1073, %"compiler/source:Span" %t1074, ptr %t1072)
  store ptr %t1076, ptr %l530
  br label %bb252
bb252:
  %t1077 = load ptr, ptr %l530, !tbaa !29
  store ptr %t1077, ptr %l8, !tbaa !29
  %t1079 = load ptr, ptr %l0, !tbaa !29
  %t1080 = load ptr, ptr %l1, !tbaa !29
  %t1082 = getelementptr %"compiler/ast:VarDecl", ptr %t1080, i32 0, i32 3
  %t1083 = load { i64, ptr }, ptr %t1082, !tbaa !27
  store { i64, ptr } %t1083, ptr %l534, !tbaa !27
  %t1084 = load i64, ptr %l2, !tbaa !24
  %t1086 = getelementptr { i64, ptr }, ptr %l534, i32 0, i32 1
  %t1087 = load ptr, ptr %t1086, !tbaa !27
  %t1088 = getelementptr ptr, ptr %t1087, i64 %t1084
  %t1089 = load ptr, ptr %t1088, !tbaa !39
  %t1090 = load ptr, ptr %l8, !tbaa !29
  %t1091 = load i1, ptr %l11, !tbaa !21
  %t1096 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t1079, ptr %t1089, ptr %t1090, i1 %t1091)
  store i32 %t1096, ptr %l539
  br label %bb253
bb253:
  %t1097 = load i32, ptr %l539, !tbaa !23
  store i32 %t1097, ptr %l7, !tbaa !23
  %t1098 = load ptr, ptr %l0, !tbaa !29
  %t1100 = getelementptr %"compiler/check:Checker", ptr %t1098, i32 0, i32 1
  %t1101 = load ptr, ptr %t1100, !tbaa !29
  %t1103 = getelementptr %"compiler/generic:Program", ptr %t1101, i32 0, i32 2
  %t1104 = load i32, ptr %l7, !tbaa !23
  %t1107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1103, i32 %t1104)
  store i32 %t1107, ptr %l544
  br label %bb254
bb254:
  %t1108 = load i32, ptr %l544, !range !{i32 0, i32 33}
  %t1110 = trunc i64 19 to i32
  %t1111 = icmp eq i32 %t1108, %t1110
  br i1 %t1111, label %bb255, label %bb256
bb255:
  %t1113 = load ptr, ptr %l0, !tbaa !29
  %t1115 = getelementptr %"compiler/check:Checker", ptr %t1113, i32 0, i32 1
  %t1116 = load ptr, ptr %t1115, !tbaa !29
  %t1118 = getelementptr %"compiler/generic:Program", ptr %t1116, i32 0, i32 2
  store ptr %t1118, ptr %l550, !tbaa !29
  %t1119 = load i32, ptr %l7, !tbaa !23
  store i32 %t1119, ptr %l551, !tbaa !23
  %t1120 = load ptr, ptr %l8, !tbaa !29
  %t1122 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1120)
  store i32 %t1122, ptr %l553
  br label %bb257
bb256:
  store i1 false, ptr %l547, !tbaa !21
  br label %bb259
bb257:
  %t1123 = load ptr, ptr %l550, !tbaa !29
  %t1124 = load i32, ptr %l551, !tbaa !23
  %t1125 = load i32, ptr %l553, !tbaa !23
  %t1126 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t1123, i32 %t1124, i32 %t1125)
  store i1 %t1126, ptr %l554
  br label %bb258
bb258:
  %t1127 = load i1, ptr %l554, !tbaa !21
  %t1128 = xor i1 %t1127, true
  store i1 %t1128, ptr %l547, !tbaa !21
  br label %bb259
bb259:
  %t1130 = load i1, ptr %l547, !tbaa !21
  br i1 %t1130, label %bb260, label %bb261
bb260:
  %t1131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1131, ptr %l556, !tbaa !29
  %t1132 = load ptr, ptr %l8, !tbaa !29
  %t1134 = icmp eq ptr %t1132, null
  br i1 %t1134, label %bb262, label %bb263
bb261:
  br label %bb266
bb262:
  call void @__olang_check_failed(ptr @olang_loc_457623a9c758d3c7_b05c0b7da85964c3)
  unreachable
bb263:
  br label %bb264
bb264:
  %t1136 = load ptr, ptr %l8, !tbaa !29
  %t1137 = load i32, ptr %l7, !tbaa !23
  %t1138 = load %"compiler/source:Span", ptr %l20
  %t1139 = load ptr, ptr %l556, !tbaa !29
  %t1143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t1139, ptr %t1136, i32 %t1137, %"compiler/source:Span" %t1138)
  store ptr %t1143, ptr %l562
  br label %bb265
bb265:
  %t1144 = load ptr, ptr %l562, !tbaa !29
  store ptr %t1144, ptr %l8, !tbaa !29
  br label %bb266
bb266:
  br label %bb267
bb267:
  br label %bb268
bb268:
  %t1146 = load i32, ptr %l7, !tbaa !23
  store i32 %t1146, ptr %l564, !tbaa !23
  %t1147 = load ptr, ptr %l0, !tbaa !29
  %t1149 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t1147)
  store i32 %t1149, ptr %l566
  br label %bb269
bb269:
  %t1150 = load i32, ptr %l564, !tbaa !23
  %t1151 = load i32, ptr %l566, !tbaa !23
  %t1152 = icmp eq i32 %t1150, %t1151
  br i1 %t1152, label %bb270, label %bb271
bb270:
  %t1154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1154, ptr %l569, !tbaa !29
  %t1155 = load ptr, ptr %l8, !tbaa !29
  %t1157 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1155)
  store i32 %t1157, ptr %l571
  br label %bb272
bb271:
  store i1 false, ptr %l568, !tbaa !21
  br label %bb274
bb272:
  %t1158 = load ptr, ptr %l569, !tbaa !29
  %t1159 = load i32, ptr %l571, !tbaa !23
  %t1160 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1158, i32 %t1159)
  store i1 %t1160, ptr %l572
  br label %bb273
bb273:
  %t1161 = load i1, ptr %l572, !tbaa !21
  store i1 %t1161, ptr %l568, !tbaa !21
  br label %bb274
bb274:
  %t1162 = load i1, ptr %l568, !tbaa !21
  br i1 %t1162, label %bb275, label %bb276
bb275:
  %t1163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1163, ptr %l573, !tbaa !29
  %t1164 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t1164, ptr %l574
  %t1165 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t1165, ptr %l575
  %t1166 = load i32, ptr %l7, !tbaa !23
  store i32 %t1166, ptr %l576, !tbaa !23
  %t1167 = load ptr, ptr %l8, !tbaa !29
  %t1169 = icmp eq ptr %t1167, null
  br i1 %t1169, label %bb277, label %bb278
bb276:
  br label %bb281
bb277:
  call void @__olang_check_failed(ptr @olang_loc_68b39597279db2a8_7d3f350750fe5f34)
  unreachable
bb278:
  br label %bb279
bb279:
  %t1171 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t1172
  %t1173 = getelementptr { i64, [4 x i64] }, ptr %t1172, i32 0, i32 0
  store i64 2, ptr %t1173
  %t1174 = load %"compiler/source:Span", ptr %l575
  %t1175 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1174, 0
  %t1176 = load i32, ptr %l576, !tbaa !23
  %t1177 = insertvalue { %"compiler/source:Span", i32, ptr } %t1175, i32 %t1176, 1
  %t1179 = insertvalue { %"compiler/source:Span", i32, ptr } %t1177, ptr %t1171, 2
  %t1180 = getelementptr { i64, [4 x i64] }, ptr %t1172, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1179, ptr %t1180
  %t1181 = load { i64, [4 x i64] }, ptr %t1172
  %t1183 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1181, ptr %t1183
  %t1184 = load ptr, ptr %l573, !tbaa !29
  %t1185 = load %"compiler/source:Span", ptr %l574
  %t1187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t1184, %"compiler/source:Span" %t1185, ptr %t1183)
  store ptr %t1187, ptr %l582
  br label %bb280
bb280:
  %t1188 = load ptr, ptr %l582, !tbaa !29
  store ptr %t1188, ptr %l8, !tbaa !29
  br label %bb281
bb281:
  %t1190 = load i64, ptr %l2, !tbaa !24
  %t1191 = load ptr, ptr %l1, !tbaa !29
  %t1193 = getelementptr %"compiler/ast:VarDecl", ptr %t1191, i32 0, i32 3
  %t1194 = load { i64, ptr }, ptr %t1193, !tbaa !27
  %t1196 = extractvalue { i64, ptr } %t1194, 0
  %t1199 = icmp slt i64 %t1190, %t1196
  br i1 %t1199, label %bb282, label %bb283
bb282:
  %t1201 = load ptr, ptr %l1, !tbaa !29
  %t1203 = getelementptr %"compiler/ast:VarDecl", ptr %t1201, i32 0, i32 2
  %t1204 = load ptr, ptr %t1203, !tbaa !29
  %t1206 = icmp eq ptr %t1204, null
  br i1 %t1206, label %bb284, label %bb285
bb283:
  store i1 false, ptr %l589, !tbaa !21
  br label %bb287
bb284:
  store i1 true, ptr %l593, !tbaa !21
  br label %bb286
bb285:
  %t1208 = load ptr, ptr %l1, !tbaa !29
  %t1210 = getelementptr %"compiler/ast:VarDecl", ptr %t1208, i32 0, i32 4
  %t1211 = load i1, ptr %t1210, !tbaa !21
  store i1 %t1211, ptr %l593, !tbaa !21
  br label %bb286
bb286:
  %t1213 = load i1, ptr %l593, !tbaa !21
  store i1 %t1213, ptr %l589, !tbaa !21
  br label %bb287
bb287:
  %t1214 = load i1, ptr %l589, !tbaa !21
  store i1 %t1214, ptr %l21, !tbaa !21
  store i1 false, ptr %l22, !tbaa !21
  %t1215 = load i64, ptr %l2, !tbaa !24
  %t1216 = load ptr, ptr %l1, !tbaa !29
  %t1218 = getelementptr %"compiler/ast:VarDecl", ptr %t1216, i32 0, i32 3
  %t1219 = load { i64, ptr }, ptr %t1218, !tbaa !27
  %t1221 = extractvalue { i64, ptr } %t1219, 0
  %t1224 = icmp slt i64 %t1215, %t1221
  br i1 %t1224, label %bb288, label %bb289
bb288:
  %t1226 = load ptr, ptr %l0, !tbaa !29
  %t1227 = load i32, ptr %l7, !tbaa !23
  %t1230 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1226, i32 %t1227)
  store i1 %t1230, ptr %l604
  br label %bb290
bb289:
  store i1 false, ptr %l601, !tbaa !21
  br label %bb291
bb290:
  %t1231 = load i1, ptr %l604, !tbaa !21
  %t1232 = xor i1 %t1231, true
  store i1 %t1232, ptr %l601, !tbaa !21
  br label %bb291
bb291:
  %t1234 = load i1, ptr %l601, !tbaa !21
  br i1 %t1234, label %bb292, label %bb293
bb292:
  %t1235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1235, ptr %l607, !tbaa !29
  %t1236 = load ptr, ptr %l8, !tbaa !29
  %t1238 = icmp eq ptr %t1236, null
  br i1 %t1238, label %bb294, label %bb295
bb293:
  store i1 false, ptr %l606, !tbaa !21
  br label %bb298
bb294:
  call void @__olang_check_failed(ptr @olang_loc_bb2f53ecd9453d1e_99003bb1ad581f22)
  unreachable
bb295:
  br label %bb296
bb296:
  %t1240 = load ptr, ptr %l8, !tbaa !29
  %t1241 = load ptr, ptr %l607, !tbaa !29
  %t1243 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v0, ptr %t1241, ptr %t1240)
  store i1 %t1243, ptr %l611
  br label %bb297
bb297:
  %t1244 = load i1, ptr %l611, !tbaa !21
  store i1 %t1244, ptr %l606, !tbaa !21
  br label %bb298
bb298:
  %t1245 = load i1, ptr %l606, !tbaa !21
  br i1 %t1245, label %bb299, label %bb300
bb299:
  %t1246 = load i1, ptr %l21, !tbaa !21
  br i1 %t1246, label %bb301, label %bb302
bb300:
  br label %bb322
bb301:
  %t1248 = load ptr, ptr %l1, !tbaa !29
  %t1250 = getelementptr %"compiler/ast:VarDecl", ptr %t1248, i32 0, i32 5
  %t1251 = load i1, ptr %t1250, !tbaa !21
  %t1253 = xor i1 %t1251, true
  store i1 %t1253, ptr %l613, !tbaa !21
  br label %bb303
bb302:
  store i1 false, ptr %l613, !tbaa !21
  br label %bb303
bb303:
  %t1255 = load i1, ptr %l613, !tbaa !21
  br i1 %t1255, label %bb304, label %bb305
bb304:
  %t1256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1256, ptr %l617, !tbaa !29
  %t1257 = load ptr, ptr %l8, !tbaa !29
  %t1259 = icmp eq ptr %t1257, null
  br i1 %t1259, label %bb306, label %bb307
bb305:
  store %olang.scope zeroinitializer, ptr %s30
  %t1261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1261, ptr %l631, !tbaa !29
  %t1262 = load ptr, ptr %l8, !tbaa !29
  %t1264 = icmp eq ptr %t1262, null
  br i1 %t1264, label %bb312, label %bb313
bb306:
  call void @__olang_check_failed(ptr @olang_loc_e95e92bfbd181c5_df64b77a5c642989)
  unreachable
bb307:
  br label %bb308
bb308:
  %t1266 = load ptr, ptr %l8, !tbaa !29
  store ptr %t1266, ptr %l620, !tbaa !29
  %t1267 = load ptr, ptr %l1, !tbaa !29
  %t1269 = getelementptr %"compiler/ast:VarDecl", ptr %t1267, i32 0, i32 3
  %t1270 = load { i64, ptr }, ptr %t1269, !tbaa !27
  store { i64, ptr } %t1270, ptr %l622, !tbaa !27
  %t1271 = load i64, ptr %l2, !tbaa !24
  %t1273 = getelementptr { i64, ptr }, ptr %l622, i32 0, i32 1
  %t1274 = load ptr, ptr %t1273, !tbaa !27
  %t1275 = getelementptr ptr, ptr %t1274, i64 %t1271
  %t1276 = load ptr, ptr %t1275, !tbaa !39
  %t1278 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1276)
  store %"compiler/source:Span" %t1278, ptr %l625
  br label %bb309
bb309:
  %t1279 = load ptr, ptr %l617, !tbaa !29
  %t1280 = load ptr, ptr %l620, !tbaa !29
  %t1281 = load %"compiler/source:Span", ptr %l625
  %t1282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v0, ptr %v0, ptr %t1279, ptr %t1280, %"compiler/source:Span" %t1281, i1 true, i1 false)
  store ptr %t1282, ptr %l626
  br label %bb310
bb310:
  %t1283 = load ptr, ptr %l626, !tbaa !29
  store ptr %t1283, ptr %l8, !tbaa !29
  %t1285 = load ptr, ptr %l8, !tbaa !29
  %t1288 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1285)
  store i32 %t1288, ptr %l630
  br label %bb311
bb311:
  %t1289 = load i32, ptr %l630, !tbaa !23
  store i32 %t1289, ptr %l7, !tbaa !23
  br label %bb321
bb312:
  call void @__olang_check_failed(ptr @olang_loc_f1a2b5bf4319ea70_a1020a03511bf894)
  unreachable
bb313:
  br label %bb314
bb314:
  %t1290 = load ptr, ptr %l8, !tbaa !29
  %t1291 = load ptr, ptr %l631, !tbaa !29
  %t1293 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueMoved(ptr %v0, ptr %v0, ptr %t1291, ptr %t1290)
  store i1 %t1293, ptr %l635
  br label %bb315
bb315:
  %t1294 = load i1, ptr %l635, !tbaa !21
  store i1 %t1294, ptr %l22, !tbaa !21
  %t1295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1295, ptr %l636, !tbaa !29
  %t1296 = load ptr, ptr %l8, !tbaa !29
  %t1298 = icmp eq ptr %t1296, null
  br i1 %t1298, label %bb316, label %bb317
bb316:
  call void @__olang_check_failed(ptr @olang_loc_2a0f33252d4f174f_5cf7e0fb34c443a3)
  unreachable
bb317:
  br label %bb318
bb318:
  %t1300 = load ptr, ptr %l8, !tbaa !29
  store ptr %t1300, ptr %l639, !tbaa !29
  %t1301 = load ptr, ptr %l0, !tbaa !29
  %t1302 = load ptr, ptr %l1, !tbaa !29
  %t1304 = getelementptr %"compiler/ast:VarDecl", ptr %t1302, i32 0, i32 0
  %t1305 = load { i64, ptr }, ptr %t1304, !tbaa !27
  store { i64, ptr } %t1305, ptr %l642, !tbaa !27
  %t1306 = load i64, ptr %l2, !tbaa !24
  %t1308 = getelementptr { i64, ptr }, ptr %l642, i32 0, i32 1
  %t1309 = load ptr, ptr %t1308, !tbaa !27
  %t1310 = getelementptr i32, ptr %t1309, i64 %t1306
  %t1311 = load i32, ptr %t1310, !tbaa !33
  %t1314 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s30, ptr %t1301, i32 %t1311)
  store { i64, ptr } %t1314, ptr %l645
  br label %bb319
bb319:
  %t1315 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t1316 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t1317 = load { i64, ptr }, ptr %l645, !tbaa !27
  %t1318 = extractvalue { i64, ptr } %t1317, 1
  %t1319 = extractvalue { i64, ptr } %t1317, 0
  %t1320 = add i64 %t1316, %t1319
  %t1321 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t1322 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t1323 = add i64 %t1320, %t1322
  %t1324 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1323)
  call void @olang_textcopy(ptr %t1324, ptr %t1315, i64 %t1316)
  %t1325 = getelementptr i8, ptr %t1324, i64 %t1316
  call void @olang_textcopy(ptr %t1325, ptr %t1318, i64 %t1319)
  %t1326 = getelementptr i8, ptr %t1325, i64 %t1319
  call void @olang_textcopy(ptr %t1326, ptr %t1321, i64 %t1322)
  %t1327 = insertvalue { i64, ptr } undef, i64 %t1323, 0
  %t1328 = insertvalue { i64, ptr } %t1327, ptr %t1324, 1
  %t1330 = load ptr, ptr %l636, !tbaa !29
  %t1331 = load ptr, ptr %l639, !tbaa !29
  %t1333 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1330, ptr %t1331, { i64, ptr } %t1328, i1 false)
  store ptr %t1333, ptr %l648
  br label %bb320
bb320:
  %t1334 = load ptr, ptr %l648, !tbaa !29
  store ptr %t1334, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s30)
  br label %bb321
bb321:
  br label %bb322
bb322:
  %t1336 = load i64, ptr %l2, !tbaa !24
  %t1337 = load ptr, ptr %l1, !tbaa !29
  %t1339 = getelementptr %"compiler/ast:VarDecl", ptr %t1337, i32 0, i32 3
  %t1340 = load { i64, ptr }, ptr %t1339, !tbaa !27
  %t1342 = extractvalue { i64, ptr } %t1340, 0
  %t1345 = icmp slt i64 %t1336, %t1342
  br i1 %t1345, label %bb323, label %bb324
bb323:
  %t1347 = load i1, ptr %l21, !tbaa !21
  store i1 %t1347, ptr %l655, !tbaa !21
  br label %bb325
bb324:
  store i1 false, ptr %l655, !tbaa !21
  br label %bb325
bb325:
  %t1349 = load i1, ptr %l655, !tbaa !21
  br i1 %t1349, label %bb326, label %bb327
bb326:
  %t1350 = load ptr, ptr %l1, !tbaa !29
  %t1352 = getelementptr %"compiler/ast:VarDecl", ptr %t1350, i32 0, i32 5
  %t1353 = load i1, ptr %t1352, !tbaa !21
  %t1355 = xor i1 %t1353, true
  store i1 %t1355, ptr %l657, !tbaa !21
  br label %bb328
bb327:
  store i1 false, ptr %l657, !tbaa !21
  br label %bb328
bb328:
  %t1357 = load i1, ptr %l657, !tbaa !21
  br i1 %t1357, label %bb329, label %bb330
bb329:
  %t1358 = load ptr, ptr %l0, !tbaa !29
  %t1359 = load i32, ptr %l7, !tbaa !23
  %t1362 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1358, i32 %t1359)
  store i1 %t1362, ptr %l664
  br label %bb331
bb330:
  store i1 false, ptr %l661, !tbaa !21
  br label %bb332
bb331:
  %t1363 = load i1, ptr %l664, !tbaa !21
  %t1364 = xor i1 %t1363, true
  store i1 %t1364, ptr %l661, !tbaa !21
  br label %bb332
bb332:
  %t1366 = load i1, ptr %l661, !tbaa !21
  br i1 %t1366, label %bb333, label %bb334
bb333:
  %t1367 = load ptr, ptr %l0, !tbaa !29
  %t1369 = getelementptr %"compiler/check:Checker", ptr %t1367, i32 0, i32 1
  %t1370 = load ptr, ptr %t1369, !tbaa !29
  %t1371 = load i32, ptr %l7, !tbaa !23
  %t1374 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %t1370, i32 %t1371)
  store i1 %t1374, ptr %l670
  br label %bb335
bb334:
  store i1 false, ptr %l666, !tbaa !21
  br label %bb336
bb335:
  %t1375 = load i1, ptr %l670, !tbaa !21
  store i1 %t1375, ptr %l666, !tbaa !21
  br label %bb336
bb336:
  %t1376 = load i1, ptr %l666, !tbaa !21
  br i1 %t1376, label %bb337, label %bb338
bb337:
  %t1377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1377, ptr %l671, !tbaa !29
  %t1378 = load ptr, ptr %l8, !tbaa !29
  %t1380 = icmp eq ptr %t1378, null
  br i1 %t1380, label %bb339, label %bb340
bb338:
  br label %bb345
bb339:
  call void @__olang_check_failed(ptr @olang_loc_ccf41c77826e1902_e65c37e3a9ba9be)
  unreachable
bb340:
  br label %bb341
bb341:
  %t1382 = load ptr, ptr %l8, !tbaa !29
  store ptr %t1382, ptr %l674, !tbaa !29
  %t1383 = load ptr, ptr %l1, !tbaa !29
  %t1385 = getelementptr %"compiler/ast:VarDecl", ptr %t1383, i32 0, i32 3
  %t1386 = load { i64, ptr }, ptr %t1385, !tbaa !27
  store { i64, ptr } %t1386, ptr %l676, !tbaa !27
  %t1387 = load i64, ptr %l2, !tbaa !24
  %t1389 = getelementptr { i64, ptr }, ptr %l676, i32 0, i32 1
  %t1390 = load ptr, ptr %t1389, !tbaa !27
  %t1391 = getelementptr ptr, ptr %t1390, i64 %t1387
  %t1392 = load ptr, ptr %t1391, !tbaa !39
  %t1394 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1392)
  store %"compiler/source:Span" %t1394, ptr %l679
  br label %bb342
bb342:
  %t1395 = load ptr, ptr %l671, !tbaa !29
  %t1396 = load ptr, ptr %l674, !tbaa !29
  %t1397 = load %"compiler/source:Span", ptr %l679
  %t1398 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenRef(ptr %v0, ptr %v0, ptr %v0, ptr %t1395, ptr %t1396, %"compiler/source:Span" %t1397)
  store ptr %t1398, ptr %l680
  br label %bb343
bb343:
  %t1399 = load ptr, ptr %l680, !tbaa !29
  store ptr %t1399, ptr %l8, !tbaa !29
  %t1401 = load ptr, ptr %l8, !tbaa !29
  %t1404 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1401)
  store i32 %t1404, ptr %l684
  br label %bb344
bb344:
  %t1405 = load i32, ptr %l684, !tbaa !23
  store i32 %t1405, ptr %l7, !tbaa !23
  br label %bb345
bb345:
  %t1406 = load ptr, ptr %l1, !tbaa !29
  %t1408 = getelementptr %"compiler/ast:VarDecl", ptr %t1406, i32 0, i32 5
  %t1409 = load i1, ptr %t1408, !tbaa !21
  br i1 %t1409, label %bb346, label %bb347
bb346:
  %t1411 = load i64, ptr %l2, !tbaa !24
  %t1412 = load ptr, ptr %l1, !tbaa !29
  %t1414 = getelementptr %"compiler/ast:VarDecl", ptr %t1412, i32 0, i32 3
  %t1415 = load { i64, ptr }, ptr %t1414, !tbaa !27
  %t1417 = extractvalue { i64, ptr } %t1415, 0
  %t1420 = icmp slt i64 %t1411, %t1417
  store i1 %t1420, ptr %l687, !tbaa !21
  br label %bb348
bb347:
  store i1 false, ptr %l687, !tbaa !21
  br label %bb348
bb348:
  %t1422 = load i1, ptr %l687, !tbaa !21
  br i1 %t1422, label %bb349, label %bb350
bb349:
  %t1423 = load ptr, ptr %l1, !tbaa !29
  %t1425 = getelementptr %"compiler/ast:VarDecl", ptr %t1423, i32 0, i32 2
  %t1426 = load ptr, ptr %t1425, !tbaa !29
  %t1428 = icmp eq ptr %t1426, null
  %t1430 = xor i1 %t1428, true
  store i1 %t1430, ptr %l693, !tbaa !21
  br label %bb351
bb350:
  store i1 false, ptr %l693, !tbaa !21
  br label %bb351
bb351:
  %t1432 = load i1, ptr %l693, !tbaa !21
  br i1 %t1432, label %bb352, label %bb353
bb352:
  %t1433 = load ptr, ptr %l1, !tbaa !29
  %t1435 = getelementptr %"compiler/ast:VarDecl", ptr %t1433, i32 0, i32 2
  %t1436 = load ptr, ptr %t1435, !tbaa !29
  %t1438 = icmp eq ptr %t1436, null
  br i1 %t1438, label %bb354, label %bb355
bb353:
  store i1 false, ptr %l698, !tbaa !21
  br label %bb358
bb354:
  call void @__olang_check_failed(ptr @olang_loc_24f575d634af9fe9_d12bddbdf08d4b65)
  unreachable
bb355:
  br label %bb356
bb356:
  %t1440 = load ptr, ptr %l1, !tbaa !29
  %t1442 = getelementptr %"compiler/ast:VarDecl", ptr %t1440, i32 0, i32 2
  %t1443 = load ptr, ptr %t1442, !tbaa !29
  %t1445 = call i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsWeak(ptr %v1, ptr %t1443)
  store i1 %t1445, ptr %l704
  br label %bb357
bb357:
  %t1446 = load i1, ptr %l704, !tbaa !21
  store i1 %t1446, ptr %l698, !tbaa !21
  br label %bb358
bb358:
  %t1447 = load i1, ptr %l698, !tbaa !21
  br i1 %t1447, label %bb359, label %bb360
bb359:
  %t1448 = load ptr, ptr %l0, !tbaa !29
  %t1449 = load ptr, ptr %l1, !tbaa !29
  %t1451 = getelementptr %"compiler/ast:VarDecl", ptr %t1449, i32 0, i32 3
  %t1452 = load { i64, ptr }, ptr %t1451, !tbaa !27
  store { i64, ptr } %t1452, ptr %l707, !tbaa !27
  %t1453 = load i64, ptr %l2, !tbaa !24
  %t1455 = getelementptr { i64, ptr }, ptr %l707, i32 0, i32 1
  %t1456 = load ptr, ptr %t1455, !tbaa !27
  %t1457 = getelementptr ptr, ptr %t1456, i64 %t1453
  %t1458 = load ptr, ptr %t1457, !tbaa !39
  %t1461 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewInstance(ptr %v0, ptr %v1, ptr %t1448, ptr %t1458)
  store i32 %t1461, ptr %l710
  br label %bb361
bb360:
  br label %bb369
bb361:
  %t1462 = load i32, ptr %l710, !tbaa !23
  store i32 %t1462, ptr %l23, !tbaa !23
  %t1463 = load i32, ptr %l23, !tbaa !23
  %t1464 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1467 = icmp ne i32 %t1463, %t1464
  br i1 %t1467, label %bb362, label %bb363
bb362:
  store %olang.scope zeroinitializer, ptr %s34
  %t1469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1469, ptr %l714, !tbaa !29
  %t1470 = load ptr, ptr %l1, !tbaa !29
  %t1472 = getelementptr %"compiler/ast:VarDecl", ptr %t1470, i32 0, i32 3
  %t1473 = load { i64, ptr }, ptr %t1472, !tbaa !27
  store { i64, ptr } %t1473, ptr %l716, !tbaa !27
  %t1474 = load i64, ptr %l2, !tbaa !24
  %t1476 = getelementptr { i64, ptr }, ptr %l716, i32 0, i32 1
  %t1477 = load ptr, ptr %t1476, !tbaa !27
  %t1478 = getelementptr ptr, ptr %t1477, i64 %t1474
  %t1479 = load ptr, ptr %t1478, !tbaa !39
  %t1481 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1479)
  store %"compiler/source:Span" %t1481, ptr %l719
  br label %bb364
bb363:
  br label %bb368
bb364:
  %t1482 = load ptr, ptr %l0, !tbaa !29
  %t1483 = load i32, ptr %l23, !tbaa !23
  %t1486 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s34, ptr %t1482, i32 %t1483)
  store { i64, ptr } %t1486, ptr %l722
  br label %bb365
bb365:
  %t1487 = load { i64, ptr }, ptr %l722, !tbaa !27
  %t1489 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWeakFresh(ptr %s34, ptr %v0, { i64, ptr } %t1487)
  store %"compiler/diagmsg:Msg" %t1489, ptr %l724
  br label %bb366
bb366:
  %t1490 = load ptr, ptr %l714, !tbaa !29
  %t1491 = load %"compiler/source:Span", ptr %l719
  %t1492 = load %"compiler/diagmsg:Msg", ptr %l724
  %t1493 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1490, %"compiler/source:Span" %t1491, %"compiler/diagmsg:Msg" %t1492)
  store i64 %t1493, ptr %l725
  br label %bb367
bb367:
  call void @__olang_scope_close(ptr %s34)
  br label %bb368
bb368:
  br label %bb369
bb369:
  %t1494 = load i1, ptr %l21, !tbaa !21
  br i1 %t1494, label %bb370, label %bb371
bb370:
  %t1496 = load ptr, ptr %l0, !tbaa !29
  %t1497 = load i32, ptr %l7, !tbaa !23
  %t1500 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1496, i32 %t1497)
  store i1 %t1500, ptr %l730
  br label %bb372
bb371:
  store i1 false, ptr %l727, !tbaa !21
  br label %bb373
bb372:
  %t1501 = load i1, ptr %l730, !tbaa !21
  store i1 %t1501, ptr %l727, !tbaa !21
  br label %bb373
bb373:
  %t1502 = load i1, ptr %l727, !tbaa !21
  br i1 %t1502, label %bb374, label %bb375
bb374:
  %t1503 = load ptr, ptr %l0, !tbaa !29
  %t1505 = getelementptr %"compiler/check:Checker", ptr %t1503, i32 0, i32 1
  %t1506 = load ptr, ptr %t1505, !tbaa !29
  %t1508 = getelementptr %"compiler/generic:Program", ptr %t1506, i32 0, i32 2
  %t1509 = load i32, ptr %l7, !tbaa !23
  %t1512 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1508, i32 %t1509)
  store i64 %t1512, ptr %l736
  br label %bb376
bb375:
  store i1 false, ptr %l731, !tbaa !21
  br label %bb377
bb376:
  %t1513 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1514 = load i64, ptr %l736, !tbaa !24
  %t1516 = and i64 %t1514, %t1513
  %t1518 = icmp ne i64 %t1516, 0
  store i1 %t1518, ptr %l731, !tbaa !21
  br label %bb377
bb377:
  %t1520 = load i1, ptr %l731, !tbaa !21
  br i1 %t1520, label %bb378, label %bb379
bb378:
  %t1521 = load ptr, ptr %l0, !tbaa !29
  %t1523 = getelementptr %"compiler/check:Checker", ptr %t1521, i32 0, i32 1
  %t1524 = load ptr, ptr %t1523, !tbaa !29
  %t1526 = getelementptr %"compiler/generic:Program", ptr %t1524, i32 0, i32 2
  store ptr %t1526, ptr %l743, !tbaa !29
  %t1527 = load ptr, ptr %l0, !tbaa !29
  %t1528 = load i32, ptr %l7, !tbaa !23
  %t1531 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1527, i32 %t1528)
  store i32 %t1531, ptr %l746
  br label %bb380
bb379:
  store i1 false, ptr %l740, !tbaa !21
  br label %bb382
bb380:
  %t1532 = load ptr, ptr %l743, !tbaa !29
  %t1533 = load i32, ptr %l746, !tbaa !23
  %t1534 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1532, i32 %t1533)
  store i32 %t1534, ptr %l747
  br label %bb381
bb381:
  %t1535 = load i32, ptr %l747, !range !{i32 0, i32 33}
  %t1537 = trunc i64 21 to i32
  %t1538 = icmp eq i32 %t1535, %t1537
  %t1540 = xor i1 %t1538, true
  store i1 %t1540, ptr %l740, !tbaa !21
  br label %bb382
bb382:
  %t1542 = load i1, ptr %l740, !tbaa !21
  br i1 %t1542, label %bb383, label %bb384
bb383:
  %t1543 = load ptr, ptr %l0, !tbaa !29
  %t1544 = load ptr, ptr %l8, !tbaa !29
  %t1547 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t1543, ptr %t1544)
  store i1 %t1547, ptr %l754
  br label %bb385
bb384:
  store i1 false, ptr %l751, !tbaa !21
  br label %bb386
bb385:
  %t1548 = load i1, ptr %l754, !tbaa !21
  store i1 %t1548, ptr %l751, !tbaa !21
  br label %bb386
bb386:
  %t1549 = load i1, ptr %l751, !tbaa !21
  br i1 %t1549, label %bb387, label %bb388
bb387:
  %t1550 = load ptr, ptr %l0, !tbaa !29
  %t1552 = getelementptr %"compiler/check:Checker", ptr %t1550, i32 0, i32 1
  %t1553 = load ptr, ptr %t1552, !tbaa !29
  %t1555 = getelementptr %"compiler/generic:Program", ptr %t1553, i32 0, i32 2
  store ptr %t1555, ptr %l757, !tbaa !29
  %t1556 = load ptr, ptr %l0, !tbaa !29
  %t1558 = getelementptr %"compiler/check:Checker", ptr %t1556, i32 0, i32 1
  %t1559 = load ptr, ptr %t1558, !tbaa !29
  %t1561 = getelementptr %"compiler/generic:Program", ptr %t1559, i32 0, i32 2
  %t1562 = load i32, ptr %l7, !tbaa !23
  %t1565 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1561, i32 %t1562)
  store i32 %t1565, ptr %l762
  br label %bb389
bb388:
  br label %bb392
bb389:
  %t1566 = load ptr, ptr %l0, !tbaa !29
  %t1568 = getelementptr %"compiler/check:Checker", ptr %t1566, i32 0, i32 1
  %t1569 = load ptr, ptr %t1568, !tbaa !29
  %t1571 = getelementptr %"compiler/generic:Program", ptr %t1569, i32 0, i32 2
  %t1572 = load i32, ptr %l7, !tbaa !23
  %t1575 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1571, i32 %t1572)
  store i64 %t1575, ptr %l767
  br label %bb390
bb390:
  %t1576 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1578 = xor i64 %t1576, -1
  %t1579 = load i64, ptr %l767, !tbaa !24
  %t1581 = and i64 %t1579, %t1578
  %t1582 = load ptr, ptr %l757, !tbaa !29
  %t1583 = load i32, ptr %l762, !tbaa !23
  %t1585 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1582, i32 %t1583, i64 %t1581)
  store i32 %t1585, ptr %l771
  br label %bb391
bb391:
  %t1586 = load i32, ptr %l771, !tbaa !23
  store i32 %t1586, ptr %l7, !tbaa !23
  br label %bb392
bb392:
  %t1587 = load i64, ptr %l2, !tbaa !24
  %t1588 = load ptr, ptr %l1, !tbaa !29
  %t1590 = getelementptr %"compiler/ast:VarDecl", ptr %t1588, i32 0, i32 3
  %t1591 = load { i64, ptr }, ptr %t1590, !tbaa !27
  %t1593 = extractvalue { i64, ptr } %t1591, 0
  %t1596 = icmp slt i64 %t1587, %t1593
  br i1 %t1596, label %bb393, label %bb394
bb393:
  %t1598 = load i1, ptr %l21, !tbaa !21
  %t1600 = xor i1 %t1598, true
  store i1 %t1600, ptr %l777, !tbaa !21
  br label %bb395
bb394:
  store i1 false, ptr %l777, !tbaa !21
  br label %bb395
bb395:
  %t1602 = load i1, ptr %l777, !tbaa !21
  br i1 %t1602, label %bb396, label %bb397
bb396:
  %t1603 = load ptr, ptr %l0, !tbaa !29
  %t1604 = load i32, ptr %l7, !tbaa !23
  %t1607 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1603, i32 %t1604)
  store i1 %t1607, ptr %l783
  br label %bb398
bb397:
  store i1 false, ptr %l780, !tbaa !21
  br label %bb399
bb398:
  %t1608 = load i1, ptr %l783, !tbaa !21
  %t1609 = xor i1 %t1608, true
  store i1 %t1609, ptr %l780, !tbaa !21
  br label %bb399
bb399:
  %t1611 = load i1, ptr %l780, !tbaa !21
  br i1 %t1611, label %bb400, label %bb401
bb400:
  %t1612 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1612, ptr %l785, !tbaa !29
  %t1613 = load ptr, ptr %l8, !tbaa !29
  store ptr %t1613, ptr %l786, !tbaa !29
  %t1614 = load ptr, ptr %l1, !tbaa !29
  %t1616 = getelementptr %"compiler/ast:VarDecl", ptr %t1614, i32 0, i32 3
  %t1617 = load { i64, ptr }, ptr %t1616, !tbaa !27
  store { i64, ptr } %t1617, ptr %l788, !tbaa !27
  %t1618 = load i64, ptr %l2, !tbaa !24
  %t1620 = getelementptr { i64, ptr }, ptr %l788, i32 0, i32 1
  %t1621 = load ptr, ptr %t1620, !tbaa !27
  %t1622 = getelementptr ptr, ptr %t1621, i64 %t1618
  %t1623 = load ptr, ptr %t1622, !tbaa !39
  %t1625 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1623)
  store %"compiler/source:Span" %t1625, ptr %l791
  br label %bb402
bb401:
  br label %bb404
bb402:
  %t1626 = load i64, ptr @G_2ecompiler_2fcheck_2eRoDecl, !tbaa !24
  %t1627 = load ptr, ptr %l785, !tbaa !29
  %t1628 = load ptr, ptr %l786, !tbaa !29
  %t1629 = load %"compiler/source:Span", ptr %l791
  %t1631 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t1627, ptr %t1628, %"compiler/source:Span" %t1629, i64 %t1626)
  store i1 %t1631, ptr %l793
  br label %bb403
bb403:
  br label %bb404
bb404:
  %t1632 = load ptr, ptr %l0, !tbaa !29
  %t1633 = load ptr, ptr %l1, !tbaa !29
  %t1635 = getelementptr %"compiler/ast:VarDecl", ptr %t1633, i32 0, i32 0
  %t1636 = load { i64, ptr }, ptr %t1635, !tbaa !27
  store { i64, ptr } %t1636, ptr %l796, !tbaa !27
  %t1637 = load i64, ptr %l2, !tbaa !24
  %t1639 = getelementptr { i64, ptr }, ptr %l796, i32 0, i32 1
  %t1640 = load ptr, ptr %t1639, !tbaa !27
  %t1641 = getelementptr i32, ptr %t1640, i64 %t1637
  %t1642 = load i32, ptr %t1641, !tbaa !33
  %t1643 = load %"compiler/source:Span", ptr %l6
  %t1644 = load i32, ptr %l7, !tbaa !23
  %t1653 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t1632, i32 %t1642, %"compiler/source:Span" %t1643, i32 %t1644, i32 %a5, { i64, [1 x i64] } %a4)
  store i64 %t1653, ptr %l803
  br label %bb405
bb405:
  %t1654 = load i64, ptr %l803, !tbaa !24
  store i64 %t1654, ptr %l24, !tbaa !24
  %t1655 = load i1, ptr %l9, !tbaa !21
  br i1 %t1655, label %bb406, label %bb407
bb406:
  %t1657 = load i64, ptr %l24, !tbaa !24
  store i64 %t1657, ptr %l25, !tbaa !24
  store i1 true, ptr %l26, !tbaa !21
  %t1659 = load ptr, ptr %l0, !tbaa !29
  %t1661 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1659)
  store ptr %t1661, ptr %l807
  br label %bb408
bb407:
  br label %bb410
bb408:
  %t1662 = load ptr, ptr %l807, !tbaa !29
  %t1664 = getelementptr %"compiler/typed:Body", ptr %t1662, i32 0, i32 7
  %t1665 = load i64, ptr %l25, !tbaa !24
  %t1668 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v0, ptr %t1664, i64 %t1665)
  store ptr %t1668, ptr %l811
  br label %bb409
bb409:
  %t1669 = load ptr, ptr %l811, !tbaa !29
  %t1671 = load i1, ptr %l26, !tbaa !21
  %t1674 = getelementptr %"compiler/typed:Local", ptr %t1669, i32 0, i32 7
  store i1 %t1671, ptr %t1674, !tbaa !21
  br label %bb410
bb410:
  %t1675 = load i64, ptr %l2, !tbaa !24
  %t1676 = load ptr, ptr %l1, !tbaa !29
  %t1678 = getelementptr %"compiler/ast:VarDecl", ptr %t1676, i32 0, i32 3
  %t1679 = load { i64, ptr }, ptr %t1678, !tbaa !27
  %t1681 = extractvalue { i64, ptr } %t1679, 0
  %t1684 = icmp slt i64 %t1675, %t1681
  br i1 %t1684, label %bb411, label %bb412
bb411:
  %t1686 = load ptr, ptr %l1, !tbaa !29
  %t1688 = getelementptr %"compiler/ast:VarDecl", ptr %t1686, i32 0, i32 5
  %t1689 = load i1, ptr %t1688, !tbaa !21
  %t1691 = xor i1 %t1689, true
  store i1 %t1691, ptr %l819, !tbaa !21
  br label %bb413
bb412:
  store i1 false, ptr %l819, !tbaa !21
  br label %bb413
bb413:
  %t1693 = load i1, ptr %l819, !tbaa !21
  br i1 %t1693, label %bb414, label %bb415
bb414:
  %t1694 = load ptr, ptr %l1, !tbaa !29
  %t1696 = getelementptr %"compiler/ast:VarDecl", ptr %t1694, i32 0, i32 0
  %t1697 = load { i64, ptr }, ptr %t1696, !tbaa !27
  %t1699 = extractvalue { i64, ptr } %t1697, 0
  %t1701 = icmp eq i64 %t1699, 1
  store i1 %t1701, ptr %l823, !tbaa !21
  br label %bb416
bb415:
  store i1 false, ptr %l823, !tbaa !21
  br label %bb416
bb416:
  %t1703 = load i1, ptr %l823, !tbaa !21
  br i1 %t1703, label %bb417, label %bb418
bb417:
  %t1704 = load ptr, ptr %l0, !tbaa !29
  %t1706 = getelementptr %"compiler/check:Checker", ptr %t1704, i32 0, i32 1
  %t1707 = load ptr, ptr %t1706, !tbaa !29
  %t1709 = getelementptr %"compiler/generic:Program", ptr %t1707, i32 0, i32 2
  store ptr %t1709, ptr %l831, !tbaa !29
  %t1710 = load ptr, ptr %l0, !tbaa !29
  %t1712 = getelementptr %"compiler/check:Checker", ptr %t1710, i32 0, i32 1
  %t1713 = load ptr, ptr %t1712, !tbaa !29
  %t1715 = getelementptr %"compiler/generic:Program", ptr %t1713, i32 0, i32 2
  %t1716 = load i32, ptr %l7, !tbaa !23
  %t1719 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1715, i32 %t1716)
  store i32 %t1719, ptr %l836
  br label %bb419
bb418:
  store i1 false, ptr %l828, !tbaa !21
  br label %bb421
bb419:
  %t1720 = load ptr, ptr %l831, !tbaa !29
  %t1721 = load i32, ptr %l836, !tbaa !23
  %t1722 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1720, i32 %t1721)
  store i32 %t1722, ptr %l837
  br label %bb420
bb420:
  %t1723 = load i32, ptr %l837, !range !{i32 0, i32 33}
  %t1725 = trunc i64 19 to i32
  %t1726 = icmp eq i32 %t1723, %t1725
  store i1 %t1726, ptr %l828, !tbaa !21
  br label %bb421
bb421:
  %t1728 = load i1, ptr %l828, !tbaa !21
  br i1 %t1728, label %bb422, label %bb423
bb422:
  %t1729 = load ptr, ptr %l0, !tbaa !29
  %t1731 = getelementptr %"compiler/check:Checker", ptr %t1729, i32 0, i32 1
  %t1732 = load ptr, ptr %t1731, !tbaa !29
  %t1734 = getelementptr %"compiler/generic:Program", ptr %t1732, i32 0, i32 2
  store ptr %t1734, ptr %l843, !tbaa !29
  %t1735 = load ptr, ptr %l0, !tbaa !29
  %t1737 = getelementptr %"compiler/check:Checker", ptr %t1735, i32 0, i32 1
  %t1738 = load ptr, ptr %t1737, !tbaa !29
  %t1740 = getelementptr %"compiler/generic:Program", ptr %t1738, i32 0, i32 2
  %t1741 = load i32, ptr %l7, !tbaa !23
  %t1744 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1740, i32 %t1741)
  store i32 %t1744, ptr %l848
  br label %bb424
bb423:
  store i1 false, ptr %l840, !tbaa !21
  br label %bb426
bb424:
  %t1745 = load ptr, ptr %l843, !tbaa !29
  %t1746 = load i32, ptr %l848, !tbaa !23
  %t1747 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1745, i32 %t1746)
  store i32 %t1747, ptr %l849
  br label %bb425
bb425:
  %t1748 = load i32, ptr %l849, !tbaa !23
  %t1749 = icmp ne i32 %t1748, 0
  store i1 %t1749, ptr %l840, !tbaa !21
  br label %bb426
bb426:
  %t1751 = load i1, ptr %l840, !tbaa !21
  br i1 %t1751, label %bb427, label %bb428
bb427:
  %t1752 = load ptr, ptr %l0, !tbaa !29
  %t1753 = load ptr, ptr %l8, !tbaa !29
  %t1756 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoClearMade(ptr %v0, ptr %v0, ptr %t1752, ptr %t1753)
  store i1 %t1756, ptr %l854
  br label %bb429
bb428:
  store i1 false, ptr %l851, !tbaa !21
  br label %bb430
bb429:
  %t1757 = load i1, ptr %l854, !tbaa !21
  store i1 %t1757, ptr %l851, !tbaa !21
  br label %bb430
bb430:
  %t1758 = load i1, ptr %l851, !tbaa !21
  br i1 %t1758, label %bb431, label %bb432
bb431:
  %t1759 = load i64, ptr %l24, !tbaa !24
  store i64 %t1759, ptr %l28, !tbaa !24
  store i1 true, ptr %l29, !tbaa !21
  %t1761 = load ptr, ptr %l0, !tbaa !29
  %t1763 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1761)
  store ptr %t1763, ptr %l857
  br label %bb433
bb432:
  br label %bb435
bb433:
  %t1764 = load ptr, ptr %l857, !tbaa !29
  %t1766 = getelementptr %"compiler/typed:Body", ptr %t1764, i32 0, i32 7
  %t1767 = load i64, ptr %l28, !tbaa !24
  %t1770 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v0, ptr %t1766, i64 %t1767)
  store ptr %t1770, ptr %l861
  br label %bb434
bb434:
  %t1771 = load ptr, ptr %l861, !tbaa !29
  %t1773 = load i1, ptr %l29, !tbaa !21
  %t1776 = getelementptr %"compiler/typed:Local", ptr %t1771, i32 0, i32 6
  store i1 %t1773, ptr %t1776, !tbaa !21
  br label %bb435
bb435:
  %t1777 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 2
  %t1778 = load i64, ptr %t1777, !tbaa !24
  %t1780 = icmp sge i64 %t1778, 0
  br i1 %t1780, label %bb436, label %bb437
bb436:
  store %olang.scope zeroinitializer, ptr %s39
  %t1782 = load ptr, ptr %l0, !tbaa !29
  %t1784 = getelementptr %"compiler/check:Checker", ptr %t1782, i32 0, i32 129
  store ptr %t1784, ptr %l867, !tbaa !29
  %t1785 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 0
  %t1786 = load i64, ptr %t1785, !tbaa !24
  %t1787 = load i64, ptr %l24, !tbaa !24
  %t1788 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 2
  %t1789 = load i64, ptr %t1788, !tbaa !24
  %t1790 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 3
  %t1791 = load i1, ptr %t1790, !tbaa !21
  %t1792 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 4
  %t1793 = load i64, ptr %t1792, !tbaa !24
  %t1794 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 5
  %t1795 = load %"compiler/source:Span", ptr %t1794
  %t1796 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 6
  %t1797 = load i32, ptr %t1796, !tbaa !23
  %t1798 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 7
  %t1799 = load i1, ptr %t1798, !tbaa !21
  %t1808 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s39, i64 %t1786, i64 %t1787, i64 %t1789, i1 %t1791, i64 %t1793, %"compiler/source:Span" %t1795, i32 %t1797, i1 %t1799)
  store %"compiler/check:unsetCand" %t1808, ptr %l876
  br label %bb438
bb437:
  br label %bb440
bb438:
  %t1809 = load ptr, ptr %l867, !tbaa !29
  %t1810 = load %"compiler/check:unsetCand", ptr %l876
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2ePush_Hd5bae6439baa110b1f2b8b5b7cdda5ce(ptr %v0, ptr %t1809, %"compiler/check:unsetCand" %t1810)
  br label %bb439
bb439:
  call void @__olang_scope_close(ptr %s39)
  br label %bb440
bb440:
  %t1811 = load ptr, ptr %l1, !tbaa !29
  %t1813 = getelementptr %"compiler/ast:VarDecl", ptr %t1811, i32 0, i32 2
  %t1814 = load ptr, ptr %t1813, !tbaa !29
  %t1816 = icmp eq ptr %t1814, null
  %t1818 = xor i1 %t1816, true
  br i1 %t1818, label %bb441, label %bb442
bb441:
  %t1820 = load ptr, ptr %l1, !tbaa !29
  %t1822 = getelementptr %"compiler/ast:VarDecl", ptr %t1820, i32 0, i32 4
  %t1823 = load i1, ptr %t1822, !tbaa !21
  %t1825 = xor i1 %t1823, true
  store i1 %t1825, ptr %l881, !tbaa !21
  br label %bb443
bb442:
  store i1 false, ptr %l881, !tbaa !21
  br label %bb443
bb443:
  %t1827 = load i1, ptr %l881, !tbaa !21
  br i1 %t1827, label %bb444, label %bb445
bb444:
  %t1828 = load ptr, ptr %l0, !tbaa !29
  %t1830 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1828)
  store ptr %t1830, ptr %l886
  br label %bb446
bb445:
  br label %bb452
bb446:
  %t1831 = load ptr, ptr %l886, !tbaa !29
  %t1833 = getelementptr %"compiler/check:frame", ptr %t1831, i32 0, i32 3
  store ptr %t1833, ptr %l888, !tbaa !29
  %t1834 = load i64, ptr %l24, !tbaa !24
  store i64 %t1834, ptr %l889, !tbaa !24
  %t1835 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1835, ptr %l890, !tbaa !29
  %t1836 = load ptr, ptr %l1, !tbaa !29
  %t1838 = getelementptr %"compiler/ast:VarDecl", ptr %t1836, i32 0, i32 2
  %t1839 = load ptr, ptr %t1838, !tbaa !29
  %t1841 = icmp eq ptr %t1839, null
  br i1 %t1841, label %bb447, label %bb448
bb447:
  call void @__olang_check_failed(ptr @olang_loc_85cca4aa7cb02cf4_9ecd586858c19010)
  unreachable
bb448:
  br label %bb449
bb449:
  %t1843 = load ptr, ptr %l1, !tbaa !29
  %t1845 = getelementptr %"compiler/ast:VarDecl", ptr %t1843, i32 0, i32 2
  %t1846 = load ptr, ptr %t1845, !tbaa !29
  %t1847 = load ptr, ptr %l890, !tbaa !29
  %t1849 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t1847, ptr %t1846)
  store { i64, [3 x i64] } %t1849, ptr %l896
  br label %bb450
bb450:
  %t1850 = load ptr, ptr %l888, !tbaa !29
  %t1851 = load i64, ptr %l889, !tbaa !24
  %t1852 = load { i64, [3 x i64] }, ptr %l896
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t1850, i64 %t1851, { i64, [3 x i64] } %t1852)
  br label %bb451
bb451:
  br label %bb452
bb452:
  %t1853 = load i1, ptr %l21, !tbaa !21
  br i1 %t1853, label %bb453, label %bb454
bb453:
  %t1855 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1855, ptr %l898, !tbaa !29
  %t1856 = load i64, ptr %l24, !tbaa !24
  store i64 %t1856, ptr %l899, !tbaa !24
  %t1857 = load ptr, ptr %l8, !tbaa !29
  %t1859 = icmp eq ptr %t1857, null
  br i1 %t1859, label %bb455, label %bb456
bb454:
  br label %bb459
bb455:
  call void @__olang_check_failed(ptr @olang_loc_959344f4a5ca7c83_1fd822b10f304e6f)
  unreachable
bb456:
  br label %bb457
bb457:
  %t1861 = load ptr, ptr %l8, !tbaa !29
  %t1862 = load ptr, ptr %l898, !tbaa !29
  %t1863 = load i64, ptr %l899, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t1862, i64 %t1863, ptr %t1861)
  br label %bb458
bb458:
  br label %bb459
bb459:
  %t1865 = load i1, ptr %l21, !tbaa !21
  br i1 %t1865, label %bb460, label %bb461
bb460:
  %t1867 = load ptr, ptr %l1, !tbaa !29
  %t1869 = getelementptr %"compiler/ast:VarDecl", ptr %t1867, i32 0, i32 5
  %t1870 = load i1, ptr %t1869, !tbaa !21
  %t1872 = xor i1 %t1870, true
  store i1 %t1872, ptr %l904, !tbaa !21
  br label %bb462
bb461:
  store i1 false, ptr %l904, !tbaa !21
  br label %bb462
bb462:
  %t1874 = load i1, ptr %l904, !tbaa !21
  br i1 %t1874, label %bb463, label %bb464
bb463:
  %t1875 = load ptr, ptr %l0, !tbaa !29
  %t1876 = load i32, ptr %l7, !tbaa !23
  %t1879 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1875, i32 %t1876)
  store i1 %t1879, ptr %l911
  br label %bb465
bb464:
  store i1 false, ptr %l908, !tbaa !21
  br label %bb466
bb465:
  %t1880 = load i1, ptr %l911, !tbaa !21
  store i1 %t1880, ptr %l908, !tbaa !21
  br label %bb466
bb466:
  %t1881 = load i1, ptr %l908, !tbaa !21
  br i1 %t1881, label %bb467, label %bb468
bb467:
  %t1882 = load ptr, ptr %l0, !tbaa !29
  %t1883 = load ptr, ptr %l1, !tbaa !29
  %t1885 = getelementptr %"compiler/ast:VarDecl", ptr %t1883, i32 0, i32 3
  %t1886 = load { i64, ptr }, ptr %t1885, !tbaa !27
  store { i64, ptr } %t1886, ptr %l915, !tbaa !27
  %t1887 = load i64, ptr %l2, !tbaa !24
  %t1889 = getelementptr { i64, ptr }, ptr %l915, i32 0, i32 1
  %t1890 = load ptr, ptr %t1889, !tbaa !27
  %t1891 = getelementptr ptr, ptr %t1890, i64 %t1887
  %t1892 = load ptr, ptr %t1891, !tbaa !39
  %t1895 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t1882, ptr %t1892)
  store i1 %t1895, ptr %l918
  br label %bb469
bb468:
  store i1 false, ptr %l912, !tbaa !21
  br label %bb470
bb469:
  %t1896 = load i1, ptr %l918, !tbaa !21
  store i1 %t1896, ptr %l912, !tbaa !21
  br label %bb470
bb470:
  %t1897 = load i1, ptr %l912, !tbaa !21
  br i1 %t1897, label %bb471, label %bb472
bb471:
  store %olang.scope zeroinitializer, ptr %s42
  %t1898 = load ptr, ptr %l0, !tbaa !29
  %t1900 = getelementptr %"compiler/check:Checker", ptr %t1898, i32 0, i32 37
  store ptr %t1900, ptr %l920, !tbaa !29
  %t1901 = load ptr, ptr %l0, !tbaa !29
  %t1903 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1901)
  store ptr %t1903, ptr %l922
  br label %bb473
bb472:
  br label %bb476
bb473:
  %t1904 = load ptr, ptr %l922, !tbaa !29
  %t1906 = getelementptr %"compiler/check:frame", ptr %t1904, i32 0, i32 0
  %t1907 = load i64, ptr %t1906, !tbaa !24
  %t1908 = load i64, ptr %l24, !tbaa !24
  %t1911 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s42, i64 %t1907, i64 %t1908)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1911, ptr %l926
  br label %bb474
bb474:
  %t1912 = load ptr, ptr %l920, !tbaa !29
  %t1913 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l926
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t1912, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1913, i1 true)
  br label %bb475
bb475:
  call void @__olang_scope_close(ptr %s42)
  br label %bb476
bb476:
  %t1914 = load ptr, ptr %l1, !tbaa !29
  %t1916 = getelementptr %"compiler/ast:VarDecl", ptr %t1914, i32 0, i32 5
  %t1917 = load i1, ptr %t1916, !tbaa !21
  %t1919 = xor i1 %t1917, true
  br i1 %t1919, label %bb477, label %bb478
bb477:
  %t1921 = load i64, ptr %l2, !tbaa !24
  %t1922 = load ptr, ptr %l1, !tbaa !29
  %t1924 = getelementptr %"compiler/ast:VarDecl", ptr %t1922, i32 0, i32 3
  %t1925 = load { i64, ptr }, ptr %t1924, !tbaa !27
  %t1927 = extractvalue { i64, ptr } %t1925, 0
  %t1930 = icmp slt i64 %t1921, %t1927
  store i1 %t1930, ptr %l930, !tbaa !21
  br label %bb479
bb478:
  store i1 false, ptr %l930, !tbaa !21
  br label %bb479
bb479:
  %t1932 = load i1, ptr %l930, !tbaa !21
  br i1 %t1932, label %bb480, label %bb481
bb480:
  %t1933 = load ptr, ptr %l0, !tbaa !29
  %t1934 = load i32, ptr %l7, !tbaa !23
  %t1937 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainScalar(ptr %v0, ptr %t1933, i32 %t1934)
  store i1 %t1937, ptr %l939
  br label %bb482
bb481:
  store i1 false, ptr %l936, !tbaa !21
  br label %bb483
bb482:
  %t1938 = load i1, ptr %l939, !tbaa !21
  store i1 %t1938, ptr %l936, !tbaa !21
  br label %bb483
bb483:
  %t1939 = load i1, ptr %l936, !tbaa !21
  br i1 %t1939, label %bb484, label %bb485
bb484:
  store %olang.scope zeroinitializer, ptr %s43
  %t1940 = load ptr, ptr %l0, !tbaa !29
  %t1942 = getelementptr %"compiler/check:Checker", ptr %t1940, i32 0, i32 164
  store ptr %t1942, ptr %l941, !tbaa !29
  %t1943 = load ptr, ptr %l0, !tbaa !29
  %t1945 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1943)
  store ptr %t1945, ptr %l943
  br label %bb486
bb485:
  br label %bb490
bb486:
  %t1946 = load ptr, ptr %l943, !tbaa !29
  %t1948 = getelementptr %"compiler/check:frame", ptr %t1946, i32 0, i32 0
  %t1949 = load i64, ptr %t1948, !tbaa !24
  %t1950 = load i64, ptr %l24, !tbaa !24
  %t1953 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s43, i64 %t1949, i64 %t1950)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1953, ptr %l947
  br label %bb487
bb487:
  %t1954 = load ptr, ptr %l1, !tbaa !29
  %t1956 = getelementptr %"compiler/ast:VarDecl", ptr %t1954, i32 0, i32 3
  %t1957 = load { i64, ptr }, ptr %t1956, !tbaa !27
  store { i64, ptr } %t1957, ptr %l949, !tbaa !27
  %t1958 = load i64, ptr %l2, !tbaa !24
  %t1960 = getelementptr { i64, ptr }, ptr %l949, i32 0, i32 1
  %t1961 = load ptr, ptr %t1960, !tbaa !27
  %t1962 = getelementptr ptr, ptr %t1961, i64 %t1958
  %t1963 = load ptr, ptr %t1962, !tbaa !39
  %t1964 = load i32, ptr %l7, !tbaa !23
  %t1967 = call %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v1, ptr %v0, ptr %t1963, i32 %t1964)
  store %"compiler/check:fixedInit" %t1967, ptr %l953
  br label %bb488
bb488:
  %t1968 = load ptr, ptr %l941, !tbaa !29
  %t1969 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l947
  %t1970 = load %"compiler/check:fixedInit", ptr %l953
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5daf2b89f219287cc2404f0b0e96c809(ptr %v0, ptr %v0, ptr %t1968, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1969, %"compiler/check:fixedInit" %t1970)
  br label %bb489
bb489:
  call void @__olang_scope_close(ptr %s43)
  br label %bb490
bb490:
  %t1971 = load i64, ptr %l2, !tbaa !24
  %t1972 = load ptr, ptr %l1, !tbaa !29
  %t1974 = getelementptr %"compiler/ast:VarDecl", ptr %t1972, i32 0, i32 3
  %t1975 = load { i64, ptr }, ptr %t1974, !tbaa !27
  %t1977 = extractvalue { i64, ptr } %t1975, 0
  %t1980 = icmp slt i64 %t1971, %t1977
  br i1 %t1980, label %bb491, label %bb492
bb491:
  %t1982 = load ptr, ptr %l0, !tbaa !29
  %t1983 = load i32, ptr %l7, !tbaa !23
  %t1986 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1982, i32 %t1983)
  store i1 %t1986, ptr %l962
  br label %bb493
bb492:
  store i1 false, ptr %l959, !tbaa !21
  br label %bb494
bb493:
  %t1987 = load i1, ptr %l962, !tbaa !21
  %t1988 = xor i1 %t1987, true
  store i1 %t1988, ptr %l959, !tbaa !21
  br label %bb494
bb494:
  %t1990 = load i1, ptr %l959, !tbaa !21
  br i1 %t1990, label %bb495, label %bb496
bb495:
  %t1991 = load ptr, ptr %l0, !tbaa !29
  %t1993 = getelementptr %"compiler/check:Checker", ptr %t1991, i32 0, i32 1
  %t1994 = load ptr, ptr %t1993, !tbaa !29
  %t1996 = getelementptr %"compiler/generic:Program", ptr %t1994, i32 0, i32 2
  %t1997 = load i32, ptr %l7, !tbaa !23
  %t2000 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t1996, i32 %t1997)
  store i1 %t2000, ptr %l969
  br label %bb497
bb496:
  store i1 false, ptr %l964, !tbaa !21
  br label %bb498
bb497:
  %t2001 = load i1, ptr %l969, !tbaa !21
  store i1 %t2001, ptr %l964, !tbaa !21
  br label %bb498
bb498:
  %t2002 = load i1, ptr %l964, !tbaa !21
  br i1 %t2002, label %bb499, label %bb500
bb499:
  %t2003 = load i1, ptr %l22, !tbaa !21
  %t2005 = xor i1 %t2003, true
  store i1 %t2005, ptr %l970, !tbaa !21
  br label %bb501
bb500:
  store i1 false, ptr %l970, !tbaa !21
  br label %bb501
bb501:
  %t2007 = load i1, ptr %l970, !tbaa !21
  br i1 %t2007, label %bb502, label %bb503
bb502:
  %t2008 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2008, ptr %l973, !tbaa !29
  %t2009 = load ptr, ptr %l8, !tbaa !29
  %t2011 = icmp eq ptr %t2009, null
  br i1 %t2011, label %bb504, label %bb505
bb503:
  br label %bb508
bb504:
  call void @__olang_check_failed(ptr @olang_loc_91b892f1670b4a16_cb06ea6ef08c507a)
  unreachable
bb505:
  br label %bb506
bb506:
  %t2013 = load ptr, ptr %l8, !tbaa !29
  %t2014 = load ptr, ptr %l973, !tbaa !29
  %t2016 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v0, ptr %v0, ptr %t2014, ptr %t2013)
  store ptr %t2016, ptr %l977
  br label %bb507
bb507:
  %t2017 = load ptr, ptr %l977, !tbaa !29
  store ptr %t2017, ptr %l8, !tbaa !29
  br label %bb508
bb508:
  %t2019 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2019, ptr %l979, !tbaa !29
  %t2020 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t2020, ptr %l980
  %t2021 = load i64, ptr %l24, !tbaa !24
  %t2023 = trunc i64 %t2021 to i32
  store i32 %t2023, ptr %l983, !tbaa !23
  %t2025 = load ptr, ptr %l8, !tbaa !29
  %t2027 = icmp eq ptr %t2025, null
  br i1 %t2027, label %bb509, label %bb510
bb509:
  call void @__olang_check_failed(ptr @olang_loc_15565a5e809df9fd_a3fd7375e72d6f01)
  unreachable
bb510:
  br label %bb511
bb511:
  %t2029 = load ptr, ptr %l8, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t2030
  %t2031 = getelementptr { i64, [3 x i64] }, ptr %t2030, i32 0, i32 0
  store i64 0, ptr %t2031
  %t2032 = load %"compiler/source:Span", ptr %l980
  %t2033 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2032, 0
  %t2034 = load i32, ptr %l983, !tbaa !23
  %t2035 = insertvalue { %"compiler/source:Span", i32, ptr } %t2033, i32 %t2034, 1
  %t2037 = insertvalue { %"compiler/source:Span", i32, ptr } %t2035, ptr %t2029, 2
  %t2038 = getelementptr { i64, [3 x i64] }, ptr %t2030, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2037, ptr %t2038
  %t2039 = load { i64, [3 x i64] }, ptr %t2030
  %t2041 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t2039, ptr %t2041
  %t2042 = load ptr, ptr %l979, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t2042, ptr %t2041)
  br label %bb512
bb512:
  %t2044 = load ptr, ptr %l1, !tbaa !29
  %t2046 = getelementptr %"compiler/ast:VarDecl", ptr %t2044, i32 0, i32 5
  %t2047 = load i1, ptr %t2046, !tbaa !21
  br i1 %t2047, label %bb513, label %bb514
bb513:
  %t2049 = load ptr, ptr %l0, !tbaa !29
  %t2051 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t2049)
  store ptr %t2051, ptr %l992
  br label %bb515
bb514:
  br label %bb517
bb515:
  %t2052 = load ptr, ptr %l992, !tbaa !29
  %t2054 = getelementptr %"compiler/typed:Body", ptr %t2052, i32 0, i32 10
  %t2055 = load i64, ptr %l24, !tbaa !24
  %t2057 = trunc i64 %t2055 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t2054, i32 %t2057)
  br label %bb516
bb516:
  br label %bb517
bb517:
  %t2061 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2061, ptr %l998, !tbaa !29
  %t2062 = load i64, ptr %l24, !tbaa !24
  store i64 %t2062, ptr %l999, !tbaa !24
  %t2063 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t2063, ptr %l1000
  %t2064 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 3
  %t2065 = load i1, ptr %t2064, !tbaa !21
  %t2067 = xor i1 %t2065, true
  br i1 %t2067, label %bb518, label %bb519
bb518:
  store i1 true, ptr %l1003, !tbaa !21
  br label %bb520
bb519:
  %t2069 = getelementptr %"compiler/check:unsetCand", ptr %l10, i32 0, i32 2
  %t2070 = load i64, ptr %t2069, !tbaa !24
  %t2072 = icmp slt i64 %t2070, 0
  store i1 %t2072, ptr %l1003, !tbaa !21
  br label %bb520
bb520:
  %t2074 = load ptr, ptr %l998, !tbaa !29
  %t2075 = load i64, ptr %l999, !tbaa !24
  %t2076 = load %"compiler/source:Span", ptr %l1000
  %t2077 = load i1, ptr %l1003, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %t2074, i64 %t2075, %"compiler/source:Span" %t2076, i1 %t2077)
  br label %bb521
bb521:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l28 = alloca ptr
  %l32 = alloca %"compiler/typed:Local"
  %l35 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l66 = alloca i32
  %l68 = alloca i64
  %l69 = alloca ptr
  %l73 = alloca ptr
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca ptr
  %l87 = alloca ptr
  %l89 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l102 = alloca i64
  %l106 = alloca { i64, i64, i64 }
  %l110 = alloca ptr
  %l121 = alloca ptr
  %l127 = alloca ptr
  %s0 = alloca %olang.scope
  %t109 = alloca { i64, [3 x i64] }, align 8
  %t207 = alloca { i64, [4 x i64] }, align 8
  %t242 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i32, ptr %l14, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l4, !tbaa !23
  %t17 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l21, !tbaa !21
  store i1 %t18, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l18, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l25
  br label %bb8
bb8:
  %t25 = load i1, ptr %l25, !tbaa !21
  %t26 = xor i1 %t25, true
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l22, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l28
  br label %bb13
bb13:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = trunc i64 %t32 to i32
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t38 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t36, i32 %t34)
  store %"compiler/typed:Local" %t38, ptr %l32
  br label %bb14
bb14:
  %t39 = getelementptr %"compiler/typed:Local", ptr %l32, i32 0, i32 4
  %t40 = load i32, ptr %t39, !range !{i32 0, i32 7}
  %t42 = trunc i64 6 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t45)
  store ptr %t47, ptr %l37
  br label %bb17
bb16:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb18
bb17:
  %t48 = load ptr, ptr %l37, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 13
  %t51 = load i1, ptr %t50, !tbaa !21
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l35, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  store ptr %t59, ptr %l43, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l46, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t66)
  store ptr %t68, ptr %l48
  br label %bb21
bb20:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb24
bb21:
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t73, i32 %t72)
  store i32 %t75, ptr %l51
  br label %bb22
bb22:
  %t76 = load ptr, ptr %l43, !tbaa !29
  %t77 = load i32, ptr %l51, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l52
  br label %bb23
bb23:
  %t79 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  %t82 = icmp eq i64 %t80, 0
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l40, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l2
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t91 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t85, %"compiler/source:Span" %t86, i32 %t87)
  store i64 %t91, ptr %l58
  br label %bb28
bb28:
  %t92 = load i64, ptr %l58, !tbaa !24
  store i64 %t92, ptr %l5, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l59, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t94, ptr %l60
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store i32 %t97, ptr %l63, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l64, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t100, ptr %l65
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t101, ptr %l66, !tbaa !23
  br i1 %a3, label %bb29, label %bb30
bb29:
  store i64 1, ptr %l68, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t104 = load ptr, ptr %l64, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l65
  %t106 = load i32, ptr %l66, !tbaa !23
  %t107 = load i64, ptr %l68, !tbaa !24
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t104, %"compiler/source:Span" %t105, i32 %t106, i64 %t107)
  store ptr %t108, ptr %l69
  br label %bb32
bb32:
  store { i64, [3 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [3 x i64] }, ptr %t109, i32 0, i32 0
  store i64 0, ptr %t110
  %t111 = load %"compiler/source:Span", ptr %l60
  %t112 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t111, 0
  %t113 = load i32, ptr %l63, !tbaa !23
  %t114 = insertvalue { %"compiler/source:Span", i32, ptr } %t112, i32 %t113, 1
  %t115 = load ptr, ptr %l69, !tbaa !29
  %t116 = insertvalue { %"compiler/source:Span", i32, ptr } %t114, ptr %t115, 2
  %t117 = getelementptr { i64, [3 x i64] }, ptr %t109, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t116, ptr %t117
  %t118 = load { i64, [3 x i64] }, ptr %t109
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t118, ptr %t120
  %t121 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t121, ptr %t120)
  br label %bb33
bb33:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t123)
  store ptr %t125, ptr %l73
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l73, !tbaa !29
  %t128 = getelementptr %"compiler/check:frame", ptr %t126, i32 0, i32 23
  %t129 = load i64, ptr %l1, !tbaa !24
  %t130 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t128, i64 %t129, i64 %t130)
  br label %bb35
bb35:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 83
  store ptr %t136, ptr %l79, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t137)
  store ptr %t139, ptr %l81
  br label %bb36
bb36:
  %t140 = load ptr, ptr %l81, !tbaa !29
  %t142 = getelementptr %"compiler/check:frame", ptr %t140, i32 0, i32 0
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = load ptr, ptr %l79, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t144, i64 %t143, i1 true)
  br label %bb37
bb37:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t146)
  store ptr %t148, ptr %l85
  br label %bb38
bb38:
  %t149 = load ptr, ptr %l85, !tbaa !29
  %t151 = getelementptr %"compiler/check:frame", ptr %t149, i32 0, i32 22
  store ptr %t151, ptr %l87, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t152)
  store ptr %t154, ptr %l89
  br label %bb39
bb39:
  %t155 = load ptr, ptr %l89, !tbaa !29
  %t157 = getelementptr %"compiler/check:frame", ptr %t155, i32 0, i32 7
  %t158 = load i64, ptr %t157, !tbaa !24
  %t159 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t159, i64 %t158)
  br label %bb40
bb40:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t161)
  store ptr %t163, ptr %l93
  br label %bb41
bb41:
  %t164 = load ptr, ptr %l93, !tbaa !29
  %t166 = getelementptr %"compiler/check:frame", ptr %t164, i32 0, i32 24
  store ptr %t166, ptr %l95, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t167)
  store ptr %t169, ptr %l97
  br label %bb42
bb42:
  %t170 = load ptr, ptr %l97, !tbaa !29
  %t172 = getelementptr %"compiler/check:frame", ptr %t170, i32 0, i32 7
  %t173 = load i64, ptr %t172, !tbaa !24
  %t174 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t174, i64 %t173)
  br label %bb43
bb43:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 48
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t178)
  store i64 %t180, ptr %l102
  br label %bb44
bb44:
  %t181 = load i64, ptr %l102, !tbaa !24
  store i64 %t181, ptr %l6, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l2
  %t187 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t182, i32 8, %"compiler/source:Span" %t183)
  store { i64, i64, i64 } %t187, ptr %l106
  br label %bb45
bb45:
  %t188 = load { i64, i64, i64 }, ptr %l106
  store { i64, i64, i64 } %t188, ptr %l7
  %t189 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t190 = load i64, ptr %t189, !tbaa !24
  store i64 %t190, ptr %l8, !tbaa !24
  %t192 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t193 = load i64, ptr %t192, !tbaa !24
  store i64 %t193, ptr %l9, !tbaa !24
  %t195 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t196 = load i64, ptr %t195, !tbaa !24
  store i64 %t196, ptr %l10, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l110, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l2
  %t201 = load %"compiler/source:Span", ptr %l2
  %t202 = load i32, ptr %l4, !tbaa !23
  %t203 = load i64, ptr %l1, !tbaa !24
  %t205 = trunc i64 %t203 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 0
  store i64 0, ptr %t208
  %t210 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t201, 0
  %t212 = insertvalue { %"compiler/source:Span", i32, i32 } %t210, i32 %t202, 1
  %t214 = insertvalue { %"compiler/source:Span", i32, i32 } %t212, i32 %t205, 2
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t214, ptr %t215
  %t216 = load { i64, [4 x i64] }, ptr %t207
  %t218 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t216, ptr %t218
  %t219 = load i64, ptr %l5, !tbaa !24
  %t224 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v0, ptr %v0, ptr %t199, %"compiler/source:Span" %t200, ptr %t218, i64 %t219)
  store ptr %t224, ptr %l121
  br label %bb46
bb46:
  %t225 = load ptr, ptr %l110, !tbaa !29
  %t226 = load ptr, ptr %l121, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t225, ptr %t226)
  br label %bb47
bb47:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i64, ptr %l8, !tbaa !24
  %t229 = load i64, ptr %l9, !tbaa !24
  %t230 = load i64, ptr %l10, !tbaa !24
  %t231 = load i64, ptr %l6, !tbaa !24
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t227, i64 %t228, i64 %t229, i64 %t230, i64 %t231)
  store ptr %t237, ptr %l127
  br label %bb48
bb48:
  %t238 = load ptr, ptr %l127, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load %"compiler/source:Span", ptr %l2
  store { i64, [3 x i64] } zeroinitializer, ptr %t242
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t242, i32 0, i32 0
  store i64 12, ptr %t243
  %t245 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t240, 0
  %t247 = insertvalue { %"compiler/source:Span", ptr } %t245, ptr %t238, 1
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t242, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t247, ptr %t248
  %t249 = load { i64, [3 x i64] }, ptr %t242
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t249, ptr %t251
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t239, ptr %t251)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldNotParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l12 = alloca ptr
  %l16 = alloca %"compiler/typed:Local"
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, ptr }
  %l26 = alloca %"compiler/diagmsg:Msg"
  %l27 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca %"compiler/typed:Local"
  %l41 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l46 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t11)
  store ptr %t13, ptr %l12
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 7
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/typed:Local" %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = getelementptr %"compiler/typed:Local", ptr %l16, i32 0, i32 4
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 7}
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t32, i32 %t33)
  store { i64, ptr } %t36, ptr %l24
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %s0, ptr %v0, { i64, ptr } %t37)
  store %"compiler/diagmsg:Msg" %t39, ptr %l26
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l21
  %t42 = load %"compiler/diagmsg:Msg", ptr %l26
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t40, %"compiler/source:Span" %t41, %"compiler/diagmsg:Msg" %t42)
  store i64 %t43, ptr %l27
  br label %bb12
bb12:
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/load:Loader", ptr %t51, i32 0, i32 4
  %t54 = load ptr, ptr %t53, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i64 %t44, ptr %l32, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l35
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 7
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t62, i64 %t63)
  store %"compiler/typed:Local" %t66, ptr %l39
  br label %bb14
bb14:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l39, i32 0, i32 1
  %t68 = load %"compiler/source:Span", ptr %t67
  %t69 = load ptr, ptr %l33, !tbaa !29
  %t71 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t69, %"compiler/source:Span" %t68)
  store { i64, [3 x i64] } %t71, ptr %l41
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l1, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l44
  br label %bb16
bb16:
  %t77 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t79 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s0, ptr %v0, { i64, ptr } %t77)
  store %"compiler/diagmsg:Msg" %t79, ptr %l46
  br label %bb17
bb17:
  %t80 = load ptr, ptr %l31, !tbaa !29
  %t81 = load i64, ptr %l32, !tbaa !24
  %t82 = load { i64, [3 x i64] }, ptr %l41
  %t83 = load %"compiler/diagmsg:Msg", ptr %l46
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t80, i64 %t81, { i64, [3 x i64] } %t82, %"compiler/diagmsg:Msg" %t83)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 14
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l24, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l25
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t52 = icmp slt i64 %t46, %t49
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l30, !tbaa !23
  br label %bb13
bb12:
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t62, ptr %l30, !tbaa !23
  br label %bb13
bb13:
  %t64 = load i32, ptr %l30, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypes(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l36 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l72 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca i32
  %l83 = alloca %"compiler/typed:Local"
  %l85 = alloca { i64, ptr }
  %l90 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i32
  %l108 = alloca i32
  %l113 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l15, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l20
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = load i32, ptr %l20, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l21
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l23
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 10
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l26
  %t29 = call ptr @__olang_scope_hold(ptr %s0)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l27, !tbaa !24
  %t31 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = call ptr @__olang_region_make_part(ptr %s0)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l27, !tbaa !24
  br label %bb5
bb5:
  %t35 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l29, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l30, !tbaa !24
  %t39 = load i64, ptr %l30, !tbaa !24
  %t40 = mul i64 %t39, 4
  %t41 = load i64, ptr %l27
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l30, !tbaa !24
  %t51 = mul i64 %t50, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t53 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0
  br i1 %t54, label %bb6, label %bb7
bb6:
  %t56 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t60 = icmp eq i64 %t58, 0
  br i1 %t60, label %bb8, label %bb9
bb7:
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l3
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l36, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t67, ptr %l38
  br label %bb10
bb8:
  %t68 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t68, !tbaa !27
  br label %bb9
bb9:
  %t69 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t70 = load i64, ptr %l27
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = load { i64, ptr }, ptr %t69
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = call ptr @__olang_region_or(ptr %t73, ptr null)
  %t75 = icmp ne ptr %t74, null
  %t76 = select i1 %t75, ptr %t74, ptr null
  call void @__olang_region_settle_in(ptr %t71, ptr %t76)
  br label %bb7
bb10:
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = load i64, ptr %l38, !tbaa !24
  %t79 = icmp ne i64 %t77, %t78
  br i1 %t79, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t81 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l41, !tbaa !24
  %t84 = load i64, ptr %l41, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb14, label %bb15
bb14:
  %t87 = load i64, ptr %l41, !tbaa !24
  %t88 = icmp sle i64 %t87, 2305843009213693951
  br i1 %t88, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_ad8923f011cb5acf_6f8a151e60866063)
  unreachable
bb16:
  %t90 = load i64, ptr %l41, !tbaa !24
  %t91 = mul i64 %t90, 4
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l4, !tbaa !27
  store i1 false, ptr %l5, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_ad8923f011cb5acf_6f8a151e60866063)
  unreachable
bb18:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb23
bb20:
  %t110 = load i64, ptr %l7, !tbaa !24
  %t111 = load i64, ptr %l6, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l53, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb22
bb22:
  %t126 = load i64, ptr %l53, !tbaa !24
  store i64 %t126, ptr %l50, !tbaa !24
  br label %bb23
bb23:
  %t127 = load i64, ptr %l50, !tbaa !24
  store i64 %t127, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb24
bb24:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb25, label %bb26
bb25:
  br label %bb38
bb26:
  br label %bb27
bb27:
  %t136 = load i64, ptr %l6, !tbaa !24
  %t137 = load i64, ptr %l10, !tbaa !24
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l11, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t147, ptr %l72, !tbaa !27
  %t148 = load i64, ptr %l11, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 %t148
  %t153 = load i32, ptr %t152, !tbaa !33
  %t156 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i32, ptr %t157, i64 %t146
  store i32 %t153, ptr %t158, !tbaa !33
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t159)
  store ptr %t161, ptr %l76
  br label %bb28
bb28:
  %t162 = load ptr, ptr %l76, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 7
  store ptr %t164, ptr %l78, !tbaa !29
  %t165 = load i64, ptr %l11, !tbaa !24
  %t168 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 %t165)
  store i32 %t168, ptr %l81
  br label %bb29
bb29:
  %t169 = load i32, ptr %l81, !tbaa !23
  %t170 = sext i32 %t169 to i64
  %t171 = load ptr, ptr %l78, !tbaa !29
  %t173 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t171, i64 %t170)
  store %"compiler/typed:Local" %t173, ptr %l83
  br label %bb30
bb30:
  %t174 = getelementptr %"compiler/typed:Local", ptr %l83, i32 0, i32 2
  %t175 = load i32, ptr %t174, !tbaa !23
  store i32 %t175, ptr %l12, !tbaa !23
  %t177 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t177, ptr %l85, !tbaa !27
  %t178 = load i64, ptr %l11, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 %t178
  %t183 = load i32, ptr %t182, !tbaa !33
  %t184 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t187 = icmp eq i32 %t183, %t184
  br i1 %t187, label %bb31, label %bb32
bb31:
  %t189 = load i32, ptr %l12, !tbaa !23
  %t190 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t193 = icmp ne i32 %t189, %t190
  store i1 %t193, ptr %l90, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb33
bb33:
  %t195 = load i1, ptr %l90, !tbaa !21
  br i1 %t195, label %bb34, label %bb35
bb34:
  %t196 = load i64, ptr %l11, !tbaa !24
  %t197 = load i32, ptr %l12, !tbaa !23
  %t200 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i32, ptr %t201, i64 %t196
  store i32 %t197, ptr %t202, !tbaa !33
  store i1 true, ptr %l5, !tbaa !21
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t203 = load i64, ptr %l10, !tbaa !24
  %t206 = add i64 %t203, 1
  store i64 %t206, ptr %l10, !tbaa !24
  br label %bb24
bb38:
  %t208 = load i1, ptr %l5, !tbaa !21
  br i1 %t208, label %bb39, label %bb40
bb39:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = getelementptr %"compiler/generic:Program", ptr %t213, i32 0, i32 2
  store ptr %t215, ptr %l102, !tbaa !29
  %t216 = load i32, ptr %l1, !tbaa !23
  store i32 %t216, ptr %l103, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 2
  %t223 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t226 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t222, { i64, ptr } %t223)
  store i32 %t226, ptr %l108
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 2
  %t233 = load i32, ptr %l1, !tbaa !23
  %t236 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDtorWritten(ptr %v0, ptr %t232, i32 %t233)
  store i1 %t236, ptr %l113
  br label %bb42
bb42:
  %t237 = load ptr, ptr %l102, !tbaa !29
  %t238 = load i32, ptr %l103, !tbaa !23
  %t239 = load i32, ptr %l108, !tbaa !23
  %t240 = load i1, ptr %l113, !tbaa !21
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %t237, i32 %t238, i32 %t239, i1 %t240)
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitRefs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l12 = alloca i32
  %l17 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l54 = alloca i1
  %l59 = alloca i64
  %l64 = alloca i64
  %l66 = alloca ptr
  %l71 = alloca ptr
  %l79 = alloca i64
  %l83 = alloca i1
  %l88 = alloca i64
  %l93 = alloca i1
  %l94 = alloca ptr
  %l102 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l108 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca %"compiler/typed:Promote"
  %l120 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca i32
  %l125 = alloca i32
  %l127 = alloca %"compiler/diagmsg:Msg"
  %l128 = alloca %"compiler/diagmsg:Msg"
  %l131 = alloca { i64, ptr }
  %l133 = alloca %"compiler/diagmsg:Msg"
  %l134 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l140 = alloca %"compiler/diagmsg:Msg"
  %l141 = alloca i64
  %l149 = alloca i64
  %l153 = alloca i1
  %l157 = alloca i1
  %l166 = alloca i1
  %l173 = alloca ptr
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t177 = alloca { i64, [4 x i64] }, align 8
  %t215 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l17
  br label %bb2
bb2:
  %t22 = load i32, ptr %l17, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l5, !tbaa !23
  %t30 = load i32, ptr %l6, !tbaa !23
  %t34 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t28, i32 %t29, i32 %t30)
  store i1 %t34, ptr %l23
  br label %bb3
bb3:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l5, !tbaa !23
  %t38 = load i32, ptr %l6, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t36, i32 %t37, i32 %t38)
  store i1 %t42, ptr %l28
  br label %bb6
bb6:
  %t43 = load i1, ptr %l28, !tbaa !21
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t44 = load i1, ptr %l24, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb8, label %bb9
bb8:
  store ptr null, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l5, !tbaa !23
  %t50 = load i32, ptr %l6, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsInPlace(ptr %v0, ptr %t48, i32 %t49, i32 %t50)
  store i1 %t54, ptr %l34
  br label %bb11
bb11:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t57, ptr %l36
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l6, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t58, i32 %t59)
  store { i64, ptr } %t62, ptr %l39
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t65 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRowsInPlaceLent(ptr %s2, ptr %v0, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t65, ptr %l41
  br label %bb15
bb15:
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l36
  %t68 = load %"compiler/diagmsg:Msg", ptr %l41
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t66, %"compiler/source:Span" %t67, %"compiler/diagmsg:Msg" %t68)
  store i64 %t69, ptr %l42
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t70, ptr %rv
  br label %ret
bb17:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l2, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l47
  br label %bb18
bb18:
  %t78 = load i1, ptr %l47, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l5, !tbaa !23
  %t86 = load i32, ptr %l6, !tbaa !23
  %t90 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i1 %t90, ptr %l54
  br label %bb21
bb20:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb22
bb21:
  %t91 = load i1, ptr %l54, !tbaa !21
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb22
bb22:
  %t92 = load i1, ptr %l48, !tbaa !21
  br i1 %t92, label %bb23, label %bb24
bb23:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t98, i32 %t99)
  store i64 %t102, ptr %l59
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l3, !tbaa !23
  %t112 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t108, i32 %t109)
  store i64 %t112, ptr %l64
  br label %bb26
bb26:
  %t113 = load i64, ptr %l59, !tbaa !24
  %t114 = load i64, ptr %l64, !tbaa !24
  %t115 = icmp ne i64 %t113, %t114
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l4
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t120 = load i32, ptr %l3, !tbaa !23
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %t117, %"compiler/source:Span" %t118, ptr %t119, i32 %t120)
  store ptr %t125, ptr %l71
  br label %bb29
bb28:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l66, !tbaa !29
  br label %bb30
bb29:
  %t129 = load ptr, ptr %l71, !tbaa !29
  store ptr %t129, ptr %l66, !tbaa !29
  br label %bb30
bb30:
  %t131 = load ptr, ptr %l66, !tbaa !29
  store ptr %t131, ptr %rv
  br label %ret
bb31:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %l3, !tbaa !23
  %t141 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t137, i32 %t138)
  store i64 %t141, ptr %l79
  br label %bb32
bb32:
  %t142 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t143 = load i64, ptr %l79, !tbaa !24
  %t145 = and i64 %t143, %t142
  %t147 = icmp ne i64 %t145, 0
  br i1 %t147, label %bb33, label %bb34
bb33:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l2, !tbaa !23
  %t158 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t154, i32 %t155)
  store i64 %t158, ptr %l88
  br label %bb35
bb34:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb36
bb35:
  %t159 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t160 = load i64, ptr %l88, !tbaa !24
  %t162 = and i64 %t160, %t159
  %t164 = icmp eq i64 %t162, 0
  store i1 %t164, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t166 = load i1, ptr %l83, !tbaa !21
  br i1 %t166, label %bb37, label %bb38
bb37:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = call i1 @compiler_2fcheck_2eisData(ptr %v1, ptr %t167)
  store i1 %t169, ptr %l93
  br label %bb39
bb38:
  br label %bb62
bb39:
  %t170 = load i1, ptr %l93, !tbaa !21
  br i1 %t170, label %bb40, label %bb41
bb40:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l94, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l4
  %t174 = load %"compiler/source:Span", ptr %l4
  %t175 = load i32, ptr %l5, !tbaa !23
  %t176 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t177, i32 0, i32 0
  store i64 2, ptr %t178
  %t180 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t174, 0
  %t182 = insertvalue { %"compiler/source:Span", i32, ptr } %t180, i32 %t175, 1
  %t184 = insertvalue { %"compiler/source:Span", i32, ptr } %t182, ptr %t176, 2
  %t185 = getelementptr { i64, [4 x i64] }, ptr %t177, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t184, ptr %t185
  %t186 = load { i64, [4 x i64] }, ptr %t177
  %t188 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t186, ptr %t188
  %t192 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t172, %"compiler/source:Span" %t173, ptr %t188)
  store ptr %t192, ptr %l102
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t193 = load i32, ptr %l6, !tbaa !23
  %t194 = load %"compiler/source:Span", ptr %l4
  %t195 = load ptr, ptr %l94, !tbaa !29
  %t196 = load ptr, ptr %l102, !tbaa !29
  %t199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t195, ptr %t196, i32 %t193, %"compiler/source:Span" %t194)
  store ptr %t199, ptr %l105
  br label %bb43
bb43:
  %t200 = load ptr, ptr %l105, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t201, ptr %l106
  %t202 = load i32, ptr %l3, !tbaa !23
  store i32 %t202, ptr %l107, !tbaa !23
  store ptr %t200, ptr %l108, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l4
  %t209 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t204, i32 2, %"compiler/source:Span" %t205)
  store i32 %t209, ptr %l112
  br label %bb44
bb44:
  %t210 = load ptr, ptr %l108, !tbaa !29
  %t211 = load i32, ptr %l112, !tbaa !23
  %t212 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v2, ptr %v2, ptr %t210, i32 %t211)
  store %"compiler/typed:Promote" %t212, ptr %l113
  br label %bb45
bb45:
  %t213 = load %"compiler/typed:Promote", ptr %l113
  %t214 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/typed:Promote" %t213, ptr %t214
  store { i64, [5 x i64] } zeroinitializer, ptr %t215
  %t216 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 0
  store i64 5, ptr %t216
  %t217 = load %"compiler/source:Span", ptr %l106
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t217, 0
  %t219 = load i32, ptr %l107, !tbaa !23
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr } %t218, i32 %t219, 1
  %t222 = insertvalue { %"compiler/source:Span", i32, ptr } %t220, ptr %t214, 2
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t222, ptr %t223
  %t224 = load { i64, [5 x i64] }, ptr %t215
  %t226 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t224, ptr %t226
  store ptr %t226, ptr %rv
  br label %ret
bb46:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t232 = load i32, ptr %l5, !tbaa !23
  %t235 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t231, i32 %t232)
  store i1 %t235, ptr %l120
  br label %bb47
bb47:
  %t236 = load i1, ptr %l120, !tbaa !21
  br i1 %t236, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l121, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t238, ptr %l122
  %t239 = load i32, ptr %l5, !tbaa !23
  store i32 %t239, ptr %l123, !tbaa !23
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t240)
  store i32 %t242, ptr %l125
  br label %bb50
bb49:
  br label %bb58
bb50:
  %t243 = load i32, ptr %l123, !tbaa !23
  %t244 = load i32, ptr %l125, !tbaa !23
  %t245 = icmp eq i32 %t243, %t244
  br i1 %t245, label %bb51, label %bb52
bb51:
  %t247 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTextWrite(ptr %v0)
  store %"compiler/diagmsg:Msg" %t247, ptr %l128
  br label %bb53
bb52:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l5, !tbaa !23
  %t252 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t248, i32 %t249)
  store { i64, ptr } %t252, ptr %l131
  br label %bb54
bb53:
  %t253 = load %"compiler/diagmsg:Msg", ptr %l128
  store %"compiler/diagmsg:Msg" %t253, ptr %l127
  br label %bb56
bb54:
  %t254 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t256 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImmutWrite(ptr %s6, ptr %v0, { i64, ptr } %t254)
  store %"compiler/diagmsg:Msg" %t256, ptr %l133
  br label %bb55
bb55:
  %t257 = load %"compiler/diagmsg:Msg", ptr %l133
  store %"compiler/diagmsg:Msg" %t257, ptr %l127
  br label %bb56
bb56:
  %t258 = load ptr, ptr %l121, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l122
  %t260 = load %"compiler/diagmsg:Msg", ptr %l127
  %t261 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t258, %"compiler/source:Span" %t259, %"compiler/diagmsg:Msg" %t260)
  store i64 %t261, ptr %l134
  br label %bb57
bb57:
  %t262 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  store ptr %t262, ptr %rv
  br label %ret
bb58:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l137, !tbaa !29
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l138, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t267, ptr %l139
  %t268 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %v0)
  store %"compiler/diagmsg:Msg" %t268, ptr %l140
  br label %bb59
bb59:
  %t269 = load ptr, ptr %l138, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l139
  %t271 = load %"compiler/diagmsg:Msg", ptr %l140
  %t272 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t269, %"compiler/source:Span" %t270, %"compiler/diagmsg:Msg" %t271)
  store i64 %t272, ptr %l141
  br label %bb60
bb60:
  %t273 = load ptr, ptr %l1, !tbaa !29
  %t274 = load ptr, ptr %l137, !tbaa !29
  %t275 = load i64, ptr %l141, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWalkUnique(ptr %v0, ptr %v1, ptr %t274, i64 %t275, ptr %t273)
  br label %bb61
bb61:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %rv
  br label %ret
bb62:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = getelementptr %"compiler/generic:Program", ptr %t283, i32 0, i32 2
  %t286 = load i32, ptr %l3, !tbaa !23
  %t289 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t285, i32 %t286)
  store i64 %t289, ptr %l149
  br label %bb63
bb63:
  %t290 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t291 = load i64, ptr %l149, !tbaa !24
  %t293 = and i64 %t291, %t290
  %t295 = icmp ne i64 %t293, 0
  br i1 %t295, label %bb64, label %bb65
bb64:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l4
  %t303 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroWritableRef(ptr %v0, ptr %v1, ptr %t297, ptr %t298, %"compiler/source:Span" %t299)
  store i1 %t303, ptr %l157
  br label %bb66
bb65:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb67
bb66:
  %t304 = load i1, ptr %l157, !tbaa !21
  %t305 = xor i1 %t304, true
  store i1 %t305, ptr %l153, !tbaa !21
  br label %bb67
bb67:
  %t307 = load i1, ptr %l153, !tbaa !21
  br i1 %t307, label %bb68, label %bb69
bb68:
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/check:Checker", ptr %t311, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t314, i32 0, i32 2
  %t317 = load i32, ptr %l5, !tbaa !23
  %t318 = load i32, ptr %l6, !tbaa !23
  %t322 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t316, i32 %t317, i32 %t318)
  store i1 %t322, ptr %l166
  br label %bb71
bb71:
  %t323 = load i1, ptr %l166, !tbaa !21
  br i1 %t323, label %bb72, label %bb73
bb72:
  %t324 = load ptr, ptr %l1, !tbaa !29
  store ptr %t324, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l4
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t330 = load i32, ptr %l3, !tbaa !23
  %t335 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %t327, %"compiler/source:Span" %t328, ptr %t329, i32 %t330)
  store ptr %t335, ptr %l173
  br label %bb75
bb75:
  %t336 = load ptr, ptr %l173, !tbaa !29
  store ptr %t336, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"compiler/check:b5aWalk"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t2 = alloca %"compiler/check:b5aWalk", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_3ab5aWalk_2ector(ptr %t2, ptr %v1, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t2, i64 296, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 296, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l6, i64 296, i1 false)
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t6, ptr %t7, i64 %a2)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t12 = load ptr, ptr %lp3
  %t13 = getelementptr %"compiler/check:b5aWalk", ptr %t12, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l12, !tbaa !24
  %t17 = load ptr, ptr %lp3
  %t18 = getelementptr %"compiler/check:b5aWalk", ptr %t17, i32 0, i32 2
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t18)
  store i64 %t20, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %lp3
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %lp3
  %t31 = getelementptr %"compiler/check:b5aWalk", ptr %t30, i32 0, i32 2
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l21
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i64 %t38)
  br label %bb12
bb12:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t44 = load ptr, ptr %lp3
  %t45 = getelementptr %"compiler/check:b5aWalk", ptr %t44, i32 0, i32 3
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l25
  %t47 = call ptr @__olang_scope_hold(ptr %v1)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l26, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = call ptr @__olang_region_make_part(ptr %v1)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l26, !tbaa !24
  br label %bb16
bb16:
  %t53 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l28, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l29, !tbaa !24
  %t57 = load i64, ptr %l29, !tbaa !24
  %t58 = mul i64 %t57, 8
  %t59 = load i64, ptr %l26
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = call ptr @__olang_held_alloc(ptr %t60, i64 %t58)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l30, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l29, !tbaa !24
  %t69 = mul i64 %t68, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %t67, i64 %t69, i1 false)
  %t70 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t71 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  store { i64, ptr } %t70, ptr %t71, !tbaa !27
  %t72 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t74 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t78 = icmp eq i64 %t76, 0
  br i1 %t78, label %bb19, label %bb20
bb18:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %rv
  br label %ret
bb19:
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t81, !tbaa !27
  br label %bb20
bb20:
  %t82 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  %t83 = load i64, ptr %l26
  %t84 = inttoptr i64 %t83 to ptr
  %t85 = load { i64, ptr }, ptr %t82
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = call ptr @__olang_region_or(ptr %t86, ptr null)
  %t88 = icmp ne ptr %t87, null
  %t89 = select i1 %t88, ptr %t87, ptr null
  call void @__olang_region_settle_in(ptr %t84, ptr %t89)
  br label %bb18
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalMut(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t4, i64 %a1, i32 %a2)
  store ptr %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/ast:VarDecl", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %t21)
  store i1 %t23, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t24 = load i1, ptr %l15, !tbaa !21
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l12, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l17 = alloca i32
  %l22 = alloca i32
  %l25 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca i1
  %l38 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca i1
  %l53 = alloca i1
  %l60 = alloca i32
  %l61 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i64
  %l81 = alloca i64
  %l88 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i1
  %l123 = alloca i1
  %l125 = alloca i1
  %l131 = alloca i32
  %l132 = alloca i1
  %l135 = alloca ptr
  %l140 = alloca i32
  %l142 = alloca i1
  %l145 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i1
  %l155 = alloca ptr
  %l160 = alloca i32
  %l163 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 12
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t11, i32 %a1)
  store i32 %t15, ptr %l17
  br label %bb4
bb4:
  %t16 = load i32, ptr %l17, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l22
  br label %bb5
bb5:
  %t27 = load i32, ptr %l22, !range !{i32 0, i32 33}
  store i32 %t27, ptr %l4
  %t28 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t30 = trunc i64 19 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l25, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l30
  br label %bb9
bb9:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = add i64 %t44, 1
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i32, ptr %l30, !tbaa !23
  %t50 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t47, i32 %t48, i64 %t46)
  store i1 %t50, ptr %l33
  br label %bb10
bb10:
  %t51 = load i1, ptr %l33, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
bb11:
  %t52 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t54 = trunc i64 22 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t59 = trunc i64 23 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l43
  br label %bb17
bb17:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i32, ptr %l43, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t74, i32 %t75, i64 %t73)
  store i1 %t77, ptr %l45
  br label %bb18
bb18:
  %t78 = load i1, ptr %l45, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb19:
  %t79 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t81 = trunc i64 18 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_968c62dd2cdb7cc9_e4aa23f03d53ae95)
  unreachable
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l53
  br label %bb29
bb29:
  %t95 = load i1, ptr %l53, !tbaa !21
  %t96 = xor i1 %t95, true
  br i1 %t96, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l60
  br label %bb33
bb33:
  %t109 = load i32, ptr %l60, !tbaa !23
  store i32 %t109, ptr %l5, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l61, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l66
  br label %bb34
bb34:
  %t121 = load ptr, ptr %l61, !tbaa !29
  %t122 = load i32, ptr %l66, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t121, i32 %t122)
  store { i64, ptr } %t123, ptr %l67
  br label %bb35
bb35:
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t124, ptr %l6, !tbaa !27
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l5, !tbaa !23
  %t134 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t130, i32 %t131)
  store i64 %t134, ptr %l72
  br label %bb36
bb36:
  %t135 = load i64, ptr %l72, !tbaa !24
  store i64 %t135, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l7, !tbaa !24
  %t138 = icmp sge i64 %t136, 0
  br i1 %t138, label %bb37, label %bb38
bb37:
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %l76, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 0
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/load:Loader", ptr %t147, i32 0, i32 10
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb40
bb39:
  %t152 = load i64, ptr %l76, !tbaa !24
  %t153 = load i64, ptr %l81, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  store i1 %t154, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  %t156 = load i1, ptr %l75, !tbaa !21
  br i1 %t156, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/load:Loader", ptr %t163, i32 0, i32 10
  %t166 = load i64, ptr %l7, !tbaa !24
  %t169 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t165, i64 %t166)
  store ptr %t169, ptr %l88
  br label %bb43
bb42:
  br label %bb84
bb43:
  %t170 = load ptr, ptr %l88, !tbaa !29
  %t172 = getelementptr %"compiler/load:Module", ptr %t170, i32 0, i32 2
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l8, !tbaa !27
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/load:Loader", ptr %t181, i32 0, i32 10
  %t184 = load i64, ptr %l7, !tbaa !24
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t183, i64 %t184)
  store ptr %t187, ptr %l96
  br label %bb44
bb44:
  %t188 = load ptr, ptr %l96, !tbaa !29
  %t190 = getelementptr %"compiler/load:Module", ptr %t188, i32 0, i32 3
  %t191 = load i1, ptr %t190, !tbaa !21
  br i1 %t191, label %bb45, label %bb46
bb45:
  %t193 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t195 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t193, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t195, ptr %l101
  br label %bb47
bb46:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb56
bb47:
  %t196 = load i1, ptr %l101, !tbaa !21
  br i1 %t196, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb51
bb49:
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t197, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t199, ptr %l104
  br label %bb50
bb50:
  %t200 = load i1, ptr %l104, !tbaa !21
  store i1 %t200, ptr %l102, !tbaa !21
  br label %bb51
bb51:
  %t201 = load i1, ptr %l102, !tbaa !21
  br i1 %t201, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb55
bb53:
  %t202 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t202, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t204, ptr %l107
  br label %bb54
bb54:
  %t205 = load i1, ptr %l107, !tbaa !21
  store i1 %t205, ptr %l105, !tbaa !21
  br label %bb55
bb55:
  %t206 = load i1, ptr %l105, !tbaa !21
  store i1 %t206, ptr %l99, !tbaa !21
  br label %bb56
bb56:
  %t207 = load i1, ptr %l99, !tbaa !21
  br i1 %t207, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t211 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t209, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t211, ptr %l110
  br label %bb60
bb60:
  %t212 = load i1, ptr %l110, !tbaa !21
  br i1 %t212, label %bb61, label %bb62
bb61:
  %t213 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t213, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t215, ptr %l113
  br label %bb63
bb62:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb64
bb63:
  %t216 = load i1, ptr %l113, !tbaa !21
  store i1 %t216, ptr %l111, !tbaa !21
  br label %bb64
bb64:
  %t217 = load i1, ptr %l111, !tbaa !21
  br i1 %t217, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb72
bb66:
  %t218 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t218, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t220, ptr %l116
  br label %bb67
bb67:
  %t221 = load i1, ptr %l116, !tbaa !21
  br i1 %t221, label %bb68, label %bb69
bb68:
  %t222 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t222, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t224, ptr %l119
  br label %bb70
bb69:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb71
bb70:
  %t225 = load i1, ptr %l119, !tbaa !21
  store i1 %t225, ptr %l117, !tbaa !21
  br label %bb71
bb71:
  %t226 = load i1, ptr %l117, !tbaa !21
  store i1 %t226, ptr %l114, !tbaa !21
  br label %bb72
bb72:
  %t227 = load i1, ptr %l114, !tbaa !21
  br i1 %t227, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t229 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t231 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t229, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t231, ptr %l122
  br label %bb76
bb76:
  %t232 = load i1, ptr %l122, !tbaa !21
  br i1 %t232, label %bb77, label %bb78
bb77:
  %t233 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t235 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t233, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t235, ptr %l125
  br label %bb79
bb78:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb80
bb79:
  %t236 = load i1, ptr %l125, !tbaa !21
  store i1 %t236, ptr %l123, !tbaa !21
  br label %bb80
bb80:
  %t237 = load i1, ptr %l123, !tbaa !21
  br i1 %t237, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb84:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  %t245 = load i32, ptr %l5, !tbaa !23
  %t248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t244, i32 %t245)
  store i32 %t248, ptr %l131
  br label %bb85
bb85:
  %t249 = load i32, ptr %l131, !range !{i32 0, i32 6}
  store i32 %t249, ptr %l9
  %t250 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t252 = trunc i64 0 to i32
  %t253 = icmp eq i32 %t250, %t252
  br i1 %t253, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l135, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 2
  %t262 = load i32, ptr %l3, !tbaa !23
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t261, i32 %t262)
  store i32 %t265, ptr %l140
  br label %bb89
bb89:
  %t266 = load i64, ptr %l2, !tbaa !24
  %t267 = load ptr, ptr %l135, !tbaa !29
  %t268 = load i32, ptr %l140, !tbaa !23
  %t270 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t267, i32 %t268, i64 %t266)
  store i1 %t270, ptr %l142
  br label %bb90
bb90:
  %t271 = load i1, ptr %l142, !tbaa !21
  store i1 %t271, ptr %l132, !tbaa !21
  br label %bb108
bb91:
  %t272 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t274 = trunc i64 1 to i32
  %t275 = icmp eq i32 %t272, %t274
  br i1 %t275, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l145, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = getelementptr %"compiler/generic:Program", ptr %t281, i32 0, i32 2
  %t284 = load i32, ptr %l3, !tbaa !23
  %t287 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t283, i32 %t284)
  store i32 %t287, ptr %l150
  br label %bb95
bb95:
  %t288 = load i64, ptr %l2, !tbaa !24
  %t289 = load ptr, ptr %l145, !tbaa !29
  %t290 = load i32, ptr %l150, !tbaa !23
  %t292 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t289, i32 %t290, i64 %t288)
  store i1 %t292, ptr %l152
  br label %bb96
bb96:
  %t293 = load i1, ptr %l152, !tbaa !21
  store i1 %t293, ptr %l132, !tbaa !21
  br label %bb108
bb97:
  %t294 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t296 = trunc i64 4 to i32
  %t297 = icmp eq i32 %t294, %t296
  br i1 %t297, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l155, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t305 = getelementptr %"compiler/generic:Program", ptr %t303, i32 0, i32 2
  %t306 = load i32, ptr %l3, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l160
  br label %bb101
bb101:
  %t310 = load i64, ptr %l2, !tbaa !24
  %t312 = add i64 %t310, 1
  %t313 = load ptr, ptr %l155, !tbaa !29
  %t314 = load i32, ptr %l160, !tbaa !23
  %t316 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t313, i32 %t314, i64 %t312)
  store i1 %t316, ptr %l163
  br label %bb102
bb102:
  %t317 = load i1, ptr %l163, !tbaa !21
  store i1 %t317, ptr %l132, !tbaa !21
  br label %bb108
bb103:
  br i1 true, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_9c0e2310e04cd1f8_9ba0cca7b5a93fa4)
  unreachable
bb108:
  %t318 = load i1, ptr %l132, !tbaa !21
  store i1 %t318, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillPaths(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca %"compiler/check:nullNarrow"
  %l59 = alloca i1
  %l63 = alloca %"compiler/check:nullNarrow"
  %l68 = alloca ptr
  %l69 = alloca i64
  %l73 = alloca %"compiler/check:nullNarrow"
  %l75 = alloca %"compiler/check:nullNarrow"
  %l81 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l109 = alloca %"compiler/check:narrowed"
  %l112 = alloca i1
  %l116 = alloca %"compiler/check:narrowed"
  %l121 = alloca ptr
  %l122 = alloca i64
  %l126 = alloca %"compiler/check:narrowed"
  %l128 = alloca %"compiler/check:narrowed"
  %l134 = alloca i64
  %l138 = alloca i64
  %l141 = alloca i64
  %l162 = alloca %"compiler/check:errNarrow"
  %l165 = alloca i1
  %l169 = alloca %"compiler/check:errNarrow"
  %l174 = alloca ptr
  %l175 = alloca i64
  %l179 = alloca %"compiler/check:errNarrow"
  %l181 = alloca %"compiler/check:errNarrow"
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l22, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 53
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 50
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l28
  br label %bb5
bb5:
  %t17 = load i64, ptr %l28, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb8:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l35, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l35, !tbaa !24
  store i64 %t44, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t45 = load i64, ptr %l32, !tbaa !24
  store i64 %t45, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb14:
  br label %bb15
bb15:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l8, !tbaa !24
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 50
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %s3, ptr %t66, i64 %t67)
  store %"compiler/check:nullNarrow" %t70, ptr %l56
  br label %bb16
bb16:
  %t71 = getelementptr %"compiler/check:nullNarrow", ptr %l56, i32 0, i32 3
  %t72 = load i1, ptr %t71, !tbaa !21
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/check:frame", ptr %t76, i32 0, i32 50
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store %"compiler/check:nullNarrow" %t82, ptr %l63
  br label %bb19
bb18:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb20
bb19:
  %t83 = getelementptr %"compiler/check:nullNarrow", ptr %l63, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t88 = icmp sgt i64 %t86, 1
  store i1 %t88, ptr %l59, !tbaa !21
  br label %bb20
bb20:
  %t90 = load i1, ptr %l59, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/check:frame", ptr %t91, i32 0, i32 50
  store ptr %t93, ptr %l68, !tbaa !29
  %t94 = load i64, ptr %l8, !tbaa !24
  store i64 %t94, ptr %l69, !tbaa !24
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/check:frame", ptr %t95, i32 0, i32 50
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t97, i64 %t98)
  store %"compiler/check:nullNarrow" %t101, ptr %l73
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t102 = load i64, ptr %l1, !tbaa !24
  %t103 = load %"compiler/check:nullNarrow", ptr %l73
  %t105 = call %"compiler/check:nullNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3anullNarrow_2eKilled(ptr %v0, ptr %v0, %"compiler/check:nullNarrow" %t103, i64 %t102)
  store %"compiler/check:nullNarrow" %t105, ptr %l75
  br label %bb24
bb24:
  %t106 = load ptr, ptr %l68, !tbaa !29
  %t107 = load i64, ptr %l69, !tbaa !24
  %t108 = load %"compiler/check:nullNarrow", ptr %l75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v0, ptr %t106, i64 %t107, %"compiler/check:nullNarrow" %t108)
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l7, !tbaa !24
  br label %bb12
bb28:
  store i64 0, ptr %l9, !tbaa !24
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/check:frame", ptr %t114, i32 0, i32 46
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t116)
  store i64 %t118, ptr %l81
  br label %bb29
bb29:
  %t119 = load i64, ptr %l81, !tbaa !24
  store i64 %t119, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb30, label %bb31
bb30:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb35
bb32:
  %t130 = load i64, ptr %l10, !tbaa !24
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = add i64 %t134, %t135
  %t140 = sub i64 %t138, 1
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = sdiv i64 %t140, %t141
  store i64 %t144, ptr %l88, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb34
bb34:
  %t146 = load i64, ptr %l88, !tbaa !24
  store i64 %t146, ptr %l85, !tbaa !24
  br label %bb35
bb35:
  %t147 = load i64, ptr %l85, !tbaa !24
  store i64 %t147, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load i64, ptr %l12, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb38:
  br label %bb39
bb39:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t157 = load i64, ptr %l13, !tbaa !24
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = mul i64 %t157, %t158
  %t164 = add i64 %t156, %t161
  store i64 %t164, ptr %l14, !tbaa !24
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr %"compiler/check:frame", ptr %t166, i32 0, i32 46
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %s7, ptr %t168, i64 %t169)
  store %"compiler/check:narrowed" %t172, ptr %l109
  br label %bb40
bb40:
  %t173 = getelementptr %"compiler/check:narrowed", ptr %l109, i32 0, i32 7
  %t174 = load i1, ptr %t173, !tbaa !21
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb41, label %bb42
bb41:
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = getelementptr %"compiler/check:frame", ptr %t178, i32 0, i32 46
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t180, i64 %t181)
  store %"compiler/check:narrowed" %t184, ptr %l116
  br label %bb43
bb42:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb44
bb43:
  %t185 = getelementptr %"compiler/check:narrowed", ptr %l116, i32 0, i32 5
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t190 = icmp sgt i64 %t188, 1
  store i1 %t190, ptr %l112, !tbaa !21
  br label %bb44
bb44:
  %t192 = load i1, ptr %l112, !tbaa !21
  br i1 %t192, label %bb45, label %bb46
bb45:
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t195 = getelementptr %"compiler/check:frame", ptr %t193, i32 0, i32 46
  store ptr %t195, ptr %l121, !tbaa !29
  %t196 = load i64, ptr %l14, !tbaa !24
  store i64 %t196, ptr %l122, !tbaa !24
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t199 = getelementptr %"compiler/check:frame", ptr %t197, i32 0, i32 46
  %t200 = load i64, ptr %l14, !tbaa !24
  %t203 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t199, i64 %t200)
  store %"compiler/check:narrowed" %t203, ptr %l126
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t204 = load i64, ptr %l1, !tbaa !24
  %t205 = load %"compiler/check:narrowed", ptr %l126
  %t207 = call %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(ptr %v0, ptr %v0, %"compiler/check:narrowed" %t205, i64 %t204)
  store %"compiler/check:narrowed" %t207, ptr %l128
  br label %bb48
bb48:
  %t208 = load ptr, ptr %l121, !tbaa !29
  %t209 = load i64, ptr %l122, !tbaa !24
  %t210 = load %"compiler/check:narrowed", ptr %l128
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %v0, ptr %t208, i64 %t209, %"compiler/check:narrowed" %t210)
  br label %bb49
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb51:
  %t211 = load i64, ptr %l13, !tbaa !24
  %t214 = add i64 %t211, 1
  store i64 %t214, ptr %l13, !tbaa !24
  br label %bb36
bb52:
  store i64 0, ptr %l15, !tbaa !24
  %t216 = load ptr, ptr %l2, !tbaa !29
  %t218 = getelementptr %"compiler/check:frame", ptr %t216, i32 0, i32 62
  %t220 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t218)
  store i64 %t220, ptr %l134
  br label %bb53
bb53:
  %t221 = load i64, ptr %l134, !tbaa !24
  store i64 %t221, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t222 = load i64, ptr %l16, !tbaa !24
  %t223 = load i64, ptr %l15, !tbaa !24
  %t226 = icmp sgt i64 %t222, %t223
  br i1 %t226, label %bb54, label %bb55
bb54:
  %t228 = load i64, ptr %l17, !tbaa !24
  %t230 = icmp sgt i64 %t228, 0
  br i1 %t230, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb59
bb56:
  %t232 = load i64, ptr %l16, !tbaa !24
  %t233 = load i64, ptr %l15, !tbaa !24
  %t236 = sub i64 %t232, %t233
  %t237 = load i64, ptr %l17, !tbaa !24
  %t240 = add i64 %t236, %t237
  %t242 = sub i64 %t240, 1
  %t243 = load i64, ptr %l17, !tbaa !24
  %t246 = sdiv i64 %t242, %t243
  store i64 %t246, ptr %l141, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb58
bb58:
  %t248 = load i64, ptr %l141, !tbaa !24
  store i64 %t248, ptr %l138, !tbaa !24
  br label %bb59
bb59:
  %t249 = load i64, ptr %l138, !tbaa !24
  store i64 %t249, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t250 = load i64, ptr %l19, !tbaa !24
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = icmp slt i64 %t250, %t251
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb62:
  br label %bb63
bb63:
  %t258 = load i64, ptr %l15, !tbaa !24
  %t259 = load i64, ptr %l19, !tbaa !24
  %t260 = load i64, ptr %l17, !tbaa !24
  %t263 = mul i64 %t259, %t260
  %t266 = add i64 %t258, %t263
  store i64 %t266, ptr %l20, !tbaa !24
  %t268 = load ptr, ptr %l2, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 62
  %t271 = load i64, ptr %l20, !tbaa !24
  %t274 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %s11, ptr %t270, i64 %t271)
  store %"compiler/check:errNarrow" %t274, ptr %l162
  br label %bb64
bb64:
  %t275 = getelementptr %"compiler/check:errNarrow", ptr %l162, i32 0, i32 4
  %t276 = load i1, ptr %t275, !tbaa !21
  %t278 = xor i1 %t276, true
  br i1 %t278, label %bb65, label %bb66
bb65:
  %t280 = load ptr, ptr %l2, !tbaa !29
  %t282 = getelementptr %"compiler/check:frame", ptr %t280, i32 0, i32 62
  %t283 = load i64, ptr %l20, !tbaa !24
  %t286 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %v0, ptr %t282, i64 %t283)
  store %"compiler/check:errNarrow" %t286, ptr %l169
  br label %bb67
bb66:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb68
bb67:
  %t287 = getelementptr %"compiler/check:errNarrow", ptr %l169, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t292 = icmp sgt i64 %t290, 1
  store i1 %t292, ptr %l165, !tbaa !21
  br label %bb68
bb68:
  %t294 = load i1, ptr %l165, !tbaa !21
  br i1 %t294, label %bb69, label %bb70
bb69:
  %t295 = load ptr, ptr %l2, !tbaa !29
  %t297 = getelementptr %"compiler/check:frame", ptr %t295, i32 0, i32 62
  store ptr %t297, ptr %l174, !tbaa !29
  %t298 = load i64, ptr %l20, !tbaa !24
  store i64 %t298, ptr %l175, !tbaa !24
  %t299 = load ptr, ptr %l2, !tbaa !29
  %t301 = getelementptr %"compiler/check:frame", ptr %t299, i32 0, i32 62
  %t302 = load i64, ptr %l20, !tbaa !24
  %t305 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %v0, ptr %t301, i64 %t302)
  store %"compiler/check:errNarrow" %t305, ptr %l179
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t306 = load i64, ptr %l1, !tbaa !24
  %t307 = load %"compiler/check:errNarrow", ptr %l179
  %t309 = call %"compiler/check:errNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3aerrNarrow_2eKilled(ptr %v0, ptr %v0, %"compiler/check:errNarrow" %t307, i64 %t306)
  store %"compiler/check:errNarrow" %t309, ptr %l181
  br label %bb72
bb72:
  %t310 = load ptr, ptr %l174, !tbaa !29
  %t311 = load i64, ptr %l175, !tbaa !24
  %t312 = load %"compiler/check:errNarrow", ptr %l181
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %v0, ptr %t310, i64 %t311, %"compiler/check:errNarrow" %t312)
  br label %bb73
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s11)
  br label %bb75
bb75:
  %t313 = load i64, ptr %l19, !tbaa !24
  %t316 = add i64 %t313, 1
  store i64 %t316, ptr %l19, !tbaa !24
  br label %bb60
bb76:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elinkTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/diagmsg:Msg"
  %l17 = alloca i64
  %l22 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca i32
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/diagmsg:Msg"
  %l38 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i32
  %l58 = alloca i1
  %l61 = alloca i1
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca i64
  %l79 = alloca i1
  %l80 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l90 = alloca i32
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efreshWritten(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i1, ptr %l8, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l9, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t8)
  store %"compiler/source:Span" %t10, ptr %l11
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l12, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l14
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l12, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l14
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t15, %"compiler/source:Span" %t16)
  store { i64, ptr } %t17, ptr %l15
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t19 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFresh(ptr %v0, ptr %v0, { i64, ptr } %t18)
  store %"compiler/diagmsg:Msg" %t19, ptr %l16
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l11
  %t22 = load %"compiler/diagmsg:Msg", ptr %l16
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t20, %"compiler/source:Span" %t21, %"compiler/diagmsg:Msg" %t22)
  store i64 %t23, ptr %l17
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t24, ptr %t25, i32 %t27)
  store ptr %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l22, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t33, ptr %t34, i32 %t36)
  store ptr %t40, ptr %l27
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l27, !tbaa !29
  store ptr %t41, ptr %l2, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t45 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t42)
  store i32 %t45, ptr %l30
  br label %bb12
bb12:
  %t46 = load i32, ptr %l30, !tbaa !23
  store i32 %t46, ptr %l3, !tbaa !23
  %t47 = load i32, ptr %l3, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t51 = icmp eq i32 %t47, %t48
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t54)
  store %"compiler/source:Span" %t56, ptr %l36
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0)
  store %"compiler/diagmsg:Msg" %t57, ptr %l37
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l34, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l36
  %t60 = load %"compiler/diagmsg:Msg", ptr %l37
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t58, %"compiler/source:Span" %t59, %"compiler/diagmsg:Msg" %t60)
  store i64 %t61, ptr %l38
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l39, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l41
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l41
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t66, %"compiler/source:Span" %t67)
  store ptr %t68, ptr %l42
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l42, !tbaa !29
  store ptr %t69, ptr %rv
  br label %ret
bb20:
  %t70 = load i32, ptr %l3, !tbaa !23
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t74 = icmp eq i32 %t70, %t71
  br i1 %t74, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb24
bb22:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l3, !tbaa !23
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l49
  br label %bb23
bb23:
  %t81 = load i1, ptr %l49, !tbaa !21
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t82 = load i1, ptr %l46, !tbaa !21
  br i1 %t82, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb28
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l55
  br label %bb27
bb27:
  %t93 = load i32, ptr %l55, !range !{i32 0, i32 33}
  %t95 = trunc i64 21 to i32
  %t96 = icmp eq i32 %t93, %t95
  store i1 %t96, ptr %l50, !tbaa !21
  br label %bb28
bb28:
  %t98 = load i1, ptr %l50, !tbaa !21
  br i1 %t98, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb32
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l3, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArg(ptr %v0, ptr %t99, i32 %t100)
  store i1 %t103, ptr %l61
  br label %bb31
bb31:
  %t104 = load i1, ptr %l61, !tbaa !21
  store i1 %t104, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t105 = load i1, ptr %l58, !tbaa !21
  br i1 %t105, label %bb33, label %bb34
bb33:
  %t106 = load ptr, ptr %l2, !tbaa !29
  store ptr %t106, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v2, ptr %t108)
  store ptr %t110, ptr %l64
  br label %bb36
bb36:
  %t111 = load ptr, ptr %l64, !tbaa !29
  store ptr %t111, ptr %l4, !tbaa !29
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  br i1 %t114, label %bb37, label %bb38
bb37:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l67, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t117)
  store %"compiler/source:Span" %t119, ptr %l69
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l70, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t121)
  store %"compiler/source:Span" %t123, ptr %l72
  br label %bb40
bb40:
  %t124 = load ptr, ptr %l70, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l72
  %t126 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t124, %"compiler/source:Span" %t125)
  store { i64, ptr } %t126, ptr %l73
  br label %bb41
bb41:
  %t127 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t128 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFresh(ptr %v0, ptr %v0, { i64, ptr } %t127)
  store %"compiler/diagmsg:Msg" %t128, ptr %l74
  br label %bb42
bb42:
  %t129 = load ptr, ptr %l67, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l69
  %t131 = load %"compiler/diagmsg:Msg", ptr %l74
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t129, %"compiler/source:Span" %t130, %"compiler/diagmsg:Msg" %t131)
  store i64 %t132, ptr %l75
  br label %bb43
bb43:
  %t133 = load ptr, ptr %l2, !tbaa !29
  store ptr %t133, ptr %rv
  br label %ret
bb44:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t139 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elinkWritable(ptr %v0, ptr %v2, ptr %t135, ptr %t136)
  store i1 %t139, ptr %l79
  br label %bb45
bb45:
  %t140 = load i1, ptr %l79, !tbaa !21
  br i1 %t140, label %bb46, label %bb47
bb46:
  %t141 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t141, ptr %l80, !tbaa !24
  br label %bb48
bb47:
  %t143 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t143, ptr %l80, !tbaa !24
  br label %bb48
bb48:
  %t145 = load i64, ptr %l80, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l83, !tbaa !29
  %t147 = load ptr, ptr %l2, !tbaa !29
  store ptr %t147, ptr %l84, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i32, ptr %l3, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t153, i32 %t154, i64 %t145)
  store i32 %t159, ptr %l90
  br label %bb49
bb49:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t160)
  store %"compiler/source:Span" %t162, ptr %l92
  br label %bb50
bb50:
  %t163 = load ptr, ptr %l83, !tbaa !29
  %t164 = load ptr, ptr %l84, !tbaa !29
  %t165 = load i32, ptr %l90, !tbaa !23
  %t166 = load %"compiler/source:Span", ptr %l92
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t163, ptr %t164, i32 %t165, %"compiler/source:Span" %t166)
  store ptr %t167, ptr %l93
  br label %bb51
bb51:
  %t168 = load ptr, ptr %l93, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elinkWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca ptr
  %l17 = alloca %"compiler/typed:Local"
  %l20 = alloca i1
  %l24 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l15
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l17
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 4
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 7}
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t32 = sext i32 %t30 to i64
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t29, i64 %t32)
  store i1 %t35, ptr %l24
  br label %bb10
bb9:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb10:
  %t36 = load i1, ptr %l24, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l20, !tbaa !21
  store i1 %t39, ptr %l7, !tbaa !21
  br label %bb44
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 1
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t51, i32 0, i32 2
  %t53 = load i64, ptr %t52
  store i64 %t53, ptr %l3, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t57, i32 0, i32 3
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l4, !tbaa !23
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i32, ptr %l4, !tbaa !23
  %t67 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalMut(ptr %v0, ptr %t61, i64 %t62, i32 %t63)
  store i1 %t67, ptr %l37
  br label %bb18
bb18:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %l7, !tbaa !21
  br label %bb44
bb19:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t70 = load ptr, ptr %l38, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 8}
  %t76 = icmp eq i64 %t74, 2
  store i1 %t76, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t77 = load i1, ptr %l39, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l44, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t88 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t85)
  store i32 %t88, ptr %l47
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l44, !tbaa !29
  %t90 = load i32, ptr %l47, !tbaa !23
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t91, ptr %l48
  br label %bb26
bb26:
  %t92 = load i1, ptr %l48, !tbaa !21
  br i1 %t92, label %bb27, label %bb28
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l52, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t102 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t99)
  store i32 %t102, ptr %l55
  br label %bb29
bb28:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb31
bb29:
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load i32, ptr %l55, !tbaa !23
  %t105 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t103, i32 %t104)
  store i64 %t105, ptr %l56
  br label %bb30
bb30:
  %t106 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t107 = load i64, ptr %l56, !tbaa !24
  %t109 = and i64 %t107, %t106
  %t111 = icmp ne i64 %t109, 0
  store i1 %t111, ptr %l49, !tbaa !21
  br label %bb31
bb31:
  %t113 = load i1, ptr %l49, !tbaa !21
  store i1 %t113, ptr %l7, !tbaa !21
  br label %bb44
bb32:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t115 = load ptr, ptr %l60, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t118 = load ptr, ptr %l60, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 8}
  %t121 = icmp eq i64 %t119, 3
  store i1 %t121, ptr %l61, !tbaa !21
  br label %bb34
bb34:
  %t122 = load i1, ptr %l61, !tbaa !21
  br i1 %t122, label %bb35, label %bb36
bb35:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elinkWritable(ptr %v0, ptr %v1, ptr %t129, ptr %t130)
  store i1 %t133, ptr %l68
  br label %bb38
bb38:
  %t134 = load i1, ptr %l68, !tbaa !21
  store i1 %t134, ptr %l7, !tbaa !21
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_684fdb51a9211423_400f786f6f1a912f)
  unreachable
bb44:
  %t135 = load i1, ptr %l7, !tbaa !21
  store i1 %t135, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutGlobalsValue(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i32
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l29 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l42 = alloca { i64, ptr }
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i32
  %l77 = alloca i32
  %l78 = alloca i32
  %l81 = alloca i1
  %l85 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i64
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 9
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp eq i64 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t15, ptr %l19, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l22
  br label %bb5
bb5:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l1
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/load:Loader", ptr %t39, i32 0, i32 9
  store ptr %t41, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l3, !tbaa !24
  store i64 %t43, ptr %l27, !tbaa !24
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l29
  br label %bb7
bb7:
  %t47 = load i64, ptr %l27, !tbaa !24
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = icmp slt i64 %t47, %t48
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t53, i64 %t54)
  store i64 %t57, ptr %l34
  br label %bb11
bb11:
  %t58 = load i64, ptr %l34, !tbaa !24
  store i64 %t58, ptr %l4, !tbaa !24
  store ptr %l1, ptr %l35, !tbaa !29
  %t59 = call ptr @__olang_scope_hold(ptr %s0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l36, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t63 = call ptr @__olang_region_make(ptr %s0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l36, !tbaa !24
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = trunc i64 %t66 to i32
  %t70 = load i64, ptr %l36
  %t71 = inttoptr i64 %t70 to ptr
  %t74 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %t71, ptr %t65, i32 %t68)
  store { i64, ptr } %t74, ptr %l42
  br label %bb14
bb14:
  %t75 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t76 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t76, { i64, ptr } %t75)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t78 = load i64, ptr %l3, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l3, !tbaa !24
  br label %bb6
bb17:
  %t83 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_14, 0
  %t84 = insertvalue { ptr, ptr } %t83, ptr null, 1
  %t87 = extractvalue { ptr, ptr } %t84, 0
  %t88 = extractvalue { ptr, ptr } %t84, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l1, ptr %t87, ptr %t88)
  br label %bb18
bb18:
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l49
  br label %bb19
bb19:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l5
  %t91 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t91, ptr %l50
  br label %bb20
bb20:
  %t92 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t92, ptr %l6
  %t93 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l51
  br label %bb21
bb21:
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l7
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/load:Loader", ptr %t101, i32 0, i32 9
  store ptr %t103, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  %t105 = load i64, ptr %l9, !tbaa !24
  store i64 %t105, ptr %l56, !tbaa !24
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t106)
  store i64 %t108, ptr %l58
  br label %bb23
bb23:
  %t109 = load i64, ptr %l56, !tbaa !24
  %t110 = load i64, ptr %l58, !tbaa !24
  %t111 = icmp slt i64 %t109, %t110
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t115 = load ptr, ptr %l8, !tbaa !29
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t115, i64 %t116)
  store i64 %t119, ptr %l63
  br label %bb27
bb27:
  %t120 = load i64, ptr %l63, !tbaa !24
  %t123 = trunc i64 %t120 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i32 %t123)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l9, !tbaa !24
  br label %bb22
bb30:
  br label %bb31
bb31:
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7)
  store i64 %t133, ptr %l72
  br label %bb32
bb32:
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = icmp sgt i64 %t134, 0
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb33, label %bb34
bb33:
  br label %bb53
bb34:
  br label %bb35
bb35:
  %t140 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePop_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7)
  %t141 = extractvalue { i32, i32 } %t140, 1
  %t142 = extractvalue { i32, i32 } %t140, 0
  store i32 %t142, ptr %l78
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb37, label %ok.144, !prof !99
ok.144:
  store i32 %t141, ptr %l77
  br label %bb36
bb36:
  %t145 = load i32, ptr %l77, !tbaa !23
  store i32 %t145, ptr %l75, !tbaa !23
  br label %bb39
bb37:
  br label %bb38
bb38:
  br label %bb53
bb39:
  %t146 = load i32, ptr %l75, !tbaa !23
  store i32 %t146, ptr %l11, !tbaa !23
  %t147 = load i32, ptr %l11, !tbaa !23
  %t149 = icmp eq i32 %t147, 0
  br i1 %t149, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb43
bb41:
  %t151 = load i32, ptr %l11, !tbaa !23
  %t153 = sext i32 %t151 to i64
  %t156 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l6, i64 %t153)
  store i1 %t156, ptr %l85
  br label %bb42
bb42:
  %t157 = load i1, ptr %l85, !tbaa !21
  store i1 %t157, ptr %l81, !tbaa !21
  br label %bb43
bb43:
  %t158 = load i1, ptr %l81, !tbaa !21
  br i1 %t158, label %bb44, label %bb45
bb44:
  br label %bb52
bb45:
  br label %bb46
bb46:
  %t159 = load i32, ptr %l11, !tbaa !23
  %t161 = sext i32 %t159 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l6, i64 %t161, i1 true)
  br label %bb47
bb47:
  store ptr %l5, ptr %l89, !tbaa !29
  %t164 = call ptr @__olang_scope_hold(ptr %s0)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l90, !tbaa !24
  %t166 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t166, label %bb48, label %bb49
bb48:
  %t168 = call ptr @__olang_region_make(ptr %s0)
  %t169 = ptrtoint ptr %t168 to i64
  store i64 %t169, ptr %l90, !tbaa !24
  br label %bb49
bb49:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l11, !tbaa !23
  %t172 = load i64, ptr %l90
  %t173 = inttoptr i64 %t172 to ptr
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeLine(ptr %v0, ptr %s0, ptr %t173, ptr %t170, i32 %t171, ptr %l7)
  store { i64, ptr } %t177, ptr %l95
  br label %bb50
bb50:
  %t178 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t179 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t179, { i64, ptr } %t178)
  br label %bb51
bb51:
  br label %bb52
bb52:
  br label %bb31
bb53:
  %t181 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_15, 0
  %t182 = insertvalue { ptr, ptr } %t181, ptr null, 1
  %t185 = extractvalue { ptr, ptr } %t182, 0
  %t186 = extractvalue { ptr, ptr } %t182, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l5, ptr %t185, ptr %t186)
  br label %bb54
bb54:
  %t188 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store { i64, ptr } %t188, ptr %l100
  br label %bb55
bb55:
  %t190 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store { i64, ptr } %t190, ptr %l102
  br label %bb56
bb56:
  %t191 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = add i64 %t196, %t199
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t192, i64 %t193)
  %t205 = getelementptr i8, ptr %t204, i64 %t193
  call void @olang_textcopy(ptr %t205, ptr %t194, i64 %t195)
  %t206 = getelementptr i8, ptr %t205, i64 %t195
  call void @olang_textcopy(ptr %t206, ptr %t198, i64 %t199)
  %t207 = getelementptr i8, ptr %t206, i64 %t199
  call void @olang_textcopy(ptr %t207, ptr %t201, i64 %t202)
  %t208 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t204, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t209, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoClearMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 7
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Make", ptr %t21, i32 0, i32 6
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l6, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_929b44a27af4e606_c6f0275d053ca0d2)
  unreachable
bb14:
  %t26 = load i1, ptr %l6, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, [3 x i64] }
  %l13 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i64
  %l41 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca i32
  %l55 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca i32
  %l79 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca ptr
  %l101 = alloca i1
  %l103 = alloca i1
  %l108 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/diagmsg:Msg"
  %l119 = alloca i64
  %l123 = alloca ptr
  %l128 = alloca i1
  %l129 = alloca i1
  %l134 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l138 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca %"compiler/diagmsg:Msg"
  %l145 = alloca i64
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca i32
  %l150 = alloca i64
  %l151 = alloca ptr
  %l154 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l157 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca %"compiler/diagmsg:Msg"
  %l168 = alloca i64
  %l170 = alloca ptr
  %l174 = alloca { i64, [3 x i64] }
  %l177 = alloca { i64, [3 x i64] }
  %l180 = alloca { i64, [3 x i64] }
  %l187 = alloca ptr
  %l188 = alloca i64
  %l189 = alloca { i64, [3 x i64] }
  %l190 = alloca %"compiler/diagmsg:Msg"
  %l191 = alloca ptr
  %l192 = alloca %"compiler/source:Span"
  %l193 = alloca i32
  %l195 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca i32
  %l205 = alloca %"compiler/source:Span"
  %l206 = alloca ptr
  %l214 = alloca ptr
  %l216 = alloca ptr
  %l220 = alloca ptr
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load i1, ptr %l15, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t5)
  store i1 %t7, ptr %l18
  br label %bb4
bb3:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb5
bb4:
  %t8 = load i1, ptr %l18, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l16, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i1, ptr %l4, !tbaa !21
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullTest(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %t12, %"compiler/source:Span" %t13, ptr %t14, ptr %t15, i1 %t16)
  store ptr %t22, ptr %l25
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t23 = load ptr, ptr %l25, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l26, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t25)
  store %"compiler/source:Span" %t27, ptr %l28
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l30
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l26, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l28
  %t33 = load %"compiler/source:Span", ptr %l30
  %t34 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/source:Span" %t33, i64 2)
  store %"compiler/source:Span" %t34, ptr %l31
  br label %bb12
bb12:
  %t35 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t35, ptr %l5
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t36)
  store i1 %t38, ptr %l33
  br label %bb13
bb13:
  %t39 = load i1, ptr %l33, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l34, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t41, ptr %l35
  %t42 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullTestOfNull(ptr %v0)
  store %"compiler/diagmsg:Msg" %t42, ptr %l36
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t43 = load ptr, ptr %l34, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l35
  %t45 = load %"compiler/diagmsg:Msg", ptr %l36
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t43, %"compiler/source:Span" %t44, %"compiler/diagmsg:Msg" %t45)
  store i64 %t46, ptr %l37
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t47, %"compiler/source:Span" %t48, i32 %t49, i64 0)
  store ptr %t53, ptr %l41
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l41, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t55, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l46
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l46, !tbaa !29
  store ptr %t63, ptr %l6, !tbaa !29
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t67 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t64)
  store i32 %t67, ptr %l49
  br label %bb21
bb21:
  %t68 = load i32, ptr %l49, !tbaa !23
  store i32 %t68, ptr %l7, !tbaa !23
  %t69 = load i32, ptr %l7, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp eq i32 %t69, %t70
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l1
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t75, %"compiler/source:Span" %t76)
  store ptr %t79, ptr %l55
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t80 = load ptr, ptr %l55, !tbaa !29
  store ptr %t80, ptr %rv
  br label %ret
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l7, !tbaa !23
  %t90 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t90, ptr %l60
  br label %bb26
bb26:
  %t91 = load i1, ptr %l60, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t94 = load ptr, ptr %l6, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v3, ptr %t92, ptr %t93, ptr %t94)
  store i1 %t98, ptr %l64
  br label %bb29
bb28:
  br label %bb47
bb29:
  %t99 = load i1, ptr %l64, !tbaa !21
  br i1 %t99, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l65, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t101, ptr %l66
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l67, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t103)
  store %"compiler/source:Span" %t105, ptr %l69
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t106 = load ptr, ptr %l67, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l69
  %t108 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s5, ptr %t106, %"compiler/source:Span" %t107)
  store { i64, ptr } %t108, ptr %l70
  br label %bb33
bb33:
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t111 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = add i64 %t110, %t113
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t109, i64 %t110)
  %t119 = getelementptr i8, ptr %t118, i64 %t110
  call void @olang_textcopy(ptr %t119, ptr %t112, i64 %t113)
  %t120 = getelementptr i8, ptr %t119, i64 %t113
  call void @olang_textcopy(ptr %t120, ptr %t115, i64 %t116)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t118, 1
  %t125 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %s5, ptr %v0, { i64, ptr } %t122)
  store %"compiler/diagmsg:Msg" %t125, ptr %l73
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l65, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l66
  %t128 = load %"compiler/diagmsg:Msg", ptr %l73
  %t129 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t126, %"compiler/source:Span" %t127, %"compiler/diagmsg:Msg" %t128)
  store i64 %t129, ptr %l74
  br label %bb35
bb35:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l75, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t131, ptr %l76
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t132, ptr %l77, !tbaa !23
  %t133 = load i1, ptr %l4, !tbaa !21
  br i1 %t133, label %bb36, label %bb37
bb36:
  store i64 1, ptr %l79, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb38
bb38:
  %t135 = load ptr, ptr %l75, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l76
  %t137 = load i32, ptr %l77, !tbaa !23
  %t138 = load i64, ptr %l79, !tbaa !24
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t135, %"compiler/source:Span" %t136, i32 %t137, i64 %t138)
  store ptr %t139, ptr %l80
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s5)
  %t140 = load ptr, ptr %l80, !tbaa !29
  store ptr %t140, ptr %rv
  br label %ret
bb40:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l81, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t142, ptr %l82
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t143, ptr %l83, !tbaa !23
  store i32 13, ptr %l84
  %t144 = load ptr, ptr %l6, !tbaa !29
  store ptr %t144, ptr %l85, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  %t147 = load i32, ptr %l7, !tbaa !23
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t145, %"compiler/source:Span" %t146, i32 %t147, i64 0)
  store ptr %t151, ptr %l89
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l89, !tbaa !29
  %t153 = load ptr, ptr %l81, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l82
  %t155 = load i32, ptr %l83, !tbaa !23
  %t156 = load i32, ptr %l84, !range !{i32 0, i32 54}
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t153, %"compiler/source:Span" %t154, i32 %t155, i32 %t156, ptr %t157, ptr %t152)
  store ptr %t159, ptr %l91
  br label %bb42
bb42:
  %t160 = load ptr, ptr %l91, !tbaa !29
  store ptr %t160, ptr %l8, !tbaa !29
  %t161 = load i1, ptr %l4, !tbaa !21
  br i1 %t161, label %bb43, label %bb44
bb43:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  %t165 = load ptr, ptr %l8, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t163, %"compiler/source:Span" %t164, ptr %t165)
  store ptr %t169, ptr %l97
  br label %bb45
bb44:
  %t170 = load ptr, ptr %l8, !tbaa !29
  store ptr %t170, ptr %l93, !tbaa !29
  br label %bb46
bb45:
  %t172 = load ptr, ptr %l97, !tbaa !29
  store ptr %t172, ptr %l93, !tbaa !29
  br label %bb46
bb46:
  %t173 = load ptr, ptr %l93, !tbaa !29
  store ptr %t173, ptr %rv
  br label %ret
bb47:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l7, !tbaa !23
  %t178 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t174, i32 %t175)
  store i1 %t178, ptr %l101
  br label %bb48
bb48:
  %t179 = load i1, ptr %l101, !tbaa !21
  %t180 = xor i1 %t179, true
  br i1 %t180, label %bb49, label %bb50
bb49:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 2
  %t188 = load i32, ptr %l7, !tbaa !23
  %t191 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t187, i32 %t188)
  store i32 %t191, ptr %l108
  br label %bb51
bb50:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb52
bb51:
  %t192 = load i32, ptr %l108, !range !{i32 0, i32 33}
  %t194 = trunc i64 21 to i32
  %t195 = icmp eq i32 %t192, %t194
  %t197 = xor i1 %t195, true
  store i1 %t197, ptr %l103, !tbaa !21
  br label %bb52
bb52:
  %t199 = load i1, ptr %l103, !tbaa !21
  br i1 %t199, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s7
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l112, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t201, ptr %l113
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l7, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t202, i32 %t203)
  store { i64, ptr } %t206, ptr %l116
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t207 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t209 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullTestOfValue(ptr %s7, ptr %v0, { i64, ptr } %t207)
  store %"compiler/diagmsg:Msg" %t209, ptr %l118
  br label %bb56
bb56:
  %t210 = load ptr, ptr %l112, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l113
  %t212 = load %"compiler/diagmsg:Msg", ptr %l118
  %t213 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t210, %"compiler/source:Span" %t211, %"compiler/diagmsg:Msg" %t212)
  store i64 %t213, ptr %l119
  br label %bb57
bb57:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  %t216 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t220 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t214, %"compiler/source:Span" %t215, i32 %t216, i64 0)
  store ptr %t220, ptr %l123
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  %t221 = load ptr, ptr %l123, !tbaa !29
  store ptr %t221, ptr %rv
  br label %ret
bb59:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l7, !tbaa !23
  %t231 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l128
  br label %bb60
bb60:
  %t232 = load i1, ptr %l128, !tbaa !21
  br i1 %t232, label %bb61, label %bb62
bb61:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t239 = load i32, ptr %l7, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t238, i32 %t239)
  store i1 %t242, ptr %l134
  br label %bb63
bb62:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb64
bb63:
  %t243 = load i1, ptr %l134, !tbaa !21
  %t244 = xor i1 %t243, true
  store i1 %t244, ptr %l129, !tbaa !21
  br label %bb64
bb64:
  %t246 = load i1, ptr %l129, !tbaa !21
  br i1 %t246, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s8
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l136, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t248, ptr %l137
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l138, !tbaa !29
  %t250 = load ptr, ptr %l2, !tbaa !29
  %t252 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t250)
  store %"compiler/source:Span" %t252, ptr %l140
  br label %bb67
bb66:
  br label %bb78
bb67:
  %t253 = load ptr, ptr %l138, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l140
  %t255 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t253, %"compiler/source:Span" %t254)
  store { i64, ptr } %t255, ptr %l141
  br label %bb68
bb68:
  %t256 = load i1, ptr %l4, !tbaa !21
  br i1 %t256, label %bb69, label %bb70
bb69:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l143, !tbaa !27
  br label %bb71
bb70:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l143, !tbaa !27
  br label %bb71
bb71:
  %t258 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t260 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %s8, ptr %v0, { i64, ptr } %t258, { i64, ptr } %t259)
  store %"compiler/diagmsg:Msg" %t260, ptr %l144
  br label %bb72
bb72:
  %t261 = load ptr, ptr %l136, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l137
  %t263 = load %"compiler/diagmsg:Msg", ptr %l144
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t261, %"compiler/source:Span" %t262, %"compiler/diagmsg:Msg" %t263)
  store i64 %t264, ptr %l145
  br label %bb73
bb73:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l146, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l147
  %t267 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t267, ptr %l148, !tbaa !23
  %t268 = load i1, ptr %l4, !tbaa !21
  br i1 %t268, label %bb74, label %bb75
bb74:
  store i64 1, ptr %l150, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb76
bb76:
  %t270 = load ptr, ptr %l146, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l147
  %t272 = load i32, ptr %l148, !tbaa !23
  %t273 = load i64, ptr %l150, !tbaa !24
  %t274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t270, %"compiler/source:Span" %t271, i32 %t272, i64 %t273)
  store ptr %t274, ptr %l151
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s8)
  %t275 = load ptr, ptr %l151, !tbaa !29
  store ptr %t275, ptr %rv
  br label %ret
bb78:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i32, ptr %l7, !tbaa !23
  %t280 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t276, i32 %t277)
  store i1 %t280, ptr %l154
  br label %bb79
bb79:
  %t281 = load i1, ptr %l154, !tbaa !21
  br i1 %t281, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l155, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t283, ptr %l156
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l157, !tbaa !29
  %t285 = load ptr, ptr %l2, !tbaa !29
  %t287 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t285)
  store %"compiler/source:Span" %t287, ptr %l159
  br label %bb82
bb81:
  br label %bb105
bb82:
  %t288 = load ptr, ptr %l157, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l159
  %t290 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t288, %"compiler/source:Span" %t289)
  store { i64, ptr } %t290, ptr %l160
  br label %bb83
bb83:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l7, !tbaa !23
  %t295 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t291, i32 %t292)
  store { i64, ptr } %t295, ptr %l163
  br label %bb84
bb84:
  %t296 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t296, ptr %l164, !tbaa !27
  %t297 = load i1, ptr %l4, !tbaa !21
  br i1 %t297, label %bb85, label %bb86
bb85:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l166, !tbaa !27
  br label %bb87
bb86:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l166, !tbaa !27
  br label %bb87
bb87:
  %t299 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t302 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %s9, ptr %s9, ptr %v0, { i64, ptr } %t299, { i64, ptr } %t300, { i64, ptr } %t301)
  store %"compiler/diagmsg:Msg" %t302, ptr %l167
  br label %bb88
bb88:
  %t303 = load ptr, ptr %l155, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l156
  %t305 = load %"compiler/diagmsg:Msg", ptr %l167
  %t306 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t303, %"compiler/source:Span" %t304, %"compiler/diagmsg:Msg" %t305)
  store i64 %t306, ptr %l168
  br label %bb89
bb89:
  %t307 = load i64, ptr %l168, !tbaa !24
  store i64 %t307, ptr %l9, !tbaa !24
  %t308 = load ptr, ptr %l6, !tbaa !29
  %t310 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v3, ptr %v3, ptr %t308)
  store ptr %t310, ptr %l170
  br label %bb90
bb90:
  %t311 = load ptr, ptr %l170, !tbaa !29
  store ptr %t311, ptr %l10, !tbaa !29
  %t312 = load ptr, ptr %l10, !tbaa !29
  %t314 = icmp eq ptr %t312, null
  %t316 = xor i1 %t314, true
  br i1 %t316, label %bb91, label %bb92
bb91:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load ptr, ptr %l10, !tbaa !29
  %t322 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v3, ptr %t318, ptr %t319)
  store { i64, [3 x i64] } %t322, ptr %l177
  br label %bb93
bb92:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l6, !tbaa !29
  %t327 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v3, ptr %t323, ptr %t324)
  store { i64, [3 x i64] } %t327, ptr %l180
  br label %bb94
bb93:
  %t328 = load { i64, [3 x i64] }, ptr %l177
  store { i64, [3 x i64] } %t328, ptr %l174
  br label %bb95
bb94:
  %t329 = load { i64, [3 x i64] }, ptr %l180
  store { i64, [3 x i64] } %t329, ptr %l174
  br label %bb95
bb95:
  %t330 = load { i64, [3 x i64] }, ptr %l174
  store { i64, [3 x i64] } %t330, ptr %l11
  %t331 = load { i64, [3 x i64] }, ptr %l11
  %t333 = extractvalue { i64, [3 x i64] } %t331, 0
  %t334 = icmp eq i64 %t333, 0
  %t336 = xor i1 %t334, true
  br i1 %t336, label %bb96, label %bb97
bb96:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/load:Loader", ptr %t344, i32 0, i32 4
  %t347 = load ptr, ptr %t346, !tbaa !29
  store ptr %t347, ptr %l187, !tbaa !29
  %t348 = load i64, ptr %l9, !tbaa !24
  store i64 %t348, ptr %l188, !tbaa !24
  %t349 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t349, ptr %l189
  %t350 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %v0)
  store %"compiler/diagmsg:Msg" %t350, ptr %l190
  br label %bb98
bb97:
  br label %bb100
bb98:
  %t351 = load ptr, ptr %l187, !tbaa !29
  %t352 = load i64, ptr %l188, !tbaa !24
  %t353 = load { i64, [3 x i64] }, ptr %l189
  %t354 = load %"compiler/diagmsg:Msg", ptr %l190
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t351, i64 %t352, { i64, [3 x i64] } %t353, %"compiler/diagmsg:Msg" %t354)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l191, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t356, ptr %l192
  %t357 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t357, ptr %l193, !tbaa !23
  %t358 = load i1, ptr %l4, !tbaa !21
  br i1 %t358, label %bb101, label %bb102
bb101:
  store i64 1, ptr %l195, !tbaa !24
  br label %bb103
bb102:
  store i64 0, ptr %l195, !tbaa !24
  br label %bb103
bb103:
  %t360 = load ptr, ptr %l191, !tbaa !29
  %t361 = load %"compiler/source:Span", ptr %l192
  %t362 = load i32, ptr %l193, !tbaa !23
  %t363 = load i64, ptr %l195, !tbaa !24
  %t364 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t360, %"compiler/source:Span" %t361, i32 %t362, i64 %t363)
  store ptr %t364, ptr %l196
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s9)
  %t365 = load ptr, ptr %l196, !tbaa !29
  store ptr %t365, ptr %rv
  br label %ret
bb105:
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l197, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l3, !tbaa !29
  %t370 = load i32, ptr %l7, !tbaa !23
  %t374 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t367, ptr %t368, i32 %t370)
  store ptr %t374, ptr %l202
  br label %bb106
bb106:
  %t375 = load i32, ptr %l7, !tbaa !23
  store i32 %t375, ptr %l203, !tbaa !23
  %t376 = load ptr, ptr %l3, !tbaa !29
  %t378 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t376)
  store %"compiler/source:Span" %t378, ptr %l205
  br label %bb107
bb107:
  %t379 = load ptr, ptr %l197, !tbaa !29
  %t380 = load ptr, ptr %l202, !tbaa !29
  %t381 = load i32, ptr %l203, !tbaa !23
  %t382 = load %"compiler/source:Span", ptr %l205
  %t383 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v3, ptr %t379, ptr %t380, i32 %t381, %"compiler/source:Span" %t382)
  store ptr %t383, ptr %l206
  br label %bb108
bb108:
  %t384 = load ptr, ptr %l206, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load %"compiler/source:Span", ptr %l1
  %t387 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t388 = load ptr, ptr %l6, !tbaa !29
  %t397 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t385, %"compiler/source:Span" %t386, i32 %t387, i32 19, ptr %t388, ptr %t384)
  store ptr %t397, ptr %l214
  br label %bb109
bb109:
  %t398 = load ptr, ptr %l214, !tbaa !29
  store ptr %t398, ptr %l13, !tbaa !29
  %t399 = load i1, ptr %l4, !tbaa !21
  br i1 %t399, label %bb110, label %bb111
bb110:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load %"compiler/source:Span", ptr %l1
  %t403 = load ptr, ptr %l13, !tbaa !29
  %t407 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t401, %"compiler/source:Span" %t402, ptr %t403)
  store ptr %t407, ptr %l220
  br label %bb112
bb111:
  %t408 = load ptr, ptr %l13, !tbaa !29
  store ptr %t408, ptr %l216, !tbaa !29
  br label %bb113
bb112:
  %t410 = load ptr, ptr %l220, !tbaa !29
  store ptr %t410, ptr %l216, !tbaa !29
  br label %bb113
bb113:
  %t411 = load ptr, ptr %l216, !tbaa !29
  store ptr %t411, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l79 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i32
  %l87 = alloca i1
  %l91 = alloca ptr
  %l95 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca i64
  %l110 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i64
  %l138 = alloca ptr
  %l147 = alloca i1
  %l151 = alloca ptr
  %l156 = alloca i1
  %l159 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i64
  %l164 = alloca i64
  %l171 = alloca i64
  %l172 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l175 = alloca i64
  %l177 = alloca i64
  %l182 = alloca i64
  %l183 = alloca ptr
  %l185 = alloca i64
  %l189 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l191 = alloca i64
  %l193 = alloca i64
  %l198 = alloca i64
  %l199 = alloca ptr
  %l200 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i32
  %l211 = alloca ptr
  %l213 = alloca i64
  %l214 = alloca i64
  %l225 = alloca i64
  %l228 = alloca i64
  %l250 = alloca i64
  %l254 = alloca i64
  %l258 = alloca i64
  %l261 = alloca i64
  %l281 = alloca i64
  %l283 = alloca i1
  %l286 = alloca i64
  %l300 = alloca ptr
  %l303 = alloca i64
  %l313 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l314 = alloca i64
  %l317 = alloca i64
  %l318 = alloca i32
  %l327 = alloca i64
  %l331 = alloca i64
  %l334 = alloca i64
  %l354 = alloca i64
  %l355 = alloca ptr
  %l356 = alloca ptr
  %l359 = alloca i64
  %l360 = alloca i64
  %l371 = alloca i64
  %l375 = alloca i64
  %l379 = alloca i64
  %l382 = alloca i64
  %l402 = alloca i1
  %l405 = alloca i64
  %l407 = alloca i1
  %l410 = alloca i64
  %l415 = alloca i64
  %l425 = alloca i64
  %l428 = alloca i64
  %l449 = alloca ptr
  %l452 = alloca i64
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l64
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l65
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 35
  store ptr %t7, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l68, !tbaa !24
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l70
  br label %bb4
bb4:
  %t13 = load i64, ptr %l68, !tbaa !24
  %t14 = load i64, ptr %l70, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t19, i64 %t20)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t23, ptr %l75
  br label %bb8
bb8:
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l75
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l7
  %t25 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = icmp ne i64 %t26, %t27
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb30
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 33
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t38 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t34, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l84
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb13, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l83
  br label %bb12
bb12:
  %t43 = load i64, ptr %l83, !tbaa !24
  store i64 %t43, ptr %l79, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l79, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l79, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb19
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 19
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l91
  br label %bb18
bb18:
  %t56 = load ptr, ptr %l91, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 11
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  store i1 %t61, ptr %l87, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l87, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb23
bb21:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t64)
  store i1 %t67, ptr %l98
  br label %bb22
bb22:
  %t68 = load i1, ptr %l98, !tbaa !21
  store i1 %t68, ptr %l95, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l95, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  store ptr %l4, ptr %l99, !tbaa !29
  %t70 = load i64, ptr %l8, !tbaa !24
  store i64 %t70, ptr %l100, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t72, ptr %l102
  br label %bb27
bb27:
  %t73 = load ptr, ptr %l99, !tbaa !29
  %t74 = load i64, ptr %l100, !tbaa !24
  %t75 = load i64, ptr %l102, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t73, i64 %t74, i64 %t75)
  br label %bb28
bb28:
  %t76 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t76)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb3
bb31:
  store i64 0, ptr %l9, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 19
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l110
  br label %bb32
bb32:
  %t89 = load i64, ptr %l110, !tbaa !24
  store i64 %t89, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb33, label %bb34
bb33:
  %t96 = load i64, ptr %l11, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb38
bb35:
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l117, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb37
bb37:
  %t116 = load i64, ptr %l117, !tbaa !24
  store i64 %t116, ptr %l114, !tbaa !24
  br label %bb38
bb38:
  %t117 = load i64, ptr %l114, !tbaa !24
  store i64 %t117, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  %t118 = load i64, ptr %l13, !tbaa !24
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb40, label %bb41
bb40:
  br label %bb68
bb41:
  br label %bb42
bb42:
  %t126 = load i64, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l14, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 19
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t138, i64 %t139)
  store ptr %t142, ptr %l138
  br label %bb43
bb43:
  %t143 = load ptr, ptr %l138, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Body", ptr %t143, i32 0, i32 1
  %t146 = load { i64, [2 x i64] }, ptr %t145
  store { i64, [2 x i64] } %t146, ptr %l15
  %t148 = load { i64, [2 x i64] }, ptr %l15
  %t150 = extractvalue { i64, [2 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 6
  br i1 %t151, label %bb44, label %bb45
bb44:
  %t153 = getelementptr { i64, [2 x i64] }, ptr %l15, i32 0, i32 1
  %t154 = getelementptr { i64, i32 }, ptr %t153, i32 0, i32 0
  %t155 = load i64, ptr %t154
  store i64 %t155, ptr %l16, !tbaa !24
  br label %bb46
bb45:
  br label %bb61
bb46:
  %t157 = load i64, ptr %l16, !tbaa !24
  %t158 = load i64, ptr %l1, !tbaa !24
  %t161 = icmp eq i64 %t157, %t158
  br i1 %t161, label %bb47, label %bb48
bb47:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 19
  %t166 = load i64, ptr %l14, !tbaa !24
  %t169 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t165, i64 %t166)
  store ptr %t169, ptr %l151
  br label %bb49
bb48:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb50
bb49:
  %t170 = load ptr, ptr %l151, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t170, i32 0, i32 11
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = icmp eq ptr %t173, null
  %t177 = xor i1 %t175, true
  store i1 %t177, ptr %l147, !tbaa !21
  br label %bb50
bb50:
  %t179 = load i1, ptr %l147, !tbaa !21
  br i1 %t179, label %bb51, label %bb52
bb51:
  %t180 = load i64, ptr %l14, !tbaa !24
  %t183 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t180)
  store i1 %t183, ptr %l159
  br label %bb53
bb52:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb54
bb53:
  %t184 = load i1, ptr %l159, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l156, !tbaa !21
  br label %bb54
bb54:
  %t187 = load i1, ptr %l156, !tbaa !21
  br i1 %t187, label %bb55, label %bb56
bb55:
  store ptr %l4, ptr %l161, !tbaa !29
  %t188 = load i64, ptr %l14, !tbaa !24
  store i64 %t188, ptr %l162, !tbaa !24
  %t190 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t190, ptr %l164
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t191 = load ptr, ptr %l161, !tbaa !29
  %t192 = load i64, ptr %l162, !tbaa !24
  %t193 = load i64, ptr %l164, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t191, i64 %t192, i64 %t193)
  br label %bb58
bb58:
  %t194 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t194)
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_eb65b3680edb0345_685145072e457a11)
  unreachable
bb66:
  br label %bb67
bb67:
  %t197 = load i64, ptr %l13, !tbaa !24
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %l13, !tbaa !24
  br label %bb39
bb68:
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t203, ptr %l171
  br label %bb69
bb69:
  %t204 = load i64, ptr %l171, !tbaa !24
  store i64 %t204, ptr %l17, !tbaa !24
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l172
  br label %bb70
bb70:
  %t206 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l172
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l18
  %t207 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t207, ptr %l173
  br label %bb71
bb71:
  %t208 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t208, ptr %l19
  store ptr %l3, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb72
bb72:
  %t210 = load i64, ptr %l21, !tbaa !24
  store i64 %t210, ptr %l175, !tbaa !24
  %t211 = load ptr, ptr %l20, !tbaa !29
  %t213 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t211)
  store i64 %t213, ptr %l177
  br label %bb73
bb73:
  %t214 = load i64, ptr %l175, !tbaa !24
  %t215 = load i64, ptr %l177, !tbaa !24
  %t216 = icmp slt i64 %t214, %t215
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb74, label %bb75
bb74:
  br label %bb95
bb75:
  br label %bb76
bb76:
  %t220 = load ptr, ptr %l20, !tbaa !29
  %t221 = load i64, ptr %l21, !tbaa !24
  %t224 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t220, i64 %t221)
  store i64 %t224, ptr %l182
  br label %bb77
bb77:
  %t225 = load i64, ptr %l182, !tbaa !24
  store i64 %t225, ptr %l22, !tbaa !24
  store ptr %l18, ptr %l183, !tbaa !29
  %t227 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t227, ptr %l185
  br label %bb78
bb78:
  %t228 = load ptr, ptr %l183, !tbaa !29
  %t229 = load i64, ptr %l185, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t228, i64 %t229)
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l1, !tbaa !24
  %t232 = load i64, ptr %l22, !tbaa !24
  %t236 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %s14, ptr %t230, i64 %t231, i64 %t232)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t236, ptr %l189
  br label %bb80
bb80:
  %t237 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l189
  %t238 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t237, ptr %t238
  store ptr %t238, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb81
bb81:
  %t240 = load i64, ptr %l24, !tbaa !24
  store i64 %t240, ptr %l191, !tbaa !24
  %t241 = load ptr, ptr %l23, !tbaa !29
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s14, ptr %t241)
  store i64 %t243, ptr %l193
  br label %bb82
bb82:
  %t244 = load i64, ptr %l191, !tbaa !24
  %t245 = load i64, ptr %l193, !tbaa !24
  %t246 = icmp slt i64 %t244, %t245
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb83, label %bb84
bb83:
  br label %bb93
bb84:
  br label %bb85
bb85:
  %t250 = load ptr, ptr %l23, !tbaa !29
  %t251 = load i64, ptr %l24, !tbaa !24
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s14, ptr %t250, i64 %t251)
  store i64 %t254, ptr %l198
  br label %bb86
bb86:
  %t255 = load i64, ptr %l198, !tbaa !24
  store ptr %l19, ptr %l199, !tbaa !29
  %t259 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t255)
  %t260 = extractvalue { i32, i64 } %t259, 1
  %t261 = extractvalue { i32, i64 } %t259, 0
  store i32 %t261, ptr %l204
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb88, label %ok.263, !prof !99
ok.263:
  store i64 %t260, ptr %l203
  br label %bb87
bb87:
  %t264 = load i64, ptr %l203, !tbaa !24
  store i64 %t264, ptr %l200, !tbaa !24
  br label %bb90
bb88:
  br label %bb89
bb89:
  store i64 -1, ptr %l200, !tbaa !24
  br label %bb90
bb90:
  %t265 = load ptr, ptr %l199, !tbaa !29
  %t266 = load i64, ptr %l200, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t265, i64 %t266)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t267 = load i64, ptr %l24, !tbaa !24
  %t270 = add i64 %t267, 1
  store i64 %t270, ptr %l24, !tbaa !24
  br label %bb81
bb93:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb94:
  %t272 = load i64, ptr %l21, !tbaa !24
  %t275 = add i64 %t272, 1
  store i64 %t275, ptr %l21, !tbaa !24
  br label %bb72
bb95:
  store ptr %l18, ptr %l211, !tbaa !29
  %t278 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t278, ptr %l213
  br label %bb96
bb96:
  %t279 = load ptr, ptr %l211, !tbaa !29
  %t280 = load i64, ptr %l213, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t279, i64 %t280)
  br label %bb97
bb97:
  %t281 = load i64, ptr %l17, !tbaa !24
  store i64 %t281, ptr %l214, !tbaa !24
  %t282 = load i64, ptr %l214, !tbaa !24
  %t283 = icmp sge i64 %t282, 0
  br i1 %t283, label %bb98, label %bb99
bb98:
  %t285 = load i64, ptr %l214, !tbaa !24
  %t286 = mul i64 %t285, 1
  %t287 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t286)
  %t288 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  store { i64, ptr } %t289, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_becd3eb77e076db3_2d856a700a1e74b7)
  unreachable
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t291 = load i64, ptr %l27, !tbaa !24
  %t292 = load i64, ptr %l17, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s18)
  br label %bb232
bb102:
  br label %bb103
bb103:
  store i64 -1, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  %t299 = load i64, ptr %l17, !tbaa !24
  store i64 %t299, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t301 = load i64, ptr %l30, !tbaa !24
  %t302 = load i64, ptr %l29, !tbaa !24
  %t305 = icmp sgt i64 %t301, %t302
  br i1 %t305, label %bb104, label %bb105
bb104:
  %t307 = load i64, ptr %l31, !tbaa !24
  %t309 = icmp sgt i64 %t307, 0
  br i1 %t309, label %bb106, label %bb107
bb105:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb109
bb106:
  %t311 = load i64, ptr %l30, !tbaa !24
  %t312 = load i64, ptr %l29, !tbaa !24
  %t315 = sub i64 %t311, %t312
  %t316 = load i64, ptr %l31, !tbaa !24
  %t319 = add i64 %t315, %t316
  %t321 = sub i64 %t319, 1
  %t322 = load i64, ptr %l31, !tbaa !24
  %t325 = sdiv i64 %t321, %t322
  store i64 %t325, ptr %l228, !tbaa !24
  br label %bb108
bb107:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb108
bb108:
  %t327 = load i64, ptr %l228, !tbaa !24
  store i64 %t327, ptr %l225, !tbaa !24
  br label %bb109
bb109:
  %t328 = load i64, ptr %l225, !tbaa !24
  store i64 %t328, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb110
bb110:
  %t329 = load i64, ptr %l33, !tbaa !24
  %t330 = load i64, ptr %l32, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb111, label %bb112
bb111:
  br label %bb143
bb112:
  br label %bb113
bb113:
  %t337 = load i64, ptr %l29, !tbaa !24
  %t338 = load i64, ptr %l33, !tbaa !24
  %t339 = load i64, ptr %l31, !tbaa !24
  %t342 = mul i64 %t338, %t339
  %t345 = add i64 %t337, %t342
  store i64 %t345, ptr %l34, !tbaa !24
  %t347 = load i64, ptr %l34, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr i1, ptr %t350, i64 %t347
  %t352 = load i1, ptr %t351, !tbaa !31
  br i1 %t352, label %bb114, label %bb115
bb114:
  br label %bb142
bb115:
  br label %bb116
bb116:
  store i1 true, ptr %l35, !tbaa !21
  %t354 = load i64, ptr %l34, !tbaa !24
  %t357 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t354)
  store i64 %t357, ptr %l250
  br label %bb117
bb117:
  %t358 = load i64, ptr %l250, !tbaa !24
  store i64 %t358, ptr %l36, !tbaa !24
  %t359 = load i64, ptr %l34, !tbaa !24
  %t361 = add i64 %t359, 1
  %t364 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t361)
  store i64 %t364, ptr %l254
  br label %bb118
bb118:
  %t365 = load i64, ptr %l254, !tbaa !24
  store i64 %t365, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t366 = load i64, ptr %l37, !tbaa !24
  %t367 = load i64, ptr %l36, !tbaa !24
  %t370 = icmp sgt i64 %t366, %t367
  br i1 %t370, label %bb119, label %bb120
bb119:
  %t372 = load i64, ptr %l38, !tbaa !24
  %t374 = icmp sgt i64 %t372, 0
  br i1 %t374, label %bb121, label %bb122
bb120:
  store i64 0, ptr %l258, !tbaa !24
  br label %bb124
bb121:
  %t376 = load i64, ptr %l37, !tbaa !24
  %t377 = load i64, ptr %l36, !tbaa !24
  %t380 = sub i64 %t376, %t377
  %t381 = load i64, ptr %l38, !tbaa !24
  %t384 = add i64 %t380, %t381
  %t386 = sub i64 %t384, 1
  %t387 = load i64, ptr %l38, !tbaa !24
  %t390 = sdiv i64 %t386, %t387
  store i64 %t390, ptr %l261, !tbaa !24
  br label %bb123
bb122:
  store i64 0, ptr %l261, !tbaa !24
  br label %bb123
bb123:
  %t392 = load i64, ptr %l261, !tbaa !24
  store i64 %t392, ptr %l258, !tbaa !24
  br label %bb124
bb124:
  %t393 = load i64, ptr %l258, !tbaa !24
  store i64 %t393, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb125
bb125:
  %t394 = load i64, ptr %l40, !tbaa !24
  %t395 = load i64, ptr %l39, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb126, label %bb127
bb126:
  br label %bb138
bb127:
  br label %bb128
bb128:
  %t402 = load i64, ptr %l36, !tbaa !24
  %t403 = load i64, ptr %l40, !tbaa !24
  %t404 = load i64, ptr %l38, !tbaa !24
  %t407 = mul i64 %t403, %t404
  %t410 = add i64 %t402, %t407
  store i64 %t410, ptr %l41, !tbaa !24
  %t412 = load i64, ptr %l41, !tbaa !24
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t412)
  store i64 %t415, ptr %l281
  br label %bb129
bb129:
  %t416 = load i64, ptr %l281, !tbaa !24
  %t417 = icmp sge i64 %t416, 0
  br i1 %t417, label %bb130, label %bb131
bb130:
  %t419 = load i64, ptr %l41, !tbaa !24
  %t422 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t419)
  store i64 %t422, ptr %l286
  br label %bb132
bb131:
  store i1 false, ptr %l283, !tbaa !21
  br label %bb133
bb132:
  %t423 = load i64, ptr %l286, !tbaa !24
  %t424 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr i1, ptr %t425, i64 %t423
  %t427 = load i1, ptr %t426, !tbaa !31
  %t429 = xor i1 %t427, true
  store i1 %t429, ptr %l283, !tbaa !21
  br label %bb133
bb133:
  %t431 = load i1, ptr %l283, !tbaa !21
  br i1 %t431, label %bb134, label %bb135
bb134:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb136
bb135:
  br label %bb136
bb136:
  br label %bb137
bb137:
  %t432 = load i64, ptr %l40, !tbaa !24
  %t435 = add i64 %t432, 1
  store i64 %t435, ptr %l40, !tbaa !24
  br label %bb125
bb138:
  %t437 = load i1, ptr %l35, !tbaa !21
  br i1 %t437, label %bb139, label %bb140
bb139:
  %t439 = load i64, ptr %l34, !tbaa !24
  store i64 %t439, ptr %l28, !tbaa !24
  br label %bb143
bb140:
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t441 = load i64, ptr %l33, !tbaa !24
  %t444 = add i64 %t441, 1
  store i64 %t444, ptr %l33, !tbaa !24
  br label %bb110
bb143:
  %t446 = load i64, ptr %l28, !tbaa !24
  %t448 = icmp sge i64 %t446, 0
  br i1 %t448, label %bb144, label %bb145
bb144:
  %t450 = load i64, ptr %l28, !tbaa !24
  %t452 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !27
  %t454 = getelementptr i1, ptr %t453, i64 %t450
  store i1 true, ptr %t454, !tbaa !31
  %t455 = load ptr, ptr %l2, !tbaa !29
  store ptr %t455, ptr %l300, !tbaa !29
  %t456 = load i64, ptr %l28, !tbaa !24
  %t459 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t456)
  store i64 %t459, ptr %l303
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t460 = load ptr, ptr %l300, !tbaa !29
  %t461 = load i64, ptr %l303, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t460, i64 %t461)
  br label %bb147
bb147:
  %t462 = load i64, ptr %l27, !tbaa !24
  %t465 = add i64 %t462, 1
  store i64 %t465, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb231
bb148:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb149
bb149:
  %t467 = load i64, ptr %l42, !tbaa !24
  %t469 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !27
  %t471 = getelementptr i1, ptr %t470, i64 %t467
  %t472 = load i1, ptr %t471, !tbaa !31
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb150, label %bb151
bb150:
  br label %bb154
bb151:
  br label %bb152
bb152:
  %t476 = load i64, ptr %l42, !tbaa !24
  %t479 = add i64 %t476, 1
  store i64 %t479, ptr %l42, !tbaa !24
  br label %bb153
bb153:
  br label %bb149
bb154:
  %t481 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t481, ptr %l313
  br label %bb155
bb155:
  %t482 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l313
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t482, ptr %l43
  br label %bb156
bb156:
  %t483 = load i64, ptr %l42, !tbaa !24
  %t486 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %s18, ptr %l43, i64 %t483)
  %t487 = extractvalue { i32, i64 } %t486, 1
  %t488 = extractvalue { i32, i64 } %t486, 0
  store i32 %t488, ptr %l318
  %t489 = icmp ne i32 %t488, 0
  br i1 %t489, label %bb158, label %ok.490, !prof !99
ok.490:
  store i64 %t487, ptr %l317
  br label %bb157
bb157:
  %t491 = load i64, ptr %l317, !tbaa !24
  store i64 %t491, ptr %l314, !tbaa !24
  br label %bb160
bb158:
  br label %bb159
bb159:
  store i64 -1, ptr %l314, !tbaa !24
  br label %bb160
bb160:
  %t492 = load i64, ptr %l314, !tbaa !24
  store i64 %t492, ptr %l44, !tbaa !24
  %t493 = load i64, ptr %l44, !tbaa !24
  %t495 = icmp sge i64 %t493, 0
  br i1 %t495, label %bb161, label %bb162
bb161:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %s0, ptr %s18, ptr %t497, ptr %l3, ptr %l43, i64 %t498)
  br label %bb163
bb162:
  br label %bb181
bb163:
  %t503 = load i64, ptr %l44, !tbaa !24
  store i64 %t503, ptr %l45, !tbaa !24
  %t506 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l43)
  store i64 %t506, ptr %l327
  br label %bb164
bb164:
  %t507 = load i64, ptr %l327, !tbaa !24
  store i64 %t507, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t508 = load i64, ptr %l46, !tbaa !24
  %t509 = load i64, ptr %l45, !tbaa !24
  %t512 = icmp sgt i64 %t508, %t509
  br i1 %t512, label %bb165, label %bb166
bb165:
  %t514 = load i64, ptr %l47, !tbaa !24
  %t516 = icmp sgt i64 %t514, 0
  br i1 %t516, label %bb167, label %bb168
bb166:
  store i64 0, ptr %l331, !tbaa !24
  br label %bb170
bb167:
  %t518 = load i64, ptr %l46, !tbaa !24
  %t519 = load i64, ptr %l45, !tbaa !24
  %t522 = sub i64 %t518, %t519
  %t523 = load i64, ptr %l47, !tbaa !24
  %t526 = add i64 %t522, %t523
  %t528 = sub i64 %t526, 1
  %t529 = load i64, ptr %l47, !tbaa !24
  %t532 = sdiv i64 %t528, %t529
  store i64 %t532, ptr %l334, !tbaa !24
  br label %bb169
bb168:
  store i64 0, ptr %l334, !tbaa !24
  br label %bb169
bb169:
  %t534 = load i64, ptr %l334, !tbaa !24
  store i64 %t534, ptr %l331, !tbaa !24
  br label %bb170
bb170:
  %t535 = load i64, ptr %l331, !tbaa !24
  store i64 %t535, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb171
bb171:
  %t536 = load i64, ptr %l49, !tbaa !24
  %t537 = load i64, ptr %l48, !tbaa !24
  %t540 = icmp slt i64 %t536, %t537
  %t542 = xor i1 %t540, true
  br i1 %t542, label %bb172, label %bb173
bb172:
  br label %bb180
bb173:
  br label %bb174
bb174:
  %t544 = load i64, ptr %l45, !tbaa !24
  %t545 = load i64, ptr %l49, !tbaa !24
  %t546 = load i64, ptr %l47, !tbaa !24
  %t549 = mul i64 %t545, %t546
  %t552 = add i64 %t544, %t549
  store i64 %t552, ptr %l50, !tbaa !24
  %t554 = load i64, ptr %l50, !tbaa !24
  %t557 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l43, i64 %t554)
  store i64 %t557, ptr %l354
  br label %bb175
bb175:
  %t558 = load i64, ptr %l354, !tbaa !24
  %t559 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !27
  %t561 = getelementptr i1, ptr %t560, i64 %t558
  store i1 true, ptr %t561, !tbaa !31
  %t562 = load ptr, ptr %l2, !tbaa !29
  store ptr %t562, ptr %l355, !tbaa !29
  store ptr %l3, ptr %l356, !tbaa !29
  %t563 = load i64, ptr %l50, !tbaa !24
  %t566 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l43, i64 %t563)
  store i64 %t566, ptr %l359
  br label %bb176
bb176:
  %t567 = load ptr, ptr %l356, !tbaa !29
  %t568 = load i64, ptr %l359, !tbaa !24
  %t569 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t567, i64 %t568)
  store i64 %t569, ptr %l360
  br label %bb177
bb177:
  %t570 = load ptr, ptr %l355, !tbaa !29
  %t571 = load i64, ptr %l360, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t570, i64 %t571)
  br label %bb178
bb178:
  %t572 = load i64, ptr %l27, !tbaa !24
  %t575 = add i64 %t572, 1
  store i64 %t575, ptr %l27, !tbaa !24
  br label %bb179
bb179:
  %t577 = load i64, ptr %l49, !tbaa !24
  %t580 = add i64 %t577, 1
  store i64 %t580, ptr %l49, !tbaa !24
  br label %bb171
bb180:
  br label %bb230
bb181:
  %t582 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s18, ptr %l43, i64 %t582)
  br label %bb182
bb182:
  store i64 -1, ptr %l51, !tbaa !24
  %t585 = load i64, ptr %l42, !tbaa !24
  %t588 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t585)
  store i64 %t588, ptr %l371
  br label %bb183
bb183:
  %t589 = load i64, ptr %l371, !tbaa !24
  store i64 %t589, ptr %l52, !tbaa !24
  %t590 = load i64, ptr %l42, !tbaa !24
  %t592 = add i64 %t590, 1
  %t595 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t592)
  store i64 %t595, ptr %l375
  br label %bb184
bb184:
  %t596 = load i64, ptr %l375, !tbaa !24
  store i64 %t596, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t597 = load i64, ptr %l53, !tbaa !24
  %t598 = load i64, ptr %l52, !tbaa !24
  %t601 = icmp sgt i64 %t597, %t598
  br i1 %t601, label %bb185, label %bb186
bb185:
  %t603 = load i64, ptr %l54, !tbaa !24
  %t605 = icmp sgt i64 %t603, 0
  br i1 %t605, label %bb187, label %bb188
bb186:
  store i64 0, ptr %l379, !tbaa !24
  br label %bb190
bb187:
  %t607 = load i64, ptr %l53, !tbaa !24
  %t608 = load i64, ptr %l52, !tbaa !24
  %t611 = sub i64 %t607, %t608
  %t612 = load i64, ptr %l54, !tbaa !24
  %t615 = add i64 %t611, %t612
  %t617 = sub i64 %t615, 1
  %t618 = load i64, ptr %l54, !tbaa !24
  %t621 = sdiv i64 %t617, %t618
  store i64 %t621, ptr %l382, !tbaa !24
  br label %bb189
bb188:
  store i64 0, ptr %l382, !tbaa !24
  br label %bb189
bb189:
  %t623 = load i64, ptr %l382, !tbaa !24
  store i64 %t623, ptr %l379, !tbaa !24
  br label %bb190
bb190:
  %t624 = load i64, ptr %l379, !tbaa !24
  store i64 %t624, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb191
bb191:
  %t625 = load i64, ptr %l56, !tbaa !24
  %t626 = load i64, ptr %l55, !tbaa !24
  %t629 = icmp slt i64 %t625, %t626
  %t631 = xor i1 %t629, true
  br i1 %t631, label %bb192, label %bb193
bb192:
  br label %bb208
bb193:
  br label %bb194
bb194:
  %t633 = load i64, ptr %l52, !tbaa !24
  %t634 = load i64, ptr %l56, !tbaa !24
  %t635 = load i64, ptr %l54, !tbaa !24
  %t638 = mul i64 %t634, %t635
  %t641 = add i64 %t633, %t638
  store i64 %t641, ptr %l57, !tbaa !24
  %t643 = load i64, ptr %l51, !tbaa !24
  %t645 = icmp slt i64 %t643, 0
  br i1 %t645, label %bb195, label %bb196
bb195:
  %t647 = load i64, ptr %l57, !tbaa !24
  %t650 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t647)
  store i64 %t650, ptr %l405
  br label %bb197
bb196:
  store i1 false, ptr %l402, !tbaa !21
  br label %bb198
bb197:
  %t651 = load i64, ptr %l405, !tbaa !24
  %t652 = icmp sge i64 %t651, 0
  store i1 %t652, ptr %l402, !tbaa !21
  br label %bb198
bb198:
  %t654 = load i1, ptr %l402, !tbaa !21
  br i1 %t654, label %bb199, label %bb200
bb199:
  %t655 = load i64, ptr %l57, !tbaa !24
  %t658 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t655)
  store i64 %t658, ptr %l410
  br label %bb201
bb200:
  store i1 false, ptr %l407, !tbaa !21
  br label %bb202
bb201:
  %t659 = load i64, ptr %l410, !tbaa !24
  %t660 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !27
  %t662 = getelementptr i1, ptr %t661, i64 %t659
  %t663 = load i1, ptr %t662, !tbaa !31
  %t665 = xor i1 %t663, true
  store i1 %t665, ptr %l407, !tbaa !21
  br label %bb202
bb202:
  %t667 = load i1, ptr %l407, !tbaa !21
  br i1 %t667, label %bb203, label %bb204
bb203:
  %t668 = load i64, ptr %l57, !tbaa !24
  %t671 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t668)
  store i64 %t671, ptr %l415
  br label %bb205
bb204:
  br label %bb206
bb205:
  %t672 = load i64, ptr %l415, !tbaa !24
  store i64 %t672, ptr %l51, !tbaa !24
  br label %bb206
bb206:
  br label %bb207
bb207:
  %t673 = load i64, ptr %l56, !tbaa !24
  %t676 = add i64 %t673, 1
  store i64 %t676, ptr %l56, !tbaa !24
  br label %bb191
bb208:
  %t678 = load i64, ptr %l51, !tbaa !24
  %t680 = icmp slt i64 %t678, 0
  br i1 %t680, label %bb209, label %bb210
bb209:
  store i64 0, ptr %l58, !tbaa !24
  %t682 = load i64, ptr %l17, !tbaa !24
  store i64 %t682, ptr %l59, !tbaa !24
  store i64 1, ptr %l60, !tbaa !24
  %t684 = load i64, ptr %l59, !tbaa !24
  %t685 = load i64, ptr %l58, !tbaa !24
  %t688 = icmp sgt i64 %t684, %t685
  br i1 %t688, label %bb211, label %bb212
bb210:
  br label %bb228
bb211:
  %t690 = load i64, ptr %l60, !tbaa !24
  %t692 = icmp sgt i64 %t690, 0
  br i1 %t692, label %bb213, label %bb214
bb212:
  store i64 0, ptr %l425, !tbaa !24
  br label %bb216
bb213:
  %t694 = load i64, ptr %l59, !tbaa !24
  %t695 = load i64, ptr %l58, !tbaa !24
  %t698 = sub i64 %t694, %t695
  %t699 = load i64, ptr %l60, !tbaa !24
  %t702 = add i64 %t698, %t699
  %t704 = sub i64 %t702, 1
  %t705 = load i64, ptr %l60, !tbaa !24
  %t708 = sdiv i64 %t704, %t705
  store i64 %t708, ptr %l428, !tbaa !24
  br label %bb215
bb214:
  store i64 0, ptr %l428, !tbaa !24
  br label %bb215
bb215:
  %t710 = load i64, ptr %l428, !tbaa !24
  store i64 %t710, ptr %l425, !tbaa !24
  br label %bb216
bb216:
  %t711 = load i64, ptr %l425, !tbaa !24
  store i64 %t711, ptr %l61, !tbaa !24
  store i64 0, ptr %l62, !tbaa !24
  br label %bb217
bb217:
  %t712 = load i64, ptr %l62, !tbaa !24
  %t713 = load i64, ptr %l61, !tbaa !24
  %t716 = icmp slt i64 %t712, %t713
  %t718 = xor i1 %t716, true
  br i1 %t718, label %bb218, label %bb219
bb218:
  br label %bb227
bb219:
  br label %bb220
bb220:
  %t720 = load i64, ptr %l58, !tbaa !24
  %t721 = load i64, ptr %l62, !tbaa !24
  %t722 = load i64, ptr %l60, !tbaa !24
  %t725 = mul i64 %t721, %t722
  %t728 = add i64 %t720, %t725
  store i64 %t728, ptr %l63, !tbaa !24
  %t730 = load i64, ptr %l63, !tbaa !24
  %t732 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t733 = load ptr, ptr %t732, !tbaa !27
  %t734 = getelementptr i1, ptr %t733, i64 %t730
  %t735 = load i1, ptr %t734, !tbaa !31
  br i1 %t735, label %bb221, label %bb222
bb221:
  br label %bb226
bb222:
  br label %bb223
bb223:
  %t737 = load i64, ptr %l63, !tbaa !24
  %t739 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !27
  %t741 = getelementptr i1, ptr %t740, i64 %t737
  store i1 true, ptr %t741, !tbaa !31
  %t742 = load ptr, ptr %l2, !tbaa !29
  store ptr %t742, ptr %l449, !tbaa !29
  %t743 = load i64, ptr %l63, !tbaa !24
  %t746 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t743)
  store i64 %t746, ptr %l452
  br label %bb224
bb224:
  %t747 = load ptr, ptr %l449, !tbaa !29
  %t748 = load i64, ptr %l452, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t747, i64 %t748)
  br label %bb225
bb225:
  %t749 = load i64, ptr %l27, !tbaa !24
  %t752 = add i64 %t749, 1
  store i64 %t752, ptr %l27, !tbaa !24
  br label %bb226
bb226:
  %t754 = load i64, ptr %l62, !tbaa !24
  %t757 = add i64 %t754, 1
  store i64 %t757, ptr %l62, !tbaa !24
  br label %bb217
bb227:
  br label %bb230
bb228:
  %t759 = load i64, ptr %l51, !tbaa !24
  store i64 %t759, ptr %l42, !tbaa !24
  br label %bb229
bb229:
  br label %bb156
bb230:
  call void @__olang_scope_close(ptr %s18)
  br label %bb231
bb231:
  br label %bb100
bb232:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainScalar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = load i32, ptr %l8, !tbaa !23
  %t15 = icmp eq i32 %t13, %t12
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l14
  br label %bb9
bb9:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb12
bb11:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i32, ptr %l23, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t43, ptr %l24
  br label %bb13
bb13:
  %t44 = load i1, ptr %l24, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l15, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l15, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epuns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l38 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i1
  %l59 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb31
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l22, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t25 = load ptr, ptr %l6, !tbaa !29
  store ptr %t25, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t26 = load ptr, ptr %l25, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l25, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 22}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l26, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l26, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  br label %bb30
bb9:
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr }, ptr %t38, i32 0, i32 0
  %t40 = load %"compiler/source:Span", ptr %t39
  store %"compiler/source:Span" %t40, ptr %l7
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", ptr }, ptr %t44, i32 0, i32 1
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l9, !tbaa !29
  %t50 = load ptr, ptr %l9, !tbaa !29
  %t52 = getelementptr %"compiler/ast:VarDecl", ptr %t50, i32 0, i32 5
  %t53 = load i1, ptr %t52, !tbaa !21
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb13
bb12:
  %t57 = load ptr, ptr %l9, !tbaa !29
  %t59 = getelementptr %"compiler/ast:VarDecl", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t66 = load i1, ptr %l38, !tbaa !21
  br i1 %t66, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t67 = load ptr, ptr %l9, !tbaa !29
  %t69 = getelementptr %"compiler/ast:VarDecl", ptr %t67, i32 0, i32 3
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t74 = icmp sgt i64 %t72, 0
  store i1 %t74, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb18:
  %t77 = load ptr, ptr %l9, !tbaa !29
  %t79 = getelementptr %"compiler/ast:VarDecl", ptr %t77, i32 0, i32 4
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t82 = load i1, ptr %l48, !tbaa !21
  br i1 %t82, label %bb20, label %bb21
bb20:
  br label %bb30
bb21:
  br label %bb22
bb22:
  %t83 = load ptr, ptr %l9, !tbaa !29
  %t85 = getelementptr %"compiler/ast:VarDecl", ptr %t83, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  store i64 %t90, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l12, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t100 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t100, ptr %l59, !tbaa !27
  %t101 = load i64, ptr %l11, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i32, ptr %t104, i64 %t101
  %t106 = load i32, ptr %t105, !tbaa !33
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v2, ptr %l2, i32 %t106, i1 true)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = add i64 %t111, 1
  store i64 %t114, ptr %l11, !tbaa !24
  br label %bb23
bb29:
  br label %bb30
bb30:
  %t116 = load i64, ptr %l4, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l4, !tbaa !24
  br label %bb2
bb31:
  %t121 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t121, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l28 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i32
  %l41 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i32
  %l57 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l66 = alloca ptr
  %l73 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l85 = alloca i64
  %l88 = alloca ptr
  %l93 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i1
  %l104 = alloca ptr
  %l109 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l124 = alloca i32
  %l126 = alloca ptr
  %s2 = alloca %olang.scope
  %t122 = alloca { i64, [1 x i64] }, align 8
  %t140 = alloca { i64, [3 x i64] }, align 8
  %t236 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t4, ptr %l6
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t8 = load ptr, ptr %l15, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb45
bb4:
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 28}
  %t14 = icmp eq i64 %t12, 0
  store i1 %t14, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l16, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l7
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l8, !tbaa !23
  br label %bb8
bb7:
  br label %bb37
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l8, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l25
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t34, ptr %l26
  br label %bb10
bb10:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l28
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l28, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 43
  %t42 = load i32, ptr %l8, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l32
  br label %bb15
bb15:
  %t46 = load i1, ptr %l32, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunRows(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l36
  br label %bb18
bb17:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i32, ptr %l4, !tbaa !23
  %t53 = load i32, ptr %l36, !tbaa !23
  %t55 = icmp ne i32 %t53, %t52
  store i1 %t55, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunRows(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l41
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %l4, !tbaa !23
  br label %bb23
bb23:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l44, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l47
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t76 = load i32, ptr %l47, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l48
  br label %bb25
bb25:
  %t78 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t80 = trunc i64 19 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = load i32, ptr %l4, !tbaa !23
  store i32 %t89, ptr %l55, !tbaa !23
  %t90 = load ptr, ptr %l3, !tbaa !29
  store ptr %t90, ptr %l57, !tbaa !29
  %t92 = load ptr, ptr %l57, !tbaa !29
  %t93 = call ptr @__olang_scope_of(ptr %t92, ptr null)
  %t94 = call ptr @__olang_scope_hold(ptr %t93)
  %t95 = ptrtoint ptr %t94 to i64
  %t97 = inttoptr i64 %t95 to ptr
  %t98 = load ptr, ptr %l57, !tbaa !29
  %t99 = call i32 @compiler_2fcheck_2etypeOf(ptr %t97, ptr %t98)
  store i32 %t99, ptr %l59
  br label %bb28
bb27:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb30
bb28:
  %t100 = load ptr, ptr %l54, !tbaa !29
  %t101 = load i32, ptr %l55, !tbaa !23
  %t102 = load i32, ptr %l59, !tbaa !23
  %t103 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t100, i32 %t101, i32 %t102)
  store i1 %t103, ptr %l60
  br label %bb29
bb29:
  %t104 = load i1, ptr %l60, !tbaa !21
  %t105 = xor i1 %t104, true
  store i1 %t105, ptr %l51, !tbaa !21
  br label %bb30
bb30:
  %t107 = load i1, ptr %l51, !tbaa !21
  br i1 %t107, label %bb31, label %bb32
bb31:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t110 = load i32, ptr %l4, !tbaa !23
  %t111 = load %"compiler/source:Span", ptr %l7
  %t116 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t108, ptr %t109, i32 %t110, %"compiler/source:Span" %t111)
  store ptr %t116, ptr %l66
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t117 = load ptr, ptr %l66, !tbaa !29
  store ptr %t117, ptr %l3, !tbaa !29
  br label %bb34
bb34:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l8, !tbaa !23
  %t120 = load %"compiler/source:Span", ptr %l7
  %t121 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t122
  %t123 = getelementptr { i64, [1 x i64] }, ptr %t122, i32 0, i32 0
  store i64 4, ptr %t123
  %t124 = load { i64, [1 x i64] }, ptr %t122
  %t131 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t118, i32 %t119, %"compiler/source:Span" %t120, i32 %t121, i32 1, { i64, [1 x i64] } %t124)
  store i64 %t131, ptr %l73
  br label %bb35
bb35:
  %t132 = load i64, ptr %l73, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l7
  %t137 = trunc i64 %t132 to i32
  %t139 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [3 x i64] }, ptr %t140, i32 0, i32 0
  store i64 0, ptr %t141
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t134, 0
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr } %t143, i32 %t137, 1
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } %t145, ptr %t139, 2
  %t148 = getelementptr { i64, [3 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t147, ptr %t148
  %t149 = load { i64, [3 x i64] }, ptr %t140
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t149, ptr %t151
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t133, ptr %t151)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l82, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t155, ptr %l83
  %t156 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
  store %"compiler/diagmsg:Msg" %t156, ptr %l84
  br label %bb41
bb41:
  %t157 = load ptr, ptr %l82, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l83
  %t159 = load %"compiler/diagmsg:Msg", ptr %l84
  %t160 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t157, %"compiler/source:Span" %t158, %"compiler/diagmsg:Msg" %t159)
  store i64 %t160, ptr %l85
  br label %bb42
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_fb06dcd16342dc9_94e70e479081575d)
  unreachable
bb44:
  br label %ret
bb45:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v0, ptr %t161, ptr %t162)
  store ptr %t165, ptr %l88
  br label %bb46
bb46:
  %t166 = load ptr, ptr %l88, !tbaa !29
  store ptr %t166, ptr %l10, !tbaa !29
  %t167 = load ptr, ptr %l10, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  br i1 %t169, label %bb47, label %bb48
bb47:
  br label %ret
bb48:
  br label %bb49
bb49:
  %t173 = xor i1 %a5, true
  br i1 %t173, label %bb50, label %bb51
bb50:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l94, !tbaa !29
  %t176 = load ptr, ptr %l10, !tbaa !29
  %t178 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t176)
  store i32 %t178, ptr %l96
  br label %bb52
bb51:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb54
bb52:
  %t179 = load ptr, ptr %l94, !tbaa !29
  %t180 = load i32, ptr %l96, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t179, i32 %t180)
  store i1 %t181, ptr %l97
  br label %bb53
bb53:
  %t182 = load i1, ptr %l97, !tbaa !21
  store i1 %t182, ptr %l93, !tbaa !21
  br label %bb54
bb54:
  %t183 = load i1, ptr %l93, !tbaa !21
  br i1 %t183, label %bb55, label %bb56
bb55:
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l99, !tbaa !29
  %t185 = load ptr, ptr %l10, !tbaa !29
  %t187 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t185)
  store i32 %t187, ptr %l101
  br label %bb57
bb56:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb59
bb57:
  %t188 = load ptr, ptr %l99, !tbaa !29
  %t189 = load i32, ptr %l101, !tbaa !23
  %t190 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargRef(ptr %v0, ptr %t188, i32 %t189)
  store i1 %t190, ptr %l102
  br label %bb58
bb58:
  %t191 = load i1, ptr %l102, !tbaa !21
  %t192 = xor i1 %t191, true
  store i1 %t192, ptr %l98, !tbaa !21
  br label %bb59
bb59:
  %t194 = load i1, ptr %l98, !tbaa !21
  br i1 %t194, label %bb60, label %bb61
bb60:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l6
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t198 = load ptr, ptr %l10, !tbaa !29
  %t203 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethrough(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t195, %"compiler/source:Span" %t196, ptr %t197, ptr %t198)
  store ptr %t203, ptr %l109
  br label %bb62
bb61:
  %t204 = load ptr, ptr %l10, !tbaa !29
  store ptr %t204, ptr %l104, !tbaa !29
  br label %bb63
bb62:
  %t206 = load ptr, ptr %l109, !tbaa !29
  store ptr %t206, ptr %l104, !tbaa !29
  br label %bb63
bb63:
  %t207 = load ptr, ptr %l104, !tbaa !29
  store ptr %t207, ptr %l11, !tbaa !29
  %t208 = load ptr, ptr %l11, !tbaa !29
  %t209 = load ptr, ptr %l10, !tbaa !29
  %t212 = icmp eq ptr %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb64, label %bb65
bb64:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l11, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t216, ptr %t217, %"compiler/source:Span" %t218)
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb67
bb67:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l118, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t223, ptr %l119
  %t224 = load ptr, ptr %l11, !tbaa !29
  store ptr %t224, ptr %l120, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l121, !tbaa !29
  %t226 = load ptr, ptr %l3, !tbaa !29
  store ptr %t226, ptr %l122, !tbaa !29
  %t227 = load ptr, ptr %l11, !tbaa !29
  %t229 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t227)
  store i32 %t229, ptr %l124
  br label %bb68
bb68:
  %t230 = load %"compiler/source:Span", ptr %l6
  %t231 = load ptr, ptr %l121, !tbaa !29
  %t232 = load ptr, ptr %l122, !tbaa !29
  %t233 = load i32, ptr %l124, !tbaa !23
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t231, ptr %t232, i32 %t233, %"compiler/source:Span" %t230)
  store ptr %t235, ptr %l126
  br label %bb69
bb69:
  store { i64, [3 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t236, i32 0, i32 0
  store i64 1, ptr %t237
  %t238 = load %"compiler/source:Span", ptr %l119
  %t239 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t238, 0
  %t240 = load ptr, ptr %l120, !tbaa !29
  %t241 = insertvalue { %"compiler/source:Span", ptr, ptr } %t239, ptr %t240, 1
  %t242 = load ptr, ptr %l126, !tbaa !29
  %t243 = insertvalue { %"compiler/source:Span", ptr, ptr } %t241, ptr %t242, 2
  %t244 = getelementptr { i64, [3 x i64] }, ptr %t236, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t243, ptr %t244
  %t245 = load { i64, [3 x i64] }, ptr %t236
  %t247 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t245, ptr %t247
  %t248 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t248, ptr %t247)
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erangeDecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/check:rangeIndex"
  %l11 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i1
  %l19 = alloca i1
  %l21 = alloca { i64, ptr }
  %l23 = alloca i32
  %l27 = alloca i1
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/check:rangeIndex"
  %l39 = alloca %"compiler/check:rangeIndex"
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca %"compiler/check:rangeIndex"
  %l54 = alloca %"compiler/check:rangeIndex"
  %l56 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l65 = alloca %"compiler/diagmsg:Msg"
  %l66 = alloca i64
  %l70 = alloca ptr
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t44 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 44
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2eLen_H423801dd0d60e2c88405a5484a32cfa6(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = call ptr @__olang_scope_hold(ptr %v0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l13, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e44
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = call ptr @__olang_region_make(ptr %v0)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t15 = load i64, ptr %l13
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2ector(ptr %t16, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l15
  br label %bb7
bb7:
  %t18 = load i64, ptr %l13
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_scope_alloc_a(ptr %t19, i64 32, i64 8)
  store ptr %t20, ptr %lp4
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t22 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %t22
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call i1 @compiler_2ftyped_2eCutsShort(ptr %v1, ptr %t23)
  store i1 %t25, ptr %l17
  br label %bb8
bb8:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/ast:ForIn", ptr %t29, i32 0, i32 4
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l21, !tbaa !27
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/ast:ForIn", ptr %t33, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  store i32 %t36, ptr %l23, !tbaa !23
  %t37 = icmp sge i64 1, 0
  br i1 %t37, label %bb11, label %bb12
bb10:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb16
bb11:
  %t39 = icmp sle i64 1, 2305843009213693951
  br i1 %t39, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_b9e76f30cfc88eb5_4fabd464cb64d2f9)
  unreachable
bb13:
  %t41 = mul i64 1, 4
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  %t43 = load i32, ptr %l23, !tbaa !23
  store i64 0, ptr %t44
  br label %fill.45
fill.45:
  %t48 = load i64, ptr %t44
  %t49 = icmp slt i64 %t48, 1
  br i1 %t49, label %fillb.46, label %filld.47
fillb.46:
  %t50 = getelementptr i32, ptr %t42, i64 %t48
  store i32 %t43, ptr %t50
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %t44
  br label %fill.45
filld.47:
  %t52 = insertvalue { i64, ptr } undef, i64 1, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t42, 1
  %t54 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t56 = call i1 @compiler_2fcheck_2eassignsName(ptr %v2, ptr %s0, { i64, ptr } %t54, { i64, ptr } %t53)
  store i1 %t56, ptr %l27
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b9e76f30cfc88eb5_4fabd464cb64d2f9)
  unreachable
bb15:
  %t57 = load i1, ptr %l27, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %l5, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 44
  store ptr %t63, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load i64, ptr %l7, !tbaa !24
  store i64 %t65, ptr %l31, !tbaa !24
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2eLen_H423801dd0d60e2c88405a5484a32cfa6(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l33
  br label %bb18
bb18:
  %t69 = load i64, ptr %l31, !tbaa !24
  %t70 = load i64, ptr %l33, !tbaa !24
  %t71 = icmp slt i64 %t69, %t70
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb20:
  br label %bb21
bb21:
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = call %"compiler/check:rangeIndex" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2eAt__Hb3807dfbbe58365e936467ca31dc9d49(ptr %v0, ptr %v0, ptr %t75, i64 %t76)
  store %"compiler/check:rangeIndex" %t79, ptr %l38
  br label %bb22
bb22:
  %t80 = load %"compiler/check:rangeIndex", ptr %l38
  store %"compiler/check:rangeIndex" %t80, ptr %l39
  %t81 = call ptr @__olang_scope_hold(ptr %s3)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l40, !tbaa !24
  %t83 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3arangeIndex_2e3
  br i1 %t83, label %bb23, label %bb24
bb23:
  %t85 = call ptr @__olang_region_make_part(ptr %s3)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l40, !tbaa !24
  br label %bb24
bb24:
  %t87 = getelementptr %"compiler/check:rangeIndex", ptr %l39, i32 0, i32 3
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l42, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l43, !tbaa !24
  %t91 = load i64, ptr %l43, !tbaa !24
  %t92 = mul i64 %t91, 1
  %t93 = load i64, ptr %l40
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = call ptr @__olang_held_alloc(ptr %t94, i64 %t92)
  %t96 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l44, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l43, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t105 = getelementptr %"compiler/check:rangeIndex", ptr %l39, i32 0, i32 3
  store { i64, ptr } %t104, ptr %t105, !tbaa !27
  %t106 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3arangeIndex_2e3
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t108 = getelementptr %"compiler/check:rangeIndex", ptr %l39, i32 0, i32 3
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb27, label %bb28
bb26:
  %t114 = load %"compiler/check:rangeIndex", ptr %l39
  store %"compiler/check:rangeIndex" %t114, ptr %l8
  %t115 = getelementptr %"compiler/check:rangeIndex", ptr %l8, i32 0, i32 0
  %t116 = load i64, ptr %t115, !tbaa !24
  %t120 = icmp ne i64 %t116, %a1
  br i1 %t120, label %bb29, label %bb30
bb27:
  %t122 = getelementptr %"compiler/check:rangeIndex", ptr %l39, i32 0, i32 3
  store { i64, ptr } zeroinitializer, ptr %t122, !tbaa !27
  br label %bb28
bb28:
  %t123 = getelementptr %"compiler/check:rangeIndex", ptr %l39, i32 0, i32 3
  %t124 = load i64, ptr %l40
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = load { i64, ptr }, ptr %t123
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = call ptr @__olang_region_or(ptr %t127, ptr null)
  %t129 = icmp ne ptr %t128, null
  %t130 = select i1 %t129, ptr %t128, ptr null
  call void @__olang_region_settle_in(ptr %t125, ptr %t130)
  br label %bb26
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t131 = load ptr, ptr %lp4
  store ptr %t131, ptr %l51, !tbaa !29
  %t132 = load %"compiler/check:rangeIndex", ptr %l8
  store %"compiler/check:rangeIndex" %t132, ptr %l52
  %t134 = call %"compiler/check:rangeIndex" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3arangeIndex(ptr %s4, ptr %l52)
  store %"compiler/check:rangeIndex" %t134, ptr %l54
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t135 = load i64, ptr %l13
  %t136 = inttoptr i64 %t135 to ptr
  %t137 = load ptr, ptr %l51, !tbaa !29
  %t138 = load %"compiler/check:rangeIndex", ptr %l54
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2ePus_Hb04e4a892496cc754693e16cdaa43e26(ptr %t136, ptr %s4, ptr %t137, %"compiler/check:rangeIndex" %t138)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb33:
  %t139 = load i1, ptr %l5, !tbaa !21
  br i1 %t139, label %bb34, label %bb35
bb34:
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t142 = getelementptr %"compiler/check:rangeIndex", ptr %l8, i32 0, i32 1
  %t143 = load %"compiler/source:Span", ptr %t142
  %t146 = call i1 @compiler_2ftyped_2eEveryTurn(ptr %v1, ptr %t141, %"compiler/source:Span" %t143)
  store i1 %t146, ptr %l59
  br label %bb36
bb35:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb37
bb36:
  %t147 = load i1, ptr %l59, !tbaa !21
  store i1 %t147, ptr %l56, !tbaa !21
  br label %bb37
bb37:
  %t148 = load i1, ptr %l56, !tbaa !21
  br i1 %t148, label %bb38, label %bb39
bb38:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l60, !tbaa !29
  %t150 = getelementptr %"compiler/check:rangeIndex", ptr %l8, i32 0, i32 2
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l61
  %t152 = getelementptr %"compiler/check:rangeIndex", ptr %l8, i32 0, i32 3
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t154 = getelementptr %"compiler/check:rangeIndex", ptr %l8, i32 0, i32 4
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = getelementptr %"compiler/check:rangeIndex", ptr %l8, i32 0, i32 5
  %t157 = load i64, ptr %t156, !tbaa !24
  %t161 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIndexReaches(ptr %s3, ptr %v0, { i64, ptr } %t153, i64 %t155, i64 %t157)
  store %"compiler/diagmsg:Msg" %t161, ptr %l65
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t162 = load ptr, ptr %l60, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l61
  %t164 = load %"compiler/diagmsg:Msg", ptr %l65
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t162, %"compiler/source:Span" %t163, %"compiler/diagmsg:Msg" %t164)
  store i64 %t165, ptr %l66
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t166 = load i64, ptr %l7, !tbaa !24
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %l7, !tbaa !24
  br label %bb17
bb44:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l70, !tbaa !29
  %t172 = load ptr, ptr %lp4
  %t173 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t172
  %t174 = load ptr, ptr %l70, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 44
  %t176 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t175
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %l72
  %t178 = load ptr, ptr %l70, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %t179
  %t180 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e44
  br i1 %t180, label %bb45, label %bb46
bb45:
  %t182 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72, i32 0, i32 0
  %t183 = load { i64, ptr }, ptr %t182
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = call ptr @__olang_region_or(ptr %t184, ptr null)
  %t186 = call ptr @__olang_region_home(ptr %t185)
  %t187 = icmp ne ptr %t186, null
  %t188 = select i1 %t187, ptr %t186, ptr null
  call void @__olang_region_drop(ptr %t188)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l72
  br label %bb46
bb46:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb47
bb47:
  %t189 = load i64, ptr %l74, !tbaa !24
  %t190 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72, i32 0, i32 1
  %t191 = load i64, ptr %t190, !tbaa !24
  %t192 = icmp slt i64 %t189, %t191
  br i1 %t192, label %bb48, label %bb49
bb48:
  %t194 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3arangeIndex_2e3
  br i1 %t194, label %bb50, label %bb51
bb49:
  %t196 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2e0
  br i1 %t196, label %bb52, label %bb53
bb50:
  %t198 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72, i32 0, i32 0
  %t199 = load i64, ptr %l74, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr %"compiler/check:rangeIndex", ptr %t201, i64 %t199
  %t203 = getelementptr %"compiler/check:rangeIndex", ptr %t202, i32 0, i32 3
  %t204 = load { i64, ptr }, ptr %t203
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t206 = extractvalue { i64, ptr } %t204, 1
  call void @__olang_region_release_part(ptr %t206, i64 %t205)
  store { i64, ptr } zeroinitializer, ptr %t203
  br label %bb51
bb51:
  %t207 = load i64, ptr %l74, !tbaa !24
  %t208 = add i64 %t207, 1
  store i64 %t208, ptr %l74, !tbaa !24
  br label %bb47
bb52:
  %t209 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72, i32 0, i32 0
  %t210 = load { i64, ptr }, ptr %t209
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  call void @__olang_region_release_part(ptr %t212, i64 %t211)
  store { i64, ptr } zeroinitializer, ptr %t209
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefRows(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l17 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca ptr
  %l34 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l59 = alloca i64
  %l60 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t12, i32 %a2)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb3
bb3:
  %t28 = load i32, ptr %l17, !range !{i32 0, i32 33}
  %t30 = trunc i64 19 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb7
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l4, !tbaa !23
  %t37 = load i32, ptr %l3, !tbaa !23
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsInPlace(ptr %v0, ptr %t35, i32 %t36, i32 %t37)
  store i1 %t41, ptr %l25
  br label %bb6
bb6:
  %t42 = load i1, ptr %l25, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t46 = load i32, ptr %l1, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  store ptr %t51, ptr %l29, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l4, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l34
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l39
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l29, !tbaa !29
  %t73 = load i32, ptr %l34, !tbaa !23
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t72, i32 %t73, i32 %t74)
  store i1 %t75, ptr %l40
  br label %bb13
bb13:
  %t76 = load i1, ptr %l40, !tbaa !21
  %t77 = xor i1 %t76, true
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t79 = load i32, ptr %l1, !tbaa !23
  store i32 %t79, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  store ptr %t86, ptr %l45, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  store ptr %t92, ptr %l48, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l4, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l53
  br label %bb17
bb17:
  %t103 = load ptr, ptr %l48, !tbaa !29
  %t104 = load i32, ptr %l53, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t103, i32 %t104, i32 0)
  store i32 %t105, ptr %l54
  br label %bb18
bb18:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l1, !tbaa !23
  %t115 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t111, i32 %t112)
  store i64 %t115, ptr %l59
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l45, !tbaa !29
  %t117 = load i32, ptr %l54, !tbaa !23
  %t118 = load i64, ptr %l59, !tbaa !24
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t116, i32 %t117, i64 %t118)
  store i32 %t119, ptr %l60
  br label %bb20
bb20:
  %t120 = load i32, ptr %l60, !tbaa !23
  store i32 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %l12 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca %"compiler/typed:Local"
  %l55 = alloca i1
  %l57 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca ptr
  %l63 = alloca %"compiler/typed:Local"
  %l68 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca i1
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l96 = alloca ptr
  %l100 = alloca ptr
  %l103 = alloca i64
  %l105 = alloca i64
  %l110 = alloca i32
  %l111 = alloca ptr
  %l113 = alloca ptr
  %l115 = alloca %"compiler/typed:Local"
  %l125 = alloca { i64, ptr }
  %l126 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 48
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 13
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l20, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l23, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t27)
  store ptr %t29, ptr %l25
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t30 = load ptr, ptr %l25, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t34, i32 %t33)
  store i32 %t36, ptr %l28
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load i32, ptr %l28, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t43 = icmp eq i64 %t41, 0
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l17, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epuns(ptr %v0, ptr %v1, ptr %s0, ptr %t46, { i64, ptr } %t47)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t50, ptr %l35
  br label %bb11
bb10:
  %t51 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t51, ptr %l36
  br label %bb12
bb11:
  %t52 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t52, ptr %l32
  br label %bb13
bb12:
  %t53 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t53, ptr %l32
  br label %bb13
bb13:
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %l3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t55)
  store ptr %t57, ptr %l38
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 5
  store ptr %t60, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %l41, !tbaa !24
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l43
  br label %bb16
bb16:
  %t66 = load i64, ptr %l41, !tbaa !24
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = icmp slt i64 %t66, %t67
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb31
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t72, i64 %t73)
  store i32 %t76, ptr %l48
  br label %bb20
bb20:
  %t77 = load i32, ptr %l48, !tbaa !23
  store i32 %t77, ptr %l6, !tbaa !23
  store ptr %l3, ptr %l49, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t78)
  store ptr %t80, ptr %l51
  br label %bb21
bb21:
  %t81 = load i32, ptr %l6, !tbaa !23
  %t82 = load ptr, ptr %l51, !tbaa !29
  %t84 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t82, i32 %t81)
  store %"compiler/typed:Local" %t84, ptr %l53
  br label %bb22
bb22:
  %t85 = getelementptr %"compiler/typed:Local", ptr %l53, i32 0, i32 0
  %t86 = load i32, ptr %t85, !tbaa !23
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t89 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %s0, ptr %t87, i32 %t86)
  store i1 %t89, ptr %l55
  br label %bb23
bb23:
  %t90 = load i1, ptr %l55, !tbaa !21
  %t91 = xor i1 %t90, true
  br i1 %t91, label %bb24, label %bb25
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l57, !tbaa !29
  %t94 = load i32, ptr %l6, !tbaa !23
  %t96 = sext i32 %t94 to i64
  store i64 %t96, ptr %l59, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l61
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t100 = load i32, ptr %l6, !tbaa !23
  %t101 = load ptr, ptr %l61, !tbaa !29
  %t103 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t101, i32 %t100)
  store %"compiler/typed:Local" %t103, ptr %l63
  br label %bb27
bb27:
  %t104 = getelementptr %"compiler/typed:Local", ptr %l63, i32 0, i32 1
  %t105 = load %"compiler/source:Span", ptr %t104
  %t106 = load ptr, ptr %l57, !tbaa !29
  %t107 = load i64, ptr %l59, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %t106, i64 %t107, %"compiler/source:Span" %t105, i1 true)
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb15
bb31:
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t114, ptr %l68, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t115)
  store ptr %t117, ptr %l70
  br label %bb32
bb32:
  %t118 = load ptr, ptr %l70, !tbaa !29
  %t120 = getelementptr %"compiler/check:frame", ptr %t118, i32 0, i32 43
  %t121 = load { i64, ptr }, ptr %l68, !tbaa !27
  call void @compiler_2fcheck_2estoredIn(ptr %v1, ptr %v0, { i64, ptr } %t121, ptr %t120)
  br label %bb33
bb33:
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb34, label %bb35
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t129, { i64, ptr } %t130)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t133)
  store ptr %t135, ptr %l79
  br label %bb38
bb38:
  %t136 = load ptr, ptr %l79, !tbaa !29
  %t138 = getelementptr %"compiler/check:frame", ptr %t136, i32 0, i32 13
  %t139 = load i1, ptr %t138, !tbaa !21
  br i1 %t139, label %bb39, label %bb40
bb39:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l84, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t145)
  store ptr %t147, ptr %l86
  br label %bb41
bb40:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb43
bb41:
  %t148 = load ptr, ptr %l86, !tbaa !29
  %t150 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 14
  %t151 = load i32, ptr %t150, !tbaa !23
  %t152 = load ptr, ptr %l84, !tbaa !29
  %t154 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t152, i32 %t151)
  store i1 %t154, ptr %l89
  br label %bb42
bb42:
  %t155 = load i1, ptr %l89, !tbaa !21
  store i1 %t155, ptr %l82, !tbaa !21
  br label %bb43
bb43:
  %t156 = load i1, ptr %l82, !tbaa !21
  br i1 %t156, label %bb44, label %bb45
bb44:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l90, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t158)
  store ptr %t160, ptr %l92
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t161 = load ptr, ptr %l92, !tbaa !29
  %t163 = getelementptr %"compiler/check:frame", ptr %t161, i32 0, i32 14
  %t164 = load i32, ptr %t163, !tbaa !23
  %t165 = load ptr, ptr %l90, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %t165, i32 %t164)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t167)
  store ptr %t169, ptr %l96
  br label %bb49
bb49:
  %t170 = load ptr, ptr %l96, !tbaa !29
  %t172 = getelementptr %"compiler/check:frame", ptr %t170, i32 0, i32 13
  %t173 = load i1, ptr %t172, !tbaa !21
  br i1 %t173, label %bb50, label %bb51
bb50:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t175)
  store ptr %t177, ptr %l100
  br label %bb52
bb51:
  br label %bb64
bb52:
  %t178 = load ptr, ptr %l100, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Body", ptr %t178, i32 0, i32 10
  store ptr %t180, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb53
bb53:
  %t182 = load i64, ptr %l8, !tbaa !24
  store i64 %t182, ptr %l103, !tbaa !24
  %t183 = load ptr, ptr %l7, !tbaa !29
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t183)
  store i64 %t185, ptr %l105
  br label %bb54
bb54:
  %t186 = load i64, ptr %l103, !tbaa !24
  %t187 = load i64, ptr %l105, !tbaa !24
  %t188 = icmp slt i64 %t186, %t187
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb55, label %bb56
bb55:
  br label %bb63
bb56:
  br label %bb57
bb57:
  %t192 = load ptr, ptr %l7, !tbaa !29
  %t193 = load i64, ptr %l8, !tbaa !24
  %t196 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t192, i64 %t193)
  store i32 %t196, ptr %l110
  br label %bb58
bb58:
  %t197 = load i32, ptr %l110, !tbaa !23
  store i32 %t197, ptr %l9, !tbaa !23
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l111, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t199)
  store ptr %t201, ptr %l113
  br label %bb59
bb59:
  %t202 = load i32, ptr %l9, !tbaa !23
  %t203 = load ptr, ptr %l113, !tbaa !29
  %t205 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t203, i32 %t202)
  store %"compiler/typed:Local" %t205, ptr %l115
  br label %bb60
bb60:
  %t206 = getelementptr %"compiler/typed:Local", ptr %l115, i32 0, i32 1
  %t207 = load %"compiler/source:Span", ptr %t206
  %t208 = load i32, ptr %l9, !tbaa !23
  %t210 = sext i32 %t208 to i64
  %t211 = load ptr, ptr %l111, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropsGone(ptr %v0, ptr %t211, %"compiler/source:Span" %t207, i64 %t210)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t214 = load i64, ptr %l8, !tbaa !24
  %t217 = add i64 %t214, 1
  store i64 %t217, ptr %l8, !tbaa !24
  br label %bb53
bb63:
  br label %bb64
bb64:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 48
  %t222 = load i64, ptr %l2, !tbaa !24
  %t225 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t221, i64 %t222)
  store { i64, ptr } %t225, ptr %l125
  br label %bb65
bb65:
  %t226 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t227 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t226)
  store %"compiler/typed:Block" %t227, ptr %l126
  br label %bb66
bb66:
  %t228 = load %"compiler/typed:Block", ptr %l126
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t228, ptr %t229
  call void @__olang_scope_close(ptr %s0)
  store ptr %t229, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l12 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i32, ptr %l12, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l17
  br label %bb6
bb6:
  %t31 = load i32, ptr %l17, !range !{i32 0, i32 33}
  %t33 = trunc i64 19 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l21, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb9:
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load i32, ptr %l26, !tbaa !23
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t49, ptr %l27
  br label %bb10
bb10:
  %t50 = load i1, ptr %l27, !tbaa !21
  store i1 %t50, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l20, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueWalk(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i1
  %l13 = alloca i64
  %l21 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i1
  %l44 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l53 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i1, ptr %l8, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t13, i32 %t14, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, i64 1)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp slt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  %t29 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t27, i64 %t28, i32 %t29)
  store i32 %t33, ptr %l21
  br label %bb9
bb9:
  %t34 = load i32, ptr %l21, !tbaa !23
  store i32 %t34, ptr %l3, !tbaa !23
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb13
bb13:
  %t52 = load i32, ptr %l30, !tbaa !23
  store i32 %t52, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l33
  br label %bb14
bb14:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l36, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l39
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb17:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t70, ptr %l40
  br label %bb18
bb18:
  %t71 = load i1, ptr %l40, !tbaa !21
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l49
  br label %bb22
bb21:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb24
bb22:
  %t89 = load ptr, ptr %l44, !tbaa !29
  %t90 = load i32, ptr %l49, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t89, i32 %t90)
  store { i64, ptr } %t91, ptr %l50
  br label %bb23
bb23:
  %t92 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t95 = icmp eq i64 %t93, 0
  store i1 %t95, ptr %l41, !tbaa !21
  br label %bb24
bb24:
  %t97 = load i1, ptr %l41, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l53, !tbaa !24
  br label %bb27
bb26:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i64, ptr %l53, !tbaa !24
  store i64 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsetLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/typed:Local"
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca %"compiler/typed:Local"
  %l50 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  %l72 = alloca i64
  %l75 = alloca i64
  %l79 = alloca ptr
  %l88 = alloca i64
  %l91 = alloca i64
  %l109 = alloca i64
  %l116 = alloca ptr
  %l121 = alloca ptr
  %l125 = alloca i1
  %l132 = alloca i64
  %l134 = alloca i64
  %l138 = alloca ptr
  %l141 = alloca i64
  %l164 = alloca i32
  %l170 = alloca ptr
  %l174 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca i1
  %t123 = alloca i64
  %t271 = alloca { i64, [3 x i64] }, align 8
  %t293 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 48
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l28
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l28, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  store ptr %t9, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t10 = load ptr, ptr %l29, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l29, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 17}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l30, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t20, i32 0, i32 0
  %t22 = load %"compiler/source:Span", ptr %t21
  store %"compiler/source:Span" %t22, ptr %l5
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t26, i32 0, i32 1
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l6, !tbaa !23
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l7, !tbaa !29
  br label %bb6
bb5:
  br label %bb75
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l40
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l40, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t39, i32 0, i32 7
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t41, i64 %t42)
  store %"compiler/typed:Local" %t45, ptr %l44
  br label %bb8
bb8:
  %t46 = load %"compiler/typed:Local", ptr %l44
  store %"compiler/typed:Local" %t46, ptr %l8
  %t47 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 2
  %t48 = load i32, ptr %t47, !tbaa !23
  store i32 %t48, ptr %l9, !tbaa !23
  %t50 = load i32, ptr %l6, !tbaa !23
  %t52 = sext i32 %t50 to i64
  %t53 = load i64, ptr %l2, !tbaa !24
  %t56 = icmp ne i64 %t52, %t53
  br i1 %t56, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb11
bb10:
  %t58 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 4
  %t59 = load i32, ptr %t58, !range !{i32 0, i32 7}
  %t61 = trunc i64 1 to i32
  %t62 = icmp eq i32 %t59, %t61
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l50, !tbaa !21
  br label %bb11
bb11:
  %t66 = load i1, ptr %l50, !tbaa !21
  br i1 %t66, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb14
bb13:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 6
  %t68 = load i1, ptr %t67, !tbaa !21
  store i1 %t68, ptr %l54, !tbaa !21
  br label %bb14
bb14:
  %t70 = load i1, ptr %l54, !tbaa !21
  br i1 %t70, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb18
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l9, !tbaa !23
  %t75 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t71, i32 %t72)
  store i1 %t75, ptr %l59
  br label %bb17
bb17:
  %t76 = load i1, ptr %l59, !tbaa !21
  store i1 %t76, ptr %l56, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l56, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb22
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l9, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsetLowers(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l63
  br label %bb21
bb21:
  %t83 = load i1, ptr %l63, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l60, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb26
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l9, !tbaa !23
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %t87, i32 %t88)
  store i1 %t91, ptr %l68
  br label %bb25
bb25:
  %t92 = load i1, ptr %l68, !tbaa !21
  store i1 %t92, ptr %l65, !tbaa !21
  br label %bb26
bb26:
  %t93 = load i1, ptr %l65, !tbaa !21
  br i1 %t93, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 48
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l72
  br label %bb30
bb30:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t101 = load i64, ptr %l72, !tbaa !24
  %t103 = sub i64 %t101, %t100
  %t105 = sub i64 %t103, 1
  store i64 %t105, ptr %l75, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 48
  %t109 = load i64, ptr %l1, !tbaa !24
  %t112 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %s1, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l79
  br label %bb31
bb31:
  %t113 = load i64, ptr %l75, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb32, label %bb33
bb32:
  %t116 = load i64, ptr %l75, !tbaa !24
  %t117 = icmp sle i64 %t116, 1152921504606846975
  br i1 %t117, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_70ab971263114c9e_cd743d11240e125a)
  unreachable
bb34:
  %t119 = load i64, ptr %l75, !tbaa !24
  %t120 = mul i64 %t119, 8
  %t121 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t120)
  %t122 = load ptr, ptr %l79, !tbaa !29
  store i64 0, ptr %t123
  br label %fill.124
fill.124:
  %t127 = load i64, ptr %t123
  %t128 = icmp slt i64 %t127, %t119
  br i1 %t128, label %fillb.125, label %filld.126
fillb.125:
  %t129 = getelementptr ptr, ptr %t121, i64 %t127
  store ptr %t122, ptr %t129
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %t123
  br label %fill.124
filld.126:
  %t131 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t121, 1
  store { i64, ptr } %t132, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = icmp sgt i64 %t138, %t139
  br i1 %t142, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_70ab971263114c9e_cd743d11240e125a)
  unreachable
bb36:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb41
bb38:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = sub i64 %t148, %t149
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = add i64 %t152, %t153
  %t158 = sub i64 %t156, 1
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = sdiv i64 %t158, %t159
  store i64 %t162, ptr %l91, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb40
bb40:
  %t164 = load i64, ptr %l91, !tbaa !24
  store i64 %t164, ptr %l88, !tbaa !24
  br label %bb41
bb41:
  %t165 = load i64, ptr %l88, !tbaa !24
  store i64 %t165, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb42
bb42:
  %t166 = load i64, ptr %l15, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t174 = load i64, ptr %l11, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t176 = load i64, ptr %l13, !tbaa !24
  %t179 = mul i64 %t175, %t176
  %t182 = add i64 %t174, %t179
  store i64 %t182, ptr %l16, !tbaa !24
  %t184 = load i64, ptr %l16, !tbaa !24
  store i64 %t184, ptr %l109, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 48
  %t188 = load i64, ptr %l1, !tbaa !24
  %t190 = add i64 %t188, 1
  %t191 = load i64, ptr %l16, !tbaa !24
  %t194 = add i64 %t190, %t191
  %t197 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %s1, ptr %t187, i64 %t194)
  store ptr %t197, ptr %l116
  br label %bb46
bb46:
  %t198 = load ptr, ptr %l116, !tbaa !29
  %t199 = load i64, ptr %l109, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr ptr, ptr %t201, i64 %t199
  store ptr %t198, ptr %t202, !tbaa !39
  br label %bb47
bb47:
  %t203 = load i64, ptr %l15, !tbaa !24
  %t206 = add i64 %t203, 1
  store i64 %t206, ptr %l15, !tbaa !24
  br label %bb42
bb48:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t208)
  store ptr %t210, ptr %l121
  br label %bb49
bb49:
  %t211 = load i32, ptr %l6, !tbaa !23
  %t212 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t214 = load ptr, ptr %l121, !tbaa !29
  %t218 = call i1 @compiler_2fdefinit_2eReadIn(ptr %v0, ptr %s1, ptr %v1, ptr %t214, i32 %t211, { i64, ptr } %t212, ptr %a3)
  store i1 %t218, ptr %l125
  br label %bb50
bb50:
  %t219 = load i1, ptr %l125, !tbaa !21
  br i1 %t219, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t224, i32 0, i32 0
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/load:Loader", ptr %t227, i32 0, i32 4
  %t230 = load ptr, ptr %t229, !tbaa !29
  store ptr %t230, ptr %l17, !tbaa !29
  %t232 = load ptr, ptr %l17, !tbaa !29
  %t234 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t232)
  store i64 %t234, ptr %l132
  br label %bb54
bb54:
  %t235 = load i64, ptr %l132, !tbaa !24
  store i64 %t235, ptr %l18, !tbaa !24
  %t236 = load ptr, ptr %l17, !tbaa !29
  %t238 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t236)
  store i64 %t238, ptr %l134
  br label %bb55
bb55:
  %t239 = load i64, ptr %l134, !tbaa !24
  store i64 %t239, ptr %l19, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l5
  %t242 = load i32, ptr %l9, !tbaa !23
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t240, %"compiler/source:Span" %t241, i32 %t242)
  store ptr %t246, ptr %l138
  br label %bb56
bb56:
  %t247 = load ptr, ptr %l138, !tbaa !29
  store ptr %t247, ptr %l20, !tbaa !29
  %t248 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t248)
  br label %bb57
bb57:
  %t250 = load ptr, ptr %l17, !tbaa !29
  %t252 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t250)
  store i64 %t252, ptr %l141
  br label %bb58
bb58:
  %t253 = load i64, ptr %l19, !tbaa !24
  %t254 = load i64, ptr %l141, !tbaa !24
  %t256 = icmp sgt i64 %t254, %t253
  store i1 %t256, ptr %l21, !tbaa !21
  %t258 = load ptr, ptr %l17, !tbaa !29
  %t259 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t258, i64 %t259)
  br label %bb59
bb59:
  %t262 = load i1, ptr %l21, !tbaa !21
  br i1 %t262, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 48
  %t268 = load i64, ptr %l1, !tbaa !24
  %t269 = load %"compiler/source:Span", ptr %l5
  %t270 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [3 x i64] }, ptr %t271, i32 0, i32 0
  store i64 2, ptr %t272
  %t274 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t269, 0
  %t276 = insertvalue { %"compiler/source:Span", ptr } %t274, ptr %t270, 1
  %t277 = getelementptr { i64, [3 x i64] }, ptr %t271, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t276, ptr %t277
  %t278 = load { i64, [3 x i64] }, ptr %t271
  %t280 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t278, ptr %t280
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eSetAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t267, i64 %t268, ptr %t280)
  br label %bb63
bb63:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 48
  %t287 = load i64, ptr %l1, !tbaa !24
  %t289 = add i64 %t287, 1
  %t290 = load %"compiler/source:Span", ptr %l5
  %t291 = load i32, ptr %l6, !tbaa !23
  %t292 = load ptr, ptr %l20, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t293
  %t294 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 0
  store i64 0, ptr %t294
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t290, 0
  %t298 = insertvalue { %"compiler/source:Span", i32, ptr } %t296, i32 %t291, 1
  %t300 = insertvalue { %"compiler/source:Span", i32, ptr } %t298, ptr %t292, 2
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t300, ptr %t301
  %t302 = load { i64, [3 x i64] }, ptr %t293
  %t304 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t302, ptr %t304
  %t308 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eInsert_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t286, i64 %t289, ptr %t304)
  store i32 %t308, ptr %l164
  %t309 = icmp ne i32 %t308, 0
  br i1 %t309, label %bb65, label %ok.310, !prof !99
ok.310:
  br label %bb64
bb64:
  br label %bb72
bb65:
  %t311 = load i32, ptr %l164, !tbaa !23
  %t312 = icmp eq i32 %t311, 65536
  br i1 %t312, label %bb66, label %bb67
bb66:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5ba8350fe4512599_b4866249ee2176d5)
  unreachable
bb67:
  %t314 = load i32, ptr %l164, !tbaa !23
  %t315 = icmp eq i32 %t314, 65537
  br i1 %t315, label %bb68, label %bb69
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1409f0b176f20518_2389703636ba5b94)
  unreachable
bb69:
  %t317 = load i32, ptr %l164, !tbaa !23
  %t318 = icmp eq i32 %t317, 65538
  br i1 %t318, label %bb70, label %bb71
bb70:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d019ff468b10bf96_655f5891923eae12)
  unreachable
bb71:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5357dc0062411eea_45c797ca02d5070e)
  unreachable
bb72:
  %t320 = load i64, ptr %l2, !tbaa !24
  store i64 %t320, ptr %l22, !tbaa !24
  store i1 true, ptr %l23, !tbaa !21
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t322)
  store ptr %t324, ptr %l170
  br label %bb73
bb73:
  %t325 = load ptr, ptr %l170, !tbaa !29
  %t327 = getelementptr %"compiler/typed:Body", ptr %t325, i32 0, i32 7
  %t328 = load i64, ptr %l22, !tbaa !24
  %t331 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v0, ptr %t327, i64 %t328)
  store ptr %t331, ptr %l174
  br label %bb74
bb74:
  %t332 = load ptr, ptr %l174, !tbaa !29
  %t334 = load i1, ptr %l23, !tbaa !21
  %t337 = getelementptr %"compiler/typed:Local", ptr %t332, i32 0, i32 6
  store i1 %t334, ptr %t337, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_a9e0d18ce713e138_9f5957e93e8b8944)
  unreachable
bb80:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca i32
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l49 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l58 = alloca ptr
  %l63 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca i32
  %l100 = alloca i32
  %l104 = alloca ptr
  %l107 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca i64
  %l119 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca %"compiler/source:Span"
  %l125 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca %"compiler/source:Span"
  %l149 = alloca ptr
  %l152 = alloca i32
  %l153 = alloca i32
  %l157 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca %"compiler/source:Span"
  %l168 = alloca ptr
  %l169 = alloca i64
  %l173 = alloca ptr
  %l178 = alloca i64
  %l180 = alloca ptr
  %l183 = alloca i64
  %l184 = alloca i32
  %l185 = alloca i64
  %l187 = alloca ptr
  %l190 = alloca i64
  %l191 = alloca i32
  %l197 = alloca ptr
  %l200 = alloca i64
  %l204 = alloca { i64, i64, i64 }
  %l208 = alloca ptr
  %l209 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l211 = alloca i64
  %l212 = alloca ptr
  %l213 = alloca %"compiler/source:Span"
  %l215 = alloca i32
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l223 = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t265 = alloca { i64, [4 x i64] }, align 8
  %t421 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v2, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l29
  br label %bb1
bb1:
  %t8 = load i64, ptr %l29, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l30, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l31
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l33
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l30, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l31
  %t16 = load i32, ptr %l33, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l34
  br label %bb3
bb3:
  %t18 = load i64, ptr %l34, !tbaa !24
  store i64 %t18, ptr %l9, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l35, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l36
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l39, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l40, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l41
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l43
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l40, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l41
  %t32 = load i32, ptr %l43, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l44
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l36
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l39, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l44, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 48
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l49
  br label %bb7
bb7:
  %t53 = load i64, ptr %l49, !tbaa !24
  store i64 %t53, ptr %l10, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t59 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t54, i32 2, %"compiler/source:Span" %t55)
  store { i64, i64, i64 } %t59, ptr %l53
  br label %bb8
bb8:
  %t60 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t60, ptr %l11
  %t61 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l13, !tbaa !24
  %t67 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t70)
  store ptr %t72, ptr %l58
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l58, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 10
  %t76 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t79)
  store ptr %t81, ptr %l63
  br label %bb11
bb11:
  %t82 = load ptr, ptr %l63, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 11
  %t85 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  br label %bb12
bb12:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/ast:ForIn", ptr %t88, i32 0, i32 3
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t93)
  store ptr %t95, ptr %l70
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t96 = load ptr, ptr %l70, !tbaa !29
  store ptr %t96, ptr %l71, !tbaa !29
  %t97 = load ptr, ptr %l71, !tbaa !29
  %t98 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 15
  %t99 = load i64, ptr %t98, !tbaa !24
  %t102 = add i64 %t99, 1
  %t104 = load ptr, ptr %l71, !tbaa !29
  %t105 = getelementptr %"compiler/check:frame", ptr %t104, i32 0, i32 15
  store i64 %t102, ptr %t105, !tbaa !24
  br label %bb16
bb16:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l75, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t107, ptr %l76
  %t108 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t108, ptr %l77
  store i64 %a5, ptr %l78, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  %t112 = load i64, ptr %l8, !tbaa !24
  %t116 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t110, %"compiler/source:Span" %t111, i64 %t112)
  store ptr %t116, ptr %l82
  br label %bb17
bb17:
  %t117 = load ptr, ptr %l82, !tbaa !29
  store ptr %t117, ptr %l83, !tbaa !29
  %t118 = icmp sge i64 0, 0
  br i1 %t118, label %bb18, label %bb19
bb18:
  %t120 = icmp sle i64 0, 1152921504606846975
  br i1 %t120, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb20:
  %t122 = mul i64 0, 8
  %t123 = insertvalue { i64, ptr } undef, i64 0, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t124, ptr %l86, !tbaa !27
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb22:
  %t127 = icmp sle i64 0, 1152921504606846975
  br i1 %t127, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb24:
  %t129 = mul i64 0, 8
  %t130 = insertvalue { i64, ptr } undef, i64 0, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t131, ptr %l89, !tbaa !27
  %t132 = icmp sge i64 0, 0
  br i1 %t132, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb26:
  %t134 = icmp sle i64 0, 2305843009213693951
  br i1 %t134, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb28:
  %t136 = mul i64 0, 4
  %t137 = insertvalue { i64, ptr } undef, i64 0, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t139 = load ptr, ptr %l75, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l76
  %t141 = load %"compiler/source:Span", ptr %l77
  %t142 = load i64, ptr %l78, !tbaa !24
  %t143 = load ptr, ptr %l83, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t139, %"compiler/source:Span" %t140, %"compiler/source:Span" %t141, i64 %t142, ptr %t143, { i64, ptr } %t144, { i64, ptr } %t145, { i64, ptr } %t138)
  store ptr %t147, ptr %l93
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb30:
  %t148 = load ptr, ptr %l93, !tbaa !29
  store ptr %t148, ptr %l15, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l94, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l95, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t151, ptr %l96
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l97, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l98
  %t154 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t154, ptr %l99, !tbaa !23
  store i32 15, ptr %l100
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  %t157 = load i64, ptr %l9, !tbaa !24
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t155, %"compiler/source:Span" %t156, i64 %t157)
  store ptr %t161, ptr %l104
  br label %bb31
bb31:
  %t162 = load ptr, ptr %l15, !tbaa !29
  %t164 = load ptr, ptr %l97, !tbaa !29
  %t165 = load %"compiler/source:Span", ptr %l98
  %t166 = load i32, ptr %l99, !tbaa !23
  %t167 = load i32, ptr %l100, !range !{i32 0, i32 54}
  %t168 = load ptr, ptr %l104, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t164, %"compiler/source:Span" %t165, i32 %t166, i32 %t167, ptr %t168, ptr %t162)
  store ptr %t170, ptr %l107
  br label %bb32
bb32:
  %t171 = load i64, ptr %l12, !tbaa !24
  %t172 = load ptr, ptr %l95, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l96
  %t174 = load ptr, ptr %l107, !tbaa !29
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v0, ptr %v0, ptr %t172, %"compiler/source:Span" %t173, ptr %t174, i64 %t171)
  store ptr %t176, ptr %l109
  br label %bb33
bb33:
  %t177 = load ptr, ptr %l94, !tbaa !29
  %t178 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t177, ptr %t178)
  br label %bb34
bb34:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l110, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l111, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i64, ptr %l8, !tbaa !24
  %t185 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t181, i64 %t182)
  store i32 %t185, ptr %l114
  br label %bb35
bb35:
  %t186 = load ptr, ptr %l111, !tbaa !29
  %t187 = load i32, ptr %l114, !tbaa !23
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t186, i32 %t187)
  store i32 %t188, ptr %l115
  br label %bb36
bb36:
  %t189 = load ptr, ptr %l110, !tbaa !29
  %t190 = load i32, ptr %l115, !tbaa !23
  %t191 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueWalk(ptr %v0, ptr %t189, i32 %t190)
  store i64 %t191, ptr %l116
  br label %bb37
bb37:
  %t192 = load i64, ptr %l116, !tbaa !24
  store i64 %t192, ptr %l16, !tbaa !24
  %t193 = load i64, ptr %l16, !tbaa !24
  %t195 = icmp slt i64 %t193, 0
  br i1 %t195, label %bb38, label %bb39
bb38:
  store i64 %a4, ptr %l119, !tbaa !24
  br label %bb40
bb39:
  %t199 = load i64, ptr %l16, !tbaa !24
  store i64 %t199, ptr %l119, !tbaa !24
  br label %bb40
bb40:
  %t201 = load i64, ptr %l119, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l122, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t203, ptr %l123
  %t204 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t204, ptr %l124
  store i64 %t201, ptr %l125, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l1
  %t208 = load i64, ptr %l8, !tbaa !24
  %t212 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t206, %"compiler/source:Span" %t207, i64 %t208)
  store ptr %t212, ptr %l129
  br label %bb41
bb41:
  %t213 = load ptr, ptr %l129, !tbaa !29
  store ptr %t213, ptr %l130, !tbaa !29
  %t214 = icmp sge i64 0, 0
  br i1 %t214, label %bb42, label %bb43
bb42:
  %t216 = icmp sle i64 0, 1152921504606846975
  br i1 %t216, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb44:
  %t218 = mul i64 0, 8
  %t219 = insertvalue { i64, ptr } undef, i64 0, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t220, ptr %l133, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l134, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l1
  %t224 = load i64, ptr %l9, !tbaa !24
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t222, %"compiler/source:Span" %t223, i64 %t224)
  store ptr %t228, ptr %l138
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb46:
  %t229 = load ptr, ptr %l134, !tbaa !29
  %t230 = load ptr, ptr %l138, !tbaa !29
  %t231 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t229, ptr %t230)
  store { i64, ptr } %t231, ptr %l139
  br label %bb47
bb47:
  %t232 = icmp sge i64 0, 0
  br i1 %t232, label %bb48, label %bb49
bb48:
  %t234 = icmp sle i64 0, 2305843009213693951
  br i1 %t234, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb50:
  %t236 = mul i64 0, 4
  %t237 = insertvalue { i64, ptr } undef, i64 0, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t239 = load ptr, ptr %l122, !tbaa !29
  %t240 = load %"compiler/source:Span", ptr %l123
  %t241 = load %"compiler/source:Span", ptr %l124
  %t242 = load i64, ptr %l125, !tbaa !24
  %t243 = load ptr, ptr %l130, !tbaa !29
  %t244 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t239, %"compiler/source:Span" %t240, %"compiler/source:Span" %t241, i64 %t242, ptr %t243, { i64, ptr } %t244, { i64, ptr } %t245, { i64, ptr } %t238)
  store ptr %t247, ptr %l143
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb52:
  %t248 = load ptr, ptr %l143, !tbaa !29
  store ptr %t248, ptr %l18, !tbaa !29
  %t249 = load i64, ptr %l16, !tbaa !24
  %t251 = icmp sge i64 %t249, 0
  br i1 %t251, label %bb53, label %bb54
bb53:
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l146, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t254, ptr %l147
  %t255 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t255, ptr %l148
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l149, !tbaa !29
  %t257 = load ptr, ptr %l18, !tbaa !29
  %t260 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t257)
  store i32 %t260, ptr %l152
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t261 = load ptr, ptr %l149, !tbaa !29
  %t262 = load i32, ptr %l152, !tbaa !23
  %t263 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t261, i32 %t262)
  store i32 %t263, ptr %l153
  br label %bb56
bb56:
  %t264 = load ptr, ptr %l18, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t265
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t265, i32 0, i32 0
  store i64 2, ptr %t266
  %t267 = load %"compiler/source:Span", ptr %l148
  %t268 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t267, 0
  %t269 = load i32, ptr %l153, !tbaa !23
  %t270 = insertvalue { %"compiler/source:Span", i32, ptr } %t268, i32 %t269, 1
  %t272 = insertvalue { %"compiler/source:Span", i32, ptr } %t270, ptr %t264, 2
  %t273 = getelementptr { i64, [4 x i64] }, ptr %t265, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t272, ptr %t273
  %t274 = load { i64, [4 x i64] }, ptr %t265
  %t276 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t274, ptr %t276
  %t277 = load ptr, ptr %l146, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l147
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t277, %"compiler/source:Span" %t278, ptr %t276)
  store ptr %t280, ptr %l157
  br label %bb57
bb57:
  %t281 = load ptr, ptr %l157, !tbaa !29
  store ptr %t281, ptr %l18, !tbaa !29
  br label %bb58
bb58:
  %t282 = load ptr, ptr %l2, !tbaa !29
  %t284 = getelementptr %"compiler/ast:ForIn", ptr %t282, i32 0, i32 3
  %t285 = load i1, ptr %t284, !tbaa !21
  br i1 %t285, label %bb59, label %bb60
bb59:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t287)
  store ptr %t289, ptr %l161
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t290 = load ptr, ptr %l161, !tbaa !29
  store ptr %t290, ptr %l162, !tbaa !29
  %t291 = load ptr, ptr %l162, !tbaa !29
  %t292 = getelementptr %"compiler/check:frame", ptr %t291, i32 0, i32 15
  %t293 = load i64, ptr %t292, !tbaa !24
  %t296 = sub i64 %t293, 1
  %t298 = load ptr, ptr %l162, !tbaa !29
  %t299 = getelementptr %"compiler/check:frame", ptr %t298, i32 0, i32 15
  store i64 %t296, ptr %t299, !tbaa !24
  br label %bb62
bb62:
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l166, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t301, ptr %l167
  %t302 = load ptr, ptr %l2, !tbaa !29
  store ptr %t302, ptr %l168, !tbaa !29
  %t303 = load i64, ptr %l9, !tbaa !24
  store i64 %t303, ptr %l169, !tbaa !24
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l18, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l1
  %t310 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v0, ptr %v0, ptr %t304, ptr %t305, %"compiler/source:Span" %t306, i1 false, i1 false)
  store ptr %t310, ptr %l173
  br label %bb63
bb63:
  %t311 = load ptr, ptr %l166, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l167
  %t313 = load ptr, ptr %l168, !tbaa !29
  %t314 = load i64, ptr %l169, !tbaa !24
  %t315 = load ptr, ptr %l173, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t311, %"compiler/source:Span" %t312, ptr %t313, i64 %t314, ptr %t315, i1 false)
  br label %bb64
bb64:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t316, ptr %t317, ptr %a6, i32 %a7)
  br label %bb65
bb65:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t324)
  store ptr %t326, ptr %l180
  br label %bb66
bb66:
  %t327 = load ptr, ptr %l180, !tbaa !29
  %t329 = getelementptr %"compiler/check:frame", ptr %t327, i32 0, i32 10
  %t331 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t329)
  %t332 = extractvalue { i32, i64 } %t331, 1
  %t333 = extractvalue { i32, i64 } %t331, 0
  store i32 %t333, ptr %l184
  %t334 = icmp ne i32 %t333, 0
  br i1 %t334, label %bb68, label %ok.335, !prof !99
ok.335:
  store i64 %t332, ptr %l183
  br label %bb67
bb67:
  %t336 = load i64, ptr %l183, !tbaa !24
  store i64 %t336, ptr %l178, !tbaa !24
  br label %bb70
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t337)
  store ptr %t339, ptr %l187
  br label %bb71
bb71:
  %t340 = load ptr, ptr %l187, !tbaa !29
  %t342 = getelementptr %"compiler/check:frame", ptr %t340, i32 0, i32 11
  %t344 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t342)
  %t345 = extractvalue { i32, i64 } %t344, 1
  %t346 = extractvalue { i32, i64 } %t344, 0
  store i32 %t346, ptr %l191
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb73, label %ok.348, !prof !99
ok.348:
  store i64 %t345, ptr %l190
  br label %bb72
bb72:
  %t349 = load i64, ptr %l190, !tbaa !24
  store i64 %t349, ptr %l185, !tbaa !24
  br label %bb75
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load i64, ptr %l12, !tbaa !24
  %t352 = load i64, ptr %l13, !tbaa !24
  %t353 = load i64, ptr %l14, !tbaa !24
  %t354 = load i64, ptr %l10, !tbaa !24
  %t360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t350, i64 %t351, i64 %t352, i64 %t353, i64 %t354)
  store ptr %t360, ptr %l197
  br label %bb76
bb76:
  %t361 = load ptr, ptr %l197, !tbaa !29
  store ptr %t361, ptr %l19, !tbaa !29
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/check:Checker", ptr %t362, i32 0, i32 48
  %t366 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t364)
  store i64 %t366, ptr %l200
  br label %bb77
bb77:
  %t367 = load i64, ptr %l200, !tbaa !24
  store i64 %t367, ptr %l20, !tbaa !24
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load %"compiler/source:Span", ptr %l1
  %t373 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t368, i32 3, %"compiler/source:Span" %t369)
  store { i64, i64, i64 } %t373, ptr %l204
  br label %bb78
bb78:
  %t374 = load { i64, i64, i64 }, ptr %l204
  store { i64, i64, i64 } %t374, ptr %l21
  %t375 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 0
  %t376 = load i64, ptr %t375, !tbaa !24
  store i64 %t376, ptr %l22, !tbaa !24
  %t378 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 1
  %t379 = load i64, ptr %t378, !tbaa !24
  store i64 %t379, ptr %l23, !tbaa !24
  %t381 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 2
  %t382 = load i64, ptr %t381, !tbaa !24
  store i64 %t382, ptr %l24, !tbaa !24
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l208, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t385, ptr %l209, !tbaa !29
  %t386 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t386, ptr %l210
  %t387 = load i64, ptr %l9, !tbaa !24
  store i64 %t387, ptr %l211, !tbaa !24
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l212, !tbaa !29
  %t389 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t389, ptr %l213
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t390)
  store i32 %t392, ptr %l215
  br label %bb79
bb79:
  %t393 = load ptr, ptr %l212, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l213
  %t395 = load i32, ptr %l215, !tbaa !23
  %t396 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t393, %"compiler/source:Span" %t394, i32 %t395, i64 1)
  store ptr %t396, ptr %l216
  br label %bb80
bb80:
  %t397 = load ptr, ptr %l209, !tbaa !29
  %t398 = load %"compiler/source:Span", ptr %l210
  %t399 = load i64, ptr %l211, !tbaa !24
  %t400 = load ptr, ptr %l216, !tbaa !29
  %t401 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t397, %"compiler/source:Span" %t398, i64 %t399, ptr %t400)
  store ptr %t401, ptr %l217
  br label %bb81
bb81:
  %t402 = load ptr, ptr %l208, !tbaa !29
  %t403 = load ptr, ptr %l217, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t402, ptr %t403)
  br label %bb82
bb82:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load i64, ptr %l22, !tbaa !24
  %t406 = load i64, ptr %l23, !tbaa !24
  %t407 = load i64, ptr %l24, !tbaa !24
  %t408 = load i64, ptr %l20, !tbaa !24
  %t414 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t404, i64 %t405, i64 %t406, i64 %t407, i64 %t408)
  store ptr %t414, ptr %l223
  br label %bb83
bb83:
  %t415 = load ptr, ptr %l223, !tbaa !29
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l1
  %t418 = load ptr, ptr %l19, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t421
  %t422 = getelementptr { i64, [3 x i64] }, ptr %t421, i32 0, i32 0
  store i64 4, ptr %t422
  %t424 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t417, 0
  %t426 = insertvalue { %"compiler/source:Span", ptr, ptr } %t424, ptr %t418, 1
  %t428 = insertvalue { %"compiler/source:Span", ptr, ptr } %t426, ptr %t415, 2
  %t429 = getelementptr { i64, [3 x i64] }, ptr %t421, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t428, ptr %t429
  %t430 = load { i64, [3 x i64] }, ptr %t421
  %t432 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t430, ptr %t432
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t416, ptr %t432)
  br label %bb84
bb84:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eweakRow(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/check:weakPlace" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:weakPlace"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, [3 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/check:weakPlace" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t6 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = trunc i64 %t7 to i32
  %t13 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t5, i32 %t9)
  store i32 %t13, ptr %l15
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l16
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 6
  %t24 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %s0, ptr %t23, i64 %t25)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l23
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb4, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l22
  br label %bb3
bb3:
  %t33 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l25, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t46, ptr %l17, !tbaa !27
  br label %bb6
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t47, ptr %l17, !tbaa !27
  br label %bb6
bb6:
  %t49 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l28, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t62, ptr %l3, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t65, ptr %l31
  br label %bb7
bb7:
  %t66 = load i1, ptr %l31, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb8, label %bb9
bb8:
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t73 = extractvalue { i64, ptr } %t69, 1
  %t74 = extractvalue { i64, ptr } %t69, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t80, ptr %t73, i64 %t74)
  %t81 = getelementptr i8, ptr %t80, i64 %t74
  call void @olang_textcopy(ptr %t81, ptr %t76, i64 %t77)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t79, 1
  store { i64, ptr } %t83, ptr %l33, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb10
bb10:
  %t86 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t86, ptr %l4, !tbaa !27
  %t87 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 0
  %t88 = load { i64, [3 x i64] }, ptr %t87
  store { i64, [3 x i64] } %t88, ptr %l5
  %t90 = load { i64, [3 x i64] }, ptr %l5
  %t92 = extractvalue { i64, [3 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 3
  br i1 %t93, label %bb11, label %bb12
bb11:
  %t95 = getelementptr { i64, [3 x i64] }, ptr %l5, i32 0, i32 1
  %t96 = getelementptr { i64, i64, i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l6, !tbaa !24
  %t99 = getelementptr { i64, [3 x i64] }, ptr %l5, i32 0, i32 1
  %t100 = getelementptr { i64, i64, i64 }, ptr %t99, i32 0, i32 1
  %t101 = load i64, ptr %t100
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i64, ptr %l6, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t118 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %t112, i64 %t113, i64 %t114)
  store { i64, ptr } %t118, ptr %l49
  br label %bb14
bb14:
  %t119 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t119, ptr %l38, !tbaa !27
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t120, ptr %l38, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e30e75934041bac1_8633653d6080ffc5)
  unreachable
bb20:
  %t122 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l52, !tbaa !24
  %t124 = load i64, ptr %l52, !tbaa !24
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l53, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l52, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t137 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t141 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t135, 1
  %t145 = extractvalue { i64, ptr } %t135, 0
  %t146 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t150 = extractvalue { i64, ptr } %t138, 1
  %t151 = extractvalue { i64, ptr } %t138, 0
  %t152 = add i64 %t148, %t151
  %t153 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t157 = extractvalue { i64, ptr } %t139, 1
  %t158 = extractvalue { i64, ptr } %t139, 0
  %t159 = add i64 %t155, %t158
  %t160 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t162 = add i64 %t159, %t161
  %t164 = extractvalue { i64, ptr } %t140, 1
  %t165 = extractvalue { i64, ptr } %t140, 0
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t142, 1
  %t172 = extractvalue { i64, ptr } %t142, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t144, i64 %t145)
  %t178 = getelementptr i8, ptr %t177, i64 %t145
  call void @olang_textcopy(ptr %t178, ptr %t146, i64 %t147)
  %t179 = getelementptr i8, ptr %t178, i64 %t147
  call void @olang_textcopy(ptr %t179, ptr %t150, i64 %t151)
  %t180 = getelementptr i8, ptr %t179, i64 %t151
  call void @olang_textcopy(ptr %t180, ptr %t153, i64 %t154)
  %t181 = getelementptr i8, ptr %t180, i64 %t154
  call void @olang_textcopy(ptr %t181, ptr %t157, i64 %t158)
  %t182 = getelementptr i8, ptr %t181, i64 %t158
  call void @olang_textcopy(ptr %t182, ptr %t160, i64 %t161)
  %t183 = getelementptr i8, ptr %t182, i64 %t161
  call void @olang_textcopy(ptr %t183, ptr %t164, i64 %t165)
  %t184 = getelementptr i8, ptr %t183, i64 %t165
  call void @olang_textcopy(ptr %t184, ptr %t167, i64 %t168)
  %t185 = getelementptr i8, ptr %t184, i64 %t168
  call void @olang_textcopy(ptr %t185, ptr %t171, i64 %t172)
  %t186 = getelementptr i8, ptr %t185, i64 %t172
  call void @olang_textcopy(ptr %t186, ptr %t174, i64 %t175)
  %t187 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t177, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t188, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { ptr, %"compiler/check:unsetCand" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l20 = alloca { i64, [3 x i64] }
  %l26 = alloca i64
  %l28 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i64
  %l42 = alloca ptr
  %l47 = alloca i64
  %l54 = alloca i64
  %l57 = alloca ptr
  %l59 = alloca ptr
  %l69 = alloca %"compiler/check:unsetCand"
  %s0 = alloca %olang.scope
  %rv = alloca { ptr, %"compiler/check:unsetCand" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 18
  %t4 = load { i64, [3 x i64] }, ptr %t3
  store { i64, [3 x i64] } %t4, ptr %l4
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l14, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:VarDecl", ptr %t8, i32 0, i32 2
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  br i1 %t13, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d697a30a6d3c659a_b9f18755b68d06fe)
  unreachable
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:VarDecl", ptr %t15, i32 0, i32 2
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t21 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t19, ptr %t18)
  store { i64, [3 x i64] } %t21, ptr %l20
  br label %bb4
bb4:
  %t22 = load { i64, [3 x i64] }, ptr %l20
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 18
  store { i64, [3 x i64] } %t22, ptr %t24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/load:Loader", ptr %t31, i32 0, i32 4
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l5, !tbaa !29
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l26
  br label %bb5
bb5:
  %t39 = load i64, ptr %l26, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l28
  br label %bb6
bb6:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l2
  %t46 = load i32, ptr %l3, !tbaa !23
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v2, ptr %t44, %"compiler/source:Span" %t45, i32 %t46)
  store ptr %t50, ptr %l32
  br label %bb7
bb7:
  %t51 = load ptr, ptr %l32, !tbaa !29
  store ptr %t51, ptr %l8, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t52)
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t56 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l35
  br label %bb9
bb9:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l35, !tbaa !24
  %t60 = icmp sgt i64 %t58, %t57
  store i1 %t60, ptr %l9, !tbaa !21
  %t62 = load i1, ptr %l9, !tbaa !21
  br i1 %t62, label %bb10, label %bb11
bb10:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l2
  %t66 = load i32, ptr %l3, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t64, %"compiler/source:Span" %t65, i32 %t66, i64 0)
  store ptr %t70, ptr %l42
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t71 = load ptr, ptr %l42, !tbaa !29
  store ptr %t71, ptr %l8, !tbaa !29
  br label %bb13
bb13:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load { i64, [3 x i64] }, ptr %l4
  %t76 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 18
  store { i64, [3 x i64] } %t73, ptr %t76
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 128
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l47
  br label %bb14
bb14:
  %t82 = load i64, ptr %l47, !tbaa !24
  store i64 %t82, ptr %l10, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l2
  %t85 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v0, ptr %t83, i32 1, %"compiler/source:Span" %t84, i32 %t85, ptr null)
  br label %bb15
bb15:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 128
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t92)
  store i64 %t94, ptr %l54
  br label %bb16
bb16:
  %t95 = load i64, ptr %l10, !tbaa !24
  %t96 = load i64, ptr %l54, !tbaa !24
  %t98 = icmp eq i64 %t96, %t95
  br i1 %t98, label %bb17, label %bb18
bb17:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t100 = load ptr, ptr %l8, !tbaa !29
  store ptr %t100, ptr %l57, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t101)
  store ptr %t103, ptr %l59
  br label %bb20
bb20:
  %t104 = load ptr, ptr %l59, !tbaa !29
  %t106 = getelementptr %"compiler/check:frame", ptr %t104, i32 0, i32 0
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load i64, ptr %l6, !tbaa !24
  %t109 = load i1, ptr %l9, !tbaa !21
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load %"compiler/source:Span", ptr %l2
  %t112 = load i32, ptr %l3, !tbaa !23
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/ast:VarDecl", ptr %t113, i32 0, i32 5
  %t116 = load i1, ptr %t115, !tbaa !21
  %t124 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s0, i64 %t107, i64 -1, i64 %t108, i1 %t109, i64 %t110, %"compiler/source:Span" %t111, i32 %t112, i1 %t116)
  store %"compiler/check:unsetCand" %t124, ptr %l69
  br label %bb21
bb21:
  %t125 = load ptr, ptr %l57, !tbaa !29
  %t126 = insertvalue { ptr, %"compiler/check:unsetCand" } undef, ptr %t125, 0
  %t127 = load %"compiler/check:unsetCand", ptr %l69
  %t128 = insertvalue { ptr, %"compiler/check:unsetCand" } %t126, %"compiler/check:unsetCand" %t127, 1
  call void @__olang_scope_close(ptr %s0)
  store { ptr, %"compiler/check:unsetCand" } %t128, ptr %rv
  br label %ret
ret:
  %rr = load { ptr, %"compiler/check:unsetCand" }, ptr %rv
  ret { ptr, %"compiler/check:unsetCand" } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ejoinBytes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l53 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i1
  %l93 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = add i64 %t3, %t6
  store i64 %t9, ptr %l19, !tbaa !24
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l19, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_489f62f877911e0f_f9fedbe42e1f3c23)
  unreachable
bb3:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb8
bb5:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l30, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l30, !tbaa !24
  store i64 %t49, ptr %l27, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l27, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t51, 1
  store i64 %t52, ptr %l39, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t53, 2147483648
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp sge i64 %t55, 0
  %t59 = and i1 %t54, %t56
  store i1 %t59, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t79, ptr %l53, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t88 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t78
  store i8 %t85, ptr %t90, !tbaa !32
  br label %bb13
bb13:
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l7, !tbaa !24
  br label %bb9
bb14:
  store i64 0, ptr %l9, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb15, label %bb16
bb15:
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb20
bb17:
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l67, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb19
bb19:
  %t126 = load i64, ptr %l67, !tbaa !24
  store i64 %t126, ptr %l64, !tbaa !24
  br label %bb20
bb20:
  %t127 = load i64, ptr %l64, !tbaa !24
  store i64 %t127, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = sub i64 %t128, 1
  store i64 %t129, ptr %l76, !tbaa !24
  %t130 = load i64, ptr %l12, !tbaa !24
  %t131 = icmp slt i64 %t130, 2147483648
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  %t136 = and i1 %t131, %t133
  store i1 %t136, ptr %l79, !tbaa !21
  br label %bb21
bb21:
  %t137 = load i64, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  store i64 %t153, ptr %l14, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = load i64, ptr %l14, !tbaa !24
  %t161 = add i64 %t157, %t158
  %t162 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t162, ptr %l93, !tbaa !27
  %t163 = load i64, ptr %l14, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i8, ptr %t166, i64 %t163
  %t168 = load i8, ptr %t167, !tbaa !32
  %t171 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i8, ptr %t172, i64 %t161
  store i8 %t168, ptr %t173, !tbaa !32
  br label %bb25
bb25:
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l13, !tbaa !24
  br label %bb21
bb26:
  %t179 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t179, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2eplaceLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb31
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 28}
  %t17 = icmp eq i64 %t15, 12
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb31
bb12:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb13, label %bb14
bb13:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 28}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb14
bb14:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb15, label %bb16
bb15:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i1 @compiler_2fcheck_2eplaceLike(ptr %v0, ptr %t34)
  store i1 %t36, ptr %l19
  br label %bb18
bb18:
  %t37 = load i1, ptr %l19, !tbaa !21
  store i1 %t37, ptr %l3, !tbaa !21
  br label %bb31
bb19:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb20, label %bb21
bb20:
  %t42 = load ptr, ptr %l20, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 28}
  %t45 = icmp eq i64 %t43, 2
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb22, label %bb23
bb22:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = call i1 @compiler_2fcheck_2eplaceLike(ptr %v0, ptr %t53)
  store i1 %t55, ptr %l27
  br label %bb25
bb25:
  %t56 = load i1, ptr %l27, !tbaa !21
  store i1 %t56, ptr %l3, !tbaa !21
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8194cbcd93ed6595_4ed826dc17164771)
  unreachable
bb31:
  %t57 = load i1, ptr %l3, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:fixedInit"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:fixedInit" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/check:fixedInit" %t6, i32 %a1, 1
  store %"compiler/check:fixedInit" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:fixedInit", ptr %rv
  ret %"compiler/check:fixedInit" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a conversion of this kind" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Vec" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Map" }>, align 8
@.d6 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"StringBuilder" }>, align 8
@.d7 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"std/set" }>, align 8
@.d8 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Set" }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"std/deque" }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Deque" }>, align 8
@.d11 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"std/heap" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Heap" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define internal i1 @olang_lambda_14(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define internal i1 @olang_lambda_15(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d20 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".Len() > 0" }>, align 8
@.d21 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".Len() == 0" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@olang_2esole_2ecompiler_2fcheck_3aChecker_2e44 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3arangeIndex_2e3 = weak hidden constant i1 false
define linkonce_odr %"compiler/check:rangeIndex" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3arangeIndex(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:rangeIndex"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/check:rangeIndex"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:rangeIndex", ptr %a0
  store %"compiler/check:rangeIndex" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:rangeIndex", ptr %l1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/check:rangeIndex", ptr %l1, i32 0, i32 3
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/check:rangeIndex", ptr %l1
  store %"compiler/check:rangeIndex" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:rangeIndex", ptr %rv
  ret %"compiler/check:rangeIndex" %rr
}

declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Ref" }>, align 8
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" -" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c": memory: " }>, align 8
@.d33 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" is weak: a " }>, align 8
@.d34 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" is held by its owning places" }>, align 8
@.d35 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d36 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" reads null once none holds it\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_82b0d2a61edf3c68_78216e4ccea776dc = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerBinding(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderNotValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4, %"compiler/source:Span" %a5, i32 %a6, i1 %a7)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_d5eb4bc83317f0cf_8c7e90b31a67a25b = external constant [0 x i8]
@olang_loc_9d7ece6248e2c3f0_c2c00bd4e16cd76c = external constant [0 x i8]
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efilledNext(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_ba7201cf019a5b45_d1ff0f9e11a3d721 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
@olang_loc_670b6c8fdf0e169e_19408787ee47819a = external constant [0 x i8]
declare ptr @compiler_2fcheck_2eheldValue(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_416f5d97ab935603_252f7809267b087 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_31a8bd4d82790674_3781f3f0c2055368 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d0d18e793a787969_e89e213e76d783d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2efreshValue(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efreshWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_78d0351a8836f282_d675d63765080c56 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_457623a9c758d3c7_b05c0b7da85964c3 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@olang_loc_68b39597279db2a8_7d3f350750fe5f34 = external constant [0 x i8]
@olang_loc_bb2f53ecd9453d1e_99003bb1ad581f22 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e95e92bfbd181c5_df64b77a5c642989 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3, i1 %a4)
@olang_loc_f1a2b5bf4319ea70_a1020a03511bf894 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueMoved(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2a0f33252d4f174f_5cf7e0fb34c443a3 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ccf41c77826e1902_e65c37e3a9ba9be = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_24f575d634af9fe9_d12bddbdf08d4b65 = external constant [0 x i8]
declare i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsWeak(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewInstance(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWeakFresh(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoDecl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2ePush_Hd5bae6439baa110b1f2b8b5b7cdda5ce(ptr %v0, ptr %a0, %"compiler/check:unsetCand" %a1)
@olang_loc_85cca4aa7cb02cf4_9ecd586858c19010 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
@olang_loc_959344f4a5ca7c83_1fd822b10f304e6f = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5daf2b89f219287cc2404f0b0e96c809(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/check:fixedInit" %a2)
@olang_loc_91b892f1670b4a16_cb06ea6ef08c507a = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_15565a5e809df9fd_a3fd7375e72d6f01 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ad8923f011cb5acf_6f8a151e60866063 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDtorWritten(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsInPlace(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRowsInPlaceLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eisData(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTextWrite(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImmutWrite(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWalkUnique(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroWritableRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_3ab5aWalk_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_968c62dd2cdb7cc9_e4aa23f03d53ae95 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9c0e2310e04cd1f8_9ba0cca7b5a93fa4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/check:nullNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3anullNarrow_2eKilled(ptr %v0, ptr %v1, %"compiler/check:nullNarrow" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:nullNarrow" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(ptr %v0, ptr %v1, %"compiler/check:narrowed" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:narrowed" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/check:errNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3aerrNarrow_2eKilled(ptr %v0, ptr %v1, %"compiler/check:errNarrow" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:errNarrow" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFresh(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArg(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_684fdb51a9211423_400f786f6f1a912f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePop_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeLine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_929b44a27af4e606_c6f0275d053ca0d2 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullTestOfNull(ptr %v0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullTestOfValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
@olang_loc_eb65b3680edb0345_685145072e457a11 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_becd3eb77e076db3_2d856a700a1e74b7 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunRows(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
@olang_loc_fb06dcd16342dc9_94e70e479081575d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2eLen_H423801dd0d60e2c88405a5484a32cfa6(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2ftyped_2eCutsShort(ptr %v0, ptr %a0)
@olang_loc_b9e76f30cfc88eb5_4fabd464cb64d2f9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/check:rangeIndex" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2eAt__Hb3807dfbbe58365e936467ca31dc9d49(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2ePus_Hb04e4a892496cc754693e16cdaa43e26(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:rangeIndex" %a1)
declare i1 @compiler_2ftyped_2eEveryTurn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIndexReaches(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropsGone(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsetLowers(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_70ab971263114c9e_cd743d11240e125a = external constant [0 x i8]
declare i1 @compiler_2fdefinit_2eReadIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, ptr %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eSetAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eInsert_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_5ba8350fe4512599_b4866249ee2176d5 = external constant [0 x i8]
@olang_loc_1409f0b176f20518_2389703636ba5b94 = external constant [0 x i8]
@olang_loc_d019ff468b10bf96_655f5891923eae12 = external constant [0 x i8]
@olang_loc_5357dc0062411eea_45c797ca02d5070e = external constant [0 x i8]
@olang_loc_a9e0d18ce713e138_9f5957e93e8b8944 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8 = external constant [0 x i8]
@olang_loc_19568a04807ed851_528b5bfe222c3865 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
@olang_loc_130b25e968db6b32_47c65c95f253846 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, i1 %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_e30e75934041bac1_8633653d6080ffc5 = external constant [0 x i8]
@olang_loc_d697a30a6d3c659a_b9f18755b68d06fe = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
@olang_loc_489f62f877911e0f_f9fedbe42e1f3c23 = external constant [0 x i8]
@olang_loc_8194cbcd93ed6595_4ed826dc17164771 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
