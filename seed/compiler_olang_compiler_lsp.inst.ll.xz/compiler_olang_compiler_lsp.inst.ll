; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/diag:Item" = type { i1, { i64, ptr }, i64, i64, i64, i64, { i64, ptr } }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local i64 @std_2fjson_2enameHash_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -3750763034362895579, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t49
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = zext i8 %t57 to i64
  %t62 = xor i64 %t51, %t59
  %t64 = mul i64 %t62, 1099511628211
  store i64 %t64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l6, !tbaa !24
  br label %bb7
bb12:
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fjson_2esameName_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp ne i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l22, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l22, !tbaa !24
  store i64 %t42, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l19, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l7, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l40, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i8, ptr %t66, i64 %t63
  %t68 = load i8, ptr %t67, !tbaa !32
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i8, ptr %t72, i64 %t69
  %t74 = load i8, ptr %t73, !tbaa !32
  %t77 = icmp ne i8 %t68, %t74
  br i1 %t77, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb10
bb18:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"std/json:Object", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l10, !tbaa !27
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t24 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %t20, { i64, ptr } %a1)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l15
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb7, label %ok.28
ok.28:
  store i64 %t25, ptr %l14
  br label %bb6
bb6:
  %t29 = load i64, ptr %l14, !tbaa !24
  store i64 %t29, ptr %l11, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  %t31 = insertvalue { i32, ptr } zeroinitializer, i32 65543, 0
  store { i32, ptr } %t31, ptr %rv
  br label %ret
bb9:
  %t32 = load i64, ptr %l11, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t32
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = insertvalue { i32, ptr } zeroinitializer, ptr %t36, 1
  store { i32, ptr } %t38, ptr %rv
  br label %ret
bb10:
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 65544, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"std/json:Object", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l10, !tbaa !27
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t24 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %t20, { i64, ptr } %a1)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l15
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb7, label %ok.28
ok.28:
  store i64 %t25, ptr %l14
  br label %bb6
bb6:
  %t29 = load i64, ptr %l14, !tbaa !24
  store i64 %t29, ptr %l11, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  %t31 = insertvalue { i32, ptr } zeroinitializer, i32 65543, 0
  store { i32, ptr } %t31, ptr %rv
  br label %ret
bb9:
  %t32 = load i64, ptr %l11, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t32
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = insertvalue { i32, ptr } zeroinitializer, ptr %t36, 1
  store { i32, ptr } %t38, ptr %rv
  br label %ret
bb10:
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 65544, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l38 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:Object", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:Object", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = sub i64 %t15, 1
  store i64 %t17, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb13
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/json:Object", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l24, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %t32, i64 %t29
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !37
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = call i1 @std_2fjson_2esameName_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, { i64, ptr } %t34, { i64, ptr } %t35)
  store i1 %t38, ptr %l28
  br label %bb7
bb7:
  %t39 = load i1, ptr %l28, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  %t42 = insertvalue { i32, i64 } zeroinitializer, i64 %t40, 1
  store { i32, i64 } %t42, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = sub i64 %t43, 1
  store i64 %t45, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb3
bb12:
  %t48 = insertvalue { i32, i64 } zeroinitializer, i32 65543, 0
  store { i32, i64 } %t48, ptr %rv
  br label %ret
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"std/json:Object", ptr %t49, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = sub i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = call i64 @std_2fjson_2enameHash_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t58)
  store i64 %t60, ptr %l38
  br label %bb14
bb14:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l38, !tbaa !24
  %t64 = and i64 %t62, %t61
  store i64 %t64, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"std/json:Object", ptr %t66, i32 0, i32 2
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  store i64 %t71, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb20
bb17:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l50, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l50, !tbaa !24
  store i64 %t99, ptr %l47, !tbaa !24
  br label %bb20
bb20:
  %t100 = load i64, ptr %l47, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb23:
  br label %bb24
bb24:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l10, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/json:Object", ptr %t119, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l69, !tbaa !27
  %t123 = load i64, ptr %l4, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t123
  %t128 = load i32, ptr %t127, !tbaa !33
  %t130 = sext i32 %t128 to i64
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = icmp eq i64 %t132, 0
  br i1 %t134, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  %t137 = insertvalue { i32, i64 } zeroinitializer, i32 65543, 0
  store { i32, i64 } %t137, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"std/json:Object", ptr %t138, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l77, !tbaa !27
  %t142 = load i64, ptr %l11, !tbaa !24
  %t144 = sub i64 %t142, 1
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %t147, i64 %t144
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !37
  %t150 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t153 = call i1 @std_2fjson_2esameName_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, { i64, ptr } %t149, { i64, ptr } %t150)
  store i1 %t153, ptr %l82
  br label %bb28
bb28:
  %t154 = load i1, ptr %l82, !tbaa !21
  br i1 %t154, label %bb29, label %bb30
bb29:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t157 = sub i64 %t155, 1
  call void @__olang_scope_close(ptr %s5)
  %t159 = insertvalue { i32, i64 } zeroinitializer, i64 %t157, 1
  store { i32, i64 } %t159, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t160 = load i64, ptr %l4, !tbaa !24
  %t162 = add i64 %t160, 1
  %t163 = load i64, ptr %l3, !tbaa !24
  %t166 = and i64 %t162, %t163
  store i64 %t166, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l9, !tbaa !24
  br label %bb21
bb33:
  %t173 = insertvalue { i32, i64 } zeroinitializer, i32 65543, 0
  store { i32, i64 } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local %"compiler/diag:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"compiler/diag:Item"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/diag:Item", ptr %t17, i64 %t14
  %t19 = load %"compiler/diag:Item", ptr %t18
  store %"compiler/diag:Item" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/diag:Item", ptr %t60, i64 %t57
  %t62 = load %"compiler/diag:Item", ptr %t61
  store %"compiler/diag:Item" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diag:Item", ptr %rv
  ret %"compiler/diag:Item" %rr
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret ptr %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_Hc8e24fa4dba7e8fd650818e9a0171b72(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ePu_H886a66ffa23940650f82c48d9485539c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_Hc8f637dbd3c39b4e5f02c4f7fcfa329b(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2eRu_Hdae492cbfddb0b6a70eec6865333e543(ptr %v0, ptr %a0, i64 %a1)
  ret { i32, { i64, ptr } } %r
}

define dso_local %"std/prelude/text:StringBuilder" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilde_H0e2e3c0fe5ff21020d49b50eb045255d(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"std/prelude/text:StringBuilder"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"std/prelude/text:StringBuilder", ptr %t17, i64 %t14
  %t19 = load %"std/prelude/text:StringBuilder", ptr %t18
  store %"std/prelude/text:StringBuilder" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"std/prelude/text:StringBuilder", ptr %t60, i64 %t57
  %t62 = load %"std/prelude/text:StringBuilder", ptr %t61
  store %"std/prelude/text:StringBuilder" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilde_H96a31ecee6fa958f3b956bd4cf13d4ad(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/text:StringBuilder" %a1) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"std/prelude/text:StringBuilder" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"std/prelude/text:StringBuilder", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aStringB_H28de6cb3879ddd61f73081b44a30725a(ptr %v0, ptr %v1, ptr %t18, %"std/prelude/text:StringBuilder" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"std/prelude/text:StringBuilder", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"std/prelude/text:StringBuilder", ptr %t34, i64 %t29
  store %"std/prelude/text:StringBuilder" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H962a30edd485f38e7d3abb41262b569a(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aString__H5ad1091e47cf724a2eabcddfbb6c04ee(ptr %v0, ptr %t6, i64 0)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t8, i32 0, i32 7
  store i64 0, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t11, i32 0, i32 5
  store i64 0, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t14, i32 0, i32 3
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t21, i32 0, i32 2
  store i64 1, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t24, i32 0, i32 4
  store { i64, ptr } %t28, ptr %t31, !tbaa !27
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t33, i32 0, i32 4
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t41 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 6
  store i64 %t38, ptr %t41, !tbaa !24
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20compiler_2flsp_3aDoc_26__H25066e8afe29c1259412fccd96168159(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20compiler_2flsp_3aDoc_26__H5a413a3571739350f72420cc6931cd5b(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_H3a47d2b30dd068f82b18182b93098e2f(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20compiler_2flsp_3aDoc_26__H7889fbc03fc78cadb5118a469d0523e9(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_He54124e4892c254df357a8103d0ba529(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aStringB_H1a9c908708280fc99c450ab275f4d973(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aStringB_H28de6cb3879ddd61f73081b44a30725a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/text:StringBuilder" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"std/prelude/text:StringBuilder"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"std/prelude/text:StringBuilder" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"std/prelude/text:StringBuilder", ptr %l1
  store %"std/prelude/text:StringBuilder" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 1152921504606846975
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c5cd80569b3876e3_bf4a49248ce8f1ef)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 8
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"std/prelude/text:StringBuilder", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"std/prelude/text:StringBuilder", ptr %t52, i64 %t58
  store %"std/prelude/text:StringBuilder" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c5cd80569b3876e3_bf4a49248ce8f1ef)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a91071e6b75f776e_9e937877aeb9211a)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a91071e6b75f776e_9e937877aeb9211a)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_9932c5fcf7f9206d_786a753056557a99)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9932c5fcf7f9206d_786a753056557a99)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"std/prelude/text:StringBuilder", ptr %l1
  store %"std/prelude/text:StringBuilder" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 1152921504606846975
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ea126fc19927bb40_3f432d984770bb8c)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 8
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"std/prelude/text:StringBuilder", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"std/prelude/text:StringBuilder", ptr %t251, i64 %t257
  store %"std/prelude/text:StringBuilder" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_ea126fc19927bb40_3f432d984770bb8c)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aString__H5ad1091e47cf724a2eabcddfbb6c04ee(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l78 = alloca i64
  %l85 = alloca i64
  %l97 = alloca i64
  %l100 = alloca i64
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 7
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = icmp sge i64 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t14 = add i64 %t10, %t11
  store i64 %t14, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l35
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l35, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t35)
  store i64 %t37, ptr %l39
  br label %bb5
bb5:
  %t38 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t39 = load i64, ptr %l39, !tbaa !24
  %t41 = sub i64 %t39, %t38
  store i64 %t41, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp sgt i64 %t49, %t50
  br i1 %t53, label %bb6, label %bb7
bb6:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb11
bb8:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = sub i64 %t59, %t60
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = add i64 %t63, %t64
  %t69 = sub i64 %t67, 1
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = sdiv i64 %t69, %t70
  store i64 %t73, ptr %l51, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb10
bb10:
  %t75 = load i64, ptr %l51, !tbaa !24
  store i64 %t75, ptr %l48, !tbaa !24
  br label %bb11
bb11:
  %t76 = load i64, ptr %l48, !tbaa !24
  store i64 %t76, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb14:
  br label %bb15
bb15:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = mul i64 %t86, %t87
  %t93 = add i64 %t85, %t90
  store i64 %t93, ptr %l11, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t95, i64 %t96)
  store { i64, ptr } %t99, ptr %l71
  br label %bb16
bb16:
  %t100 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t100, ptr %l12, !tbaa !27
  %t101 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  store i64 %t102, ptr %l73, !tbaa !24
  %t104 = load i64, ptr %l73, !tbaa !24
  %t105 = load i64, ptr %l73, !tbaa !24
  %t106 = shl i64 %t101, %t105
  store i64 %t106, ptr %l13, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t109 = load i64, ptr %l4, !tbaa !24
  %t112 = icmp eq i64 %t108, %t109
  br i1 %t112, label %bb17, label %bb18
bb17:
  %t114 = load i64, ptr %l2, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = sub i64 %t114, %t115
  store i64 %t118, ptr %l78, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb19
bb19:
  %t120 = load i64, ptr %l78, !tbaa !24
  store i64 %t120, ptr %l14, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l5, !tbaa !24
  %t125 = icmp eq i64 %t121, %t122
  br i1 %t125, label %bb20, label %bb21
bb20:
  %t127 = load i64, ptr %l3, !tbaa !24
  %t128 = load i64, ptr %l13, !tbaa !24
  %t131 = sub i64 %t127, %t128
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l85, !tbaa !24
  br label %bb22
bb21:
  %t135 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l85, !tbaa !24
  br label %bb22
bb22:
  %t139 = load i64, ptr %l85, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  store i64 %t140, ptr %l16, !tbaa !24
  store i64 %t139, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp sgt i64 %t144, %t145
  br i1 %t148, label %bb23, label %bb24
bb23:
  %t150 = load i64, ptr %l18, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb28
bb25:
  %t154 = load i64, ptr %l17, !tbaa !24
  %t155 = load i64, ptr %l16, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l18, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l18, !tbaa !24
  %t168 = sdiv i64 %t164, %t165
  store i64 %t168, ptr %l100, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb27
bb27:
  %t170 = load i64, ptr %l100, !tbaa !24
  store i64 %t170, ptr %l97, !tbaa !24
  br label %bb28
bb28:
  %t171 = load i64, ptr %l97, !tbaa !24
  store i64 %t171, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t172 = load i64, ptr %l20, !tbaa !24
  %t173 = load i64, ptr %l19, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb31:
  br label %bb32
bb32:
  %t180 = load i64, ptr %l16, !tbaa !24
  %t181 = load i64, ptr %l20, !tbaa !24
  %t182 = load i64, ptr %l18, !tbaa !24
  %t185 = mul i64 %t181, %t182
  %t188 = add i64 %t180, %t185
  %t190 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t190, ptr %l118, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %t194, i64 %t188
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !37
  store { i64, ptr } %t196, ptr %l120, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  %t197 = load i64, ptr %l20, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l20, !tbaa !24
  br label %bb29
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb12
bb36:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilder_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cmut_20compiler_2flsp_3aDoc_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aStringBuilder_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 0)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l14, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t58, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i64, ptr %t65, i64 %t53
  %t67 = load i64, ptr %t66, !tbaa !34
  %t71 = icmp eq i64 %t67, %a1
  br i1 %t71, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb7
bb15:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l14, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t58, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i64, ptr %t65, i64 %t62
  %t67 = load i64, ptr %t66, !tbaa !34
  %t71 = icmp eq i64 %t67, %a1
  br i1 %t71, label %bb11, label %bb12
bb11:
  %t73 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  %t75 = insertvalue { i32, i64 } zeroinitializer, i64 %t73, 1
  store { i32, i64 } %t75, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l6, !tbaa !24
  br label %bb7
bb15:
  %t81 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eInsert_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca ptr
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp slt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = icmp sgt i64 %t10, %t14
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i32 65538, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t33 = icmp eq i64 %t24, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t36, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t42 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI64_3e_2eroom_3cI64_3e(ptr %v0, ptr %t35, i64 %t41, i64 %t42)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l1, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t59, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l33, !tbaa !27
  %t63 = load i64, ptr %l4, !tbaa !24
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t64, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l36, !tbaa !27
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t72 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i64, ptr %t73, i64 %t70
  %t75 = load i64, ptr %t74, !tbaa !34
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i64, ptr %t79, i64 %t63
  store i64 %t75, ptr %t80, !tbaa !34
  %t81 = load i64, ptr %l4, !tbaa !24
  %t83 = sub i64 %t81, 1
  store i64 %t83, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  br label %bb11
bb16:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t85, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l43, !tbaa !27
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i64, ptr %t94, i64 %t89
  store i64 %t90, ptr %t95, !tbaa !34
  %t96 = load ptr, ptr %l3, !tbaa !29
  store ptr %t96, ptr %l46, !tbaa !29
  %t97 = load ptr, ptr %l46, !tbaa !29
  %t98 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t97, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = add i64 %t99, 1
  %t103 = load ptr, ptr %l46, !tbaa !29
  %t104 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t103, i32 0, i32 1
  store i64 %t101, ptr %t104, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTakeAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %rv
  br label %ret
bb3:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l11 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %t1, i64 %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t12)
  store i32 %t17, ptr %l11
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb6, label %ok.19
ok.19:
  br label %bb5
bb5:
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_6aedc85f0c11dafa_37647e3d146f545e)
  unreachable
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTakeAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i1
  %l21 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l62 = alloca ptr
  %s3 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp slt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = icmp sge i64 %t10, %t14
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i64, ptr %t29, i64 %t26
  %t31 = load i64, ptr %t30, !tbaa !34
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = sub i64 %t38, 1
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb9:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l34, !tbaa !24
  store i64 %t68, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t69 = load i64, ptr %l31, !tbaa !24
  store i64 %t69, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l9, !tbaa !24
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t88, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l9, !tbaa !24
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t93, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l56, !tbaa !27
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = add i64 %t97, 1
  %t101 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i64, ptr %t102, i64 %t99
  %t104 = load i64, ptr %t103, !tbaa !34
  %t107 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i64, ptr %t108, i64 %t92
  store i64 %t104, ptr %t109, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t114 = load ptr, ptr %l2, !tbaa !29
  store ptr %t114, ptr %l62, !tbaa !29
  %t115 = load ptr, ptr %l62, !tbaa !29
  %t116 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t115, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = sub i64 %t117, 1
  %t121 = load ptr, ptr %l62, !tbaa !29
  %t122 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t121, i32 0, i32 1
  store i64 %t119, ptr %t122, !tbaa !24
  %t123 = load i64, ptr %l3, !tbaa !24
  %t125 = insertvalue { i32, i64 } zeroinitializer, i64 %t123, 1
  store { i32, i64 } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %s3 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l29, !tbaa !24
  store i64 %t55, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l48, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t73
  %t84 = load i64, ptr %t83, !tbaa !34
  store i64 %t84, ptr %l50, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
declare void @__olang_check_failed(ptr)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2estd_2fprelude_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2ehighBit(i64 %a0)
@G_2estd_2fprelude_2flist_2efirstChunkLog = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ePu_H886a66ffa23940650f82c48d9485539c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2eRu_Hdae492cbfddb0b6a70eec6865333e543(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_H3a47d2b30dd068f82b18182b93098e2f(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_He54124e4892c254df357a8103d0ba529(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c5cd80569b3876e3_bf4a49248ce8f1ef = external constant [0 x i8]
@olang_loc_a91071e6b75f776e_9e937877aeb9211a = external constant [0 x i8]
@olang_loc_9932c5fcf7f9206d_786a753056557a99 = external constant [0 x i8]
@olang_loc_ea126fc19927bb40_3f432d984770bb8c = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU64_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cU64_3e_2ector(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI64_3e_2eroom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_6aedc85f0c11dafa_37647e3d146f545e = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
