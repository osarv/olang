; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_4831fd819d5e12f9_2de476e8196a26d = weak_odr constant [47 x i8] c"compiler/token.olang:128: unreachable reached\0A\00"
@olang_loc_68bd4249b8d73c4b_5d7571019b0b81ef = weak_odr constant [47 x i8] c"compiler/token.olang:234: unreachable reached\0A\00"
@olang_loc_8335b6838977a45d_7f00c755aebb82a1 = weak_odr constant [47 x i8] c"compiler/token.olang:139: unreachable reached\0A\00"
@olang_loc_a871279a946ea0ab_b38731ddf3b3cb1f = weak_odr constant [47 x i8] c"compiler/token.olang:252: unreachable reached\0A\00"
