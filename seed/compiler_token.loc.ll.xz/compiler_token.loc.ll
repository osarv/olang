; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_4831fd819d5e12f9_2de476e8196a26d = weak_odr constant [47 x i8] c"compiler/token.olang:148: unreachable reached\0A\00"
@olang_loc_68bd4249b8d73c4b_5d7571019b0b81ef = weak_odr constant [47 x i8] c"compiler/token.olang:276: unreachable reached\0A\00"
@olang_loc_8335b6838977a45d_7f00c755aebb82a1 = weak_odr constant [47 x i8] c"compiler/token.olang:161: unreachable reached\0A\00"
@olang_loc_a8f8505ea607fe55_8ebbaef23bfb5239 = weak_odr constant [47 x i8] c"compiler/token.olang:294: unreachable reached\0A\00"
