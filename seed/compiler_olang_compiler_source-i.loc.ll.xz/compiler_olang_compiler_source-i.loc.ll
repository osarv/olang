; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_382b00697b13583_41c3ef5ab0edf3f7 = weak_odr constant [53 x i8] c"std/prelude/map.olang:43: array length out of range\0A\00"
@olang_loc_6fcc548405dda386_83bd6362e8bb628a = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
