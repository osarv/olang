; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_261c7c2ce11ae094_4cf5301c06c88970 = weak_odr constant [53 x i8] c"std/prelude/map.olang:97: slice bounds out of range\0A\00"
@olang_loc_4f069b411daade01_63fe3b58ab41eb4d = weak_odr constant [53 x i8] c"std/prelude/map.olang:94: slice bounds out of range\0A\00"
@olang_loc_a2c9391612ab2f46_82cfd77014e5ab12 = weak_odr constant [54 x i8] c"std/prelude/map.olang:103: array length out of range\0A\00"
@olang_loc_cb06226da9b2fa22_33b702da20951dc6 = weak_odr constant [54 x i8] c"std/prelude/map.olang:114: array length out of range\0A\00"
