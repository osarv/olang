; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33" = type { i64, { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"<pthread.h>:pthread_mutex_t", %"<pthread.h>:pthread_cond_t", %"<pthread.h>:pthread_cond_t" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"<pthread.h>:pthread_mutex_t" = type { [5 x i64] }
%"<pthread.h>:pthread_cond_t" = type { [6 x i64] }
define dso_local i32 @std_2fchan_2eSendUntil_3cI32_3e(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i32
  %l13 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l31 = alloca i64
  %l40 = alloca i32
  %l44 = alloca i64
  %l47 = alloca i1
  %l52 = alloca i1
  %l58 = alloca i1
  %l64 = alloca i32
  %l66 = alloca i32
  %l71 = alloca i64
  %l79 = alloca i1
  %l86 = alloca i32
  %l90 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t1, i32 0, i32 12
  %t5 = call i32 @pthread_mutex_lock(ptr %t3)
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t6, i32 0, i32 4
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t18, i32 0, i32 8
  %t21 = load i1, ptr %t20, !tbaa !21
  %t23 = xor i1 %t21, true
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l13, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  br label %bb24
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v1, ptr %t28)
  store i1 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_2eunpark_3cI32_3e(ptr %v0, ptr %t32, i64 %t33)
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t36, i32 0, i32 12
  %t40 = call i32 @pthread_mutex_unlock(ptr %t38)
  store i32 %t40, ptr %l24
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v1, ptr %t41)
  store i32 %t43, ptr %l26
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb15, label %ok.45, !prof !99
ok.45:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t46 = load i32, ptr %l26, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  store i32 %t54, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = icmp slt i64 %t56, 0
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call i64 @std_2fchan_2epark_3cI32_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l31
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t63 = load i64, ptr %l31, !tbaa !24
  store i64 %t63, ptr %l3, !tbaa !24
  br label %bb23
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_2esleep_3cI32_3e(ptr %v0, ptr %v1, ptr %t64, ptr %t65, i64 %t66)
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb2
bb24:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t70, i32 0, i32 8
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_2eunpark_3cI32_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l40
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb30, label %ok.83, !prof !99
ok.83:
  br label %bb29
bb29:
  br label %bb31
bb30:
  %t84 = load i32, ptr %l40, !tbaa !23
  %t85 = lshr i32 %t84, 16
  %t86 = and i32 %t84, 65535
  %t87 = icmp eq i32 %t85, 1
  %t88 = select i1 %t87, i32 2, i32 0
  %t89 = icmp eq i32 %t84, 0
  %t90 = shl i32 %t88, 16
  %t91 = or i32 %t90, %t86
  %t92 = select i1 %t89, i32 0, i32 %t91
  store i32 %t92, ptr %rv
  br label %ret
bb31:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i64 @std_2fchan_2eplace_3cI32_3e(ptr %v0, ptr %t94, i32 %a1)
  store i64 %t98, ptr %l44
  br label %bb32
bb32:
  %t99 = load i64, ptr %l44, !tbaa !24
  store i64 %t99, ptr %l4, !tbaa !24
  br label %bb33
bb33:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t100, i32 0, i32 5
  %t103 = load i1, ptr %t102, !tbaa !21
  br i1 %t103, label %bb34, label %bb35
bb34:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t105, i32 0, i32 7
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load i64, ptr %l4, !tbaa !24
  %t112 = icmp sle i64 %t108, %t109
  store i1 %t112, ptr %l47, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb36
bb36:
  %t114 = load i1, ptr %l47, !tbaa !21
  br i1 %t114, label %bb37, label %bb38
bb37:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t115, i32 0, i32 8
  %t118 = load i1, ptr %t117, !tbaa !21
  %t120 = xor i1 %t118, true
  store i1 %t120, ptr %l52, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb39
bb39:
  %t122 = load i1, ptr %l52, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb40, label %bb41
bb40:
  br label %bb59
bb41:
  br label %bb42
bb42:
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v1, ptr %t125)
  store i1 %t127, ptr %l58
  br label %bb43
bb43:
  %t128 = load i1, ptr %l58, !tbaa !21
  br i1 %t128, label %bb44, label %bb45
bb44:
  %t129 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %t129)
  br label %bb46
bb45:
  br label %bb52
bb46:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_2eunpark_3cI32_3e(ptr %v0, ptr %t131, i64 %t132)
  br label %bb47
bb47:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t135, i32 0, i32 12
  %t139 = call i32 @pthread_mutex_unlock(ptr %t137)
  store i32 %t139, ptr %l64
  br label %bb48
bb48:
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t142 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v1, ptr %t140)
  store i32 %t142, ptr %l66
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb50, label %ok.144, !prof !99
ok.144:
  br label %bb49
bb49:
  br label %bb51
bb50:
  %t145 = load i32, ptr %l66, !tbaa !23
  %t146 = lshr i32 %t145, 16
  %t147 = and i32 %t145, 65535
  %t148 = icmp eq i32 %t146, 1
  %t149 = select i1 %t148, i32 1, i32 0
  %t150 = icmp eq i32 %t145, 0
  %t151 = shl i32 %t149, 16
  %t152 = or i32 %t151, %t147
  %t153 = select i1 %t150, i32 0, i32 %t152
  store i32 %t153, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t155 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp slt i64 %t155, 0
  br i1 %t157, label %bb53, label %bb54
bb53:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call i64 @std_2fchan_2epark_3cI32_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l71
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t162 = load i64, ptr %l71, !tbaa !24
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb58
bb56:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t165 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_2esleep_3cI32_3e(ptr %v0, ptr %v1, ptr %t163, ptr %t164, i64 %t165)
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb33
bb59:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_2eunpark_3cI32_3e(ptr %v0, ptr %t169, i64 %t170)
  br label %bb60
bb60:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t173, i32 0, i32 5
  %t176 = load i1, ptr %t175, !tbaa !21
  br i1 %t176, label %bb61, label %bb62
bb61:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t178, i32 0, i32 7
  %t181 = load i64, ptr %t180, !tbaa !24
  %t182 = load i64, ptr %l4, !tbaa !24
  %t185 = icmp sle i64 %t181, %t182
  store i1 %t185, ptr %l79, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb63
bb63:
  %t187 = load i1, ptr %l79, !tbaa !21
  br i1 %t187, label %bb64, label %bb65
bb64:
  %t188 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %t188)
  br label %bb66
bb65:
  br label %bb70
bb66:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t190)
  store i32 %t192, ptr %l86
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb68, label %ok.194, !prof !99
ok.194:
  br label %bb67
bb67:
  br label %bb69
bb68:
  %t195 = load i32, ptr %l86, !tbaa !23
  %t196 = lshr i32 %t195, 16
  %t197 = and i32 %t195, 65535
  %t198 = icmp eq i32 %t196, 1
  %t199 = select i1 %t198, i32 2, i32 0
  %t200 = icmp eq i32 %t195, 0
  %t201 = shl i32 %t199, 16
  %t202 = or i32 %t201, %t197
  %t203 = select i1 %t200, i32 0, i32 %t202
  store i32 %t203, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", ptr %t205, i32 0, i32 12
  %t209 = call i32 @pthread_mutex_unlock(ptr %t207)
  store i32 %t209, ptr %l90
  br label %bb71
bb71:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

declare i32 @pthread_mutex_lock(ptr)
declare i32 @pthread_mutex_unlock(ptr)
declare i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0)
declare void @std_2fchan_2eunpark_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v0, ptr %a0)
declare i64 @std_2fchan_2epark_3cI32_3e(ptr %v0, ptr %a0)
declare void @std_2fchan_2esleep_3cI32_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fchan_2eplace_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
