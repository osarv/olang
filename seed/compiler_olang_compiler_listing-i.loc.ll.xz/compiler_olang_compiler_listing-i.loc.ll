; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_2539e868f30e214a_bfbc5158cbb5f35e = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
