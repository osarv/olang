; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_206e06ac8bdfa97e_79140d8154c21c02 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_7a19c027c91c8b56_ca3ea7f284234e72 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:284: array length out of range\0A\00"
@olang_loc_c16ee5e939ffe06b_222ab0afb9a78267 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:283: array length out of range\0A\00"
