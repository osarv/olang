; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:landing" = type { i64, i64, %"compiler/source:Span", i32, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/check:inPlaceRead" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span" }
define dso_local i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 31, ptr %l1
  br label %bb35
bb5:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t8, ptr %l6
  br label %bb6
bb6:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 32, ptr %l1
  br label %bb35
bb10:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t13, ptr %l9
  br label %bb11
bb11:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i32 33, ptr %l1
  br label %bb35
bb15:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t18, ptr %l12
  br label %bb16
bb16:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 34, ptr %l1
  br label %bb35
bb20:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t23, ptr %l15
  br label %bb21
bb21:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 35, ptr %l1
  br label %bb35
bb25:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t28, ptr %l18
  br label %bb26
bb26:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i32 36, ptr %l1
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i32 29, ptr %l1
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a3fc486149a2dc5d_17491af4361141b9)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i32, ptr %l1, !range !{i32 0, i32 52}
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb50
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l18
  br label %bb12
bb12:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l6, !tbaa !21
  br label %bb50
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t44)
  store i1 %t46, ptr %l26
  br label %bb19
bb19:
  %t47 = load i1, ptr %l26, !tbaa !21
  store i1 %t47, ptr %l6, !tbaa !21
  br label %bb50
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb21, label %bb22
bb21:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 8}
  %t55 = icmp eq i64 %t53, 4
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Elem", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l35
  br label %bb26
bb26:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb27, label %bb28
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Elem", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l39
  br label %bb29
bb28:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb30
bb29:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t77 = load i1, ptr %l36, !tbaa !21
  store i1 %t77, ptr %l6, !tbaa !21
  br label %bb50
bb31:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb32, label %bb33
bb32:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb33
bb33:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Payload", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t96)
  store i1 %t98, ptr %l48
  br label %bb37
bb37:
  %t99 = load i1, ptr %l48, !tbaa !21
  store i1 %t99, ptr %l6, !tbaa !21
  br label %bb50
bb38:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 8}
  %t107 = icmp eq i64 %t105, 6
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb40
bb40:
  %t108 = load i1, ptr %l50, !tbaa !21
  br i1 %t108, label %bb41, label %bb42
bb41:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t115)
  store i1 %t117, ptr %l56
  br label %bb44
bb44:
  %t118 = load i1, ptr %l56, !tbaa !21
  store i1 %t118, ptr %l6, !tbaa !21
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8)
  unreachable
bb50:
  %t119 = load i1, ptr %l6, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l17 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l7, !tbaa !29
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l9
  %t11 = load %"compiler/source:Span", ptr %l11
  %t12 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t9, %"compiler/source:Span" %t10, %"compiler/source:Span" %t11, i64 2)
  store %"compiler/source:Span" %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t13)
  store i32 %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l12
  %t20 = load i32, ptr %l15, !tbaa !23
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v3, ptr %t18, %"compiler/source:Span" %t19, i32 %t20, ptr %t17)
  store i32 %t22, ptr %l17
  br label %bb5
bb5:
  %t23 = load i32, ptr %l17, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t28 = icmp eq i32 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t30, %"compiler/source:Span" %t31)
  store ptr %t34, ptr %l23
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load ptr, ptr %l23, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l25
  %t38 = load ptr, ptr %l2, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  store i32 %t39, ptr %l27, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l30
  br label %bb10
bb10:
  %t44 = mul i64 1, 4
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 0
  store i32 %t48, ptr %t51, !tbaa !33
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l34
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l36
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l34
  %t61 = load %"compiler/source:Span", ptr %l36
  %t62 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, %"compiler/source:Span" %t61, i64 2)
  store %"compiler/source:Span" %t62, ptr %l37
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l28, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t65 = load %"compiler/source:Span", ptr %l37
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t63, { i64, ptr } %t64, %"compiler/source:Span" %t65, i1 true)
  store i32 %t66, ptr %l38
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l24, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l25
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t70 = load i32, ptr %l27, !tbaa !23
  %t71 = load i32, ptr %l38, !range !{i32 0, i32 3}
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v4, ptr %t67, %"compiler/source:Span" %t68, ptr %t69, i32 %t70, i32 %t71)
  store ptr %t72, ptr %l39
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load ptr, ptr %l39, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb10, label %bb11
bb10:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb12, label %bb13
bb12:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb15
bb15:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %rv
  br label %ret
bb16:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb17, label %bb18
bb17:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 5
  store i1 %t46, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Promote", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t62, ptr %l35
  br label %bb22
bb22:
  %t63 = load i1, ptr %l35, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 6
  store i1 %t71, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l37, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 0
  %t77 = load %"compiler/source:Span", ptr %t76
  store %"compiler/source:Span" %t77, ptr %l4
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Call", ptr %t85, i32 0, i32 1
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Call", ptr %t94, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l52
  br label %bb31
bb30:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb33
bb31:
  %t104 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t104, ptr %l54
  %t107 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l52, ptr %l54)
  store i1 %t107, ptr %l56
  br label %bb32
bb32:
  %t108 = load i1, ptr %l56, !tbaa !21
  store i1 %t108, ptr %l48, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l48, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
bb34:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t111 = load ptr, ptr %l57, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t114 = load ptr, ptr %l57, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 18}
  %t117 = icmp eq i64 %t115, 14
  store i1 %t117, ptr %l58, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l58, !tbaa !21
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Try", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l6, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Try", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t134, ptr %t138)
  store i1 %t141, ptr %l71
  br label %bb42
bb41:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb43
bb42:
  %t142 = load i1, ptr %l71, !tbaa !21
  store i1 %t142, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t143 = load i1, ptr %l67, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
bb44:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t145 = load ptr, ptr %l72, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb45, label %bb46
bb45:
  %t148 = load ptr, ptr %l72, !tbaa !29
  %t149 = load i64, ptr %t148, !range !{i64 0, i64 18}
  %t151 = icmp eq i64 %t149, 11
  store i1 %t151, ptr %l73, !tbaa !21
  br label %bb46
bb46:
  %t152 = load i1, ptr %l73, !tbaa !21
  br i1 %t152, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t154 = load ptr, ptr %l76, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb49, label %bb50
bb49:
  %t157 = load ptr, ptr %l76, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 18}
  %t160 = icmp eq i64 %t158, 13
  store i1 %t160, ptr %l77, !tbaa !21
  br label %bb50
bb50:
  %t161 = load i1, ptr %l77, !tbaa !21
  br i1 %t161, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t166 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %t162, ptr %t163)
  store i1 %t166, ptr %l82
  br label %bb54
bb54:
  %t167 = load i1, ptr %l82, !tbaa !21
  store i1 %t167, ptr %rv
  br label %ret
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i1 false, ptr %rv
  br label %ret
bb59:
  call void @__olang_check_failed(ptr @olang_loc_2fb1f9f5dda04b10_a3bd6c7ca1760a54)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:b5aWalk", ptr %t3, i32 0, i32 2
  %t9 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t5, i64 %t1)
  store i1 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 2
  %t16 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t15, i64 %t16)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 %a2, %"compiler/source:Span" %a3)
  store { i64, i64, i64 } %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t14, ptr %l5
  %t15 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %a1)
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v2, ptr %t28, i64 %t29, i64 %t30, i64 %t31, i64 %t32)
  store ptr %t38, ptr %l26
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l26, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:ownerAt"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca %"compiler/check:ownerAt"
  %l25 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t26 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store %"compiler/check:ownerAt" %t26, ptr %l15
  br label %bb6
bb6:
  %t27 = load %"compiler/check:ownerAt", ptr %l15
  store %"compiler/check:ownerAt" %t27, ptr %l4
  %t28 = getelementptr %"compiler/check:ownerAt", ptr %l4, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = getelementptr %"compiler/check:ownerAt", ptr %l4, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = getelementptr %"compiler/check:ownerAt", ptr %l4, i32 0, i32 1
  %t44 = load i1, ptr %t43, !tbaa !21
  %t49 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t39, i32 %t41, i32 %t42, i1 %t44)
  store i64 %t49, ptr %l25
  br label %bb10
bb10:
  %t50 = load i64, ptr %l25, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_5d13064994ae0ba3_8fd3ca0506e03b5f)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/check:ownerAt"
  %l6 = alloca i64
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca %"compiler/check:ownerAt"
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l34 = alloca i64
  %l43 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i32
  %l77 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l89 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i64
  %l98 = alloca ptr
  %l106 = alloca ptr
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t123 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t1, ptr %a3)
  store %"compiler/check:ownerAt" %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load %"compiler/check:ownerAt", ptr %l15
  store %"compiler/check:ownerAt" %t6, ptr %l5
  %t7 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t12 = icmp eq i32 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t15, i32 %t17)
  store i1 %t20, ptr %l22
  br label %bb5
bb5:
  %t21 = load i1, ptr %l22, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load i32, ptr %l4, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t22, i32 %t24, i32 %t25)
  store i1 %t29, ptr %l27
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i1, ptr %l27, !tbaa !21
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l23, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load i32, ptr %l4, !tbaa !23
  %t40 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 1
  %t41 = load i1, ptr %t40, !tbaa !21
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t36, i32 %t38, i32 %t39, i1 %t41)
  store i64 %t46, ptr %l34
  br label %bb13
bb13:
  %t47 = load i64, ptr %l34, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp slt i64 %t48, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load %"compiler/source:Span", ptr %l2
  %t56 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %t53, i64 %t54, %"compiler/source:Span" %t55, i32 %t57)
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l43, !tbaa !29
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t66)
  store i64 %t68, ptr %l45
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = load i64, ptr %l45, !tbaa !24
  %t71 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t69, i64 %t70)
  store i64 %t71, ptr %l46
  br label %bb19
bb19:
  %t72 = load i64, ptr %l46, !tbaa !24
  store i64 %t72, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp eq i64 %t73, 0
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l49, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t78, ptr %l50
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l51, !tbaa !24
  %t80 = icmp sge i64 0, 0
  br i1 %t80, label %bb22, label %bb23
bb21:
  br label %bb27
bb22:
  %t82 = icmp sle i64 0, 2305843009213693951
  br i1 %t82, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_82b0d2a61edf3c68_78216e4ccea776dc)
  unreachable
bb24:
  %t84 = mul i64 0, 4
  %t85 = insertvalue { i64, ptr } undef, i64 0, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l50
  %t89 = load i64, ptr %l51, !tbaa !24
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v2, ptr %v2, ptr %t87, %"compiler/source:Span" %t88, i64 %t89, { i64, ptr } %t86)
  store ptr %t91, ptr %l55
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_82b0d2a61edf3c68_78216e4ccea776dc)
  unreachable
bb26:
  %t92 = load ptr, ptr %l55, !tbaa !29
  store ptr %t92, ptr %rv
  br label %ret
bb27:
  %t94 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 1
  %t95 = load i1, ptr %t94, !tbaa !21
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb28, label %bb29
bb28:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerBinding(ptr %v0, ptr %v2, ptr %t102, i64 %t103, i32 %t105)
  store { i64, ptr } %t109, ptr %l64
  br label %bb30
bb29:
  %t110 = load i64, ptr %l7, !tbaa !24
  store i64 %t110, ptr %l65, !tbaa !24
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t111, ptr %l66, !tbaa !23
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  br i1 %t113, label %bb31, label %bb32
bb30:
  %t115 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t115, ptr %l59, !tbaa !27
  br label %bb35
bb31:
  %t116 = load i64, ptr %l65, !tbaa !24
  %t117 = icmp sle i64 %t116, 2305843009213693951
  br i1 %t117, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9)
  unreachable
bb33:
  %t119 = load i64, ptr %l65, !tbaa !24
  %t120 = mul i64 %t119, 4
  %t121 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t120)
  %t122 = load i32, ptr %l66, !tbaa !23
  store i64 0, ptr %t123
  br label %fill.124
fill.124:
  %t127 = load i64, ptr %t123
  %t128 = icmp slt i64 %t127, %t119
  br i1 %t128, label %fillb.125, label %filld.126
fillb.125:
  %t129 = getelementptr i32, ptr %t121, i64 %t127
  store i32 %t122, ptr %t129
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %t123
  br label %fill.124
filld.126:
  %t131 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t121, 1
  store { i64, ptr } %t132, ptr %l59, !tbaa !27
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9)
  unreachable
bb35:
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t134, ptr %lp8
  %t135 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t136 = load ptr, ptr %lp8
  store { i64, ptr } %t135, ptr %t136, !tbaa !27
  %t137 = load ptr, ptr %lp8
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l11, !tbaa !24
  br label %bb36
bb36:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb37, label %bb38
bb37:
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t152 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t152, ptr %l77, !tbaa !27
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t153
  %t158 = load i32, ptr %t157, !tbaa !33
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t164 = icmp eq i32 %t158, %t161
  br i1 %t164, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t167, ptr %l84
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l85, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load i64, ptr %l6, !tbaa !24
  %t176 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s7, ptr %t172, i64 %t173)
  store ptr %t176, ptr %l89
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t177 = load ptr, ptr %l89, !tbaa !29
  %t179 = getelementptr %"compiler/ast:Func", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %t179, !tbaa !23
  %t181 = load ptr, ptr %l85, !tbaa !29
  %t183 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t181, i32 %t180)
  store { i64, ptr } %t183, ptr %l92
  br label %bb43
bb43:
  %t184 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t192 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderNotValue(ptr %s7, ptr %s7, { i64, ptr } %t190)
  store %"compiler/diagmsg:Msg" %t192, ptr %l94
  br label %bb44
bb44:
  %t193 = load ptr, ptr %l83, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l84
  %t195 = load %"compiler/diagmsg:Msg", ptr %l94
  %t196 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t193, %"compiler/source:Span" %t194, %"compiler/diagmsg:Msg" %t195)
  store i64 %t196, ptr %l95
  br label %bb45
bb45:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t201 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t197, %"compiler/source:Span" %a1)
  store ptr %t201, ptr %l98
  br label %bb46
bb46:
  %t202 = load ptr, ptr %l98, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  store ptr %t202, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t204 = load i64, ptr %l10, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l10, !tbaa !24
  br label %bb36
bb49:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l2
  %t210 = load i64, ptr %l6, !tbaa !24
  %t211 = load ptr, ptr %lp8
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v2, ptr %v2, ptr %t208, %"compiler/source:Span" %t209, i64 %t210, { i64, ptr } %t212)
  store ptr %t217, ptr %l106
  br label %bb50
bb50:
  %t218 = load ptr, ptr %l106, !tbaa !29
  store ptr %t218, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l64 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i32
  %l72 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l92 = alloca i32
  %l105 = alloca i1
  %l107 = alloca i1
  %l112 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l126 = alloca %"compiler/typed:Local"
  %l127 = alloca i32
  %l134 = alloca ptr
  %l137 = alloca i32
  %l141 = alloca %"compiler/typed:Capture"
  %l145 = alloca i1
  %l146 = alloca i1
  %l151 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t169 = alloca { i64, [5 x i64] }, align 8
  %t192 = alloca { i64, [5 x i64] }, align 8
  %t239 = alloca { i64, [1 x i64] }, align 8
  %t306 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 19
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 19
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 14
  store ptr %t56, ptr %l40, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 16
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 19
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t59, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t71, i64 %t70)
  store ptr %t73, ptr %l48
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l52
  br label %bb18
bb18:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load i32, ptr %l7, !tbaa !23
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t84, 0
  %t95 = insertvalue { %"compiler/source:Span", i32, i32 } %t93, i32 %t85, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, i32 } %t95, i32 %t88, 2
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %l8, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l64
  br label %bb19
bb19:
  %t110 = load i1, ptr %l64, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l7, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l69
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb31
bb22:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t119 = load i32, ptr %l69, !tbaa !23
  %t121 = icmp ne i32 %t119, %t118
  br i1 %t121, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb26
bb24:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load i32, ptr %l7, !tbaa !23
  %t130 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t130, ptr %l76
  br label %bb25
bb25:
  %t131 = load i1, ptr %l76, !tbaa !21
  store i1 %t131, ptr %l72, !tbaa !21
  br label %bb26
bb26:
  %t132 = load i1, ptr %l72, !tbaa !21
  br i1 %t132, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb30
bb28:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l7, !tbaa !23
  %t142 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t138, i32 %t139)
  store i1 %t142, ptr %l82
  br label %bb29
bb29:
  %t143 = load i1, ptr %l82, !tbaa !21
  store i1 %t143, ptr %l77, !tbaa !21
  br label %bb30
bb30:
  %t144 = load i1, ptr %l77, !tbaa !21
  store i1 %t144, ptr %l66, !tbaa !21
  br label %bb31
bb31:
  %t145 = load i1, ptr %l66, !tbaa !21
  br i1 %t145, label %bb32, label %bb33
bb32:
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/check:frame", ptr %t146, i32 0, i32 20
  %t149 = load i1, ptr %t148, !tbaa !21
  %t151 = xor i1 %t149, true
  store i1 %t151, ptr %l83, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb34
bb34:
  %t153 = load i1, ptr %l83, !tbaa !21
  br i1 %t153, label %bb35, label %bb36
bb35:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l7, !tbaa !23
  %t161 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t159, i32 %t160, i64 %t161)
  store i32 %t165, ptr %l92
  br label %bb37
bb36:
  %t166 = load %"compiler/source:Span", ptr %l3
  %t167 = load i32, ptr %l7, !tbaa !23
  %t168 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 0
  store i64 2, ptr %t170
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t166, 0
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t172, i32 %t167, 1
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t174, ptr %t168, 2
  %t177 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t176, i32 -1, 3
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t177, ptr %t178
  %t179 = load { i64, [5 x i64] }, ptr %t169
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t179, ptr %t181
  store ptr %t181, ptr %l10, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l7, !tbaa !23
  %t187 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t183, i32 %t184)
  store i1 %t187, ptr %l105
  br label %bb38
bb37:
  %t188 = load i32, ptr %l92, !tbaa !23
  store i32 %t188, ptr %l9, !tbaa !23
  %t189 = load %"compiler/source:Span", ptr %l3
  %t190 = load i32, ptr %l9, !tbaa !23
  %t191 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 0
  store i64 3, ptr %t193
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t189, 0
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, i32 %t190, 1
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } %t197, ptr %t191, 2
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t199, ptr %t200
  %t201 = load { i64, [5 x i64] }, ptr %t192
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t201, ptr %t203
  store ptr %t203, ptr %l10, !tbaa !29
  br label %bb47
bb38:
  %t205 = load i1, ptr %l105, !tbaa !21
  %t206 = xor i1 %t205, true
  br i1 %t206, label %bb39, label %bb40
bb39:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l7, !tbaa !23
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t213, i32 %t214)
  store i1 %t217, ptr %l112
  br label %bb41
bb40:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb42
bb41:
  %t218 = load i1, ptr %l112, !tbaa !21
  store i1 %t218, ptr %l107, !tbaa !21
  br label %bb42
bb42:
  %t219 = load i1, ptr %l107, !tbaa !21
  br i1 %t219, label %bb43, label %bb44
bb43:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t220, i32 %t221, i64 0)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 14
  %t227 = load ptr, ptr %l4, !tbaa !29
  %t229 = getelementptr %"compiler/check:frame", ptr %t227, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  %t233 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t226, i64 %t230)
  store ptr %t233, ptr %l119
  br label %bb48
bb48:
  %t234 = load ptr, ptr %l119, !tbaa !29
  store ptr %t234, ptr %l11, !tbaa !29
  %t235 = load ptr, ptr %l11, !tbaa !29
  store ptr %t235, ptr %l120, !tbaa !29
  %t236 = load i32, ptr %l2, !tbaa !23
  %t237 = load %"compiler/source:Span", ptr %l3
  %t238 = load i32, ptr %l9, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [1 x i64] }, ptr %t239, i32 0, i32 0
  store i64 4, ptr %t240
  %t241 = load { i64, [1 x i64] }, ptr %t239
  %t247 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t236, %"compiler/source:Span" %t237, i32 %t238, i32 0, i32 5, { i64, [1 x i64] } %t241)
  store %"compiler/typed:Local" %t247, ptr %l126
  br label %bb49
bb49:
  %t248 = load ptr, ptr %l120, !tbaa !29
  %t249 = load %"compiler/typed:Local", ptr %l126
  %t250 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t248, %"compiler/typed:Local" %t249)
  store i32 %t250, ptr %l127
  br label %bb50
bb50:
  %t251 = load i32, ptr %l127, !tbaa !23
  %t252 = sext i32 %t251 to i64
  store i64 %t252, ptr %l12, !tbaa !24
  %t254 = load ptr, ptr %l4, !tbaa !29
  %t256 = getelementptr %"compiler/check:frame", ptr %t254, i32 0, i32 8
  %t257 = load i32, ptr %l2, !tbaa !23
  %t258 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t256, i32 %t257, i64 %t258)
  br label %bb51
bb51:
  %t262 = load ptr, ptr %l4, !tbaa !29
  %t264 = getelementptr %"compiler/check:frame", ptr %t262, i32 0, i32 30
  store ptr %t264, ptr %l134, !tbaa !29
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  store i32 %t267, ptr %l137, !tbaa !23
  %t269 = load ptr, ptr %l10, !tbaa !29
  %t271 = icmp eq ptr %t269, null
  br i1 %t271, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb53:
  br label %bb54
bb54:
  %t273 = load ptr, ptr %l10, !tbaa !29
  %t274 = load i32, ptr %l137, !tbaa !23
  %t276 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t274, ptr %t273)
  store %"compiler/typed:Capture" %t276, ptr %l141
  br label %bb55
bb55:
  %t277 = load %"compiler/typed:Capture", ptr %l141
  %t278 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t277, ptr %t278
  %t279 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v0, ptr %t279, ptr %t278)
  br label %bb56
bb56:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i32, ptr %l9, !tbaa !23
  %t285 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t281, i32 %t282)
  store i1 %t285, ptr %l145
  br label %bb57
bb57:
  %t286 = load i1, ptr %l145, !tbaa !21
  br i1 %t286, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb61
bb59:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = getelementptr %"compiler/generic:Program", ptr %t290, i32 0, i32 2
  %t293 = load i32, ptr %l9, !tbaa !23
  %t296 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t292, i32 %t293)
  store i1 %t296, ptr %l151
  br label %bb60
bb60:
  %t297 = load i1, ptr %l151, !tbaa !21
  store i1 %t297, ptr %l146, !tbaa !21
  br label %bb61
bb61:
  %t298 = load i1, ptr %l146, !tbaa !21
  br i1 %t298, label %bb62, label %bb63
bb62:
  %t299 = load ptr, ptr %l11, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Body", ptr %t299, i32 0, i32 6
  %t302 = load i64, ptr %l12, !tbaa !24
  %t304 = trunc i64 %t302 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [1 x i64] }, ptr %t306, i32 0, i32 0
  store i64 4, ptr %t307
  %t309 = insertvalue { i32 } undef, i32 %t304, 0
  %t310 = getelementptr { i64, [1 x i64] }, ptr %t306, i32 0, i32 1
  store { i32 } %t309, ptr %t310
  %t311 = load { i64, [1 x i64] }, ptr %t306
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t301, { i64, [1 x i64] } %t311)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t314 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t314, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca %"compiler/check:litv"
  %l59 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca %"compiler/check:litv"
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Chain", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = add i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Chain", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 113}
  store i32 %t34, ptr %l8
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb1, label %bb2
bb1:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb3
bb3:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb4, label %bb5
bb4:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t47 = load i32, ptr %l8, !range !{i32 0, i32 113}
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %v4, ptr %t45, %"compiler/source:Span" %t46, i32 %t47, ptr %t48, ptr %t49, i32 %t50)
  store ptr %t57, ptr %l36
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l36, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb7:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l39
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l41
  br label %bb9
bb9:
  %t66 = load i32, ptr %l8, !range !{i32 0, i32 113}
  %t68 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t66)
  store { i64, ptr } %t68, ptr %l43
  br label %bb10
bb10:
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l39
  %t73 = load %"compiler/source:Span", ptr %l41
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t71, %"compiler/source:Span" %t72, %"compiler/source:Span" %t73, i64 %t70)
  store %"compiler/source:Span" %t75, ptr %l45
  br label %bb11
bb11:
  %t76 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t76, ptr %l9
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb12, label %bb13
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l48, !tbaa !29
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l49, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t88 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store %"compiler/check:litv" %t88, ptr %l53
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_854899d5724a103b_e7dfb19072d83fa7)
  unreachable
bb16:
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t94 = load i32, ptr %l8, !range !{i32 0, i32 113}
  %t95 = load %"compiler/source:Span", ptr %l9
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = load %"compiler/check:litv", ptr %l53
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t96, ptr %t97, %"compiler/check:litv" %t98, ptr %t93, i32 %t94, %"compiler/source:Span" %t95, i1 false)
  store ptr %t102, ptr %l59
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l59, !tbaa !29
  store ptr %t103, ptr %l10, !tbaa !29
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l64
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load ptr, ptr %l64, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t115, ptr %l66
  %t116 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t116, ptr %l67
  %t117 = load i32, ptr %l8, !range !{i32 0, i32 113}
  store i32 %t117, ptr %l68
  %t118 = load ptr, ptr %l10, !tbaa !29
  store ptr %t118, ptr %l69, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_852b58c2eb82b3cc_e47a0c64d3951188)
  unreachable
bb24:
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l5, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l74
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t129 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t127)
  store %"compiler/source:Span" %t129, ptr %l76
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l66
  %t132 = load %"compiler/source:Span", ptr %l67
  %t133 = load i32, ptr %l68, !range !{i32 0, i32 113}
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l72, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l74
  %t137 = load %"compiler/source:Span", ptr %l76
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v4, ptr %v3, ptr %v4, ptr %t130, %"compiler/source:Span" %t131, %"compiler/source:Span" %t132, i32 %t133, ptr %t134, ptr %t135, %"compiler/source:Span" %t136, %"compiler/source:Span" %t137)
  store ptr %t138, ptr %l77
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l77, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb29:
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb30, label %bb31
bb30:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  %t145 = load ptr, ptr %l7, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  %t151 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t146, ptr %t147)
  store %"compiler/check:litv" %t151, ptr %l85
  br label %bb32
bb31:
  br label %bb41
bb32:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load i32, ptr %l8, !range !{i32 0, i32 113}
  %t154 = load %"compiler/source:Span", ptr %l9
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load %"compiler/check:litv", ptr %l85
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t155, ptr %t156, %"compiler/check:litv" %t157, ptr %t152, i32 %t153, %"compiler/source:Span" %t154, i1 true)
  store ptr %t161, ptr %l89
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l89, !tbaa !29
  store ptr %t162, ptr %l11, !tbaa !29
  %t163 = load ptr, ptr %l11, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t167, %"compiler/source:Span" %t168)
  store ptr %t171, ptr %l94
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load ptr, ptr %l94, !tbaa !29
  store ptr %t172, ptr %rv
  br label %ret
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l95, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t174, ptr %l96
  %t175 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t175, ptr %l97
  %t176 = load i32, ptr %l8, !range !{i32 0, i32 113}
  store i32 %t176, ptr %l98
  %t177 = load ptr, ptr %l4, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  store ptr %t178, ptr %l100, !tbaa !29
  %t179 = load ptr, ptr %l6, !tbaa !29
  %t181 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t179)
  store %"compiler/source:Span" %t181, ptr %l102
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t184 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t182)
  store %"compiler/source:Span" %t184, ptr %l104
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l96
  %t187 = load %"compiler/source:Span", ptr %l97
  %t188 = load i32, ptr %l98, !range !{i32 0, i32 113}
  %t189 = load ptr, ptr %l99, !tbaa !29
  %t190 = load ptr, ptr %l100, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l102
  %t192 = load %"compiler/source:Span", ptr %l104
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v2, ptr %v4, ptr %v4, ptr %t185, %"compiler/source:Span" %t186, %"compiler/source:Span" %t187, i32 %t188, ptr %t189, ptr %t190, %"compiler/source:Span" %t191, %"compiler/source:Span" %t192)
  store ptr %t193, ptr %l105
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load ptr, ptr %l105, !tbaa !29
  store ptr %t194, ptr %rv
  br label %ret
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t197, ptr %l108
  %t198 = load i32, ptr %l8, !range !{i32 0, i32 113}
  store i32 %t198, ptr %l109
  %t199 = load ptr, ptr %l4, !tbaa !29
  store ptr %t199, ptr %l110, !tbaa !29
  %t200 = load ptr, ptr %l5, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t201)
  store %"compiler/source:Span" %t203, ptr %l113
  br label %bb42
bb42:
  %t204 = load ptr, ptr %l7, !tbaa !29
  %t206 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t204)
  store %"compiler/source:Span" %t206, ptr %l115
  br label %bb43
bb43:
  %t207 = load ptr, ptr %l106, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l107
  %t209 = load %"compiler/source:Span", ptr %l108
  %t210 = load i32, ptr %l109, !range !{i32 0, i32 113}
  %t211 = load ptr, ptr %l110, !tbaa !29
  %t212 = load ptr, ptr %l111, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l113
  %t214 = load %"compiler/source:Span", ptr %l115
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t207, %"compiler/source:Span" %t208, %"compiler/source:Span" %t209, i32 %t210, ptr %t211, ptr %t212, %"compiler/source:Span" %t213, %"compiler/source:Span" %t214)
  store ptr %t215, ptr %l116
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t216 = load ptr, ptr %l116, !tbaa !29
  store ptr %t216, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/check:litv"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/diagmsg:Msg"
  %l24 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l67 = alloca i32
  %l71 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/diagmsg:Msg"
  %l97 = alloca i64
  %l100 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l111 = alloca %"compiler/source:Span"
  %l118 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t7, %"compiler/source:Span" %t8, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t11, %"compiler/source:Span" %t12)
  store ptr %t15, ptr %l15
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t16 = load ptr, ptr %l15, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp ne i64 %t19, 1
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l20
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s2, ptr %s2, i64 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, i64 %t27)
  store %"compiler/diagmsg:Msg" %t29, ptr %l23
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l20
  %t32 = load %"compiler/diagmsg:Msg", ptr %l23
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t30, %"compiler/source:Span" %t31, %"compiler/diagmsg:Msg" %t32)
  store i64 %t33, ptr %l24
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t34, %"compiler/source:Span" %t35)
  store ptr %t38, ptr %l27
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load ptr, ptr %l27, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t49 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t40, ptr %t45)
  store %"compiler/check:litv" %t49, ptr %l32
  br label %bb12
bb12:
  %t50 = load %"compiler/check:litv", ptr %l32
  store %"compiler/check:litv" %t50, ptr %l4
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t53 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/check:litv", ptr %l4
  %t58 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t56, %"compiler/check:litv" %t57, i32 %t58)
  store i1 %t62, ptr %l39
  br label %bb15
bb14:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb16
bb15:
  %t63 = load i1, ptr %l39, !tbaa !21
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l35, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb18:
  %t65 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t66 = load i1, ptr %t65, !tbaa !21
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l45, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 0
  %t75 = load ptr, ptr %t74, !tbaa !39
  %t78 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t70, ptr %t75)
  store i1 %t78, ptr %l47
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb26
bb21:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb25
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 0
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t80, ptr %t85)
  store i1 %t88, ptr %l52
  br label %bb24
bb24:
  %t89 = load i1, ptr %l52, !tbaa !21
  store i1 %t89, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l48, !tbaa !21
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l43, !tbaa !21
  store i1 %t91, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l40, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l54, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l56, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = load i32, ptr %l5, !tbaa !23
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t96, ptr %t101, i32 %t103)
  store ptr %t107, ptr %l60
  br label %bb31
bb31:
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t108, ptr %l61, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l63
  br label %bb32
bb32:
  %t115 = load ptr, ptr %l54, !tbaa !29
  %t116 = load ptr, ptr %l60, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l63
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t115, ptr %t116, %"compiler/source:Span" %t117)
  store ptr %t118, ptr %l64
  br label %bb33
bb33:
  %t119 = load ptr, ptr %l64, !tbaa !29
  store ptr %t119, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t123 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t120)
  store i32 %t123, ptr %l67
  br label %bb34
bb34:
  %t124 = load i32, ptr %l67, !tbaa !23
  store i32 %t124, ptr %l7, !tbaa !23
  %t125 = load i32, ptr %l7, !tbaa !23
  %t126 = load i32, ptr %l2, !tbaa !23
  %t129 = icmp eq i32 %t125, %t126
  br i1 %t129, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb37
bb36:
  %t131 = load i32, ptr %l7, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  store i1 %t135, ptr %l71, !tbaa !21
  br label %bb37
bb37:
  %t137 = load i1, ptr %l71, !tbaa !21
  br i1 %t137, label %bb38, label %bb39
bb38:
  %t138 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l7, !tbaa !23
  %t144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l78
  br label %bb41
bb41:
  %t145 = load i1, ptr %l78, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l2, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l82
  br label %bb44
bb43:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  %t151 = load i1, ptr %l82, !tbaa !21
  store i1 %t151, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t152 = load i1, ptr %l79, !tbaa !21
  %t153 = xor i1 %t152, true
  br i1 %t153, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l84, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t156, ptr %l85, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr ptr, ptr %t158, i64 0
  %t160 = load ptr, ptr %t159, !tbaa !39
  %t162 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t160)
  store %"compiler/source:Span" %t162, ptr %l87
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t163, i32 %t164)
  store { i64, ptr } %t167, ptr %l90
  br label %bb49
bb49:
  %t168 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l91, !tbaa !27
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l7, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t175, i32 %t176)
  store { i64, ptr } %t179, ptr %l94
  br label %bb50
bb50:
  %t180 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t187 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t189 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t187, { i64, ptr } %t186)
  store %"compiler/diagmsg:Msg" %t189, ptr %l96
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l84, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l87
  %t192 = load %"compiler/diagmsg:Msg", ptr %l96
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t190, %"compiler/source:Span" %t191, %"compiler/diagmsg:Msg" %t192)
  store i64 %t193, ptr %l97
  br label %bb52
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  %t198 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t194, %"compiler/source:Span" %t195)
  store ptr %t198, ptr %l100
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t199 = load ptr, ptr %l100, !tbaa !29
  store ptr %t199, ptr %rv
  br label %ret
bb54:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i32, ptr %l7, !tbaa !23
  %t202 = load i32, ptr %l2, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t200, i32 %t201, i32 %t202)
  store { i64, ptr } %t206, ptr %l104
  br label %bb55
bb55:
  %t207 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb56, label %bb57
bb56:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l107, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t213, ptr %l108
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t214, ptr %l109, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 0
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l111
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t221 = load ptr, ptr %l6, !tbaa !29
  %t222 = load i32, ptr %l2, !tbaa !23
  %t223 = load ptr, ptr %l107, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l108
  %t225 = load %"compiler/source:Span", ptr %l111
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %v2, ptr %t223, %"compiler/source:Span" %t224, %"compiler/source:Span" %t225, ptr %t221, i32 %t222)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load ptr, ptr %l6, !tbaa !29
  %t231 = load i32, ptr %l2, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t228, %"compiler/source:Span" %t229, ptr %t230, i32 %t231)
  store ptr %t236, ptr %l118
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t237 = load ptr, ptr %l118, !tbaa !29
  store ptr %t237, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorParamAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l37 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  %t43 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i32, ptr %l11, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v0, ptr %t16, i32 %t17)
  store ptr %t20, ptr %l14
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l14, !tbaa !29
  store ptr %t21, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = icmp slt i64 %t26, 0
  store i1 %t28, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/ast:StructBody", ptr %t32, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp sge i64 %t31, %t37
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  store { i64, [3 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 0
  store i64 0, ptr %t44
  %t45 = load { i64, [3 x i64] }, ptr %t43
  store { i64, [3 x i64] } %t45, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l27, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t51, i32 %t52)
  store i64 %t55, ptr %l31
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/ast:StructBody", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l33, !tbaa !27
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t67 = getelementptr %"compiler/ast:Param", ptr %t65, i32 0, i32 2
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l27, !tbaa !29
  %t70 = load i64, ptr %l31, !tbaa !24
  %t72 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t69, i64 %t70, ptr %t68)
  store { i64, [3 x i64] } %t72, ptr %l37
  br label %bb14
bb14:
  %t73 = load { i64, [3 x i64] }, ptr %l37
  store { i64, [3 x i64] } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t22, ptr %l13
  br label %bb7
bb7:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_eaffdf15d9c064d4_e1a7ee300abdca20)
  unreachable
bb16:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 11
  store i1 true, ptr %t27, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t28, ptr %t29)
  store ptr %t32, ptr %l18
  br label %bb17
bb17:
  %t33 = load ptr, ptr %l18, !tbaa !29
  store ptr %t33, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l25
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v2, ptr %t45, ptr %t46, %"compiler/source:Span" %t47)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t48 = load ptr, ptr %l3, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edispatchChecks(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, i32 %a5, %"compiler/typed:ContractInfo" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/typed:ContractInfo"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, i64, i64 }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %lp40 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l62 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l70 = alloca i64
  %l71 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l86 = alloca i32
  %l88 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l115 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca i64
  %l119 = alloca i32
  %l120 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca ptr
  %l127 = alloca i32
  %l132 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l143 = alloca ptr
  %l147 = alloca %"compiler/typed:Try"
  %l156 = alloca ptr
  %l162 = alloca i64
  %l173 = alloca i64
  %l177 = alloca { i64, i64, i64 }
  %l181 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca i32
  %l184 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l195 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l199 = alloca %"compiler/source:Span"
  %l203 = alloca ptr
  %l204 = alloca ptr
  %l206 = alloca %"compiler/typed:If"
  %l212 = alloca i64
  %l214 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca i32
  %l223 = alloca i32
  %l224 = alloca i32
  %l228 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l239 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l252 = alloca i64
  %l258 = alloca i64
  %l261 = alloca i64
  %l280 = alloca ptr
  %l285 = alloca ptr
  %l288 = alloca %"compiler/source:Span"
  %l289 = alloca i32
  %l290 = alloca ptr
  %l294 = alloca { i64, ptr }
  %l296 = alloca %"compiler/typed:Call"
  %l302 = alloca i1
  %l311 = alloca %"compiler/source:Span"
  %l312 = alloca i32
  %l316 = alloca { i64, ptr }
  %l317 = alloca %"compiler/typed:Seq"
  %l321 = alloca %"compiler/source:Span"
  %l322 = alloca i32
  %l326 = alloca { i64, ptr }
  %l328 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t53 = alloca { i64, [1 x i64] }, align 8
  %t72 = alloca { i64, [3 x i64] }, align 8
  %t223 = alloca { i64, [5 x i64] }, align 8
  %t270 = alloca { i64, [3 x i64] }, align 8
  %t375 = alloca { i64, [3 x i64] }, align 8
  %t416 = alloca { i64, [5 x i64] }, align 8
  %t432 = alloca { i64, [3 x i64] }, align 8
  %t585 = alloca { i64, [5 x i64] }, align 8
  %t614 = alloca { i64, [3 x i64] }, align 8
  %t639 = alloca { i64, [5 x i64] }, align 8
  %t667 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store %"compiler/typed:ContractInfo" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l42
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l42, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 37
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l45
  br label %bb2
bb2:
  %t10 = load i64, ptr %l45, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l46
  br label %bb3
bb3:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l9
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb27
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t27, ptr %l54, !tbaa !27
  %t28 = load i64, ptr %l11, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  store ptr %t33, ptr %l13, !tbaa !29
  %t35 = load ptr, ptr %l13, !tbaa !29
  store ptr %t35, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t36 = load ptr, ptr %l57, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l57, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 0
  store i1 %t42, ptr %l58, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l58, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 -1)
  br label %bb13
bb13:
  br label %bb25
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l62, !tbaa !29
  %t46 = load ptr, ptr %l13, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t46)
  store %"compiler/source:Span" %t48, ptr %l64
  br label %bb18
bb18:
  %t49 = load ptr, ptr %l13, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t49)
  store i32 %t52, ptr %l67
  br label %bb19
bb19:
  store { i64, [1 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i32 0, i32 0
  store i64 0, ptr %t54
  %t55 = load { i64, [1 x i64] }, ptr %t53
  %t56 = load ptr, ptr %l62, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l64
  %t58 = load i32, ptr %l67, !tbaa !23
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t56, i32 0, %"compiler/source:Span" %t57, i32 %t58, i32 2, { i64, [1 x i64] } %t55)
  store i64 %t61, ptr %l70
  br label %bb20
bb20:
  %t62 = load i64, ptr %l70, !tbaa !24
  store i64 %t62, ptr %l14, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l71, !tbaa !29
  %t64 = load ptr, ptr %l13, !tbaa !29
  %t66 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t64)
  store %"compiler/source:Span" %t66, ptr %l73
  br label %bb21
bb21:
  %t67 = load i64, ptr %l14, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  %t71 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 0
  store i64 0, ptr %t73
  %t74 = load %"compiler/source:Span", ptr %l73
  %t75 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t74, 0
  %t77 = insertvalue { %"compiler/source:Span", i32, ptr } %t75, i32 %t69, 1
  %t79 = insertvalue { %"compiler/source:Span", i32, ptr } %t77, ptr %t71, 2
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t79, ptr %t80
  %t81 = load { i64, [3 x i64] }, ptr %t72
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t81, ptr %t83
  %t84 = load ptr, ptr %l71, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t84, ptr %t83)
  br label %bb22
bb22:
  %t86 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t86)
  br label %bb23
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_27e3ab5b7d984c5a_74f0959f23b09f6e)
  unreachable
bb25:
  br label %bb26
bb26:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l11, !tbaa !24
  br label %bb4
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t96, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d9, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i32 %t98, ptr %l86
  br label %bb28
bb28:
  %t99 = load i32, ptr %l86, !tbaa !23
  store i32 %t99, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  %t100 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 2
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t100)
  store i64 %t102, ptr %l88
  br label %bb29
bb29:
  %t103 = load i64, ptr %l88, !tbaa !24
  store i64 %t103, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t104 = load i64, ptr %l17, !tbaa !24
  %t105 = load i64, ptr %l16, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb30, label %bb31
bb30:
  %t110 = load i64, ptr %l18, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb35
bb32:
  %t114 = load i64, ptr %l17, !tbaa !24
  %t115 = load i64, ptr %l16, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l18, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l18, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l95, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb34
bb34:
  %t130 = load i64, ptr %l95, !tbaa !24
  store i64 %t130, ptr %l92, !tbaa !24
  br label %bb35
bb35:
  %t131 = load i64, ptr %l92, !tbaa !24
  store i64 %t131, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l20, !tbaa !24
  %t133 = load i64, ptr %l19, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb38:
  br label %bb39
bb39:
  %t140 = load i64, ptr %l16, !tbaa !24
  %t141 = load i64, ptr %l20, !tbaa !24
  %t142 = load i64, ptr %l18, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  store i64 %t148, ptr %l21, !tbaa !24
  %t150 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 2
  %t151 = load i64, ptr %l21, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l115
  br label %bb40
bb40:
  %t155 = load i64, ptr %l115, !tbaa !24
  store i64 %t155, ptr %l22, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l116, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l117
  %t158 = load i64, ptr %l22, !tbaa !24
  store i64 %t158, ptr %l118, !tbaa !24
  %t159 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t159, ptr %l119, !tbaa !23
  %t160 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t160, ptr %l120, !tbaa !27
  store ptr %l9, ptr %l121, !tbaa !29
  %t161 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %l122
  br label %bb41
bb41:
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %t163
  %t164 = load ptr, ptr %l116, !tbaa !29
  %t165 = load %"compiler/source:Span", ptr %l117
  %t166 = load i64, ptr %l118, !tbaa !24
  %t167 = load i32, ptr %l119, !tbaa !23
  %t168 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t169 = load ptr, ptr %l121, !tbaa !29
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %v2, ptr %s0, ptr %v0, ptr %v0, ptr %t164, %"compiler/source:Span" %t165, i64 %t166, i32 %t167, { i64, ptr } %t168, ptr %t169, ptr %t163)
  store ptr %t171, ptr %l124
  br label %bb42
bb42:
  %t172 = load ptr, ptr %l124, !tbaa !29
  store ptr %t172, ptr %l23, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l22, !tbaa !24
  %t177 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t173, i64 %t174)
  store i32 %t177, ptr %l127
  br label %bb43
bb43:
  %t178 = load i32, ptr %l127, !tbaa !23
  store i32 %t178, ptr %l24, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l24, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s7, ptr %t184, i32 %t185)
  store { i64, ptr } %t188, ptr %l132
  br label %bb44
bb44:
  %t189 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb45, label %bb46
bb45:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l24, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %t194, i32 %t195)
  br label %bb47
bb46:
  br label %bb53
bb47:
  %t198 = load ptr, ptr %l7, !tbaa !29
  store ptr %t198, ptr %l137, !tbaa !29
  %t199 = load ptr, ptr %l137, !tbaa !29
  %t200 = getelementptr %"compiler/check:frame", ptr %t199, i32 0, i32 16
  %t201 = load i64, ptr %t200, !tbaa !24
  %t203 = add i64 %t201, 1
  %t205 = load ptr, ptr %l137, !tbaa !29
  %t206 = getelementptr %"compiler/check:frame", ptr %t205, i32 0, i32 16
  store i64 %t203, ptr %t206, !tbaa !24
  %t207 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t207, ptr %l140
  %t208 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t208, ptr %l141, !tbaa !23
  %t209 = load ptr, ptr %l23, !tbaa !29
  store ptr %t209, ptr %l143, !tbaa !29
  %t211 = icmp sge i64 0, 0
  br i1 %t211, label %bb48, label %bb49
bb48:
  %t213 = icmp sle i64 0, 1152921504606846975
  br i1 %t213, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_4b7cfa1fb5fcb474_4538ddb4be3a0770)
  unreachable
bb50:
  %t215 = mul i64 0, 8
  %t216 = insertvalue { i64, ptr } undef, i64 0, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t218 = load ptr, ptr %l143, !tbaa !29
  %t220 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t218, { i64, ptr } %t217, i1 false, i1 false, i1 true)
  store %"compiler/typed:Try" %t220, ptr %l147
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_4b7cfa1fb5fcb474_4538ddb4be3a0770)
  unreachable
bb52:
  %t221 = load %"compiler/typed:Try", ptr %l147
  %t222 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t221, ptr %t222
  store { i64, [5 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 0
  store i64 14, ptr %t224
  %t225 = load %"compiler/source:Span", ptr %l140
  %t226 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t225, 0
  %t227 = load i32, ptr %l141, !tbaa !23
  %t228 = insertvalue { %"compiler/source:Span", i32, ptr } %t226, i32 %t227, 1
  %t230 = insertvalue { %"compiler/source:Span", i32, ptr } %t228, ptr %t222, 2
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t230, ptr %t231
  %t232 = load { i64, [5 x i64] }, ptr %t223
  %t234 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t232, ptr %t234
  store ptr %t234, ptr %l23, !tbaa !29
  br label %bb53
bb53:
  %t236 = load i32, ptr %l15, !tbaa !23
  %t237 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t240 = icmp eq i32 %t236, %t237
  br i1 %t240, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb79
bb55:
  br label %bb56
bb56:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t242, i32 %t243)
  br label %bb57
bb57:
  %t246 = load ptr, ptr %l7, !tbaa !29
  store ptr %t246, ptr %l156, !tbaa !29
  %t247 = load ptr, ptr %l156, !tbaa !29
  %t248 = getelementptr %"compiler/check:frame", ptr %t247, i32 0, i32 16
  %t249 = load i64, ptr %t248, !tbaa !24
  %t251 = add i64 %t249, 1
  %t253 = load ptr, ptr %l156, !tbaa !29
  %t254 = getelementptr %"compiler/check:frame", ptr %t253, i32 0, i32 16
  store i64 %t251, ptr %t254, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  %t257 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t261 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t255, %"compiler/source:Span" %t256, i32 %t257)
  store i64 %t261, ptr %l162
  br label %bb58
bb58:
  %t262 = load i64, ptr %l162, !tbaa !24
  store i64 %t262, ptr %l25, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i64, ptr %l25, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t269 = load ptr, ptr %l23, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t264, 0
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t267, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [3 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t279, ptr %t281
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t263, ptr %t281)
  br label %bb59
bb59:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 37
  %t288 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t286)
  store i64 %t288, ptr %l173
  br label %bb60
bb60:
  %t289 = load i64, ptr %l173, !tbaa !24
  store i64 %t289, ptr %l26, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l1
  %t295 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t290, i32 1, %"compiler/source:Span" %t291)
  store { i64, i64, i64 } %t295, ptr %l177
  br label %bb61
bb61:
  %t296 = load { i64, i64, i64 }, ptr %l177
  store { i64, i64, i64 } %t296, ptr %l27
  %t297 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 0
  %t298 = load i64, ptr %t297, !tbaa !24
  store i64 %t298, ptr %l28, !tbaa !24
  %t300 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 1
  %t301 = load i64, ptr %t300, !tbaa !24
  store i64 %t301, ptr %l29, !tbaa !24
  %t303 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 2
  %t304 = load i64, ptr %t303, !tbaa !24
  store i64 %t304, ptr %l30, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l181, !tbaa !29
  %t307 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t307, ptr %l182
  %t308 = load i32, ptr %l15, !tbaa !23
  store i32 %t308, ptr %l183, !tbaa !23
  %t309 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 0
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  store { i64, ptr } %t310, ptr %l184, !tbaa !27
  %t311 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 4
  %t312 = load i64, ptr %l21, !tbaa !24
  %t315 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s7, ptr %t311, i64 %t312)
  store { i64, ptr } %t315, ptr %l187
  br label %bb62
bb62:
  %t316 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t321 = add i64 %t318, %t320
  %t322 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = add i64 %t321, %t324
  %t326 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t325)
  call void @olang_textcopy(ptr %t326, ptr %t317, i64 %t318)
  %t327 = getelementptr i8, ptr %t326, i64 %t318
  call void @olang_textcopy(ptr %t327, ptr %t319, i64 %t320)
  %t328 = getelementptr i8, ptr %t327, i64 %t320
  call void @olang_textcopy(ptr %t328, ptr %t323, i64 %t324)
  %t329 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t326, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = extractvalue { i64, ptr } %t330, 1
  %t334 = mul i64 %t332, 1
  %t335 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t334)
  call void @llvm.memcpy.p0.p0.i64(ptr %t335, ptr %t333, i64 %t334, i1 false)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t335, 1
  %t338 = load ptr, ptr %l181, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l182
  %t340 = load i32, ptr %l183, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargumentPush(ptr %v0, ptr %v0, ptr %t338, %"compiler/source:Span" %t339, i32 %t340, i64 0, { i64, ptr } %t337)
  br label %bb63
bb63:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l28, !tbaa !24
  %t344 = load i64, ptr %l29, !tbaa !24
  %t345 = load i64, ptr %l30, !tbaa !24
  %t346 = load i64, ptr %l26, !tbaa !24
  %t352 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t342, i64 %t343, i64 %t344, i64 %t345, i64 %t346)
  store ptr %t352, ptr %l195
  br label %bb64
bb64:
  %t353 = load ptr, ptr %l195, !tbaa !29
  store ptr %t353, ptr %l31, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l196, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t355, ptr %l197
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l198, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t357, ptr %l199
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l1
  %t360 = load i64, ptr %l25, !tbaa !24
  %t364 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t358, %"compiler/source:Span" %t359, i64 %t360)
  store ptr %t364, ptr %l203
  br label %bb65
bb65:
  %t365 = load ptr, ptr %l198, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l199
  %t367 = load ptr, ptr %l203, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v0, ptr %v0, ptr %t365, %"compiler/source:Span" %t366, ptr %t367)
  store ptr %t368, ptr %l204
  br label %bb66
bb66:
  %t369 = load ptr, ptr %l31, !tbaa !29
  %t370 = load ptr, ptr %l204, !tbaa !29
  %t372 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t370, ptr %t369, ptr null)
  store %"compiler/typed:If" %t372, ptr %l206
  br label %bb67
bb67:
  %t373 = load %"compiler/typed:If", ptr %l206
  %t374 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t373, ptr %t374
  store { i64, [3 x i64] } zeroinitializer, ptr %t375
  %t376 = getelementptr { i64, [3 x i64] }, ptr %t375, i32 0, i32 0
  store i64 3, ptr %t376
  %t377 = load %"compiler/source:Span", ptr %l197
  %t378 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t377, 0
  %t380 = insertvalue { %"compiler/source:Span", ptr } %t378, ptr %t374, 1
  %t381 = getelementptr { i64, [3 x i64] }, ptr %t375, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t380, ptr %t381
  %t382 = load { i64, [3 x i64] }, ptr %t375
  %t384 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t382, ptr %t384
  %t385 = load ptr, ptr %l196, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t385, ptr %t384)
  br label %bb68
bb68:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 36
  %t391 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t389)
  store i64 %t391, ptr %l212
  br label %bb69
bb69:
  %t392 = load i64, ptr %l212, !tbaa !24
  store i64 %t392, ptr %l32, !tbaa !24
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = getelementptr %"compiler/check:Checker", ptr %t393, i32 0, i32 36
  store ptr %t395, ptr %l214, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load %"compiler/source:Span", ptr %l1
  %t398 = load i64, ptr %l25, !tbaa !24
  %t402 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t396, %"compiler/source:Span" %t397, i64 %t398)
  store ptr %t402, ptr %l218
  br label %bb70
bb70:
  %t403 = load ptr, ptr %l214, !tbaa !29
  %t404 = load ptr, ptr %l218, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t403, ptr %t404)
  br label %bb71
bb71:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l219, !tbaa !29
  %t406 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t406, ptr %l220
  %t407 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t407, ptr %l221
  %t408 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t408, ptr %l222, !tbaa !23
  store i32 37, ptr %l223
  store i32 2, ptr %l224
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/check:Checker", ptr %t409, i32 0, i32 36
  %t412 = load i64, ptr %l32, !tbaa !24
  %t415 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t411, i64 %t412)
  store { i64, ptr } %t415, ptr %l228
  br label %bb72
bb72:
  store { i64, [5 x i64] } zeroinitializer, ptr %t416
  %t417 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 0
  store i64 9, ptr %t417
  %t418 = load %"compiler/source:Span", ptr %l221
  %t419 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t418, 0
  %t420 = load i32, ptr %l222, !tbaa !23
  %t421 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t419, i32 %t420, 1
  %t422 = load i32, ptr %l223, !range !{i32 0, i32 52}
  %t423 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t421, i32 %t422, 2
  %t424 = load i32, ptr %l224, !range !{i32 0, i32 3}
  %t425 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t423, i32 %t424, 3
  %t426 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t427 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t425, { i64, ptr } %t426, 4
  %t428 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t427, ptr %t428
  %t429 = load { i64, [5 x i64] }, ptr %t416
  %t431 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t429, ptr %t431
  store { i64, [3 x i64] } zeroinitializer, ptr %t432
  %t433 = getelementptr { i64, [3 x i64] }, ptr %t432, i32 0, i32 0
  store i64 2, ptr %t433
  %t434 = load %"compiler/source:Span", ptr %l220
  %t435 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t434, 0
  %t437 = insertvalue { %"compiler/source:Span", ptr } %t435, ptr %t431, 1
  %t438 = getelementptr { i64, [3 x i64] }, ptr %t432, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t437, ptr %t438
  %t439 = load { i64, [3 x i64] }, ptr %t432
  %t441 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t439, ptr %t441
  %t442 = load ptr, ptr %l219, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t442, ptr %t441)
  br label %bb73
bb73:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t444)
  store ptr %t446, ptr %l234
  br label %bb74
bb74:
  %t447 = load ptr, ptr %l234, !tbaa !29
  %t449 = getelementptr %"compiler/typed:Body", ptr %t447, i32 0, i32 12
  %t450 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t451 = load i32, ptr %t450, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t449, i32 %t451)
  br label %bb75
bb75:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t454)
  store ptr %t456, ptr %l239
  br label %bb76
bb76:
  %t457 = load ptr, ptr %l239, !tbaa !29
  %t459 = getelementptr %"compiler/typed:Body", ptr %t457, i32 0, i32 13
  store ptr %t459, ptr %l241, !tbaa !29
  %t460 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 0
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !27
  store { i64, ptr } %t461, ptr %l242, !tbaa !27
  %t462 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 4
  %t463 = load i64, ptr %l21, !tbaa !24
  %t466 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s7, ptr %t462, i64 %t463)
  store { i64, ptr } %t466, ptr %l245
  br label %bb77
bb77:
  %t467 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 1
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t470 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t471 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t472 = add i64 %t469, %t471
  %t473 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t473, 1
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = add i64 %t472, %t475
  %t477 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t476)
  call void @olang_textcopy(ptr %t477, ptr %t468, i64 %t469)
  %t478 = getelementptr i8, ptr %t477, i64 %t469
  call void @olang_textcopy(ptr %t478, ptr %t470, i64 %t471)
  %t479 = getelementptr i8, ptr %t478, i64 %t471
  call void @olang_textcopy(ptr %t479, ptr %t474, i64 %t475)
  %t480 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t477, 1
  %t483 = extractvalue { i64, ptr } %t481, 0
  %t484 = extractvalue { i64, ptr } %t481, 1
  %t485 = mul i64 %t483, 1
  %t486 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t486, ptr %t484, i64 %t485, i1 false)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  %t489 = load ptr, ptr %l241, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t489, { i64, ptr } %t488)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s7)
  br label %bb79
bb79:
  %t491 = load i64, ptr %l20, !tbaa !24
  %t493 = add i64 %t491, 1
  store i64 %t493, ptr %l20, !tbaa !24
  br label %bb36
bb80:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/check:Checker", ptr %t495, i32 0, i32 36
  %t499 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t497)
  store i64 %t499, ptr %l252
  br label %bb81
bb81:
  %t500 = load i64, ptr %l252, !tbaa !24
  store i64 %t500, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  %t501 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t501, 0
  store i64 %t503, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t505 = load i64, ptr %l35, !tbaa !24
  %t506 = load i64, ptr %l34, !tbaa !24
  %t509 = icmp sgt i64 %t505, %t506
  br i1 %t509, label %bb82, label %bb83
bb82:
  %t511 = load i64, ptr %l36, !tbaa !24
  %t513 = icmp sgt i64 %t511, 0
  br i1 %t513, label %bb84, label %bb85
bb83:
  store i64 0, ptr %l258, !tbaa !24
  br label %bb87
bb84:
  %t515 = load i64, ptr %l35, !tbaa !24
  %t516 = load i64, ptr %l34, !tbaa !24
  %t519 = sub i64 %t515, %t516
  %t520 = load i64, ptr %l36, !tbaa !24
  %t523 = add i64 %t519, %t520
  %t525 = sub i64 %t523, 1
  %t526 = load i64, ptr %l36, !tbaa !24
  %t529 = sdiv i64 %t525, %t526
  store i64 %t529, ptr %l261, !tbaa !24
  br label %bb86
bb85:
  store i64 0, ptr %l261, !tbaa !24
  br label %bb86
bb86:
  %t531 = load i64, ptr %l261, !tbaa !24
  store i64 %t531, ptr %l258, !tbaa !24
  br label %bb87
bb87:
  %t532 = load i64, ptr %l258, !tbaa !24
  store i64 %t532, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb88
bb88:
  %t533 = load i64, ptr %l38, !tbaa !24
  %t534 = load i64, ptr %l37, !tbaa !24
  %t537 = icmp slt i64 %t533, %t534
  %t539 = xor i1 %t537, true
  br i1 %t539, label %bb89, label %bb90
bb89:
  br label %bb95
bb90:
  br label %bb91
bb91:
  %t541 = load i64, ptr %l34, !tbaa !24
  %t542 = load i64, ptr %l38, !tbaa !24
  %t543 = load i64, ptr %l36, !tbaa !24
  %t546 = mul i64 %t542, %t543
  %t549 = add i64 %t541, %t546
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = getelementptr %"compiler/check:Checker", ptr %t551, i32 0, i32 36
  store ptr %t553, ptr %l280, !tbaa !29
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t561 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v2, ptr %s0, ptr %v2, ptr %t554, { i64, ptr } %t555, ptr %l9, i64 %t549)
  store ptr %t561, ptr %l285
  br label %bb92
bb92:
  %t562 = load ptr, ptr %l280, !tbaa !29
  %t563 = load ptr, ptr %l285, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t562, ptr %t563)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t564 = load i64, ptr %l38, !tbaa !24
  %t566 = add i64 %t564, 1
  store i64 %t566, ptr %l38, !tbaa !24
  br label %bb88
bb95:
  %t568 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t568, ptr %l288
  %t569 = load i32, ptr %l2, !tbaa !23
  store i32 %t569, ptr %l289, !tbaa !23
  store ptr %a3, ptr %l290, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/check:Checker", ptr %t571, i32 0, i32 36
  %t574 = load i64, ptr %l33, !tbaa !24
  %t577 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t573, i64 %t574)
  store { i64, ptr } %t577, ptr %l294
  br label %bb96
bb96:
  %t579 = load ptr, ptr %l290, !tbaa !29
  %t580 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t582 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v1, ptr %v0, ptr %v4, ptr %t579, { i64, ptr } %t580, i32 %a5, i1 false, i1 false)
  store %"compiler/typed:Call" %t582, ptr %l296
  br label %bb97
bb97:
  %t583 = load %"compiler/typed:Call", ptr %l296
  %t584 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"compiler/typed:Call" %t583, ptr %t584
  store { i64, [5 x i64] } zeroinitializer, ptr %t585
  %t586 = getelementptr { i64, [5 x i64] }, ptr %t585, i32 0, i32 0
  store i64 6, ptr %t586
  %t587 = load %"compiler/source:Span", ptr %l288
  %t588 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t587, 0
  %t589 = load i32, ptr %l289, !tbaa !23
  %t590 = insertvalue { %"compiler/source:Span", i32, ptr } %t588, i32 %t589, 1
  %t592 = insertvalue { %"compiler/source:Span", i32, ptr } %t590, ptr %t584, 2
  %t593 = getelementptr { i64, [5 x i64] }, ptr %t585, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t592, ptr %t593
  %t594 = load { i64, [5 x i64] }, ptr %t585
  %t595 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store ptr %t595, ptr %lp40
  %t597 = load ptr, ptr %lp40
  store { i64, [5 x i64] } %t594, ptr %t597
  %t598 = load i32, ptr %l2, !tbaa !23
  %t599 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t602 = icmp eq i32 %t598, %t599
  br i1 %t602, label %bb98, label %bb99
bb98:
  store i1 true, ptr %l302, !tbaa !21
  br label %bb100
bb99:
  %t604 = load i32, ptr %l2, !tbaa !23
  %t605 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t608 = icmp eq i32 %t604, %t605
  store i1 %t608, ptr %l302, !tbaa !21
  br label %bb100
bb100:
  %t610 = load i1, ptr %l302, !tbaa !21
  br i1 %t610, label %bb101, label %bb102
bb101:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load %"compiler/source:Span", ptr %l1
  %t613 = load ptr, ptr %lp40
  store { i64, [3 x i64] } zeroinitializer, ptr %t614
  %t615 = getelementptr { i64, [3 x i64] }, ptr %t614, i32 0, i32 0
  store i64 2, ptr %t615
  %t617 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t612, 0
  %t619 = insertvalue { %"compiler/source:Span", ptr } %t617, ptr %t613, 1
  %t620 = getelementptr { i64, [3 x i64] }, ptr %t614, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t619, ptr %t620
  %t621 = load { i64, [3 x i64] }, ptr %t614
  %t623 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t621, ptr %t623
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t611, ptr %t623)
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t626 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t626, ptr %l311
  %t627 = load i32, ptr %l2, !tbaa !23
  store i32 %t627, ptr %l312, !tbaa !23
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/check:Checker", ptr %t628, i32 0, i32 37
  %t631 = load i64, ptr %l8, !tbaa !24
  %t634 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t630, i64 %t631)
  store { i64, ptr } %t634, ptr %l316
  br label %bb104
bb104:
  %t635 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t636 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v4, ptr %v4, { i64, ptr } %t635, ptr null, i1 false)
  store %"compiler/typed:Seq" %t636, ptr %l317
  br label %bb105
bb105:
  %t637 = load %"compiler/typed:Seq", ptr %l317
  %t638 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"compiler/typed:Seq" %t637, ptr %t638
  store { i64, [5 x i64] } zeroinitializer, ptr %t639
  %t640 = getelementptr { i64, [5 x i64] }, ptr %t639, i32 0, i32 0
  store i64 12, ptr %t640
  %t641 = load %"compiler/source:Span", ptr %l311
  %t642 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t641, 0
  %t643 = load i32, ptr %l312, !tbaa !23
  %t644 = insertvalue { %"compiler/source:Span", i32, ptr } %t642, i32 %t643, 1
  %t646 = insertvalue { %"compiler/source:Span", i32, ptr } %t644, ptr %t638, 2
  %t647 = getelementptr { i64, [5 x i64] }, ptr %t639, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t646, ptr %t647
  %t648 = load { i64, [5 x i64] }, ptr %t639
  %t650 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t648, ptr %t650
  call void @__olang_scope_close(ptr %s0)
  store ptr %t650, ptr %rv
  br label %ret
bb106:
  %t652 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t652, ptr %l321
  %t653 = load i32, ptr %l2, !tbaa !23
  store i32 %t653, ptr %l322, !tbaa !23
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = getelementptr %"compiler/check:Checker", ptr %t654, i32 0, i32 37
  %t657 = load i64, ptr %l8, !tbaa !24
  %t660 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t656, i64 %t657)
  store { i64, ptr } %t660, ptr %l326
  br label %bb107
bb107:
  %t661 = load ptr, ptr %lp40
  %t662 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t664 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v4, ptr %v4, { i64, ptr } %t662, ptr %t661, i1 false)
  store %"compiler/typed:Seq" %t664, ptr %l328
  br label %bb108
bb108:
  %t665 = load %"compiler/typed:Seq", ptr %l328
  %t666 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"compiler/typed:Seq" %t665, ptr %t666
  store { i64, [5 x i64] } zeroinitializer, ptr %t667
  %t668 = getelementptr { i64, [5 x i64] }, ptr %t667, i32 0, i32 0
  store i64 12, ptr %t668
  %t669 = load %"compiler/source:Span", ptr %l321
  %t670 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t669, 0
  %t671 = load i32, ptr %l322, !tbaa !23
  %t672 = insertvalue { %"compiler/source:Span", i32, ptr } %t670, i32 %t671, 1
  %t674 = insertvalue { %"compiler/source:Span", i32, ptr } %t672, ptr %t666, 2
  %t675 = getelementptr { i64, [5 x i64] }, ptr %t667, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t674, ptr %t675
  %t676 = load { i64, [5 x i64] }, ptr %t667
  %t678 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t676, ptr %t678
  call void @__olang_scope_close(ptr %s0)
  store ptr %t678, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb22
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 30}
  %t30 = icmp eq i64 %t28, 5
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 113}
  store i32 %t36, ptr %l6
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l7, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t46, i32 0, i32 3
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l8, !tbaa !29
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t50 = load i32, ptr %l6, !range !{i32 0, i32 113}
  %t52 = trunc i64 78 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l7, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t55, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l35
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l8, !tbaa !29
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t63, ptr %t64, i32 %t66)
  store ptr %t70, ptr %l40
  br label %bb13
bb13:
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t71, ptr %t72, i32 %t74)
  store ptr %t78, ptr %l45
  br label %bb18
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6f8999b7f8ddffc_ce9c2022d5a87cc8)
  unreachable
bb20:
  br label %bb21
bb21:
  %t79 = load i64, ptr %l3, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l3, !tbaa !24
  br label %bb1
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l27 = alloca i1
  %l30 = alloca ptr
  %l34 = alloca %"compiler/typed:Local"
  %l37 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l65 = alloca i32
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l70 = alloca i64
  %l71 = alloca ptr
  %l75 = alloca ptr
  %l81 = alloca ptr
  %l83 = alloca ptr
  %l87 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l104 = alloca i64
  %l108 = alloca { i64, i64, i64 }
  %l112 = alloca ptr
  %l123 = alloca ptr
  %l129 = alloca ptr
  %s0 = alloca %olang.scope
  %t114 = alloca { i64, [3 x i64] }, align 8
  %t212 = alloca { i64, [4 x i64] }, align 8
  %t247 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i32, ptr %l14, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l4, !tbaa !23
  %t17 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l21, !tbaa !21
  store i1 %t18, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l18, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l27
  br label %bb8
bb8:
  %t30 = load i1, ptr %l27, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t34)
  store ptr %t36, ptr %l30
  br label %bb13
bb13:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = trunc i64 %t37 to i32
  %t41 = load ptr, ptr %l30, !tbaa !29
  %t43 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t41, i32 %t39)
  store %"compiler/typed:Local" %t43, ptr %l34
  br label %bb14
bb14:
  %t44 = getelementptr %"compiler/typed:Local", ptr %l34, i32 0, i32 4
  %t45 = load i32, ptr %t44, !range !{i32 0, i32 7}
  %t47 = trunc i64 6 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t50)
  store ptr %t52, ptr %l39
  br label %bb17
bb16:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb18
bb17:
  %t53 = load ptr, ptr %l39, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 13
  %t56 = load i1, ptr %t55, !tbaa !21
  store i1 %t56, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l37, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  store ptr %t64, ptr %l45, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  store ptr %t70, ptr %l48, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t71)
  store ptr %t73, ptr %l50
  br label %bb21
bb20:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb24
bb21:
  %t74 = load ptr, ptr %l50, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %t76, !tbaa !23
  %t78 = load ptr, ptr %l48, !tbaa !29
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t78, i32 %t77)
  store i32 %t80, ptr %l53
  br label %bb22
bb22:
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t82 = load i32, ptr %l53, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l54
  br label %bb23
bb23:
  %t84 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t87 = icmp eq i64 %t85, 0
  store i1 %t87, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t89 = load i1, ptr %l42, !tbaa !21
  br i1 %t89, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l2
  %t92 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t96 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t90, %"compiler/source:Span" %t91, i32 %t92)
  store i64 %t96, ptr %l60
  br label %bb28
bb28:
  %t97 = load i64, ptr %l60, !tbaa !24
  store i64 %t97, ptr %l5, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l61, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t99, ptr %l62
  %t100 = load i64, ptr %l5, !tbaa !24
  %t102 = trunc i64 %t100 to i32
  store i32 %t102, ptr %l65, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l66, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t105, ptr %l67
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t106, ptr %l68, !tbaa !23
  br i1 %a3, label %bb29, label %bb30
bb29:
  store i64 1, ptr %l70, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb31
bb31:
  %t109 = load ptr, ptr %l66, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l67
  %t111 = load i32, ptr %l68, !tbaa !23
  %t112 = load i64, ptr %l70, !tbaa !24
  %t113 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t109, %"compiler/source:Span" %t110, i32 %t111, i64 %t112)
  store ptr %t113, ptr %l71
  br label %bb32
bb32:
  store { i64, [3 x i64] } zeroinitializer, ptr %t114
  %t115 = getelementptr { i64, [3 x i64] }, ptr %t114, i32 0, i32 0
  store i64 0, ptr %t115
  %t116 = load %"compiler/source:Span", ptr %l62
  %t117 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t116, 0
  %t118 = load i32, ptr %l65, !tbaa !23
  %t119 = insertvalue { %"compiler/source:Span", i32, ptr } %t117, i32 %t118, 1
  %t120 = load ptr, ptr %l71, !tbaa !29
  %t121 = insertvalue { %"compiler/source:Span", i32, ptr } %t119, ptr %t120, 2
  %t122 = getelementptr { i64, [3 x i64] }, ptr %t114, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t121, ptr %t122
  %t123 = load { i64, [3 x i64] }, ptr %t114
  %t125 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t123, ptr %t125
  %t126 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t126, ptr %t125)
  br label %bb33
bb33:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t128)
  store ptr %t130, ptr %l75
  br label %bb34
bb34:
  %t131 = load ptr, ptr %l75, !tbaa !29
  %t133 = getelementptr %"compiler/check:frame", ptr %t131, i32 0, i32 23
  %t134 = load i64, ptr %l1, !tbaa !24
  %t135 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t133, i64 %t134, i64 %t135)
  br label %bb35
bb35:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 67
  store ptr %t141, ptr %l81, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t142)
  store ptr %t144, ptr %l83
  br label %bb36
bb36:
  %t145 = load ptr, ptr %l83, !tbaa !29
  %t147 = getelementptr %"compiler/check:frame", ptr %t145, i32 0, i32 0
  %t148 = load i64, ptr %t147, !tbaa !24
  %t149 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t149, i64 %t148, i1 true)
  br label %bb37
bb37:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t151)
  store ptr %t153, ptr %l87
  br label %bb38
bb38:
  %t154 = load ptr, ptr %l87, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 22
  store ptr %t156, ptr %l89, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t157)
  store ptr %t159, ptr %l91
  br label %bb39
bb39:
  %t160 = load ptr, ptr %l91, !tbaa !29
  %t162 = getelementptr %"compiler/check:frame", ptr %t160, i32 0, i32 7
  %t163 = load i64, ptr %t162, !tbaa !24
  %t164 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t164, i64 %t163)
  br label %bb40
bb40:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t166)
  store ptr %t168, ptr %l95
  br label %bb41
bb41:
  %t169 = load ptr, ptr %l95, !tbaa !29
  %t171 = getelementptr %"compiler/check:frame", ptr %t169, i32 0, i32 24
  store ptr %t171, ptr %l97, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t172)
  store ptr %t174, ptr %l99
  br label %bb42
bb42:
  %t175 = load ptr, ptr %l99, !tbaa !29
  %t177 = getelementptr %"compiler/check:frame", ptr %t175, i32 0, i32 7
  %t178 = load i64, ptr %t177, !tbaa !24
  %t179 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t179, i64 %t178)
  br label %bb43
bb43:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/check:Checker", ptr %t181, i32 0, i32 37
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t183)
  store i64 %t185, ptr %l104
  br label %bb44
bb44:
  %t186 = load i64, ptr %l104, !tbaa !24
  store i64 %t186, ptr %l6, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l2
  %t192 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t187, i32 8, %"compiler/source:Span" %t188)
  store { i64, i64, i64 } %t192, ptr %l108
  br label %bb45
bb45:
  %t193 = load { i64, i64, i64 }, ptr %l108
  store { i64, i64, i64 } %t193, ptr %l7
  %t194 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t195 = load i64, ptr %t194, !tbaa !24
  store i64 %t195, ptr %l8, !tbaa !24
  %t197 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t198 = load i64, ptr %t197, !tbaa !24
  store i64 %t198, ptr %l9, !tbaa !24
  %t200 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t201 = load i64, ptr %t200, !tbaa !24
  store i64 %t201, ptr %l10, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l112, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l2
  %t206 = load %"compiler/source:Span", ptr %l2
  %t207 = load i32, ptr %l4, !tbaa !23
  %t208 = load i64, ptr %l1, !tbaa !24
  %t210 = trunc i64 %t208 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t212, i32 0, i32 0
  store i64 0, ptr %t213
  %t215 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t206, 0
  %t217 = insertvalue { %"compiler/source:Span", i32, i32 } %t215, i32 %t207, 1
  %t219 = insertvalue { %"compiler/source:Span", i32, i32 } %t217, i32 %t210, 2
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t212, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t219, ptr %t220
  %t221 = load { i64, [4 x i64] }, ptr %t212
  %t223 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t221, ptr %t223
  %t224 = load i64, ptr %l5, !tbaa !24
  %t229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v0, ptr %v0, ptr %t204, %"compiler/source:Span" %t205, ptr %t223, i64 %t224)
  store ptr %t229, ptr %l123
  br label %bb46
bb46:
  %t230 = load ptr, ptr %l112, !tbaa !29
  %t231 = load ptr, ptr %l123, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t230, ptr %t231)
  br label %bb47
bb47:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l8, !tbaa !24
  %t234 = load i64, ptr %l9, !tbaa !24
  %t235 = load i64, ptr %l10, !tbaa !24
  %t236 = load i64, ptr %l6, !tbaa !24
  %t242 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t232, i64 %t233, i64 %t234, i64 %t235, i64 %t236)
  store ptr %t242, ptr %l129
  br label %bb48
bb48:
  %t243 = load ptr, ptr %l129, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load %"compiler/source:Span", ptr %l2
  store { i64, [3 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 0
  store i64 12, ptr %t248
  %t250 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t245, 0
  %t252 = insertvalue { %"compiler/source:Span", ptr } %t250, ptr %t243, 1
  %t253 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t252, ptr %t253
  %t254 = load { i64, [3 x i64] }, ptr %t247
  %t256 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t254, ptr %t256
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t244, ptr %t256)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t35, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l28, !tbaa !24
  store i64 %t67, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store ptr %l3, ptr %l52, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t91, i32 %t98)
  store { i64, ptr } %t101, ptr %l57
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t109, { i64, ptr } %t108)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb12
bb23:
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t116, ptr %l62
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypes(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l65 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca i32
  %l76 = alloca %"compiler/typed:Local"
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i32
  %l100 = alloca i32
  %l105 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l15, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l20
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = load i32, ptr %l20, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l21
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l23
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 10
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l25
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l25)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l27
  br label %bb4
bb4:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l3
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l29, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t35, ptr %l31
  br label %bb5
bb5:
  %t36 = load i64, ptr %l29, !tbaa !24
  %t37 = load i64, ptr %l31, !tbaa !24
  %t38 = icmp ne i64 %t36, %t37
  br i1 %t38, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l34, !tbaa !24
  %t43 = load i64, ptr %l34, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = icmp sle i64 %t46, 2305843009213693951
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ad8923f011cb5acf_6f8a151e60866063)
  unreachable
bb11:
  %t49 = load i64, ptr %l34, !tbaa !24
  %t50 = mul i64 %t49, 4
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l4, !tbaa !27
  store i1 false, ptr %l5, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ad8923f011cb5acf_6f8a151e60866063)
  unreachable
bb13:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb18
bb15:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l46, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l46, !tbaa !24
  store i64 %t85, ptr %l43, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l43, !tbaa !24
  store i64 %t86, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t87 = load i64, ptr %l10, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb20, label %bb21
bb20:
  br label %bb33
bb21:
  br label %bb22
bb22:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t106, ptr %l65, !tbaa !27
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i32, ptr %t110, i64 %t107
  %t112 = load i32, ptr %t111, !tbaa !33
  %t115 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t105
  store i32 %t112, ptr %t117, !tbaa !33
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t118)
  store ptr %t120, ptr %l69
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l69, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Body", ptr %t121, i32 0, i32 7
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 %t124)
  store i32 %t127, ptr %l74
  br label %bb24
bb24:
  %t128 = load i32, ptr %l74, !tbaa !23
  %t129 = sext i32 %t128 to i64
  %t130 = load ptr, ptr %l71, !tbaa !29
  %t132 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t130, i64 %t129)
  store %"compiler/typed:Local" %t132, ptr %l76
  br label %bb25
bb25:
  %t133 = getelementptr %"compiler/typed:Local", ptr %l76, i32 0, i32 2
  %t134 = load i32, ptr %t133, !tbaa !23
  store i32 %t134, ptr %l12, !tbaa !23
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t136, ptr %l78, !tbaa !27
  %t137 = load i64, ptr %l11, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 %t137
  %t142 = load i32, ptr %t141, !tbaa !33
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t146 = icmp eq i32 %t142, %t143
  br i1 %t146, label %bb26, label %bb27
bb26:
  %t148 = load i32, ptr %l12, !tbaa !23
  %t149 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t152 = icmp ne i32 %t148, %t149
  store i1 %t152, ptr %l83, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb28
bb28:
  %t154 = load i1, ptr %l83, !tbaa !21
  br i1 %t154, label %bb29, label %bb30
bb29:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t156 = load i32, ptr %l12, !tbaa !23
  %t159 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t155
  store i32 %t156, ptr %t161, !tbaa !33
  store i1 true, ptr %l5, !tbaa !21
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l10, !tbaa !24
  br label %bb19
bb33:
  %t166 = load i1, ptr %l5, !tbaa !21
  br i1 %t166, label %bb34, label %bb35
bb34:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  store ptr %t173, ptr %l94, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  store i32 %t174, ptr %l95, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t180, { i64, ptr } %t181)
  store i32 %t184, ptr %l100
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 2
  %t191 = load i32, ptr %l1, !tbaa !23
  %t194 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDtorWritten(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t194, ptr %l105
  br label %bb37
bb37:
  %t195 = load ptr, ptr %l94, !tbaa !29
  %t196 = load i32, ptr %l95, !tbaa !23
  %t197 = load i32, ptr %l100, !tbaa !23
  %t198 = load i1, ptr %l105, !tbaa !21
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %t195, i32 %t196, i32 %t197, i1 %t198)
  br label %bb38
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i32
  %l29 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %l43 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l17
  br label %bb8
bb8:
  %t28 = load i64, ptr %l17, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t43 = insertvalue { i64 } undef, i64 %t39, 0
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 1
  store { i64 } %t43, ptr %t44
  %t45 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t45, ptr %l24
  %t46 = load i32, ptr %l4, !tbaa !23
  store i32 %t46, ptr %l25, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l29
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l33
  br label %bb11
bb11:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  %t67 = load ptr, ptr %l22, !tbaa !29
  %t68 = load { i64, [2 x i64] }, ptr %l24
  %t69 = load i32, ptr %l25, !tbaa !23
  %t70 = load i64, ptr %l29, !tbaa !24
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t67, { i64, [2 x i64] } %t68, i32 %t69, i64 %t70, %"compiler/source:Span" %t66)
  store i64 %t72, ptr %l36
  br label %bb12
bb12:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 20
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  br label %bb13
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l43
  br label %bb14
bb14:
  %t87 = load i1, ptr %l43, !tbaa !21
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 54
  %t91 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t90, i64 %t91, i1 true)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t94 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l37 = alloca ptr
  %t66 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 1, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l15
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t13, ptr %l4
  %t14 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:For3", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/ast:For3", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:For3", ptr %t37, i32 0, i32 3
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/ast:For3", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t31, %"compiler/source:Span" %t32, ptr %t36, { i64, ptr } %t40, ptr %t44)
  br label %bb4
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t51, i64 %t52, i64 %t53, i64 %t54, i64 %t55)
  store ptr %t61, ptr %l37
  br label %bb5
bb5:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 0
  store i64 11, ptr %t67
  %t69 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t64, 0
  %t71 = insertvalue { %"compiler/source:Span", ptr } %t69, ptr %t62, 1
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t66
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t73, ptr %t75
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t63, ptr %t75)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr ptr, ptr %t13, i64 %t10
  %t15 = load ptr, ptr %t14, !tbaa !39
  store ptr %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l11, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t32, %"compiler/source:Span" %t33, i64 %t34)
  store ptr %t35, ptr %l19
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l19, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l17 = alloca i32
  %l22 = alloca i32
  %l25 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca i1
  %l38 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca i1
  %l53 = alloca i1
  %l60 = alloca i32
  %l61 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i64
  %l81 = alloca i64
  %l88 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i1
  %l123 = alloca i1
  %l125 = alloca i1
  %l131 = alloca i32
  %l132 = alloca i1
  %l135 = alloca ptr
  %l140 = alloca i32
  %l142 = alloca i1
  %l145 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i1
  %l155 = alloca ptr
  %l160 = alloca i32
  %l163 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 12
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t11, i32 %a1)
  store i32 %t15, ptr %l17
  br label %bb4
bb4:
  %t16 = load i32, ptr %l17, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l22
  br label %bb5
bb5:
  %t27 = load i32, ptr %l22, !range !{i32 0, i32 33}
  store i32 %t27, ptr %l4
  %t28 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t30 = trunc i64 19 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l25, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l30
  br label %bb9
bb9:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = add i64 %t44, 1
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i32, ptr %l30, !tbaa !23
  %t50 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t47, i32 %t48, i64 %t46)
  store i1 %t50, ptr %l33
  br label %bb10
bb10:
  %t51 = load i1, ptr %l33, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
bb11:
  %t52 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t54 = trunc i64 22 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t59 = trunc i64 23 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l43
  br label %bb17
bb17:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i32, ptr %l43, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t74, i32 %t75, i64 %t73)
  store i1 %t77, ptr %l45
  br label %bb18
bb18:
  %t78 = load i1, ptr %l45, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb19:
  %t79 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t81 = trunc i64 18 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_968c62dd2cdb7cc9_e4aa23f03d53ae95)
  unreachable
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l53
  br label %bb29
bb29:
  %t95 = load i1, ptr %l53, !tbaa !21
  %t96 = xor i1 %t95, true
  br i1 %t96, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l60
  br label %bb33
bb33:
  %t109 = load i32, ptr %l60, !tbaa !23
  store i32 %t109, ptr %l5, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l61, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l66
  br label %bb34
bb34:
  %t121 = load ptr, ptr %l61, !tbaa !29
  %t122 = load i32, ptr %l66, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t121, i32 %t122)
  store { i64, ptr } %t123, ptr %l67
  br label %bb35
bb35:
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t124, ptr %l6, !tbaa !27
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l5, !tbaa !23
  %t134 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t130, i32 %t131)
  store i64 %t134, ptr %l72
  br label %bb36
bb36:
  %t135 = load i64, ptr %l72, !tbaa !24
  store i64 %t135, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l7, !tbaa !24
  %t138 = icmp sge i64 %t136, 0
  br i1 %t138, label %bb37, label %bb38
bb37:
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %l76, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 0
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/load:Loader", ptr %t147, i32 0, i32 10
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb40
bb39:
  %t152 = load i64, ptr %l76, !tbaa !24
  %t153 = load i64, ptr %l81, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  store i1 %t154, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  %t156 = load i1, ptr %l75, !tbaa !21
  br i1 %t156, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/load:Loader", ptr %t163, i32 0, i32 10
  %t166 = load i64, ptr %l7, !tbaa !24
  %t169 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t165, i64 %t166)
  store ptr %t169, ptr %l88
  br label %bb43
bb42:
  br label %bb84
bb43:
  %t170 = load ptr, ptr %l88, !tbaa !29
  %t172 = getelementptr %"compiler/load:Module", ptr %t170, i32 0, i32 2
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l8, !tbaa !27
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/load:Loader", ptr %t181, i32 0, i32 10
  %t184 = load i64, ptr %l7, !tbaa !24
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t183, i64 %t184)
  store ptr %t187, ptr %l96
  br label %bb44
bb44:
  %t188 = load ptr, ptr %l96, !tbaa !29
  %t190 = getelementptr %"compiler/load:Module", ptr %t188, i32 0, i32 3
  %t191 = load i1, ptr %t190, !tbaa !21
  br i1 %t191, label %bb45, label %bb46
bb45:
  %t193 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t195 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t193, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t195, ptr %l101
  br label %bb47
bb46:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb56
bb47:
  %t196 = load i1, ptr %l101, !tbaa !21
  br i1 %t196, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb51
bb49:
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t197, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t199, ptr %l104
  br label %bb50
bb50:
  %t200 = load i1, ptr %l104, !tbaa !21
  store i1 %t200, ptr %l102, !tbaa !21
  br label %bb51
bb51:
  %t201 = load i1, ptr %l102, !tbaa !21
  br i1 %t201, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb55
bb53:
  %t202 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t202, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t204, ptr %l107
  br label %bb54
bb54:
  %t205 = load i1, ptr %l107, !tbaa !21
  store i1 %t205, ptr %l105, !tbaa !21
  br label %bb55
bb55:
  %t206 = load i1, ptr %l105, !tbaa !21
  store i1 %t206, ptr %l99, !tbaa !21
  br label %bb56
bb56:
  %t207 = load i1, ptr %l99, !tbaa !21
  br i1 %t207, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t211 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t209, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t211, ptr %l110
  br label %bb60
bb60:
  %t212 = load i1, ptr %l110, !tbaa !21
  br i1 %t212, label %bb61, label %bb62
bb61:
  %t213 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t213, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t215, ptr %l113
  br label %bb63
bb62:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb64
bb63:
  %t216 = load i1, ptr %l113, !tbaa !21
  store i1 %t216, ptr %l111, !tbaa !21
  br label %bb64
bb64:
  %t217 = load i1, ptr %l111, !tbaa !21
  br i1 %t217, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb72
bb66:
  %t218 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t218, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t220, ptr %l116
  br label %bb67
bb67:
  %t221 = load i1, ptr %l116, !tbaa !21
  br i1 %t221, label %bb68, label %bb69
bb68:
  %t222 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t222, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t224, ptr %l119
  br label %bb70
bb69:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb71
bb70:
  %t225 = load i1, ptr %l119, !tbaa !21
  store i1 %t225, ptr %l117, !tbaa !21
  br label %bb71
bb71:
  %t226 = load i1, ptr %l117, !tbaa !21
  store i1 %t226, ptr %l114, !tbaa !21
  br label %bb72
bb72:
  %t227 = load i1, ptr %l114, !tbaa !21
  br i1 %t227, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t229 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t231 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t229, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t231, ptr %l122
  br label %bb76
bb76:
  %t232 = load i1, ptr %l122, !tbaa !21
  br i1 %t232, label %bb77, label %bb78
bb77:
  %t233 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t235 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t233, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t235, ptr %l125
  br label %bb79
bb78:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb80
bb79:
  %t236 = load i1, ptr %l125, !tbaa !21
  store i1 %t236, ptr %l123, !tbaa !21
  br label %bb80
bb80:
  %t237 = load i1, ptr %l123, !tbaa !21
  br i1 %t237, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb84:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  %t245 = load i32, ptr %l5, !tbaa !23
  %t248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t244, i32 %t245)
  store i32 %t248, ptr %l131
  br label %bb85
bb85:
  %t249 = load i32, ptr %l131, !range !{i32 0, i32 6}
  store i32 %t249, ptr %l9
  %t250 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t252 = trunc i64 0 to i32
  %t253 = icmp eq i32 %t250, %t252
  br i1 %t253, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l135, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 2
  %t262 = load i32, ptr %l3, !tbaa !23
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t261, i32 %t262)
  store i32 %t265, ptr %l140
  br label %bb89
bb89:
  %t266 = load i64, ptr %l2, !tbaa !24
  %t267 = load ptr, ptr %l135, !tbaa !29
  %t268 = load i32, ptr %l140, !tbaa !23
  %t270 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t267, i32 %t268, i64 %t266)
  store i1 %t270, ptr %l142
  br label %bb90
bb90:
  %t271 = load i1, ptr %l142, !tbaa !21
  store i1 %t271, ptr %l132, !tbaa !21
  br label %bb108
bb91:
  %t272 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t274 = trunc i64 1 to i32
  %t275 = icmp eq i32 %t272, %t274
  br i1 %t275, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l145, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = getelementptr %"compiler/generic:Program", ptr %t281, i32 0, i32 2
  %t284 = load i32, ptr %l3, !tbaa !23
  %t287 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t283, i32 %t284)
  store i32 %t287, ptr %l150
  br label %bb95
bb95:
  %t288 = load i64, ptr %l2, !tbaa !24
  %t289 = load ptr, ptr %l145, !tbaa !29
  %t290 = load i32, ptr %l150, !tbaa !23
  %t292 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t289, i32 %t290, i64 %t288)
  store i1 %t292, ptr %l152
  br label %bb96
bb96:
  %t293 = load i1, ptr %l152, !tbaa !21
  store i1 %t293, ptr %l132, !tbaa !21
  br label %bb108
bb97:
  %t294 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t296 = trunc i64 4 to i32
  %t297 = icmp eq i32 %t294, %t296
  br i1 %t297, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l155, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t305 = getelementptr %"compiler/generic:Program", ptr %t303, i32 0, i32 2
  %t306 = load i32, ptr %l3, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l160
  br label %bb101
bb101:
  %t310 = load i64, ptr %l2, !tbaa !24
  %t312 = add i64 %t310, 1
  %t313 = load ptr, ptr %l155, !tbaa !29
  %t314 = load i32, ptr %l160, !tbaa !23
  %t316 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t313, i32 %t314, i64 %t312)
  store i1 %t316, ptr %l163
  br label %bb102
bb102:
  %t317 = load i1, ptr %l163, !tbaa !21
  store i1 %t317, ptr %l132, !tbaa !21
  br label %bb108
bb103:
  br i1 true, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_9c0e2310e04cd1f8_9ba0cca7b5a93fa4)
  unreachable
bb108:
  %t318 = load i1, ptr %l132, !tbaa !21
  store i1 %t318, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca ptr
  %t3 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t6 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %a1, 0
  %t8 = insertvalue { %"compiler/source:Span", i32, i64 } %t6, i32 %t2, 1
  %t9 = insertvalue { %"compiler/source:Span", i32, i64 } %t8, i64 0, 2
  %t10 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t9, ptr %t10
  %t11 = load { i64, [5 x i64] }, ptr %t3
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t11, ptr %t13
  store ptr %t13, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l52 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = xor i1 %a2, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t10)
  store i32 %t12, ptr %l15
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb3:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = load i32, ptr %l15, !tbaa !23
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t15, ptr %l16
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l12, !tbaa !29
  %t17 = load i32, ptr %l16, !tbaa !23
  %t18 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load i1, ptr %l17, !tbaa !21
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l10, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l18, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t22)
  store i32 %t24, ptr %l20
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t25 = load ptr, ptr %l18, !tbaa !29
  %t26 = load i32, ptr %l20, !tbaa !23
  %t27 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t27, ptr %l21
  br label %bb10
bb10:
  %t28 = load i32, ptr %l21, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t30 = load ptr, ptr %l23, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l23, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l24, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l22, !tbaa !29
  br label %bb34
bb17:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 8}
  %t54 = icmp eq i64 %t52, 4
  store i1 %t54, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l32, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Elem", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l22, !tbaa !29
  br label %bb34
bb23:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t69 = load ptr, ptr %l40, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb24, label %bb25
bb24:
  %t72 = load ptr, ptr %l40, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 8}
  %t75 = icmp eq i64 %t73, 5
  store i1 %t75, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb26, label %bb27
bb26:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Payload", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l22, !tbaa !29
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store ptr null, ptr %l22, !tbaa !29
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a3ad144bf6dfe67e_aaa74880c72315a2)
  unreachable
bb34:
  %t89 = load ptr, ptr %l22, !tbaa !29
  store ptr %t89, ptr %l6, !tbaa !29
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  br i1 %t92, label %bb35, label %bb36
bb35:
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l52, !tbaa !29
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t97)
  store i32 %t99, ptr %l54
  br label %bb38
bb38:
  %t100 = load ptr, ptr %l52, !tbaa !29
  %t101 = load i32, ptr %l54, !tbaa !23
  %t102 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t102, ptr %l55
  br label %bb39
bb39:
  %t103 = load i32, ptr %l55, !tbaa !23
  store i32 %t103, ptr %l7, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load i32, ptr %l7, !tbaa !23
  %t111 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l59
  br label %bb40
bb40:
  %t112 = load i1, ptr %l59, !tbaa !21
  br i1 %t112, label %bb41, label %bb42
bb41:
  %t113 = load i32, ptr %l7, !tbaa !23
  store i32 %t113, ptr %l60, !tbaa !23
  br label %bb43
bb42:
  %t115 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t115, ptr %l60, !tbaa !23
  br label %bb43
bb43:
  %t117 = load i32, ptr %l60, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb34
bb5:
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp ne i64 %t24, 1
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l4, !tbaa !29
  store ptr %t29, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t30 = load ptr, ptr %l24, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 30}
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32 }, ptr %t40, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t44 = load i32, ptr %l6, !tbaa !23
  store i32 %t44, ptr %l23, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cf50a113ac2177e6_e3cc5936e852a452)
  unreachable
bb19:
  %t46 = load i32, ptr %l23, !tbaa !23
  store i32 %t46, ptr %l7, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l8, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t54 = load ptr, ptr %l34, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 30}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l35, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32 }, ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65
  store i32 %t66, ptr %l9, !tbaa !23
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t68 = load i32, ptr %l9, !tbaa !23
  store i32 %t68, ptr %l33, !tbaa !23
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i32 0, ptr %l33, !tbaa !23
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_baddfb655e016c47_d17e78f9e01d2853)
  unreachable
bb30:
  %t70 = load i32, ptr %l33, !tbaa !23
  store i32 %t70, ptr %l10, !tbaa !23
  %t71 = load i32, ptr %l7, !tbaa !23
  %t75 = icmp eq i32 %t71, %a2
  br i1 %t75, label %bb31, label %bb32
bb31:
  %t77 = load i32, ptr %l10, !tbaa !23
  %t81 = icmp eq i32 %t77, %a3
  store i1 %t81, ptr %l44, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb33
bb33:
  %t83 = load i1, ptr %l44, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3e69957d7270204c_dfbf9d9d846a9638)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 14
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 14
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l16
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb14
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t47, i64 %t48)
  store i32 %t51, ptr %l29
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l30
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t58 = icmp sgt i64 %t56, 0
  store i1 %t58, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9109cadfb541186e_2a46ab96c2b41f0a)
  unreachable
bb19:
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambdaErrs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca ptr
  %l51 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l64 = alloca i32
  %l65 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i32
  %l74 = alloca i32
  %l79 = alloca i32
  %l80 = alloca i32
  %l85 = alloca i32
  %l90 = alloca i64
  %l91 = alloca i32
  %rv = alloca ptr
  %t193 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 18}
  %t14 = icmp eq i64 %t12, 15
  store i1 %t14, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l3
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l5, !tbaa !29
  br label %bb8
bb7:
  br label %bb33
bb8:
  %t34 = load ptr, ptr %l5, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 3}
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t45, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb28
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l32
  br label %bb14
bb14:
  %t59 = load i32, ptr %l2, !tbaa !23
  %t60 = load i32, ptr %l32, !tbaa !23
  %t62 = icmp eq i32 %t60, %t59
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 14
  %t70 = load i32, ptr %l6, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t69, i64 %t72)
  store ptr %t75, ptr %l41
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l41, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  store ptr %t83, ptr %l45, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t89, i32 %t93)
  store i32 %t96, ptr %l51
  br label %bb19
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t102, i32 %t106)
  store i32 %t109, ptr %l57
  br label %bb20
bb20:
  %t110 = load i32, ptr %l2, !tbaa !23
  store i32 %t110, ptr %l58, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %t119, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t116, i32 %t120)
  store i32 %t123, ptr %l64
  br label %bb21
bb21:
  %t124 = load ptr, ptr %l45, !tbaa !29
  %t125 = load i32, ptr %l51, !tbaa !23
  %t126 = load i32, ptr %l57, !tbaa !23
  %t127 = load i32, ptr %l58, !tbaa !23
  %t128 = load i32, ptr %l64, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t124, i32 %t125, i32 %t126, i32 %t127, i32 %t128, i64 0, i1 false, i32 0, i64 0)
  store i32 %t129, ptr %l65
  br label %bb22
bb22:
  %t130 = load i32, ptr %l65, !tbaa !23
  %t131 = load ptr, ptr %l42, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Body", ptr %t131, i32 0, i32 2
  store i32 %t130, ptr %t132, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  store ptr %t138, ptr %l68, !tbaa !29
  %t139 = load i32, ptr %l4, !tbaa !23
  store i32 %t139, ptr %l69, !tbaa !23
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l4, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l74
  br label %bb23
bb23:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = load i32, ptr %l4, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l79
  br label %bb24
bb24:
  %t160 = load i32, ptr %l2, !tbaa !23
  store i32 %t160, ptr %l80, !tbaa !23
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/generic:Program", ptr %t164, i32 0, i32 2
  %t167 = load i32, ptr %l4, !tbaa !23
  %t170 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t166, i32 %t167)
  store i32 %t170, ptr %l85
  br label %bb25
bb25:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %l4, !tbaa !23
  %t180 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t176, i32 %t177)
  store i64 %t180, ptr %l90
  br label %bb26
bb26:
  %t181 = load ptr, ptr %l68, !tbaa !29
  %t182 = load i32, ptr %l69, !tbaa !23
  %t183 = load i32, ptr %l74, !tbaa !23
  %t184 = load i32, ptr %l79, !tbaa !23
  %t185 = load i32, ptr %l80, !tbaa !23
  %t186 = load i32, ptr %l85, !tbaa !23
  %t187 = load i64, ptr %l90, !tbaa !24
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefunc(ptr %v0, ptr %t181, i32 %t182, i32 %t183, i32 %t184, i32 %t185, i32 %t186, i64 %t187)
  store i32 %t188, ptr %l91
  br label %bb27
bb27:
  %t189 = load i32, ptr %l91, !tbaa !23
  %t190 = load %"compiler/source:Span", ptr %l3
  %t192 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [5 x i64] }, ptr %t193, i32 0, i32 0
  store i64 15, ptr %t194
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t190, 0
  %t198 = insertvalue { %"compiler/source:Span", i32, ptr } %t196, i32 %t189, 1
  %t200 = insertvalue { %"compiler/source:Span", i32, ptr } %t198, ptr %t192, 2
  %t201 = getelementptr { i64, [5 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t200, ptr %t201
  %t202 = load { i64, [5 x i64] }, ptr %t193
  %t204 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t202, ptr %t204
  store ptr %t204, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_24473ecab934ff5a_e5063e673d38f936)
  unreachable
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_1dc6773449e59e5b_c7fcef2f52138cd7)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca ptr
  %l22 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 40
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t4, ptr %t5)
  store i1 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp ne i32 %t10, %t11
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l15
  br label %bb7
bb6:
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t22, ptr %l12, !tbaa !23
  br label %bb8
bb7:
  %t24 = load i32, ptr %l15, !tbaa !23
  store i32 %t24, ptr %l12, !tbaa !23
  br label %bb8
bb8:
  %t25 = load i32, ptr %l12, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l17, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t27, ptr %t28, i32 %t25)
  store ptr %t34, ptr %l22
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t35)
  store %"compiler/source:Span" %t37, ptr %l24
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l17, !tbaa !29
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l24
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t38, ptr %t39, %"compiler/source:Span" %t40)
  store ptr %t41, ptr %l25
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l25, !tbaa !29
  store ptr %t42, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAssign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/check:laneVals"
  %l11 = alloca i32
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca %"compiler/check:laneVals"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l1
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %v1, ptr %t5, %"compiler/source:Span" %t6, ptr %t7)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l16, !tbaa !29
  store ptr %a5, ptr %l17, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l20
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = load i32, ptr %l20, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v2, ptr %v0, ptr %t20, ptr %t21, i32 %t22)
  store ptr %t23, ptr %l21
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l21, !tbaa !29
  store ptr %t24, ptr %l8, !tbaa !29
  %t25 = call %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %s0)
  store %"compiler/check:laneVals" %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load %"compiler/check:laneVals", ptr %l22
  store %"compiler/check:laneVals" %t26, ptr %l9
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l24
  store %"compiler/source:Span" %a2, ptr %l25
  store i32 %a3, ptr %l26
  %t31 = load i32, ptr %l6, !tbaa !23
  store i32 %t31, ptr %l27, !tbaa !23
  %t32 = load i64, ptr %l7, !tbaa !24
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l8, !tbaa !29
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t33, ptr %t34)
  store i64 %t37, ptr %l31
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l24
  %t40 = load %"compiler/source:Span", ptr %l25
  %t41 = load i32, ptr %l26, !range !{i32 0, i32 113}
  %t42 = load i32, ptr %l27, !tbaa !23
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %s0, ptr %t38, %"compiler/source:Span" %t39, %"compiler/source:Span" %t40, i32 %t41, i32 %t42, i64 %t43, i64 %t44, ptr %l9)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i32, ptr %l8, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/typed:Item"
  %l18 = alloca i32
  %l21 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %l33 = alloca i64
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l68 = alloca i64
  %l82 = alloca i32
  %l89 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load i32, ptr %l18, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t12, i32 %t13)
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t17 = load i64, ptr %l21, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sge i64 %t18, 64
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = sub i64 0, 1
  store i64 %t22, ptr %l24, !tbaa !65
  br label %bb5
bb4:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l26, !tbaa !24
  %t25 = load i64, ptr %l26, !tbaa !24
  %t26 = load i64, ptr %l26, !tbaa !24
  %t27 = shl i64 1, %t26
  %t29 = sub i64 %t27, 1
  store i64 %t29, ptr %l24, !tbaa !65
  br label %bb5
bb5:
  %t31 = load i64, ptr %l24, !tbaa !65
  store i64 %t31, ptr %l5, !tbaa !65
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t37, i32 %t38)
  store i64 %t41, ptr %l33
  br label %bb6
bb6:
  %t42 = load i64, ptr %l5, !tbaa !65
  %t43 = load i64, ptr %l33, !tbaa !65
  %t45 = and i64 %t43, %t42
  store i64 %t45, ptr %l6, !tbaa !65
  store ptr %a2, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l8, !tbaa !24
  store i64 %t49, ptr %l37, !tbaa !24
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v1, ptr %t50)
  store i64 %t52, ptr %l39
  br label %bb8
bb8:
  %t53 = load i64, ptr %l37, !tbaa !24
  %t54 = load i64, ptr %l39, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  br label %bb32
bb10:
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l7, !tbaa !29
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v1, ptr %v1, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l44
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l44, !tbaa !29
  store ptr %t64, ptr %l9, !tbaa !29
  %t65 = load ptr, ptr %l9, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Clause", ptr %t65, i32 0, i32 2
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t70, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l9, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Clause", ptr %t72, i32 0, i32 1
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l12, !tbaa !24
  br label %bb16
bb16:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb17, label %bb18
bb17:
  br label %bb30
bb18:
  br label %bb19
bb19:
  %t89 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t89, ptr %l56, !tbaa !27
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr %"compiler/typed:Item", ptr %t93, i64 %t90
  %t95 = load %"compiler/typed:Item", ptr %t94
  store %"compiler/typed:Item" %t95, ptr %l13
  %t97 = getelementptr %"compiler/typed:Item", ptr %l13, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = icmp eq i32 %t98, %t99
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t104 = getelementptr %"compiler/typed:Item", ptr %l13, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb22, label %bb23
bb21:
  br label %bb28
bb22:
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t109, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t111 = getelementptr %"compiler/typed:Item", ptr %l13, i32 0, i32 1
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = icmp slt i64 %t112, 64
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t116 = load i64, ptr %l6, !tbaa !65
  %t117 = getelementptr %"compiler/typed:Item", ptr %l13, i32 0, i32 1
  %t118 = load i64, ptr %t117, !tbaa !24
  store i64 %t118, ptr %l68, !tbaa !24
  %t119 = load i64, ptr %l68, !tbaa !24
  %t120 = load i64, ptr %l68, !tbaa !24
  %t121 = shl i64 1, %t120
  %t123 = xor i64 %t121, -1
  %t126 = and i64 %t116, %t123
  store i64 %t126, ptr %l6, !tbaa !65
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t128 = load i64, ptr %l11, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l11, !tbaa !24
  br label %bb16
bb30:
  br label %bb31
bb31:
  %t132 = load i64, ptr %l8, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l8, !tbaa !24
  br label %bb7
bb32:
  %t136 = load i64, ptr %l6, !tbaa !65
  %t138 = icmp eq i64 %t136, 0
  br i1 %t138, label %bb33, label %bb34
bb33:
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t140, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t142 = load i64, ptr %l6, !tbaa !65
  %t143 = load i64, ptr %l5, !tbaa !65
  %t146 = icmp eq i64 %t142, %t143
  br i1 %t146, label %bb36, label %bb37
bb36:
  %t148 = load i32, ptr %l3, !tbaa !23
  store i32 %t148, ptr %l82, !tbaa !23
  br label %bb39
bb37:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = load i32, ptr %l3, !tbaa !23
  %t157 = load i64, ptr %l6, !tbaa !65
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t155, i32 %t156, i64 %t157)
  store i32 %t161, ptr %l89
  br label %bb38
bb38:
  %t162 = load i32, ptr %l89, !tbaa !23
  store i32 %t162, ptr %l82, !tbaa !23
  br label %bb39
bb39:
  %t163 = load i32, ptr %l82, !tbaa !23
  store i32 %t163, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emakesOwner(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l32 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i1
  %l50 = alloca i32
  %l53 = alloca i1
  %l58 = alloca i32
  %l63 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l6, !tbaa !29
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load i32, ptr %l10, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb3
bb3:
  %t26 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t28 = trunc i64 25 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  store ptr %t36, ptr %l20, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  store i32 %t37, ptr %l21, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l26
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t48 = load ptr, ptr %l20, !tbaa !29
  %t49 = load i32, ptr %l21, !tbaa !23
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t48, i32 %t49, i32 %t50)
  store i1 %t51, ptr %l27
  br label %bb7
bb7:
  %t52 = load i1, ptr %l27, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
bb8:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l32
  br label %bb9
bb9:
  %t63 = load i32, ptr %l32, !range !{i32 0, i32 33}
  %t65 = trunc i64 18 to i32
  %t66 = icmp eq i32 %t63, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb10, label %bb11
bb10:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  store ptr %t75, ptr %l38, !tbaa !29
  %t76 = load i32, ptr %l3, !tbaa !23
  store i32 %t76, ptr %l39, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l2, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l44
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t87 = load ptr, ptr %l38, !tbaa !29
  %t88 = load i32, ptr %l39, !tbaa !23
  %t89 = load i32, ptr %l44, !tbaa !23
  %t90 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t87, i32 %t88, i32 %t89)
  store i1 %t90, ptr %l45
  br label %bb13
bb13:
  %t91 = load i1, ptr %l45, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
bb14:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l50
  br label %bb15
bb15:
  %t102 = load i32, ptr %l50, !range !{i32 0, i32 33}
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l58
  br label %bb18
bb17:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb20
bb18:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l2, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l63
  br label %bb19
bb19:
  %t127 = load i32, ptr %l58, !tbaa !23
  %t128 = load i32, ptr %l63, !tbaa !23
  %t129 = icmp eq i32 %t127, %t128
  store i1 %t129, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t131 = load i1, ptr %l53, !tbaa !21
  store i1 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l22 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l52 = alloca i64
  %l57 = alloca i64
  %l63 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l79 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l89 = alloca ptr
  %s2 = alloca %olang.scope
  %t77 = alloca { i64, [3 x i64] }, align 8
  %t157 = alloca { i64, [3 x i64] }, align 8
  %t183 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store i1 %t12, ptr %l14
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i1, ptr %l14, !tbaa !21
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, ptr %t17)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i64 %t30, ptr %l22
  br label %bb11
bb10:
  br label %bb23
bb11:
  %t31 = load i64, ptr %l22, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Match", ptr %t36, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l4, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %s2, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l30
  br label %bb15
bb15:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l5
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Case", ptr %t51, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l35, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t62, ptr %l37
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Case", ptr %t64, i32 0, i32 4
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Case", ptr %t68, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v0, ptr %t63, { i64, ptr } %t67, i32 1, %"compiler/source:Span" %t71)
  store ptr %t76, ptr %l44
  br label %bb18
bb17:
  br label %bb21
bb18:
  store { i64, [3 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 0
  store i64 11, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l37
  %t80 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t79, 0
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t82 = insertvalue { %"compiler/source:Span", ptr } %t80, ptr %t81, 1
  %t83 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t82, ptr %t83
  %t84 = load { i64, [3 x i64] }, ptr %t77
  %t86 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t84, ptr %t86
  %t87 = load ptr, ptr %l36, !tbaa !29
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v0, ptr %v0, ptr %t87, ptr %t86)
  store ptr %t89, ptr %l47
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l35, !tbaa !29
  %t91 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t90, ptr %t91)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunbindCase(ptr %v0, ptr %s2, ptr %t92, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb23:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMatch(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i64 %t100, ptr %l52
  br label %bb24
bb24:
  %t101 = load i64, ptr %l52, !tbaa !24
  store i64 %t101, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = icmp eq i64 %t102, -2
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  store i64 %t110, ptr %l57
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l6, !tbaa !24
  br label %bb28
bb28:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = icmp ne i64 %t112, -2
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb31, label %bb32
bb30:
  br label %bb40
bb31:
  br label %ret
bb32:
  br label %bb33
bb33:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:Match", ptr %t120, i32 0, i32 3
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  store ptr %t129, ptr %l7, !tbaa !29
  %t131 = load ptr, ptr %l7, !tbaa !29
  %t133 = getelementptr %"compiler/ast:Case", ptr %t131, i32 0, i32 4
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb34, label %bb35
bb34:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l70, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l71, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t142, ptr %l72
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 4
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t148 = load ptr, ptr %l7, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Case", ptr %t148, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  %t156 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v0, ptr %t143, { i64, ptr } %t147, i32 1, %"compiler/source:Span" %t151)
  store ptr %t156, ptr %l79
  br label %bb36
bb35:
  br label %bb39
bb36:
  store { i64, [3 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [3 x i64] }, ptr %t157, i32 0, i32 0
  store i64 11, ptr %t158
  %t159 = load %"compiler/source:Span", ptr %l72
  %t160 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t159, 0
  %t161 = load ptr, ptr %l79, !tbaa !29
  %t162 = insertvalue { %"compiler/source:Span", ptr } %t160, ptr %t161, 1
  %t163 = getelementptr { i64, [3 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t162, ptr %t163
  %t164 = load { i64, [3 x i64] }, ptr %t157
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t164, ptr %t166
  %t167 = load ptr, ptr %l71, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v0, ptr %v0, ptr %t167, ptr %t166)
  store ptr %t169, ptr %l82
  br label %bb37
bb37:
  %t170 = load ptr, ptr %l70, !tbaa !29
  %t171 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t170, ptr %t171)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
bb40:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l83, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t173, ptr %l84
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l1
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t177 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t174, %"compiler/source:Span" %t175, ptr %t176, i1 false, i32 %t177)
  store ptr %t182, ptr %l89
  br label %bb41
bb41:
  store { i64, [3 x i64] } zeroinitializer, ptr %t183
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 0
  store i64 2, ptr %t184
  %t185 = load %"compiler/source:Span", ptr %l84
  %t186 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t185, 0
  %t187 = load ptr, ptr %l89, !tbaa !29
  %t188 = insertvalue { %"compiler/source:Span", ptr } %t186, ptr %t187, 1
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t188, ptr %t189
  %t190 = load { i64, [3 x i64] }, ptr %t183
  %t192 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t190, ptr %t192
  %t193 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t193, ptr %t192)
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementions(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i1
  %l21 = alloca i1
  %l27 = alloca i32
  %l32 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l53 = alloca i1
  %l59 = alloca ptr
  %l64 = alloca i32
  %l68 = alloca i1
  %l71 = alloca ptr
  %l76 = alloca i32
  %l80 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t20 = load i32, ptr %l2, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t18, i32 %t19, i32 %t20)
  store i1 %t24, ptr %l21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l21, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l27
  br label %bb11
bb11:
  %t37 = load i32, ptr %l27, !range !{i32 0, i32 33}
  store i32 %t37, ptr %l4
  %t38 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t40 = trunc i64 18 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l32, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l37
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load i32, ptr %l37, !tbaa !23
  %t61 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t59, i32 %t60)
  store { i64, ptr } %t61, ptr %l38
  br label %bb16
bb16:
  %t62 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  br label %bb20
bb20:
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t75, ptr %l45, !tbaa !27
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i32, ptr %t79, i64 %t76
  %t81 = load i32, ptr %t80, !tbaa !33
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l2, !tbaa !23
  %t86 = load i64, ptr %l3, !tbaa !24
  %t88 = add i64 %t86, 1
  %t93 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementions(ptr %v0, ptr %t83, i32 %t81, i32 %t85, i64 %t88)
  store i1 %t93, ptr %l53
  br label %bb21
bb21:
  %t94 = load i1, ptr %l53, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l6, !tbaa !24
  br label %bb17
bb26:
  br label %bb44
bb27:
  %t100 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t102 = trunc i64 19 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l1, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l64
  br label %bb31
bb31:
  %t116 = load i32, ptr %l2, !tbaa !23
  %t117 = load i64, ptr %l3, !tbaa !24
  %t119 = add i64 %t117, 1
  %t120 = load ptr, ptr %l59, !tbaa !29
  %t121 = load i32, ptr %l64, !tbaa !23
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementions(ptr %v0, ptr %t120, i32 %t121, i32 %t116, i64 %t119)
  store i1 %t124, ptr %l68
  br label %bb32
bb32:
  %t125 = load i1, ptr %l68, !tbaa !21
  store i1 %t125, ptr %rv
  br label %ret
bb33:
  %t126 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t128 = trunc i64 20 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l71, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %l1, !tbaa !23
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l76
  br label %bb37
bb37:
  %t142 = load i32, ptr %l2, !tbaa !23
  %t143 = load i64, ptr %l3, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load ptr, ptr %l71, !tbaa !29
  %t147 = load i32, ptr %l76, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementions(ptr %v0, ptr %t146, i32 %t147, i32 %t142, i64 %t145)
  store i1 %t150, ptr %l80
  br label %bb38
bb38:
  %t151 = load i1, ptr %l80, !tbaa !21
  store i1 %t151, ptr %rv
  br label %ret
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_a227993f85dd5ea2_8a35cef040514d1e)
  unreachable
bb44:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i1
  %l20 = alloca i32
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l50 = alloca %"compiler/generic:Binding"
  %l52 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i64
  %l83 = alloca i32
  %l84 = alloca i64
  %l85 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t4, i64 %t5)
  store i1 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t14, i64 %t15)
  store i32 %t18, ptr %l20
  br label %bb5
bb5:
  %t19 = load i32, ptr %l20, !tbaa !23
  store i32 %t19, ptr %l3, !tbaa !23
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t20)
  store i64 %t22, ptr %l22
  br label %bb6
bb6:
  %t23 = load i64, ptr %l22, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l26
  br label %bb7
bb7:
  %t32 = load i64, ptr %l26, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l29, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t41, i64 %t42, i32 0)
  store i64 %t45, ptr %l33
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t47 = load i64, ptr %l33, !tbaa !24
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t48, ptr %l34
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i64, ptr %l34, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  store ptr %t55, ptr %l37, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l3, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l42
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l37, !tbaa !29
  %t67 = load i32, ptr %l42, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t66, i32 %t67)
  store { i64, ptr } %t68, ptr %l43
  br label %bb14
bb14:
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t69, ptr %l6, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t74 = icmp eq i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t78 = load i64, ptr %l5, !tbaa !24
  %t81 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t77, i64 %t78)
  store %"compiler/generic:Binding" %t81, ptr %l50
  br label %bb18
bb18:
  %t82 = load %"compiler/generic:Binding", ptr %l50
  store %"compiler/generic:Binding" %t82, ptr %l7
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t84, ptr %l52, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 0
  %t88 = load i32, ptr %t87, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t83, i32 %t88, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb19
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t97, ptr %l7)
  br label %bb20
bb20:
  %t100 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  %t107 = load i64, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb22, label %bb23
bb22:
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t115, ptr %l66, !tbaa !27
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i32, ptr %t119, i64 %t116
  %t121 = load i32, ptr %t120, !tbaa !33
  %t124 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t127 = icmp eq i32 %t121, %t124
  br i1 %t127, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t130 = load i64, ptr %l9, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l9, !tbaa !24
  br label %bb21
bb29:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l75, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l77, !tbaa !29
  %t139 = load i64, ptr %l1, !tbaa !24
  store i64 %t139, ptr %l78, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t145, { i64, ptr } %t147)
  store i32 %t150, ptr %l83
  br label %bb30
bb30:
  %t151 = load ptr, ptr %l77, !tbaa !29
  %t152 = load i64, ptr %l78, !tbaa !24
  %t153 = load i32, ptr %l83, !tbaa !23
  %t154 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t151, i64 %t152, i32 %t153)
  store i64 %t154, ptr %l84
  br label %bb31
bb31:
  %t155 = load ptr, ptr %l75, !tbaa !29
  %t156 = load i64, ptr %l84, !tbaa !24
  %t157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t155, i64 %t156)
  store i64 %t157, ptr %l85
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t158 = load i64, ptr %l85, !tbaa !24
  store i64 %t158, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l26 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l35 = alloca i32
  %l38 = alloca %"compiler/source:Span"
  %l42 = alloca i1
  %l44 = alloca %"compiler/source:Span"
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t24, i32 0, i32 2
  %t26 = load i1, ptr %t25
  store i1 %t26, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  br label %bb40
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load i1, ptr %l5, !tbaa !21
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 -1, i32 -1)
  store %"compiler/source:Span" %t32, ptr %l18
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t33 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t33, ptr %rv
  br label %ret
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t34, ptr %t35)
  store i1 %t38, ptr %l21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 -1, i32 -1)
  store %"compiler/source:Span" %t40, ptr %l22
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t41 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t41, ptr %rv
  br label %ret
bb14:
  %t42 = load i32, ptr %l2, !tbaa !23
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t46 = icmp ne i32 %t42, %t43
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l2, !tbaa !23
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l29
  br label %bb17
bb16:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb22
bb17:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb21
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l35
  br label %bb20
bb20:
  %t64 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t66 = trunc i64 25 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l30, !tbaa !21
  br label %bb21
bb21:
  %t69 = load i1, ptr %l30, !tbaa !21
  store i1 %t69, ptr %l26, !tbaa !21
  br label %bb22
bb22:
  %t70 = load i1, ptr %l26, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 -1, i32 -1)
  store %"compiler/source:Span" %t71, ptr %l38
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  %t72 = load %"compiler/source:Span", ptr %l38
  store %"compiler/source:Span" %t72, ptr %rv
  br label %ret
bb26:
  %t73 = load i32, ptr %l2, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb27, label %bb28
bb27:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l44
  br label %bb29
bb28:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb30
bb29:
  %t82 = getelementptr %"compiler/source:Span", ptr %l44, i32 0, i32 1
  %t83 = load i32, ptr %t82, !tbaa !23
  %t84 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = add i32 %t85, 3
  %t90 = icmp sgt i32 %t83, %t87
  store i1 %t90, ptr %l42, !tbaa !21
  br label %bb30
bb30:
  %t92 = load i1, ptr %l42, !tbaa !21
  br i1 %t92, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t97 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t97, ptr %l52
  br label %bb33
bb32:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb34
bb33:
  %t98 = load i1, ptr %l52, !tbaa !21
  store i1 %t98, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t99 = load i1, ptr %l49, !tbaa !21
  br i1 %t99, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 -1, i32 -1)
  store %"compiler/source:Span" %t100, ptr %l53
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  %t101 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t101, ptr %rv
  br label %ret
bb38:
  %t102 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = add i32 %t105, 3
  %t110 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t103, i32 %t107)
  store %"compiler/source:Span" %t110, ptr %l57
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s1)
  %t111 = load %"compiler/source:Span", ptr %l57
  store %"compiler/source:Span" %t111, ptr %rv
  br label %ret
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb45
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t112 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 -1, i32 -1)
  store %"compiler/source:Span" %t112, ptr %l58
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  %t113 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t113, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_5a62b0635aab9a02_96142af7f6ac351e)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l21
  br label %bb13
bb13:
  %t42 = load i64, ptr %l21, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_77892b47b9a99b47_46cd468a4d441f7b)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/generic:Origin"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l21 = alloca i64
  %l25 = alloca %"compiler/generic:Origin"
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l46 = alloca { i64, [3 x i64] }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l55 = alloca %"compiler/diagmsg:Msg"
  %l56 = alloca i64
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i64
  %l81 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t78 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i32, ptr %l14, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundBy(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t21 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v2, ptr %t15, %"compiler/source:Span" %t16, %"compiler/diagmsg:Msg" %a4)
  store i64 %t21, ptr %l21
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l21, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t26, i64 %t27)
  store %"compiler/generic:Origin" %t30, ptr %l25
  br label %bb7
bb7:
  %t31 = load %"compiler/generic:Origin", ptr %l25
  store %"compiler/generic:Origin" %t31, ptr %l6
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l26, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l32
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t45, i64 %t46)
  store ptr %t47, ptr %l33
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l33, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t52, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l7, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Origin", ptr %l6, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/generic:Origin", ptr %l6, i32 0, i32 1
  %t69 = getelementptr %"compiler/source:Span", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t73 = getelementptr %"compiler/generic:Origin", ptr %l6, i32 0, i32 1
  %t74 = getelementptr %"compiler/source:Span", ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 0
  store i64 3, ptr %t79
  %t81 = insertvalue { i64, i64, i64 } undef, i64 %t67, 0
  %t83 = insertvalue { i64, i64, i64 } %t81, i64 %t72, 1
  %t85 = insertvalue { i64, i64, i64 } %t83, i64 %t77, 2
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  store { i64, i64, i64 } %t85, ptr %t86
  %t87 = load { i64, [3 x i64] }, ptr %t78
  store { i64, [3 x i64] } %t87, ptr %l46
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t88, ptr %l47, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l48, !tbaa !27
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l49, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l52
  br label %bb11
bb11:
  %t96 = load ptr, ptr %l49, !tbaa !29
  %t97 = load i32, ptr %l52, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t96, i32 %t97)
  store { i64, ptr } %t98, ptr %l53
  br label %bb12
bb12:
  %t99 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = extractvalue { i64, ptr } %t99, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t109 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenericNeeds(ptr %v0, ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t106, { i64, ptr } %t107, { i64, ptr } %t105)
  store %"compiler/diagmsg:Msg" %t109, ptr %l55
  br label %bb13
bb13:
  %t110 = load ptr, ptr %l40, !tbaa !29
  %t111 = load { i64, [3 x i64] }, ptr %l46
  %t112 = load %"compiler/diagmsg:Msg", ptr %l55
  %t113 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBare(ptr %v0, ptr %s0, ptr %t110, { i64, [3 x i64] } %t111, %"compiler/diagmsg:Msg" %t112)
  store i64 %t113, ptr %l56
  br label %bb14
bb14:
  %t114 = load i64, ptr %l56, !tbaa !24
  store i64 %t114, ptr %l8, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l58
  br label %bb15
bb15:
  %t118 = load i64, ptr %l58, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp sge i64 %t119, 0
  br i1 %t121, label %bb16, label %bb17
bb16:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l62, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  store ptr %t127, ptr %l64, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i64, ptr %l9, !tbaa !24
  %t135 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l68
  br label %bb18
bb17:
  %t136 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t136, ptr %l61, !tbaa !27
  br label %bb21
bb18:
  %t138 = load ptr, ptr %l64, !tbaa !29
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t138, i64 %t139)
  store ptr %t140, ptr %l69
  br label %bb19
bb19:
  %t141 = load ptr, ptr %l69, !tbaa !29
  %t143 = getelementptr %"compiler/ast:Func", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = load ptr, ptr %l62, !tbaa !29
  %t147 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t145, i32 %t144)
  store { i64, ptr } %t147, ptr %l72
  br label %bb20
bb20:
  %t148 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t148, ptr %l61, !tbaa !27
  br label %bb21
bb21:
  %t149 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t149, ptr %l10, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/load:Loader", ptr %t156, i32 0, i32 4
  %t159 = load ptr, ptr %t158, !tbaa !29
  store ptr %t159, ptr %l77, !tbaa !29
  %t160 = load i64, ptr %l8, !tbaa !24
  store i64 %t160, ptr %l78, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l1
  %t165 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t161, %"compiler/source:Span" %t162)
  store { i64, [3 x i64] } %t165, ptr %l81
  br label %bb22
bb22:
  %t166 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t170 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGenericNeeds(ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t166, { i64, ptr } %t167)
  store %"compiler/diagmsg:Msg" %t170, ptr %l84
  br label %bb23
bb23:
  %t171 = load ptr, ptr %l77, !tbaa !29
  %t172 = load i64, ptr %l78, !tbaa !24
  %t173 = load { i64, [3 x i64] }, ptr %l81
  %t174 = load %"compiler/diagmsg:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t171, i64 %t172, { i64, [3 x i64] } %t173, %"compiler/diagmsg:Msg" %t174)
  br label %bb24
bb24:
  %t175 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t175, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/check:nullNarrow"
  %l10 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"compiler/check:nullNarrow"
  %l23 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t10, ptr %l10
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 50
  store ptr %t13, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l13, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l15
  br label %bb6
bb6:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t25, i64 %t26)
  store %"compiler/check:nullNarrow" %t29, ptr %l20
  br label %bb10
bb10:
  %t30 = load %"compiler/check:nullNarrow", ptr %l20
  store %"compiler/check:nullNarrow" %t30, ptr %l4
  %t31 = getelementptr %"compiler/check:nullNarrow", ptr %l4, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = getelementptr %"compiler/check:nullNarrow", ptr %l4, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %t37, { i64, ptr } %t38)
  store i1 %t41, ptr %l26
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb14
bb13:
  %t42 = load i1, ptr %l26, !tbaa !21
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l3, !tbaa !24
  br label %bb5
bb19:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l79 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i32
  %l87 = alloca i1
  %l91 = alloca ptr
  %l95 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca i64
  %l109 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i64
  %l137 = alloca ptr
  %l146 = alloca i1
  %l150 = alloca ptr
  %l155 = alloca i1
  %l158 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i64
  %l163 = alloca i64
  %l169 = alloca i64
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca i64
  %l181 = alloca ptr
  %l183 = alloca i64
  %l187 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l189 = alloca i64
  %l191 = alloca i64
  %l196 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i32
  %l207 = alloca ptr
  %l209 = alloca i64
  %l210 = alloca i64
  %l221 = alloca i64
  %l224 = alloca i64
  %l246 = alloca i64
  %l250 = alloca i64
  %l254 = alloca i64
  %l257 = alloca i64
  %l277 = alloca i64
  %l279 = alloca i1
  %l282 = alloca i64
  %l294 = alloca ptr
  %l297 = alloca i64
  %l305 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l306 = alloca i64
  %l309 = alloca i64
  %l310 = alloca i32
  %l319 = alloca i64
  %l323 = alloca i64
  %l326 = alloca i64
  %l346 = alloca i64
  %l347 = alloca ptr
  %l348 = alloca ptr
  %l351 = alloca i64
  %l352 = alloca i64
  %l361 = alloca i64
  %l365 = alloca i64
  %l369 = alloca i64
  %l372 = alloca i64
  %l392 = alloca i1
  %l395 = alloca i64
  %l397 = alloca i1
  %l400 = alloca i64
  %l405 = alloca i64
  %l414 = alloca i64
  %l417 = alloca i64
  %l438 = alloca ptr
  %l441 = alloca i64
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l64
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l65
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 29
  store ptr %t7, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l68, !tbaa !24
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l70
  br label %bb4
bb4:
  %t13 = load i64, ptr %l68, !tbaa !24
  %t14 = load i64, ptr %l70, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t19, i64 %t20)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t23, ptr %l75
  br label %bb8
bb8:
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l75
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l7
  %t25 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = icmp ne i64 %t26, %t27
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb30
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 27
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t38 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t34, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l84
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb13, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l83
  br label %bb12
bb12:
  %t43 = load i64, ptr %l83, !tbaa !24
  store i64 %t43, ptr %l79, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l79, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l79, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb19
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 14
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l91
  br label %bb18
bb18:
  %t56 = load ptr, ptr %l91, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 11
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  store i1 %t61, ptr %l87, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l87, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb23
bb21:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t64)
  store i1 %t67, ptr %l98
  br label %bb22
bb22:
  %t68 = load i1, ptr %l98, !tbaa !21
  store i1 %t68, ptr %l95, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l95, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  store ptr %l4, ptr %l99, !tbaa !29
  %t70 = load i64, ptr %l8, !tbaa !24
  store i64 %t70, ptr %l100, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t72, ptr %l102
  br label %bb27
bb27:
  %t73 = load ptr, ptr %l99, !tbaa !29
  %t74 = load i64, ptr %l100, !tbaa !24
  %t75 = load i64, ptr %l102, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t73, i64 %t74, i64 %t75)
  br label %bb28
bb28:
  %t76 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t76)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb3
bb31:
  store i64 0, ptr %l9, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 14
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l109
  br label %bb32
bb32:
  %t88 = load i64, ptr %l109, !tbaa !24
  store i64 %t88, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb33, label %bb34
bb33:
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb38
bb35:
  %t99 = load i64, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = sub i64 %t99, %t100
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t109 = sub i64 %t107, 1
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = sdiv i64 %t109, %t110
  store i64 %t113, ptr %l116, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb37
bb37:
  %t115 = load i64, ptr %l116, !tbaa !24
  store i64 %t115, ptr %l113, !tbaa !24
  br label %bb38
bb38:
  %t116 = load i64, ptr %l113, !tbaa !24
  store i64 %t116, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb40, label %bb41
bb40:
  br label %bb68
bb41:
  br label %bb42
bb42:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = mul i64 %t126, %t127
  %t133 = add i64 %t125, %t130
  store i64 %t133, ptr %l14, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 14
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l137
  br label %bb43
bb43:
  %t142 = load ptr, ptr %l137, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 1
  %t145 = load { i64, [2 x i64] }, ptr %t144
  store { i64, [2 x i64] } %t145, ptr %l15
  %t147 = load { i64, [2 x i64] }, ptr %l15
  %t149 = extractvalue { i64, [2 x i64] } %t147, 0
  %t150 = icmp eq i64 %t149, 6
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = getelementptr { i64, [2 x i64] }, ptr %l15, i32 0, i32 1
  %t153 = getelementptr { i64, i32 }, ptr %t152, i32 0, i32 0
  %t154 = load i64, ptr %t153
  store i64 %t154, ptr %l16, !tbaa !24
  br label %bb46
bb45:
  br label %bb61
bb46:
  %t156 = load i64, ptr %l16, !tbaa !24
  %t157 = load i64, ptr %l1, !tbaa !24
  %t160 = icmp eq i64 %t156, %t157
  br i1 %t160, label %bb47, label %bb48
bb47:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 14
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l150
  br label %bb49
bb48:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb50
bb49:
  %t169 = load ptr, ptr %l150, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 11
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  %t176 = xor i1 %t174, true
  store i1 %t176, ptr %l146, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l146, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load i64, ptr %l14, !tbaa !24
  %t182 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t179)
  store i1 %t182, ptr %l158
  br label %bb53
bb52:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb54
bb53:
  %t183 = load i1, ptr %l158, !tbaa !21
  %t184 = xor i1 %t183, true
  store i1 %t184, ptr %l155, !tbaa !21
  br label %bb54
bb54:
  %t186 = load i1, ptr %l155, !tbaa !21
  br i1 %t186, label %bb55, label %bb56
bb55:
  store ptr %l4, ptr %l160, !tbaa !29
  %t187 = load i64, ptr %l14, !tbaa !24
  store i64 %t187, ptr %l161, !tbaa !24
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t189, ptr %l163
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t190 = load ptr, ptr %l160, !tbaa !29
  %t191 = load i64, ptr %l161, !tbaa !24
  %t192 = load i64, ptr %l163, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t190, i64 %t191, i64 %t192)
  br label %bb58
bb58:
  %t193 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t193)
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_eb65b3680edb0345_685145072e457a11)
  unreachable
bb66:
  br label %bb67
bb67:
  %t196 = load i64, ptr %l13, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l13, !tbaa !24
  br label %bb39
bb68:
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t201, ptr %l169
  br label %bb69
bb69:
  %t202 = load i64, ptr %l169, !tbaa !24
  store i64 %t202, ptr %l17, !tbaa !24
  %t203 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t203, ptr %l170
  br label %bb70
bb70:
  %t204 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %l18
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l171
  br label %bb71
bb71:
  %t206 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l171
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l19
  store ptr %l3, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb72
bb72:
  %t208 = load i64, ptr %l21, !tbaa !24
  store i64 %t208, ptr %l173, !tbaa !24
  %t209 = load ptr, ptr %l20, !tbaa !29
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t209)
  store i64 %t211, ptr %l175
  br label %bb73
bb73:
  %t212 = load i64, ptr %l173, !tbaa !24
  %t213 = load i64, ptr %l175, !tbaa !24
  %t214 = icmp slt i64 %t212, %t213
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb74, label %bb75
bb74:
  br label %bb95
bb75:
  br label %bb76
bb76:
  %t218 = load ptr, ptr %l20, !tbaa !29
  %t219 = load i64, ptr %l21, !tbaa !24
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t218, i64 %t219)
  store i64 %t222, ptr %l180
  br label %bb77
bb77:
  %t223 = load i64, ptr %l180, !tbaa !24
  store i64 %t223, ptr %l22, !tbaa !24
  store ptr %l18, ptr %l181, !tbaa !29
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t225, ptr %l183
  br label %bb78
bb78:
  %t226 = load ptr, ptr %l181, !tbaa !29
  %t227 = load i64, ptr %l183, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t226, i64 %t227)
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l1, !tbaa !24
  %t230 = load i64, ptr %l22, !tbaa !24
  %t234 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %s14, ptr %t228, i64 %t229, i64 %t230)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l187
  br label %bb80
bb80:
  %t235 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l187
  %t236 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %t236
  store ptr %t236, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb81
bb81:
  %t238 = load i64, ptr %l24, !tbaa !24
  store i64 %t238, ptr %l189, !tbaa !24
  %t239 = load ptr, ptr %l23, !tbaa !29
  %t241 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s14, ptr %t239)
  store i64 %t241, ptr %l191
  br label %bb82
bb82:
  %t242 = load i64, ptr %l189, !tbaa !24
  %t243 = load i64, ptr %l191, !tbaa !24
  %t244 = icmp slt i64 %t242, %t243
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb83, label %bb84
bb83:
  br label %bb93
bb84:
  br label %bb85
bb85:
  %t248 = load ptr, ptr %l23, !tbaa !29
  %t249 = load i64, ptr %l24, !tbaa !24
  %t252 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s14, ptr %t248, i64 %t249)
  store i64 %t252, ptr %l196
  br label %bb86
bb86:
  %t253 = load i64, ptr %l196, !tbaa !24
  store ptr %l19, ptr %l197, !tbaa !29
  %t257 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t253)
  %t258 = extractvalue { i32, i64 } %t257, 1
  %t259 = extractvalue { i32, i64 } %t257, 0
  store i32 %t259, ptr %l202
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb88, label %ok.261, !prof !99
ok.261:
  store i64 %t258, ptr %l201
  br label %bb87
bb87:
  %t262 = load i64, ptr %l201, !tbaa !24
  store i64 %t262, ptr %l198, !tbaa !24
  br label %bb90
bb88:
  br label %bb89
bb89:
  store i64 -1, ptr %l198, !tbaa !24
  br label %bb90
bb90:
  %t263 = load ptr, ptr %l197, !tbaa !29
  %t264 = load i64, ptr %l198, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t263, i64 %t264)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t265 = load i64, ptr %l24, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l24, !tbaa !24
  br label %bb81
bb93:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb94:
  %t269 = load i64, ptr %l21, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l21, !tbaa !24
  br label %bb72
bb95:
  store ptr %l18, ptr %l207, !tbaa !29
  %t274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t274, ptr %l209
  br label %bb96
bb96:
  %t275 = load ptr, ptr %l207, !tbaa !29
  %t276 = load i64, ptr %l209, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t275, i64 %t276)
  br label %bb97
bb97:
  %t277 = load i64, ptr %l17, !tbaa !24
  store i64 %t277, ptr %l210, !tbaa !24
  %t278 = load i64, ptr %l210, !tbaa !24
  %t279 = icmp sge i64 %t278, 0
  br i1 %t279, label %bb98, label %bb99
bb98:
  %t281 = load i64, ptr %l210, !tbaa !24
  %t282 = mul i64 %t281, 1
  %t283 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t282)
  %t284 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  store { i64, ptr } %t285, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_becd3eb77e076db3_2d856a700a1e74b7)
  unreachable
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t287 = load i64, ptr %l27, !tbaa !24
  %t288 = load i64, ptr %l17, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s18)
  br label %bb232
bb102:
  br label %bb103
bb103:
  store i64 -1, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  %t295 = load i64, ptr %l17, !tbaa !24
  store i64 %t295, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t297 = load i64, ptr %l30, !tbaa !24
  %t298 = load i64, ptr %l29, !tbaa !24
  %t301 = icmp sgt i64 %t297, %t298
  br i1 %t301, label %bb104, label %bb105
bb104:
  %t303 = load i64, ptr %l31, !tbaa !24
  %t305 = icmp sgt i64 %t303, 0
  br i1 %t305, label %bb106, label %bb107
bb105:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb109
bb106:
  %t307 = load i64, ptr %l30, !tbaa !24
  %t308 = load i64, ptr %l29, !tbaa !24
  %t311 = sub i64 %t307, %t308
  %t312 = load i64, ptr %l31, !tbaa !24
  %t315 = add i64 %t311, %t312
  %t317 = sub i64 %t315, 1
  %t318 = load i64, ptr %l31, !tbaa !24
  %t321 = sdiv i64 %t317, %t318
  store i64 %t321, ptr %l224, !tbaa !24
  br label %bb108
bb107:
  store i64 0, ptr %l224, !tbaa !24
  br label %bb108
bb108:
  %t323 = load i64, ptr %l224, !tbaa !24
  store i64 %t323, ptr %l221, !tbaa !24
  br label %bb109
bb109:
  %t324 = load i64, ptr %l221, !tbaa !24
  store i64 %t324, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb110
bb110:
  %t325 = load i64, ptr %l33, !tbaa !24
  %t326 = load i64, ptr %l32, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb111, label %bb112
bb111:
  br label %bb143
bb112:
  br label %bb113
bb113:
  %t333 = load i64, ptr %l29, !tbaa !24
  %t334 = load i64, ptr %l33, !tbaa !24
  %t335 = load i64, ptr %l31, !tbaa !24
  %t338 = mul i64 %t334, %t335
  %t341 = add i64 %t333, %t338
  store i64 %t341, ptr %l34, !tbaa !24
  %t343 = load i64, ptr %l34, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr i1, ptr %t346, i64 %t343
  %t348 = load i1, ptr %t347, !tbaa !31
  br i1 %t348, label %bb114, label %bb115
bb114:
  br label %bb142
bb115:
  br label %bb116
bb116:
  store i1 true, ptr %l35, !tbaa !21
  %t350 = load i64, ptr %l34, !tbaa !24
  %t353 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t350)
  store i64 %t353, ptr %l246
  br label %bb117
bb117:
  %t354 = load i64, ptr %l246, !tbaa !24
  store i64 %t354, ptr %l36, !tbaa !24
  %t355 = load i64, ptr %l34, !tbaa !24
  %t357 = add i64 %t355, 1
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t357)
  store i64 %t360, ptr %l250
  br label %bb118
bb118:
  %t361 = load i64, ptr %l250, !tbaa !24
  store i64 %t361, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t362 = load i64, ptr %l37, !tbaa !24
  %t363 = load i64, ptr %l36, !tbaa !24
  %t366 = icmp sgt i64 %t362, %t363
  br i1 %t366, label %bb119, label %bb120
bb119:
  %t368 = load i64, ptr %l38, !tbaa !24
  %t370 = icmp sgt i64 %t368, 0
  br i1 %t370, label %bb121, label %bb122
bb120:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb124
bb121:
  %t372 = load i64, ptr %l37, !tbaa !24
  %t373 = load i64, ptr %l36, !tbaa !24
  %t376 = sub i64 %t372, %t373
  %t377 = load i64, ptr %l38, !tbaa !24
  %t380 = add i64 %t376, %t377
  %t382 = sub i64 %t380, 1
  %t383 = load i64, ptr %l38, !tbaa !24
  %t386 = sdiv i64 %t382, %t383
  store i64 %t386, ptr %l257, !tbaa !24
  br label %bb123
bb122:
  store i64 0, ptr %l257, !tbaa !24
  br label %bb123
bb123:
  %t388 = load i64, ptr %l257, !tbaa !24
  store i64 %t388, ptr %l254, !tbaa !24
  br label %bb124
bb124:
  %t389 = load i64, ptr %l254, !tbaa !24
  store i64 %t389, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb125
bb125:
  %t390 = load i64, ptr %l40, !tbaa !24
  %t391 = load i64, ptr %l39, !tbaa !24
  %t394 = icmp slt i64 %t390, %t391
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb126, label %bb127
bb126:
  br label %bb138
bb127:
  br label %bb128
bb128:
  %t398 = load i64, ptr %l36, !tbaa !24
  %t399 = load i64, ptr %l40, !tbaa !24
  %t400 = load i64, ptr %l38, !tbaa !24
  %t403 = mul i64 %t399, %t400
  %t406 = add i64 %t398, %t403
  store i64 %t406, ptr %l41, !tbaa !24
  %t408 = load i64, ptr %l41, !tbaa !24
  %t411 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t408)
  store i64 %t411, ptr %l277
  br label %bb129
bb129:
  %t412 = load i64, ptr %l277, !tbaa !24
  %t413 = icmp sge i64 %t412, 0
  br i1 %t413, label %bb130, label %bb131
bb130:
  %t415 = load i64, ptr %l41, !tbaa !24
  %t418 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t415)
  store i64 %t418, ptr %l282
  br label %bb132
bb131:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb133
bb132:
  %t419 = load i64, ptr %l282, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr i1, ptr %t421, i64 %t419
  %t423 = load i1, ptr %t422, !tbaa !31
  %t425 = xor i1 %t423, true
  store i1 %t425, ptr %l279, !tbaa !21
  br label %bb133
bb133:
  %t427 = load i1, ptr %l279, !tbaa !21
  br i1 %t427, label %bb134, label %bb135
bb134:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb136
bb135:
  br label %bb136
bb136:
  br label %bb137
bb137:
  %t428 = load i64, ptr %l40, !tbaa !24
  %t430 = add i64 %t428, 1
  store i64 %t430, ptr %l40, !tbaa !24
  br label %bb125
bb138:
  %t432 = load i1, ptr %l35, !tbaa !21
  br i1 %t432, label %bb139, label %bb140
bb139:
  %t434 = load i64, ptr %l34, !tbaa !24
  store i64 %t434, ptr %l28, !tbaa !24
  br label %bb143
bb140:
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t436 = load i64, ptr %l33, !tbaa !24
  %t438 = add i64 %t436, 1
  store i64 %t438, ptr %l33, !tbaa !24
  br label %bb110
bb143:
  %t440 = load i64, ptr %l28, !tbaa !24
  %t442 = icmp sge i64 %t440, 0
  br i1 %t442, label %bb144, label %bb145
bb144:
  %t444 = load i64, ptr %l28, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr i1, ptr %t447, i64 %t444
  store i1 true, ptr %t448, !tbaa !31
  %t449 = load ptr, ptr %l2, !tbaa !29
  store ptr %t449, ptr %l294, !tbaa !29
  %t450 = load i64, ptr %l28, !tbaa !24
  %t453 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t450)
  store i64 %t453, ptr %l297
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t454 = load ptr, ptr %l294, !tbaa !29
  %t455 = load i64, ptr %l297, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t454, i64 %t455)
  br label %bb147
bb147:
  %t456 = load i64, ptr %l27, !tbaa !24
  %t458 = add i64 %t456, 1
  store i64 %t458, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb231
bb148:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb149
bb149:
  %t460 = load i64, ptr %l42, !tbaa !24
  %t462 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr i1, ptr %t463, i64 %t460
  %t465 = load i1, ptr %t464, !tbaa !31
  %t467 = xor i1 %t465, true
  br i1 %t467, label %bb150, label %bb151
bb150:
  br label %bb154
bb151:
  br label %bb152
bb152:
  %t469 = load i64, ptr %l42, !tbaa !24
  %t471 = add i64 %t469, 1
  store i64 %t471, ptr %l42, !tbaa !24
  br label %bb153
bb153:
  br label %bb149
bb154:
  %t473 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t473, ptr %l305
  br label %bb155
bb155:
  %t474 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l305
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t474, ptr %l43
  br label %bb156
bb156:
  %t475 = load i64, ptr %l42, !tbaa !24
  %t478 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %s18, ptr %l43, i64 %t475)
  %t479 = extractvalue { i32, i64 } %t478, 1
  %t480 = extractvalue { i32, i64 } %t478, 0
  store i32 %t480, ptr %l310
  %t481 = icmp ne i32 %t480, 0
  br i1 %t481, label %bb158, label %ok.482, !prof !99
ok.482:
  store i64 %t479, ptr %l309
  br label %bb157
bb157:
  %t483 = load i64, ptr %l309, !tbaa !24
  store i64 %t483, ptr %l306, !tbaa !24
  br label %bb160
bb158:
  br label %bb159
bb159:
  store i64 -1, ptr %l306, !tbaa !24
  br label %bb160
bb160:
  %t484 = load i64, ptr %l306, !tbaa !24
  store i64 %t484, ptr %l44, !tbaa !24
  %t485 = load i64, ptr %l44, !tbaa !24
  %t487 = icmp sge i64 %t485, 0
  br i1 %t487, label %bb161, label %bb162
bb161:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %s0, ptr %s18, ptr %t489, ptr %l3, ptr %l43, i64 %t490)
  br label %bb163
bb162:
  br label %bb181
bb163:
  %t495 = load i64, ptr %l44, !tbaa !24
  store i64 %t495, ptr %l45, !tbaa !24
  %t498 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l43)
  store i64 %t498, ptr %l319
  br label %bb164
bb164:
  %t499 = load i64, ptr %l319, !tbaa !24
  store i64 %t499, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t500 = load i64, ptr %l46, !tbaa !24
  %t501 = load i64, ptr %l45, !tbaa !24
  %t504 = icmp sgt i64 %t500, %t501
  br i1 %t504, label %bb165, label %bb166
bb165:
  %t506 = load i64, ptr %l47, !tbaa !24
  %t508 = icmp sgt i64 %t506, 0
  br i1 %t508, label %bb167, label %bb168
bb166:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb170
bb167:
  %t510 = load i64, ptr %l46, !tbaa !24
  %t511 = load i64, ptr %l45, !tbaa !24
  %t514 = sub i64 %t510, %t511
  %t515 = load i64, ptr %l47, !tbaa !24
  %t518 = add i64 %t514, %t515
  %t520 = sub i64 %t518, 1
  %t521 = load i64, ptr %l47, !tbaa !24
  %t524 = sdiv i64 %t520, %t521
  store i64 %t524, ptr %l326, !tbaa !24
  br label %bb169
bb168:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb169
bb169:
  %t526 = load i64, ptr %l326, !tbaa !24
  store i64 %t526, ptr %l323, !tbaa !24
  br label %bb170
bb170:
  %t527 = load i64, ptr %l323, !tbaa !24
  store i64 %t527, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb171
bb171:
  %t528 = load i64, ptr %l49, !tbaa !24
  %t529 = load i64, ptr %l48, !tbaa !24
  %t532 = icmp slt i64 %t528, %t529
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb172, label %bb173
bb172:
  br label %bb180
bb173:
  br label %bb174
bb174:
  %t536 = load i64, ptr %l45, !tbaa !24
  %t537 = load i64, ptr %l49, !tbaa !24
  %t538 = load i64, ptr %l47, !tbaa !24
  %t541 = mul i64 %t537, %t538
  %t544 = add i64 %t536, %t541
  store i64 %t544, ptr %l50, !tbaa !24
  %t546 = load i64, ptr %l50, !tbaa !24
  %t549 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l43, i64 %t546)
  store i64 %t549, ptr %l346
  br label %bb175
bb175:
  %t550 = load i64, ptr %l346, !tbaa !24
  %t551 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr i1, ptr %t552, i64 %t550
  store i1 true, ptr %t553, !tbaa !31
  %t554 = load ptr, ptr %l2, !tbaa !29
  store ptr %t554, ptr %l347, !tbaa !29
  store ptr %l3, ptr %l348, !tbaa !29
  %t555 = load i64, ptr %l50, !tbaa !24
  %t558 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l43, i64 %t555)
  store i64 %t558, ptr %l351
  br label %bb176
bb176:
  %t559 = load ptr, ptr %l348, !tbaa !29
  %t560 = load i64, ptr %l351, !tbaa !24
  %t561 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t559, i64 %t560)
  store i64 %t561, ptr %l352
  br label %bb177
bb177:
  %t562 = load ptr, ptr %l347, !tbaa !29
  %t563 = load i64, ptr %l352, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t562, i64 %t563)
  br label %bb178
bb178:
  %t564 = load i64, ptr %l27, !tbaa !24
  %t566 = add i64 %t564, 1
  store i64 %t566, ptr %l27, !tbaa !24
  br label %bb179
bb179:
  %t568 = load i64, ptr %l49, !tbaa !24
  %t570 = add i64 %t568, 1
  store i64 %t570, ptr %l49, !tbaa !24
  br label %bb171
bb180:
  br label %bb230
bb181:
  %t572 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s18, ptr %l43, i64 %t572)
  br label %bb182
bb182:
  store i64 -1, ptr %l51, !tbaa !24
  %t575 = load i64, ptr %l42, !tbaa !24
  %t578 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t575)
  store i64 %t578, ptr %l361
  br label %bb183
bb183:
  %t579 = load i64, ptr %l361, !tbaa !24
  store i64 %t579, ptr %l52, !tbaa !24
  %t580 = load i64, ptr %l42, !tbaa !24
  %t582 = add i64 %t580, 1
  %t585 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t582)
  store i64 %t585, ptr %l365
  br label %bb184
bb184:
  %t586 = load i64, ptr %l365, !tbaa !24
  store i64 %t586, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t587 = load i64, ptr %l53, !tbaa !24
  %t588 = load i64, ptr %l52, !tbaa !24
  %t591 = icmp sgt i64 %t587, %t588
  br i1 %t591, label %bb185, label %bb186
bb185:
  %t593 = load i64, ptr %l54, !tbaa !24
  %t595 = icmp sgt i64 %t593, 0
  br i1 %t595, label %bb187, label %bb188
bb186:
  store i64 0, ptr %l369, !tbaa !24
  br label %bb190
bb187:
  %t597 = load i64, ptr %l53, !tbaa !24
  %t598 = load i64, ptr %l52, !tbaa !24
  %t601 = sub i64 %t597, %t598
  %t602 = load i64, ptr %l54, !tbaa !24
  %t605 = add i64 %t601, %t602
  %t607 = sub i64 %t605, 1
  %t608 = load i64, ptr %l54, !tbaa !24
  %t611 = sdiv i64 %t607, %t608
  store i64 %t611, ptr %l372, !tbaa !24
  br label %bb189
bb188:
  store i64 0, ptr %l372, !tbaa !24
  br label %bb189
bb189:
  %t613 = load i64, ptr %l372, !tbaa !24
  store i64 %t613, ptr %l369, !tbaa !24
  br label %bb190
bb190:
  %t614 = load i64, ptr %l369, !tbaa !24
  store i64 %t614, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb191
bb191:
  %t615 = load i64, ptr %l56, !tbaa !24
  %t616 = load i64, ptr %l55, !tbaa !24
  %t619 = icmp slt i64 %t615, %t616
  %t621 = xor i1 %t619, true
  br i1 %t621, label %bb192, label %bb193
bb192:
  br label %bb208
bb193:
  br label %bb194
bb194:
  %t623 = load i64, ptr %l52, !tbaa !24
  %t624 = load i64, ptr %l56, !tbaa !24
  %t625 = load i64, ptr %l54, !tbaa !24
  %t628 = mul i64 %t624, %t625
  %t631 = add i64 %t623, %t628
  store i64 %t631, ptr %l57, !tbaa !24
  %t633 = load i64, ptr %l51, !tbaa !24
  %t635 = icmp slt i64 %t633, 0
  br i1 %t635, label %bb195, label %bb196
bb195:
  %t637 = load i64, ptr %l57, !tbaa !24
  %t640 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t637)
  store i64 %t640, ptr %l395
  br label %bb197
bb196:
  store i1 false, ptr %l392, !tbaa !21
  br label %bb198
bb197:
  %t641 = load i64, ptr %l395, !tbaa !24
  %t642 = icmp sge i64 %t641, 0
  store i1 %t642, ptr %l392, !tbaa !21
  br label %bb198
bb198:
  %t644 = load i1, ptr %l392, !tbaa !21
  br i1 %t644, label %bb199, label %bb200
bb199:
  %t645 = load i64, ptr %l57, !tbaa !24
  %t648 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t645)
  store i64 %t648, ptr %l400
  br label %bb201
bb200:
  store i1 false, ptr %l397, !tbaa !21
  br label %bb202
bb201:
  %t649 = load i64, ptr %l400, !tbaa !24
  %t650 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = getelementptr i1, ptr %t651, i64 %t649
  %t653 = load i1, ptr %t652, !tbaa !31
  %t655 = xor i1 %t653, true
  store i1 %t655, ptr %l397, !tbaa !21
  br label %bb202
bb202:
  %t657 = load i1, ptr %l397, !tbaa !21
  br i1 %t657, label %bb203, label %bb204
bb203:
  %t658 = load i64, ptr %l57, !tbaa !24
  %t661 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t658)
  store i64 %t661, ptr %l405
  br label %bb205
bb204:
  br label %bb206
bb205:
  %t662 = load i64, ptr %l405, !tbaa !24
  store i64 %t662, ptr %l51, !tbaa !24
  br label %bb206
bb206:
  br label %bb207
bb207:
  %t663 = load i64, ptr %l56, !tbaa !24
  %t665 = add i64 %t663, 1
  store i64 %t665, ptr %l56, !tbaa !24
  br label %bb191
bb208:
  %t667 = load i64, ptr %l51, !tbaa !24
  %t669 = icmp slt i64 %t667, 0
  br i1 %t669, label %bb209, label %bb210
bb209:
  store i64 0, ptr %l58, !tbaa !24
  %t671 = load i64, ptr %l17, !tbaa !24
  store i64 %t671, ptr %l59, !tbaa !24
  store i64 1, ptr %l60, !tbaa !24
  %t673 = load i64, ptr %l59, !tbaa !24
  %t674 = load i64, ptr %l58, !tbaa !24
  %t677 = icmp sgt i64 %t673, %t674
  br i1 %t677, label %bb211, label %bb212
bb210:
  br label %bb228
bb211:
  %t679 = load i64, ptr %l60, !tbaa !24
  %t681 = icmp sgt i64 %t679, 0
  br i1 %t681, label %bb213, label %bb214
bb212:
  store i64 0, ptr %l414, !tbaa !24
  br label %bb216
bb213:
  %t683 = load i64, ptr %l59, !tbaa !24
  %t684 = load i64, ptr %l58, !tbaa !24
  %t687 = sub i64 %t683, %t684
  %t688 = load i64, ptr %l60, !tbaa !24
  %t691 = add i64 %t687, %t688
  %t693 = sub i64 %t691, 1
  %t694 = load i64, ptr %l60, !tbaa !24
  %t697 = sdiv i64 %t693, %t694
  store i64 %t697, ptr %l417, !tbaa !24
  br label %bb215
bb214:
  store i64 0, ptr %l417, !tbaa !24
  br label %bb215
bb215:
  %t699 = load i64, ptr %l417, !tbaa !24
  store i64 %t699, ptr %l414, !tbaa !24
  br label %bb216
bb216:
  %t700 = load i64, ptr %l414, !tbaa !24
  store i64 %t700, ptr %l61, !tbaa !24
  store i64 0, ptr %l62, !tbaa !24
  br label %bb217
bb217:
  %t701 = load i64, ptr %l62, !tbaa !24
  %t702 = load i64, ptr %l61, !tbaa !24
  %t705 = icmp slt i64 %t701, %t702
  %t707 = xor i1 %t705, true
  br i1 %t707, label %bb218, label %bb219
bb218:
  br label %bb227
bb219:
  br label %bb220
bb220:
  %t709 = load i64, ptr %l58, !tbaa !24
  %t710 = load i64, ptr %l62, !tbaa !24
  %t711 = load i64, ptr %l60, !tbaa !24
  %t714 = mul i64 %t710, %t711
  %t717 = add i64 %t709, %t714
  store i64 %t717, ptr %l63, !tbaa !24
  %t719 = load i64, ptr %l63, !tbaa !24
  %t721 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t722 = load ptr, ptr %t721, !tbaa !27
  %t723 = getelementptr i1, ptr %t722, i64 %t719
  %t724 = load i1, ptr %t723, !tbaa !31
  br i1 %t724, label %bb221, label %bb222
bb221:
  br label %bb226
bb222:
  br label %bb223
bb223:
  %t726 = load i64, ptr %l63, !tbaa !24
  %t728 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !27
  %t730 = getelementptr i1, ptr %t729, i64 %t726
  store i1 true, ptr %t730, !tbaa !31
  %t731 = load ptr, ptr %l2, !tbaa !29
  store ptr %t731, ptr %l438, !tbaa !29
  %t732 = load i64, ptr %l63, !tbaa !24
  %t735 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t732)
  store i64 %t735, ptr %l441
  br label %bb224
bb224:
  %t736 = load ptr, ptr %l438, !tbaa !29
  %t737 = load i64, ptr %l441, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t736, i64 %t737)
  br label %bb225
bb225:
  %t738 = load i64, ptr %l27, !tbaa !24
  %t740 = add i64 %t738, 1
  store i64 %t740, ptr %l27, !tbaa !24
  br label %bb226
bb226:
  %t742 = load i64, ptr %l62, !tbaa !24
  %t744 = add i64 %t742, 1
  store i64 %t744, ptr %l62, !tbaa !24
  br label %bb217
bb227:
  br label %bb230
bb228:
  %t746 = load i64, ptr %l51, !tbaa !24
  store i64 %t746, ptr %l42, !tbaa !24
  br label %bb229
bb229:
  br label %bb156
bb230:
  call void @__olang_scope_close(ptr %s18)
  br label %bb231
bb231:
  br label %bb100
bb232:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epower(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l22 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i32
  %l38 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l46 = alloca i32
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca i32
  %l75 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l101 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t2)
  store %"compiler/source:Span" %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t5)
  store %"compiler/source:Span" %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = load %"compiler/source:Span", ptr %l12
  %t10 = load %"compiler/source:Span", ptr %l14
  %t11 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t8, %"compiler/source:Span" %t9, %"compiler/source:Span" %t10, i64 2)
  store %"compiler/source:Span" %t11, ptr %l15
  br label %bb3
bb3:
  %t12 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t12, ptr %l5
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp ne i32 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l4, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l22
  br label %bb6
bb5:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %l19, !tbaa !23
  br label %bb7
bb6:
  %t26 = load i32, ptr %l22, !tbaa !23
  store i32 %t26, ptr %l19, !tbaa !23
  br label %bb7
bb7:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l24, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l25, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i1 %t36, ptr %l30
  br label %bb8
bb8:
  %t37 = load i1, ptr %l30, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l34
  br label %bb11
bb10:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb12
bb11:
  %t43 = load i1, ptr %l34, !tbaa !21
  store i1 %t43, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l31, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l38
  br label %bb15
bb14:
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t50, ptr %l35, !tbaa !23
  br label %bb16
bb15:
  %t52 = load i32, ptr %l38, !tbaa !23
  store i32 %t52, ptr %l35, !tbaa !23
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l25, !tbaa !29
  %t54 = load ptr, ptr %l27, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t53, ptr %t54, i32 %t55)
  store ptr %t56, ptr %l40
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t57)
  store %"compiler/source:Span" %t59, ptr %l42
  br label %bb18
bb18:
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l42
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t60, ptr %t61, %"compiler/source:Span" %t62)
  store ptr %t63, ptr %l43
  br label %bb19
bb19:
  %t64 = load ptr, ptr %l43, !tbaa !29
  store ptr %t64, ptr %l7, !tbaa !29
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t68 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t65)
  store i32 %t68, ptr %l46
  br label %bb20
bb20:
  %t69 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t70 = load i32, ptr %l46, !tbaa !23
  %t72 = icmp eq i32 %t70, %t69
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t74, ptr %t75, i32 %t77)
  store ptr %t81, ptr %l53
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l1
  %t86 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t82, %"compiler/source:Span" %t83)
  store ptr %t86, ptr %l56
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l56, !tbaa !29
  store ptr %t87, ptr %rv
  br label %ret
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v3, ptr %t88, ptr %t89)
  store i64 %t92, ptr %l59
  br label %bb26
bb26:
  %t93 = load i64, ptr %l59, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  br i1 %t94, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb31
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l62, !tbaa !29
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t97)
  store i32 %t100, ptr %l65
  br label %bb29
bb29:
  %t101 = load ptr, ptr %l62, !tbaa !29
  %t102 = load i32, ptr %l65, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t101, i32 %t102)
  store i1 %t103, ptr %l66
  br label %bb30
bb30:
  %t104 = load i1, ptr %l66, !tbaa !21
  store i1 %t104, ptr %l61, !tbaa !21
  br label %bb31
bb31:
  %t105 = load i1, ptr %l61, !tbaa !21
  br i1 %t105, label %bb32, label %bb33
bb32:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l67, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l68, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l69, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l7, !tbaa !29
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v3, ptr %t109, ptr %t110)
  store i32 %t114, ptr %l73
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t115 = load ptr, ptr %l69, !tbaa !29
  %t116 = load i32, ptr %l73, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l74
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l67, !tbaa !29
  %t119 = load ptr, ptr %l68, !tbaa !29
  %t120 = load i32, ptr %l74, !tbaa !23
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v2, ptr %v3, ptr %t118, ptr %t119, i32 %t120)
  store ptr %t121, ptr %l75
  br label %bb36
bb36:
  %t122 = load ptr, ptr %l75, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t125 = load %"compiler/source:Span", ptr %l5
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t123, %"compiler/source:Span" %t124, %"compiler/source:Span" %t125, i32 70, ptr %t126, ptr %t122)
  store ptr %t134, ptr %l82
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l82, !tbaa !29
  store ptr %t135, ptr %rv
  br label %ret
bb38:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l83, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l84, !tbaa !29
  %t138 = load ptr, ptr %l3, !tbaa !29
  store ptr %t138, ptr %l86, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l87, !tbaa !29
  %t141 = load ptr, ptr %l7, !tbaa !29
  %t144 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t141)
  store i32 %t144, ptr %l90
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l87, !tbaa !29
  %t146 = load i32, ptr %l90, !tbaa !23
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t147, ptr %l91
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l84, !tbaa !29
  %t149 = load ptr, ptr %l86, !tbaa !29
  %t150 = load i32, ptr %l91, !tbaa !23
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t148, ptr %t149, i32 %t150)
  store ptr %t151, ptr %l92
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l3, !tbaa !29
  %t154 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t152)
  store %"compiler/source:Span" %t154, ptr %l94
  br label %bb42
bb42:
  %t155 = load ptr, ptr %l83, !tbaa !29
  %t156 = load ptr, ptr %l92, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l94
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t155, ptr %t156, %"compiler/source:Span" %t157)
  store ptr %t158, ptr %l95
  br label %bb43
bb43:
  %t159 = load ptr, ptr %l95, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l1
  %t162 = load %"compiler/source:Span", ptr %l5
  %t163 = load ptr, ptr %l7, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t160, %"compiler/source:Span" %t161, %"compiler/source:Span" %t162, ptr %t163, ptr %t159)
  store ptr %t170, ptr %l101
  br label %bb44
bb44:
  %t171 = load ptr, ptr %l101, !tbaa !29
  store ptr %t171, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %rv = alloca ptr
  %t35 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 36
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t9, ptr %a4)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 36
  %t22 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t21, ptr %t22)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  store %"compiler/source:Span" %a1, ptr %l19
  store i32 %a2, ptr %l20, !tbaa !23
  store i32 %a3, ptr %l21
  store i32 0, ptr %l22
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 36
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t30, i64 %t31)
  store { i64, ptr } %t34, ptr %l26
  br label %bb7
bb7:
  store { i64, [5 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 0
  store i64 9, ptr %t36
  %t37 = load %"compiler/source:Span", ptr %l19
  %t38 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t37, 0
  %t39 = load i32, ptr %l20, !tbaa !23
  %t40 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t38, i32 %t39, 1
  %t41 = load i32, ptr %l21, !range !{i32 0, i32 52}
  %t42 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t40, i32 %t41, 2
  %t43 = load i32, ptr %l22, !range !{i32 0, i32 3}
  %t44 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t42, i32 %t43, 3
  %t45 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t46 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t44, { i64, ptr } %t45, 4
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t46, ptr %t47
  %t48 = load { i64, [5 x i64] }, ptr %t35
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t48, ptr %t50
  store ptr %t50, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i64
  %l32 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l53 = alloca %"compiler/diagmsg:Msg"
  %l54 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 16
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp eq i64 %t10, 0
  store i1 %t11, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l19
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t28, i32 %t27)
  store { i64, ptr } %t30, ptr %l22
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t32, { i64, ptr } %t33)
  store i1 %t36, ptr %l25
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb15
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l30
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t46)
  store ptr %t48, ptr %l32
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l30, !tbaa !24
  %t55 = icmp eq i64 %t53, %t52
  store i1 %t55, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l26, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l40, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t73 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t69, %"compiler/source:Span" %a4)
  store { i64, [3 x i64] } %t73, ptr %l43
  br label %bb19
bb19:
  store { i64, ptr } %a5, ptr %l44, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t76, i32 %a2)
  store i32 %t80, ptr %l48
  br label %bb20
bb20:
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t82 = load i32, ptr %l48, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l49
  br label %bb21
bb21:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t97 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v2, ptr %s0, ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t93, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } %t92)
  store %"compiler/diagmsg:Msg" %t97, ptr %l53
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l40, !tbaa !29
  %t99 = load { i64, [3 x i64] }, ptr %l43
  %t100 = load %"compiler/diagmsg:Msg", ptr %l53
  %t101 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s0, ptr %t98, { i64, [3 x i64] } %t99, %"compiler/diagmsg:Msg" %t100)
  store i64 %t101, ptr %l54
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i32
  %l55 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %l64 = alloca ptr
  %l71 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/diagmsg:Msg"
  %l83 = alloca i64
  %l86 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca i32
  %l97 = alloca ptr
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t121 = alloca { i64, [1 x i64] }, align 8
  %t139 = alloca { i64, [3 x i64] }, align 8
  %t184 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t4, ptr %l5
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb45
bb4:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 30}
  %t14 = icmp eq i64 %t12, 0
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l14, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l6
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l7, !tbaa !23
  br label %bb8
bb7:
  br label %bb37
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t34, ptr %l24
  br label %bb10
bb10:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l26
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 43
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l30
  br label %bb15
bb15:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i32, ptr %l4, !tbaa !23
  %t53 = load i32, ptr %l34, !tbaa !23
  %t55 = icmp ne i32 %t53, %t52
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l39
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t63 = load i32, ptr %l39, !tbaa !23
  store i32 %t63, ptr %l4, !tbaa !23
  br label %bb23
bb23:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l46
  br label %bb25
bb25:
  %t78 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t80 = trunc i64 19 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load i32, ptr %l4, !tbaa !23
  store i32 %t89, ptr %l53, !tbaa !23
  %t90 = load ptr, ptr %l3, !tbaa !29
  store ptr %t90, ptr %l55, !tbaa !29
  %t92 = load ptr, ptr %l55, !tbaa !29
  %t93 = call ptr @__olang_scope_of(ptr %t92, ptr null)
  %t94 = ptrtoint ptr %t93 to i64
  %t96 = inttoptr i64 %t94 to ptr
  %t97 = load ptr, ptr %l55, !tbaa !29
  %t98 = call i32 @compiler_2fcheck_2etypeOf(ptr %t96, ptr %t97)
  store i32 %t98, ptr %l57
  br label %bb28
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb28:
  %t99 = load ptr, ptr %l52, !tbaa !29
  %t100 = load i32, ptr %l53, !tbaa !23
  %t101 = load i32, ptr %l57, !tbaa !23
  %t102 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t99, i32 %t100, i32 %t101)
  store i1 %t102, ptr %l58
  br label %bb29
bb29:
  %t103 = load i1, ptr %l58, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t106 = load i1, ptr %l49, !tbaa !21
  br i1 %t106, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t109 = load i32, ptr %l4, !tbaa !23
  %t110 = load %"compiler/source:Span", ptr %l6
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t107, ptr %t108, i32 %t109, %"compiler/source:Span" %t110)
  store ptr %t115, ptr %l64
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t116 = load ptr, ptr %l64, !tbaa !29
  store ptr %t116, ptr %l3, !tbaa !29
  br label %bb34
bb34:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l7, !tbaa !23
  %t119 = load %"compiler/source:Span", ptr %l6
  %t120 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [1 x i64] }, ptr %t121, i32 0, i32 0
  store i64 4, ptr %t122
  %t123 = load { i64, [1 x i64] }, ptr %t121
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t117, i32 %t118, %"compiler/source:Span" %t119, i32 %t120, i32 1, { i64, [1 x i64] } %t123)
  store i64 %t130, ptr %l71
  br label %bb35
bb35:
  %t131 = load i64, ptr %l71, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l6
  %t136 = trunc i64 %t131 to i32
  %t138 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 0
  store i64 0, ptr %t140
  %t142 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t133, 0
  %t144 = insertvalue { %"compiler/source:Span", i32, ptr } %t142, i32 %t136, 1
  %t146 = insertvalue { %"compiler/source:Span", i32, ptr } %t144, ptr %t138, 2
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t146, ptr %t147
  %t148 = load { i64, [3 x i64] }, ptr %t139
  %t150 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t148, ptr %t150
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t132, ptr %t150)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb43
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l80, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t154, ptr %l81
  %t155 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %s6)
  store %"compiler/diagmsg:Msg" %t155, ptr %l82
  br label %bb41
bb41:
  %t156 = load ptr, ptr %l80, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l81
  %t158 = load %"compiler/diagmsg:Msg", ptr %l82
  %t159 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t156, %"compiler/source:Span" %t157, %"compiler/diagmsg:Msg" %t158)
  store i64 %t159, ptr %l83
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_fb06dcd16342dc9_94e70e479081575d)
  unreachable
bb44:
  br label %ret
bb45:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t164 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v0, ptr %t160, ptr %t161)
  store ptr %t164, ptr %l86
  br label %bb46
bb46:
  %t165 = load ptr, ptr %l86, !tbaa !29
  store ptr %t165, ptr %l9, !tbaa !29
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = icmp eq ptr %t166, null
  br i1 %t168, label %bb47, label %bb48
bb47:
  br label %ret
bb48:
  br label %bb49
bb49:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l89, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t171, ptr %l90
  %t172 = load ptr, ptr %l9, !tbaa !29
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l92, !tbaa !29
  %t174 = load ptr, ptr %l3, !tbaa !29
  store ptr %t174, ptr %l93, !tbaa !29
  %t175 = load ptr, ptr %l9, !tbaa !29
  %t177 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t175)
  store i32 %t177, ptr %l95
  br label %bb50
bb50:
  %t178 = load %"compiler/source:Span", ptr %l5
  %t179 = load ptr, ptr %l92, !tbaa !29
  %t180 = load ptr, ptr %l93, !tbaa !29
  %t181 = load i32, ptr %l95, !tbaa !23
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t179, ptr %t180, i32 %t181, %"compiler/source:Span" %t178)
  store ptr %t183, ptr %l97
  br label %bb51
bb51:
  store { i64, [3 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t184, i32 0, i32 0
  store i64 1, ptr %t185
  %t186 = load %"compiler/source:Span", ptr %l90
  %t187 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t186, 0
  %t188 = load ptr, ptr %l91, !tbaa !29
  %t189 = insertvalue { %"compiler/source:Span", ptr, ptr } %t187, ptr %t188, 1
  %t190 = load ptr, ptr %l97, !tbaa !29
  %t191 = insertvalue { %"compiler/source:Span", ptr, ptr } %t189, ptr %t190, 2
  %t192 = getelementptr { i64, [3 x i64] }, ptr %t184, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t191, ptr %t192
  %t193 = load { i64, [3 x i64] }, ptr %t184
  %t195 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t193, ptr %t195
  %t196 = load ptr, ptr %l89, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t196, ptr %t195)
  br label %bb52
bb52:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflLen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"compiler/check:reflList"
  %l5 = alloca { { i64, ptr }, { i64, ptr } }
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l13 = alloca i1
  %l17 = alloca %"compiler/check:reflVal"
  %l20 = alloca %"compiler/check:reflList"
  %l23 = alloca %"compiler/check:reflVal"
  %l28 = alloca %"compiler/check:reflVal"
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca { { i64, ptr }, { i64, ptr } }
  %l42 = alloca i1
  %l43 = alloca %"compiler/check:reflVal"
  %l46 = alloca %"compiler/check:reflVal"
  %l47 = alloca %"compiler/check:reflVal"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflVal"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a2)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i1, ptr %l11, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t13 = extractvalue { i64, ptr } %a3, 0
  %t15 = icmp ne i64 %t13, 0
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v3)
  store %"compiler/check:reflVal" %t18, ptr %l17
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load %"compiler/check:reflVal", ptr %l17
  store %"compiler/check:reflVal" %t19, ptr %rv
  br label %ret
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t20, ptr %a1)
  store %"compiler/check:reflList" %t24, ptr %l20
  br label %bb10
bb10:
  %t25 = load %"compiler/check:reflList", ptr %l20
  store %"compiler/check:reflList" %t25, ptr %l4
  %t26 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 0
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v3)
  store %"compiler/check:reflVal" %t31, ptr %l23
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load %"compiler/check:reflVal", ptr %l23
  store %"compiler/check:reflVal" %t32, ptr %rv
  br label %ret
bb14:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 141
  store i1 true, ptr %t35, !tbaa !21
  %t36 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 1
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t41 = icmp eq i32 %t37, %t38
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v3)
  store %"compiler/check:reflVal" %t43, ptr %l28
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load %"compiler/check:reflVal", ptr %l28
  store %"compiler/check:reflVal" %t44, ptr %rv
  br label %ret
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  store i32 %t50, ptr %l31, !tbaa !23
  %t51 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 2
  %t52 = load i64, ptr %t51, !tbaa !24
  store i64 %t52, ptr %l32, !tbaa !24
  %t53 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 3
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l33, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t55)
  store ptr %t57, ptr %l35
  br label %bb19
bb19:
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load ptr, ptr %l30, !tbaa !29
  %t63 = load i32, ptr %l31, !tbaa !23
  %t64 = load i64, ptr %l32, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t67 = call { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %s0, ptr %t62, i32 %t63, i64 %t64, i64 %t65, i64 %t61)
  store { { i64, ptr }, { i64, ptr } } %t67, ptr %l38
  br label %bb20
bb20:
  %t68 = load { { i64, ptr }, { i64, ptr } }, ptr %l38
  store { { i64, ptr }, { i64, ptr } } %t68, ptr %l5
  %t69 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l5, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l6, !tbaa !27
  %t72 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l5, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t77, ptr %l42
  br label %bb21
bb21:
  %t78 = load i1, ptr %l42, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t79 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v3, i64 %t81)
  store %"compiler/check:reflVal" %t83, ptr %l46
  br label %bb24
bb23:
  %t84 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v3)
  store %"compiler/check:reflVal" %t84, ptr %l47
  br label %bb25
bb24:
  %t85 = load %"compiler/check:reflVal", ptr %l46
  store %"compiler/check:reflVal" %t85, ptr %l43
  br label %bb26
bb25:
  %t86 = load %"compiler/check:reflVal", ptr %l47
  store %"compiler/check:reflVal" %t86, ptr %l43
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load %"compiler/check:reflVal", ptr %l43
  store %"compiler/check:reflVal" %t87, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 85
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t4, i64 %t5)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t14, i64 %t15, i64 %t16)
  store i1 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 19
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb9:
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp ne i64 %t29, 2
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 84
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  store i1 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 84
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l18
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd27b567062a69be2f699d8e9ab74cf5a(ptr %v0, ptr %v0, ptr %t26, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 84
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t35 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf1792c165fec863e4f2028b41ed50f44(ptr %v0, ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  %t36 = extractvalue { i32, ptr } %t35, 1
  %t37 = extractvalue { i32, ptr } %t35, 0
  store i32 %t37, ptr %l25
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39, !prof !99
ok.39:
  store ptr %t36, ptr %l24
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l24, !tbaa !29
  store ptr %t40, ptr %l20, !tbaa !29
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t41, ptr %t43)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %l12 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca %"compiler/typed:Local"
  %l55 = alloca i1
  %l57 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca ptr
  %l63 = alloca %"compiler/typed:Local"
  %l68 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca i1
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l96 = alloca ptr
  %l100 = alloca ptr
  %l103 = alloca i64
  %l105 = alloca i64
  %l110 = alloca i32
  %l111 = alloca ptr
  %l113 = alloca ptr
  %l115 = alloca %"compiler/typed:Local"
  %l124 = alloca { i64, ptr }
  %l125 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 13
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l20, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l23, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t27)
  store ptr %t29, ptr %l25
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t30 = load ptr, ptr %l25, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t34, i32 %t33)
  store i32 %t36, ptr %l28
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load i32, ptr %l28, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t43 = icmp eq i64 %t41, 0
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l17, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epuns(ptr %v0, ptr %v1, ptr %s0, ptr %t46, { i64, ptr } %t47)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t50, ptr %l35
  br label %bb11
bb10:
  %t51 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t51, ptr %l36
  br label %bb12
bb11:
  %t52 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t52, ptr %l32
  br label %bb13
bb12:
  %t53 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t53, ptr %l32
  br label %bb13
bb13:
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %l3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t55)
  store ptr %t57, ptr %l38
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 5
  store ptr %t60, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %l41, !tbaa !24
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l43
  br label %bb16
bb16:
  %t66 = load i64, ptr %l41, !tbaa !24
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = icmp slt i64 %t66, %t67
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb31
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t72, i64 %t73)
  store i32 %t76, ptr %l48
  br label %bb20
bb20:
  %t77 = load i32, ptr %l48, !tbaa !23
  store i32 %t77, ptr %l6, !tbaa !23
  store ptr %l3, ptr %l49, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t78)
  store ptr %t80, ptr %l51
  br label %bb21
bb21:
  %t81 = load i32, ptr %l6, !tbaa !23
  %t82 = load ptr, ptr %l51, !tbaa !29
  %t84 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t82, i32 %t81)
  store %"compiler/typed:Local" %t84, ptr %l53
  br label %bb22
bb22:
  %t85 = getelementptr %"compiler/typed:Local", ptr %l53, i32 0, i32 0
  %t86 = load i32, ptr %t85, !tbaa !23
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t89 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %s0, ptr %t87, i32 %t86)
  store i1 %t89, ptr %l55
  br label %bb23
bb23:
  %t90 = load i1, ptr %l55, !tbaa !21
  %t91 = xor i1 %t90, true
  br i1 %t91, label %bb24, label %bb25
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l57, !tbaa !29
  %t94 = load i32, ptr %l6, !tbaa !23
  %t96 = sext i32 %t94 to i64
  store i64 %t96, ptr %l59, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l61
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t100 = load i32, ptr %l6, !tbaa !23
  %t101 = load ptr, ptr %l61, !tbaa !29
  %t103 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t101, i32 %t100)
  store %"compiler/typed:Local" %t103, ptr %l63
  br label %bb27
bb27:
  %t104 = getelementptr %"compiler/typed:Local", ptr %l63, i32 0, i32 1
  %t105 = load %"compiler/source:Span", ptr %t104
  %t106 = load ptr, ptr %l57, !tbaa !29
  %t107 = load i64, ptr %l59, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %t106, i64 %t107, %"compiler/source:Span" %t105, i1 true)
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l5, !tbaa !24
  br label %bb15
bb31:
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %t113)
  br label %bb32
bb32:
  %t115 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t115, ptr %l68, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t116)
  store ptr %t118, ptr %l70
  br label %bb33
bb33:
  %t119 = load ptr, ptr %l70, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 43
  %t122 = load { i64, ptr }, ptr %l68, !tbaa !27
  call void @compiler_2fcheck_2estoredIn(ptr %v1, ptr %v0, { i64, ptr } %t122, ptr %t121)
  br label %bb34
bb34:
  %t124 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb35, label %bb36
bb35:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t130, { i64, ptr } %t131)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t134)
  store ptr %t136, ptr %l79
  br label %bb39
bb39:
  %t137 = load ptr, ptr %l79, !tbaa !29
  %t139 = getelementptr %"compiler/check:frame", ptr %t137, i32 0, i32 13
  %t140 = load i1, ptr %t139, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  store ptr %t145, ptr %l84, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t146)
  store ptr %t148, ptr %l86
  br label %bb42
bb41:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb44
bb42:
  %t149 = load ptr, ptr %l86, !tbaa !29
  %t151 = getelementptr %"compiler/check:frame", ptr %t149, i32 0, i32 14
  %t152 = load i32, ptr %t151, !tbaa !23
  %t153 = load ptr, ptr %l84, !tbaa !29
  %t155 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t153, i32 %t152)
  store i1 %t155, ptr %l89
  br label %bb43
bb43:
  %t156 = load i1, ptr %l89, !tbaa !21
  store i1 %t156, ptr %l82, !tbaa !21
  br label %bb44
bb44:
  %t157 = load i1, ptr %l82, !tbaa !21
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l90, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t159)
  store ptr %t161, ptr %l92
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t162 = load ptr, ptr %l92, !tbaa !29
  %t164 = getelementptr %"compiler/check:frame", ptr %t162, i32 0, i32 14
  %t165 = load i32, ptr %t164, !tbaa !23
  %t166 = load ptr, ptr %l90, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %t166, i32 %t165)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t168)
  store ptr %t170, ptr %l96
  br label %bb50
bb50:
  %t171 = load ptr, ptr %l96, !tbaa !29
  %t173 = getelementptr %"compiler/check:frame", ptr %t171, i32 0, i32 13
  %t174 = load i1, ptr %t173, !tbaa !21
  br i1 %t174, label %bb51, label %bb52
bb51:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t176)
  store ptr %t178, ptr %l100
  br label %bb53
bb52:
  br label %bb65
bb53:
  %t179 = load ptr, ptr %l100, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Body", ptr %t179, i32 0, i32 10
  store ptr %t181, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb54
bb54:
  %t183 = load i64, ptr %l8, !tbaa !24
  store i64 %t183, ptr %l103, !tbaa !24
  %t184 = load ptr, ptr %l7, !tbaa !29
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l105
  br label %bb55
bb55:
  %t187 = load i64, ptr %l103, !tbaa !24
  %t188 = load i64, ptr %l105, !tbaa !24
  %t189 = icmp slt i64 %t187, %t188
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb56, label %bb57
bb56:
  br label %bb64
bb57:
  br label %bb58
bb58:
  %t193 = load ptr, ptr %l7, !tbaa !29
  %t194 = load i64, ptr %l8, !tbaa !24
  %t197 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t193, i64 %t194)
  store i32 %t197, ptr %l110
  br label %bb59
bb59:
  %t198 = load i32, ptr %l110, !tbaa !23
  store i32 %t198, ptr %l9, !tbaa !23
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l111, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t200)
  store ptr %t202, ptr %l113
  br label %bb60
bb60:
  %t203 = load i32, ptr %l9, !tbaa !23
  %t204 = load ptr, ptr %l113, !tbaa !29
  %t206 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t204, i32 %t203)
  store %"compiler/typed:Local" %t206, ptr %l115
  br label %bb61
bb61:
  %t207 = getelementptr %"compiler/typed:Local", ptr %l115, i32 0, i32 1
  %t208 = load %"compiler/source:Span", ptr %t207
  %t209 = load i32, ptr %l9, !tbaa !23
  %t211 = sext i32 %t209 to i64
  %t212 = load ptr, ptr %l111, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropsGone(ptr %v0, ptr %t212, %"compiler/source:Span" %t208, i64 %t211)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t215 = load i64, ptr %l8, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l8, !tbaa !24
  br label %bb54
bb64:
  br label %bb65
bb65:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 37
  %t222 = load i64, ptr %l2, !tbaa !24
  %t225 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t221, i64 %t222)
  store { i64, ptr } %t225, ptr %l124
  br label %bb66
bb66:
  %t226 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t227 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t226)
  store %"compiler/typed:Block" %t227, ptr %l125
  br label %bb67
bb67:
  %t228 = load %"compiler/typed:Block", ptr %l125
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t228, ptr %t229
  call void @__olang_scope_close(ptr %s0)
  store ptr %t229, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructColumn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %a2)
  store i32 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i32, ptr %l13, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l5, !tbaa !24
  store i64 %t14, ptr %l15, !tbaa !24
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t15)
  store i64 %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb4, label %bb5
bb4:
  br label %bb24
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l22
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 0
  %t34 = load ptr, ptr %t33, !tbaa !39
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l7, !tbaa !29
  store ptr %t36, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 9}
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t45 = load ptr, ptr %l7, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l8, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l8, !tbaa !29
  %t55 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructDecl(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i32 %t55, ptr %l33
  br label %bb13
bb13:
  %t56 = load i32, ptr %l3, !tbaa !23
  %t57 = load i32, ptr %l33, !tbaa !23
  %t59 = icmp eq i32 %t57, %t56
  br i1 %t59, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_8ded448c56d61a9a_a1642562b2a40e16)
  unreachable
bb22:
  br label %bb23
bb23:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb2
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethunkModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l49 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 10
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l19
  br label %bb2
bb2:
  %t24 = load i64, ptr %l19, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l23, !tbaa !24
  store i64 %t52, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 10
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store ptr %t83, ptr %l49
  br label %bb13
bb13:
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 4
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = icmp eq i64 %t87, %t88
  br i1 %t91, label %bb14, label %bb15
bb14:
  %t93 = load i64, ptr %l8, !tbaa !24
  store i64 %t93, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb9
bb18:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etoDeclaredFunc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l10 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/diagmsg:Msg"
  %l19 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l33 = alloca i32
  %l42 = alloca i32
  %l45 = alloca i1
  %l50 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l68 = alloca i1
  %l69 = alloca i32
  %l74 = alloca i32
  %l76 = alloca { i64, ptr }
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i32, ptr %l10, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = icmp ne i64 %t12, 1
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t17, ptr %l15
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s1, ptr %s1, i64 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, i64 %t20)
  store %"compiler/diagmsg:Msg" %t22, ptr %l18
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l15
  %t25 = load %"compiler/diagmsg:Msg", ptr %l18
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t23, %"compiler/source:Span" %t24, %"compiler/diagmsg:Msg" %t25)
  store i64 %t26, ptr %l19
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t27, { i64, ptr } %t28)
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t31, %"compiler/source:Span" %t32)
  store ptr %t35, ptr %l24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t36 = load ptr, ptr %l24, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l26, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 0
  %t42 = load ptr, ptr %t41, !tbaa !39
  %t44 = load i32, ptr %l4, !tbaa !23
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t42, i32 %t44)
  store ptr %t48, ptr %l30
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l30, !tbaa !29
  store ptr %t49, ptr %l5, !tbaa !29
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t50)
  store i32 %t53, ptr %l33
  br label %bb10
bb10:
  %t54 = load i32, ptr %l33, !tbaa !23
  store i32 %t54, ptr %l6, !tbaa !23
  %t55 = load i32, ptr %l6, !tbaa !23
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t59 = icmp eq i32 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load ptr, ptr %l5, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l6, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l42
  br label %bb14
bb14:
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t74 = load i32, ptr %l42, !tbaa !23
  %t76 = icmp ne i32 %t74, %t73
  br i1 %t76, label %bb15, label %bb16
bb15:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l6, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l50
  br label %bb17
bb16:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb18
bb17:
  %t88 = load i32, ptr %l2, !tbaa !23
  %t89 = load i32, ptr %l50, !tbaa !23
  %t91 = icmp ne i32 %t89, %t88
  store i1 %t91, ptr %l45, !tbaa !21
  br label %bb18
bb18:
  %t93 = load i1, ptr %l45, !tbaa !21
  br i1 %t93, label %bb19, label %bb20
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l53, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t95, ptr %l54
  %t96 = load ptr, ptr %l5, !tbaa !29
  store ptr %t96, ptr %l55, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l6, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUntagged(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l60
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t107 = load ptr, ptr %l53, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l54
  %t109 = load ptr, ptr %l55, !tbaa !29
  %t110 = load i32, ptr %l60, !tbaa !23
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t107, %"compiler/source:Span" %t108, ptr %t109, i32 %t110)
  store ptr %t111, ptr %l61
  br label %bb22
bb22:
  %t112 = load ptr, ptr %l61, !tbaa !29
  store ptr %t112, ptr %l5, !tbaa !29
  br label %bb23
bb23:
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l62, !tbaa !29
  %t114 = load ptr, ptr %l5, !tbaa !29
  store ptr %t114, ptr %l63, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l6, !tbaa !23
  %t124 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l68
  br label %bb24
bb24:
  %t125 = load i1, ptr %l68, !tbaa !21
  br i1 %t125, label %bb25, label %bb26
bb25:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l4, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l74
  br label %bb27
bb26:
  %t136 = load i32, ptr %l4, !tbaa !23
  store i32 %t136, ptr %l69, !tbaa !23
  br label %bb28
bb27:
  %t138 = load i32, ptr %l74, !tbaa !23
  store i32 %t138, ptr %l69, !tbaa !23
  br label %bb28
bb28:
  %t139 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t139, ptr %l76, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 0
  %t143 = load ptr, ptr %t142, !tbaa !39
  %t145 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t143)
  store %"compiler/source:Span" %t145, ptr %l78
  br label %bb29
bb29:
  %t146 = load ptr, ptr %l62, !tbaa !29
  %t147 = load ptr, ptr %l63, !tbaa !29
  %t148 = load i32, ptr %l69, !tbaa !23
  %t149 = load %"compiler/source:Span", ptr %l78
  %t150 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t146, ptr %t147, i32 %t148, %"compiler/source:Span" %t149)
  store ptr %t150, ptr %l79
  br label %bb30
bb30:
  %t151 = load ptr, ptr %l79, !tbaa !29
  store ptr %t151, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryBorrowed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l18 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l29 = alloca ptr
  %l37 = alloca ptr
  %l47 = alloca %"compiler/typed:Try"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t95 = alloca { i64, [5 x i64] }, align 8
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l4
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb21
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Try", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = icmp ne i64 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb12
bb7:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Try", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_aba8aa6938d7a087_5d05cf2ee38e12b)
  unreachable
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Try", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %s1, ptr %t41)
  store ptr %t43, ptr %l24
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = icmp eq ptr %t44, null
  store i1 %t45, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l18, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t49 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t49, ptr %l27
  %t50 = load i32, ptr %l2, !tbaa !23
  store i32 %t50, ptr %l28, !tbaa !23
  store ptr %a0, ptr %l29, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Try", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e0d7a6d968754368_2e78c0e3cd1ef5bc)
  unreachable
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Try", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t65 = load ptr, ptr %l29, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %t65, ptr %t62, i32 %t63, %"compiler/source:Span" %a3)
  store ptr %t69, ptr %l37
  br label %bb19
bb19:
  %t70 = load ptr, ptr %l37, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Try", ptr %t71, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Try", ptr %t75, i32 0, i32 2
  %t78 = load i1, ptr %t77, !tbaa !21
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Try", ptr %t79, i32 0, i32 3
  %t82 = load i1, ptr %t81, !tbaa !21
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Try", ptr %t83, i32 0, i32 4
  %t86 = load i1, ptr %t85, !tbaa !21
  %t92 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v2, ptr %v1, ptr %v2, ptr %t70, { i64, ptr } %t74, i1 %t78, i1 %t82, i1 %t86)
  store %"compiler/typed:Try" %t92, ptr %l47
  br label %bb20
bb20:
  %t93 = load %"compiler/typed:Try", ptr %l47
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t93, ptr %t94
  store { i64, [5 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 0
  store i64 14, ptr %t96
  %t97 = load %"compiler/source:Span", ptr %l27
  %t98 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t97, 0
  %t99 = load i32, ptr %l28, !tbaa !23
  %t100 = insertvalue { %"compiler/source:Span", i32, ptr } %t98, i32 %t99, 1
  %t102 = insertvalue { %"compiler/source:Span", i32, ptr } %t100, ptr %t94, 2
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t102, ptr %t103
  %t104 = load { i64, [5 x i64] }, ptr %t95
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t104, ptr %t106
  call void @__olang_scope_close(ptr %s1)
  store ptr %t106, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store ptr null, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2b61f833cd126364_51d75042885d0038)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 3
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 3}
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l18
  br label %bb11
bb11:
  %t36 = load i1, ptr %l18, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l24
  br label %bb14
bb13:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb16
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l26
  br label %bb15
bb15:
  %t50 = load i32, ptr %l24, !tbaa !23
  %t51 = load i32, ptr %l26, !tbaa !23
  %t52 = icmp eq i32 %t50, %t51
  store i1 %t52, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l19, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l30, !tbaa !24
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l31, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l30, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t69, ptr %l29, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e722c21055ee6b49_58bcebf0b772fb7d)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eca48244095fc078_aacf4c954a6e214c)
  unreachable
bb31:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l32, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t72)
  store i32 %t75, ptr %l35
  br label %bb32
bb32:
  %t76 = load ptr, ptr %l32, !tbaa !29
  %t77 = load i32, ptr %l35, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v2, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l36
  br label %bb33
bb33:
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i64
  %l7 = alloca i1
  %l13 = alloca i64
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l28 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca %"compiler/check:landing"
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = load i1, ptr %l3, !tbaa !21
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandedOn(ptr %v0, ptr %v1, ptr %t11, ptr %t12, i1 %t13)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 66
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t26)
  store ptr %t28, ptr %l19
  br label %bb8
bb7:
  br label %bb20
bb8:
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t31 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 0
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  store i64 %t33, ptr %l22, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t34)
  store %"compiler/source:Span" %t36, ptr %l24
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t40 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t37)
  store i32 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l28, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t45 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t42)
  store i32 %t45, ptr %l31
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i32, ptr %l31, !tbaa !23
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t48, ptr %l32
  br label %bb12
bb12:
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = load %"compiler/source:Span", ptr %l24
  %t52 = load i32, ptr %l27, !tbaa !23
  %t53 = load i64, ptr %l32, !tbaa !24
  %t54 = call %"compiler/check:landing" @compiler_2fcheck_3alanding_2ector(ptr %s2, i64 %t49, i64 %t50, %"compiler/source:Span" %t51, i32 %t52, i64 %t53)
  store %"compiler/check:landing" %t54, ptr %l33
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l17, !tbaa !29
  %t56 = load %"compiler/check:landing", ptr %l33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2ePush_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %t55, %"compiler/check:landing" %t56)
  br label %bb14
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l34, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l35, !tbaa !29
  %t59 = load i64, ptr %l4, !tbaa !24
  store i64 %t59, ptr %l36, !tbaa !24
  %t60 = load i1, ptr %l3, !tbaa !21
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emovesHere(ptr %v0, ptr %t64)
  store i1 %t66, ptr %l41
  br label %bb17
bb16:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb18
bb17:
  %t67 = load i1, ptr %l41, !tbaa !21
  store i1 %t67, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t68 = load ptr, ptr %l34, !tbaa !29
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i64, ptr %l36, !tbaa !24
  %t71 = load i1, ptr %l39, !tbaa !21
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandOn(ptr %v0, ptr %v1, ptr %v3, ptr %t68, ptr %t69, i64 %t70, i1 %t71)
  store ptr %t72, ptr %l42
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t73 = load ptr, ptr %l42, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l43, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t75)
  store %"compiler/source:Span" %t77, ptr %l45
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t78)
  store i32 %t81, ptr %l48
  br label %bb22
bb22:
  %t83 = load ptr, ptr %l43, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l45
  %t85 = load i32, ptr %l48, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueErr(ptr %v0, ptr %v2, ptr %t83, %"compiler/source:Span" %t84, i32 %t85, { i64, ptr } %a2)
  br label %bb23
bb23:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l9 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l14
  br label %bb4
bb4:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l20
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t34 = load i64, ptr %l20, !tbaa !24
  %t35 = icmp sle i64 %t34, 64
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l15, !tbaa !21
  store i1 %t37, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l9, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca i32
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l49 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l58 = alloca ptr
  %l63 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l99 = alloca i32
  %l103 = alloca ptr
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i32
  %l115 = alloca i64
  %l118 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca i64
  %l128 = alloca ptr
  %l129 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i32
  %l156 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l166 = alloca ptr
  %l167 = alloca i64
  %l171 = alloca ptr
  %l176 = alloca i64
  %l178 = alloca ptr
  %l181 = alloca i64
  %l182 = alloca i32
  %l183 = alloca i64
  %l185 = alloca ptr
  %l188 = alloca i64
  %l189 = alloca i32
  %l195 = alloca ptr
  %l198 = alloca i64
  %l202 = alloca { i64, i64, i64 }
  %l206 = alloca ptr
  %l207 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i64
  %l210 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l213 = alloca i32
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l221 = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t264 = alloca { i64, [4 x i64] }, align 8
  %t419 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v2, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l29
  br label %bb1
bb1:
  %t8 = load i64, ptr %l29, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l30, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l31
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l33
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l30, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l31
  %t16 = load i32, ptr %l33, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l34
  br label %bb3
bb3:
  %t18 = load i64, ptr %l34, !tbaa !24
  store i64 %t18, ptr %l9, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l35, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l36
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l39, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l40, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l41
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l43
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l40, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l41
  %t32 = load i32, ptr %l43, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l44
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l36
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l39, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l44, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 37
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l49
  br label %bb7
bb7:
  %t53 = load i64, ptr %l49, !tbaa !24
  store i64 %t53, ptr %l10, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t59 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t54, i32 2, %"compiler/source:Span" %t55)
  store { i64, i64, i64 } %t59, ptr %l53
  br label %bb8
bb8:
  %t60 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t60, ptr %l11
  %t61 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l13, !tbaa !24
  %t67 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t70)
  store ptr %t72, ptr %l58
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l58, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 10
  %t76 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t79)
  store ptr %t81, ptr %l63
  br label %bb11
bb11:
  %t82 = load ptr, ptr %l63, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 11
  %t85 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  br label %bb12
bb12:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/ast:ForIn", ptr %t88, i32 0, i32 3
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t93)
  store ptr %t95, ptr %l70
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t96 = load ptr, ptr %l70, !tbaa !29
  store ptr %t96, ptr %l71, !tbaa !29
  %t97 = load ptr, ptr %l71, !tbaa !29
  %t98 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 15
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = add i64 %t99, 1
  %t103 = load ptr, ptr %l71, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 15
  store i64 %t101, ptr %t104, !tbaa !24
  br label %bb16
bb16:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l74, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t106, ptr %l75
  %t107 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t107, ptr %l76
  store i64 %a5, ptr %l77, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l1
  %t111 = load i64, ptr %l8, !tbaa !24
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t109, %"compiler/source:Span" %t110, i64 %t111)
  store ptr %t115, ptr %l81
  br label %bb17
bb17:
  %t116 = load ptr, ptr %l81, !tbaa !29
  store ptr %t116, ptr %l82, !tbaa !29
  %t117 = icmp sge i64 0, 0
  br i1 %t117, label %bb18, label %bb19
bb18:
  %t119 = icmp sle i64 0, 1152921504606846975
  br i1 %t119, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb20:
  %t121 = mul i64 0, 8
  %t122 = insertvalue { i64, ptr } undef, i64 0, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t123, ptr %l85, !tbaa !27
  %t124 = icmp sge i64 0, 0
  br i1 %t124, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb22:
  %t126 = icmp sle i64 0, 1152921504606846975
  br i1 %t126, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb24:
  %t128 = mul i64 0, 8
  %t129 = insertvalue { i64, ptr } undef, i64 0, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t130, ptr %l88, !tbaa !27
  %t131 = icmp sge i64 0, 0
  br i1 %t131, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb26:
  %t133 = icmp sle i64 0, 2305843009213693951
  br i1 %t133, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb28:
  %t135 = mul i64 0, 4
  %t136 = insertvalue { i64, ptr } undef, i64 0, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t138 = load ptr, ptr %l74, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l75
  %t140 = load %"compiler/source:Span", ptr %l76
  %t141 = load i64, ptr %l77, !tbaa !24
  %t142 = load ptr, ptr %l82, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t138, %"compiler/source:Span" %t139, %"compiler/source:Span" %t140, i64 %t141, ptr %t142, { i64, ptr } %t143, { i64, ptr } %t144, { i64, ptr } %t137)
  store ptr %t146, ptr %l92
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb30:
  %t147 = load ptr, ptr %l92, !tbaa !29
  store ptr %t147, ptr %l15, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l93, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l94, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l95
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l96, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t152, ptr %l97
  %t153 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t153, ptr %l98, !tbaa !23
  store i32 15, ptr %l99
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  %t156 = load i64, ptr %l9, !tbaa !24
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t154, %"compiler/source:Span" %t155, i64 %t156)
  store ptr %t160, ptr %l103
  br label %bb31
bb31:
  %t161 = load ptr, ptr %l15, !tbaa !29
  %t163 = load ptr, ptr %l96, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l97
  %t165 = load i32, ptr %l98, !tbaa !23
  %t166 = load i32, ptr %l99, !range !{i32 0, i32 52}
  %t167 = load ptr, ptr %l103, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t163, %"compiler/source:Span" %t164, i32 %t165, i32 %t166, ptr %t167, ptr %t161)
  store ptr %t169, ptr %l106
  br label %bb32
bb32:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load ptr, ptr %l94, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l95
  %t173 = load ptr, ptr %l106, !tbaa !29
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v0, ptr %v0, ptr %t171, %"compiler/source:Span" %t172, ptr %t173, i64 %t170)
  store ptr %t175, ptr %l108
  br label %bb33
bb33:
  %t176 = load ptr, ptr %l93, !tbaa !29
  %t177 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t176, ptr %t177)
  br label %bb34
bb34:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l109, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l110, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l8, !tbaa !24
  %t184 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t180, i64 %t181)
  store i32 %t184, ptr %l113
  br label %bb35
bb35:
  %t185 = load ptr, ptr %l110, !tbaa !29
  %t186 = load i32, ptr %l113, !tbaa !23
  %t187 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t187, ptr %l114
  br label %bb36
bb36:
  %t188 = load ptr, ptr %l109, !tbaa !29
  %t189 = load i32, ptr %l114, !tbaa !23
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueWalk(ptr %v0, ptr %t188, i32 %t189)
  store i64 %t190, ptr %l115
  br label %bb37
bb37:
  %t191 = load i64, ptr %l115, !tbaa !24
  store i64 %t191, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = icmp slt i64 %t192, 0
  br i1 %t194, label %bb38, label %bb39
bb38:
  store i64 %a4, ptr %l118, !tbaa !24
  br label %bb40
bb39:
  %t198 = load i64, ptr %l16, !tbaa !24
  store i64 %t198, ptr %l118, !tbaa !24
  br label %bb40
bb40:
  %t200 = load i64, ptr %l118, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l121, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t202, ptr %l122
  %t203 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t203, ptr %l123
  store i64 %t200, ptr %l124, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  %t207 = load i64, ptr %l8, !tbaa !24
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t205, %"compiler/source:Span" %t206, i64 %t207)
  store ptr %t211, ptr %l128
  br label %bb41
bb41:
  %t212 = load ptr, ptr %l128, !tbaa !29
  store ptr %t212, ptr %l129, !tbaa !29
  %t213 = icmp sge i64 0, 0
  br i1 %t213, label %bb42, label %bb43
bb42:
  %t215 = icmp sle i64 0, 1152921504606846975
  br i1 %t215, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb44:
  %t217 = mul i64 0, 8
  %t218 = insertvalue { i64, ptr } undef, i64 0, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t219, ptr %l132, !tbaa !27
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l133, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l1
  %t223 = load i64, ptr %l9, !tbaa !24
  %t227 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t221, %"compiler/source:Span" %t222, i64 %t223)
  store ptr %t227, ptr %l137
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb46:
  %t228 = load ptr, ptr %l133, !tbaa !29
  %t229 = load ptr, ptr %l137, !tbaa !29
  %t230 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t228, ptr %t229)
  store { i64, ptr } %t230, ptr %l138
  br label %bb47
bb47:
  %t231 = icmp sge i64 0, 0
  br i1 %t231, label %bb48, label %bb49
bb48:
  %t233 = icmp sle i64 0, 2305843009213693951
  br i1 %t233, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb50:
  %t235 = mul i64 0, 4
  %t236 = insertvalue { i64, ptr } undef, i64 0, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t238 = load ptr, ptr %l121, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l122
  %t240 = load %"compiler/source:Span", ptr %l123
  %t241 = load i64, ptr %l124, !tbaa !24
  %t242 = load ptr, ptr %l129, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t238, %"compiler/source:Span" %t239, %"compiler/source:Span" %t240, i64 %t241, ptr %t242, { i64, ptr } %t243, { i64, ptr } %t244, { i64, ptr } %t237)
  store ptr %t246, ptr %l142
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb52:
  %t247 = load ptr, ptr %l142, !tbaa !29
  store ptr %t247, ptr %l18, !tbaa !29
  %t248 = load i64, ptr %l16, !tbaa !24
  %t250 = icmp sge i64 %t248, 0
  br i1 %t250, label %bb53, label %bb54
bb53:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l145, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l146
  %t254 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t254, ptr %l147
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l148, !tbaa !29
  %t256 = load ptr, ptr %l18, !tbaa !29
  %t259 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t256)
  store i32 %t259, ptr %l151
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t260 = load ptr, ptr %l148, !tbaa !29
  %t261 = load i32, ptr %l151, !tbaa !23
  %t262 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t262, ptr %l152
  br label %bb56
bb56:
  %t263 = load ptr, ptr %l18, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t264
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 0
  store i64 2, ptr %t265
  %t266 = load %"compiler/source:Span", ptr %l147
  %t267 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t266, 0
  %t268 = load i32, ptr %l152, !tbaa !23
  %t269 = insertvalue { %"compiler/source:Span", i32, ptr } %t267, i32 %t268, 1
  %t271 = insertvalue { %"compiler/source:Span", i32, ptr } %t269, ptr %t263, 2
  %t272 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t271, ptr %t272
  %t273 = load { i64, [4 x i64] }, ptr %t264
  %t275 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t273, ptr %t275
  %t276 = load ptr, ptr %l145, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l146
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t276, %"compiler/source:Span" %t277, ptr %t275)
  store ptr %t279, ptr %l156
  br label %bb57
bb57:
  %t280 = load ptr, ptr %l156, !tbaa !29
  store ptr %t280, ptr %l18, !tbaa !29
  br label %bb58
bb58:
  %t281 = load ptr, ptr %l2, !tbaa !29
  %t283 = getelementptr %"compiler/ast:ForIn", ptr %t281, i32 0, i32 3
  %t284 = load i1, ptr %t283, !tbaa !21
  br i1 %t284, label %bb59, label %bb60
bb59:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t286)
  store ptr %t288, ptr %l160
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t289 = load ptr, ptr %l160, !tbaa !29
  store ptr %t289, ptr %l161, !tbaa !29
  %t290 = load ptr, ptr %l161, !tbaa !29
  %t291 = getelementptr %"compiler/check:frame", ptr %t290, i32 0, i32 15
  %t292 = load i64, ptr %t291, !tbaa !24
  %t294 = sub i64 %t292, 1
  %t296 = load ptr, ptr %l161, !tbaa !29
  %t297 = getelementptr %"compiler/check:frame", ptr %t296, i32 0, i32 15
  store i64 %t294, ptr %t297, !tbaa !24
  br label %bb62
bb62:
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l164, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t299, ptr %l165
  %t300 = load ptr, ptr %l2, !tbaa !29
  store ptr %t300, ptr %l166, !tbaa !29
  %t301 = load i64, ptr %l9, !tbaa !24
  store i64 %t301, ptr %l167, !tbaa !24
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l18, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l1
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v0, ptr %v0, ptr %t302, ptr %t303, %"compiler/source:Span" %t304, i1 false)
  store ptr %t308, ptr %l171
  br label %bb63
bb63:
  %t309 = load ptr, ptr %l164, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l165
  %t311 = load ptr, ptr %l166, !tbaa !29
  %t312 = load i64, ptr %l167, !tbaa !24
  %t313 = load ptr, ptr %l171, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t309, %"compiler/source:Span" %t310, ptr %t311, i64 %t312, ptr %t313)
  br label %bb64
bb64:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t314, ptr %t315, ptr %a6, i32 %a7)
  br label %bb65
bb65:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t322)
  store ptr %t324, ptr %l178
  br label %bb66
bb66:
  %t325 = load ptr, ptr %l178, !tbaa !29
  %t327 = getelementptr %"compiler/check:frame", ptr %t325, i32 0, i32 10
  %t329 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t327)
  %t330 = extractvalue { i32, i64 } %t329, 1
  %t331 = extractvalue { i32, i64 } %t329, 0
  store i32 %t331, ptr %l182
  %t332 = icmp ne i32 %t331, 0
  br i1 %t332, label %bb68, label %ok.333, !prof !99
ok.333:
  store i64 %t330, ptr %l181
  br label %bb67
bb67:
  %t334 = load i64, ptr %l181, !tbaa !24
  store i64 %t334, ptr %l176, !tbaa !24
  br label %bb70
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t335)
  store ptr %t337, ptr %l185
  br label %bb71
bb71:
  %t338 = load ptr, ptr %l185, !tbaa !29
  %t340 = getelementptr %"compiler/check:frame", ptr %t338, i32 0, i32 11
  %t342 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t340)
  %t343 = extractvalue { i32, i64 } %t342, 1
  %t344 = extractvalue { i32, i64 } %t342, 0
  store i32 %t344, ptr %l189
  %t345 = icmp ne i32 %t344, 0
  br i1 %t345, label %bb73, label %ok.346, !prof !99
ok.346:
  store i64 %t343, ptr %l188
  br label %bb72
bb72:
  %t347 = load i64, ptr %l188, !tbaa !24
  store i64 %t347, ptr %l183, !tbaa !24
  br label %bb75
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i64, ptr %l12, !tbaa !24
  %t350 = load i64, ptr %l13, !tbaa !24
  %t351 = load i64, ptr %l14, !tbaa !24
  %t352 = load i64, ptr %l10, !tbaa !24
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t348, i64 %t349, i64 %t350, i64 %t351, i64 %t352)
  store ptr %t358, ptr %l195
  br label %bb76
bb76:
  %t359 = load ptr, ptr %l195, !tbaa !29
  store ptr %t359, ptr %l19, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/check:Checker", ptr %t360, i32 0, i32 37
  %t364 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t362)
  store i64 %t364, ptr %l198
  br label %bb77
bb77:
  %t365 = load i64, ptr %l198, !tbaa !24
  store i64 %t365, ptr %l20, !tbaa !24
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l1
  %t371 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t366, i32 3, %"compiler/source:Span" %t367)
  store { i64, i64, i64 } %t371, ptr %l202
  br label %bb78
bb78:
  %t372 = load { i64, i64, i64 }, ptr %l202
  store { i64, i64, i64 } %t372, ptr %l21
  %t373 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 0
  %t374 = load i64, ptr %t373, !tbaa !24
  store i64 %t374, ptr %l22, !tbaa !24
  %t376 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 1
  %t377 = load i64, ptr %t376, !tbaa !24
  store i64 %t377, ptr %l23, !tbaa !24
  %t379 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 2
  %t380 = load i64, ptr %t379, !tbaa !24
  store i64 %t380, ptr %l24, !tbaa !24
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l206, !tbaa !29
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l207, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t384, ptr %l208
  %t385 = load i64, ptr %l9, !tbaa !24
  store i64 %t385, ptr %l209, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l210, !tbaa !29
  %t387 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t387, ptr %l211
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t388)
  store i32 %t390, ptr %l213
  br label %bb79
bb79:
  %t391 = load ptr, ptr %l210, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l211
  %t393 = load i32, ptr %l213, !tbaa !23
  %t394 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t391, %"compiler/source:Span" %t392, i32 %t393, i64 1)
  store ptr %t394, ptr %l214
  br label %bb80
bb80:
  %t395 = load ptr, ptr %l207, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l208
  %t397 = load i64, ptr %l209, !tbaa !24
  %t398 = load ptr, ptr %l214, !tbaa !29
  %t399 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t395, %"compiler/source:Span" %t396, i64 %t397, ptr %t398)
  store ptr %t399, ptr %l215
  br label %bb81
bb81:
  %t400 = load ptr, ptr %l206, !tbaa !29
  %t401 = load ptr, ptr %l215, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t400, ptr %t401)
  br label %bb82
bb82:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i64, ptr %l22, !tbaa !24
  %t404 = load i64, ptr %l23, !tbaa !24
  %t405 = load i64, ptr %l24, !tbaa !24
  %t406 = load i64, ptr %l20, !tbaa !24
  %t412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t402, i64 %t403, i64 %t404, i64 %t405, i64 %t406)
  store ptr %t412, ptr %l221
  br label %bb83
bb83:
  %t413 = load ptr, ptr %l221, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load %"compiler/source:Span", ptr %l1
  %t416 = load ptr, ptr %l19, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t419
  %t420 = getelementptr { i64, [3 x i64] }, ptr %t419, i32 0, i32 0
  store i64 4, ptr %t420
  %t422 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t415, 0
  %t424 = insertvalue { %"compiler/source:Span", ptr, ptr } %t422, ptr %t416, 1
  %t426 = insertvalue { %"compiler/source:Span", ptr, ptr } %t424, ptr %t413, 2
  %t427 = getelementptr { i64, [3 x i64] }, ptr %t419, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t426, ptr %t427
  %t428 = load { i64, [3 x i64] }, ptr %t419
  %t430 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t428, ptr %t430
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t414, ptr %t430)
  br label %bb84
bb84:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esome(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2ereaches(ptr %v0, ptr %a0, i32 %t28)
  store i1 %t31, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2edeclaredFact(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i1, ptr %l9, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca double
  %l2 = alloca double
  %l5 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load double, ptr %l1, !tbaa !26
  %t3 = fcmp ogt double %t1, 0x7fefffffffffffff
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load double, ptr %l1, !tbaa !26
  %t7 = fcmp olt double %t5, 0xffefffffffffffff
  store i1 %t7, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load double, ptr %l1, !tbaa !26
  store double %t11, ptr %l2, !tbaa !26
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 13
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t17 = load double, ptr %l1, !tbaa !26
  %t19 = fptrunc double %t17 to float
  %t21 = fpext float %t19 to double
  store double %t21, ptr %l2, !tbaa !26
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t23 = load i32, ptr %l0, !tbaa !23
  %t25 = icmp eq i32 %t23, 11
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load double, ptr %l1, !tbaa !26
  %t29 = fptrunc double %t27 to half
  %t31 = fpext half %t29 to double
  store double %t31, ptr %l2, !tbaa !26
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t33 = load i32, ptr %l0, !tbaa !23
  %t35 = icmp eq i32 %t33, 12
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load double, ptr %l1, !tbaa !26
  %t39 = fptrunc double %t37 to bfloat
  %t41 = bitcast bfloat %t39 to i16
  %t42 = zext i16 %t41 to i32
  %t43 = shl i32 %t42, 16
  %t44 = bitcast i32 %t43 to float
  %t45 = fpext float %t44 to double
  store double %t45, ptr %l2, !tbaa !26
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t47 = load double, ptr %l2, !tbaa !26
  %t49 = fcmp ogt double %t47, 0x7fefffffffffffff
  br i1 %t49, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t51 = load double, ptr %l2, !tbaa !26
  %t53 = fcmp olt double %t51, 0xffefffffffffffff
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l27, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 true, i1 false, i64 0, double %a0)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2ematchExisting(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %l27 = alloca i1
  %l35 = alloca i1
  %l45 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l4, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Arm", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Arm", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3bef89c29375057e_93446d82378ce1ba)
  unreachable
bb8:
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Arm", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l27
  br label %bb10
bb10:
  %t48 = load i1, ptr %l27, !tbaa !21
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t49 = load i1, ptr %l21, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb1
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Match", ptr %t64, i32 0, i32 2
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb20:
  br label %bb21
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Match", ptr %t71, i32 0, i32 2
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Arm", ptr %t74, i32 0, i32 4
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l35, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Match", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = icmp eq ptr %t88, null
  br i1 %t90, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb26:
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Match", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Arm", ptr %t95, i32 0, i32 4
  %t99 = load ptr, ptr %t98, !tbaa !29
  store ptr %t99, ptr %l5, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb29:
  br label %bb30
bb30:
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t105)
  store i1 %t107, ptr %l56
  br label %bb31
bb31:
  %t108 = load i1, ptr %l56, !tbaa !21
  store i1 %t108, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l45, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t3 = trunc i64 67 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb4:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t8 = trunc i64 68 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb8:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t13 = trunc i64 69 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb12:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t18 = trunc i64 71 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb16:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t23 = trunc i64 72 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb20:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t28 = trunc i64 73 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb24:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t33 = trunc i64 96 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb33
bb26:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t38 = trunc i64 98 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t43 = trunc i64 97 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t48 = trunc i64 99 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb34:
  %t51 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t53 = trunc i64 100 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb38:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t58 = trunc i64 101 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb42:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t63 = trunc i64 102 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb46:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t68 = trunc i64 105 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb50:
  %t71 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t73 = trunc i64 106 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb54:
  %t76 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t78 = trunc i64 70 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_445c35e7b454dfb2_9156676d88e8071e)
  unreachable
bb63:
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2eplainLen(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb17
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32 }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 113}
  store i32 %t23, ptr %l1
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t27 = trunc i64 2 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l2, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_64562bc7ca55259a_4dcf078b9ca87c6)
  unreachable
bb17:
  %t30 = load i1, ptr %l2, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2etextBytes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l19 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t12, ptr %lp1
  %t14 = load ptr, ptr %lp1
  store { i64, ptr } %t11, ptr %t14, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7873eed4a01e5678_b9c164dc568d47a4)
  unreachable
bb3:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  br label %bb8
bb5:
  br label %bb6
bb6:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t43 = load ptr, ptr %lp1
  %t45 = getelementptr { i64, ptr }, ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t29
  store i8 %t37, ptr %t47, !tbaa !32
  br label %bb7
bb7:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb3
bb8:
  %t52 = load ptr, ptr %lp1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:inPlaceRead" @compiler_2fcheck_3ainPlaceRead_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %rv = alloca %"compiler/check:inPlaceRead"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:inPlaceRead" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:inPlaceRead" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  %t14 = insertvalue %"compiler/check:inPlaceRead" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:inPlaceRead" %t14, %"compiler/source:Span" %a3, 3
  store %"compiler/check:inPlaceRead" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:inPlaceRead", ptr %rv
  ret %"compiler/check:inPlaceRead" %rr
}

define dso_local %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %v0, i1 %a0, i32 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:reflList"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:reflList" undef, i1 %a0, 0
  %t12 = insertvalue %"compiler/check:reflList" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/check:reflList" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:reflList" %t14, i64 %a3, 3
  store %"compiler/check:reflList" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflList", ptr %rv
  ret %"compiler/check:reflList" %rr
}

@.d0 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"LeadingZeros" }>, align 8
@.d1 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"TrailingZeros" }>, align 8
@.d2 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"PopCount" }>, align 8
@.d3 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RotateLeft" }>, align 8
@.d4 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"RotateRight" }>, align 8
@.d5 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ByteSwap" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a conversion of this kind" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d9 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/argument" }>, align 8
@.d10 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ArgumentError" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d13 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Vec" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Map" }>, align 8
@.d17 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"StringBuilder" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"std/set" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Set" }>, align 8
@.d20 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"std/deque" }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Deque" }>, align 8
@.d22 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"std/heap" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Heap" }>, align 8
@.d24 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"an unreachable's" }>, align 8
@.d25 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"an assert's" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d31 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"NoReturn" }>, align 8
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Exported" }>, align 8
@.d33 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Extern" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Commutes" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d36 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Div" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Rem" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"MatMul" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Less" }>, align 8
@.d42 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d43 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d44 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d45 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ShiftLeft" }>, align 8
@.d46 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ShiftRight" }>, align 8
@.d47 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a3fc486149a2dc5d_17491af4361141b9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
@olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2fb1f9f5dda04b10_a3bd6c7ca1760a54 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
@olang_loc_5d13064994ae0ba3_8fd3ca0506e03b5f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_82b0d2a61edf3c68_78216e4ccea776dc = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerBinding(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderNotValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i32 %a5)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_854899d5724a103b_e7dfb19072d83fa7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6)
@olang_loc_852b58c2eb82b3cc_e47a0c64d3951188 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_eaffdf15d9c064d4_e1a7ee300abdca20 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_27e3ab5b7d984c5a_74f0959f23b09f6e = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, ptr %a6)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4b7cfa1fb5fcb474_4538ddb4be3a0770 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargumentPush(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3, i1 %a4)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
@olang_loc_6f8999b7f8ddffc_ce9c2022d5a87cc8 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
@olang_loc_ad8923f011cb5acf_6f8a151e60866063 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDtorWritten(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_968c62dd2cdb7cc9_e4aa23f03d53ae95 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9c0e2310e04cd1f8_9ba0cca7b5a93fa4 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a3ad144bf6dfe67e_aaa74880c72315a2 = external constant [0 x i8]
@olang_loc_cf50a113ac2177e6_e3cc5936e852a452 = external constant [0 x i8]
@olang_loc_baddfb655e016c47_d17e78f9e01d2853 = external constant [0 x i8]
@olang_loc_3e69957d7270204c_dfbf9d9d846a9638 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9109cadfb541186e_2a46ab96c2b41f0a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i32 %a5, i64 %a6)
@olang_loc_24473ecab934ff5a_e5063e673d38f936 = external constant [0 x i8]
@olang_loc_1dc6773449e59e5b_c7fcef2f52138cd7 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, i64 %a5, i64 %a6, ptr %a7)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunbindCase(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a227993f85dd5ea2_8a35cef040514d1e = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5a62b0635aab9a02_96142af7f6ac351e = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_77892b47b9a99b47_46cd468a4d441f7b = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundBy(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenericNeeds(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBare(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGenericNeeds(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_eb65b3680edb0345_685145072e457a11 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_becd3eb77e076db3_2d856a700a1e74b7 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
@olang_loc_fb06dcd16342dc9_94e70e479081575d = external constant [0 x i8]
declare %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v0)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v0, i64 %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd27b567062a69be2f699d8e9ab74cf5a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf1792c165fec863e4f2028b41ed50f44(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epuns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropsGone(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8ded448c56d61a9a_a1642562b2a40e16 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUntagged(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncNullable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_aba8aa6938d7a087_5d05cf2ee38e12b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_e0d7a6d968754368_2e78c0e3cd1ef5bc = external constant [0 x i8]
@olang_loc_2b61f833cd126364_51d75042885d0038 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@olang_loc_e722c21055ee6b49_58bcebf0b772fb7d = external constant [0 x i8]
@olang_loc_eca48244095fc078_aacf4c954a6e214c = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandedOn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:landing" @compiler_2fcheck_3alanding_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2ePush_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %a0, %"compiler/check:landing" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emovesHere(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueErr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
@olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8 = external constant [0 x i8]
@olang_loc_19568a04807ed851_528b5bfe222c3865 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueWalk(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_130b25e968db6b32_47c65c95f253846 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2ereaches(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
@olang_loc_3bef89c29375057e_93446d82378ce1ba = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
@olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541 = external constant [0 x i8]
@olang_loc_445c35e7b454dfb2_9156676d88e8071e = external constant [0 x i8]
@olang_loc_64562bc7ca55259a_4dcf078b9ca87c6 = external constant [0 x i8]
@olang_loc_7873eed4a01e5678_b9c164dc568d47a4 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
