; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/check:factRead" = type { i64, i64, { i64, ptr }, i1, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i32, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:pathMarks" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i64, i1, i64 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, { i64, ptr }, i64, i1, i64 }
%"compiler/check:errNarrow" = type { { i64, ptr }, i32, i64, i64, i1, i64 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/check:litBuilder" = type { i64, i32 }
%"compiler/check:seqOf" = type { i32, i64, i64, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/check:landing" = type { i64, i64, %"compiler/source:Span", i32, i64 }
%"compiler/check:TopAssertAsk" = type { i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:idleCall" = type { i64, i64, %"compiler/source:Span", { i64, ptr }, ptr }
%"compiler/check:inPlaceRead" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span" }
%"compiler/check:roOrigin" = type { ptr, i1 }
define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtBinding(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/typed:Local"
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca ptr
  %l29 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca %"compiler/typed:Local"
  %l57 = alloca ptr
  %l62 = alloca i32
  %l67 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i32
  %l76 = alloca ptr
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l5, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l5, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l16
  br label %bb3
bb3:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l20
  br label %bb6
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i1, ptr %l20, !tbaa !21
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l17, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  store ptr %t32, ptr %l24, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l34
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l24, !tbaa !29
  %t54 = load i32, ptr %l29, !tbaa !23
  %t55 = load i32, ptr %l34, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t53, i32 %t54, i32 %t55)
  store i1 %t56, ptr %l35
  br label %bb12
bb12:
  %t57 = load i1, ptr %l35, !tbaa !21
  store i1 %t57, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l21, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l37, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l38
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s1, ptr %t63, i32 %a2)
  store { i64, ptr } %t67, ptr %l41
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t68 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l42, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l5, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t75, i32 %t76)
  store { i64, ptr } %t79, ptr %l45
  br label %bb17
bb17:
  %t80 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t89 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %s1, ptr %s1, ptr %v0, { i64, ptr } %t87, { i64, ptr } %t86)
  store %"compiler/diagmsg:Msg" %t89, ptr %l47
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l37, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l38
  %t92 = load %"compiler/diagmsg:Msg", ptr %l47
  %t93 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t90, %"compiler/source:Span" %t91, %"compiler/diagmsg:Msg" %t92)
  store i64 %t93, ptr %l48
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t94)
  store ptr %t96, ptr %l50
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l50, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Body", ptr %t97, i32 0, i32 7
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t99, i64 %t100)
  store %"compiler/typed:Local" %t103, ptr %l54
  br label %bb22
bb22:
  %t104 = load %"compiler/typed:Local", ptr %l54
  store %"compiler/typed:Local" %t104, ptr %l6
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  store ptr %t110, ptr %l57, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l62
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l5, !tbaa !23
  %t130 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t126, i32 %t127)
  store i64 %t130, ptr %l67
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t136, i32 %t137)
  store i64 %t140, ptr %l72
  br label %bb25
bb25:
  %t141 = load i64, ptr %l67, !tbaa !24
  %t142 = load i64, ptr %l72, !tbaa !24
  %t143 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t141, i64 %t142)
  store i64 %t143, ptr %l73
  br label %bb26
bb26:
  %t144 = load ptr, ptr %l57, !tbaa !29
  %t145 = load i32, ptr %l62, !tbaa !23
  %t146 = load i64, ptr %l73, !tbaa !24
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t144, i32 %t145, i64 %t146)
  store i32 %t147, ptr %l74
  br label %bb27
bb27:
  %t148 = load i32, ptr %l74, !tbaa !23
  %t149 = getelementptr %"compiler/typed:Local", ptr %l6, i32 0, i32 2
  store i32 %t148, ptr %t149, !tbaa !23
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t150)
  store ptr %t152, ptr %l76
  br label %bb28
bb28:
  %t153 = load ptr, ptr %l76, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Body", ptr %t153, i32 0, i32 7
  %t156 = load i64, ptr %l3, !tbaa !24
  %t157 = load %"compiler/typed:Local", ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t155, i64 %t156, %"compiler/typed:Local" %t157)
  br label %bb29
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  store ptr %t14, ptr %l9, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i32, ptr %l12, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l13
  br label %bb5
bb5:
  %t23 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t25 = trunc i64 19 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l6, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, [3 x i64] }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l65 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca ptr
  %l116 = alloca i64
  %l118 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca { i64, [3 x i64] }
  %l135 = alloca %"compiler/diagmsg:Msg"
  %l136 = alloca i64
  %l137 = alloca %"std/prelude/text:StringBuilder"
  %l140 = alloca i64
  %l144 = alloca i64
  %l147 = alloca i64
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca ptr
  %l170 = alloca i64
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l178 = alloca ptr
  %l179 = alloca ptr
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l190 = alloca { i64, [3 x i64] }
  %l192 = alloca { i64, ptr }
  %l194 = alloca %"compiler/diagmsg:Msg"
  %l195 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t177 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t3)
  store i64 %t5, ptr %l28
  br label %bb1
bb1:
  %t6 = load i64, ptr %l28, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l35, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l35, !tbaa !24
  store i64 %t33, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l32, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 35
  store ptr %t55, ptr %l54, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l55, !tbaa !29
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t57, i64 %t51)
  store i64 %t61, ptr %l58
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l55, !tbaa !29
  %t63 = load i64, ptr %l58, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t62, i64 %t63)
  store i64 %t64, ptr %l59
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l54, !tbaa !29
  %t66 = load i64, ptr %l59, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t67, ptr %l60
  br label %bb14
bb14:
  %t68 = load i1, ptr %l60, !tbaa !21
  br i1 %t68, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l8, !tbaa !24
  br label %bb8
bb19:
  %t73 = load i64, ptr %l3, !tbaa !24
  store i64 %t73, ptr %l10, !tbaa !24
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t75)
  store i64 %t77, ptr %l65
  br label %bb20
bb20:
  %t78 = load i64, ptr %l65, !tbaa !24
  store i64 %t78, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t85 = load i64, ptr %l12, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb26
bb23:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l12, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l72, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb25
bb25:
  %t105 = load i64, ptr %l72, !tbaa !24
  store i64 %t105, ptr %l69, !tbaa !24
  br label %bb26
bb26:
  %t106 = load i64, ptr %l69, !tbaa !24
  store i64 %t106, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb27
bb27:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l13, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb28, label %bb29
bb28:
  br label %bb35
bb29:
  br label %bb30
bb30:
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 35
  store ptr %t127, ptr %l91, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  store ptr %t128, ptr %l92, !tbaa !29
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t129, i64 %t123)
  store i64 %t133, ptr %l95
  br label %bb31
bb31:
  %t134 = load ptr, ptr %l92, !tbaa !29
  %t135 = load i64, ptr %l95, !tbaa !24
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t134, i64 %t135)
  store i64 %t136, ptr %l96
  br label %bb32
bb32:
  %t137 = load ptr, ptr %l91, !tbaa !29
  %t138 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t137, i64 %t138, i1 true)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t139 = load i64, ptr %l14, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l14, !tbaa !24
  br label %bb27
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 18
  store ptr %t145, ptr %l100, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  store ptr %t146, ptr %l101, !tbaa !29
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t148 = load i64, ptr %l3, !tbaa !24
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t147, i64 %t148)
  store i64 %t151, ptr %l104
  br label %bb36
bb36:
  %t152 = load ptr, ptr %l101, !tbaa !29
  %t153 = load i64, ptr %l104, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t152, i64 %t153)
  store i64 %t154, ptr %l105
  br label %bb37
bb37:
  %t155 = load ptr, ptr %l100, !tbaa !29
  %t156 = load i64, ptr %l105, !tbaa !24
  %t157 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t155, i64 %t156)
  store ptr %t157, ptr %l106
  br label %bb38
bb38:
  %t158 = load ptr, ptr %l106, !tbaa !29
  store ptr %t158, ptr %l16, !tbaa !29
  %t159 = load ptr, ptr %l16, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Body", ptr %t159, i32 0, i32 3
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load ptr, ptr %l16, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 4
  %t166 = getelementptr %"compiler/source:Span", ptr %t165, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t170 = load ptr, ptr %l16, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t170, i32 0, i32 4
  %t173 = getelementptr %"compiler/source:Span", ptr %t172, i32 0, i32 1
  %t174 = load i32, ptr %t173, !tbaa !23
  %t176 = sext i32 %t174 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t177, i32 0, i32 0
  store i64 3, ptr %t178
  %t180 = insertvalue { i64, i64, i64 } undef, i64 %t162, 0
  %t182 = insertvalue { i64, i64, i64 } %t180, i64 %t169, 1
  %t184 = insertvalue { i64, i64, i64 } %t182, i64 %t176, 2
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t177, i32 0, i32 1
  store { i64, i64, i64 } %t184, ptr %t185
  %t186 = load { i64, [3 x i64] }, ptr %t177
  store { i64, [3 x i64] } %t186, ptr %l17
  %t188 = load i64, ptr %l3, !tbaa !24
  store i64 %t188, ptr %l116, !tbaa !24
  %t189 = load ptr, ptr %l2, !tbaa !29
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t189)
  store i64 %t191, ptr %l118
  br label %bb39
bb39:
  %t192 = load i64, ptr %l118, !tbaa !24
  %t193 = sub i64 %t192, 1
  %t194 = load i64, ptr %l116, !tbaa !24
  %t196 = icmp eq i64 %t194, %t193
  br i1 %t196, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l121, !tbaa !29
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l122, !tbaa !29
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t201 = load i64, ptr %l3, !tbaa !24
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t200, i64 %t201)
  store i64 %t204, ptr %l125
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t205 = load ptr, ptr %l122, !tbaa !29
  %t206 = load i64, ptr %l125, !tbaa !24
  %t207 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t205, i64 %t206)
  store i64 %t207, ptr %l126
  br label %bb43
bb43:
  %t208 = load ptr, ptr %l121, !tbaa !29
  %t209 = load i64, ptr %l126, !tbaa !24
  %t210 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aName(ptr %v0, ptr %s8, ptr %t208, i64 %t209)
  store { i64, ptr } %t210, ptr %l127
  br label %bb44
bb44:
  %t211 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t211, ptr %l18, !tbaa !27
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/load:Loader", ptr %t218, i32 0, i32 4
  %t221 = load ptr, ptr %t220, !tbaa !29
  store ptr %t221, ptr %l131, !tbaa !29
  %t222 = load { i64, [3 x i64] }, ptr %l17
  store { i64, [3 x i64] } %t222, ptr %l132
  %t223 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t227 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGlobalReadsItself(ptr %s8, ptr %s8, ptr %v0, { i64, ptr } %t223, { i64, ptr } %t224)
  store %"compiler/diagmsg:Msg" %t227, ptr %l135
  br label %bb45
bb45:
  %t228 = load ptr, ptr %l131, !tbaa !29
  %t229 = load { i64, [3 x i64] }, ptr %l132
  %t230 = load %"compiler/diagmsg:Msg", ptr %l135
  %t231 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t228, { i64, [3 x i64] } %t229, %"compiler/diagmsg:Msg" %t230)
  store i64 %t231, ptr %l136
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb47:
  %t232 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t232, ptr %l137
  br label %bb48
bb48:
  %t233 = load %"std/prelude/text:StringBuilder", ptr %l137
  store %"std/prelude/text:StringBuilder" %t233, ptr %l19
  %t234 = load i64, ptr %l3, !tbaa !24
  store i64 %t234, ptr %l20, !tbaa !24
  %t236 = load ptr, ptr %l2, !tbaa !29
  %t238 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t236)
  store i64 %t238, ptr %l140
  br label %bb49
bb49:
  %t239 = load i64, ptr %l140, !tbaa !24
  store i64 %t239, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t240 = load i64, ptr %l21, !tbaa !24
  %t241 = load i64, ptr %l20, !tbaa !24
  %t244 = icmp sgt i64 %t240, %t241
  br i1 %t244, label %bb50, label %bb51
bb50:
  %t246 = load i64, ptr %l22, !tbaa !24
  %t248 = icmp sgt i64 %t246, 0
  br i1 %t248, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb55
bb52:
  %t250 = load i64, ptr %l21, !tbaa !24
  %t251 = load i64, ptr %l20, !tbaa !24
  %t254 = sub i64 %t250, %t251
  %t255 = load i64, ptr %l22, !tbaa !24
  %t258 = add i64 %t254, %t255
  %t260 = sub i64 %t258, 1
  %t261 = load i64, ptr %l22, !tbaa !24
  %t264 = sdiv i64 %t260, %t261
  store i64 %t264, ptr %l147, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb54
bb54:
  %t266 = load i64, ptr %l147, !tbaa !24
  store i64 %t266, ptr %l144, !tbaa !24
  br label %bb55
bb55:
  %t267 = load i64, ptr %l144, !tbaa !24
  store i64 %t267, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t268 = load i64, ptr %l24, !tbaa !24
  %t269 = load i64, ptr %l23, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb58:
  br label %bb59
bb59:
  %t276 = load i64, ptr %l20, !tbaa !24
  %t277 = load i64, ptr %l24, !tbaa !24
  %t278 = load i64, ptr %l22, !tbaa !24
  %t281 = mul i64 %t277, %t278
  %t284 = add i64 %t276, %t281
  store ptr %l19, ptr %l165, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l166, !tbaa !29
  %t287 = load ptr, ptr %l1, !tbaa !29
  store ptr %t287, ptr %l167, !tbaa !29
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t288, i64 %t284)
  store i64 %t292, ptr %l170
  br label %bb60
bb60:
  %t293 = load ptr, ptr %l167, !tbaa !29
  %t294 = load i64, ptr %l170, !tbaa !24
  %t295 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t293, i64 %t294)
  store i64 %t295, ptr %l171
  br label %bb61
bb61:
  %t296 = load ptr, ptr %l166, !tbaa !29
  %t297 = load i64, ptr %l171, !tbaa !24
  %t298 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aName(ptr %v0, ptr %s10, ptr %t296, i64 %t297)
  store { i64, ptr } %t298, ptr %l172
  br label %bb62
bb62:
  %t299 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 1
  %t301 = extractvalue { i64, ptr } %t299, 0
  %t302 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t303 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t304 = add i64 %t301, %t303
  %t305 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t304)
  call void @olang_textcopy(ptr %t305, ptr %t300, i64 %t301)
  %t306 = getelementptr i8, ptr %t305, i64 %t301
  call void @olang_textcopy(ptr %t306, ptr %t302, i64 %t303)
  %t307 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t305, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = extractvalue { i64, ptr } %t308, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t316 = load ptr, ptr %l165, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t316, { i64, ptr } %t315)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb64:
  %t318 = load i64, ptr %l24, !tbaa !24
  %t320 = add i64 %t318, 1
  store i64 %t320, ptr %l24, !tbaa !24
  br label %bb56
bb65:
  store ptr %l19, ptr %l177, !tbaa !29
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l178, !tbaa !29
  %t323 = load ptr, ptr %l1, !tbaa !29
  store ptr %t323, ptr %l179, !tbaa !29
  %t324 = load ptr, ptr %l2, !tbaa !29
  %t325 = load i64, ptr %l3, !tbaa !24
  %t328 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t324, i64 %t325)
  store i64 %t328, ptr %l182
  br label %bb66
bb66:
  %t329 = load ptr, ptr %l179, !tbaa !29
  %t330 = load i64, ptr %l182, !tbaa !24
  %t331 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t329, i64 %t330)
  store i64 %t331, ptr %l183
  br label %bb67
bb67:
  %t332 = load ptr, ptr %l178, !tbaa !29
  %t333 = load i64, ptr %l183, !tbaa !24
  %t334 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aName(ptr %v0, ptr %s0, ptr %t332, i64 %t333)
  store { i64, ptr } %t334, ptr %l184
  br label %bb68
bb68:
  %t335 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t342 = load ptr, ptr %l177, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t342, { i64, ptr } %t341)
  br label %bb69
bb69:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:Checker", ptr %t344, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t349 = getelementptr %"compiler/generic:Program", ptr %t347, i32 0, i32 0
  %t350 = load ptr, ptr %t349, !tbaa !29
  %t352 = getelementptr %"compiler/load:Loader", ptr %t350, i32 0, i32 4
  %t353 = load ptr, ptr %t352, !tbaa !29
  store ptr %t353, ptr %l189, !tbaa !29
  %t354 = load { i64, [3 x i64] }, ptr %l17
  store { i64, [3 x i64] } %t354, ptr %l190
  %t356 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l19)
  store { i64, ptr } %t356, ptr %l192
  br label %bb70
bb70:
  %t357 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 0
  %t359 = extractvalue { i64, ptr } %t357, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  %t365 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGlobalsCycle(ptr %s0, ptr %v0, { i64, ptr } %t363)
  store %"compiler/diagmsg:Msg" %t365, ptr %l194
  br label %bb71
bb71:
  %t366 = load ptr, ptr %l189, !tbaa !29
  %t367 = load { i64, [3 x i64] }, ptr %l190
  %t368 = load %"compiler/diagmsg:Msg", ptr %l194
  %t369 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t366, { i64, [3 x i64] } %t367, %"compiler/diagmsg:Msg" %t368)
  store i64 %t369, ptr %l195
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  %t27 = add i64 %a2, 1
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %t21, i64 %t27)
  store i1 %t31, ptr %l21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyAttrs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l42 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l90 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca i1
  %l133 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t2 = load ptr, ptr %l28, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l28, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l29, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l29, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [6 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb25
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/ast:StructBody", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l42, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = getelementptr %"compiler/ast:Param", ptr %t39, i32 0, i32 4
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t41, i64 %t42, { i64, ptr } %t46)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb6
bb12:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/ast:StructBody", ptr %t54, i32 0, i32 2
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t71, ptr %l59, !tbaa !27
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 %t72
  %t77 = load ptr, ptr %t76, !tbaa !39
  store ptr %t77, ptr %l11, !tbaa !29
  %t79 = load ptr, ptr %l11, !tbaa !29
  store ptr %t79, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t80 = load ptr, ptr %l62, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t83 = load ptr, ptr %l62, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 22}
  %t86 = icmp eq i64 %t84, 1
  store i1 %t86, ptr %l63, !tbaa !21
  br label %bb18
bb18:
  %t87 = load i1, ptr %l63, !tbaa !21
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t88 = load ptr, ptr %l11, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", ptr }, ptr %t90, i32 0, i32 0
  %t92 = load %"compiler/source:Span", ptr %t91
  store %"compiler/source:Span" %t92, ptr %l12
  %t94 = load ptr, ptr %l11, !tbaa !29
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", ptr }, ptr %t96, i32 0, i32 1
  %t98 = load ptr, ptr %t97
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  %t105 = getelementptr %"compiler/ast:VarDecl", ptr %t98, i32 0, i32 6
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t100, i64 %t101, { i64, ptr } %t106)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l9, !tbaa !24
  br label %bb13
bb24:
  br label %bb66
bb25:
  %t114 = load ptr, ptr %l2, !tbaa !29
  store ptr %t114, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t115 = load ptr, ptr %l77, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t118 = load ptr, ptr %l77, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 5}
  %t121 = icmp eq i64 %t119, 1
  store i1 %t121, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t122 = load i1, ptr %l78, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr { i64, [6 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { { i64, ptr }, ptr }, ptr %t125, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126
  store { i64, ptr } %t127, ptr %l14, !tbaa !27
  br label %bb30
bb29:
  br label %bb45
bb30:
  %t129 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t129, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l17, !tbaa !24
  br label %bb31
bb31:
  %t135 = load i64, ptr %l16, !tbaa !24
  %t136 = load i64, ptr %l17, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb32, label %bb33
bb32:
  br label %bb44
bb33:
  br label %bb34
bb34:
  %t143 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t143, ptr %l90, !tbaa !27
  %t144 = load i64, ptr %l16, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr ptr, ptr %t147, i64 %t144
  %t149 = load ptr, ptr %t148, !tbaa !39
  store ptr %t149, ptr %l18, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l1, !tbaa !24
  %t153 = load ptr, ptr %l18, !tbaa !29
  %t155 = getelementptr %"compiler/ast:CaseDecl", ptr %t153, i32 0, i32 5
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t151, i64 %t152, { i64, ptr } %t156)
  br label %bb35
bb35:
  %t160 = load ptr, ptr %l18, !tbaa !29
  %t162 = getelementptr %"compiler/ast:CaseDecl", ptr %t160, i32 0, i32 2
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l21, !tbaa !24
  br label %bb36
bb36:
  %t169 = load i64, ptr %l20, !tbaa !24
  %t170 = load i64, ptr %l21, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb37, label %bb38
bb37:
  br label %bb42
bb38:
  br label %bb39
bb39:
  %t177 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t177, ptr %l105, !tbaa !27
  %t178 = load i64, ptr %l20, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr ptr, ptr %t181, i64 %t178
  %t183 = load ptr, ptr %t182, !tbaa !39
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i64, ptr %l1, !tbaa !24
  %t189 = getelementptr %"compiler/ast:Param", ptr %t183, i32 0, i32 4
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t185, i64 %t186, { i64, ptr } %t190)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t194 = load i64, ptr %l20, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l20, !tbaa !24
  br label %bb36
bb42:
  br label %bb43
bb43:
  %t198 = load i64, ptr %l16, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l16, !tbaa !24
  br label %bb31
bb44:
  br label %bb66
bb45:
  %t202 = load ptr, ptr %l2, !tbaa !29
  store ptr %t202, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t203 = load ptr, ptr %l116, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb46, label %bb47
bb46:
  %t206 = load ptr, ptr %l116, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 5}
  %t209 = icmp eq i64 %t207, 3
  store i1 %t209, ptr %l117, !tbaa !21
  br label %bb47
bb47:
  %t210 = load i1, ptr %l117, !tbaa !21
  br i1 %t210, label %bb48, label %bb49
bb48:
  %t211 = load ptr, ptr %l2, !tbaa !29
  %t213 = getelementptr { i64, [6 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { ptr, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l23, !tbaa !29
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t217 = load ptr, ptr %l23, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  br i1 %t219, label %bb51, label %bb52
bb51:
  br label %ret
bb52:
  br label %bb53
bb53:
  %t221 = load ptr, ptr %l23, !tbaa !29
  %t223 = getelementptr %"compiler/ast:Func", ptr %t221, i32 0, i32 3
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/ast:Sig", ptr %t224, i32 0, i32 0
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  store { i64, ptr } %t227, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  store i64 %t231, ptr %l26, !tbaa !24
  br label %bb54
bb54:
  %t233 = load i64, ptr %l25, !tbaa !24
  %t234 = load i64, ptr %l26, !tbaa !24
  %t237 = icmp slt i64 %t233, %t234
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb55, label %bb56
bb55:
  br label %bb60
bb56:
  br label %bb57
bb57:
  %t241 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t241, ptr %l133, !tbaa !27
  %t242 = load i64, ptr %l25, !tbaa !24
  %t244 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 %t242
  %t247 = load ptr, ptr %t246, !tbaa !39
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i64, ptr %l1, !tbaa !24
  %t253 = getelementptr %"compiler/ast:Param", ptr %t247, i32 0, i32 4
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t249, i64 %t250, { i64, ptr } %t254)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t258 = load i64, ptr %l25, !tbaa !24
  %t260 = add i64 %t258, 1
  store i64 %t260, ptr %l25, !tbaa !24
  br label %bb54
bb60:
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_975dab88aa27b035_9179ffefefe8db69)
  unreachable
bb66:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t15, ptr %l10
  br label %bb6
bb6:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t17, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  store i32 %t28, ptr %l16
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecCallback(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb12
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l14
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb11
bb8:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Func", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t27, i32 %t26)
  store { i64, ptr } %t29, ptr %l17
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t31, ptr %l18
  br label %bb10
bb10:
  %t32 = load i1, ptr %l18, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t35 = load i1, ptr %l9, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_687718fa9f832d83_eed198ed3faef857)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t1, i32 %t2, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l8
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t19 = load i32, ptr %l12, !range !{i32 0, i32 6}
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/load:Loader", ptr %t31, i32 0, i32 10
  store ptr %t33, ptr %l19, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb12
bb11:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb15
bb12:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i32, ptr %l27, !tbaa !23
  %t52 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t50, i32 %t51)
  store i64 %t52, ptr %l28
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l19, !tbaa !29
  %t54 = load i64, ptr %l28, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t55, ptr %l29
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t58 = getelementptr %"compiler/load:Module", ptr %t56, i32 0, i32 30
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l15, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l44 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca %"compiler/typed:Local"
  %l75 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i32
  %l83 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l101 = alloca i32
  %l114 = alloca i1
  %l116 = alloca i1
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca ptr
  %l135 = alloca %"compiler/typed:Local"
  %l136 = alloca i32
  %l143 = alloca ptr
  %l146 = alloca i32
  %l150 = alloca %"compiler/typed:Capture"
  %l154 = alloca i1
  %l155 = alloca i1
  %l160 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t115 = alloca { i64, [4 x i64] }, align 8
  %t189 = alloca { i64, [5 x i64] }, align 8
  %t212 = alloca { i64, [5 x i64] }, align 8
  %t259 = alloca { i64, [1 x i64] }, align 8
  %t326 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 20
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 19
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 19
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 19
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 14
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = icmp eq i64 %t57, %t61
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load i32, ptr %l2, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 15
  %t70 = load i32, ptr %t69, !tbaa !23
  %t73 = icmp eq i32 %t66, %t70
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t75 = load i1, ptr %l44, !tbaa !21
  br i1 %t75, label %bb19, label %bb20
bb19:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 16
  store i1 true, ptr %t78, !tbaa !21
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 18
  store ptr %t81, ptr %l51, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 20
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 19
  %t88 = load i64, ptr %t87, !tbaa !24
  %t91 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t84, i64 %t88)
  store ptr %t91, ptr %l56
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l56, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load ptr, ptr %l51, !tbaa !29
  %t98 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t96, i64 %t95)
  store ptr %t98, ptr %l59
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l59, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t99, i32 0, i32 7
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t101, i64 %t102)
  store %"compiler/typed:Local" %t105, ptr %l63
  br label %bb24
bb24:
  %t106 = getelementptr %"compiler/typed:Local", ptr %l63, i32 0, i32 2
  %t107 = load i32, ptr %t106, !tbaa !23
  store i32 %t107, ptr %l7, !tbaa !23
  %t109 = load %"compiler/source:Span", ptr %l3
  %t110 = load i32, ptr %l7, !tbaa !23
  %t111 = load i64, ptr %l6, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 0
  store i64 0, ptr %t116
  %t118 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t109, 0
  %t120 = insertvalue { %"compiler/source:Span", i32, i32 } %t118, i32 %t110, 1
  %t122 = insertvalue { %"compiler/source:Span", i32, i32 } %t120, i32 %t113, 2
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t122, ptr %t123
  %t124 = load { i64, [4 x i64] }, ptr %t115
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t124, ptr %t126
  store ptr %t126, ptr %l8, !tbaa !29
  %t128 = load i32, ptr %l7, !tbaa !23
  store i32 %t128, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l7, !tbaa !23
  %t134 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t130, i32 %t131)
  store i1 %t134, ptr %l75
  br label %bb25
bb25:
  %t135 = load i1, ptr %l75, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb26, label %bb27
bb26:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l7, !tbaa !23
  %t142 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l80
  br label %bb28
bb27:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb37
bb28:
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = load i32, ptr %l80, !tbaa !23
  %t146 = icmp ne i32 %t144, %t143
  br i1 %t146, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb32
bb30:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t152 = load i32, ptr %l7, !tbaa !23
  %t155 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t155, ptr %l87
  br label %bb31
bb31:
  %t156 = load i1, ptr %l87, !tbaa !21
  store i1 %t156, ptr %l83, !tbaa !21
  br label %bb32
bb32:
  %t157 = load i1, ptr %l83, !tbaa !21
  br i1 %t157, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb36
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l7, !tbaa !23
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %t158, i32 %t159)
  store i1 %t162, ptr %l91
  br label %bb35
bb35:
  %t163 = load i1, ptr %l91, !tbaa !21
  store i1 %t163, ptr %l88, !tbaa !21
  br label %bb36
bb36:
  %t164 = load i1, ptr %l88, !tbaa !21
  store i1 %t164, ptr %l77, !tbaa !21
  br label %bb37
bb37:
  %t165 = load i1, ptr %l77, !tbaa !21
  br i1 %t165, label %bb38, label %bb39
bb38:
  %t166 = load ptr, ptr %l4, !tbaa !29
  %t168 = getelementptr %"compiler/check:frame", ptr %t166, i32 0, i32 20
  %t169 = load i1, ptr %t168, !tbaa !21
  %t171 = xor i1 %t169, true
  store i1 %t171, ptr %l92, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb40
bb40:
  %t173 = load i1, ptr %l92, !tbaa !21
  br i1 %t173, label %bb41, label %bb42
bb41:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %l7, !tbaa !23
  %t181 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t179, i32 %t180, i64 %t181)
  store i32 %t185, ptr %l101
  br label %bb43
bb42:
  %t186 = load %"compiler/source:Span", ptr %l3
  %t187 = load i32, ptr %l7, !tbaa !23
  %t188 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 0
  store i64 2, ptr %t190
  %t192 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t186, 0
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t192, i32 %t187, 1
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t194, ptr %t188, 2
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t196, i32 -1, 3
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t197, ptr %t198
  %t199 = load { i64, [5 x i64] }, ptr %t189
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t199, ptr %t201
  store ptr %t201, ptr %l10, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l7, !tbaa !23
  %t207 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t203, i32 %t204)
  store i1 %t207, ptr %l114
  br label %bb44
bb43:
  %t208 = load i32, ptr %l101, !tbaa !23
  store i32 %t208, ptr %l9, !tbaa !23
  %t209 = load %"compiler/source:Span", ptr %l3
  %t210 = load i32, ptr %l9, !tbaa !23
  %t211 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 0
  store i64 3, ptr %t213
  %t215 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t209, 0
  %t217 = insertvalue { %"compiler/source:Span", i32, ptr } %t215, i32 %t210, 1
  %t219 = insertvalue { %"compiler/source:Span", i32, ptr } %t217, ptr %t211, 2
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t219, ptr %t220
  %t221 = load { i64, [5 x i64] }, ptr %t212
  %t223 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t221, ptr %t223
  store ptr %t223, ptr %l10, !tbaa !29
  br label %bb53
bb44:
  %t225 = load i1, ptr %l114, !tbaa !21
  %t226 = xor i1 %t225, true
  br i1 %t226, label %bb45, label %bb46
bb45:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %l7, !tbaa !23
  %t237 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t233, i32 %t234)
  store i1 %t237, ptr %l121
  br label %bb47
bb46:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb48
bb47:
  %t238 = load i1, ptr %l121, !tbaa !21
  store i1 %t238, ptr %l116, !tbaa !21
  br label %bb48
bb48:
  %t239 = load i1, ptr %l116, !tbaa !21
  br i1 %t239, label %bb49, label %bb50
bb49:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t240, i32 %t241, i64 0)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 18
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t249 = getelementptr %"compiler/check:frame", ptr %t247, i32 0, i32 0
  %t250 = load i64, ptr %t249, !tbaa !24
  %t253 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t246, i64 %t250)
  store ptr %t253, ptr %l128
  br label %bb54
bb54:
  %t254 = load ptr, ptr %l128, !tbaa !29
  store ptr %t254, ptr %l11, !tbaa !29
  %t255 = load ptr, ptr %l11, !tbaa !29
  store ptr %t255, ptr %l129, !tbaa !29
  %t256 = load i32, ptr %l2, !tbaa !23
  %t257 = load %"compiler/source:Span", ptr %l3
  %t258 = load i32, ptr %l9, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [1 x i64] }, ptr %t259, i32 0, i32 0
  store i64 4, ptr %t260
  %t261 = load { i64, [1 x i64] }, ptr %t259
  %t267 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t256, %"compiler/source:Span" %t257, i32 %t258, i32 0, i32 5, { i64, [1 x i64] } %t261)
  store %"compiler/typed:Local" %t267, ptr %l135
  br label %bb55
bb55:
  %t268 = load ptr, ptr %l129, !tbaa !29
  %t269 = load %"compiler/typed:Local", ptr %l135
  %t270 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t268, %"compiler/typed:Local" %t269)
  store i32 %t270, ptr %l136
  br label %bb56
bb56:
  %t271 = load i32, ptr %l136, !tbaa !23
  %t272 = sext i32 %t271 to i64
  store i64 %t272, ptr %l12, !tbaa !24
  %t274 = load ptr, ptr %l4, !tbaa !29
  %t276 = getelementptr %"compiler/check:frame", ptr %t274, i32 0, i32 8
  %t277 = load i32, ptr %l2, !tbaa !23
  %t278 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t276, i32 %t277, i64 %t278)
  br label %bb57
bb57:
  %t282 = load ptr, ptr %l4, !tbaa !29
  %t284 = getelementptr %"compiler/check:frame", ptr %t282, i32 0, i32 30
  store ptr %t284, ptr %l143, !tbaa !29
  %t285 = load i64, ptr %l12, !tbaa !24
  %t287 = trunc i64 %t285 to i32
  store i32 %t287, ptr %l146, !tbaa !23
  %t289 = load ptr, ptr %l10, !tbaa !29
  %t291 = icmp eq ptr %t289, null
  br i1 %t291, label %bb58, label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb59:
  br label %bb60
bb60:
  %t293 = load ptr, ptr %l10, !tbaa !29
  %t294 = load i32, ptr %l146, !tbaa !23
  %t296 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t294, ptr %t293)
  store %"compiler/typed:Capture" %t296, ptr %l150
  br label %bb61
bb61:
  %t297 = load %"compiler/typed:Capture", ptr %l150
  %t298 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t297, ptr %t298
  %t299 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v0, ptr %t299, ptr %t298)
  br label %bb62
bb62:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l9, !tbaa !23
  %t305 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t301, i32 %t302)
  store i1 %t305, ptr %l154
  br label %bb63
bb63:
  %t306 = load i1, ptr %l154, !tbaa !21
  br i1 %t306, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb67
bb65:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = getelementptr %"compiler/generic:Program", ptr %t310, i32 0, i32 2
  %t313 = load i32, ptr %l9, !tbaa !23
  %t316 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t312, i32 %t313)
  store i1 %t316, ptr %l160
  br label %bb66
bb66:
  %t317 = load i1, ptr %l160, !tbaa !21
  store i1 %t317, ptr %l155, !tbaa !21
  br label %bb67
bb67:
  %t318 = load i1, ptr %l155, !tbaa !21
  br i1 %t318, label %bb68, label %bb69
bb68:
  %t319 = load ptr, ptr %l11, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Body", ptr %t319, i32 0, i32 6
  %t322 = load i64, ptr %l12, !tbaa !24
  %t324 = trunc i64 %t322 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [1 x i64] }, ptr %t326, i32 0, i32 0
  store i64 4, ptr %t327
  %t329 = insertvalue { i32 } undef, i32 %t324, 0
  %t330 = getelementptr { i64, [1 x i64] }, ptr %t326, i32 0, i32 1
  store { i32 } %t329, ptr %t330
  %t331 = load { i64, [1 x i64] }, ptr %t326
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t321, { i64, [1 x i64] } %t331)
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t334 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t334, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapturedValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca %"compiler/typed:Local"
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca ptr
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t4)
  store ptr %t5, ptr %l10
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l10, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l14, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 8}
  %t19 = icmp eq i64 %t17, 0
  store i1 %t19, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l15, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb39
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t27)
  store ptr %t29, ptr %l21
  br label %bb11
bb11:
  %t30 = load i32, ptr %l3, !tbaa !23
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t33 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t31, i32 %t30)
  store %"compiler/typed:Local" %t33, ptr %l23
  br label %bb12
bb12:
  %t34 = getelementptr %"compiler/typed:Local", ptr %l23, i32 0, i32 4
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 7}
  %t37 = trunc i64 5 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t43)
  store ptr %t45, ptr %l29
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t48 = getelementptr %"compiler/check:frame", ptr %t46, i32 0, i32 30
  store ptr %t48, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb17
bb17:
  %t50 = load i64, ptr %l5, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eLen_H3aff79531665083e8df6fb2351948096(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l34
  br label %bb18
bb18:
  %t54 = load i64, ptr %l32, !tbaa !24
  %t55 = load i64, ptr %l34, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb19, label %bb20
bb19:
  br label %bb38
bb20:
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eAt__H223e9cc5a62bb13aec2c4037d58f7975(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t64, ptr %l39
  br label %bb22
bb22:
  %t65 = load ptr, ptr %l39, !tbaa !29
  store ptr %t65, ptr %l6, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Capture", ptr %t66, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load i32, ptr %l3, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  br i1 %t73, label %bb23, label %bb24
bb23:
  br label %bb37
bb24:
  br label %bb25
bb25:
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Capture", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  store ptr %t78, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 18}
  %t87 = icmp eq i64 %t85, 3
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb27
bb27:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_3fa0bc2758d24028_39c102aa9b869b2c)
  unreachable
bb36:
  %t89 = load i1, ptr %l46, !tbaa !21
  store i1 %t89, ptr %rv
  br label %ret
bb37:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l5, !tbaa !24
  br label %bb17
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_386bb7dc57d3fef9_468931e243621ddd)
  unreachable
bb44:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i64
  %l26 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca { i64, [3 x i64] }
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr i8, ptr %t8, i64 0
  %t10 = load i8, ptr %t9, !tbaa !32
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t10)
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 20
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l13
  br label %bb5
bb5:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = icmp eq i64 %t19, 0
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %a1)
  store i32 %t38, ptr %l23
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i32, ptr %l23, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t41, ptr %l24
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t42)
  store ptr %t44, ptr %l26
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr %l24, !tbaa !24
  %t51 = icmp eq i64 %t49, %t48
  store i1 %t51, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l15, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/load:Loader", ptr %t60, i32 0, i32 4
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t68 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t64, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t68, ptr %l36
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l39
  br label %bb17
bb17:
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t82 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %s0, ptr %v0, { i64, ptr } %t80)
  store %"compiler/diagmsg:Msg" %t82, ptr %l41
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l33, !tbaa !29
  %t84 = load { i64, [3 x i64] }, ptr %l36
  %t85 = load %"compiler/diagmsg:Msg", ptr %l41
  %t86 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v0, ptr %t83, { i64, [3 x i64] } %t84, %"compiler/diagmsg:Msg" %t85)
  store i64 %t86, ptr %l42
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckThunk(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/generic:AnySlot"
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, [3 x i64] }
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca i64
  %l76 = alloca i32
  %l81 = alloca i32
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i64
  %l87 = alloca %"compiler/generic:Context"
  %l89 = alloca %"compiler/generic:Context"
  %l92 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca i32
  %l102 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca { i64, ptr }
  %l114 = alloca i64
  %l117 = alloca i64
  %l137 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l173 = alloca ptr
  %l176 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i64
  %l204 = alloca ptr
  %l208 = alloca ptr
  %l214 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l222 = alloca i64
  %l225 = alloca { i64, ptr }
  %l228 = alloca i1
  %l231 = alloca i1
  %l233 = alloca ptr
  %l239 = alloca i64
  %l240 = alloca i1
  %l242 = alloca ptr
  %l250 = alloca i64
  %l258 = alloca ptr
  %l259 = alloca ptr
  %l263 = alloca { i64, ptr }
  %l264 = alloca %"compiler/typed:Block"
  %l269 = alloca ptr
  %l270 = alloca %"compiler/source:Span"
  %l271 = alloca %"compiler/source:Span"
  %l272 = alloca i64
  %l274 = alloca ptr
  %l277 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l282 = alloca ptr
  %l286 = alloca { i64, [3 x i64] }
  %l288 = alloca ptr
  %l294 = alloca i64
  %l295 = alloca { i64, [3 x i64] }
  %l296 = alloca i32
  %l304 = alloca ptr
  %l305 = alloca { i64, [3 x i64] }
  %l306 = alloca i64
  %l308 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l318 = alloca ptr
  %l319 = alloca %"compiler/source:Span"
  %l320 = alloca %"compiler/source:Span"
  %l321 = alloca i64
  %l323 = alloca ptr
  %l326 = alloca { i64, ptr }
  %l327 = alloca { i64, ptr }
  %l331 = alloca ptr
  %l341 = alloca i1
  %l342 = alloca ptr
  %l343 = alloca %"compiler/source:Span"
  %l345 = alloca i32
  %l349 = alloca ptr
  %l350 = alloca ptr
  %l354 = alloca ptr
  %l355 = alloca { i64, ptr }
  %l356 = alloca ptr
  %l359 = alloca i1
  %l360 = alloca ptr
  %l361 = alloca %"compiler/source:Span"
  %l363 = alloca i32
  %l366 = alloca ptr
  %l369 = alloca i1
  %l370 = alloca ptr
  %l371 = alloca %"compiler/source:Span"
  %l376 = alloca i32
  %l377 = alloca i32
  %l381 = alloca ptr
  %l382 = alloca ptr
  %l388 = alloca ptr
  %l390 = alloca ptr
  %l398 = alloca ptr
  %l403 = alloca i32
  %l404 = alloca { i64, ptr }
  %l407 = alloca %"compiler/source:Span"
  %l410 = alloca i32
  %l412 = alloca ptr
  %l416 = alloca %"compiler/typed:Try"
  %l422 = alloca i64
  %l427 = alloca i32
  %l453 = alloca ptr
  %l454 = alloca %"compiler/source:Span"
  %l459 = alloca ptr
  %l464 = alloca ptr
  %l465 = alloca ptr
  %l469 = alloca { i64, ptr }
  %l470 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %t104 = alloca %"compiler/generic:Context", align 8
  %t356 = alloca { i64, [4 x i64] }, align 8
  %t381 = alloca { i64, [4 x i64] }, align 8
  %t569 = alloca { i64, [3 x i64] }, align 8
  %t670 = alloca { i64, [3 x i64] }, align 8
  %t819 = alloca { i64, [3 x i64] }, align 8
  %t963 = alloca { i64, [5 x i64] }, align 8
  %t1004 = alloca { i64, [3 x i64] }, align 8
  %t1027 = alloca { i64, [3 x i64] }, align 8
  %t1056 = alloca { i64, [3 x i64] }, align 8
  %t1070 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 61
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H53de96b937c1888202b72d022fb4696d(ptr %v0, ptr %v0, ptr %t6, i64 %a2)
  store ptr %t10, ptr %l43
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l43, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/generic:AnyTable", ptr %t16, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t15, i32 %t19)
  store { i64, ptr } %t22, ptr %l48
  br label %bb2
bb2:
  %t23 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t30 = srem i64 %a3, %t24
  store i64 %t30, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/generic:AnyTable", ptr %t36, i32 0, i32 1
  %t39 = load i32, ptr %t38, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t35, i32 %t39)
  store { i64, ptr } %t42, ptr %l57
  br label %bb3
bb3:
  %t43 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t43, ptr %l58, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/generic:AnySlot", ptr %t47, i64 %t44
  %t49 = load %"compiler/generic:AnySlot", ptr %t48
  store %"compiler/generic:AnySlot" %t49, ptr %l7
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l1, !tbaa !24
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur0(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l63
  br label %bb4
bb4:
  %t56 = load ptr, ptr %l63, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %t58, !tbaa !23
  store i32 %t59, ptr %l8, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethunkModule(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l68
  br label %bb5
bb5:
  %t66 = load i64, ptr %l68, !tbaa !24
  store i64 %t66, ptr %l9, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l69, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  store i64 %t68, ptr %l70, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  store i64 %t69, ptr %l71, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l8, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l76
  br label %bb6
bb6:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l8, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l81
  br label %bb7
bb7:
  %t90 = load ptr, ptr %l69, !tbaa !29
  %t91 = load i64, ptr %l70, !tbaa !24
  %t92 = load i64, ptr %l71, !tbaa !24
  %t93 = load i32, ptr %l76, !tbaa !23
  %t94 = load i32, ptr %l81, !tbaa !23
  %t95 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t90, i64 %t91, i64 %t92, i32 %t93, i32 %t94)
  store ptr %t95, ptr %l82
  br label %bb8
bb8:
  %t96 = load ptr, ptr %l82, !tbaa !29
  store ptr %t96, ptr %l10, !tbaa !29
  %t97 = load ptr, ptr %l10, !tbaa !29
  store ptr %t97, ptr %l83, !tbaa !29
  %t98 = ptrtoint ptr %v0 to i64
  store i64 %t98, ptr %l84, !tbaa !24
  %t99 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t99, label %bb9, label %bb10
bb9:
  %t101 = call ptr @__olang_region_make(ptr %v0)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l84, !tbaa !24
  br label %bb10
bb10:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t105 = load i64, ptr %l84
  %t106 = inttoptr i64 %t105 to ptr
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t104, ptr %t106, i64 %t103, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l87, ptr %t104, i64 160, i1 false)
  br label %bb11
bb11:
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t108, label %bb12, label %bb13
bb12:
  %t110 = load i64, ptr %l84
  %t111 = inttoptr i64 %t110 to ptr
  %t112 = getelementptr %"compiler/generic:Context", ptr %l87, i32 0, i32 3
  %t113 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 2
  %t114 = load { i64, ptr }, ptr %t113
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = call ptr @__olang_region_or(ptr %t115, ptr null)
  %t117 = call ptr @__olang_region_home(ptr %t116)
  %t118 = icmp ne ptr %t117, null
  %t119 = select i1 %t118, ptr %t117, ptr null
  %t120 = getelementptr %"compiler/generic:Context", ptr %l87, i32 0, i32 3
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t120, i32 0, i32 1
  %t122 = load { i64, ptr }, ptr %t121
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = call ptr @__olang_region_home(ptr %t124)
  %t126 = icmp ne ptr %t125, null
  %t127 = select i1 %t126, ptr %t125, ptr %t119
  %t128 = getelementptr %"compiler/generic:Context", ptr %l87, i32 0, i32 3
  %t129 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t128, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = call ptr @__olang_region_or(ptr %t131, ptr null)
  %t133 = call ptr @__olang_region_home(ptr %t132)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr %t127
  %t136 = getelementptr %"compiler/generic:Context", ptr %l87, i32 0, i32 2
  %t137 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t136, i32 0, i32 2
  %t138 = load { i64, ptr }, ptr %t137
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = call ptr @__olang_region_or(ptr %t139, ptr null)
  %t141 = call ptr @__olang_region_home(ptr %t140)
  %t142 = icmp ne ptr %t141, null
  %t143 = select i1 %t142, ptr %t141, ptr %t135
  %t144 = getelementptr %"compiler/generic:Context", ptr %l87, i32 0, i32 2
  %t145 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t144, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = call ptr @__olang_region_or(ptr %t147, ptr null)
  %t149 = call ptr @__olang_region_home(ptr %t148)
  %t150 = icmp ne ptr %t149, null
  %t151 = select i1 %t150, ptr %t149, ptr %t143
  %t152 = getelementptr %"compiler/generic:Context", ptr %l87, i32 0, i32 2
  %t153 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t152, i32 0, i32 0
  %t154 = load { i64, ptr }, ptr %t153
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = call ptr @__olang_region_or(ptr %t155, ptr null)
  %t157 = call ptr @__olang_region_home(ptr %t156)
  %t158 = icmp ne ptr %t157, null
  %t159 = select i1 %t158, ptr %t157, ptr %t151
  %t160 = icmp eq ptr %t159, %t111
  call void @__olang_region_settle(ptr %t111, i1 %t160)
  br label %bb13
bb13:
  %t161 = load ptr, ptr %l83, !tbaa !29
  %t162 = getelementptr %"compiler/check:frame", ptr %t161, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t162, i64 160, i1 false)
  %t163 = load ptr, ptr %l83, !tbaa !29
  %t164 = getelementptr %"compiler/check:frame", ptr %t163, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t164, ptr %l87, i64 160, i1 false)
  %t165 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t165, label %bb14, label %bb15
bb14:
  %t167 = getelementptr %"compiler/generic:Context", ptr %l89, i32 0, i32 3
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 2
  %t169 = load { i64, ptr }, ptr %t168
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = call ptr @__olang_region_home(ptr %t171)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, ptr %t172, ptr null
  %t175 = getelementptr %"compiler/generic:Context", ptr %l89, i32 0, i32 3
  %t176 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t175, i32 0, i32 1
  %t177 = load { i64, ptr }, ptr %t176
  %t178 = extractvalue { i64, ptr } %t177, 1
  %t179 = call ptr @__olang_region_or(ptr %t178, ptr null)
  %t180 = call ptr @__olang_region_home(ptr %t179)
  %t181 = icmp ne ptr %t180, null
  %t182 = select i1 %t181, ptr %t180, ptr %t174
  %t183 = getelementptr %"compiler/generic:Context", ptr %l89, i32 0, i32 3
  %t184 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t183, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = call ptr @__olang_region_or(ptr %t186, ptr null)
  %t188 = call ptr @__olang_region_home(ptr %t187)
  %t189 = icmp ne ptr %t188, null
  %t190 = select i1 %t189, ptr %t188, ptr %t182
  %t191 = getelementptr %"compiler/generic:Context", ptr %l89, i32 0, i32 2
  %t192 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t191, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = call ptr @__olang_region_or(ptr %t194, ptr null)
  %t196 = call ptr @__olang_region_home(ptr %t195)
  %t197 = icmp ne ptr %t196, null
  %t198 = select i1 %t197, ptr %t196, ptr %t190
  %t199 = getelementptr %"compiler/generic:Context", ptr %l89, i32 0, i32 2
  %t200 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t199, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = call ptr @__olang_region_or(ptr %t202, ptr null)
  %t204 = call ptr @__olang_region_home(ptr %t203)
  %t205 = icmp ne ptr %t204, null
  %t206 = select i1 %t205, ptr %t204, ptr %t198
  %t207 = getelementptr %"compiler/generic:Context", ptr %l89, i32 0, i32 2
  %t208 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t207, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = call ptr @__olang_region_or(ptr %t210, ptr null)
  %t212 = call ptr @__olang_region_home(ptr %t211)
  %t213 = icmp ne ptr %t212, null
  %t214 = select i1 %t213, ptr %t212, ptr %t206
  call void @__olang_region_drop(ptr %t214)
  store %"compiler/generic:Context" zeroinitializer, ptr %l89
  br label %bb15
bb15:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t215)
  store ptr %t217, ptr %l92
  br label %bb16
bb16:
  %t218 = load ptr, ptr %l92, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Body", ptr %t218, i32 0, i32 4
  %t221 = load %"compiler/source:Span", ptr %t220
  store %"compiler/source:Span" %t221, ptr %l11
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t223)
  store ptr %t225, ptr %l96
  br label %bb17
bb17:
  %t226 = load %"compiler/source:Span", ptr %l11
  %t227 = load ptr, ptr %l96, !tbaa !29
  %t230 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t227, i32 -1, i32 0, %"compiler/source:Span" %t226)
  store i32 %t230, ptr %l99
  br label %bb18
bb18:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/generic:Program", ptr %t234, i32 0, i32 2
  store ptr %t236, ptr %l102, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 2
  %t243 = load i32, ptr %l8, !tbaa !23
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t242, i32 %t243)
  store i32 %t246, ptr %l107
  br label %bb19
bb19:
  %t247 = load ptr, ptr %l102, !tbaa !29
  %t248 = load i32, ptr %l107, !tbaa !23
  %t249 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t247, i32 %t248)
  store { i64, ptr } %t249, ptr %l108
  br label %bb20
bb20:
  %t250 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t250, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t255 = load i64, ptr %l14, !tbaa !24
  %t256 = load i64, ptr %l13, !tbaa !24
  %t259 = icmp sgt i64 %t255, %t256
  br i1 %t259, label %bb21, label %bb22
bb21:
  %t261 = load i64, ptr %l15, !tbaa !24
  %t263 = icmp sgt i64 %t261, 0
  br i1 %t263, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb26
bb23:
  %t265 = load i64, ptr %l14, !tbaa !24
  %t266 = load i64, ptr %l13, !tbaa !24
  %t269 = sub i64 %t265, %t266
  %t270 = load i64, ptr %l15, !tbaa !24
  %t273 = add i64 %t269, %t270
  %t275 = sub i64 %t273, 1
  %t276 = load i64, ptr %l15, !tbaa !24
  %t279 = sdiv i64 %t275, %t276
  store i64 %t279, ptr %l117, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb25
bb25:
  %t281 = load i64, ptr %l117, !tbaa !24
  store i64 %t281, ptr %l114, !tbaa !24
  br label %bb26
bb26:
  %t282 = load i64, ptr %l114, !tbaa !24
  store i64 %t282, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  %t283 = load i64, ptr %l17, !tbaa !24
  %t284 = load i64, ptr %l16, !tbaa !24
  %t287 = icmp slt i64 %t283, %t284
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t291 = load i64, ptr %l13, !tbaa !24
  %t292 = load i64, ptr %l17, !tbaa !24
  %t293 = load i64, ptr %l15, !tbaa !24
  %t296 = mul i64 %t292, %t293
  %t299 = add i64 %t291, %t296
  store i64 %t299, ptr %l18, !tbaa !24
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l11
  %t303 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t303, ptr %l137, !tbaa !27
  %t304 = load i64, ptr %l18, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr i32, ptr %t307, i64 %t304
  %t309 = load i32, ptr %t308, !tbaa !33
  %t310 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %s2, ptr %t301, i32 0, %"compiler/source:Span" %t302, i32 %t309, i64 %t310, ptr null)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t315 = load i64, ptr %l17, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l17, !tbaa !24
  br label %bb27
bb33:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t319)
  store ptr %t321, ptr %l144
  br label %bb34
bb34:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/check:Checker", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t326 = load i32, ptr %l8, !tbaa !23
  %t329 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t325, i32 %t326)
  store { i64, ptr } %t329, ptr %l148
  br label %bb35
bb35:
  %t330 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 0
  %t332 = extractvalue { i64, ptr } %t330, 1
  %t333 = mul i64 %t331, 8
  %t334 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t334, ptr %t332, i64 %t333, i1 false)
  %t335 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  %t337 = load ptr, ptr %l144, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t337, { i64, ptr } %t336)
  br label %bb36
bb36:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l11
  %t343 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t339, %"compiler/source:Span" %t340, i64 0)
  store ptr %t343, ptr %l152
  br label %bb37
bb37:
  %t344 = load ptr, ptr %l152, !tbaa !29
  %t345 = load ptr, ptr %l4, !tbaa !29
  %t347 = getelementptr %"compiler/generic:AnyTable", ptr %t345, i32 0, i32 0
  %t348 = load i32, ptr %t347, !tbaa !23
  store i32 %t348, ptr %l20, !tbaa !23
  %t350 = load %"compiler/source:Span", ptr %l11
  %t351 = load ptr, ptr %l4, !tbaa !29
  %t353 = getelementptr %"compiler/generic:AnyTable", ptr %t351, i32 0, i32 2
  %t354 = load i32, ptr %t353, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [4 x i64] }, ptr %t356, i32 0, i32 0
  store i64 2, ptr %t357
  %t359 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t350, 0
  %t361 = insertvalue { %"compiler/source:Span", i32, ptr } %t359, i32 %t354, 1
  %t363 = insertvalue { %"compiler/source:Span", i32, ptr } %t361, ptr %t344, 2
  %t364 = getelementptr { i64, [4 x i64] }, ptr %t356, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t363, ptr %t364
  %t365 = load { i64, [4 x i64] }, ptr %t356
  %t367 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t365, ptr %t367
  store ptr %t367, ptr %l21, !tbaa !29
  %t369 = load ptr, ptr %l4, !tbaa !29
  %t371 = getelementptr %"compiler/generic:AnyTable", ptr %t369, i32 0, i32 2
  %t372 = load i32, ptr %t371, !tbaa !23
  %t373 = load i32, ptr %l20, !tbaa !23
  %t376 = icmp ne i32 %t372, %t373
  br i1 %t376, label %bb38, label %bb39
bb38:
  %t378 = load %"compiler/source:Span", ptr %l11
  %t379 = load i32, ptr %l20, !tbaa !23
  %t380 = load ptr, ptr %l21, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t381
  %t382 = getelementptr { i64, [4 x i64] }, ptr %t381, i32 0, i32 0
  store i64 3, ptr %t382
  %t384 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t378, 0
  %t386 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t384, i32 %t379, 1
  %t388 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t386, ptr %t380, 2
  %t389 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t388, i64 0, 3
  %t390 = getelementptr { i64, [4 x i64] }, ptr %t381, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t389, ptr %t390
  %t391 = load { i64, [4 x i64] }, ptr %t381
  %t393 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t391, ptr %t393
  store ptr %t393, ptr %l21, !tbaa !29
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l11
  %t397 = load ptr, ptr %l21, !tbaa !29
  %t401 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t395, %"compiler/source:Span" %t396, ptr %t397)
  store ptr %t401, ptr %l173
  br label %bb41
bb41:
  %t402 = load ptr, ptr %l173, !tbaa !29
  store ptr %t402, ptr %l22, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 44
  %t407 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t405)
  store i64 %t407, ptr %l176
  br label %bb42
bb42:
  %t408 = load i64, ptr %l176, !tbaa !24
  store i64 %t408, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t409 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t409, 0
  store i64 %t411, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t413 = load i64, ptr %l25, !tbaa !24
  %t414 = load i64, ptr %l24, !tbaa !24
  %t417 = icmp sgt i64 %t413, %t414
  br i1 %t417, label %bb43, label %bb44
bb43:
  %t419 = load i64, ptr %l26, !tbaa !24
  %t421 = icmp sgt i64 %t419, 0
  br i1 %t421, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l182, !tbaa !24
  br label %bb48
bb45:
  %t423 = load i64, ptr %l25, !tbaa !24
  %t424 = load i64, ptr %l24, !tbaa !24
  %t427 = sub i64 %t423, %t424
  %t428 = load i64, ptr %l26, !tbaa !24
  %t431 = add i64 %t427, %t428
  %t433 = sub i64 %t431, 1
  %t434 = load i64, ptr %l26, !tbaa !24
  %t437 = sdiv i64 %t433, %t434
  store i64 %t437, ptr %l185, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb47
bb47:
  %t439 = load i64, ptr %l185, !tbaa !24
  store i64 %t439, ptr %l182, !tbaa !24
  br label %bb48
bb48:
  %t440 = load i64, ptr %l182, !tbaa !24
  store i64 %t440, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb49
bb49:
  %t441 = load i64, ptr %l28, !tbaa !24
  %t442 = load i64, ptr %l27, !tbaa !24
  %t445 = icmp slt i64 %t441, %t442
  %t447 = xor i1 %t445, true
  br i1 %t447, label %bb50, label %bb51
bb50:
  br label %bb56
bb51:
  br label %bb52
bb52:
  %t449 = load i64, ptr %l24, !tbaa !24
  %t450 = load i64, ptr %l28, !tbaa !24
  %t451 = load i64, ptr %l26, !tbaa !24
  %t454 = mul i64 %t450, %t451
  %t457 = add i64 %t449, %t454
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/check:Checker", ptr %t459, i32 0, i32 44
  store ptr %t461, ptr %l204, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load %"compiler/source:Span", ptr %l11
  %t468 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t462, %"compiler/source:Span" %t463, i64 %t457)
  store ptr %t468, ptr %l208
  br label %bb53
bb53:
  %t469 = load ptr, ptr %l204, !tbaa !29
  %t470 = load ptr, ptr %l208, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t469, ptr %t470)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t471 = load i64, ptr %l28, !tbaa !24
  %t473 = add i64 %t471, 1
  store i64 %t473, ptr %l28, !tbaa !24
  br label %bb49
bb56:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 44
  %t478 = load i64, ptr %l23, !tbaa !24
  %t481 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t477, i64 %t478)
  store { i64, ptr } %t481, ptr %l214
  br label %bb57
bb57:
  %t482 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t482, ptr %l30, !tbaa !27
  %t483 = load ptr, ptr %l10, !tbaa !29
  store ptr %t483, ptr %l215, !tbaa !29
  %t484 = load ptr, ptr %l215, !tbaa !29
  %t485 = getelementptr %"compiler/check:frame", ptr %t484, i32 0, i32 15
  %t486 = load i64, ptr %t485, !tbaa !24
  %t488 = add i64 %t486, 1
  %t490 = load ptr, ptr %l215, !tbaa !29
  %t491 = getelementptr %"compiler/check:frame", ptr %t490, i32 0, i32 15
  store i64 %t488, ptr %t491, !tbaa !24
  store ptr null, ptr %l31, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/check:Checker", ptr %t492, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !29
  %t496 = load i32, ptr %l20, !tbaa !23
  %t497 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 0
  %t498 = load i32, ptr %t497, !tbaa !23
  %t502 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t495, i32 %t496, i32 %t498)
  store i64 %t502, ptr %l222
  br label %bb58
bb58:
  %t503 = load i64, ptr %l222, !tbaa !24
  store i64 %t503, ptr %l32, !tbaa !24
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 0
  %t506 = load i32, ptr %t505, !tbaa !23
  %t509 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t504, i32 %t506)
  store { i64, ptr } %t509, ptr %l225
  br label %bb59
bb59:
  %t510 = load { i64, ptr }, ptr %l225, !tbaa !27
  store { i64, ptr } %t510, ptr %l33, !tbaa !27
  %t511 = load i64, ptr %l32, !tbaa !24
  %t513 = icmp slt i64 %t511, 0
  br i1 %t513, label %bb60, label %bb61
bb60:
  %t515 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 3
  %t516 = load i64, ptr %t515, !tbaa !24
  %t518 = icmp sge i64 %t516, 0
  store i1 %t518, ptr %l228, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb62
bb62:
  %t520 = load i1, ptr %l228, !tbaa !21
  br i1 %t520, label %bb63, label %bb64
bb63:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/check:Checker", ptr %t521, i32 0, i32 173
  store ptr %t523, ptr %l233, !tbaa !29
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t526 = getelementptr %"compiler/check:Checker", ptr %t524, i32 0, i32 1
  %t527 = load ptr, ptr %t526, !tbaa !29
  %t528 = load ptr, ptr %l4, !tbaa !29
  %t530 = getelementptr %"compiler/generic:AnyTable", ptr %t528, i32 0, i32 1
  %t531 = load i32, ptr %t530, !tbaa !23
  %t532 = load i64, ptr %l6, !tbaa !24
  %t536 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %t527, i32 %t531, i64 %t532)
  store i64 %t536, ptr %l239
  br label %bb65
bb64:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb67
bb65:
  %t537 = load ptr, ptr %l233, !tbaa !29
  %t538 = load i64, ptr %l239, !tbaa !24
  %t539 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %t537, i64 %t538)
  store i1 %t539, ptr %l240
  br label %bb66
bb66:
  %t540 = load i1, ptr %l240, !tbaa !21
  %t541 = xor i1 %t540, true
  store i1 %t541, ptr %l231, !tbaa !21
  br label %bb67
bb67:
  %t543 = load i1, ptr %l231, !tbaa !21
  br i1 %t543, label %bb68, label %bb69
bb68:
  %t544 = load ptr, ptr %l10, !tbaa !29
  store ptr %t544, ptr %l242, !tbaa !29
  %t545 = load ptr, ptr %l242, !tbaa !29
  %t546 = getelementptr %"compiler/check:frame", ptr %t545, i32 0, i32 15
  %t547 = load i64, ptr %t546, !tbaa !24
  %t549 = sub i64 %t547, 1
  %t551 = load ptr, ptr %l242, !tbaa !29
  %t552 = getelementptr %"compiler/check:frame", ptr %t551, i32 0, i32 15
  store i64 %t549, ptr %t552, !tbaa !24
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/check:Checker", ptr %t553, i32 0, i32 174
  %t556 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t555, i64 %t556)
  br label %bb70
bb69:
  br label %bb77
bb70:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 45
  %t563 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t561)
  store i64 %t563, ptr %l250
  br label %bb71
bb71:
  %t564 = load i64, ptr %l250, !tbaa !24
  store i64 %t564, ptr %l34, !tbaa !24
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t567 = getelementptr %"compiler/check:Checker", ptr %t565, i32 0, i32 45
  %t568 = load %"compiler/source:Span", ptr %l11
  store { i64, [3 x i64] } zeroinitializer, ptr %t569
  %t570 = getelementptr { i64, [3 x i64] }, ptr %t569, i32 0, i32 0
  store i64 9, ptr %t570
  %t572 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t568, 0
  %t574 = insertvalue { %"compiler/source:Span", i32, ptr } %t572, i32 0, 1
  %t575 = insertvalue { %"compiler/source:Span", i32, ptr } %t574, ptr null, 2
  %t576 = getelementptr { i64, [3 x i64] }, ptr %t569, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t575, ptr %t576
  %t577 = load { i64, [3 x i64] }, ptr %t569
  %t579 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t577, ptr %t579
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t567, ptr %t579)
  br label %bb72
bb72:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t582)
  store ptr %t584, ptr %l258
  br label %bb73
bb73:
  %t585 = load ptr, ptr %l258, !tbaa !29
  store ptr %t585, ptr %l259, !tbaa !29
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t588 = getelementptr %"compiler/check:Checker", ptr %t586, i32 0, i32 45
  %t589 = load i64, ptr %l34, !tbaa !24
  %t592 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t588, i64 %t589)
  store { i64, ptr } %t592, ptr %l263
  br label %bb74
bb74:
  %t593 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t594 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t593)
  store %"compiler/typed:Block" %t594, ptr %l264
  br label %bb75
bb75:
  %t595 = load %"compiler/typed:Block", ptr %l264
  %t596 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t595, ptr %t596
  %t598 = load ptr, ptr %l259, !tbaa !29
  %t599 = getelementptr %"compiler/typed:Body", ptr %t598, i32 0, i32 11
  store ptr %t596, ptr %t599, !tbaa !29
  %t600 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t600)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb77:
  %t602 = load i64, ptr %l32, !tbaa !24
  %t604 = icmp sge i64 %t602, 0
  br i1 %t604, label %bb78, label %bb79
bb78:
  %t606 = load ptr, ptr %l0, !tbaa !29
  store ptr %t606, ptr %l269, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t607, ptr %l270
  %t608 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t608, ptr %l271
  %t609 = load i64, ptr %l32, !tbaa !24
  store i64 %t609, ptr %l272, !tbaa !24
  %t610 = load ptr, ptr %l22, !tbaa !29
  store ptr %t610, ptr %l274, !tbaa !29
  %t612 = icmp sge i64 0, 0
  br i1 %t612, label %bb80, label %bb81
bb79:
  %t614 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 3
  %t615 = load i64, ptr %t614, !tbaa !24
  %t617 = icmp sge i64 %t615, 0
  br i1 %t617, label %bb89, label %bb90
bb80:
  %t619 = icmp sle i64 0, 1152921504606846975
  br i1 %t619, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_3c4a57751e7c3c44_a964a095ba0d8e8)
  unreachable
bb82:
  %t621 = mul i64 0, 8
  %t622 = insertvalue { i64, ptr } undef, i64 0, 0
  %t623 = insertvalue { i64, ptr } %t622, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t623, ptr %l277, !tbaa !27
  %t624 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t624, ptr %l278, !tbaa !27
  %t625 = icmp sge i64 0, 0
  br i1 %t625, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_3c4a57751e7c3c44_a964a095ba0d8e8)
  unreachable
bb84:
  %t627 = icmp sle i64 0, 2305843009213693951
  br i1 %t627, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5)
  unreachable
bb86:
  %t629 = mul i64 0, 4
  %t630 = insertvalue { i64, ptr } undef, i64 0, 0
  %t631 = insertvalue { i64, ptr } %t630, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t632 = load ptr, ptr %l269, !tbaa !29
  %t633 = load %"compiler/source:Span", ptr %l270
  %t634 = load %"compiler/source:Span", ptr %l271
  %t635 = load i64, ptr %l272, !tbaa !24
  %t636 = load ptr, ptr %l274, !tbaa !29
  %t637 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t638 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t640 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t632, %"compiler/source:Span" %t633, %"compiler/source:Span" %t634, i64 %t635, ptr %t636, { i64, ptr } %t637, { i64, ptr } %t638, { i64, ptr } %t631)
  store ptr %t640, ptr %l282
  br label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5)
  unreachable
bb88:
  %t641 = load ptr, ptr %l282, !tbaa !29
  store ptr %t641, ptr %l31, !tbaa !29
  br label %bb141
bb89:
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t645 = getelementptr %"compiler/check:Checker", ptr %t643, i32 0, i32 173
  store ptr %t645, ptr %l288, !tbaa !29
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/check:Checker", ptr %t646, i32 0, i32 1
  %t649 = load ptr, ptr %t648, !tbaa !29
  %t650 = load ptr, ptr %l4, !tbaa !29
  %t652 = getelementptr %"compiler/generic:AnyTable", ptr %t650, i32 0, i32 1
  %t653 = load i32, ptr %t652, !tbaa !23
  %t654 = load i64, ptr %l6, !tbaa !24
  %t658 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %t649, i32 %t653, i64 %t654)
  store i64 %t658, ptr %l294
  br label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s15
  %t659 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t661 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t659, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t661, ptr %l341
  br label %bb117
bb91:
  %t662 = load ptr, ptr %l288, !tbaa !29
  %t663 = load i64, ptr %l294, !tbaa !24
  %t664 = call { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %t662, i64 %t663)
  %t665 = extractvalue { i32, { i64, [3 x i64] } } %t664, 1
  %t666 = extractvalue { i32, { i64, [3 x i64] } } %t664, 0
  store i32 %t666, ptr %l296
  %t667 = icmp ne i32 %t666, 0
  br i1 %t667, label %bb93, label %ok.668, !prof !99
ok.668:
  store { i64, [3 x i64] } %t665, ptr %l295
  br label %bb92
bb92:
  %t669 = load { i64, [3 x i64] }, ptr %l295
  store { i64, [3 x i64] } %t669, ptr %l286
  br label %bb95
bb93:
  br label %bb94
bb94:
  store { i64, [3 x i64] } zeroinitializer, ptr %t670
  %t671 = getelementptr { i64, [3 x i64] }, ptr %t670, i32 0, i32 0
  store i64 0, ptr %t671
  %t672 = load { i64, [3 x i64] }, ptr %t670
  store { i64, [3 x i64] } %t672, ptr %l286
  br label %bb95
bb95:
  %t674 = load { i64, [3 x i64] }, ptr %l286
  store { i64, [3 x i64] } %t674, ptr %l35
  %t675 = load { i64, [3 x i64] }, ptr %l35
  %t677 = extractvalue { i64, [3 x i64] } %t675, 0
  %t678 = icmp eq i64 %t677, 0
  %t680 = xor i1 %t678, true
  br i1 %t680, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s12
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t684 = getelementptr %"compiler/check:Checker", ptr %t682, i32 0, i32 1
  %t685 = load ptr, ptr %t684, !tbaa !29
  %t687 = getelementptr %"compiler/generic:Program", ptr %t685, i32 0, i32 0
  %t688 = load ptr, ptr %t687, !tbaa !29
  %t690 = getelementptr %"compiler/load:Loader", ptr %t688, i32 0, i32 4
  %t691 = load ptr, ptr %t690, !tbaa !29
  store ptr %t691, ptr %l304, !tbaa !29
  %t692 = load { i64, [3 x i64] }, ptr %l35
  store { i64, [3 x i64] } %t692, ptr %l305
  %t693 = ptrtoint ptr %v0 to i64
  store i64 %t693, ptr %l306, !tbaa !24
  %t694 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3acontext_2e1
  br i1 %t694, label %bb98, label %bb99
bb97:
  br label %bb103
bb98:
  %t696 = call ptr @__olang_region_make(ptr %v0)
  %t697 = ptrtoint ptr %t696 to i64
  store i64 %t697, ptr %l306, !tbaa !24
  br label %bb99
bb99:
  %t698 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t698, ptr %l308, !tbaa !27
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t700 = load ptr, ptr %l4, !tbaa !29
  %t702 = getelementptr %"compiler/generic:AnyTable", ptr %t700, i32 0, i32 1
  %t703 = load i32, ptr %t702, !tbaa !23
  %t706 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t699, i32 %t703)
  store { i64, ptr } %t706, ptr %l312
  br label %bb100
bb100:
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t708 = load i32, ptr %l20, !tbaa !23
  %t711 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t707, i32 %t708)
  store { i64, ptr } %t711, ptr %l315
  br label %bb101
bb101:
  %t712 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t713 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t714 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t715 = extractvalue { i64, ptr } %t714, 1
  %t716 = extractvalue { i64, ptr } %t714, 0
  %t717 = add i64 %t713, %t716
  %t718 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t719 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t720 = add i64 %t717, %t719
  %t721 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t722 = extractvalue { i64, ptr } %t721, 1
  %t723 = extractvalue { i64, ptr } %t721, 0
  %t724 = add i64 %t720, %t723
  %t725 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t726 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t727 = add i64 %t724, %t726
  %t728 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t729 = extractvalue { i64, ptr } %t728, 1
  %t730 = extractvalue { i64, ptr } %t728, 0
  %t731 = add i64 %t727, %t730
  %t732 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t733 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t734 = add i64 %t731, %t733
  %t735 = load i64, ptr %l306
  %t736 = inttoptr i64 %t735 to ptr
  %t737 = call ptr @__olang_held_alloc(ptr %t736, i64 %t734)
  call void @olang_textcopy(ptr %t737, ptr %t712, i64 %t713)
  %t738 = getelementptr i8, ptr %t737, i64 %t713
  call void @olang_textcopy(ptr %t738, ptr %t715, i64 %t716)
  %t739 = getelementptr i8, ptr %t738, i64 %t716
  call void @olang_textcopy(ptr %t739, ptr %t718, i64 %t719)
  %t740 = getelementptr i8, ptr %t739, i64 %t719
  call void @olang_textcopy(ptr %t740, ptr %t722, i64 %t723)
  %t741 = getelementptr i8, ptr %t740, i64 %t723
  call void @olang_textcopy(ptr %t741, ptr %t725, i64 %t726)
  %t742 = getelementptr i8, ptr %t741, i64 %t726
  call void @olang_textcopy(ptr %t742, ptr %t729, i64 %t730)
  %t743 = getelementptr i8, ptr %t742, i64 %t730
  call void @olang_textcopy(ptr %t743, ptr %t732, i64 %t733)
  %t744 = insertvalue { i64, ptr } undef, i64 %t734, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t737, 1
  %t747 = load i64, ptr %l306
  %t748 = inttoptr i64 %t747 to ptr
  %t749 = extractvalue { i64, ptr } %t745, 0
  %t750 = extractvalue { i64, ptr } %t745, 1
  %t751 = mul i64 %t749, 1
  %t752 = call ptr @__olang_held_alloc(ptr %t748, i64 %t751)
  call void @llvm.memcpy.p0.p0.i64(ptr %t752, ptr %t750, i64 %t751, i1 false)
  %t753 = insertvalue { i64, ptr } undef, i64 %t749, 0
  %t754 = insertvalue { i64, ptr } %t753, ptr %t752, 1
  %t755 = load ptr, ptr %l304, !tbaa !29
  %t756 = load { i64, [3 x i64] }, ptr %l305
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v0, ptr %t755, { i64, [3 x i64] } %t756, { i64, ptr } %t754)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s12)
  br label %bb103
bb103:
  %t758 = load ptr, ptr %l0, !tbaa !29
  store ptr %t758, ptr %l318, !tbaa !29
  %t759 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t759, ptr %l319
  %t760 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t760, ptr %l320
  %t761 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 3
  %t762 = load i64, ptr %t761, !tbaa !24
  store i64 %t762, ptr %l321, !tbaa !24
  %t763 = load ptr, ptr %l22, !tbaa !29
  store ptr %t763, ptr %l323, !tbaa !29
  %t765 = icmp sge i64 0, 0
  br i1 %t765, label %bb104, label %bb105
bb104:
  %t767 = icmp sle i64 0, 1152921504606846975
  br i1 %t767, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @olang_loc_f31fa7029241fd32_aa76ba41726a43b6)
  unreachable
bb106:
  %t769 = mul i64 0, 8
  %t770 = insertvalue { i64, ptr } undef, i64 0, 0
  %t771 = insertvalue { i64, ptr } %t770, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t771, ptr %l326, !tbaa !27
  %t772 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t772, ptr %l327, !tbaa !27
  %t773 = icmp sge i64 0, 0
  br i1 %t773, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @olang_loc_f31fa7029241fd32_aa76ba41726a43b6)
  unreachable
bb108:
  %t775 = icmp sle i64 0, 2305843009213693951
  br i1 %t775, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5)
  unreachable
bb110:
  %t777 = mul i64 0, 4
  %t778 = insertvalue { i64, ptr } undef, i64 0, 0
  %t779 = insertvalue { i64, ptr } %t778, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t780 = load ptr, ptr %l318, !tbaa !29
  %t781 = load %"compiler/source:Span", ptr %l319
  %t782 = load %"compiler/source:Span", ptr %l320
  %t783 = load i64, ptr %l321, !tbaa !24
  %t784 = load ptr, ptr %l323, !tbaa !29
  %t785 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t786 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t788 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t780, %"compiler/source:Span" %t781, %"compiler/source:Span" %t782, i64 %t783, ptr %t784, { i64, ptr } %t785, { i64, ptr } %t786, { i64, ptr } %t779)
  store ptr %t788, ptr %l331
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5)
  unreachable
bb112:
  %t789 = load ptr, ptr %l331, !tbaa !29
  store ptr %t789, ptr %l31, !tbaa !29
  %t791 = load { i64, [3 x i64] }, ptr %l35
  %t793 = extractvalue { i64, [3 x i64] } %t791, 0
  %t794 = icmp eq i64 %t793, 0
  %t796 = xor i1 %t794, true
  br i1 %t796, label %bb113, label %bb114
bb113:
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/check:Checker", ptr %t798, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = getelementptr %"compiler/generic:Program", ptr %t801, i32 0, i32 0
  %t804 = load ptr, ptr %t803, !tbaa !29
  %t806 = getelementptr %"compiler/load:Loader", ptr %t804, i32 0, i32 4
  %t807 = load ptr, ptr %t806, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t807)
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb116
bb116:
  br label %bb140
bb117:
  %t809 = load i1, ptr %l341, !tbaa !21
  br i1 %t809, label %bb118, label %bb119
bb118:
  %t810 = load ptr, ptr %l0, !tbaa !29
  store ptr %t810, ptr %l342, !tbaa !29
  %t811 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t811, ptr %l343
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t814 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t812)
  store i32 %t814, ptr %l345
  br label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s17
  %t815 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t817 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s17, { i64, ptr } %t815, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t817, ptr %l359
  br label %bb124
bb120:
  %t818 = load i32, ptr %l20, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t819
  %t820 = getelementptr { i64, [3 x i64] }, ptr %t819, i32 0, i32 0
  store i64 4, ptr %t820
  %t822 = insertvalue { i32, i32 } undef, i32 1, 0
  %t824 = insertvalue { i32, i32 } %t822, i32 %t818, 1
  %t825 = getelementptr { i64, [3 x i64] }, ptr %t819, i32 0, i32 1
  store { i32, i32 } %t824, ptr %t825
  %t826 = load { i64, [3 x i64] }, ptr %t819
  %t828 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t826, ptr %t828
  store ptr %t828, ptr %l349, !tbaa !29
  %t829 = load ptr, ptr %l0, !tbaa !29
  store ptr %t829, ptr %l350, !tbaa !29
  %t830 = load ptr, ptr %l0, !tbaa !29
  %t831 = load ptr, ptr %l22, !tbaa !29
  %t832 = load %"compiler/source:Span", ptr %l11
  %t836 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t830, ptr %t831, %"compiler/source:Span" %t832)
  store ptr %t836, ptr %l354
  br label %bb121
bb121:
  %t837 = load ptr, ptr %l350, !tbaa !29
  %t838 = load ptr, ptr %l354, !tbaa !29
  %t839 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t837, ptr %t838)
  store { i64, ptr } %t839, ptr %l355
  br label %bb122
bb122:
  %t840 = load ptr, ptr %l342, !tbaa !29
  %t841 = load %"compiler/source:Span", ptr %l343
  %t842 = load i32, ptr %l345, !tbaa !23
  %t843 = load ptr, ptr %l349, !tbaa !29
  %t844 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t845 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t840, %"compiler/source:Span" %t841, i32 %t842, ptr %t843, { i64, ptr } %t844)
  store ptr %t845, ptr %l356
  br label %bb123
bb123:
  %t846 = load ptr, ptr %l356, !tbaa !29
  store ptr %t846, ptr %l31, !tbaa !29
  br label %bb139
bb124:
  %t848 = load i1, ptr %l359, !tbaa !21
  br i1 %t848, label %bb125, label %bb126
bb125:
  %t849 = load ptr, ptr %l0, !tbaa !29
  store ptr %t849, ptr %l360, !tbaa !29
  %t850 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t850, ptr %l361
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t853 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t851)
  store i32 %t853, ptr %l363
  br label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s19
  %t854 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t856 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s19, { i64, ptr } %t854, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t856, ptr %l369
  br label %bb129
bb127:
  %t857 = load ptr, ptr %l22, !tbaa !29
  %t858 = load ptr, ptr %l360, !tbaa !29
  %t859 = load %"compiler/source:Span", ptr %l361
  %t860 = load i32, ptr %l363, !tbaa !23
  %t863 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t858, %"compiler/source:Span" %t859, i32 %t860, i32 22, ptr %t857, ptr null)
  store ptr %t863, ptr %l366
  br label %bb128
bb128:
  %t864 = load ptr, ptr %l366, !tbaa !29
  store ptr %t864, ptr %l31, !tbaa !29
  br label %bb138
bb129:
  %t866 = load i1, ptr %l369, !tbaa !21
  br i1 %t866, label %bb130, label %bb131
bb130:
  %t867 = load ptr, ptr %l0, !tbaa !29
  store ptr %t867, ptr %l370, !tbaa !29
  %t868 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t868, ptr %l371
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t871 = getelementptr %"compiler/check:Checker", ptr %t869, i32 0, i32 1
  %t872 = load ptr, ptr %t871, !tbaa !29
  %t874 = getelementptr %"compiler/generic:Program", ptr %t872, i32 0, i32 2
  %t875 = load i32, ptr %l8, !tbaa !23
  %t878 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t874, i32 %t875)
  store i32 %t878, ptr %l376
  br label %bb132
bb131:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t880 = load %"compiler/source:Span", ptr %l11
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t879, %"compiler/source:Span" %t880, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb135
bb132:
  store i32 21, ptr %l377
  %t883 = load ptr, ptr %l0, !tbaa !29
  %t884 = load ptr, ptr %l22, !tbaa !29
  %t885 = load %"compiler/source:Span", ptr %l11
  %t889 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t883, ptr %t884, %"compiler/source:Span" %t885)
  store ptr %t889, ptr %l381
  br label %bb133
bb133:
  %t890 = load ptr, ptr %l370, !tbaa !29
  %t891 = load %"compiler/source:Span", ptr %l371
  %t892 = load i32, ptr %l376, !tbaa !23
  %t893 = load i32, ptr %l377, !range !{i32 0, i32 52}
  %t894 = load ptr, ptr %l381, !tbaa !29
  %t895 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t890, %"compiler/source:Span" %t891, i32 %t892, i32 %t893, ptr %t894, ptr null)
  store ptr %t895, ptr %l382
  br label %bb134
bb134:
  %t896 = load ptr, ptr %l382, !tbaa !29
  store ptr %t896, ptr %l31, !tbaa !29
  br label %bb137
bb135:
  %t898 = load ptr, ptr %l0, !tbaa !29
  %t899 = load %"compiler/source:Span", ptr %l11
  %t902 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v0, ptr %t898, %"compiler/source:Span" %t899)
  store ptr %t902, ptr %l388
  br label %bb136
bb136:
  %t903 = load ptr, ptr %l388, !tbaa !29
  store ptr %t903, ptr %l31, !tbaa !29
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s19)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s17)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s15)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t905 = load ptr, ptr %l10, !tbaa !29
  store ptr %t905, ptr %l390, !tbaa !29
  %t906 = load ptr, ptr %l390, !tbaa !29
  %t907 = getelementptr %"compiler/check:frame", ptr %t906, i32 0, i32 15
  %t908 = load i64, ptr %t907, !tbaa !24
  %t910 = sub i64 %t908, 1
  %t912 = load ptr, ptr %l390, !tbaa !29
  %t913 = getelementptr %"compiler/check:frame", ptr %t912, i32 0, i32 15
  store i64 %t910, ptr %t913, !tbaa !24
  %t914 = load ptr, ptr %l31, !tbaa !29
  %t916 = icmp eq ptr %t914, null
  br i1 %t916, label %bb142, label %bb143
bb142:
  call void @__olang_check_failed(ptr @olang_loc_e17fa1ab378faab9_6d6fcc9fefe16fc5)
  unreachable
bb143:
  br label %bb144
bb144:
  %t918 = load ptr, ptr %l31, !tbaa !29
  store ptr %t918, ptr %l36, !tbaa !29
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t922 = getelementptr %"compiler/check:Checker", ptr %t920, i32 0, i32 1
  %t923 = load ptr, ptr %t922, !tbaa !29
  %t925 = getelementptr %"compiler/generic:Program", ptr %t923, i32 0, i32 2
  store ptr %t925, ptr %l398, !tbaa !29
  %t926 = load ptr, ptr %l0, !tbaa !29
  %t928 = getelementptr %"compiler/check:Checker", ptr %t926, i32 0, i32 1
  %t929 = load ptr, ptr %t928, !tbaa !29
  %t931 = getelementptr %"compiler/generic:Program", ptr %t929, i32 0, i32 2
  %t932 = load i32, ptr %l8, !tbaa !23
  %t935 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t931, i32 %t932)
  store i32 %t935, ptr %l403
  br label %bb145
bb145:
  %t936 = load ptr, ptr %l398, !tbaa !29
  %t937 = load i32, ptr %l403, !tbaa !23
  %t938 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t936, i32 %t937)
  store { i64, ptr } %t938, ptr %l404
  br label %bb146
bb146:
  %t939 = load { i64, ptr }, ptr %l404, !tbaa !27
  %t940 = extractvalue { i64, ptr } %t939, 0
  %t942 = icmp sgt i64 %t940, 0
  br i1 %t942, label %bb147, label %bb148
bb147:
  %t944 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t944, ptr %l407
  %t945 = load ptr, ptr %l36, !tbaa !29
  %t948 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t945)
  store i32 %t948, ptr %l410
  br label %bb149
bb148:
  br label %bb155
bb149:
  %t949 = load ptr, ptr %l36, !tbaa !29
  store ptr %t949, ptr %l412, !tbaa !29
  %t951 = icmp sge i64 0, 0
  br i1 %t951, label %bb150, label %bb151
bb150:
  %t953 = icmp sle i64 0, 1152921504606846975
  br i1 %t953, label %bb152, label %bb153
bb151:
  call void @__olang_check_failed(ptr @olang_loc_cd555273ac5ad6b8_af09fb78e7087b4)
  unreachable
bb152:
  %t955 = mul i64 0, 8
  %t956 = insertvalue { i64, ptr } undef, i64 0, 0
  %t957 = insertvalue { i64, ptr } %t956, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t958 = load ptr, ptr %l412, !tbaa !29
  %t960 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t958, { i64, ptr } %t957, i1 false, i1 false, i1 true)
  store %"compiler/typed:Try" %t960, ptr %l416
  br label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_cd555273ac5ad6b8_af09fb78e7087b4)
  unreachable
bb154:
  %t961 = load %"compiler/typed:Try", ptr %l416
  %t962 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t961, ptr %t962
  store { i64, [5 x i64] } zeroinitializer, ptr %t963
  %t964 = getelementptr { i64, [5 x i64] }, ptr %t963, i32 0, i32 0
  store i64 14, ptr %t964
  %t965 = load %"compiler/source:Span", ptr %l407
  %t966 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t965, 0
  %t967 = load i32, ptr %l410, !tbaa !23
  %t968 = insertvalue { %"compiler/source:Span", i32, ptr } %t966, i32 %t967, 1
  %t970 = insertvalue { %"compiler/source:Span", i32, ptr } %t968, ptr %t962, 2
  %t971 = getelementptr { i64, [5 x i64] }, ptr %t963, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t970, ptr %t971
  %t972 = load { i64, [5 x i64] }, ptr %t963
  %t974 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t972, ptr %t974
  store ptr %t974, ptr %l36, !tbaa !29
  br label %bb155
bb155:
  %t976 = load ptr, ptr %l0, !tbaa !29
  %t978 = getelementptr %"compiler/check:Checker", ptr %t976, i32 0, i32 45
  %t980 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t978)
  store i64 %t980, ptr %l422
  br label %bb156
bb156:
  %t981 = load i64, ptr %l422, !tbaa !24
  store i64 %t981, ptr %l37, !tbaa !24
  %t982 = load ptr, ptr %l0, !tbaa !29
  %t984 = getelementptr %"compiler/check:Checker", ptr %t982, i32 0, i32 1
  %t985 = load ptr, ptr %t984, !tbaa !29
  %t987 = getelementptr %"compiler/generic:Program", ptr %t985, i32 0, i32 2
  %t988 = load i32, ptr %l8, !tbaa !23
  %t991 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t987, i32 %t988)
  store i32 %t991, ptr %l427
  br label %bb157
bb157:
  %t992 = load i32, ptr %l427, !tbaa !23
  store i32 %t992, ptr %l38, !tbaa !23
  %t993 = load i32, ptr %l38, !tbaa !23
  %t994 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t997 = icmp eq i32 %t993, %t994
  br i1 %t997, label %bb158, label %bb159
bb158:
  %t999 = load ptr, ptr %l0, !tbaa !29
  %t1001 = getelementptr %"compiler/check:Checker", ptr %t999, i32 0, i32 45
  %t1002 = load %"compiler/source:Span", ptr %l11
  %t1003 = load ptr, ptr %l36, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1004
  %t1005 = getelementptr { i64, [3 x i64] }, ptr %t1004, i32 0, i32 0
  store i64 2, ptr %t1005
  %t1007 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1002, 0
  %t1009 = insertvalue { %"compiler/source:Span", ptr } %t1007, ptr %t1003, 1
  %t1010 = getelementptr { i64, [3 x i64] }, ptr %t1004, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1009, ptr %t1010
  %t1011 = load { i64, [3 x i64] }, ptr %t1004
  %t1013 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1011, ptr %t1013
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1001, ptr %t1013)
  br label %bb160
bb159:
  %t1016 = load i32, ptr %l38, !tbaa !23
  %t1017 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t1020 = icmp eq i32 %t1016, %t1017
  br i1 %t1020, label %bb161, label %bb162
bb160:
  br label %bb168
bb161:
  %t1022 = load ptr, ptr %l0, !tbaa !29
  %t1024 = getelementptr %"compiler/check:Checker", ptr %t1022, i32 0, i32 45
  %t1025 = load %"compiler/source:Span", ptr %l11
  %t1026 = load ptr, ptr %l36, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1027
  %t1028 = getelementptr { i64, [3 x i64] }, ptr %t1027, i32 0, i32 0
  store i64 2, ptr %t1028
  %t1030 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1025, 0
  %t1032 = insertvalue { %"compiler/source:Span", ptr } %t1030, ptr %t1026, 1
  %t1033 = getelementptr { i64, [3 x i64] }, ptr %t1027, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1032, ptr %t1033
  %t1034 = load { i64, [3 x i64] }, ptr %t1027
  %t1036 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1034, ptr %t1036
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1024, ptr %t1036)
  br label %bb163
bb162:
  %t1039 = load ptr, ptr %l0, !tbaa !29
  %t1041 = getelementptr %"compiler/check:Checker", ptr %t1039, i32 0, i32 45
  store ptr %t1041, ptr %l453, !tbaa !29
  %t1042 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t1042, ptr %l454
  %t1043 = load ptr, ptr %l0, !tbaa !29
  %t1044 = load ptr, ptr %l36, !tbaa !29
  %t1045 = load i32, ptr %l38, !tbaa !23
  %t1046 = load %"compiler/source:Span", ptr %l11
  %t1051 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t1043, ptr %t1044, i32 %t1045, %"compiler/source:Span" %t1046)
  store ptr %t1051, ptr %l459
  br label %bb165
bb163:
  %t1052 = load ptr, ptr %l0, !tbaa !29
  %t1054 = getelementptr %"compiler/check:Checker", ptr %t1052, i32 0, i32 45
  %t1055 = load %"compiler/source:Span", ptr %l11
  store { i64, [3 x i64] } zeroinitializer, ptr %t1056
  %t1057 = getelementptr { i64, [3 x i64] }, ptr %t1056, i32 0, i32 0
  store i64 9, ptr %t1057
  %t1059 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1055, 0
  %t1061 = insertvalue { %"compiler/source:Span", i32, ptr } %t1059, i32 0, 1
  %t1062 = insertvalue { %"compiler/source:Span", i32, ptr } %t1061, ptr null, 2
  %t1063 = getelementptr { i64, [3 x i64] }, ptr %t1056, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1062, ptr %t1063
  %t1064 = load { i64, [3 x i64] }, ptr %t1056
  %t1066 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1064, ptr %t1066
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1054, ptr %t1066)
  br label %bb164
bb164:
  br label %bb167
bb165:
  %t1069 = load ptr, ptr %l459, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1070
  %t1071 = getelementptr { i64, [3 x i64] }, ptr %t1070, i32 0, i32 0
  store i64 6, ptr %t1071
  %t1072 = load %"compiler/source:Span", ptr %l454
  %t1073 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1072, 0
  %t1075 = insertvalue { %"compiler/source:Span", ptr } %t1073, ptr %t1069, 1
  %t1076 = getelementptr { i64, [3 x i64] }, ptr %t1070, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1075, ptr %t1076
  %t1077 = load { i64, [3 x i64] }, ptr %t1070
  %t1079 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1077, ptr %t1079
  %t1080 = load ptr, ptr %l453, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1080, ptr %t1079)
  br label %bb166
bb166:
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t1082 = load ptr, ptr %l0, !tbaa !29
  %t1084 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1082)
  store ptr %t1084, ptr %l464
  br label %bb169
bb169:
  %t1085 = load ptr, ptr %l464, !tbaa !29
  store ptr %t1085, ptr %l465, !tbaa !29
  %t1086 = load ptr, ptr %l0, !tbaa !29
  %t1088 = getelementptr %"compiler/check:Checker", ptr %t1086, i32 0, i32 45
  %t1089 = load i64, ptr %l37, !tbaa !24
  %t1092 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1088, i64 %t1089)
  store { i64, ptr } %t1092, ptr %l469
  br label %bb170
bb170:
  %t1093 = load { i64, ptr }, ptr %l469, !tbaa !27
  %t1094 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t1093)
  store %"compiler/typed:Block" %t1094, ptr %l470
  br label %bb171
bb171:
  %t1095 = load %"compiler/typed:Block", ptr %l470
  %t1096 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t1095, ptr %t1096
  %t1098 = load ptr, ptr %l465, !tbaa !29
  %t1099 = getelementptr %"compiler/typed:Body", ptr %t1098, i32 0, i32 11
  store ptr %t1096, ptr %t1099, !tbaa !29
  %t1100 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t1100)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i64
  %l9 = alloca i64
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %rv = alloca ptr
  %t36 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 44
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t9, ptr %a4)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t15, ptr %a5)
  br label %bb3
bb3:
  store %"compiler/source:Span" %a1, ptr %l16
  %t20 = load i32, ptr %l2, !tbaa !23
  store i32 %t20, ptr %l17, !tbaa !23
  %t21 = load i32, ptr %l3, !range !{i32 0, i32 52}
  store i32 %t21, ptr %l18
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 52}
  %t24 = load i32, ptr %l2, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopCheck(ptr %v0, ptr %t22, i32 %t23, i32 %t24)
  store i32 %t28, ptr %l22
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 44
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t31, i64 %t32)
  store { i64, ptr } %t35, ptr %l26
  br label %bb5
bb5:
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 9, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l16
  %t39 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t38, 0
  %t40 = load i32, ptr %l17, !tbaa !23
  %t41 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t39, i32 %t40, 1
  %t42 = load i32, ptr %l18, !range !{i32 0, i32 52}
  %t43 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t41, i32 %t42, 2
  %t44 = load i32, ptr %l22, !range !{i32 0, i32 4}
  %t45 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t43, i32 %t44, 3
  %t46 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t47 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t45, { i64, ptr } %t46, 4
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t47, ptr %t48
  %t49 = load { i64, [5 x i64] }, ptr %t36
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t49, ptr %t51
  store ptr %t51, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i32, ptr %l6, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = icmp ne i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp ne i32 %t12, %t13
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t20)
  store %"compiler/source:Span" %t22, ptr %l16
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l19
  br label %bb8
bb8:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %v0, { i64, ptr } %t34)
  store %"compiler/diagmsg:Msg" %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l16
  %t39 = load %"compiler/diagmsg:Msg", ptr %l21
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t37, %"compiler/source:Span" %t38, %"compiler/diagmsg:Msg" %t39)
  store i64 %t40, ptr %l22
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l23, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l25
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t45, %"compiler/source:Span" %t46)
  store ptr %t47, ptr %l26
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t48 = load ptr, ptr %l26, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i32
  %l26 = alloca i1
  %l28 = alloca i1
  %l32 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/diagmsg:Msg"
  %l51 = alloca i64
  %l56 = alloca ptr
  %l59 = alloca i1
  %l61 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i64
  %l74 = alloca ptr
  %l80 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l92 = alloca i32
  %l94 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l110 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca i32
  %l125 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l136 = alloca i1
  %l139 = alloca i1
  %l144 = alloca ptr
  %l147 = alloca i1
  %l151 = alloca i32
  %l158 = alloca ptr
  %l164 = alloca i32
  %l170 = alloca i64
  %l174 = alloca i1
  %l176 = alloca { i64, ptr }
  %l178 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca %"compiler/source:Span"
  %l184 = alloca i32
  %l189 = alloca ptr
  %l190 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca i32
  %l198 = alloca { i64, ptr }
  %l200 = alloca %"compiler/source:Span"
  %l202 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l213 = alloca %"compiler/diagmsg:Msg"
  %l214 = alloca i64
  %l217 = alloca ptr
  %l222 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l231 = alloca i1
  %l232 = alloca i32
  %l235 = alloca ptr
  %l236 = alloca { i64, ptr }
  %l238 = alloca %"compiler/source:Span"
  %l239 = alloca ptr
  %l242 = alloca i32
  %l246 = alloca i1
  %l253 = alloca i1
  %l254 = alloca i1
  %l257 = alloca i1
  %l262 = alloca ptr
  %l263 = alloca ptr
  %l266 = alloca i32
  %l268 = alloca i1
  %l269 = alloca i1
  %l270 = alloca ptr
  %l273 = alloca i32
  %l275 = alloca i1
  %l279 = alloca i1
  %l281 = alloca ptr
  %l284 = alloca i32
  %l285 = alloca i1
  %l289 = alloca i1
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l292 = alloca %"compiler/source:Span"
  %l293 = alloca %"compiler/source:Span"
  %l296 = alloca i32
  %l300 = alloca ptr
  %l302 = alloca ptr
  %l303 = alloca %"compiler/source:Span"
  %l306 = alloca ptr
  %l308 = alloca ptr
  %l311 = alloca i1
  %l312 = alloca ptr
  %l313 = alloca %"compiler/source:Span"
  %l314 = alloca ptr
  %l317 = alloca ptr
  %l318 = alloca i32
  %l323 = alloca i64
  %l324 = alloca i32
  %l325 = alloca ptr
  %l327 = alloca ptr
  %l331 = alloca i1
  %l334 = alloca ptr
  %l337 = alloca i32
  %l338 = alloca i32
  %l341 = alloca i1
  %l344 = alloca ptr
  %l347 = alloca i32
  %l348 = alloca i32
  %l351 = alloca i1
  %l352 = alloca ptr
  %l355 = alloca ptr
  %l358 = alloca i32
  %l359 = alloca i32
  %l362 = alloca ptr
  %l365 = alloca i32
  %l366 = alloca i32
  %l367 = alloca i1
  %l370 = alloca i1
  %l371 = alloca i64
  %l374 = alloca ptr
  %l375 = alloca %"compiler/source:Span"
  %l376 = alloca %"compiler/source:Span"
  %l382 = alloca i32
  %l385 = alloca ptr
  %l391 = alloca i32
  %l392 = alloca ptr
  %l400 = alloca ptr
  %l404 = alloca i1
  %l410 = alloca ptr
  %l411 = alloca ptr
  %l412 = alloca %"compiler/source:Span"
  %l413 = alloca ptr
  %l414 = alloca ptr
  %l415 = alloca i32
  %l416 = alloca { i64, ptr }
  %l418 = alloca %"compiler/source:Span"
  %l419 = alloca ptr
  %l421 = alloca ptr
  %l422 = alloca ptr
  %l423 = alloca { i64, ptr }
  %l425 = alloca %"compiler/source:Span"
  %l428 = alloca { i64, ptr }
  %l429 = alloca { i64, ptr }
  %l432 = alloca { i64, ptr }
  %l434 = alloca %"compiler/diagmsg:Msg"
  %l435 = alloca i64
  %l438 = alloca ptr
  %l441 = alloca ptr
  %l442 = alloca %"compiler/source:Span"
  %l445 = alloca { i64, ptr }
  %l446 = alloca { i64, ptr }
  %l448 = alloca %"compiler/diagmsg:Msg"
  %l449 = alloca i64
  %l454 = alloca ptr
  %l457 = alloca i1
  %l459 = alloca ptr
  %l464 = alloca i32
  %l465 = alloca i1
  %l469 = alloca i32
  %l476 = alloca ptr
  %l477 = alloca %"compiler/source:Span"
  %l478 = alloca %"compiler/source:Span"
  %l479 = alloca i32
  %l482 = alloca ptr
  %l487 = alloca i32
  %l488 = alloca i32
  %l489 = alloca { i64, ptr }
  %l493 = alloca ptr
  %l498 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca ptr
  %t211 = alloca { i64, [3 x i64] }, align 8
  %t350 = alloca { i64, [3 x i64] }, align 8
  %t580 = alloca { i64, [4 x i64] }, align 8
  %t760 = alloca { i64, [5 x i64] }, align 8
  %t795 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l2
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i1 %t7, ptr %l26
  br label %bb1
bb1:
  %t8 = load i1, ptr %l26, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l32
  br label %bb4
bb4:
  %t19 = load i1, ptr %l32, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l28, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t23, { i64, ptr } %t24)
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t27, %"compiler/source:Span" %t28)
  store ptr %t31, ptr %l38
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l38, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l41
  br label %bb11
bb11:
  %t38 = load i32, ptr %l41, !range !{i32 0, i32 6}
  store i32 %t38, ptr %l5
  %t39 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t41 = trunc i64 5 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l44, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t45, ptr %l45
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t46, i32 %t47)
  store { i64, ptr } %t50, ptr %l48
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t51 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForeignBuilt(ptr %s2, ptr %v0, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t59, ptr %l50
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l44, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l45
  %t62 = load %"compiler/diagmsg:Msg", ptr %l50
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t60, %"compiler/source:Span" %t61, %"compiler/diagmsg:Msg" %t62)
  store i64 %t63, ptr %l51
  br label %bb16
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t64, { i64, ptr } %t65)
  br label %bb17
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l1
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t68, %"compiler/source:Span" %t69)
  store ptr %t72, ptr %l56
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  %t73 = load ptr, ptr %l56, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb19:
  %t74 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t76 = trunc i64 0 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  store ptr %t82, ptr %l61, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l66
  br label %bb22
bb21:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb24
bb22:
  %t93 = load ptr, ptr %l61, !tbaa !29
  %t94 = load i32, ptr %l66, !tbaa !23
  %t95 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t93, i32 %t94)
  store i64 %t95, ptr %l67
  br label %bb23
bb23:
  %t96 = load i64, ptr %l67, !tbaa !24
  %t97 = icmp sgt i64 %t96, 0
  store i1 %t97, ptr %l59, !tbaa !21
  br label %bb24
bb24:
  %t99 = load i1, ptr %l59, !tbaa !21
  br i1 %t99, label %bb25, label %bb26
bb25:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  %t102 = load %"compiler/source:Span", ptr %l2
  %t103 = load i32, ptr %l3, !tbaa !23
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinCall(ptr %v0, ptr %v1, ptr %v2, ptr %t100, %"compiler/source:Span" %t101, %"compiler/source:Span" %t102, i32 %t103, { i64, ptr } %t104)
  store ptr %t110, ptr %l74
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t111 = load ptr, ptr %l74, !tbaa !29
  store ptr %t111, ptr %rv
  br label %ret
bb28:
  %t112 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t114 = trunc i64 0 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t121 = load i32, ptr %l3, !tbaa !23
  %t124 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l80
  br label %bb31
bb30:
  br label %bb52
bb31:
  %t125 = load i32, ptr %l80, !tbaa !23
  store i32 %t125, ptr %l6, !tbaa !23
  %t126 = load i32, ptr %l6, !tbaa !23
  %t127 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t130 = icmp eq i32 %t126, %t127
  br i1 %t130, label %bb32, label %bb33
bb32:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l1
  %t136 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t132, %"compiler/source:Span" %t133)
  store ptr %t136, ptr %l86
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s4)
  %t137 = load ptr, ptr %l86, !tbaa !29
  store ptr %t137, ptr %rv
  br label %ret
bb35:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l87, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l3, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l92
  br label %bb36
bb36:
  %t149 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t150 = load ptr, ptr %l87, !tbaa !29
  %t151 = load i32, ptr %l92, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %v0, ptr %t150, i32 %t151, { i64, ptr } %t149)
  store { i64, ptr } %t153, ptr %l94
  br label %bb37
bb37:
  %t154 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t154, ptr %l4, !tbaa !27
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 170
  %t158 = load i1, ptr %t157, !tbaa !21
  br i1 %t158, label %bb38, label %bb39
bb38:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 170
  store i1 false, ptr %t162, !tbaa !21
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v0, ptr %t163, { i64, ptr } %t164)
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t167, %"compiler/source:Span" %t168)
  store ptr %t171, ptr %l102
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s4)
  %t172 = load ptr, ptr %l102, !tbaa !29
  store ptr %t172, ptr %rv
  br label %ret
bb42:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 171
  %t177 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %s4, ptr %t175)
  store { i64, ptr } %t177, ptr %l105
  br label %bb43
bb43:
  %t178 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t178, ptr %l7, !tbaa !27
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 171
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t181)
  br label %bb44
bb44:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l3, !tbaa !23
  %t187 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t183, i32 %t184)
  store i64 %t187, ptr %l110
  br label %bb45
bb45:
  %t188 = load i64, ptr %l110, !tbaa !24
  store i64 %t188, ptr %l8, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 28
  %t192 = load i32, ptr %t191, !tbaa !23
  store i32 %t192, ptr %l9, !tbaa !23
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l3, !tbaa !23
  %t198 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 28
  store i32 %t195, ptr %t198, !tbaa !23
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %s4, ptr %t199, { i64, ptr } %t200)
  br label %bb46
bb46:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l117, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t204, ptr %l118
  %t205 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t205, ptr %l119
  %t206 = load i32, ptr %l6, !tbaa !23
  store i32 %t206, ptr %l120, !tbaa !23
  %t207 = load i64, ptr %l8, !tbaa !24
  %t209 = trunc i64 %t207 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 0
  store i64 0, ptr %t212
  %t214 = insertvalue { i32 } undef, i32 %t209, 0
  %t215 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  store { i32 } %t214, ptr %t215
  %t216 = load { i64, [3 x i64] }, ptr %t211
  %t218 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t216, ptr %t218
  store ptr %t218, ptr %l125, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t219, ptr %l126, !tbaa !27
  %t220 = icmp sge i64 0, 0
  br i1 %t220, label %bb47, label %bb48
bb47:
  %t222 = icmp sle i64 0, 1152921504606846975
  br i1 %t222, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_77e9ca8727c07af9_ddc1fd4e636ee49d)
  unreachable
bb49:
  %t224 = mul i64 0, 8
  %t225 = insertvalue { i64, ptr } undef, i64 0, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t227 = load ptr, ptr %l117, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l118
  %t229 = load %"compiler/source:Span", ptr %l119
  %t230 = load i32, ptr %l120, !tbaa !23
  %t231 = load ptr, ptr %l125, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t227, %"compiler/source:Span" %t228, %"compiler/source:Span" %t229, i32 %t230, ptr %t231, i64 -1, ptr null, { i64, ptr } %t232, { i64, ptr } %t226)
  store ptr %t234, ptr %l130
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_77e9ca8727c07af9_ddc1fd4e636ee49d)
  unreachable
bb51:
  %t235 = load ptr, ptr %l130, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l9, !tbaa !23
  %t240 = getelementptr %"compiler/check:Checker", ptr %t236, i32 0, i32 28
  store i32 %t237, ptr %t240, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  store ptr %t235, ptr %rv
  br label %ret
bb52:
  %t243 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t245 = trunc i64 4 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb53, label %bb54
bb53:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l3, !tbaa !23
  %t252 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %t248, i32 %t249)
  store i1 %t252, ptr %l139
  br label %bb55
bb54:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb56
bb55:
  %t253 = load i1, ptr %l139, !tbaa !21
  store i1 %t253, ptr %l136, !tbaa !21
  br label %bb56
bb56:
  %t254 = load i1, ptr %l136, !tbaa !21
  br i1 %t254, label %bb57, label %bb58
bb57:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t255, { i64, ptr } %t256)
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t259, %"compiler/source:Span" %t260)
  store ptr %t263, ptr %l144
  br label %bb60
bb60:
  %t264 = load ptr, ptr %l144, !tbaa !29
  store ptr %t264, ptr %rv
  br label %ret
bb61:
  %t265 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t267 = trunc i64 4 to i32
  %t268 = icmp eq i32 %t265, %t267
  br i1 %t268, label %bb62, label %bb63
bb62:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load i32, ptr %l3, !tbaa !23
  %t277 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l151
  br label %bb64
bb63:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb65
bb64:
  %t278 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t279 = load i32, ptr %l151, !tbaa !23
  %t281 = icmp ne i32 %t279, %t278
  store i1 %t281, ptr %l147, !tbaa !21
  br label %bb65
bb65:
  %t283 = load i1, ptr %l147, !tbaa !21
  br i1 %t283, label %bb66, label %bb67
bb66:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l1
  %t286 = load i32, ptr %l3, !tbaa !23
  %t287 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t292 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etoDeclaredFunc(ptr %v0, ptr %v1, ptr %v2, ptr %t284, %"compiler/source:Span" %t285, i32 %t286, { i64, ptr } %t287)
  store ptr %t292, ptr %l158
  br label %bb68
bb67:
  br label %bb69
bb68:
  %t293 = load ptr, ptr %l158, !tbaa !29
  store ptr %t293, ptr %rv
  br label %ret
bb69:
  %t294 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t296 = trunc i64 4 to i32
  %t297 = icmp eq i32 %t294, %t296
  br i1 %t297, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s9
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t303 = load i32, ptr %l3, !tbaa !23
  %t306 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l164
  br label %bb72
bb71:
  br label %bb196
bb72:
  %t307 = load i32, ptr %l164, !tbaa !23
  store i32 %t307, ptr %l11, !tbaa !23
  %t308 = load i32, ptr %l11, !tbaa !23
  %t309 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t312 = icmp ne i32 %t308, %t309
  br i1 %t312, label %bb73, label %bb74
bb73:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load i32, ptr %l3, !tbaa !23
  %t318 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t314, i32 %t315)
  store i64 %t318, ptr %l170
  br label %bb75
bb74:
  br label %bb90
bb75:
  %t319 = load i64, ptr %l170, !tbaa !24
  store i64 %t319, ptr %l12, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t324 = icmp eq i64 %t322, 1
  br i1 %t324, label %bb76, label %bb77
bb76:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t327, ptr %l176, !tbaa !27
  %t328 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr ptr, ptr %t329, i64 0
  %t331 = load ptr, ptr %t330, !tbaa !39
  %t334 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t326, ptr %t331)
  store i1 %t334, ptr %l178
  br label %bb78
bb77:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb79
bb78:
  %t335 = load i1, ptr %l178, !tbaa !21
  store i1 %t335, ptr %l174, !tbaa !21
  br label %bb79
bb79:
  %t336 = load i1, ptr %l174, !tbaa !21
  store i1 %t336, ptr %l13, !tbaa !21
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load i1, ptr %l13, !tbaa !21
  %t341 = getelementptr %"compiler/check:Checker", ptr %t337, i32 0, i32 55
  store i1 %t338, ptr %t341, !tbaa !21
  %t342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t342, ptr %l181, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t343, ptr %l182
  %t344 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t344, ptr %l183
  %t345 = load i32, ptr %l11, !tbaa !23
  store i32 %t345, ptr %l184, !tbaa !23
  %t346 = load i64, ptr %l12, !tbaa !24
  %t348 = trunc i64 %t346 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t350
  %t351 = getelementptr { i64, [3 x i64] }, ptr %t350, i32 0, i32 0
  store i64 0, ptr %t351
  %t353 = insertvalue { i32 } undef, i32 %t348, 0
  %t354 = getelementptr { i64, [3 x i64] }, ptr %t350, i32 0, i32 1
  store { i32 } %t353, ptr %t354
  %t355 = load { i64, [3 x i64] }, ptr %t350
  %t357 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t355, ptr %t357
  store ptr %t357, ptr %l189, !tbaa !29
  %t358 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t358, ptr %l190, !tbaa !27
  %t359 = icmp sge i64 0, 0
  br i1 %t359, label %bb80, label %bb81
bb80:
  %t361 = icmp sle i64 0, 1152921504606846975
  br i1 %t361, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_5759851fa91ce76c_a0f65aa07f0891f0)
  unreachable
bb82:
  %t363 = mul i64 0, 8
  %t364 = insertvalue { i64, ptr } undef, i64 0, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t366 = load ptr, ptr %l181, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l182
  %t368 = load %"compiler/source:Span", ptr %l183
  %t369 = load i32, ptr %l184, !tbaa !23
  %t370 = load ptr, ptr %l189, !tbaa !29
  %t371 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t373 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v2, ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t366, %"compiler/source:Span" %t367, %"compiler/source:Span" %t368, i32 %t369, ptr %t370, i64 -1, ptr null, { i64, ptr } %t371, { i64, ptr } %t365)
  store ptr %t373, ptr %l194
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_5759851fa91ce76c_a0f65aa07f0891f0)
  unreachable
bb84:
  %t374 = load ptr, ptr %l194, !tbaa !29
  store ptr %t374, ptr %l14, !tbaa !29
  %t375 = load i1, ptr %l13, !tbaa !21
  br i1 %t375, label %bb85, label %bb86
bb85:
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l196, !tbaa !29
  store i32 0, ptr %l197
  %t378 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t378, ptr %l198, !tbaa !27
  %t379 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !27
  %t381 = getelementptr ptr, ptr %t380, i64 0
  %t382 = load ptr, ptr %t381, !tbaa !39
  %t384 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t382)
  store %"compiler/source:Span" %t384, ptr %l200
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t385 = load i32, ptr %l3, !tbaa !23
  %t386 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t386, ptr %l202, !tbaa !27
  %t387 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr ptr, ptr %t388, i64 0
  %t390 = load ptr, ptr %t389, !tbaa !39
  %t392 = load ptr, ptr %l196, !tbaa !29
  %t393 = load i32, ptr %l197, !range !{i32 0, i32 3}
  %t394 = load %"compiler/source:Span", ptr %l200
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %t392, i32 %t393, %"compiler/source:Span" %t394, i32 %t385, ptr %t390)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t397 = load ptr, ptr %l14, !tbaa !29
  call void @__olang_scope_close(ptr %s9)
  store ptr %t397, ptr %rv
  br label %ret
bb90:
  %t399 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t403 = icmp ne i64 %t401, 1
  br i1 %t403, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s12
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l209, !tbaa !29
  %t406 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t406, ptr %l210
  %t407 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t407, 0
  %t411 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s12, ptr %v0, i64 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, i64 %t409)
  store %"compiler/diagmsg:Msg" %t411, ptr %l213
  br label %bb93
bb92:
  br label %bb96
bb93:
  %t412 = load ptr, ptr %l209, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l210
  %t414 = load %"compiler/diagmsg:Msg", ptr %l213
  %t415 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t412, %"compiler/source:Span" %t413, %"compiler/diagmsg:Msg" %t414)
  store i64 %t415, ptr %l214
  br label %bb94
bb94:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l1
  %t420 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t416, %"compiler/source:Span" %t417)
  store ptr %t420, ptr %l217
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s9)
  %t421 = load ptr, ptr %l217, !tbaa !29
  store ptr %t421, ptr %rv
  br label %ret
bb96:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/check:Checker", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l3, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l222
  br label %bb97
bb97:
  %t432 = load i32, ptr %l222, !tbaa !23
  store i32 %t432, ptr %l15, !tbaa !23
  %t433 = load ptr, ptr %l0, !tbaa !29
  store ptr %t433, ptr %l223, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t434, ptr %l224, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t435, ptr %l225, !tbaa !27
  %t436 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = getelementptr ptr, ptr %t437, i64 0
  %t439 = load ptr, ptr %t438, !tbaa !39
  store ptr %t439, ptr %l227, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t442, ptr %l229, !tbaa !27
  %t443 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr ptr, ptr %t444, i64 0
  %t446 = load ptr, ptr %t445, !tbaa !39
  %t449 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t441, ptr %t446)
  store i1 %t449, ptr %l231
  br label %bb98
bb98:
  %t450 = load i1, ptr %l231, !tbaa !21
  br i1 %t450, label %bb99, label %bb100
bb99:
  %t451 = load i32, ptr %l3, !tbaa !23
  store i32 %t451, ptr %l232, !tbaa !23
  br label %bb101
bb100:
  %t453 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t453, ptr %l232, !tbaa !23
  br label %bb101
bb101:
  %t455 = load ptr, ptr %l224, !tbaa !29
  %t456 = load ptr, ptr %l227, !tbaa !29
  %t457 = load i32, ptr %l232, !tbaa !23
  %t458 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t455, ptr %t456, i32 %t457)
  store ptr %t458, ptr %l235
  br label %bb102
bb102:
  %t459 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t459, ptr %l236, !tbaa !27
  %t460 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr ptr, ptr %t461, i64 0
  %t463 = load ptr, ptr %t462, !tbaa !39
  %t465 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t463)
  store %"compiler/source:Span" %t465, ptr %l238
  br label %bb103
bb103:
  %t466 = load ptr, ptr %l223, !tbaa !29
  %t467 = load ptr, ptr %l235, !tbaa !29
  %t468 = load %"compiler/source:Span", ptr %l238
  %t469 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t466, ptr %t467, %"compiler/source:Span" %t468)
  store ptr %t469, ptr %l239
  br label %bb104
bb104:
  %t470 = load ptr, ptr %l239, !tbaa !29
  store ptr %t470, ptr %l16, !tbaa !29
  %t471 = load ptr, ptr %l16, !tbaa !29
  %t474 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t471)
  store i32 %t474, ptr %l242
  br label %bb105
bb105:
  %t475 = load i32, ptr %l242, !tbaa !23
  store i32 %t475, ptr %l17, !tbaa !23
  %t476 = load i32, ptr %l17, !tbaa !23
  %t477 = load i32, ptr %l3, !tbaa !23
  %t480 = icmp eq i32 %t476, %t477
  br i1 %t480, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb108
bb107:
  %t482 = load i32, ptr %l17, !tbaa !23
  %t483 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t486 = icmp eq i32 %t482, %t483
  store i1 %t486, ptr %l246, !tbaa !21
  br label %bb108
bb108:
  %t488 = load i1, ptr %l246, !tbaa !21
  br i1 %t488, label %bb109, label %bb110
bb109:
  %t489 = load ptr, ptr %l16, !tbaa !29
  call void @__olang_scope_close(ptr %s9)
  store ptr %t489, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i32, ptr %l17, !tbaa !23
  %t495 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t491, i32 %t492)
  store i1 %t495, ptr %l253
  br label %bb112
bb112:
  %t496 = load i1, ptr %l253, !tbaa !21
  br i1 %t496, label %bb113, label %bb114
bb113:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load i32, ptr %l3, !tbaa !23
  %t501 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t497, i32 %t498)
  store i1 %t501, ptr %l257
  br label %bb115
bb114:
  store i1 false, ptr %l254, !tbaa !21
  br label %bb116
bb115:
  %t502 = load i1, ptr %l257, !tbaa !21
  store i1 %t502, ptr %l254, !tbaa !21
  br label %bb116
bb116:
  %t503 = load i1, ptr %l254, !tbaa !21
  br i1 %t503, label %bb117, label %bb118
bb117:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load %"compiler/source:Span", ptr %l1
  %t506 = load ptr, ptr %l16, !tbaa !29
  %t507 = load i32, ptr %l3, !tbaa !23
  %t512 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t504, %"compiler/source:Span" %t505, ptr %t506, i32 %t507)
  store ptr %t512, ptr %l262
  br label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_scope_close(ptr %s9)
  %t513 = load ptr, ptr %l262, !tbaa !29
  store ptr %t513, ptr %rv
  br label %ret
bb120:
  %t514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t514, ptr %l263, !tbaa !29
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load i32, ptr %l17, !tbaa !23
  %t519 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t515, i32 %t516)
  store i32 %t519, ptr %l266
  br label %bb121
bb121:
  %t520 = load i32, ptr %l15, !tbaa !23
  %t521 = load ptr, ptr %l263, !tbaa !29
  %t522 = load i32, ptr %l266, !tbaa !23
  %t524 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t521, i32 %t522, i32 %t520)
  store i1 %t524, ptr %l268
  br label %bb122
bb122:
  %t525 = load i1, ptr %l268, !tbaa !21
  br i1 %t525, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l269, !tbaa !21
  br label %bb127
bb124:
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l270, !tbaa !29
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load i32, ptr %l17, !tbaa !23
  %t531 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t527, i32 %t528)
  store i32 %t531, ptr %l273
  br label %bb125
bb125:
  %t532 = load i32, ptr %l15, !tbaa !23
  %t533 = load ptr, ptr %l270, !tbaa !29
  %t534 = load i32, ptr %l273, !tbaa !23
  %t536 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t533, i32 %t534, i32 %t532)
  store i1 %t536, ptr %l275
  br label %bb126
bb126:
  %t537 = load i1, ptr %l275, !tbaa !21
  store i1 %t537, ptr %l269, !tbaa !21
  br label %bb127
bb127:
  %t538 = load i1, ptr %l269, !tbaa !21
  br i1 %t538, label %bb128, label %bb129
bb128:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = getelementptr %"compiler/check:Checker", ptr %t539, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !29
  %t543 = load i32, ptr %l3, !tbaa !23
  %t546 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t542, i32 %t543)
  store i1 %t546, ptr %l279
  br label %bb130
bb129:
  br label %bb189
bb130:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/check:Checker", ptr %t547, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !29
  store ptr %t550, ptr %l281, !tbaa !29
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t552 = load i32, ptr %l17, !tbaa !23
  %t555 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t551, i32 %t552)
  store i32 %t555, ptr %l284
  br label %bb131
bb131:
  %t556 = load ptr, ptr %l281, !tbaa !29
  %t557 = load i32, ptr %l284, !tbaa !23
  %t558 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t556, i32 %t557)
  store i1 %t558, ptr %l285
  br label %bb132
bb132:
  %t559 = load i1, ptr %l279, !tbaa !21
  %t560 = load i1, ptr %l285, !tbaa !21
  %t561 = icmp ne i1 %t559, %t560
  br i1 %t561, label %bb133, label %bb134
bb133:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i32, ptr %l17, !tbaa !23
  %t567 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t563, i32 %t564)
  store i1 %t567, ptr %l289
  br label %bb135
bb134:
  br label %bb143
bb135:
  %t568 = load i1, ptr %l289, !tbaa !21
  br i1 %t568, label %bb136, label %bb137
bb136:
  %t569 = load ptr, ptr %l0, !tbaa !29
  store ptr %t569, ptr %l291, !tbaa !29
  %t570 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t570, ptr %l292
  %t571 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t571, ptr %l293
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load i32, ptr %l17, !tbaa !23
  %t576 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t572, i32 %t573)
  store i32 %t576, ptr %l296
  br label %bb138
bb137:
  %t577 = load ptr, ptr %l16, !tbaa !29
  store ptr %t577, ptr %l290, !tbaa !29
  br label %bb140
bb138:
  %t579 = load ptr, ptr %l16, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t580
  %t581 = getelementptr { i64, [4 x i64] }, ptr %t580, i32 0, i32 0
  store i64 2, ptr %t581
  %t582 = load %"compiler/source:Span", ptr %l293
  %t583 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t582, 0
  %t584 = load i32, ptr %l296, !tbaa !23
  %t585 = insertvalue { %"compiler/source:Span", i32, ptr } %t583, i32 %t584, 1
  %t587 = insertvalue { %"compiler/source:Span", i32, ptr } %t585, ptr %t579, 2
  %t588 = getelementptr { i64, [4 x i64] }, ptr %t580, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t587, ptr %t588
  %t589 = load { i64, [4 x i64] }, ptr %t580
  %t591 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t589, ptr %t591
  %t592 = load ptr, ptr %l291, !tbaa !29
  %t593 = load %"compiler/source:Span", ptr %l292
  %t595 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t592, %"compiler/source:Span" %t593, ptr %t591)
  store ptr %t595, ptr %l300
  br label %bb139
bb139:
  %t596 = load ptr, ptr %l300, !tbaa !29
  store ptr %t596, ptr %l290, !tbaa !29
  br label %bb140
bb140:
  %t597 = load ptr, ptr %l290, !tbaa !29
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l302, !tbaa !29
  %t599 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t599, ptr %l303
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t604 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v2, ptr %v0, ptr %t600, ptr %t597)
  store ptr %t604, ptr %l306
  br label %bb141
bb141:
  %t605 = load i32, ptr %l3, !tbaa !23
  %t606 = load ptr, ptr %l302, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l303
  %t608 = load ptr, ptr %l306, !tbaa !29
  %t610 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v2, ptr %t606, %"compiler/source:Span" %t607, ptr %t608, i32 %t605)
  store ptr %t610, ptr %l308
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s9)
  %t611 = load ptr, ptr %l308, !tbaa !29
  store ptr %t611, ptr %rv
  br label %ret
bb143:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load i32, ptr %l17, !tbaa !23
  %t616 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t612, i32 %t613)
  store i1 %t616, ptr %l311
  br label %bb144
bb144:
  %t617 = load i1, ptr %l311, !tbaa !21
  br i1 %t617, label %bb145, label %bb146
bb145:
  %t618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t618, ptr %l312, !tbaa !29
  %t619 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t619, ptr %l313
  %t620 = load ptr, ptr %l16, !tbaa !29
  store ptr %t620, ptr %l314, !tbaa !29
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = getelementptr %"compiler/check:Checker", ptr %t621, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !29
  %t626 = getelementptr %"compiler/generic:Program", ptr %t624, i32 0, i32 2
  store ptr %t626, ptr %l317, !tbaa !29
  %t627 = load i32, ptr %l3, !tbaa !23
  store i32 %t627, ptr %l318, !tbaa !23
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/check:Checker", ptr %t628, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !29
  %t633 = getelementptr %"compiler/generic:Program", ptr %t631, i32 0, i32 2
  %t634 = load i32, ptr %l17, !tbaa !23
  %t637 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t633, i32 %t634)
  store i64 %t637, ptr %l323
  br label %bb147
bb146:
  br label %bb150
bb147:
  %t638 = load ptr, ptr %l317, !tbaa !29
  %t639 = load i32, ptr %l318, !tbaa !23
  %t640 = load i64, ptr %l323, !tbaa !24
  %t641 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t638, i32 %t639, i64 %t640)
  store i32 %t641, ptr %l324
  br label %bb148
bb148:
  %t642 = load ptr, ptr %l312, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l313
  %t644 = load ptr, ptr %l314, !tbaa !29
  %t645 = load i32, ptr %l324, !tbaa !23
  %t646 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t642, %"compiler/source:Span" %t643, ptr %t644, i32 %t645)
  store ptr %t646, ptr %l325
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s9)
  %t647 = load ptr, ptr %l325, !tbaa !29
  store ptr %t647, ptr %rv
  br label %ret
bb150:
  %t648 = load ptr, ptr %l16, !tbaa !29
  %t650 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v2, ptr %t648)
  store ptr %t650, ptr %l327
  br label %bb151
bb151:
  %t651 = load ptr, ptr %l327, !tbaa !29
  store ptr %t651, ptr %l19, !tbaa !29
  %t652 = load ptr, ptr %l19, !tbaa !29
  %t654 = icmp eq ptr %t652, null
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb152, label %bb153
bb152:
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr %"compiler/check:Checker", ptr %t658, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !29
  %t663 = getelementptr %"compiler/generic:Program", ptr %t661, i32 0, i32 2
  store ptr %t663, ptr %l334, !tbaa !29
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load i32, ptr %l17, !tbaa !23
  %t668 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t664, i32 %t665)
  store i32 %t668, ptr %l337
  br label %bb154
bb153:
  store i1 false, ptr %l331, !tbaa !21
  br label %bb156
bb154:
  %t669 = load ptr, ptr %l334, !tbaa !29
  %t670 = load i32, ptr %l337, !tbaa !23
  %t671 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t669, i32 %t670)
  store i32 %t671, ptr %l338
  br label %bb155
bb155:
  %t672 = load i32, ptr %l338, !range !{i32 0, i32 33}
  %t674 = trunc i64 19 to i32
  %t675 = icmp eq i32 %t672, %t674
  store i1 %t675, ptr %l331, !tbaa !21
  br label %bb156
bb156:
  %t677 = load i1, ptr %l331, !tbaa !21
  br i1 %t677, label %bb157, label %bb158
bb157:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/check:Checker", ptr %t678, i32 0, i32 1
  %t681 = load ptr, ptr %t680, !tbaa !29
  %t683 = getelementptr %"compiler/generic:Program", ptr %t681, i32 0, i32 2
  store ptr %t683, ptr %l344, !tbaa !29
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load i32, ptr %l15, !tbaa !23
  %t688 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t684, i32 %t685)
  store i32 %t688, ptr %l347
  br label %bb159
bb158:
  store i1 false, ptr %l341, !tbaa !21
  br label %bb161
bb159:
  %t689 = load ptr, ptr %l344, !tbaa !29
  %t690 = load i32, ptr %l347, !tbaa !23
  %t691 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t689, i32 %t690)
  store i32 %t691, ptr %l348
  br label %bb160
bb160:
  %t692 = load i32, ptr %l348, !range !{i32 0, i32 33}
  %t694 = trunc i64 19 to i32
  %t695 = icmp eq i32 %t692, %t694
  store i1 %t695, ptr %l341, !tbaa !21
  br label %bb161
bb161:
  %t697 = load i1, ptr %l341, !tbaa !21
  br i1 %t697, label %bb162, label %bb163
bb162:
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l352, !tbaa !29
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t701 = getelementptr %"compiler/check:Checker", ptr %t699, i32 0, i32 1
  %t702 = load ptr, ptr %t701, !tbaa !29
  %t704 = getelementptr %"compiler/generic:Program", ptr %t702, i32 0, i32 2
  store ptr %t704, ptr %l355, !tbaa !29
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load i32, ptr %l17, !tbaa !23
  %t709 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t705, i32 %t706)
  store i32 %t709, ptr %l358
  br label %bb164
bb163:
  store i1 false, ptr %l351, !tbaa !21
  br label %bb169
bb164:
  %t710 = load ptr, ptr %l355, !tbaa !29
  %t711 = load i32, ptr %l358, !tbaa !23
  %t712 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t710, i32 %t711)
  store i32 %t712, ptr %l359
  br label %bb165
bb165:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t715 = getelementptr %"compiler/check:Checker", ptr %t713, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !29
  %t718 = getelementptr %"compiler/generic:Program", ptr %t716, i32 0, i32 2
  store ptr %t718, ptr %l362, !tbaa !29
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load i32, ptr %l15, !tbaa !23
  %t723 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t719, i32 %t720)
  store i32 %t723, ptr %l365
  br label %bb166
bb166:
  %t724 = load ptr, ptr %l362, !tbaa !29
  %t725 = load i32, ptr %l365, !tbaa !23
  %t726 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t724, i32 %t725)
  store i32 %t726, ptr %l366
  br label %bb167
bb167:
  %t727 = load ptr, ptr %l352, !tbaa !29
  %t728 = load i32, ptr %l359, !tbaa !23
  %t729 = load i32, ptr %l366, !tbaa !23
  %t730 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaidAlike(ptr %v0, ptr %t727, i32 %t728, i32 %t729)
  store i1 %t730, ptr %l367
  br label %bb168
bb168:
  %t731 = load i1, ptr %l367, !tbaa !21
  store i1 %t731, ptr %l351, !tbaa !21
  br label %bb169
bb169:
  %t732 = load i1, ptr %l351, !tbaa !21
  br i1 %t732, label %bb170, label %bb171
bb170:
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t734 = load ptr, ptr %l19, !tbaa !29
  %t737 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v2, ptr %t733, ptr %t734)
  store i1 %t737, ptr %l370
  br label %bb172
bb171:
  br label %bb180
bb172:
  %t738 = load i1, ptr %l370, !tbaa !21
  br i1 %t738, label %bb173, label %bb174
bb173:
  %t739 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t739, ptr %l371, !tbaa !24
  br label %bb175
bb174:
  %t741 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t741, ptr %l371, !tbaa !24
  br label %bb175
bb175:
  %t743 = load i64, ptr %l371, !tbaa !24
  store i64 %t743, ptr %l20, !tbaa !24
  %t744 = load ptr, ptr %l0, !tbaa !29
  store ptr %t744, ptr %l374, !tbaa !29
  %t745 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t745, ptr %l375
  %t746 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t746, ptr %l376
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/check:Checker", ptr %t747, i32 0, i32 1
  %t750 = load ptr, ptr %t749, !tbaa !29
  %t752 = getelementptr %"compiler/generic:Program", ptr %t750, i32 0, i32 2
  %t753 = load i32, ptr %l17, !tbaa !23
  %t754 = load i64, ptr %l20, !tbaa !24
  %t758 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t752, i32 %t753, i64 %t754)
  store i32 %t758, ptr %l382
  br label %bb176
bb176:
  %t759 = load ptr, ptr %l19, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t760
  %t761 = getelementptr { i64, [5 x i64] }, ptr %t760, i32 0, i32 0
  store i64 3, ptr %t761
  %t762 = load %"compiler/source:Span", ptr %l376
  %t763 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t762, 0
  %t764 = load i32, ptr %l382, !tbaa !23
  %t765 = insertvalue { %"compiler/source:Span", i32, ptr } %t763, i32 %t764, 1
  %t767 = insertvalue { %"compiler/source:Span", i32, ptr } %t765, ptr %t759, 2
  %t768 = getelementptr { i64, [5 x i64] }, ptr %t760, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t767, ptr %t768
  %t769 = load { i64, [5 x i64] }, ptr %t760
  %t771 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t769, ptr %t771
  store ptr %t771, ptr %l385, !tbaa !29
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t774 = getelementptr %"compiler/check:Checker", ptr %t772, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !29
  %t777 = getelementptr %"compiler/generic:Program", ptr %t775, i32 0, i32 2
  %t778 = load i32, ptr %l3, !tbaa !23
  %t779 = load i64, ptr %l20, !tbaa !24
  %t783 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t777, i32 %t778, i64 %t779)
  store i32 %t783, ptr %l391
  br label %bb177
bb177:
  %t784 = load ptr, ptr %l374, !tbaa !29
  %t785 = load %"compiler/source:Span", ptr %l375
  %t786 = load ptr, ptr %l385, !tbaa !29
  %t787 = load i32, ptr %l391, !tbaa !23
  %t788 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v2, ptr %t784, %"compiler/source:Span" %t785, ptr %t786, i32 %t787)
  store ptr %t788, ptr %l392
  br label %bb178
bb178:
  %t789 = load ptr, ptr %l392, !tbaa !29
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t791 = load %"compiler/source:Span", ptr %l1
  %t792 = load %"compiler/source:Span", ptr %l1
  %t793 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t795
  %t796 = getelementptr { i64, [4 x i64] }, ptr %t795, i32 0, i32 0
  store i64 2, ptr %t796
  %t798 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t792, 0
  %t800 = insertvalue { %"compiler/source:Span", i32, ptr } %t798, i32 %t793, 1
  %t802 = insertvalue { %"compiler/source:Span", i32, ptr } %t800, ptr %t789, 2
  %t803 = getelementptr { i64, [4 x i64] }, ptr %t795, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t802, ptr %t803
  %t804 = load { i64, [4 x i64] }, ptr %t795
  %t806 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t804, ptr %t806
  %t810 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t790, %"compiler/source:Span" %t791, ptr %t806)
  store ptr %t810, ptr %l400
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s9)
  %t811 = load ptr, ptr %l400, !tbaa !29
  store ptr %t811, ptr %rv
  br label %ret
bb180:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load i32, ptr %l17, !tbaa !23
  %t814 = load i32, ptr %l15, !tbaa !23
  %t818 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t812, i32 %t813, i32 %t814)
  store i1 %t818, ptr %l404
  br label %bb181
bb181:
  %t819 = load i1, ptr %l404, !tbaa !21
  %t820 = xor i1 %t819, true
  br i1 %t820, label %bb182, label %bb183
bb182:
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t823 = load %"compiler/source:Span", ptr %l1
  %t824 = load ptr, ptr %l16, !tbaa !29
  %t825 = load i32, ptr %l3, !tbaa !23
  %t830 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t822, %"compiler/source:Span" %t823, ptr %t824, i32 %t825)
  store ptr %t830, ptr %l410
  br label %bb184
bb183:
  br label %bb185
bb184:
  call void @__olang_scope_close(ptr %s9)
  %t831 = load ptr, ptr %l410, !tbaa !29
  store ptr %t831, ptr %rv
  br label %ret
bb185:
  %t832 = load ptr, ptr %l0, !tbaa !29
  store ptr %t832, ptr %l411, !tbaa !29
  %t833 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t833, ptr %l412
  %t834 = load ptr, ptr %l0, !tbaa !29
  store ptr %t834, ptr %l413, !tbaa !29
  %t835 = load ptr, ptr %l16, !tbaa !29
  store ptr %t835, ptr %l414, !tbaa !29
  %t836 = load i32, ptr %l15, !tbaa !23
  store i32 %t836, ptr %l415, !tbaa !23
  %t837 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t837, ptr %l416, !tbaa !27
  %t838 = getelementptr { i64, ptr }, ptr %l416, i32 0, i32 1
  %t839 = load ptr, ptr %t838, !tbaa !27
  %t840 = getelementptr ptr, ptr %t839, i64 0
  %t841 = load ptr, ptr %t840, !tbaa !39
  %t843 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t841)
  store %"compiler/source:Span" %t843, ptr %l418
  br label %bb186
bb186:
  %t844 = load ptr, ptr %l413, !tbaa !29
  %t845 = load ptr, ptr %l414, !tbaa !29
  %t846 = load i32, ptr %l415, !tbaa !23
  %t847 = load %"compiler/source:Span", ptr %l418
  %t848 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t844, ptr %t845, i32 %t846, %"compiler/source:Span" %t847)
  store ptr %t848, ptr %l419
  br label %bb187
bb187:
  %t849 = load i32, ptr %l3, !tbaa !23
  %t850 = load ptr, ptr %l411, !tbaa !29
  %t851 = load %"compiler/source:Span", ptr %l412
  %t852 = load ptr, ptr %l419, !tbaa !29
  %t854 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v2, ptr %t850, %"compiler/source:Span" %t851, ptr %t852, i32 %t849)
  store ptr %t854, ptr %l421
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s9)
  %t855 = load ptr, ptr %l421, !tbaa !29
  store ptr %t855, ptr %rv
  br label %ret
bb189:
  %t856 = load ptr, ptr %l0, !tbaa !29
  store ptr %t856, ptr %l422, !tbaa !29
  %t857 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t857, ptr %l423, !tbaa !27
  %t858 = getelementptr { i64, ptr }, ptr %l423, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !27
  %t860 = getelementptr ptr, ptr %t859, i64 0
  %t861 = load ptr, ptr %t860, !tbaa !39
  %t863 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t861)
  store %"compiler/source:Span" %t863, ptr %l425
  br label %bb190
bb190:
  %t864 = load ptr, ptr %l0, !tbaa !29
  %t865 = load i32, ptr %l15, !tbaa !23
  %t868 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t864, i32 %t865)
  store { i64, ptr } %t868, ptr %l428
  br label %bb191
bb191:
  %t869 = load { i64, ptr }, ptr %l428, !tbaa !27
  %t870 = extractvalue { i64, ptr } %t869, 0
  %t871 = extractvalue { i64, ptr } %t869, 1
  %t872 = mul i64 %t870, 1
  %t873 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t872)
  call void @llvm.memcpy.p0.p0.i64(ptr %t873, ptr %t871, i64 %t872, i1 false)
  %t874 = insertvalue { i64, ptr } undef, i64 %t870, 0
  %t875 = insertvalue { i64, ptr } %t874, ptr %t873, 1
  store { i64, ptr } %t875, ptr %l429, !tbaa !27
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load i32, ptr %l17, !tbaa !23
  %t880 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t876, i32 %t877)
  store { i64, ptr } %t880, ptr %l432
  br label %bb192
bb192:
  %t881 = load { i64, ptr }, ptr %l432, !tbaa !27
  %t882 = extractvalue { i64, ptr } %t881, 0
  %t883 = extractvalue { i64, ptr } %t881, 1
  %t884 = mul i64 %t882, 1
  %t885 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t884)
  call void @llvm.memcpy.p0.p0.i64(ptr %t885, ptr %t883, i64 %t884, i1 false)
  %t886 = insertvalue { i64, ptr } undef, i64 %t882, 0
  %t887 = insertvalue { i64, ptr } %t886, ptr %t885, 1
  %t888 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t890 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s9, ptr %s9, ptr %v0, { i64, ptr } %t888, { i64, ptr } %t887)
  store %"compiler/diagmsg:Msg" %t890, ptr %l434
  br label %bb193
bb193:
  %t891 = load ptr, ptr %l422, !tbaa !29
  %t892 = load %"compiler/source:Span", ptr %l425
  %t893 = load %"compiler/diagmsg:Msg", ptr %l434
  %t894 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t891, %"compiler/source:Span" %t892, %"compiler/diagmsg:Msg" %t893)
  store i64 %t894, ptr %l435
  br label %bb194
bb194:
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t896 = load %"compiler/source:Span", ptr %l1
  %t899 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t895, %"compiler/source:Span" %t896)
  store ptr %t899, ptr %l438
  br label %bb195
bb195:
  call void @__olang_scope_close(ptr %s9)
  %t900 = load ptr, ptr %l438, !tbaa !29
  store ptr %t900, ptr %rv
  br label %ret
bb196:
  %t901 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t903 = trunc i64 1 to i32
  %t904 = icmp eq i32 %t901, %t903
  br i1 %t904, label %bb197, label %bb198
bb197:
  store %olang.scope zeroinitializer, ptr %s20
  %t906 = load ptr, ptr %l0, !tbaa !29
  store ptr %t906, ptr %l441, !tbaa !29
  %t907 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t907, ptr %l442
  %t908 = load ptr, ptr %l0, !tbaa !29
  %t909 = load %"compiler/source:Span", ptr %l2
  %t912 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t908, %"compiler/source:Span" %t909)
  store { i64, ptr } %t912, ptr %l445
  br label %bb199
bb198:
  br label %bb205
bb199:
  %t913 = load { i64, ptr }, ptr %l445, !tbaa !27
  %t914 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s20, { i64, ptr } %t913)
  store { i64, ptr } %t914, ptr %l446
  br label %bb200
bb200:
  %t915 = load { i64, ptr }, ptr %l446, !tbaa !27
  %t916 = extractvalue { i64, ptr } %t915, 0
  %t917 = extractvalue { i64, ptr } %t915, 1
  %t918 = mul i64 %t916, 1
  %t919 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t918)
  call void @llvm.memcpy.p0.p0.i64(ptr %t919, ptr %t917, i64 %t918, i1 false)
  %t920 = insertvalue { i64, ptr } undef, i64 %t916, 0
  %t921 = insertvalue { i64, ptr } %t920, ptr %t919, 1
  %t923 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeHasNoConstructor(ptr %s20, ptr %v0, { i64, ptr } %t921)
  store %"compiler/diagmsg:Msg" %t923, ptr %l448
  br label %bb201
bb201:
  %t924 = load ptr, ptr %l441, !tbaa !29
  %t925 = load %"compiler/source:Span", ptr %l442
  %t926 = load %"compiler/diagmsg:Msg", ptr %l448
  %t927 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t924, %"compiler/source:Span" %t925, %"compiler/diagmsg:Msg" %t926)
  store i64 %t927, ptr %l449
  br label %bb202
bb202:
  %t928 = load ptr, ptr %l0, !tbaa !29
  %t929 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t928, { i64, ptr } %t929)
  br label %bb203
bb203:
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t933 = load %"compiler/source:Span", ptr %l1
  %t936 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t932, %"compiler/source:Span" %t933)
  store ptr %t936, ptr %l454
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s20)
  %t937 = load ptr, ptr %l454, !tbaa !29
  store ptr %t937, ptr %rv
  br label %ret
bb205:
  %t938 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t940 = trunc i64 2 to i32
  %t941 = icmp eq i32 %t938, %t940
  br i1 %t941, label %bb206, label %bb207
bb206:
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t945 = getelementptr %"compiler/check:Checker", ptr %t943, i32 0, i32 1
  %t946 = load ptr, ptr %t945, !tbaa !29
  store ptr %t946, ptr %l459, !tbaa !29
  %t947 = load ptr, ptr %l0, !tbaa !29
  %t949 = getelementptr %"compiler/check:Checker", ptr %t947, i32 0, i32 1
  %t950 = load ptr, ptr %t949, !tbaa !29
  %t952 = getelementptr %"compiler/generic:Program", ptr %t950, i32 0, i32 2
  %t953 = load i32, ptr %l3, !tbaa !23
  %t956 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t952, i32 %t953)
  store i32 %t956, ptr %l464
  br label %bb208
bb207:
  store i1 false, ptr %l457, !tbaa !21
  br label %bb210
bb208:
  %t957 = load ptr, ptr %l459, !tbaa !29
  %t958 = load i32, ptr %l464, !tbaa !23
  %t959 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t957, i32 %t958)
  store i1 %t959, ptr %l465
  br label %bb209
bb209:
  %t960 = load i1, ptr %l465, !tbaa !21
  store i1 %t960, ptr %l457, !tbaa !21
  br label %bb210
bb210:
  %t961 = load i1, ptr %l457, !tbaa !21
  br i1 %t961, label %bb211, label %bb212
bb211:
  %t962 = load ptr, ptr %l0, !tbaa !29
  %t964 = getelementptr %"compiler/check:Checker", ptr %t962, i32 0, i32 1
  %t965 = load ptr, ptr %t964, !tbaa !29
  %t966 = load i32, ptr %l3, !tbaa !23
  %t969 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t965, i32 %t966)
  store i32 %t969, ptr %l469
  br label %bb213
bb212:
  br label %bb225
bb213:
  %t970 = load i32, ptr %l469, !tbaa !23
  store i32 %t970, ptr %l22, !tbaa !23
  %t971 = load i32, ptr %l22, !tbaa !23
  %t972 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t975 = icmp ne i32 %t971, %t972
  br i1 %t975, label %bb214, label %bb215
bb214:
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t978 = load i32, ptr %l3, !tbaa !23
  %t979 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleRaised(ptr %v0, ptr %t977, i32 %t978, i32 %t979)
  br label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb217
bb217:
  %t983 = load ptr, ptr %l0, !tbaa !29
  store ptr %t983, ptr %l476, !tbaa !29
  %t984 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t984, ptr %l477
  %t985 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t985, ptr %l478
  %t986 = load i32, ptr %l3, !tbaa !23
  store i32 %t986, ptr %l479, !tbaa !23
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t989 = getelementptr %"compiler/check:Checker", ptr %t987, i32 0, i32 1
  %t990 = load ptr, ptr %t989, !tbaa !29
  %t992 = getelementptr %"compiler/generic:Program", ptr %t990, i32 0, i32 2
  store ptr %t992, ptr %l482, !tbaa !29
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t995 = getelementptr %"compiler/check:Checker", ptr %t993, i32 0, i32 1
  %t996 = load ptr, ptr %t995, !tbaa !29
  %t998 = getelementptr %"compiler/generic:Program", ptr %t996, i32 0, i32 2
  %t999 = load i32, ptr %l3, !tbaa !23
  %t1002 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t998, i32 %t999)
  store i32 %t1002, ptr %l487
  br label %bb218
bb218:
  %t1003 = load ptr, ptr %l482, !tbaa !29
  %t1004 = load i32, ptr %l487, !tbaa !23
  %t1005 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t1003, i32 %t1004)
  store i32 %t1005, ptr %l488
  br label %bb219
bb219:
  %t1006 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t1006, ptr %l489, !tbaa !27
  %t1007 = icmp sge i64 0, 0
  br i1 %t1007, label %bb220, label %bb221
bb220:
  %t1009 = icmp sle i64 0, 1152921504606846975
  br i1 %t1009, label %bb222, label %bb223
bb221:
  call void @__olang_check_failed(ptr @olang_loc_66d3d1d20fd502cf_cd668d3b10c2a493)
  unreachable
bb222:
  %t1011 = mul i64 0, 8
  %t1012 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1013 = insertvalue { i64, ptr } %t1012, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1014 = load ptr, ptr %l476, !tbaa !29
  %t1015 = load %"compiler/source:Span", ptr %l477
  %t1016 = load %"compiler/source:Span", ptr %l478
  %t1017 = load i32, ptr %l479, !tbaa !23
  %t1018 = load i32, ptr %l488, !tbaa !23
  %t1019 = load { i64, ptr }, ptr %l489, !tbaa !27
  %t1021 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t1014, %"compiler/source:Span" %t1015, %"compiler/source:Span" %t1016, i32 %t1017, i32 %t1018, { i64, ptr } %t1019, { i64, ptr } %t1013)
  store ptr %t1021, ptr %l493
  br label %bb224
bb223:
  call void @__olang_check_failed(ptr @olang_loc_66d3d1d20fd502cf_cd668d3b10c2a493)
  unreachable
bb224:
  %t1022 = load ptr, ptr %l493, !tbaa !29
  store ptr %t1022, ptr %rv
  br label %ret
bb225:
  %t1023 = load ptr, ptr %l0, !tbaa !29
  %t1024 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t1023, %"compiler/source:Span" %t1024, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb226
bb226:
  %t1027 = load ptr, ptr %l0, !tbaa !29
  %t1028 = load %"compiler/source:Span", ptr %l1
  %t1031 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t1027, %"compiler/source:Span" %t1028)
  store ptr %t1031, ptr %l498
  br label %bb227
bb227:
  %t1032 = load ptr, ptr %l498, !tbaa !29
  store ptr %t1032, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectFinish(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/typed:Block"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 45
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t8)
  store ptr %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 59
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t17 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t14)
  store { i64, ptr } %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t19 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t18)
  store %"compiler/typed:Block" %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load %"compiler/typed:Block", ptr %l12
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t20, ptr %t21
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 11
  store ptr %t21, ptr %t24, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t25)
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t29, i64 %a1, i64 2)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorChecked(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l36 = alloca i32
  %l40 = alloca ptr
  %l45 = alloca i64
  %l49 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i32
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i64
  %l69 = alloca %"compiler/generic:Context"
  %l71 = alloca %"compiler/generic:Context"
  %l77 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l84 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca { i64, ptr }
  %l111 = alloca i64
  %l115 = alloca i64
  %l118 = alloca i64
  %l138 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l180 = alloca i32
  %l181 = alloca { i64, ptr }
  %l194 = alloca i64
  %l198 = alloca ptr
  %l200 = alloca ptr
  %l211 = alloca i64
  %l214 = alloca i64
  %l246 = alloca i1
  %l250 = alloca i64
  %l251 = alloca ptr
  %l252 = alloca i1
  %l261 = alloca ptr
  %l266 = alloca i32
  %l267 = alloca { i64, ptr }
  %l271 = alloca i1
  %l277 = alloca i1
  %l283 = alloca i1
  %l290 = alloca i1
  %l293 = alloca ptr
  %l299 = alloca %"compiler/source:Span"
  %l300 = alloca ptr
  %l304 = alloca i32
  %l305 = alloca { i64, ptr }
  %l307 = alloca %"compiler/diagmsg:Msg"
  %l308 = alloca i64
  %l315 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l327 = alloca ptr
  %l331 = alloca { i64, ptr }
  %l333 = alloca ptr
  %l339 = alloca ptr
  %l341 = alloca ptr
  %l346 = alloca ptr
  %l348 = alloca ptr
  %l350 = alloca ptr
  %l353 = alloca i32
  %l354 = alloca ptr
  %l355 = alloca %"compiler/source:Span"
  %l356 = alloca ptr
  %l357 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %t77 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l36
  br label %bb1
bb1:
  %t11 = load i32, ptr %l36, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t15, i32 %t16)
  store ptr %t19, ptr %l40
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l40, !tbaa !29
  store ptr %t20, ptr %l5, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l4, !tbaa !23
  %t30 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t26, i32 %t27)
  store i64 %t30, ptr %l45
  br label %bb3
bb3:
  %t31 = load i64, ptr %l45, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 18
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l49
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l49, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  store i32 %t42, ptr %l7, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l52, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l53, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  store i64 %t46, ptr %l54, !tbaa !24
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t47, ptr %l55, !tbaa !23
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l7, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l60
  br label %bb5
bb5:
  %t58 = load ptr, ptr %l52, !tbaa !29
  %t59 = load i64, ptr %l53, !tbaa !24
  %t60 = load i64, ptr %l54, !tbaa !24
  %t61 = load i32, ptr %l55, !tbaa !23
  %t62 = load i32, ptr %l60, !tbaa !23
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t58, i64 %t59, i64 %t60, i32 %t61, i32 %t62)
  store ptr %t63, ptr %l61
  br label %bb6
bb6:
  %t64 = load ptr, ptr %l61, !tbaa !29
  store ptr %t64, ptr %l8, !tbaa !29
  %t65 = load ptr, ptr %l8, !tbaa !29
  store ptr %t65, ptr %l62, !tbaa !29
  %t66 = ptrtoint ptr %v0 to i64
  store i64 %t66, ptr %l63, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t67, label %bb7, label %bb8
bb7:
  %t69 = call ptr @__olang_region_make(ptr %v0)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l63, !tbaa !24
  br label %bb8
bb8:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = load i64, ptr %l63
  %t79 = inttoptr i64 %t78 to ptr
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %t77, ptr %v0, ptr %t79, ptr %t74, i32 %t75, i32 %a3)
  call void @llvm.memmove.p0.p0.i64(ptr %l69, ptr %t77, i64 160, i1 false)
  br label %bb9
bb9:
  %t83 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t83, label %bb10, label %bb11
bb10:
  %t85 = load i64, ptr %l63
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t88 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t87, i32 0, i32 2
  %t89 = load { i64, ptr }, ptr %t88
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = call ptr @__olang_region_or(ptr %t90, ptr null)
  %t92 = call ptr @__olang_region_home(ptr %t91)
  %t93 = icmp ne ptr %t92, null
  %t94 = select i1 %t93, ptr %t92, ptr null
  %t95 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t96 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t95, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = call ptr @__olang_region_or(ptr %t98, ptr null)
  %t100 = call ptr @__olang_region_home(ptr %t99)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr %t94
  %t103 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = call ptr @__olang_region_or(ptr %t106, ptr null)
  %t108 = call ptr @__olang_region_home(ptr %t107)
  %t109 = icmp ne ptr %t108, null
  %t110 = select i1 %t109, ptr %t108, ptr %t102
  %t111 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t112 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t111, i32 0, i32 2
  %t113 = load { i64, ptr }, ptr %t112
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = call ptr @__olang_region_or(ptr %t114, ptr null)
  %t116 = call ptr @__olang_region_home(ptr %t115)
  %t117 = icmp ne ptr %t116, null
  %t118 = select i1 %t117, ptr %t116, ptr %t110
  %t119 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t120 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t119, i32 0, i32 1
  %t121 = load { i64, ptr }, ptr %t120
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = call ptr @__olang_region_or(ptr %t122, ptr null)
  %t124 = call ptr @__olang_region_home(ptr %t123)
  %t125 = icmp ne ptr %t124, null
  %t126 = select i1 %t125, ptr %t124, ptr %t118
  %t127 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t128 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t127, i32 0, i32 0
  %t129 = load { i64, ptr }, ptr %t128
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = call ptr @__olang_region_or(ptr %t130, ptr null)
  %t132 = call ptr @__olang_region_home(ptr %t131)
  %t133 = icmp ne ptr %t132, null
  %t134 = select i1 %t133, ptr %t132, ptr %t126
  %t135 = icmp eq ptr %t134, %t86
  call void @__olang_region_settle(ptr %t86, i1 %t135)
  br label %bb11
bb11:
  %t136 = load ptr, ptr %l62, !tbaa !29
  %t137 = getelementptr %"compiler/check:frame", ptr %t136, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t137, i64 160, i1 false)
  %t138 = load ptr, ptr %l62, !tbaa !29
  %t139 = getelementptr %"compiler/check:frame", ptr %t138, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %l69, i64 160, i1 false)
  %t140 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t140, label %bb12, label %bb13
bb12:
  %t142 = getelementptr %"compiler/generic:Context", ptr %l71, i32 0, i32 3
  %t143 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t142, i32 0, i32 2
  %t144 = load { i64, ptr }, ptr %t143
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = call ptr @__olang_region_or(ptr %t145, ptr null)
  %t147 = call ptr @__olang_region_home(ptr %t146)
  %t148 = icmp ne ptr %t147, null
  %t149 = select i1 %t148, ptr %t147, ptr null
  %t150 = getelementptr %"compiler/generic:Context", ptr %l71, i32 0, i32 3
  %t151 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t150, i32 0, i32 1
  %t152 = load { i64, ptr }, ptr %t151
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = call ptr @__olang_region_or(ptr %t153, ptr null)
  %t155 = call ptr @__olang_region_home(ptr %t154)
  %t156 = icmp ne ptr %t155, null
  %t157 = select i1 %t156, ptr %t155, ptr %t149
  %t158 = getelementptr %"compiler/generic:Context", ptr %l71, i32 0, i32 3
  %t159 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t158, i32 0, i32 0
  %t160 = load { i64, ptr }, ptr %t159
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = call ptr @__olang_region_or(ptr %t161, ptr null)
  %t163 = call ptr @__olang_region_home(ptr %t162)
  %t164 = icmp ne ptr %t163, null
  %t165 = select i1 %t164, ptr %t163, ptr %t157
  %t166 = getelementptr %"compiler/generic:Context", ptr %l71, i32 0, i32 2
  %t167 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t166, i32 0, i32 2
  %t168 = load { i64, ptr }, ptr %t167
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = call ptr @__olang_region_or(ptr %t169, ptr null)
  %t171 = call ptr @__olang_region_home(ptr %t170)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr %t165
  %t174 = getelementptr %"compiler/generic:Context", ptr %l71, i32 0, i32 2
  %t175 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t174, i32 0, i32 1
  %t176 = load { i64, ptr }, ptr %t175
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = call ptr @__olang_region_or(ptr %t177, ptr null)
  %t179 = call ptr @__olang_region_home(ptr %t178)
  %t180 = icmp ne ptr %t179, null
  %t181 = select i1 %t180, ptr %t179, ptr %t173
  %t182 = getelementptr %"compiler/generic:Context", ptr %l71, i32 0, i32 2
  %t183 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t182, i32 0, i32 0
  %t184 = load { i64, ptr }, ptr %t183
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = call ptr @__olang_region_or(ptr %t185, ptr null)
  %t187 = call ptr @__olang_region_home(ptr %t186)
  %t188 = icmp ne ptr %t187, null
  %t189 = select i1 %t188, ptr %t187, ptr %t181
  call void @__olang_region_drop(ptr %t189)
  store %"compiler/generic:Context" zeroinitializer, ptr %l71
  br label %bb13
bb13:
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 13
  store i1 true, ptr %t192, !tbaa !21
  %t193 = load ptr, ptr %l8, !tbaa !29
  %t194 = load i32, ptr %l2, !tbaa !23
  %t197 = getelementptr %"compiler/check:frame", ptr %t193, i32 0, i32 14
  store i32 %t194, ptr %t197, !tbaa !23
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t198)
  store ptr %t200, ptr %l77
  br label %bb14
bb14:
  store i32 0, ptr %l78
  %t201 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t201, ptr %l79
  br label %bb15
bb15:
  %t202 = load ptr, ptr %l77, !tbaa !29
  %t203 = load i32, ptr %l78, !range !{i32 0, i32 10}
  %t204 = load %"compiler/source:Span", ptr %l79
  %t205 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t202, i32 -1, i32 %t203, %"compiler/source:Span" %t204)
  store i32 %t205, ptr %l80
  br label %bb16
bb16:
  %t206 = load ptr, ptr %l5, !tbaa !29
  %t208 = icmp eq ptr %t206, null
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb17, label %bb18
bb17:
  %t212 = load ptr, ptr %l5, !tbaa !29
  %t214 = getelementptr %"compiler/ast:TypeDecl", ptr %t212, i32 0, i32 3
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  %t219 = xor i1 %t217, true
  store i1 %t219, ptr %l84, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb19
bb19:
  %t221 = load i1, ptr %l84, !tbaa !21
  br i1 %t221, label %bb20, label %bb21
bb20:
  %t222 = load ptr, ptr %l5, !tbaa !29
  %t224 = getelementptr %"compiler/ast:TypeDecl", ptr %t222, i32 0, i32 3
  %t225 = load ptr, ptr %t224, !tbaa !29
  store ptr %t225, ptr %l9, !tbaa !29
  %t227 = load ptr, ptr %l9, !tbaa !29
  store ptr %t227, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t228 = load ptr, ptr %l91, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb22, label %bb23
bb21:
  br label %bb138
bb22:
  %t231 = load ptr, ptr %l91, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 5}
  %t234 = icmp eq i64 %t232, 0
  store i1 %t234, ptr %l92, !tbaa !21
  br label %bb23
bb23:
  %t235 = load i1, ptr %l92, !tbaa !21
  br i1 %t235, label %bb24, label %bb25
bb24:
  %t236 = load ptr, ptr %l9, !tbaa !29
  %t238 = getelementptr { i64, [6 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { ptr }, ptr %t238, i32 0, i32 0
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l10, !tbaa !29
  br label %bb26
bb25:
  br label %bb81
bb26:
  store %olang.scope zeroinitializer, ptr %s2
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/check:Checker", ptr %t242, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/generic:Program", ptr %t245, i32 0, i32 2
  store ptr %t247, ptr %l99, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = getelementptr %"compiler/generic:Program", ptr %t251, i32 0, i32 2
  %t254 = load i32, ptr %l7, !tbaa !23
  %t257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t253, i32 %t254)
  store i32 %t257, ptr %l104
  br label %bb27
bb27:
  %t258 = load ptr, ptr %l99, !tbaa !29
  %t259 = load i32, ptr %l104, !tbaa !23
  %t260 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t258, i32 %t259)
  store { i64, ptr } %t260, ptr %l105
  br label %bb28
bb28:
  %t261 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t261, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t262 = load ptr, ptr %l10, !tbaa !29
  %t264 = getelementptr %"compiler/ast:StructBody", ptr %t262, i32 0, i32 0
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t273 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t267, i64 %t270)
  store i64 %t273, ptr %l111
  br label %bb29
bb29:
  %t274 = load i64, ptr %l111, !tbaa !24
  store i64 %t274, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t275 = load i64, ptr %l13, !tbaa !24
  %t276 = load i64, ptr %l12, !tbaa !24
  %t279 = icmp sgt i64 %t275, %t276
  br i1 %t279, label %bb30, label %bb31
bb30:
  %t281 = load i64, ptr %l14, !tbaa !24
  %t283 = icmp sgt i64 %t281, 0
  br i1 %t283, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb35
bb32:
  %t285 = load i64, ptr %l13, !tbaa !24
  %t286 = load i64, ptr %l12, !tbaa !24
  %t289 = sub i64 %t285, %t286
  %t290 = load i64, ptr %l14, !tbaa !24
  %t293 = add i64 %t289, %t290
  %t295 = sub i64 %t293, 1
  %t296 = load i64, ptr %l14, !tbaa !24
  %t299 = sdiv i64 %t295, %t296
  store i64 %t299, ptr %l118, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb34
bb34:
  %t301 = load i64, ptr %l118, !tbaa !24
  store i64 %t301, ptr %l115, !tbaa !24
  br label %bb35
bb35:
  %t302 = load i64, ptr %l115, !tbaa !24
  store i64 %t302, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  %t303 = load i64, ptr %l16, !tbaa !24
  %t304 = load i64, ptr %l15, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  br label %bb39
bb39:
  %t311 = load i64, ptr %l12, !tbaa !24
  %t312 = load i64, ptr %l16, !tbaa !24
  %t313 = load i64, ptr %l14, !tbaa !24
  %t316 = mul i64 %t312, %t313
  %t319 = add i64 %t311, %t316
  store i64 %t319, ptr %l17, !tbaa !24
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l10, !tbaa !29
  %t324 = getelementptr %"compiler/ast:StructBody", ptr %t322, i32 0, i32 0
  %t325 = load { i64, ptr }, ptr %t324, !tbaa !27
  store { i64, ptr } %t325, ptr %l138, !tbaa !27
  %t326 = load i64, ptr %l17, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr ptr, ptr %t329, i64 %t326
  %t331 = load ptr, ptr %t330, !tbaa !39
  %t333 = getelementptr %"compiler/ast:Param", ptr %t331, i32 0, i32 1
  %t334 = load i32, ptr %t333, !tbaa !23
  %t335 = load ptr, ptr %l10, !tbaa !29
  %t337 = getelementptr %"compiler/ast:StructBody", ptr %t335, i32 0, i32 0
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l143, !tbaa !27
  %t339 = load i64, ptr %l17, !tbaa !24
  %t341 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr ptr, ptr %t342, i64 %t339
  %t344 = load ptr, ptr %t343, !tbaa !39
  %t346 = getelementptr %"compiler/ast:Param", ptr %t344, i32 0, i32 0
  %t347 = load %"compiler/source:Span", ptr %t346
  %t348 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t348, ptr %l147, !tbaa !27
  %t349 = load i64, ptr %l17, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr i32, ptr %t352, i64 %t349
  %t354 = load i32, ptr %t353, !tbaa !33
  %t355 = load i64, ptr %l17, !tbaa !24
  %t356 = load ptr, ptr %l10, !tbaa !29
  %t358 = getelementptr %"compiler/ast:StructBody", ptr %t356, i32 0, i32 0
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  store { i64, ptr } %t359, ptr %l152, !tbaa !27
  %t360 = load i64, ptr %l17, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr ptr, ptr %t363, i64 %t360
  %t365 = load ptr, ptr %t364, !tbaa !39
  %t367 = getelementptr %"compiler/ast:Param", ptr %t365, i32 0, i32 2
  %t368 = load ptr, ptr %t367, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v0, ptr %t321, i32 %t334, %"compiler/source:Span" %t347, i32 %t354, i64 %t355, ptr %t368)
  br label %bb40
bb40:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l10, !tbaa !29
  %t378 = getelementptr %"compiler/ast:StructBody", ptr %t376, i32 0, i32 0
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  store { i64, ptr } %t379, ptr %l158, !tbaa !27
  %t380 = load i64, ptr %l17, !tbaa !24
  %t382 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr ptr, ptr %t383, i64 %t380
  %t385 = load ptr, ptr %t384, !tbaa !39
  %t386 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t386, ptr %l161, !tbaa !27
  %t387 = load i64, ptr %l17, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr i32, ptr %t390, i64 %t387
  %t392 = load i32, ptr %t391, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v0, ptr %t375, ptr %t385, i32 %t392)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t396 = load i64, ptr %l16, !tbaa !24
  %t398 = add i64 %t396, 1
  store i64 %t398, ptr %l16, !tbaa !24
  br label %bb36
bb43:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t400)
  store ptr %t402, ptr %l167
  br label %bb44
bb44:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t407 = load i32, ptr %l7, !tbaa !23
  %t410 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s2, ptr %t406, i32 %t407)
  store { i64, ptr } %t410, ptr %l171
  br label %bb45
bb45:
  %t411 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t411, 0
  %t413 = extractvalue { i64, ptr } %t411, 1
  %t414 = mul i64 %t412, 8
  %t415 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t414)
  call void @llvm.memcpy.p0.p0.i64(ptr %t415, ptr %t413, i64 %t414, i1 false)
  %t416 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t415, 1
  %t418 = load ptr, ptr %l167, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s2, ptr %t418, { i64, ptr } %t417)
  br label %bb46
bb46:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/check:Checker", ptr %t420, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = getelementptr %"compiler/generic:Program", ptr %t423, i32 0, i32 2
  store ptr %t425, ptr %l175, !tbaa !29
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t431 = getelementptr %"compiler/generic:Program", ptr %t429, i32 0, i32 2
  %t432 = load i32, ptr %l2, !tbaa !23
  %t435 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t431, i32 %t432)
  store i32 %t435, ptr %l180
  br label %bb47
bb47:
  %t436 = load ptr, ptr %l175, !tbaa !29
  %t437 = load i32, ptr %l180, !tbaa !23
  %t438 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t436, i32 %t437)
  store { i64, ptr } %t438, ptr %l181
  br label %bb48
bb48:
  %t439 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  %t442 = icmp sgt i64 %t440, 0
  br i1 %t442, label %bb49, label %bb50
bb49:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr %l2, !tbaa !23
  %t446 = load i32, ptr %l4, !tbaa !23
  %t447 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstHoldsItself(ptr %v0, ptr %v0, ptr %t444, i32 %t445, i32 %t446, ptr %t447)
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstImmutUnique(ptr %v0, ptr %t452, i32 %t453)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i32, ptr %l2, !tbaa !23
  %t458 = load ptr, ptr %l5, !tbaa !29
  %t463 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeContexts(ptr %v0, ptr %v0, ptr %t456, i32 %t457, ptr %t458)
  store i64 %t463, ptr %l194
  br label %bb54
bb54:
  %t464 = load i64, ptr %l194, !tbaa !24
  store i64 %t464, ptr %l18, !tbaa !24
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load ptr, ptr %l10, !tbaa !29
  %t468 = getelementptr %"compiler/ast:StructBody", ptr %t466, i32 0, i32 2
  %t469 = load { i64, ptr }, ptr %t468, !tbaa !27
  %t472 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v0, ptr %v0, ptr %t465, { i64, ptr } %t469)
  store ptr %t472, ptr %l198
  br label %bb55
bb55:
  %t473 = load ptr, ptr %l198, !tbaa !29
  store ptr %t473, ptr %l19, !tbaa !29
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t474)
  store ptr %t476, ptr %l200
  br label %bb56
bb56:
  %t477 = load ptr, ptr %l200, !tbaa !29
  %t478 = load ptr, ptr %l19, !tbaa !29
  %t482 = getelementptr %"compiler/typed:Body", ptr %t477, i32 0, i32 11
  store ptr %t478, ptr %t482, !tbaa !29
  %t483 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewBody(ptr %v0, ptr %t483)
  br label %bb57
bb57:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypes(ptr %v0, ptr %t485, i32 %t486)
  br label %bb58
bb58:
  store i64 0, ptr %l20, !tbaa !24
  %t489 = load i64, ptr %l18, !tbaa !24
  store i64 %t489, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t491 = load i64, ptr %l21, !tbaa !24
  %t492 = load i64, ptr %l20, !tbaa !24
  %t495 = icmp sgt i64 %t491, %t492
  br i1 %t495, label %bb59, label %bb60
bb59:
  %t497 = load i64, ptr %l22, !tbaa !24
  %t499 = icmp sgt i64 %t497, 0
  br i1 %t499, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb64
bb61:
  %t501 = load i64, ptr %l21, !tbaa !24
  %t502 = load i64, ptr %l20, !tbaa !24
  %t505 = sub i64 %t501, %t502
  %t506 = load i64, ptr %l22, !tbaa !24
  %t509 = add i64 %t505, %t506
  %t511 = sub i64 %t509, 1
  %t512 = load i64, ptr %l22, !tbaa !24
  %t515 = sdiv i64 %t511, %t512
  store i64 %t515, ptr %l214, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l214, !tbaa !24
  br label %bb63
bb63:
  %t517 = load i64, ptr %l214, !tbaa !24
  store i64 %t517, ptr %l211, !tbaa !24
  br label %bb64
bb64:
  %t518 = load i64, ptr %l211, !tbaa !24
  store i64 %t518, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb65
bb65:
  %t519 = load i64, ptr %l24, !tbaa !24
  %t520 = load i64, ptr %l23, !tbaa !24
  %t523 = icmp slt i64 %t519, %t520
  %t525 = xor i1 %t523, true
  br i1 %t525, label %bb66, label %bb67
bb66:
  br label %bb71
bb67:
  br label %bb68
bb68:
  %t527 = load i64, ptr %l20, !tbaa !24
  %t528 = load i64, ptr %l24, !tbaa !24
  %t529 = load i64, ptr %l22, !tbaa !24
  %t532 = mul i64 %t528, %t529
  %t535 = add i64 %t527, %t532
  store i64 %t535, ptr %l25, !tbaa !24
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/check:Checker", ptr %t537, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !29
  %t542 = getelementptr %"compiler/generic:Program", ptr %t540, i32 0, i32 0
  %t543 = load ptr, ptr %t542, !tbaa !29
  %t545 = getelementptr %"compiler/load:Loader", ptr %t543, i32 0, i32 4
  %t546 = load ptr, ptr %t545, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t546)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t548 = load i64, ptr %l24, !tbaa !24
  %t550 = add i64 %t548, 1
  store i64 %t550, ptr %l24, !tbaa !24
  br label %bb65
bb71:
  %t552 = load ptr, ptr %l10, !tbaa !29
  %t554 = getelementptr %"compiler/ast:StructBody", ptr %t552, i32 0, i32 3
  %t555 = getelementptr %"compiler/source:Span", ptr %t554, i32 0, i32 1
  %t556 = load i32, ptr %t555, !tbaa !23
  %t558 = icmp sgt i32 %t556, 0
  br i1 %t558, label %bb72, label %bb73
bb72:
  %t560 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t560)
  br label %bb74
bb73:
  br label %bb80
bb74:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/check:Checker", ptr %t562, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !29
  %t567 = getelementptr %"compiler/generic:Program", ptr %t565, i32 0, i32 2
  %t568 = load i32, ptr %l2, !tbaa !23
  %t571 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t567, i32 %t568)
  store i1 %t571, ptr %l246
  br label %bb75
bb75:
  %t572 = load i1, ptr %l246, !tbaa !21
  br i1 %t572, label %bb76, label %bb77
bb76:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load i32, ptr %l2, !tbaa !23
  %t575 = load i64, ptr %l6, !tbaa !24
  %t579 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edtorBody(ptr %v0, ptr %t573, i32 %t574, i64 %t575)
  store i64 %t579, ptr %l250
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb80:
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb81:
  %t580 = load ptr, ptr %l9, !tbaa !29
  store ptr %t580, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t581 = load ptr, ptr %l251, !tbaa !29
  %t582 = icmp ne ptr %t581, null
  br i1 %t582, label %bb82, label %bb83
bb82:
  %t584 = load ptr, ptr %l251, !tbaa !29
  %t585 = load i64, ptr %t584, !range !{i64 0, i64 5}
  %t587 = icmp eq i64 %t585, 3
  store i1 %t587, ptr %l252, !tbaa !21
  br label %bb83
bb83:
  %t588 = load i1, ptr %l252, !tbaa !21
  br i1 %t588, label %bb84, label %bb85
bb84:
  %t589 = load ptr, ptr %l9, !tbaa !29
  %t591 = getelementptr { i64, [6 x i64] }, ptr %t589, i32 0, i32 1
  %t592 = getelementptr { ptr, ptr }, ptr %t591, i32 0, i32 0
  %t593 = load ptr, ptr %t592
  store ptr %t593, ptr %l26, !tbaa !29
  %t595 = load ptr, ptr %l9, !tbaa !29
  %t597 = getelementptr { i64, [6 x i64] }, ptr %t595, i32 0, i32 1
  %t598 = getelementptr { ptr, ptr }, ptr %t597, i32 0, i32 1
  %t599 = load ptr, ptr %t598
  store ptr %t599, ptr %l27, !tbaa !29
  br label %bb86
bb85:
  br label %bb130
bb86:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = getelementptr %"compiler/check:Checker", ptr %t601, i32 0, i32 1
  %t604 = load ptr, ptr %t603, !tbaa !29
  %t606 = getelementptr %"compiler/generic:Program", ptr %t604, i32 0, i32 2
  store ptr %t606, ptr %l261, !tbaa !29
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t609 = getelementptr %"compiler/check:Checker", ptr %t607, i32 0, i32 1
  %t610 = load ptr, ptr %t609, !tbaa !29
  %t612 = getelementptr %"compiler/generic:Program", ptr %t610, i32 0, i32 2
  %t613 = load i32, ptr %l7, !tbaa !23
  %t616 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t612, i32 %t613)
  store i32 %t616, ptr %l266
  br label %bb87
bb87:
  %t617 = load ptr, ptr %l261, !tbaa !29
  %t618 = load i32, ptr %l266, !tbaa !23
  %t619 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t617, i32 %t618)
  store { i64, ptr } %t619, ptr %l267
  br label %bb88
bb88:
  %t620 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t620, ptr %l28, !tbaa !27
  %t621 = load ptr, ptr %l27, !tbaa !29
  %t623 = icmp eq ptr %t621, null
  %t625 = xor i1 %t623, true
  br i1 %t625, label %bb89, label %bb90
bb89:
  %t627 = load ptr, ptr %l27, !tbaa !29
  %t629 = getelementptr %"compiler/ast:Func", ptr %t627, i32 0, i32 3
  %t630 = load ptr, ptr %t629, !tbaa !29
  %t632 = getelementptr %"compiler/ast:Sig", ptr %t630, i32 0, i32 0
  %t633 = load { i64, ptr }, ptr %t632, !tbaa !27
  %t635 = extractvalue { i64, ptr } %t633, 0
  %t637 = icmp sgt i64 %t635, 0
  store i1 %t637, ptr %l271, !tbaa !21
  br label %bb91
bb90:
  store i1 false, ptr %l271, !tbaa !21
  br label %bb91
bb91:
  %t639 = load i1, ptr %l271, !tbaa !21
  br i1 %t639, label %bb92, label %bb93
bb92:
  %t640 = load ptr, ptr %l27, !tbaa !29
  %t642 = getelementptr %"compiler/ast:Func", ptr %t640, i32 0, i32 3
  %t643 = load ptr, ptr %t642, !tbaa !29
  %t645 = getelementptr %"compiler/ast:Sig", ptr %t643, i32 0, i32 0
  %t646 = load { i64, ptr }, ptr %t645, !tbaa !27
  %t648 = extractvalue { i64, ptr } %t646, 0
  %t650 = icmp eq i64 %t648, 1
  store i1 %t650, ptr %l277, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb94
bb94:
  %t652 = load i1, ptr %l277, !tbaa !21
  br i1 %t652, label %bb95, label %bb96
bb95:
  %t653 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t655 = extractvalue { i64, ptr } %t653, 0
  %t657 = icmp eq i64 %t655, 1
  store i1 %t657, ptr %l283, !tbaa !21
  br label %bb97
bb96:
  store i1 false, ptr %l283, !tbaa !21
  br label %bb97
bb97:
  %t659 = load i1, ptr %l283, !tbaa !21
  store i1 %t659, ptr %l29, !tbaa !21
  %t660 = load ptr, ptr %l27, !tbaa !29
  %t662 = icmp eq ptr %t660, null
  %t664 = xor i1 %t662, true
  br i1 %t664, label %bb98, label %bb99
bb98:
  %t666 = load i1, ptr %l29, !tbaa !21
  %t668 = xor i1 %t666, true
  store i1 %t668, ptr %l290, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb100
bb100:
  %t670 = load i1, ptr %l290, !tbaa !21
  br i1 %t670, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s13
  %t671 = load ptr, ptr %l0, !tbaa !29
  store ptr %t671, ptr %l293, !tbaa !29
  %t672 = load ptr, ptr %l27, !tbaa !29
  %t674 = getelementptr %"compiler/ast:Func", ptr %t672, i32 0, i32 0
  %t675 = getelementptr %"compiler/source:Span", ptr %t674, i32 0, i32 0
  %t676 = load i32, ptr %t675, !tbaa !23
  %t677 = load ptr, ptr %l27, !tbaa !29
  %t679 = getelementptr %"compiler/ast:Func", ptr %t677, i32 0, i32 0
  %t680 = getelementptr %"compiler/source:Span", ptr %t679, i32 0, i32 0
  %t681 = load i32, ptr %t680, !tbaa !23
  %t683 = add i32 %t681, 1
  %t686 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s13, i32 %t676, i32 %t683)
  store %"compiler/source:Span" %t686, ptr %l299
  br label %bb103
bb102:
  %t687 = load i1, ptr %l29, !tbaa !21
  br i1 %t687, label %bb108, label %bb109
bb103:
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l300, !tbaa !29
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l26, !tbaa !29
  %t695 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v0, ptr %t690, ptr %t691)
  store i32 %t695, ptr %l304
  br label %bb104
bb104:
  %t696 = load ptr, ptr %l300, !tbaa !29
  %t697 = load i32, ptr %l304, !tbaa !23
  %t698 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t696, i32 %t697)
  store { i64, ptr } %t698, ptr %l305
  br label %bb105
bb105:
  %t699 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t699, 0
  %t701 = extractvalue { i64, ptr } %t699, 1
  %t702 = mul i64 %t700, 1
  %t703 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t702)
  call void @llvm.memcpy.p0.p0.i64(ptr %t703, ptr %t701, i64 %t702, i1 false)
  %t704 = insertvalue { i64, ptr } undef, i64 %t700, 0
  %t705 = insertvalue { i64, ptr } %t704, ptr %t703, 1
  %t707 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePrimCtorParam(ptr %s13, ptr %v0, { i64, ptr } %t705)
  store %"compiler/diagmsg:Msg" %t707, ptr %l307
  br label %bb106
bb106:
  %t708 = load ptr, ptr %l293, !tbaa !29
  %t709 = load %"compiler/source:Span", ptr %l299
  %t710 = load %"compiler/diagmsg:Msg", ptr %l307
  %t711 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t708, %"compiler/source:Span" %t709, %"compiler/diagmsg:Msg" %t710)
  store i64 %t711, ptr %l308
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s13)
  br label %bb129
bb108:
  store %olang.scope zeroinitializer, ptr %s15
  %t712 = load ptr, ptr %l27, !tbaa !29
  %t714 = icmp eq ptr %t712, null
  br i1 %t714, label %bb110, label %bb111
bb109:
  store %olang.scope zeroinitializer, ptr %s16
  %t716 = load ptr, ptr %l0, !tbaa !29
  store ptr %t716, ptr %l354, !tbaa !29
  %t717 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s16, i32 0, i32 0)
  store %"compiler/source:Span" %t717, ptr %l355
  br label %bb126
bb110:
  call void @__olang_check_failed(ptr @olang_loc_1a21871eed64942d_5f8df5778525f19)
  unreachable
bb111:
  br label %bb112
bb112:
  %t718 = load ptr, ptr %l27, !tbaa !29
  %t721 = getelementptr %"compiler/ast:Func", ptr %t718, i32 0, i32 3
  %t722 = load ptr, ptr %t721, !tbaa !29
  %t724 = getelementptr %"compiler/ast:Sig", ptr %t722, i32 0, i32 0
  %t725 = load { i64, ptr }, ptr %t724, !tbaa !27
  store { i64, ptr } %t725, ptr %l315, !tbaa !27
  %t726 = getelementptr { i64, ptr }, ptr %l315, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !27
  %t728 = getelementptr ptr, ptr %t727, i64 0
  %t729 = load ptr, ptr %t728, !tbaa !39
  store ptr %t729, ptr %l30, !tbaa !29
  %t731 = load ptr, ptr %l0, !tbaa !29
  %t732 = load ptr, ptr %l30, !tbaa !29
  %t734 = getelementptr %"compiler/ast:Param", ptr %t732, i32 0, i32 1
  %t735 = load i32, ptr %t734, !tbaa !23
  %t736 = load ptr, ptr %l30, !tbaa !29
  %t738 = getelementptr %"compiler/ast:Param", ptr %t736, i32 0, i32 0
  %t739 = load %"compiler/source:Span", ptr %t738
  %t740 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t740, ptr %l322, !tbaa !27
  %t741 = getelementptr { i64, ptr }, ptr %l322, i32 0, i32 1
  %t742 = load ptr, ptr %t741, !tbaa !27
  %t743 = getelementptr i32, ptr %t742, i64 0
  %t744 = load i32, ptr %t743, !tbaa !33
  %t745 = load ptr, ptr %l30, !tbaa !29
  %t747 = getelementptr %"compiler/ast:Param", ptr %t745, i32 0, i32 2
  %t748 = load ptr, ptr %t747, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v0, ptr %t731, i32 %t735, %"compiler/source:Span" %t739, i32 %t744, i64 0, ptr %t748)
  br label %bb113
bb113:
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t756 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t754)
  store ptr %t756, ptr %l327
  br label %bb114
bb114:
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t759 = getelementptr %"compiler/check:Checker", ptr %t757, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !29
  %t761 = load i32, ptr %l7, !tbaa !23
  %t764 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s15, ptr %t760, i32 %t761)
  store { i64, ptr } %t764, ptr %l331
  br label %bb115
bb115:
  %t765 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t766 = extractvalue { i64, ptr } %t765, 0
  %t767 = extractvalue { i64, ptr } %t765, 1
  %t768 = mul i64 %t766, 8
  %t769 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t768)
  call void @llvm.memcpy.p0.p0.i64(ptr %t769, ptr %t767, i64 %t768, i1 false)
  %t770 = insertvalue { i64, ptr } undef, i64 %t766, 0
  %t771 = insertvalue { i64, ptr } %t770, ptr %t769, 1
  %t772 = load ptr, ptr %l327, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s15, ptr %t772, { i64, ptr } %t771)
  br label %bb116
bb116:
  %t774 = load ptr, ptr %l0, !tbaa !29
  store ptr %t774, ptr %l333, !tbaa !29
  %t775 = load ptr, ptr %l27, !tbaa !29
  %t777 = icmp eq ptr %t775, null
  br i1 %t777, label %bb117, label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_c58696bc0c2f7b46_a4aa6b3b7860c7f2)
  unreachable
bb118:
  br label %bb119
bb119:
  %t779 = load ptr, ptr %l27, !tbaa !29
  %t782 = getelementptr %"compiler/ast:Func", ptr %t779, i32 0, i32 4
  %t783 = load { i64, ptr }, ptr %t782, !tbaa !27
  %t784 = load ptr, ptr %l333, !tbaa !29
  %t786 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v0, ptr %v0, ptr %t784, { i64, ptr } %t783)
  store ptr %t786, ptr %l339
  br label %bb120
bb120:
  %t787 = load ptr, ptr %l339, !tbaa !29
  store ptr %t787, ptr %l31, !tbaa !29
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t790 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t788)
  store ptr %t790, ptr %l341
  br label %bb121
bb121:
  %t791 = load ptr, ptr %l341, !tbaa !29
  %t792 = load ptr, ptr %l31, !tbaa !29
  %t796 = getelementptr %"compiler/typed:Body", ptr %t791, i32 0, i32 11
  store ptr %t792, ptr %t796, !tbaa !29
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t797)
  store ptr %t799, ptr %l346
  br label %bb122
bb122:
  %t800 = load ptr, ptr %l346, !tbaa !29
  %t802 = getelementptr %"compiler/typed:Body", ptr %t800, i32 0, i32 10
  store ptr %t802, ptr %l348, !tbaa !29
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t805 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t803)
  store ptr %t805, ptr %l350
  br label %bb123
bb123:
  %t806 = load ptr, ptr %l350, !tbaa !29
  %t808 = getelementptr %"compiler/typed:Body", ptr %t806, i32 0, i32 5
  %t810 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t808, i64 0)
  store i32 %t810, ptr %l353
  br label %bb124
bb124:
  %t811 = load ptr, ptr %l348, !tbaa !29
  %t812 = load i32, ptr %l353, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t811, i32 %t812)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s15)
  br label %bb128
bb126:
  %t813 = load ptr, ptr %l354, !tbaa !29
  %t814 = load %"compiler/source:Span", ptr %l355
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t813, %"compiler/source:Span" %t814, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s16)
  br label %bb128
bb128:
  br label %bb129
bb129:
  br label %bb137
bb130:
  br i1 true, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb136
bb133:
  store %olang.scope zeroinitializer, ptr %s17
  %t815 = load ptr, ptr %l0, !tbaa !29
  store ptr %t815, ptr %l356, !tbaa !29
  %t816 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s17, i32 0, i32 0)
  store %"compiler/source:Span" %t816, ptr %l357
  br label %bb134
bb134:
  %t817 = load ptr, ptr %l356, !tbaa !29
  %t818 = load %"compiler/source:Span", ptr %l357
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t817, %"compiler/source:Span" %t818, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s17)
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_dbcdd42e40c3e4ce_a7e80860aca3d0ca)
  unreachable
bb137:
  br label %bb138
bb138:
  %t819 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t819)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultBinds(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, i1 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l64 = alloca { i64, ptr }
  %l69 = alloca i32
  %l74 = alloca i32
  %l78 = alloca i1
  %l83 = alloca i64
  %l86 = alloca i1
  %l88 = alloca { i64, ptr }
  %l93 = alloca i64
  %l102 = alloca i1
  %l109 = alloca i1
  %l112 = alloca { i64, ptr }
  %l118 = alloca i64
  %l125 = alloca ptr
  %l130 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca i32
  %l137 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store i1 %a6, ptr %l6
  store ptr %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l25
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l25, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load i1, ptr %l6, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Func", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l27, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l27, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l32, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t22 = load i64, ptr %l32, !tbaa !24
  store i64 %t22, ptr %l9, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 4
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l10, !tbaa !29
  store i64 %a5, ptr %l11, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t40 = load i64, ptr %l12, !tbaa !24
  %t41 = load i64, ptr %l11, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load i64, ptr %l13, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb13
bb10:
  %t50 = load i64, ptr %l12, !tbaa !24
  %t51 = load i64, ptr %l11, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l13, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l13, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l46, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l46, !tbaa !24
  store i64 %t66, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l43, !tbaa !24
  store i64 %t67, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l15, !tbaa !24
  %t69 = load i64, ptr %l14, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  br label %bb50
bb16:
  br label %bb17
bb17:
  %t76 = load i64, ptr %l11, !tbaa !24
  %t77 = load i64, ptr %l15, !tbaa !24
  %t78 = load i64, ptr %l13, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l16, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t86, ptr %l64, !tbaa !27
  %t87 = load i64, ptr %l16, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i32, ptr %t90, i64 %t87
  %t92 = load i32, ptr %t91, !tbaa !33
  store i32 %t92, ptr %l17, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l17, !tbaa !23
  %t98 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t94, i32 %t95)
  store i32 %t98, ptr %l69
  br label %bb18
bb18:
  %t99 = load i32, ptr %l69, !tbaa !23
  store i32 %t99, ptr %l18, !tbaa !23
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l18, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l74
  br label %bb19
bb19:
  %t110 = load i32, ptr %l74, !range !{i32 0, i32 33}
  %t112 = trunc i64 25 to i32
  %t113 = icmp eq i32 %t110, %t112
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb23
bb21:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l18, !tbaa !23
  %t126 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t122, i32 %t123)
  store i64 %t126, ptr %l83
  br label %bb22
bb22:
  %t128 = load i64, ptr %l83, !tbaa !24
  %t130 = icmp ne i64 %t128, %a3
  store i1 %t130, ptr %l78, !tbaa !21
  br label %bb23
bb23:
  %t132 = load i1, ptr %l78, !tbaa !21
  br i1 %t132, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb27
bb25:
  %t133 = load ptr, ptr %l7, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Binding", ptr %t133, i32 0, i32 2
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l88, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %l18, !tbaa !23
  %t146 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t142, i32 %t143)
  store i64 %t146, ptr %l93
  br label %bb26
bb26:
  %t147 = load i64, ptr %l93, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i32, ptr %t149, i64 %t147
  %t151 = load i32, ptr %t150, !tbaa !33
  %t152 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t155 = icmp ne i32 %t151, %t152
  store i1 %t155, ptr %l86, !tbaa !21
  br label %bb27
bb27:
  %t157 = load i1, ptr %l86, !tbaa !21
  br i1 %t157, label %bb28, label %bb29
bb28:
  br label %bb49
bb29:
  br label %bb30
bb30:
  %t158 = load i64, ptr %l16, !tbaa !24
  %t159 = load i64, ptr %l9, !tbaa !24
  %t162 = sub i64 %t158, %t159
  store i64 %t162, ptr %l19, !tbaa !24
  %t164 = load i64, ptr %l19, !tbaa !24
  %t166 = icmp slt i64 %t164, 0
  br i1 %t166, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb33
bb32:
  %t168 = load i64, ptr %l19, !tbaa !24
  %t169 = load ptr, ptr %l8, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Func", ptr %t169, i32 0, i32 3
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/ast:Sig", ptr %t172, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t180 = icmp sge i64 %t168, %t177
  store i1 %t180, ptr %l102, !tbaa !21
  br label %bb33
bb33:
  %t182 = load i1, ptr %l102, !tbaa !21
  br i1 %t182, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb36
bb35:
  %t183 = load ptr, ptr %l8, !tbaa !29
  %t185 = getelementptr %"compiler/ast:Func", ptr %t183, i32 0, i32 3
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/ast:Sig", ptr %t186, i32 0, i32 0
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l112, !tbaa !27
  %t190 = load i64, ptr %l19, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr ptr, ptr %t193, i64 %t190
  %t195 = load ptr, ptr %t194, !tbaa !39
  %t197 = getelementptr %"compiler/ast:Param", ptr %t195, i32 0, i32 3
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = icmp eq ptr %t198, null
  store i1 %t200, ptr %l109, !tbaa !21
  br label %bb36
bb36:
  %t202 = load i1, ptr %l109, !tbaa !21
  br i1 %t202, label %bb37, label %bb38
bb37:
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t203 = load ptr, ptr %l10, !tbaa !29
  %t205 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t203)
  store i64 %t205, ptr %l118
  br label %bb40
bb40:
  %t206 = load i64, ptr %l118, !tbaa !24
  store i64 %t206, ptr %l20, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i64, ptr %l2, !tbaa !24
  %t210 = load i64, ptr %l16, !tbaa !24
  %t211 = load i1, ptr %l6, !tbaa !21
  %t212 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t219 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v0, ptr %t207, %"compiler/source:Span" %a1, i64 %t209, i64 %t210, i1 %t211, i32 %t212, i32 0)
  store ptr %t219, ptr %l125
  br label %bb41
bb41:
  %t220 = load ptr, ptr %l125, !tbaa !29
  store ptr %t220, ptr %l21, !tbaa !29
  %t221 = load ptr, ptr %l10, !tbaa !29
  %t222 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t221, i64 %t222)
  br label %bb42
bb42:
  %t225 = load ptr, ptr %l21, !tbaa !29
  %t228 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t225)
  store i32 %t228, ptr %l130
  br label %bb43
bb43:
  %t229 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t230 = load i32, ptr %l130, !tbaa !23
  %t232 = icmp ne i32 %t230, %t229
  br i1 %t232, label %bb44, label %bb45
bb44:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l133, !tbaa !29
  %t235 = load i32, ptr %l17, !tbaa !23
  store i32 %t235, ptr %l134, !tbaa !23
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l21, !tbaa !29
  %t240 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v0, ptr %t236, ptr %t237)
  store i32 %t240, ptr %l137
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t241 = load ptr, ptr %l7, !tbaa !29
  %t242 = load ptr, ptr %l133, !tbaa !29
  %t243 = load i32, ptr %l134, !tbaa !23
  %t244 = load i32, ptr %l137, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v2, ptr %t242, i32 %t243, i32 %t244, ptr %t241, i1 false, i1 false)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t246 = load i64, ptr %l15, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l15, !tbaa !24
  br label %bb14
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb22
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 28}
  %t30 = icmp eq i64 %t28, 5
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 113}
  store i32 %t36, ptr %l6
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l7, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t46, i32 0, i32 3
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l8, !tbaa !29
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t50 = load i32, ptr %l6, !range !{i32 0, i32 113}
  %t52 = trunc i64 78 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l7, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t55, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l35
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l8, !tbaa !29
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t63, ptr %t64, i32 %t66)
  store ptr %t70, ptr %l40
  br label %bb13
bb13:
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t71, ptr %t72, i32 %t74)
  store ptr %t78, ptr %l45
  br label %bb18
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6f8999b7f8ddffc_ce9c2022d5a87cc8)
  unreachable
bb20:
  br label %bb21
bb21:
  %t79 = load i64, ptr %l3, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l3, !tbaa !24
  br label %bb1
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorDeclRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/generic:Context"
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l62 = alloca ptr
  %l70 = alloca ptr
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l86 = alloca i1
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l93 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l102 = alloca i1
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, [3 x i64] }
  %l125 = alloca { i64, ptr }
  %l127 = alloca %"compiler/diagmsg:Msg"
  %l128 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l159 = alloca i64
  %l162 = alloca i64
  %l180 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l189 = alloca i64
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l199 = alloca ptr
  %l200 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i64
  %l204 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l210 = alloca { i64, [3 x i64] }
  %l212 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l217 = alloca %"compiler/diagmsg:Msg"
  %l218 = alloca i64
  %l227 = alloca %"compiler/generic:Context"
  %l235 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca i64
  %l245 = alloca i1
  %l255 = alloca i64
  %l262 = alloca i32
  %l264 = alloca i32
  %l266 = alloca i32
  %l269 = alloca { i64, ptr }
  %l273 = alloca %"compiler/source:Span"
  %l281 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l285 = alloca ptr
  %l286 = alloca i64
  %l292 = alloca i32
  %l294 = alloca i1
  %l298 = alloca ptr
  %l304 = alloca { i64, [3 x i64] }
  %l307 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l313 = alloca %"compiler/diagmsg:Msg"
  %l314 = alloca i64
  %l320 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l328 = alloca { i64, ptr }
  %l331 = alloca ptr
  %l332 = alloca i64
  %l348 = alloca { i64, ptr }
  %l352 = alloca i64
  %l354 = alloca i64
  %l359 = alloca i32
  %l364 = alloca ptr
  %l367 = alloca ptr
  %l372 = alloca i32
  %l373 = alloca i32
  %l374 = alloca { i64, ptr }
  %l379 = alloca i64
  %l385 = alloca i64
  %l388 = alloca i64
  %l406 = alloca { i64, ptr }
  %l411 = alloca i1
  %l414 = alloca i1
  %l416 = alloca i64
  %l420 = alloca { i64, ptr }
  %l422 = alloca i64
  %l425 = alloca { i64, ptr }
  %l426 = alloca i64
  %l430 = alloca ptr
  %l431 = alloca i64
  %l432 = alloca i64
  %l433 = alloca i64
  %l436 = alloca { i64, ptr }
  %l439 = alloca { i64, [3 x i64] }
  %l442 = alloca { i64, ptr }
  %l443 = alloca { i64, ptr }
  %l444 = alloca ptr
  %l449 = alloca i32
  %l450 = alloca { i64, ptr }
  %l452 = alloca %"compiler/diagmsg:Msg"
  %l453 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %t143 = alloca { i64, [3 x i64] }, align 8
  %t337 = alloca { i64, [3 x i64] }, align 8
  %t386 = alloca %"compiler/generic:Context", align 8
  %t555 = alloca { i64, [3 x i64] }, align 8
  %t848 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l62
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l62, !tbaa !29
  %t16 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 4
  %t17 = load i64, ptr %t16, !tbaa !24
  store i64 %t17, ptr %l6, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 10
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l70
  br label %bb2
bb2:
  %t32 = load ptr, ptr %l70, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l7, !tbaa !29
  %t37 = load ptr, ptr %l7, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_da726112f8a5d119_ce42f73d9d53945)
  unreachable
bb4:
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l8, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp eq i64 %t49, 1
  br i1 %t51, label %bb6, label %bb7
bb6:
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t53, ptr %l82, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 0
  %t57 = load i32, ptr %t56, !tbaa !33
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = icmp eq i32 %t57, %t58
  store i1 %t61, ptr %l81, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb8
bb8:
  %t63 = load i1, ptr %l81, !tbaa !21
  br i1 %t63, label %bb9, label %bb10
bb9:
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp eq i64 %t66, 0
  store i1 %t68, ptr %l86, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb11
bb11:
  %t70 = load i1, ptr %l86, !tbaa !21
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t71, ptr %l91, !tbaa !27
  %t72 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  %t75 = sext i32 %t73 to i64
  store i64 %t75, ptr %l93, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t76, 0
  store i64 %t79, ptr %l96, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  store i64 %t81, ptr %l97, !tbaa !24
  %t82 = load i64, ptr %l93, !tbaa !24
  %t83 = icmp sge i64 %t82, 0
  br i1 %t83, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb21
bb14:
  %t85 = load i64, ptr %l93, !tbaa !24
  %t86 = load i64, ptr %l96, !tbaa !24
  %t87 = icmp sle i64 %t85, %t86
  br i1 %t87, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_771f29b9e3f6ab8a_7fc52d4465222796)
  unreachable
bb16:
  %t89 = load i64, ptr %l96, !tbaa !24
  %t90 = load i64, ptr %l97, !tbaa !24
  %t91 = icmp sle i64 %t89, %t90
  br i1 %t91, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_771f29b9e3f6ab8a_7fc52d4465222796)
  unreachable
bb18:
  %t93 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l93, !tbaa !24
  %t96 = load i64, ptr %l96, !tbaa !24
  %t97 = getelementptr i8, ptr %t94, i64 %t95
  %t98 = sub i64 %t96, %t95
  %t99 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t102, ptr %l102
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_771f29b9e3f6ab8a_7fc52d4465222796)
  unreachable
bb20:
  %t103 = load i1, ptr %l102, !tbaa !21
  store i1 %t103, ptr %l90, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l90, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s1
  %t105 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t105, ptr %l103, !tbaa !27
  %t106 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l105, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l3, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t110, i32 %t111)
  store { i64, ptr } %t114, ptr %l108
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t115 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t116 = load i64, ptr %l105, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t118 = call i64 @compiler_2fcheck_2ewordAt(ptr %v0, ptr %v0, { i64, ptr } %t115, i64 %t116, { i64, ptr } %t117, i64 2)
  store i64 %t118, ptr %l109
  br label %bb25
bb25:
  %t119 = load i64, ptr %l109, !tbaa !24
  store i64 %t119, ptr %l9, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/load:Loader", ptr %t126, i32 0, i32 4
  %t129 = load ptr, ptr %t128, !tbaa !29
  store ptr %t129, ptr %l113, !tbaa !29
  %t130 = load i64, ptr %l6, !tbaa !24
  store i64 %t130, ptr %l114, !tbaa !24
  %t131 = load i64, ptr %l9, !tbaa !24
  store i64 %t131, ptr %l115, !tbaa !24
  %t132 = load i64, ptr %l9, !tbaa !24
  store i64 %t132, ptr %l116, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l3, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %t133, i32 %t134)
  store { i64, ptr } %t137, ptr %l119
  br label %bb26
bb26:
  %t138 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  %t140 = load i64, ptr %l116, !tbaa !24
  %t142 = add i64 %t140, %t139
  store { i64, [3 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 0
  store i64 3, ptr %t144
  %t145 = load i64, ptr %l114, !tbaa !24
  %t146 = insertvalue { i64, i64, i64 } undef, i64 %t145, 0
  %t147 = load i64, ptr %l115, !tbaa !24
  %t148 = insertvalue { i64, i64, i64 } %t146, i64 %t147, 1
  %t150 = insertvalue { i64, i64, i64 } %t148, i64 %t142, 2
  %t151 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 1
  store { i64, i64, i64 } %t150, ptr %t151
  %t152 = load { i64, [3 x i64] }, ptr %t143
  store { i64, [3 x i64] } %t152, ptr %l122
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l3, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s1, ptr %t153, i32 %t154)
  store { i64, ptr } %t157, ptr %l125
  br label %bb27
bb27:
  %t158 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t166 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaisedWordOwnName(ptr %s1, ptr %v0, { i64, ptr } %t164)
  store %"compiler/diagmsg:Msg" %t166, ptr %l127
  br label %bb28
bb28:
  %t167 = load ptr, ptr %l113, !tbaa !29
  %t168 = load { i64, [3 x i64] }, ptr %l122
  %t169 = load %"compiler/diagmsg:Msg", ptr %l127
  %t170 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t167, { i64, [3 x i64] } %t168, %"compiler/diagmsg:Msg" %t169)
  store i64 %t170, ptr %l128
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s1)
  br label %bb30
bb30:
  store i64 0, ptr %l10, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load i64, ptr %l10, !tbaa !24
  %t179 = icmp sgt i64 %t175, %t176
  br i1 %t179, label %bb31, label %bb32
bb31:
  %t181 = load i64, ptr %l12, !tbaa !24
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb36
bb33:
  %t185 = load i64, ptr %l11, !tbaa !24
  %t186 = load i64, ptr %l10, !tbaa !24
  %t189 = sub i64 %t185, %t186
  %t190 = load i64, ptr %l12, !tbaa !24
  %t193 = add i64 %t189, %t190
  %t195 = sub i64 %t193, 1
  %t196 = load i64, ptr %l12, !tbaa !24
  %t199 = sdiv i64 %t195, %t196
  store i64 %t199, ptr %l137, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb35
bb35:
  %t201 = load i64, ptr %l137, !tbaa !24
  store i64 %t201, ptr %l134, !tbaa !24
  br label %bb36
bb36:
  %t202 = load i64, ptr %l134, !tbaa !24
  store i64 %t202, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb37
bb37:
  %t203 = load i64, ptr %l14, !tbaa !24
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb38, label %bb39
bb38:
  br label %bb63
bb39:
  br label %bb40
bb40:
  %t211 = load i64, ptr %l10, !tbaa !24
  %t212 = load i64, ptr %l14, !tbaa !24
  %t213 = load i64, ptr %l12, !tbaa !24
  %t216 = mul i64 %t212, %t213
  %t219 = add i64 %t211, %t216
  store i64 %t219, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t221 = load i64, ptr %l15, !tbaa !24
  store i64 %t221, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t223 = load i64, ptr %l17, !tbaa !24
  %t224 = load i64, ptr %l16, !tbaa !24
  %t227 = icmp sgt i64 %t223, %t224
  br i1 %t227, label %bb41, label %bb42
bb41:
  %t229 = load i64, ptr %l18, !tbaa !24
  %t231 = icmp sgt i64 %t229, 0
  br i1 %t231, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l159, !tbaa !24
  br label %bb46
bb43:
  %t233 = load i64, ptr %l17, !tbaa !24
  %t234 = load i64, ptr %l16, !tbaa !24
  %t237 = sub i64 %t233, %t234
  %t238 = load i64, ptr %l18, !tbaa !24
  %t241 = add i64 %t237, %t238
  %t243 = sub i64 %t241, 1
  %t244 = load i64, ptr %l18, !tbaa !24
  %t247 = sdiv i64 %t243, %t244
  store i64 %t247, ptr %l162, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l162, !tbaa !24
  br label %bb45
bb45:
  %t249 = load i64, ptr %l162, !tbaa !24
  store i64 %t249, ptr %l159, !tbaa !24
  br label %bb46
bb46:
  %t250 = load i64, ptr %l159, !tbaa !24
  store i64 %t250, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb47
bb47:
  %t251 = load i64, ptr %l20, !tbaa !24
  %t252 = load i64, ptr %l19, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb48, label %bb49
bb48:
  br label %bb61
bb49:
  br label %bb50
bb50:
  %t259 = load i64, ptr %l16, !tbaa !24
  %t260 = load i64, ptr %l20, !tbaa !24
  %t261 = load i64, ptr %l18, !tbaa !24
  %t264 = mul i64 %t260, %t261
  %t267 = add i64 %t259, %t264
  %t269 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t269, ptr %l180, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 %t267
  %t275 = load i32, ptr %t274, !tbaa !33
  %t276 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t276, ptr %l183, !tbaa !27
  %t277 = load i64, ptr %l15, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr i32, ptr %t280, i64 %t277
  %t282 = load i32, ptr %t281, !tbaa !33
  %t285 = icmp eq i32 %t275, %t282
  br i1 %t285, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s6
  %t287 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t287, ptr %l187, !tbaa !27
  %t288 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t289 = load i32, ptr %t288, !tbaa !23
  %t291 = sext i32 %t289 to i64
  store i64 %t291, ptr %l189, !tbaa !24
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t293, ptr %l191, !tbaa !27
  %t294 = load i64, ptr %l15, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i32, ptr %t297, i64 %t294
  %t299 = load i32, ptr %t298, !tbaa !33
  %t302 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t292, i32 %t299)
  store { i64, ptr } %t302, ptr %l194
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t303 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t304 = load i64, ptr %l189, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t306 = call i64 @compiler_2fcheck_2ewordAt(ptr %v0, ptr %v0, { i64, ptr } %t303, i64 %t304, { i64, ptr } %t305, i64 2)
  store i64 %t306, ptr %l195
  br label %bb54
bb54:
  %t307 = load i64, ptr %l195, !tbaa !24
  store i64 %t307, ptr %l22, !tbaa !24
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/check:Checker", ptr %t308, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = getelementptr %"compiler/generic:Program", ptr %t311, i32 0, i32 0
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/load:Loader", ptr %t314, i32 0, i32 4
  %t317 = load ptr, ptr %t316, !tbaa !29
  store ptr %t317, ptr %l199, !tbaa !29
  %t318 = load i64, ptr %l6, !tbaa !24
  store i64 %t318, ptr %l200, !tbaa !24
  %t319 = load i64, ptr %l22, !tbaa !24
  store i64 %t319, ptr %l201, !tbaa !24
  %t320 = load i64, ptr %l22, !tbaa !24
  store i64 %t320, ptr %l202, !tbaa !24
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t322, ptr %l204, !tbaa !27
  %t323 = load i64, ptr %l15, !tbaa !24
  %t325 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr i32, ptr %t326, i64 %t323
  %t328 = load i32, ptr %t327, !tbaa !33
  %t331 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s6, ptr %t321, i32 %t328)
  store { i64, ptr } %t331, ptr %l207
  br label %bb55
bb55:
  %t332 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 0
  %t334 = load i64, ptr %l202, !tbaa !24
  %t336 = add i64 %t334, %t333
  store { i64, [3 x i64] } zeroinitializer, ptr %t337
  %t338 = getelementptr { i64, [3 x i64] }, ptr %t337, i32 0, i32 0
  store i64 3, ptr %t338
  %t339 = load i64, ptr %l200, !tbaa !24
  %t340 = insertvalue { i64, i64, i64 } undef, i64 %t339, 0
  %t341 = load i64, ptr %l201, !tbaa !24
  %t342 = insertvalue { i64, i64, i64 } %t340, i64 %t341, 1
  %t344 = insertvalue { i64, i64, i64 } %t342, i64 %t336, 2
  %t345 = getelementptr { i64, [3 x i64] }, ptr %t337, i32 0, i32 1
  store { i64, i64, i64 } %t344, ptr %t345
  %t346 = load { i64, [3 x i64] }, ptr %t337
  store { i64, [3 x i64] } %t346, ptr %l210
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t348, ptr %l212, !tbaa !27
  %t349 = load i64, ptr %l15, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr i32, ptr %t352, i64 %t349
  %t354 = load i32, ptr %t353, !tbaa !33
  %t357 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t347, i32 %t354)
  store { i64, ptr } %t357, ptr %l215
  br label %bb56
bb56:
  %t358 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t366 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorWordInUse(ptr %s6, ptr %v0, { i64, ptr } %t364)
  store %"compiler/diagmsg:Msg" %t366, ptr %l217
  br label %bb57
bb57:
  %t367 = load ptr, ptr %l199, !tbaa !29
  %t368 = load { i64, [3 x i64] }, ptr %l210
  %t369 = load %"compiler/diagmsg:Msg", ptr %l217
  %t370 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t367, { i64, [3 x i64] } %t368, %"compiler/diagmsg:Msg" %t369)
  store i64 %t370, ptr %l218
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t371 = load i64, ptr %l20, !tbaa !24
  %t373 = add i64 %t371, 1
  store i64 %t373, ptr %l20, !tbaa !24
  br label %bb47
bb61:
  br label %bb62
bb62:
  %t375 = load i64, ptr %l14, !tbaa !24
  %t377 = add i64 %t375, 1
  store i64 %t377, ptr %l14, !tbaa !24
  br label %bb37
bb63:
  %t379 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t383 = icmp eq i64 %t381, 0
  br i1 %t383, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb65:
  br label %bb66
bb66:
  %t385 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t386, ptr %s0, i64 %t385, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l227, ptr %t386, i64 160, i1 false)
  br label %bb67
bb67:
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %l227, i64 160, i1 false)
  store i1 true, ptr %l24, !tbaa !21
  %t388 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t388, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t390 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 0
  store i64 %t392, ptr %l27, !tbaa !24
  br label %bb68
bb68:
  %t394 = load i64, ptr %l26, !tbaa !24
  %t395 = load i64, ptr %l27, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb69, label %bb70
bb69:
  br label %bb79
bb70:
  br label %bb71
bb71:
  %t402 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t402, ptr %l235, !tbaa !27
  %t403 = load i64, ptr %l26, !tbaa !24
  %t405 = getelementptr { i64, ptr }, ptr %l235, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = getelementptr ptr, ptr %t406, i64 %t403
  %t408 = load ptr, ptr %t407, !tbaa !39
  store ptr %t408, ptr %l28, !tbaa !29
  %t410 = load ptr, ptr %l28, !tbaa !29
  store ptr %t410, ptr %l238, !tbaa !29
  %t411 = ptrtoint ptr %v2 to i64
  store i64 %t411, ptr %l239, !tbaa !24
  %t412 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t412, label %bb72, label %bb73
bb72:
  %t414 = load ptr, ptr %l238, !tbaa !29
  %t415 = call ptr @__olang_region_or(ptr %t414, ptr %v2)
  %t416 = ptrtoint ptr %t415 to i64
  store i64 %t416, ptr %l239, !tbaa !24
  br label %bb73
bb73:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/check:Checker", ptr %t417, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t421 = load ptr, ptr %l28, !tbaa !29
  %t422 = load i64, ptr %l239
  %t423 = inttoptr i64 %t422 to ptr
  %t427 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %s0, ptr %t423, ptr %t420, ptr %l23, ptr %t421)
  store i1 %t427, ptr %l245
  br label %bb74
bb74:
  %t428 = load i1, ptr %l245, !tbaa !21
  %t429 = xor i1 %t428, true
  br i1 %t429, label %bb75, label %bb76
bb75:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t431 = load i64, ptr %l26, !tbaa !24
  %t433 = add i64 %t431, 1
  store i64 %t433, ptr %l26, !tbaa !24
  br label %bb68
bb79:
  %t435 = load i1, ptr %l24, !tbaa !21
  %t437 = xor i1 %t435, true
  br i1 %t437, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  br label %bb82
bb82:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/check:Checker", ptr %t439, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t443 = load i64, ptr %l1, !tbaa !24
  %t444 = load i32, ptr %l3, !tbaa !23
  %t448 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t442, i64 %t443, i32 %t444)
  store i64 %t448, ptr %l255
  br label %bb83
bb83:
  %t449 = load i64, ptr %l255, !tbaa !24
  store i64 %t449, ptr %l29, !tbaa !24
  %t450 = load i64, ptr %l29, !tbaa !24
  %t452 = icmp slt i64 %t450, 0
  br i1 %t452, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb85:
  br label %bb86
bb86:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t458 = load i64, ptr %l1, !tbaa !24
  %t459 = load i64, ptr %l29, !tbaa !24
  %t463 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t457, i64 %t458, i64 %t459)
  store i32 %t463, ptr %l262
  br label %bb87
bb87:
  %t464 = load i32, ptr %l262, !tbaa !23
  store i32 %t464, ptr %l30, !tbaa !23
  %t465 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t466 = load i32, ptr %t465, !tbaa !23
  %t468 = add i32 %t466, 5
  store i32 %t468, ptr %l264, !tbaa !23
  %t469 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t470 = load i32, ptr %t469, !tbaa !23
  %t472 = add i32 %t470, 5
  store i32 %t472, ptr %l266, !tbaa !23
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i32, ptr %l3, !tbaa !23
  %t477 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t473, i32 %t474)
  store { i64, ptr } %t477, ptr %l269
  br label %bb88
bb88:
  %t478 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 0
  %t481 = trunc i64 %t479 to i32
  %t482 = load i32, ptr %l266, !tbaa !23
  %t484 = add i32 %t482, %t481
  %t485 = load i32, ptr %l264, !tbaa !23
  %t487 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t485, i32 %t484)
  store %"compiler/source:Span" %t487, ptr %l273
  br label %bb89
bb89:
  %t488 = load %"compiler/source:Span", ptr %l273
  store %"compiler/source:Span" %t488, ptr %l31
  %t489 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t489, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  store i64 %t493, ptr %l34, !tbaa !24
  br label %bb90
bb90:
  %t495 = load i64, ptr %l33, !tbaa !24
  %t496 = load i64, ptr %l34, !tbaa !24
  %t499 = icmp slt i64 %t495, %t496
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb91, label %bb92
bb91:
  br label %bb106
bb92:
  br label %bb93
bb93:
  %t503 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t503, ptr %l281, !tbaa !27
  %t504 = load i64, ptr %l33, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr ptr, ptr %t507, i64 %t504
  %t509 = load ptr, ptr %t508, !tbaa !39
  store ptr %t509, ptr %l35, !tbaa !29
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l284, !tbaa !29
  %t512 = load ptr, ptr %l35, !tbaa !29
  store ptr %t512, ptr %l285, !tbaa !29
  %t513 = ptrtoint ptr %v2 to i64
  store i64 %t513, ptr %l286, !tbaa !24
  %t514 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t514, label %bb94, label %bb95
bb94:
  %t516 = load ptr, ptr %l285, !tbaa !29
  %t517 = call ptr @__olang_region_or(ptr %t516, ptr %v2)
  %t518 = ptrtoint ptr %t517 to i64
  store i64 %t518, ptr %l286, !tbaa !24
  br label %bb95
bb95:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/check:Checker", ptr %t519, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t523 = load ptr, ptr %l35, !tbaa !29
  %t524 = load i64, ptr %l286
  %t525 = inttoptr i64 %t524 to ptr
  %t529 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %s0, ptr %t525, ptr %t522, ptr %l23, ptr %t523)
  store i32 %t529, ptr %l292
  br label %bb96
bb96:
  %t530 = load i32, ptr %l30, !tbaa !23
  %t531 = load ptr, ptr %l284, !tbaa !29
  %t532 = load i32, ptr %l292, !tbaa !23
  %t534 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetReaches(ptr %v0, ptr %t531, i32 %t532, i32 %t530, i64 0)
  store i1 %t534, ptr %l294
  br label %bb97
bb97:
  %t535 = load i1, ptr %l294, !tbaa !21
  br i1 %t535, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s18
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/check:Checker", ptr %t536, i32 0, i32 1
  %t539 = load ptr, ptr %t538, !tbaa !29
  %t541 = getelementptr %"compiler/generic:Program", ptr %t539, i32 0, i32 0
  %t542 = load ptr, ptr %t541, !tbaa !29
  %t544 = getelementptr %"compiler/load:Loader", ptr %t542, i32 0, i32 4
  %t545 = load ptr, ptr %t544, !tbaa !29
  store ptr %t545, ptr %l298, !tbaa !29
  %t546 = load i64, ptr %l6, !tbaa !24
  %t547 = getelementptr %"compiler/source:Span", ptr %l31, i32 0, i32 0
  %t548 = load i32, ptr %t547, !tbaa !23
  %t550 = sext i32 %t548 to i64
  %t551 = getelementptr %"compiler/source:Span", ptr %l31, i32 0, i32 1
  %t552 = load i32, ptr %t551, !tbaa !23
  %t554 = sext i32 %t552 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t555
  %t556 = getelementptr { i64, [3 x i64] }, ptr %t555, i32 0, i32 0
  store i64 3, ptr %t556
  %t558 = insertvalue { i64, i64, i64 } undef, i64 %t546, 0
  %t560 = insertvalue { i64, i64, i64 } %t558, i64 %t550, 1
  %t562 = insertvalue { i64, i64, i64 } %t560, i64 %t554, 2
  %t563 = getelementptr { i64, [3 x i64] }, ptr %t555, i32 0, i32 1
  store { i64, i64, i64 } %t562, ptr %t563
  %t564 = load { i64, [3 x i64] }, ptr %t555
  store { i64, [3 x i64] } %t564, ptr %l304
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i32, ptr %l3, !tbaa !23
  %t569 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t565, i32 %t566)
  store { i64, ptr } %t569, ptr %l307
  br label %bb100
bb99:
  br label %bb104
bb100:
  %t570 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t571 = extractvalue { i64, ptr } %t570, 0
  %t572 = extractvalue { i64, ptr } %t570, 1
  %t573 = mul i64 %t571, 1
  %t574 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t573)
  call void @llvm.memcpy.p0.p0.i64(ptr %t574, ptr %t572, i64 %t573, i1 false)
  %t575 = insertvalue { i64, ptr } undef, i64 %t571, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  store { i64, ptr } %t576, ptr %l308, !tbaa !27
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load ptr, ptr %l35, !tbaa !29
  %t580 = getelementptr %"compiler/ast:Path", ptr %t578, i32 0, i32 0
  %t581 = load %"compiler/source:Span", ptr %t580
  %t584 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t577, %"compiler/source:Span" %t581)
  store { i64, ptr } %t584, ptr %l312
  br label %bb101
bb101:
  %t585 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t586 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t587 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorSetHoldsItself(ptr %s18, ptr %v0, ptr %v0, { i64, ptr } %t585, { i64, ptr } %t586)
  store %"compiler/diagmsg:Msg" %t587, ptr %l313
  br label %bb102
bb102:
  %t588 = load ptr, ptr %l298, !tbaa !29
  %t589 = load { i64, [3 x i64] }, ptr %l304
  %t590 = load %"compiler/diagmsg:Msg", ptr %l313
  %t591 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t588, { i64, [3 x i64] } %t589, %"compiler/diagmsg:Msg" %t590)
  store i64 %t591, ptr %l314
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb104:
  br label %bb105
bb105:
  %t592 = load i64, ptr %l33, !tbaa !24
  %t594 = add i64 %t592, 1
  store i64 %t594, ptr %l33, !tbaa !24
  br label %bb90
bb106:
  %t596 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t598 = extractvalue { i64, ptr } %t596, 0
  %t600 = icmp eq i64 %t598, 0
  br i1 %t600, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb108:
  br label %bb109
bb109:
  %t602 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t602, ptr %l320
  br label %bb110
bb110:
  %t603 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l320
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t603, ptr %l36
  %t604 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t604, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t606 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t606, 0
  store i64 %t608, ptr %l39, !tbaa !24
  br label %bb111
bb111:
  %t610 = load i64, ptr %l38, !tbaa !24
  %t611 = load i64, ptr %l39, !tbaa !24
  %t614 = icmp slt i64 %t610, %t611
  %t616 = xor i1 %t614, true
  br i1 %t616, label %bb112, label %bb113
bb112:
  br label %bb119
bb113:
  br label %bb114
bb114:
  %t618 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t618, ptr %l328, !tbaa !27
  %t619 = load i64, ptr %l38, !tbaa !24
  %t621 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = getelementptr ptr, ptr %t622, i64 %t619
  %t624 = load ptr, ptr %t623, !tbaa !39
  store ptr %t624, ptr %l40, !tbaa !29
  %t626 = load ptr, ptr %l40, !tbaa !29
  store ptr %t626, ptr %l331, !tbaa !29
  %t627 = ptrtoint ptr %v2 to i64
  store i64 %t627, ptr %l332, !tbaa !24
  %t628 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t628, label %bb115, label %bb116
bb115:
  %t630 = load ptr, ptr %l331, !tbaa !29
  %t631 = call ptr @__olang_region_or(ptr %t630, ptr %v2)
  %t632 = ptrtoint ptr %t631 to i64
  store i64 %t632, ptr %l332, !tbaa !24
  br label %bb116
bb116:
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t635 = getelementptr %"compiler/check:Checker", ptr %t633, i32 0, i32 1
  %t636 = load ptr, ptr %t635, !tbaa !29
  %t637 = load ptr, ptr %l40, !tbaa !29
  %t638 = load i64, ptr %l332
  %t639 = inttoptr i64 %t638 to ptr
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetEntries(ptr %v0, ptr %s0, ptr %t639, ptr %s0, ptr %t636, ptr %l23, ptr %t637, ptr %l36)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t644 = load i64, ptr %l38, !tbaa !24
  %t646 = add i64 %t644, 1
  store i64 %t646, ptr %l38, !tbaa !24
  br label %bb111
bb119:
  %t648 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t648, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t650 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t652 = extractvalue { i64, ptr } %t650, 0
  store i64 %t652, ptr %l43, !tbaa !24
  br label %bb120
bb120:
  %t654 = load i64, ptr %l42, !tbaa !24
  %t655 = load i64, ptr %l43, !tbaa !24
  %t658 = icmp slt i64 %t654, %t655
  %t660 = xor i1 %t658, true
  br i1 %t660, label %bb121, label %bb122
bb121:
  br label %bb169
bb122:
  br label %bb123
bb123:
  %t662 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t662, ptr %l348, !tbaa !27
  %t663 = load i64, ptr %l42, !tbaa !24
  %t665 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t666 = load ptr, ptr %t665, !tbaa !27
  %t667 = getelementptr i32, ptr %t666, i64 %t663
  %t668 = load i32, ptr %t667, !tbaa !33
  store i32 %t668, ptr %l44, !tbaa !23
  store ptr %l36, ptr %l45, !tbaa !29
  store i64 0, ptr %l46, !tbaa !24
  br label %bb124
bb124:
  store %olang.scope zeroinitializer, ptr %s27
  %t671 = load i64, ptr %l46, !tbaa !24
  store i64 %t671, ptr %l352, !tbaa !24
  %t672 = load ptr, ptr %l45, !tbaa !29
  %t674 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t672)
  store i64 %t674, ptr %l354
  br label %bb125
bb125:
  %t675 = load i64, ptr %l352, !tbaa !24
  %t676 = load i64, ptr %l354, !tbaa !24
  %t677 = icmp slt i64 %t675, %t676
  %t679 = xor i1 %t677, true
  br i1 %t679, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s27)
  br label %bb167
bb127:
  br label %bb128
bb128:
  %t681 = load ptr, ptr %l45, !tbaa !29
  %t682 = load i64, ptr %l46, !tbaa !24
  %t685 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t681, i64 %t682)
  store i32 %t685, ptr %l359
  br label %bb129
bb129:
  %t686 = load i32, ptr %l359, !tbaa !23
  store i32 %t686, ptr %l47, !tbaa !23
  %t687 = load i32, ptr %l47, !tbaa !23
  %t688 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t691 = icmp eq i32 %t687, %t688
  br i1 %t691, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s27)
  br label %bb166
bb131:
  br label %bb132
bb132:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = getelementptr %"compiler/check:Checker", ptr %t693, i32 0, i32 1
  %t696 = load ptr, ptr %t695, !tbaa !29
  store ptr %t696, ptr %l364, !tbaa !29
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t699 = getelementptr %"compiler/check:Checker", ptr %t697, i32 0, i32 1
  %t700 = load ptr, ptr %t699, !tbaa !29
  %t702 = getelementptr %"compiler/generic:Program", ptr %t700, i32 0, i32 2
  store ptr %t702, ptr %l367, !tbaa !29
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t705 = getelementptr %"compiler/check:Checker", ptr %t703, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !29
  %t708 = getelementptr %"compiler/generic:Program", ptr %t706, i32 0, i32 2
  %t709 = load i32, ptr %l47, !tbaa !23
  %t712 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t708, i32 %t709)
  store i32 %t712, ptr %l372
  br label %bb133
bb133:
  %t713 = load ptr, ptr %l367, !tbaa !29
  %t714 = load i32, ptr %l372, !tbaa !23
  %t715 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t713, i32 %t714)
  store i32 %t715, ptr %l373
  br label %bb134
bb134:
  %t716 = load ptr, ptr %l364, !tbaa !29
  %t717 = load i32, ptr %l373, !tbaa !23
  %t718 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s27, ptr %t716, i32 %t717)
  store { i64, ptr } %t718, ptr %l374
  br label %bb135
bb135:
  %t719 = load { i64, ptr }, ptr %l374, !tbaa !27
  store { i64, ptr } %t719, ptr %l48, !tbaa !27
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t722 = getelementptr %"compiler/check:Checker", ptr %t720, i32 0, i32 1
  %t723 = load ptr, ptr %t722, !tbaa !29
  %t725 = getelementptr %"compiler/generic:Program", ptr %t723, i32 0, i32 2
  %t726 = load i32, ptr %l47, !tbaa !23
  %t729 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t725, i32 %t726)
  store i64 %t729, ptr %l379
  br label %bb136
bb136:
  %t730 = load i64, ptr %l379, !tbaa !65
  store i64 %t730, ptr %l49, !tbaa !65
  store i64 0, ptr %l50, !tbaa !24
  %t731 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t733 = extractvalue { i64, ptr } %t731, 0
  store i64 %t733, ptr %l51, !tbaa !24
  store i64 1, ptr %l52, !tbaa !24
  %t735 = load i64, ptr %l51, !tbaa !24
  %t736 = load i64, ptr %l50, !tbaa !24
  %t739 = icmp sgt i64 %t735, %t736
  br i1 %t739, label %bb137, label %bb138
bb137:
  %t741 = load i64, ptr %l52, !tbaa !24
  %t743 = icmp sgt i64 %t741, 0
  br i1 %t743, label %bb139, label %bb140
bb138:
  store i64 0, ptr %l385, !tbaa !24
  br label %bb142
bb139:
  %t745 = load i64, ptr %l51, !tbaa !24
  %t746 = load i64, ptr %l50, !tbaa !24
  %t749 = sub i64 %t745, %t746
  %t750 = load i64, ptr %l52, !tbaa !24
  %t753 = add i64 %t749, %t750
  %t755 = sub i64 %t753, 1
  %t756 = load i64, ptr %l52, !tbaa !24
  %t759 = sdiv i64 %t755, %t756
  store i64 %t759, ptr %l388, !tbaa !24
  br label %bb141
bb140:
  store i64 0, ptr %l388, !tbaa !24
  br label %bb141
bb141:
  %t761 = load i64, ptr %l388, !tbaa !24
  store i64 %t761, ptr %l385, !tbaa !24
  br label %bb142
bb142:
  %t762 = load i64, ptr %l385, !tbaa !24
  store i64 %t762, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  br label %bb143
bb143:
  %t763 = load i64, ptr %l54, !tbaa !24
  %t764 = load i64, ptr %l53, !tbaa !24
  %t767 = icmp slt i64 %t763, %t764
  %t769 = xor i1 %t767, true
  br i1 %t769, label %bb144, label %bb145
bb144:
  br label %bb165
bb145:
  br label %bb146
bb146:
  %t771 = load i64, ptr %l50, !tbaa !24
  %t772 = load i64, ptr %l54, !tbaa !24
  %t773 = load i64, ptr %l52, !tbaa !24
  %t776 = mul i64 %t772, %t773
  %t779 = add i64 %t771, %t776
  store i64 %t779, ptr %l55, !tbaa !24
  %t781 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t781, ptr %l406, !tbaa !27
  %t782 = load i64, ptr %l55, !tbaa !24
  %t784 = getelementptr { i64, ptr }, ptr %l406, i32 0, i32 1
  %t785 = load ptr, ptr %t784, !tbaa !27
  %t786 = getelementptr i32, ptr %t785, i64 %t782
  %t787 = load i32, ptr %t786, !tbaa !33
  %t788 = load i32, ptr %l44, !tbaa !23
  %t791 = icmp eq i32 %t787, %t788
  br i1 %t791, label %bb147, label %bb148
bb147:
  %t793 = load i64, ptr %l55, !tbaa !24
  %t795 = icmp sge i64 %t793, 64
  br i1 %t795, label %bb149, label %bb150
bb148:
  store i1 false, ptr %l411, !tbaa !21
  br label %bb152
bb149:
  store i1 true, ptr %l414, !tbaa !21
  br label %bb151
bb150:
  %t797 = load i64, ptr %l49, !tbaa !65
  %t798 = load i64, ptr %l55, !tbaa !24
  store i64 %t798, ptr %l416, !tbaa !24
  %t799 = load i64, ptr %l416, !tbaa !24
  %t800 = load i64, ptr %l416, !tbaa !24
  %t801 = shl i64 1, %t800
  %t804 = and i64 %t797, %t801
  %t806 = icmp ne i64 %t804, 0
  store i1 %t806, ptr %l414, !tbaa !21
  br label %bb151
bb151:
  %t808 = load i1, ptr %l414, !tbaa !21
  store i1 %t808, ptr %l411, !tbaa !21
  br label %bb152
bb152:
  %t809 = load i1, ptr %l411, !tbaa !21
  br i1 %t809, label %bb153, label %bb154
bb153:
  store %olang.scope zeroinitializer, ptr %s31
  %t810 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t810, ptr %l420, !tbaa !27
  %t811 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t812 = load i32, ptr %t811, !tbaa !23
  %t814 = sext i32 %t812 to i64
  store i64 %t814, ptr %l422, !tbaa !24
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t816 = load i32, ptr %l44, !tbaa !23
  %t819 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t815, i32 %t816)
  store { i64, ptr } %t819, ptr %l425
  br label %bb155
bb154:
  br label %bb163
bb155:
  %t820 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t821 = load i64, ptr %l422, !tbaa !24
  %t822 = load { i64, ptr }, ptr %l425, !tbaa !27
  %t823 = call i64 @compiler_2fcheck_2ewordAt(ptr %v0, ptr %v0, { i64, ptr } %t820, i64 %t821, { i64, ptr } %t822, i64 1)
  store i64 %t823, ptr %l426
  br label %bb156
bb156:
  %t824 = load i64, ptr %l426, !tbaa !24
  store i64 %t824, ptr %l56, !tbaa !24
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t827 = getelementptr %"compiler/check:Checker", ptr %t825, i32 0, i32 1
  %t828 = load ptr, ptr %t827, !tbaa !29
  %t830 = getelementptr %"compiler/generic:Program", ptr %t828, i32 0, i32 0
  %t831 = load ptr, ptr %t830, !tbaa !29
  %t833 = getelementptr %"compiler/load:Loader", ptr %t831, i32 0, i32 4
  %t834 = load ptr, ptr %t833, !tbaa !29
  store ptr %t834, ptr %l430, !tbaa !29
  %t835 = load i64, ptr %l6, !tbaa !24
  store i64 %t835, ptr %l431, !tbaa !24
  %t836 = load i64, ptr %l56, !tbaa !24
  store i64 %t836, ptr %l432, !tbaa !24
  %t837 = load i64, ptr %l56, !tbaa !24
  store i64 %t837, ptr %l433, !tbaa !24
  %t838 = load ptr, ptr %l0, !tbaa !29
  %t839 = load i32, ptr %l44, !tbaa !23
  %t842 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s31, ptr %t838, i32 %t839)
  store { i64, ptr } %t842, ptr %l436
  br label %bb157
bb157:
  %t843 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t844 = extractvalue { i64, ptr } %t843, 0
  %t845 = load i64, ptr %l433, !tbaa !24
  %t847 = add i64 %t845, %t844
  store { i64, [3 x i64] } zeroinitializer, ptr %t848
  %t849 = getelementptr { i64, [3 x i64] }, ptr %t848, i32 0, i32 0
  store i64 3, ptr %t849
  %t850 = load i64, ptr %l431, !tbaa !24
  %t851 = insertvalue { i64, i64, i64 } undef, i64 %t850, 0
  %t852 = load i64, ptr %l432, !tbaa !24
  %t853 = insertvalue { i64, i64, i64 } %t851, i64 %t852, 1
  %t855 = insertvalue { i64, i64, i64 } %t853, i64 %t847, 2
  %t856 = getelementptr { i64, [3 x i64] }, ptr %t848, i32 0, i32 1
  store { i64, i64, i64 } %t855, ptr %t856
  %t857 = load { i64, [3 x i64] }, ptr %t848
  store { i64, [3 x i64] } %t857, ptr %l439
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t859 = load i32, ptr %l44, !tbaa !23
  %t862 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s31, ptr %t858, i32 %t859)
  store { i64, ptr } %t862, ptr %l442
  br label %bb158
bb158:
  %t863 = load { i64, ptr }, ptr %l442, !tbaa !27
  %t864 = extractvalue { i64, ptr } %t863, 0
  %t865 = extractvalue { i64, ptr } %t863, 1
  %t866 = mul i64 %t864, 1
  %t867 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t866)
  call void @llvm.memcpy.p0.p0.i64(ptr %t867, ptr %t865, i64 %t866, i1 false)
  %t868 = insertvalue { i64, ptr } undef, i64 %t864, 0
  %t869 = insertvalue { i64, ptr } %t868, ptr %t867, 1
  store { i64, ptr } %t869, ptr %l443, !tbaa !27
  %t870 = load ptr, ptr %l0, !tbaa !29
  store ptr %t870, ptr %l444, !tbaa !29
  %t871 = load ptr, ptr %l0, !tbaa !29
  %t873 = getelementptr %"compiler/check:Checker", ptr %t871, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !29
  %t876 = getelementptr %"compiler/generic:Program", ptr %t874, i32 0, i32 2
  %t877 = load i32, ptr %l47, !tbaa !23
  %t880 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t876, i32 %t877)
  store i32 %t880, ptr %l449
  br label %bb159
bb159:
  %t881 = load ptr, ptr %l444, !tbaa !29
  %t882 = load i32, ptr %l449, !tbaa !23
  %t883 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s31, ptr %t881, i32 %t882)
  store { i64, ptr } %t883, ptr %l450
  br label %bb160
bb160:
  %t884 = load { i64, ptr }, ptr %l450, !tbaa !27
  %t885 = extractvalue { i64, ptr } %t884, 0
  %t886 = extractvalue { i64, ptr } %t884, 1
  %t887 = mul i64 %t885, 1
  %t888 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t887)
  call void @llvm.memcpy.p0.p0.i64(ptr %t888, ptr %t886, i64 %t887, i1 false)
  %t889 = insertvalue { i64, ptr } undef, i64 %t885, 0
  %t890 = insertvalue { i64, ptr } %t889, ptr %t888, 1
  %t891 = load { i64, ptr }, ptr %l443, !tbaa !27
  %t893 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorWordOfMember(ptr %s31, ptr %s31, ptr %v0, { i64, ptr } %t891, { i64, ptr } %t890)
  store %"compiler/diagmsg:Msg" %t893, ptr %l452
  br label %bb161
bb161:
  %t894 = load ptr, ptr %l430, !tbaa !29
  %t895 = load { i64, [3 x i64] }, ptr %l439
  %t896 = load %"compiler/diagmsg:Msg", ptr %l452
  %t897 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t894, { i64, [3 x i64] } %t895, %"compiler/diagmsg:Msg" %t896)
  store i64 %t897, ptr %l453
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s31)
  br label %bb163
bb163:
  br label %bb164
bb164:
  %t898 = load i64, ptr %l54, !tbaa !24
  %t900 = add i64 %t898, 1
  store i64 %t900, ptr %l54, !tbaa !24
  br label %bb143
bb165:
  call void @__olang_scope_close(ptr %s27)
  br label %bb166
bb166:
  %t902 = load i64, ptr %l46, !tbaa !24
  %t904 = add i64 %t902, 1
  store i64 %t904, ptr %l46, !tbaa !24
  br label %bb124
bb167:
  br label %bb168
bb168:
  %t906 = load i64, ptr %l42, !tbaa !24
  %t908 = add i64 %t906, 1
  store i64 %t908, ptr %l42, !tbaa !24
  br label %bb120
bb169:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/diagmsg:Msg"
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/diagmsg:Msg"
  %l24 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l41 = alloca i64
  %l44 = alloca i1
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca i32
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/diagmsg:Msg"
  %l90 = alloca i64
  %l95 = alloca i32
  %l104 = alloca { i64, ptr }
  %l108 = alloca %"compiler/diagmsg:Msg"
  %l110 = alloca ptr
  %l114 = alloca %"compiler/diagmsg:Msg"
  %l115 = alloca %"compiler/diagmsg:Msg"
  %l121 = alloca i1
  %l123 = alloca %"compiler/diagmsg:Msg"
  %l124 = alloca %"compiler/diagmsg:Msg"
  %l132 = alloca i64
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 34
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t13, ptr %l22
  %t14 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0)
  store %"compiler/diagmsg:Msg" %t14, ptr %l23
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t15 = load ptr, ptr %l21, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l22
  %t17 = load %"compiler/diagmsg:Msg", ptr %l23
  %t18 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t15, %"compiler/source:Span" %t16, %"compiler/diagmsg:Msg" %t17)
  store i64 %t18, ptr %l24
  br label %bb5
bb5:
  br label %ret
bb6:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 35
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l28, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t27, ptr %l29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 36
  %t32 = load i1, ptr %t31, !tbaa !21
  %t35 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s2, ptr %t28, i1 %t32)
  store { i64, ptr } %t35, ptr %l33
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t36 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t37 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %s2, ptr %v0, { i64, ptr } %t36)
  store %"compiler/diagmsg:Msg" %t37, ptr %l34
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l28, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l29
  %t40 = load %"compiler/diagmsg:Msg", ptr %l34
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t38, %"compiler/source:Span" %t39, %"compiler/diagmsg:Msg" %t40)
  store i64 %t41, ptr %l35
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 32
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l38, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l39
  %t49 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0)
  store %"compiler/diagmsg:Msg" %t49, ptr %l40
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t50 = load ptr, ptr %l38, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l39
  %t52 = load %"compiler/diagmsg:Msg", ptr %l40
  %t53 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t50, %"compiler/source:Span" %t51, %"compiler/diagmsg:Msg" %t52)
  store i64 %t53, ptr %l41
  br label %bb16
bb16:
  br label %ret
bb17:
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 12
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb20
bb19:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 26
  %t62 = load i1, ptr %t61, !tbaa !21
  store i1 %t62, ptr %l44, !tbaa !21
  br label %bb20
bb20:
  %t64 = load i1, ptr %l44, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t65 = load i64, ptr %l2, !tbaa !24
  store i64 %t65, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l2, !tbaa !24
  %t71 = add i64 %t67, %a3
  store i64 %t71, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb29
bb26:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l57, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb28
bb28:
  %t99 = load i64, ptr %l57, !tbaa !24
  store i64 %t99, ptr %l54, !tbaa !24
  br label %bb29
bb29:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb30:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb31, label %bb32
bb31:
  br label %bb78
bb32:
  br label %bb33
bb33:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 28
  %t125 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t121, i64 %t117)
  store i32 %t125, ptr %l78
  br label %bb34
bb34:
  %t126 = load i32, ptr %l78, !tbaa !23
  store i32 %t126, ptr %l11, !tbaa !23
  %t127 = load ptr, ptr %l4, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 0
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = icmp slt i64 %t130, 0
  br i1 %t132, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb38
bb36:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l4, !tbaa !29
  %t137 = getelementptr %"compiler/check:frame", ptr %t135, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %t134, i64 %t138)
  store i1 %t141, ptr %l86
  br label %bb37
bb37:
  %t142 = load i1, ptr %l86, !tbaa !21
  store i1 %t142, ptr %l82, !tbaa !21
  br label %bb38
bb38:
  %t143 = load i1, ptr %l82, !tbaa !21
  br i1 %t143, label %bb39, label %bb40
bb39:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l87, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t145, ptr %l88
  %t146 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %v0)
  store %"compiler/diagmsg:Msg" %t146, ptr %l89
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t147 = load ptr, ptr %l87, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l88
  %t149 = load %"compiler/diagmsg:Msg", ptr %l89
  %t150 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t147, %"compiler/source:Span" %t148, %"compiler/diagmsg:Msg" %t149)
  store i64 %t150, ptr %l90
  br label %bb42
bb42:
  br label %ret
bb43:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 6
  %t155 = load i32, ptr %t154, !tbaa !23
  %t156 = load i32, ptr %l11, !tbaa !23
  %t160 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t151, i32 %t155, i32 %t156)
  store i32 %t160, ptr %l95
  br label %bb44
bb44:
  %t161 = load i32, ptr %l95, !tbaa !23
  store i32 %t161, ptr %l12, !tbaa !23
  %t162 = load i32, ptr %l12, !tbaa !23
  %t163 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t166 = icmp ne i32 %t162, %t163
  br i1 %t166, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 5
  %t171 = load i1, ptr %t170, !tbaa !21
  store i1 %t171, ptr %l13, !tbaa !21
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 5
  store i1 true, ptr %t175, !tbaa !21
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l12, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l104
  br label %bb47
bb46:
  br label %bb76
bb47:
  %t181 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t181, ptr %l14, !tbaa !27
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l13, !tbaa !21
  %t186 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 5
  store i1 %t183, ptr %t186, !tbaa !21
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %s8, ptr %v0, { i64, ptr } %t187)
  store %"compiler/diagmsg:Msg" %t189, ptr %l108
  br label %bb48
bb48:
  %t190 = load %"compiler/diagmsg:Msg", ptr %l108
  store %"compiler/diagmsg:Msg" %t190, ptr %l15
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t191)
  store ptr %t193, ptr %l110
  br label %bb49
bb49:
  %t194 = load ptr, ptr %l110, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 20
  %t197 = load i1, ptr %t196, !tbaa !21
  br i1 %t197, label %bb50, label %bb51
bb50:
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t201 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenErrorNotDeclared(ptr %s8, ptr %v0, { i64, ptr } %t199)
  store %"compiler/diagmsg:Msg" %t201, ptr %l114
  br label %bb52
bb51:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesNoQuestion(ptr %v0, ptr %t202)
  store i1 %t204, ptr %l121
  br label %bb61
bb52:
  %t205 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t205, ptr %l115
  %t206 = load %"compiler/diagmsg:Msg", ptr %l114
  store %"compiler/diagmsg:Msg" %t206, ptr %l15
  %t207 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1
  br i1 %t207, label %bb53, label %bb54
bb53:
  %t209 = getelementptr %"compiler/diagmsg:Msg", ptr %l115, i32 0, i32 1
  %t210 = load { i64, ptr }, ptr %t209
  %t211 = extractvalue { i64, ptr } %t210, 1
  call void @__olang_region_release(ptr %t211)
  store { i64, ptr } zeroinitializer, ptr %t209
  br label %bb54
bb54:
  %t212 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t212, label %bb55, label %bb56
bb55:
  %t214 = getelementptr %"compiler/diagmsg:Msg", ptr %l115, i32 0, i32 2
  %t215 = load { i64, ptr }, ptr %t214
  %t216 = extractvalue { i64, ptr } %t215, 1
  call void @__olang_region_release(ptr %t216)
  store { i64, ptr } zeroinitializer, ptr %t214
  br label %bb56
bb56:
  %t217 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t217, label %bb57, label %bb58
bb57:
  %t219 = getelementptr %"compiler/diagmsg:Msg", ptr %l115, i32 0, i32 3
  %t220 = load { i64, ptr }, ptr %t219
  %t221 = extractvalue { i64, ptr } %t220, 1
  call void @__olang_region_release(ptr %t221)
  store { i64, ptr } zeroinitializer, ptr %t219
  br label %bb58
bb58:
  %t222 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t222, label %bb59, label %bb60
bb59:
  %t224 = getelementptr %"compiler/diagmsg:Msg", ptr %l115, i32 0, i32 4
  %t225 = load { i64, ptr }, ptr %t224
  %t226 = extractvalue { i64, ptr } %t225, 1
  call void @__olang_region_release(ptr %t226)
  store { i64, ptr } zeroinitializer, ptr %t224
  br label %bb60
bb60:
  br label %bb74
bb61:
  %t227 = load i1, ptr %l121, !tbaa !21
  br i1 %t227, label %bb62, label %bb63
bb62:
  %t228 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t230 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryNeedsQuestion(ptr %s8, ptr %v0, { i64, ptr } %t228)
  store %"compiler/diagmsg:Msg" %t230, ptr %l123
  br label %bb64
bb63:
  br label %bb73
bb64:
  %t231 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t231, ptr %l124
  %t232 = load %"compiler/diagmsg:Msg", ptr %l123
  store %"compiler/diagmsg:Msg" %t232, ptr %l15
  %t233 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1
  br i1 %t233, label %bb65, label %bb66
bb65:
  %t235 = getelementptr %"compiler/diagmsg:Msg", ptr %l124, i32 0, i32 1
  %t236 = load { i64, ptr }, ptr %t235
  %t237 = extractvalue { i64, ptr } %t236, 1
  call void @__olang_region_release(ptr %t237)
  store { i64, ptr } zeroinitializer, ptr %t235
  br label %bb66
bb66:
  %t238 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t238, label %bb67, label %bb68
bb67:
  %t240 = getelementptr %"compiler/diagmsg:Msg", ptr %l124, i32 0, i32 2
  %t241 = load { i64, ptr }, ptr %t240
  %t242 = extractvalue { i64, ptr } %t241, 1
  call void @__olang_region_release(ptr %t242)
  store { i64, ptr } zeroinitializer, ptr %t240
  br label %bb68
bb68:
  %t243 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t243, label %bb69, label %bb70
bb69:
  %t245 = getelementptr %"compiler/diagmsg:Msg", ptr %l124, i32 0, i32 3
  %t246 = load { i64, ptr }, ptr %t245
  %t247 = extractvalue { i64, ptr } %t246, 1
  call void @__olang_region_release(ptr %t247)
  store { i64, ptr } zeroinitializer, ptr %t245
  br label %bb70
bb70:
  %t248 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t248, label %bb71, label %bb72
bb71:
  %t250 = getelementptr %"compiler/diagmsg:Msg", ptr %l124, i32 0, i32 4
  %t251 = load { i64, ptr }, ptr %t250
  %t252 = extractvalue { i64, ptr } %t251, 1
  call void @__olang_region_release(ptr %t252)
  store { i64, ptr } zeroinitializer, ptr %t250
  br label %bb72
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  %t255 = load %"compiler/diagmsg:Msg", ptr %l15
  %t259 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t253, %"compiler/source:Span" %t254, %"compiler/diagmsg:Msg" %t255)
  store i64 %t259, ptr %l132
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s8)
  br label %ret
bb76:
  br label %bb77
bb77:
  %t260 = load i64, ptr %l9, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l9, !tbaa !24
  br label %bb30
bb78:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFound(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca %"compiler/effects:Facts"
  %l16 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca %"compiler/effects:Facts"
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:factRead", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i32 @compiler_2feffects_2eFact_2eNamed(ptr %v1, { i64, ptr } %t4)
  store i32 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i32, ptr %l5, !range !{i32 0, i32 11}
  store i32 %t7, ptr %l2
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/check:factRead", ptr %t8, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t15)
  store ptr %t17, ptr %l10
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/check:factRead", ptr %t18, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load ptr, ptr %l10, !tbaa !29
  %t24 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %t22, i64 %t21)
  store %"compiler/effects:Facts" %t24, ptr %l13
  br label %bb5
bb5:
  %t25 = load i32, ptr %l2, !range !{i32 0, i32 11}
  %t28 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %s1, ptr %l13, i32 %t25)
  store i1 %t28, ptr %l16
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i1, ptr %l16, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t30)
  store ptr %t32, ptr %l18
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 24
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/check:factRead", ptr %t36, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t35, i64 %t39)
  %t43 = extractvalue { i32, i64 } %t42, 1
  %t44 = extractvalue { i32, i64 } %t42, 0
  store i32 %t44, ptr %l25
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb10, label %ok.46, !prof !99
ok.46:
  store i64 %t43, ptr %l24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l24, !tbaa !24
  store i64 %t47, ptr %l19, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l19, !tbaa !24
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l18, !tbaa !29
  %t49 = load i64, ptr %l19, !tbaa !24
  %t50 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/effects:Facts" %t50, ptr %l26
  br label %bb13
bb13:
  %t51 = load i32, ptr %l2, !range !{i32 0, i32 11}
  %t54 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %s0, ptr %l26, i32 %t51)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 14
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l24, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l25
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t52 = icmp slt i64 %t46, %t49
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l30, !tbaa !23
  br label %bb13
bb12:
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t62, ptr %l30, !tbaa !23
  br label %bb13
bb13:
  %t64 = load i32, ptr %l30, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldUntyped(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l8, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l13
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load i32, ptr %l13, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = icmp eq i32 %t39, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb3
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i1
  %l63 = alloca i32
  %l67 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l119 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca i1
  %l141 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l158 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l22, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l27
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l22, !tbaa !29
  %t18 = load i32, ptr %l27, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l28
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 0, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l37, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l37, !tbaa !24
  store i64 %t51, ptr %l34, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l34, !tbaa !24
  store i64 %t52, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l9, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t73 = load i64, ptr %l9, !tbaa !24
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoValueCase(ptr %v0, ptr %t71, i32 %t72, i64 %t73)
  store i1 %t77, ptr %l58
  br label %bb13
bb13:
  %t78 = load i1, ptr %l58, !tbaa !21
  br i1 %t78, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb87
bb15:
  br label %bb16
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t84 = load i64, ptr %l9, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t82, i32 %t83, i64 %t84)
  store i32 %t88, ptr %l63
  br label %bb17
bb17:
  %t89 = load i32, ptr %l63, !tbaa !23
  store i32 %t89, ptr %l10, !tbaa !23
  %t90 = load i32, ptr %l10, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t94 = icmp ne i32 %t90, %t91
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l70, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l10, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l75
  br label %bb20
bb19:
  %t112 = icmp sge i64 0, 0
  br i1 %t112, label %bb22, label %bb23
bb20:
  %t114 = load ptr, ptr %l70, !tbaa !29
  %t115 = load i32, ptr %l75, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t114, i32 %t115)
  store { i64, ptr } %t116, ptr %l76
  br label %bb21
bb21:
  %t117 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t117, ptr %l67, !tbaa !27
  br label %bb26
bb22:
  %t118 = icmp sle i64 0, 2305843009213693951
  br i1 %t118, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_3f3d818644d50cc7_38dbc52e232a8b93)
  unreachable
bb24:
  %t120 = mul i64 0, 4
  %t121 = insertvalue { i64, ptr } undef, i64 0, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t122, ptr %l67, !tbaa !27
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3f3d818644d50cc7_38dbc52e232a8b93)
  unreachable
bb26:
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t124, ptr %l11, !tbaa !27
  %t125 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %l80
  br label %bb27
bb27:
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  %t127 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %t127
  store ptr %t127, ptr %l12, !tbaa !29
  store ptr %a1, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t131 = load i64, ptr %l14, !tbaa !24
  store i64 %t131, ptr %l83, !tbaa !24
  %t132 = load ptr, ptr %l13, !tbaa !29
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t132)
  store i64 %t134, ptr %l85
  br label %bb29
bb29:
  %t135 = load i64, ptr %l83, !tbaa !24
  %t136 = load i64, ptr %l85, !tbaa !24
  %t137 = icmp slt i64 %t135, %t136
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb30, label %bb31
bb30:
  br label %bb82
bb31:
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l13, !tbaa !29
  %t142 = load i64, ptr %l14, !tbaa !24
  %t145 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t141, i64 %t142)
  store { i64, ptr } %t145, ptr %l90
  br label %bb33
bb33:
  %t146 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t146, ptr %l15, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t147, ptr %l91, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr ptr, ptr %t149, i64 0
  %t151 = load ptr, ptr %t150, !tbaa !39
  store ptr %t151, ptr %l16, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l16, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  store i1 %t157, ptr %l95
  br label %bb34
bb34:
  %t158 = load i1, ptr %l95, !tbaa !21
  br i1 %t158, label %bb35, label %bb36
bb35:
  %t159 = load ptr, ptr %l12, !tbaa !29
  store ptr %t159, ptr %l96, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t160, ptr %l97, !tbaa !27
  %t161 = icmp sge i64 0, 0
  br i1 %t161, label %bb37, label %bb38
bb36:
  br label %bb43
bb37:
  %t163 = icmp sle i64 0, 1152921504606846975
  br i1 %t163, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_f2fc693d8c32a9d2_b249c5d053dbb65e)
  unreachable
bb39:
  %t165 = mul i64 0, 8
  %t166 = insertvalue { i64, ptr } undef, i64 0, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t168 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t174 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t171, { i64, ptr } %t167, i64 %t170)
  store { i64, ptr } %t174, ptr %l103
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_f2fc693d8c32a9d2_b249c5d053dbb65e)
  unreachable
bb41:
  %t175 = load ptr, ptr %l96, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l103, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %s2, ptr %v1, ptr %t175, { i64, ptr } %t176)
  br label %bb42
bb42:
  br label %bb81
bb43:
  %t177 = load ptr, ptr %l16, !tbaa !29
  store ptr %t177, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t178 = load ptr, ptr %l104, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb44, label %bb45
bb44:
  %t181 = load ptr, ptr %l104, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 9}
  %t184 = icmp eq i64 %t182, 1
  store i1 %t184, ptr %l105, !tbaa !21
  br label %bb45
bb45:
  %t185 = load i1, ptr %l105, !tbaa !21
  br i1 %t185, label %bb46, label %bb47
bb46:
  %t186 = load ptr, ptr %l16, !tbaa !29
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", ptr }, ptr %t188, i32 0, i32 1
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l17, !tbaa !29
  br label %bb52
bb47:
  %t192 = load ptr, ptr %l16, !tbaa !29
  store ptr %t192, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t193 = load ptr, ptr %l110, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb48, label %bb49
bb48:
  %t196 = load ptr, ptr %l110, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 9}
  %t199 = icmp eq i64 %t197, 4
  store i1 %t199, ptr %l111, !tbaa !21
  br label %bb49
bb49:
  %t200 = load i1, ptr %l111, !tbaa !21
  br i1 %t200, label %bb50, label %bb51
bb50:
  %t201 = load ptr, ptr %l16, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", ptr }, ptr %t203, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l17, !tbaa !29
  br label %bb52
bb51:
  br label %bb63
bb52:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l17, !tbaa !29
  %t209 = load i32, ptr %l2, !tbaa !23
  %t213 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t207, ptr %t208, i32 %t209)
  store i64 %t213, ptr %l119
  br label %bb53
bb53:
  %t214 = load i64, ptr %l9, !tbaa !24
  %t215 = load i64, ptr %l119, !tbaa !24
  %t217 = icmp eq i64 %t215, %t214
  br i1 %t217, label %bb54, label %bb55
bb54:
  %t219 = load ptr, ptr %l12, !tbaa !29
  store ptr %t219, ptr %l122, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t220, ptr %l123, !tbaa !27
  %t221 = icmp sge i64 0, 0
  br i1 %t221, label %bb56, label %bb57
bb55:
  br label %bb62
bb56:
  %t223 = icmp sle i64 0, 1152921504606846975
  br i1 %t223, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_1aa49c7f94741e71_4937354175d6cb9d)
  unreachable
bb58:
  %t225 = mul i64 0, 8
  %t226 = insertvalue { i64, ptr } undef, i64 0, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t228 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t234 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t231, { i64, ptr } %t227, i64 %t230)
  store { i64, ptr } %t234, ptr %l129
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_1aa49c7f94741e71_4937354175d6cb9d)
  unreachable
bb60:
  %t235 = load ptr, ptr %l122, !tbaa !29
  %t236 = load { i64, ptr }, ptr %l129, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %s2, ptr %v1, ptr %t235, { i64, ptr } %t236)
  br label %bb61
bb61:
  br label %bb62
bb62:
  br label %bb80
bb63:
  %t237 = load ptr, ptr %l16, !tbaa !29
  store ptr %t237, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t238 = load ptr, ptr %l130, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb64, label %bb65
bb64:
  %t241 = load ptr, ptr %l130, !tbaa !29
  %t242 = load i64, ptr %t241, !range !{i64 0, i64 9}
  %t244 = icmp eq i64 %t242, 2
  store i1 %t244, ptr %l131, !tbaa !21
  br label %bb65
bb65:
  %t245 = load i1, ptr %l131, !tbaa !21
  br i1 %t245, label %bb66, label %bb67
bb66:
  %t246 = load ptr, ptr %l16, !tbaa !29
  %t248 = getelementptr { i64, [4 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t248, i32 0, i32 1
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l18, !tbaa !29
  %t252 = load ptr, ptr %l16, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t254, i32 0, i32 2
  %t256 = load { i64, ptr }, ptr %t255
  store { i64, ptr } %t256, ptr %l19, !tbaa !27
  br label %bb68
bb67:
  br label %bb75
bb68:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l18, !tbaa !29
  %t260 = load i32, ptr %l2, !tbaa !23
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t258, ptr %t259, i32 %t260)
  store i64 %t264, ptr %l141
  br label %bb69
bb69:
  %t265 = load i64, ptr %l9, !tbaa !24
  %t266 = load i64, ptr %l141, !tbaa !24
  %t268 = icmp eq i64 %t266, %t265
  br i1 %t268, label %bb70, label %bb71
bb70:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l144, !tbaa !29
  %t271 = load ptr, ptr %l12, !tbaa !29
  store ptr %t271, ptr %l145, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t272, ptr %l146, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t273, ptr %l147, !tbaa !27
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l2, !tbaa !23
  %t276 = load i64, ptr %l9, !tbaa !24
  %t277 = load ptr, ptr %l18, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseFields(ptr %v0, ptr %v1, ptr %v0, ptr %t274, i32 %t275, i64 %t276, ptr %t277)
  store ptr %t282, ptr %l152
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t283 = load ptr, ptr %l144, !tbaa !29
  %t284 = load ptr, ptr %l145, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t287 = load ptr, ptr %l152, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyFieldRow(ptr %v0, ptr %s2, ptr %v1, ptr %v1, ptr %v0, ptr %t283, ptr %t284, { i64, ptr } %t285, { i64, ptr } %t286, ptr %t287)
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb80
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_a8287edb9132b4cb_1f129b43d5c83daf)
  unreachable
bb80:
  br label %bb81
bb81:
  %t288 = load i64, ptr %l14, !tbaa !24
  %t290 = add i64 %t288, 1
  store i64 %t290, ptr %l14, !tbaa !24
  br label %bb28
bb82:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l12, !tbaa !29
  %t294 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t298 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %s2, ptr %s2, ptr %t292, ptr %t293, { i64, ptr } %t294, i64 1)
  store i1 %t298, ptr %l158
  br label %bb83
bb83:
  %t299 = load i1, ptr %l158, !tbaa !21
  %t300 = xor i1 %t299, true
  br i1 %t300, label %bb84, label %bb85
bb84:
  %t302 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t302, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s2)
  br label %bb87
bb87:
  %t304 = load i64, ptr %l8, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l8, !tbaa !24
  br label %bb9
bb88:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l15
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t28 = load i32, ptr %l15, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l16, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t34, i64 %t35, i32 0)
  store i64 %t38, ptr %l21
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l17, !tbaa !29
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t41, ptr %l22
  br label %bb8
bb8:
  %t42 = load ptr, ptr %l16, !tbaa !29
  %t43 = load i64, ptr %l22, !tbaa !24
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t42, i64 %t43)
  store i32 %t44, ptr %l23
  br label %bb9
bb9:
  %t45 = load i32, ptr %l23, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 20
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 20
  store ptr %t11, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 20
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l9
  br label %bb4
bb3:
  %t17 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_fd7c4531a6f9112_8820f62eca2e3ad6, { i64, ptr } %t20)
  unreachable
bb4:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = sub i64 %t21, 1
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %t23, i64 %t22)
  store ptr %t25, ptr %l11
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l11, !tbaa !29
  store ptr %t26, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenRoot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca i32
  %l19 = alloca i64
  %l24 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"compiler/typed:Block"
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l73 = alloca i32
  %l79 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l84 = alloca i32
  %l88 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l112 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l131 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t130 = alloca { i64, [1 x i64] }, align 8
  %t153 = alloca { i64, [3 x i64] }, align 8
  %t203 = alloca { i64, [3 x i64] }, align 8
  %t245 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 0
  %t4 = load %"compiler/source:Span", ptr %t3
  store %"compiler/source:Span" %t4, ptr %l4
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 45
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l19
  br label %bb1
bb1:
  %t11 = load i64, ptr %l19, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t17, i32 %a2)
  store i32 %t21, ptr %l24
  br label %bb2
bb2:
  %t22 = load i32, ptr %l24, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l6, !tbaa !23
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l28
  br label %bb3
bb3:
  %t31 = load i32, ptr %l28, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  br i1 %t36, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb8
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l35, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l7, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l40
  br label %bb6
bb6:
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = load i32, ptr %l40, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l41
  br label %bb7
bb7:
  %t57 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t60 = icmp ne i64 %t58, 1
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t63, %"compiler/source:Span" %t64, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 45
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l49
  br label %bb12
bb12:
  %t74 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t75 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t74)
  store %"compiler/typed:Block" %t75, ptr %l50
  br label %bb13
bb13:
  %t76 = load %"compiler/typed:Block", ptr %l50
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t76, ptr %t77
  call void @__olang_scope_close(ptr %s0)
  store ptr %t77, ptr %rv
  br label %ret
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  store ptr %t84, ptr %l54, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l7, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l59
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load i32, ptr %l59, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t95, i32 %t96)
  store { i64, ptr } %t97, ptr %l60
  br label %bb16
bb16:
  %t98 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t98, ptr %l61, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i32, ptr %t100, i64 0
  %t102 = load i32, ptr %t101, !tbaa !33
  store i32 %t102, ptr %l8, !tbaa !23
  store i64 -1, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l3, !tbaa !24
  %t105 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenFromReturn, !tbaa !24
  %t108 = icmp eq i64 %t104, %t105
  br i1 %t108, label %bb17, label %bb18
bb17:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l6, !tbaa !23
  %t117 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t118 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t121 = or i64 %t117, %t118
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t115, i32 %t116, i64 %t121)
  store i32 %t125, ptr %l73
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t126 = load i32, ptr %l73, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l4
  %t129 = load i32, ptr %l10, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [1 x i64] }, ptr %t130, i32 0, i32 0
  store i64 3, ptr %t131
  %t132 = load { i64, [1 x i64] }, ptr %t130
  %t138 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t127, i32 0, %"compiler/source:Span" %t128, i32 %t129, i32 3, { i64, [1 x i64] } %t132)
  store i64 %t138, ptr %l79
  br label %bb20
bb20:
  %t139 = load i64, ptr %l79, !tbaa !24
  store i64 %t139, ptr %l9, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l80, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t141, ptr %l81
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = trunc i64 %t142 to i32
  store i32 %t144, ptr %l84, !tbaa !23
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l4
  %t148 = load i32, ptr %l10, !tbaa !23
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t146, %"compiler/source:Span" %t147, i32 %t148, i64 0)
  store ptr %t152, ptr %l88
  br label %bb21
bb21:
  store { i64, [3 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 0
  store i64 0, ptr %t154
  %t155 = load %"compiler/source:Span", ptr %l81
  %t156 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t155, 0
  %t157 = load i32, ptr %l84, !tbaa !23
  %t158 = insertvalue { %"compiler/source:Span", i32, ptr } %t156, i32 %t157, 1
  %t159 = load ptr, ptr %l88, !tbaa !29
  %t160 = insertvalue { %"compiler/source:Span", i32, ptr } %t158, ptr %t159, 2
  %t161 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t160, ptr %t161
  %t162 = load { i64, [3 x i64] }, ptr %t153
  %t164 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t162, ptr %t164
  %t165 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t165, ptr %t164)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t169 = load i32, ptr %l8, !tbaa !23
  %t170 = load i64, ptr %l3, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenLambda(ptr %v0, ptr %v1, ptr %v2, ptr %t167, ptr %t168, i32 %t169, i64 %t170, i64 %t171)
  store ptr %t177, ptr %l96
  br label %bb24
bb24:
  %t178 = load ptr, ptr %l96, !tbaa !29
  store ptr %t178, ptr %l11, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l6, !tbaa !23
  %t183 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t179, i32 %t180)
  store i64 %t183, ptr %l99
  br label %bb25
bb25:
  %t184 = load i64, ptr %l99, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 28
  %t188 = load i32, ptr %t187, !tbaa !23
  store i32 %t188, ptr %l13, !tbaa !23
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l6, !tbaa !23
  %t194 = getelementptr %"compiler/check:Checker", ptr %t190, i32 0, i32 28
  store i32 %t191, ptr %t194, !tbaa !23
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l104, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t196, ptr %l105
  %t197 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t197, ptr %l106
  %t198 = load i32, ptr %l7, !tbaa !23
  store i32 %t198, ptr %l107, !tbaa !23
  %t201 = trunc i64 %t184 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t203
  %t204 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 0
  store i64 0, ptr %t204
  %t206 = insertvalue { i32 } undef, i32 %t201, 0
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 1
  store { i32 } %t206, ptr %t207
  %t208 = load { i64, [3 x i64] }, ptr %t203
  %t210 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t208, ptr %t210
  store ptr %t210, ptr %l112, !tbaa !29
  %t211 = icmp sge i64 0, 0
  br i1 %t211, label %bb26, label %bb27
bb26:
  %t213 = icmp sle i64 0, 1152921504606846975
  br i1 %t213, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_8107208a4245ff9c_ccbe9a9f570baf38)
  unreachable
bb28:
  %t215 = mul i64 0, 8
  %t216 = insertvalue { i64, ptr } undef, i64 0, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t218 = load ptr, ptr %l11, !tbaa !29
  %t219 = mul i64 1, 8
  %t220 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t219)
  %t221 = insertvalue { i64, ptr } undef, i64 1, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  store { i64, ptr } %t222, ptr %l117, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 0
  store ptr %t218, ptr %t226, !tbaa !39
  %t227 = load ptr, ptr %l104, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l105
  %t229 = load %"compiler/source:Span", ptr %l106
  %t230 = load i32, ptr %l107, !tbaa !23
  %t231 = load ptr, ptr %l112, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t227, %"compiler/source:Span" %t228, %"compiler/source:Span" %t229, i32 %t230, ptr %t231, i64 -1, ptr null, { i64, ptr } %t217, { i64, ptr } %t233)
  store ptr %t234, ptr %l118
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8107208a4245ff9c_ccbe9a9f570baf38)
  unreachable
bb30:
  %t235 = load ptr, ptr %l118, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l13, !tbaa !23
  %t240 = getelementptr %"compiler/check:Checker", ptr %t236, i32 0, i32 28
  store i32 %t237, ptr %t240, !tbaa !23
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l4
  store { i64, [3 x i64] } zeroinitializer, ptr %t245
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t245, i32 0, i32 0
  store i64 6, ptr %t246
  %t248 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t242, 0
  %t250 = insertvalue { %"compiler/source:Span", ptr } %t248, ptr %t235, 1
  %t251 = getelementptr { i64, [3 x i64] }, ptr %t245, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t250, ptr %t251
  %t252 = load { i64, [3 x i64] }, ptr %t245
  %t254 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t252, ptr %t254
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t241, ptr %t254)
  br label %bb31
bb31:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 45
  %t260 = load i64, ptr %l5, !tbaa !24
  %t263 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t259, i64 %t260)
  store { i64, ptr } %t263, ptr %l130
  br label %bb32
bb32:
  %t264 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t265 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t264)
  store %"compiler/typed:Block" %t265, ptr %l131
  br label %bb33
bb33:
  %t266 = load %"compiler/typed:Block", ptr %l131
  %t267 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t266, ptr %t267
  call void @__olang_scope_close(ptr %s0)
  store ptr %t267, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleReport(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:LocalUses"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca ptr
  %l28 = alloca i64
  %l31 = alloca i1
  %l37 = alloca ptr
  %l44 = alloca %"compiler/typed:LocalUses"
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %s2 = alloca %olang.scope
  %t67 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 18
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l14, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l16
  br label %bb2
bb2:
  %t9 = load i64, ptr %l14, !tbaa !24
  %t10 = load i64, ptr %l16, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l21
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l21, !tbaa !29
  store ptr %t20, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 11
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb8:
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emodOfFile(ptr %v0, ptr %t28, i64 %t32)
  store i64 %t35, ptr %l28
  br label %bb10
bb10:
  %t36 = load i64, ptr %l28, !tbaa !24
  store i64 %t36, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 10
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t49, i64 %t50)
  store ptr %t53, ptr %l37
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l37, !tbaa !29
  %t56 = getelementptr %"compiler/load:Module", ptr %t54, i32 0, i32 3
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t67, ptr %v0, ptr %v0, ptr %s2, ptr %t65, ptr %t66)
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %t67, i64 1320, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l44, i64 1320, i1 false)
  store i64 0, ptr %l6, !tbaa !24
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 7
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l47
  br label %bb19
bb19:
  %t75 = load i64, ptr %l47, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = icmp sgt i64 %t76, %t77
  br i1 %t80, label %bb20, label %bb21
bb20:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = icmp sgt i64 %t82, 0
  br i1 %t84, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb25
bb22:
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = sub i64 %t86, %t87
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = add i64 %t90, %t91
  %t96 = sub i64 %t94, 1
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = sdiv i64 %t96, %t97
  store i64 %t100, ptr %l54, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb24
bb24:
  %t102 = load i64, ptr %l54, !tbaa !24
  store i64 %t102, ptr %l51, !tbaa !24
  br label %bb25
bb25:
  %t103 = load i64, ptr %l51, !tbaa !24
  store i64 %t103, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l8, !tbaa !24
  %t117 = mul i64 %t113, %t114
  %t120 = add i64 %t112, %t117
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t124 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleLocal(ptr %v0, ptr %v0, ptr %s2, ptr %t122, ptr %t123, ptr %l5, i64 %t124, i64 %t120)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t131 = load i64, ptr %l10, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l10, !tbaa !24
  br label %bb26
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t135 = load i64, ptr %l2, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l2, !tbaa !24
  br label %bb1
bb34:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i1
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca ptr
  %l88 = alloca i1
  %l90 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca i64
  %l99 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l109 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l124 = alloca i32
  %l125 = alloca i64
  %l138 = alloca ptr
  %rv = alloca ptr
  %t173 = alloca { i64, [3 x i64] }, align 8
  %t231 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l3, !tbaa !21
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 2 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Make", ptr %t26, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l29, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Make", ptr %t38, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb13, label %bb14
bb13:
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l43, !tbaa !27
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l8, !tbaa !29
  %t65 = call i1 @compiler_2fcheck_2epureRead(ptr %v1, ptr %t63)
  store i1 %t65, ptr %l47
  br label %bb16
bb16:
  %t66 = load i1, ptr %l47, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l8, !tbaa !29
  %t69 = call i1 @compiler_2fcheck_2eisLit(ptr %v1, ptr %t67)
  store i1 %t69, ptr %l50
  br label %bb19
bb19:
  %t70 = load i1, ptr %l50, !tbaa !21
  store i1 %t70, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l48, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb21, label %bb22
bb21:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb12
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb30:
  call void @__olang_check_failed(ptr @olang_loc_317381e6e3d2ca51_b8977c113f1a9cfd)
  unreachable
bb31:
  store i64 %a1, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 44
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l58
  br label %bb32
bb32:
  %t87 = load i64, ptr %l58, !tbaa !24
  store i64 %t87, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb33, label %bb34
bb33:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb38
bb35:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l65, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb37
bb37:
  %t114 = load i64, ptr %l65, !tbaa !24
  store i64 %t114, ptr %l62, !tbaa !24
  br label %bb38
bb38:
  %t115 = load i64, ptr %l62, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb40, label %bb41
bb40:
  br label %bb60
bb41:
  br label %bb42
bb42:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 44
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t136, i64 %t137)
  store ptr %t140, ptr %l86
  br label %bb43
bb43:
  %t141 = load ptr, ptr %l86, !tbaa !29
  store ptr %t141, ptr %l15, !tbaa !29
  %t142 = load i1, ptr %l3, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb47
bb45:
  %t144 = load ptr, ptr %l15, !tbaa !29
  %t146 = call i1 @compiler_2fcheck_2eisLit(ptr %v0, ptr %t144)
  store i1 %t146, ptr %l90
  br label %bb46
bb46:
  %t147 = load i1, ptr %l90, !tbaa !21
  store i1 %t147, ptr %l88, !tbaa !21
  br label %bb47
bb47:
  %t148 = load i1, ptr %l88, !tbaa !21
  br i1 %t148, label %bb48, label %bb49
bb48:
  br label %bb59
bb49:
  br label %bb50
bb50:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l91, !tbaa !29
  %t150 = load ptr, ptr %l15, !tbaa !29
  %t152 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t150)
  store %"compiler/source:Span" %t152, ptr %l93
  br label %bb51
bb51:
  %t153 = load ptr, ptr %l15, !tbaa !29
  %t156 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t153)
  store i32 %t156, ptr %l96
  br label %bb52
bb52:
  %t157 = load ptr, ptr %l91, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l93
  %t159 = load i32, ptr %l96, !tbaa !23
  %t160 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, i32 %t159)
  store i64 %t160, ptr %l97
  br label %bb53
bb53:
  %t161 = load i64, ptr %l97, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 45
  store ptr %t164, ptr %l99, !tbaa !29
  %t165 = load ptr, ptr %l15, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t165)
  store %"compiler/source:Span" %t167, ptr %l101
  br label %bb54
bb54:
  %t168 = load i64, ptr %l16, !tbaa !24
  %t170 = trunc i64 %t168 to i32
  %t172 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 0
  store i64 0, ptr %t174
  %t175 = load %"compiler/source:Span", ptr %l101
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t175, 0
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, i32 %t170, 1
  %t180 = insertvalue { %"compiler/source:Span", i32, ptr } %t178, ptr %t172, 2
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t180, ptr %t181
  %t182 = load { i64, [3 x i64] }, ptr %t173
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t182, ptr %t184
  %t185 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t185, ptr %t184)
  br label %bb55
bb55:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 44
  store ptr %t189, ptr %l109, !tbaa !29
  %t190 = load i64, ptr %l14, !tbaa !24
  store i64 %t190, ptr %l110, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l111, !tbaa !29
  %t192 = load ptr, ptr %l15, !tbaa !29
  %t194 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t192)
  store %"compiler/source:Span" %t194, ptr %l113
  br label %bb56
bb56:
  %t195 = load i64, ptr %l16, !tbaa !24
  %t196 = load ptr, ptr %l111, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l113
  %t199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t196, %"compiler/source:Span" %t197, i64 %t195)
  store ptr %t199, ptr %l115
  br label %bb57
bb57:
  %t200 = load ptr, ptr %l109, !tbaa !29
  %t201 = load i64, ptr %l110, !tbaa !24
  %t202 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t200, i64 %t201, ptr %t202)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t203 = load i64, ptr %l13, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l13, !tbaa !24
  br label %bb39
bb60:
  %t207 = load ptr, ptr %l2, !tbaa !29
  %t209 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t207)
  store %"compiler/source:Span" %t209, ptr %l119
  br label %bb61
bb61:
  %t210 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t210, ptr %l17
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l120, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t212, ptr %l121
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t216 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t213)
  store i32 %t216, ptr %l124
  br label %bb62
bb62:
  %t217 = load ptr, ptr %l120, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l121
  %t219 = load i32, ptr %l124, !tbaa !23
  %t220 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i32 %t219)
  store i64 %t220, ptr %l125
  br label %bb63
bb63:
  %t221 = load i64, ptr %l125, !tbaa !24
  store i64 %t221, ptr %l18, !tbaa !24
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 45
  %t225 = load %"compiler/source:Span", ptr %l17
  %t226 = load i64, ptr %l18, !tbaa !24
  %t228 = trunc i64 %t226 to i32
  %t230 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 0
  store i64 0, ptr %t232
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t225, 0
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, i32 %t228, 1
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } %t236, ptr %t230, 2
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t238, ptr %t239
  %t240 = load { i64, [3 x i64] }, ptr %t231
  %t242 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t240, ptr %t242
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t224, ptr %t242)
  br label %bb64
bb64:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l17
  %t247 = load i64, ptr %l18, !tbaa !24
  %t251 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t245, %"compiler/source:Span" %t246, i64 %t247)
  store ptr %t251, ptr %l138
  br label %bb65
bb65:
  %t252 = load ptr, ptr %l138, !tbaa !29
  store ptr %t252, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i1
  %l30 = alloca i64
  %l33 = alloca i64
  %l53 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Call", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  store ptr %t10, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t11 = load ptr, ptr %l14, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 5}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l4, !tbaa !23
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t25 = load ptr, ptr %lp2
  %t26 = load i32, ptr %l4, !tbaa !23
  %t28 = sext i32 %t26 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t25, i64 %t28)
  br label %bb7
bb7:
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t31 = load ptr, ptr %lp2
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8803ccf5e870aa5b_cb8fe22003fe469f)
  unreachable
bb13:
  store i64 1, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Call", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb19
bb16:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l33, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb18
bb18:
  %t67 = load i64, ptr %l33, !tbaa !24
  store i64 %t67, ptr %l30, !tbaa !24
  br label %bb19
bb19:
  %t68 = load i64, ptr %l30, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb21, label %bb22
bb21:
  br label %bb26
bb22:
  br label %bb23
bb23:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Call", ptr %t88, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t85
  %t97 = load ptr, ptr %t96, !tbaa !39
  %t98 = load ptr, ptr %lp2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t97, ptr %t98)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t102 = load i64, ptr %l9, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l9, !tbaa !24
  br label %bb20
bb26:
  %t106 = load ptr, ptr %lp2
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEntryType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l23 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d19, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i32 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i32, ptr %l5, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l6, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l10
  br label %bb3
bb3:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l14, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l17
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb6:
  %t29 = load ptr, ptr %l14, !tbaa !29
  %t30 = load i32, ptr %l17, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t31, ptr %l18
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l23
  br label %bb8
bb8:
  %t42 = load i32, ptr %l18, !tbaa !23
  %t43 = load i32, ptr %l23, !tbaa !23
  %t44 = icmp eq i32 %t42, %t43
  store i1 %t44, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i1, ptr %l11, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillRevived(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:pathMarks" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:pathMarks"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca %"compiler/check:nullNarrow"
  %l40 = alloca %"compiler/check:nullNarrow"
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l63 = alloca %"compiler/check:narrowed"
  %l65 = alloca %"compiler/check:narrowed"
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca i64
  %l88 = alloca %"compiler/check:errNarrow"
  %l90 = alloca %"compiler/check:errNarrow"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/check:pathMarks" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 20
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i64, ptr %l14, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l17
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l17, !tbaa !29
  store ptr %t12, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/check:pathMarks", ptr %l1, i32 0, i32 0
  store ptr %t13, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t15 = load i64, ptr %l4, !tbaa !24
  store i64 %t15, ptr %l19, !tbaa !24
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t16)
  store i64 %t18, ptr %l21
  br label %bb7
bb7:
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = load i64, ptr %l21, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb8, label %bb9
bb8:
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l26
  br label %bb11
bb11:
  %t30 = load i64, ptr %l26, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  store i64 %t31, ptr %l27, !tbaa !24
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 50
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l30
  br label %bb12
bb12:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = load i64, ptr %l30, !tbaa !24
  %t39 = icmp slt i64 %t37, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/check:frame", ptr %t41, i32 0, i32 50
  store ptr %t43, ptr %l33, !tbaa !29
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l34, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 50
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store %"compiler/check:nullNarrow" %t51, ptr %l38
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t52 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyCalled, !tbaa !24
  %t53 = load %"compiler/check:nullNarrow", ptr %l38
  %t55 = call %"compiler/check:nullNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3anullNarrow_2eKilled(ptr %v0, ptr %v0, %"compiler/check:nullNarrow" %t53, i64 %t52)
  store %"compiler/check:nullNarrow" %t55, ptr %l40
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = load %"compiler/check:nullNarrow", ptr %l40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v0, ptr %t56, i64 %t57, %"compiler/check:nullNarrow" %t58)
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb6
bb20:
  %t63 = getelementptr %"compiler/check:pathMarks", ptr %l1, i32 0, i32 1
  store ptr %t63, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb21
bb21:
  %t65 = load i64, ptr %l7, !tbaa !24
  store i64 %t65, ptr %l44, !tbaa !24
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t66)
  store i64 %t68, ptr %l46
  br label %bb22
bb22:
  %t69 = load i64, ptr %l44, !tbaa !24
  %t70 = load i64, ptr %l46, !tbaa !24
  %t71 = icmp slt i64 %t69, %t70
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb23, label %bb24
bb23:
  br label %bb35
bb24:
  br label %bb25
bb25:
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l51
  br label %bb26
bb26:
  %t80 = load i64, ptr %l51, !tbaa !24
  store i64 %t80, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l52, !tbaa !24
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 46
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l55
  br label %bb27
bb27:
  %t87 = load i64, ptr %l52, !tbaa !24
  %t88 = load i64, ptr %l55, !tbaa !24
  %t89 = icmp slt i64 %t87, %t88
  br i1 %t89, label %bb28, label %bb29
bb28:
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/check:frame", ptr %t91, i32 0, i32 46
  store ptr %t93, ptr %l58, !tbaa !29
  %t94 = load i64, ptr %l8, !tbaa !24
  store i64 %t94, ptr %l59, !tbaa !24
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/check:frame", ptr %t95, i32 0, i32 46
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t97, i64 %t98)
  store %"compiler/check:narrowed" %t101, ptr %l63
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t102 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyCalled, !tbaa !24
  %t103 = load %"compiler/check:narrowed", ptr %l63
  %t105 = call %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(ptr %v0, ptr %v0, %"compiler/check:narrowed" %t103, i64 %t102)
  store %"compiler/check:narrowed" %t105, ptr %l65
  br label %bb31
bb31:
  %t106 = load ptr, ptr %l58, !tbaa !29
  %t107 = load i64, ptr %l59, !tbaa !24
  %t108 = load %"compiler/check:narrowed", ptr %l65
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %v0, ptr %t106, i64 %t107, %"compiler/check:narrowed" %t108)
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l7, !tbaa !24
  br label %bb21
bb35:
  %t113 = getelementptr %"compiler/check:pathMarks", ptr %l1, i32 0, i32 2
  store ptr %t113, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb36
bb36:
  %t115 = load i64, ptr %l10, !tbaa !24
  store i64 %t115, ptr %l69, !tbaa !24
  %t116 = load ptr, ptr %l9, !tbaa !29
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t116)
  store i64 %t118, ptr %l71
  br label %bb37
bb37:
  %t119 = load i64, ptr %l69, !tbaa !24
  %t120 = load i64, ptr %l71, !tbaa !24
  %t121 = icmp slt i64 %t119, %t120
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb38, label %bb39
bb38:
  br label %bb50
bb39:
  br label %bb40
bb40:
  %t125 = load ptr, ptr %l9, !tbaa !29
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l76
  br label %bb41
bb41:
  %t130 = load i64, ptr %l76, !tbaa !24
  store i64 %t130, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  store i64 %t131, ptr %l77, !tbaa !24
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t134 = getelementptr %"compiler/check:frame", ptr %t132, i32 0, i32 62
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t134)
  store i64 %t136, ptr %l80
  br label %bb42
bb42:
  %t137 = load i64, ptr %l77, !tbaa !24
  %t138 = load i64, ptr %l80, !tbaa !24
  %t139 = icmp slt i64 %t137, %t138
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 62
  store ptr %t143, ptr %l83, !tbaa !29
  %t144 = load i64, ptr %l11, !tbaa !24
  store i64 %t144, ptr %l84, !tbaa !24
  %t145 = load ptr, ptr %l2, !tbaa !29
  %t147 = getelementptr %"compiler/check:frame", ptr %t145, i32 0, i32 62
  %t148 = load i64, ptr %l11, !tbaa !24
  %t151 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %v0, ptr %t147, i64 %t148)
  store %"compiler/check:errNarrow" %t151, ptr %l88
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t152 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyCalled, !tbaa !24
  %t153 = load %"compiler/check:errNarrow", ptr %l88
  %t155 = call %"compiler/check:errNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3aerrNarrow_2eKilled(ptr %v0, ptr %v0, %"compiler/check:errNarrow" %t153, i64 %t152)
  store %"compiler/check:errNarrow" %t155, ptr %l90
  br label %bb46
bb46:
  %t156 = load ptr, ptr %l83, !tbaa !29
  %t157 = load i64, ptr %l84, !tbaa !24
  %t158 = load %"compiler/check:errNarrow", ptr %l90
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %v0, ptr %t156, i64 %t157, %"compiler/check:errNarrow" %t158)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t159 = load i64, ptr %l10, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l10, !tbaa !24
  br label %bb36
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHoldLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:laneNode"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i1
  %l30 = alloca %"compiler/check:laneNode"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l42 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l73 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t143 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %s0, ptr %t3, i64 %a1, ptr %l3)
  br label %bb2
bb2:
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t10)
  store i64 %t12, ptr %l17
  br label %bb4
bb4:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l17, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb59
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l22
  br label %bb8
bb8:
  %t24 = load i64, ptr %l22, !tbaa !24
  store i64 %t24, ptr %l6, !tbaa !24
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/check:laneVals", ptr %t25, i32 0, i32 2
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v1, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l26
  br label %bb9
bb9:
  %t32 = load i1, ptr %l26, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb58
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 47
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store %"compiler/check:laneNode" %t39, ptr %l30
  br label %bb13
bb13:
  %t40 = load %"compiler/check:laneNode", ptr %l30
  store %"compiler/check:laneNode" %t40, ptr %l7
  %t41 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t46 = icmp eq i64 %t42, %t43
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/check:laneVals", ptr %t48, i32 0, i32 2
  store ptr %t50, ptr %l35, !tbaa !29
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l36, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l37, !tbaa !29
  %t53 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 2
  %t54 = load %"compiler/source:Span", ptr %t53
  store %"compiler/source:Span" %t54, ptr %l38
  %t55 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb16, label %bb17
bb15:
  br label %bb21
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d04702acd6c67beb_c6baeec7be1e7af7)
  unreachable
bb17:
  br label %bb18
bb18:
  %t60 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l38
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v0, ptr %t62, %"compiler/source:Span" %t63, ptr %t61)
  store i64 %t65, ptr %l42
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = load i64, ptr %l36, !tbaa !24
  %t68 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t66, i64 %t67, i64 %t68)
  br label %bb20
bb20:
  br label %bb58
bb21:
  %t69 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = icmp eq ptr %t70, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_57a7d7e6d1174c7c_73fda2027ad2ad8)
  unreachable
bb23:
  br label %bb24
bb24:
  %t74 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l8, !tbaa !29
  %t77 = load ptr, ptr %l8, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t78 = load ptr, ptr %l46, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb25, label %bb26
bb25:
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 0
  store i1 %t84, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t85 = load i1, ptr %l47, !tbaa !21
  br i1 %t85, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t86 = load ptr, ptr %l8, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t87 = load ptr, ptr %l50, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 18}
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l51, !tbaa !21
  br label %bb30
bb30:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb57
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb56
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = icmp eq ptr %t96, null
  br i1 %t98, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_fd3b2969d106d871_acdc32576a39b9ed)
  unreachable
bb39:
  br label %bb40
bb40:
  %t100 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %s6, ptr %t101)
  store ptr %t103, ptr %l57
  br label %bb41
bb41:
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = call i64 @compiler_2fcheck_2elocalIdOf(ptr %s6, ptr %t104)
  store i64 %t105, ptr %l58
  br label %bb42
bb42:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l9, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = icmp slt i64 %t107, 0
  br i1 %t109, label %bb43, label %bb44
bb43:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l61, !tbaa !29
  %t112 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 2
  %t113 = load %"compiler/source:Span", ptr %t112
  store %"compiler/source:Span" %t113, ptr %l62
  %t114 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = icmp eq ptr %t115, null
  br i1 %t117, label %bb45, label %bb46
bb44:
  br label %bb54
bb45:
  call void @__olang_check_failed(ptr @olang_loc_9336e0175c2e9c6a_aabb9d2690ac9706)
  unreachable
bb46:
  br label %bb47
bb47:
  %t119 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t123 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t120)
  store i32 %t123, ptr %l67
  br label %bb48
bb48:
  %t124 = load ptr, ptr %l61, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l62
  %t126 = load i32, ptr %l67, !tbaa !23
  %t127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t124, %"compiler/source:Span" %t125, i32 %t126)
  store i64 %t127, ptr %l68
  br label %bb49
bb49:
  %t128 = load i64, ptr %l68, !tbaa !24
  store i64 %t128, ptr %l9, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l69, !tbaa !29
  %t130 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 2
  %t131 = load %"compiler/source:Span", ptr %t130
  store %"compiler/source:Span" %t131, ptr %l70
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = trunc i64 %t132 to i32
  store i32 %t134, ptr %l73, !tbaa !23
  %t136 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  br i1 %t139, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_12a21cc2c4eb057_a597a544841c60b)
  unreachable
bb51:
  br label %bb52
bb52:
  %t141 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t142 = load ptr, ptr %t141, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 0
  store i64 0, ptr %t144
  %t145 = load %"compiler/source:Span", ptr %l70
  %t146 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t145, 0
  %t147 = load i32, ptr %l73, !tbaa !23
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr } %t146, i32 %t147, 1
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr } %t148, ptr %t142, 2
  %t151 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t150, ptr %t151
  %t152 = load { i64, [3 x i64] }, ptr %t143
  %t154 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t152, ptr %t154
  %t155 = load ptr, ptr %l69, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t155, ptr %t154)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/check:laneVals", ptr %t157, i32 0, i32 2
  %t160 = load i64, ptr %l6, !tbaa !24
  %t161 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t159, i64 %t160, i64 %t161)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_286fe13485cd942f_1c0d0a1e63f5e7b3)
  unreachable
bb57:
  br label %bb58
bb58:
  %t165 = load i64, ptr %l5, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l5, !tbaa !24
  br label %bb3
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t23)
  store i1 %t25, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l18, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t28, 1
  %t32 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t35)
  store i1 %t37, ptr %l22
  br label %bb8
bb8:
  %t38 = load i1, ptr %l22, !tbaa !21
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t41, 1
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = icmp eq i8 %t48, 95
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l23, !tbaa !21
  store i1 %t52, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l11, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = sub i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t66 = icmp eq i64 %t60, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t68, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load i64, ptr %l3, !tbaa !24
  %t74 = trunc i64 %t72 to i32
  %t77 = add i32 %t71, %t74
  %t78 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t82 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t77, i32 %t79)
  store %"compiler/source:Span" %t82, ptr %l42
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleadWord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l31 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp slt i64 %t7, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t21)
  store i1 %t23, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb5:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 %t26
  %t31 = load i8, ptr %t30, !tbaa !32
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t31)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t44 = icmp eq i8 %t42, 95
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l21, !tbaa !21
  store i1 %t46, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l11, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = trunc i64 %t62 to i32
  %t67 = add i32 %t61, %t64
  %t70 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t59, i32 %t67)
  store %"compiler/source:Span" %t70, ptr %l37
  br label %bb21
bb20:
  %t71 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t71, ptr %l31
  br label %bb22
bb21:
  %t73 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t73, ptr %l31
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t74, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elendsPacked(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/diagmsg:Msg"
  %l16 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epackedPart(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store %"compiler/source:Span" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t6, ptr %l3
  %t7 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l11
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l3
  %t19 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t15, %"compiler/source:Span" %t16)
  store { i64, ptr } %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t21 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedLend(ptr %v0, ptr %v0, { i64, ptr } %t20)
  store %"compiler/diagmsg:Msg" %t21, ptr %l15
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l10, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l11
  %t24 = load %"compiler/diagmsg:Msg", ptr %l15
  %t25 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t22, %"compiler/source:Span" %t23, %"compiler/diagmsg:Msg" %t24)
  store i64 %t25, ptr %l16
  br label %bb7
bb7:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l4 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  store i32 %a4, ptr %l4
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %a3)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l7, !tbaa !23
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l8, !tbaa !23
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l8, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t19 = load i1, ptr %l20, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l17, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l7, !tbaa !23
  %t25 = load i32, ptr %l4, !range !{i32 0, i32 113}
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %t23, i32 %t24, i32 %t25)
  store i32 %t29, ptr %l25
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l8, !tbaa !23
  br label %bb10
bb10:
  %t31 = load i1, ptr %l6, !tbaa !21
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l8, !tbaa !23
  %t39 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb14
bb13:
  %t40 = load i1, ptr %l31, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t46 = load i32, ptr %l4, !range !{i32 0, i32 113}
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %t44, i32 %t45, i32 %t46)
  store i32 %t50, ptr %l36
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t51 = load i32, ptr %l36, !tbaa !23
  store i32 %t51, ptr %l8, !tbaa !23
  br label %bb18
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/check:litv", ptr %l2
  %t54 = load i32, ptr %l8, !tbaa !23
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t52, %"compiler/check:litv" %t53, i32 %t54)
  store i1 %t58, ptr %l40
  br label %bb19
bb19:
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load %"compiler/check:litv", ptr %l2
  %t63 = load i32, ptr %l8, !tbaa !23
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v3, ptr %t60, ptr %t61, %"compiler/check:litv" %t62, i32 %t63)
  store ptr %t68, ptr %l46
  br label %bb22
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = load %"compiler/check:litv", ptr %l2
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v3, ptr %t69, ptr %t70, %"compiler/check:litv" %t71, i32 %t72)
  store ptr %t77, ptr %l51
  br label %bb23
bb22:
  %t78 = load ptr, ptr %l46, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  br label %bb24
bb23:
  %t79 = load ptr, ptr %l51, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  br label %bb24
bb24:
  %t80 = load ptr, ptr %l41, !tbaa !29
  store ptr %t80, ptr %l9, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/check:litv", ptr %l2
  %t83 = load i32, ptr %l8, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t81, %"compiler/check:litv" %t82, i32 %t83)
  store i1 %t87, ptr %l55
  br label %bb25
bb25:
  %t88 = load i1, ptr %l55, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l58, !tbaa !29
  store %"compiler/source:Span" %a5, ptr %l59
  %t93 = load i32, ptr %l7, !tbaa !23
  store i32 %t93, ptr %l60, !tbaa !23
  %t94 = load ptr, ptr %l9, !tbaa !29
  %t97 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t94)
  store i32 %t97, ptr %l63
  br label %bb28
bb27:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb30
bb28:
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l59
  %t100 = load i32, ptr %l60, !tbaa !23
  %t101 = load i32, ptr %l63, !tbaa !23
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t100, i32 %t101)
  store i1 %t102, ptr %l64
  br label %bb29
bb29:
  %t103 = load i1, ptr %l64, !tbaa !21
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb30
bb30:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb31, label %bb32
bb31:
  store ptr null, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l9, !tbaa !29
  store ptr %t106, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:litBuilder" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBuilder(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i1
  %l13 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"compiler/diagmsg:Msg"
  %l23 = alloca i64
  %l25 = alloca %"compiler/check:litBuilder"
  %l27 = alloca ptr
  %l28 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/diagmsg:Msg"
  %l45 = alloca i64
  %l47 = alloca %"compiler/check:litBuilder"
  %l55 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l63 = alloca { i64, ptr }
  %l65 = alloca %"compiler/diagmsg:Msg"
  %l66 = alloca i64
  %l68 = alloca %"compiler/check:litBuilder"
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l85 = alloca i64
  %l87 = alloca %"compiler/check:litBuilder"
  %l90 = alloca %"compiler/check:litBuilder"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/check:litBuilder"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t19 = trunc i64 29 to i32
  %t20 = icmp eq i32 %t17, %t19
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l17
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l20
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t30 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNotMade(ptr %s1, ptr %v0, { i64, ptr } %t36)
  store %"compiler/diagmsg:Msg" %t38, ptr %l22
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l16, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l17
  %t41 = load %"compiler/diagmsg:Msg", ptr %l22
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t39, %"compiler/source:Span" %t40, %"compiler/diagmsg:Msg" %t41)
  store i64 %t42, ptr %l23
  br label %bb10
bb10:
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = call %"compiler/check:litBuilder" @compiler_2fcheck_3alitBuilder_2ector(ptr %s1, i64 -1, i32 %t43)
  store %"compiler/check:litBuilder" %t45, ptr %l25
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t46 = load %"compiler/check:litBuilder", ptr %l25
  store %"compiler/check:litBuilder" %t46, ptr %rv
  br label %ret
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l27, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  store i32 %t51, ptr %l28, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/load:Loader", ptr %t58, i32 0, i32 3
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t61, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t63, ptr %l33
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l27, !tbaa !29
  %t65 = load i32, ptr %l28, !tbaa !23
  %t66 = load i32, ptr %l33, !tbaa !23
  %t67 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t64, i32 %t65, i32 %t66, i1 false)
  store i64 %t67, ptr %l34
  br label %bb14
bb14:
  %t68 = load i64, ptr %l34, !tbaa !24
  store i64 %t68, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = icmp slt i64 %t69, 0
  br i1 %t71, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l37, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t74, ptr %l38
  %t75 = load i32, ptr %l2, !tbaa !23
  store i32 %t75, ptr %l39, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t76, i32 %t77)
  store { i64, ptr } %t80, ptr %l42
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t81 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  %t83 = extractvalue { i64, ptr } %t81, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t89 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNoFromIter(ptr %s2, ptr %v0, { i64, ptr } %t87)
  store %"compiler/diagmsg:Msg" %t89, ptr %l44
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l37, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l38
  %t92 = load i32, ptr %l39, !tbaa !23
  %t93 = load %"compiler/diagmsg:Msg", ptr %l44
  %t94 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s2, ptr %v0, ptr %t90, %"compiler/source:Span" %t91, i32 %t92, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, %"compiler/diagmsg:Msg" %t93)
  store i64 %t94, ptr %l45
  br label %bb19
bb19:
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t97 = call %"compiler/check:litBuilder" @compiler_2fcheck_3alitBuilder_2ector(ptr %s2, i64 -1, i32 %t95)
  store %"compiler/check:litBuilder" %t97, ptr %l47
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load %"compiler/check:litBuilder", ptr %l47
  store %"compiler/check:litBuilder" %t98, ptr %rv
  br label %ret
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i64, ptr %l3, !tbaa !24
  %t101 = load %"compiler/source:Span", ptr %l1
  %t102 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %t99, i64 %t100, %"compiler/source:Span" %t101, i32 %t102)
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i64, ptr %l3, !tbaa !24
  %t109 = load i32, ptr %l2, !tbaa !23
  %t113 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efromIterElem(ptr %v0, ptr %t107, i64 %t108, i32 %t109)
  store i32 %t113, ptr %l55
  br label %bb23
bb23:
  %t114 = load i32, ptr %l55, !tbaa !23
  store i32 %t114, ptr %l4, !tbaa !23
  %t115 = load i32, ptr %l4, !tbaa !23
  %t116 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t119 = icmp eq i32 %t115, %t116
  br i1 %t119, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l59, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t122, ptr %l60
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l2, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t123, i32 %t124)
  store { i64, ptr } %t127, ptr %l63
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t128 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFromIterShape(ptr %s3, ptr %v0, { i64, ptr } %t134)
  store %"compiler/diagmsg:Msg" %t136, ptr %l65
  br label %bb27
bb27:
  %t137 = load ptr, ptr %l59, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l60
  %t139 = load %"compiler/diagmsg:Msg", ptr %l65
  %t140 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t137, %"compiler/source:Span" %t138, %"compiler/diagmsg:Msg" %t139)
  store i64 %t140, ptr %l66
  br label %bb28
bb28:
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t143 = call %"compiler/check:litBuilder" @compiler_2fcheck_3alitBuilder_2ector(ptr %s3, i64 -1, i32 %t141)
  store %"compiler/check:litBuilder" %t143, ptr %l68
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t144 = load %"compiler/check:litBuilder", ptr %l68
  store %"compiler/check:litBuilder" %t144, ptr %rv
  br label %ret
bb30:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l4, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l73
  br label %bb31
bb31:
  %t155 = load i1, ptr %l73, !tbaa !21
  br i1 %t155, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l74, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l75
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l2, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t158, i32 %t159)
  store { i64, ptr } %t162, ptr %l78
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t163 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  %t165 = extractvalue { i64, ptr } %t163, 1
  %t166 = mul i64 %t164, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t167, ptr %t165, i64 %t166, i1 false)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l79, !tbaa !27
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l4, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t170, i32 %t171)
  store { i64, ptr } %t174, ptr %l82
  br label %bb35
bb35:
  %t175 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t177 = extractvalue { i64, ptr } %t175, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  %t182 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t184 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralUnique(ptr %s4, ptr %s4, ptr %v0, { i64, ptr } %t182, { i64, ptr } %t181)
  store %"compiler/diagmsg:Msg" %t184, ptr %l84
  br label %bb36
bb36:
  %t185 = load ptr, ptr %l74, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l75
  %t187 = load %"compiler/diagmsg:Msg", ptr %l84
  %t188 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t185, %"compiler/source:Span" %t186, %"compiler/diagmsg:Msg" %t187)
  store i64 %t188, ptr %l85
  br label %bb37
bb37:
  %t189 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t191 = call %"compiler/check:litBuilder" @compiler_2fcheck_3alitBuilder_2ector(ptr %s4, i64 -1, i32 %t189)
  store %"compiler/check:litBuilder" %t191, ptr %l87
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t192 = load %"compiler/check:litBuilder", ptr %l87
  store %"compiler/check:litBuilder" %t192, ptr %rv
  br label %ret
bb39:
  %t193 = load i64, ptr %l3, !tbaa !24
  %t194 = load i32, ptr %l4, !tbaa !23
  %t197 = call %"compiler/check:litBuilder" @compiler_2fcheck_3alitBuilder_2ector(ptr %s0, i64 %t193, i32 %t194)
  store %"compiler/check:litBuilder" %t197, ptr %l90
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t198 = load %"compiler/check:litBuilder", ptr %l90
  store %"compiler/check:litBuilder" %t198, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litBuilder", ptr %rv
  ret %"compiler/check:litBuilder" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %lp36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l87 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i1
  %l104 = alloca i64
  %l107 = alloca i64
  %l125 = alloca { i64, ptr }
  %l134 = alloca i32
  %l135 = alloca i32
  %l138 = alloca { i64, ptr }
  %l142 = alloca %"compiler/source:Span"
  %l150 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/diagmsg:Msg"
  %l162 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca %"compiler/source:Span"
  %l171 = alloca %"compiler/diagmsg:Msg"
  %l174 = alloca { i64, ptr }
  %l176 = alloca %"compiler/diagmsg:Msg"
  %l179 = alloca { i64, ptr }
  %l181 = alloca %"compiler/diagmsg:Msg"
  %l182 = alloca i64
  %l190 = alloca ptr
  %l192 = alloca %"compiler/source:Span"
  %l193 = alloca %"compiler/diagmsg:Msg"
  %l194 = alloca i64
  %l210 = alloca ptr
  %l211 = alloca { i64, ptr }
  %l214 = alloca %"compiler/source:Span"
  %l215 = alloca i64
  %l218 = alloca { i64, ptr }
  %l220 = alloca %"compiler/diagmsg:Msg"
  %l221 = alloca i64
  %l229 = alloca i64
  %l232 = alloca i64
  %l257 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l265 = alloca i64
  %l268 = alloca i64
  %l290 = alloca ptr
  %l291 = alloca { i64, ptr }
  %l293 = alloca %"compiler/source:Span"
  %l305 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t38 = alloca i64
  %t582 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @compiler_2fcheck_2ehasNamed(ptr %v2, { i64, ptr } %t1)
  store i1 %t3, ptr %l45
  br label %bb1
bb1:
  %t4 = load i1, ptr %l45, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l50, !tbaa !24
  %t14 = load i64, ptr %l50, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l50, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  br i1 %t18, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2a22705e3675cc6a_15625908cbc104fe)
  unreachable
bb7:
  %t20 = load i64, ptr %l50, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t25, ptr %lp8
  %t27 = load ptr, ptr %lp8
  store { i64, ptr } %t24, ptr %t27, !tbaa !27
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l54, !tbaa !24
  %t29 = load i64, ptr %l54, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_2a22705e3675cc6a_15625908cbc104fe)
  unreachable
bb9:
  %t32 = load i64, ptr %l54, !tbaa !24
  %t33 = icmp sle i64 %t32, 1152921504606846975
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33)
  unreachable
bb11:
  %t35 = load i64, ptr %l54, !tbaa !24
  %t36 = mul i64 %t35, 8
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, %t35
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr i64, ptr %t37, i64 %t42
  store i64 -1, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t37, 1
  store { i64, ptr } %t47, ptr %l9, !tbaa !27
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l58, !tbaa !24
  %t50 = load i64, ptr %l58, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33)
  unreachable
bb13:
  %t53 = load i64, ptr %l58, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t63 = load i64, ptr %l12, !tbaa !24
  %t64 = load i64, ptr %l11, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f1d5d3b2155f2ddc_ad13ea37e14bc210)
  unreachable
bb15:
  %t69 = load i64, ptr %l13, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb20
bb17:
  %t73 = load i64, ptr %l12, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l13, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l13, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l69, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb19
bb19:
  %t89 = load i64, ptr %l69, !tbaa !24
  store i64 %t89, ptr %l66, !tbaa !24
  br label %bb20
bb20:
  %t90 = load i64, ptr %l66, !tbaa !24
  store i64 %t90, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l15, !tbaa !24
  %t92 = load i64, ptr %l14, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb22, label %bb23
bb22:
  br label %bb84
bb23:
  br label %bb24
bb24:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l15, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l16, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t109, ptr %l87, !tbaa !27
  %t110 = load i64, ptr %l16, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 %t110
  %t115 = load ptr, ptr %t114, !tbaa !39
  store ptr %t115, ptr %l17, !tbaa !29
  %t117 = load ptr, ptr %l17, !tbaa !29
  store ptr %t117, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t118 = load ptr, ptr %l90, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb25, label %bb26
bb25:
  %t121 = load ptr, ptr %l90, !tbaa !29
  %t122 = load i64, ptr %t121, !range !{i64 0, i64 28}
  %t124 = icmp eq i64 %t122, 24
  store i1 %t124, ptr %l91, !tbaa !21
  br label %bb26
bb26:
  %t125 = load i1, ptr %l91, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb27:
  %t126 = load ptr, ptr %l17, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t128, i32 0, i32 0
  %t130 = load %"compiler/source:Span", ptr %t129
  store %"compiler/source:Span" %t130, ptr %l18
  %t132 = load ptr, ptr %l17, !tbaa !29
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t134, i32 0, i32 1
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l19, !tbaa !23
  %t138 = load ptr, ptr %l17, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l20, !tbaa !29
  br label %bb29
bb28:
  br label %bb68
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l6, !tbaa !21
  store i64 -1, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  %t144 = load i64, ptr %l4, !tbaa !24
  store i64 %t144, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t146 = load i64, ptr %l23, !tbaa !24
  %t147 = load i64, ptr %l22, !tbaa !24
  %t150 = icmp sgt i64 %t146, %t147
  br i1 %t150, label %bb30, label %bb31
bb30:
  %t152 = load i64, ptr %l24, !tbaa !24
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb35
bb32:
  %t156 = load i64, ptr %l23, !tbaa !24
  %t157 = load i64, ptr %l22, !tbaa !24
  %t160 = sub i64 %t156, %t157
  %t161 = load i64, ptr %l24, !tbaa !24
  %t164 = add i64 %t160, %t161
  %t166 = sub i64 %t164, 1
  %t167 = load i64, ptr %l24, !tbaa !24
  %t170 = sdiv i64 %t166, %t167
  store i64 %t170, ptr %l107, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb34
bb34:
  %t172 = load i64, ptr %l107, !tbaa !24
  store i64 %t172, ptr %l104, !tbaa !24
  br label %bb35
bb35:
  %t173 = load i64, ptr %l104, !tbaa !24
  store i64 %t173, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb36
bb36:
  %t174 = load i64, ptr %l26, !tbaa !24
  %t175 = load i64, ptr %l25, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb37, label %bb38
bb37:
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t182 = load i64, ptr %l22, !tbaa !24
  %t183 = load i64, ptr %l26, !tbaa !24
  %t184 = load i64, ptr %l24, !tbaa !24
  %t187 = mul i64 %t183, %t184
  %t190 = add i64 %t182, %t187
  store i64 %t190, ptr %l27, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t192, ptr %l125, !tbaa !27
  %t193 = load i64, ptr %l27, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr ptr, ptr %t196, i64 %t193
  %t198 = load ptr, ptr %t197, !tbaa !39
  %t200 = getelementptr %"compiler/ast:Param", ptr %t198, i32 0, i32 1
  %t201 = load i32, ptr %t200, !tbaa !23
  %t202 = load i32, ptr %l19, !tbaa !23
  %t205 = icmp eq i32 %t201, %t202
  br i1 %t205, label %bb40, label %bb41
bb40:
  %t207 = load i64, ptr %l27, !tbaa !24
  store i64 %t207, ptr %l21, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t209 = load i64, ptr %l26, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l26, !tbaa !24
  br label %bb36
bb44:
  %t213 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t214 = load i32, ptr %t213, !tbaa !23
  store i32 %t214, ptr %l134, !tbaa !23
  %t215 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t216 = load i32, ptr %t215, !tbaa !23
  store i32 %t216, ptr %l135, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l19, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s4, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l138
  br label %bb45
bb45:
  %t222 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t225 = trunc i64 %t223 to i32
  %t226 = load i32, ptr %l135, !tbaa !23
  %t228 = add i32 %t226, %t225
  %t229 = load i32, ptr %l134, !tbaa !23
  %t231 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t229, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l142
  br label %bb46
bb46:
  %t232 = load %"compiler/source:Span", ptr %l142
  store %"compiler/source:Span" %t232, ptr %l28
  %t233 = load i64, ptr %l21, !tbaa !24
  %t235 = icmp slt i64 %t233, 0
  br i1 %t235, label %bb47, label %bb48
bb47:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l28
  %t239 = load i32, ptr %l19, !tbaa !23
  %t240 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgUnknown(ptr %v0, ptr %v1, ptr %v3, ptr %t237, %"compiler/source:Span" %t238, i32 %t239, { i64, ptr } %t240, { i64, ptr } %a3)
  br label %bb49
bb48:
  %t247 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t247, ptr %l150, !tbaa !27
  %t248 = load i64, ptr %l21, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr ptr, ptr %t251, i64 %t248
  %t253 = load ptr, ptr %t252, !tbaa !39
  %t255 = getelementptr %"compiler/ast:Param", ptr %t253, i32 0, i32 3
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = icmp eq ptr %t256, null
  br i1 %t258, label %bb50, label %bb51
bb49:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb67
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l155, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t261, ptr %l156
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i32, ptr %l19, !tbaa !23
  %t266 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s11, ptr %t262, i32 %t263)
  store { i64, ptr } %t266, ptr %l159
  br label %bb52
bb51:
  %t267 = load i64, ptr %l21, !tbaa !24
  %t268 = load ptr, ptr %lp8
  %t270 = getelementptr { i64, ptr }, ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr ptr, ptr %t271, i64 %t267
  %t273 = load ptr, ptr %t272, !tbaa !39
  %t275 = icmp eq ptr %t273, null
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb55, label %bb56
bb52:
  %t279 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  %t281 = extractvalue { i64, ptr } %t279, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t287 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %s11, ptr %v0, { i64, ptr } %t285)
  store %"compiler/diagmsg:Msg" %t287, ptr %l161
  br label %bb53
bb53:
  %t288 = load ptr, ptr %l155, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l156
  %t290 = load %"compiler/diagmsg:Msg", ptr %l161
  %t291 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t288, %"compiler/source:Span" %t289, %"compiler/diagmsg:Msg" %t290)
  store i64 %t291, ptr %l162
  br label %bb54
bb54:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb55:
  store %olang.scope zeroinitializer, ptr %s13
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l167, !tbaa !29
  %t293 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t293, ptr %l168
  %t294 = load i64, ptr %l21, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i1, ptr %t297, i64 %t294
  %t299 = load i1, ptr %t298, !tbaa !31
  br i1 %t299, label %bb57, label %bb58
bb56:
  %t301 = load i64, ptr %l21, !tbaa !24
  %t302 = load ptr, ptr %l20, !tbaa !29
  %t305 = load ptr, ptr %lp8
  %t307 = getelementptr { i64, ptr }, ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr ptr, ptr %t308, i64 %t301
  store ptr %t302, ptr %t309, !tbaa !39
  %t310 = load i64, ptr %l21, !tbaa !24
  %t311 = load i64, ptr %l16, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr i64, ptr %t315, i64 %t310
  store i64 %t311, ptr %t316, !tbaa !34
  %t317 = load i64, ptr %l21, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr i1, ptr %t320, i64 %t317
  store i1 true, ptr %t321, !tbaa !31
  br label %bb65
bb57:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l19, !tbaa !23
  %t326 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t322, i32 %t323)
  store { i64, ptr } %t326, ptr %l174
  br label %bb59
bb58:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i32, ptr %l19, !tbaa !23
  %t331 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t327, i32 %t328)
  store { i64, ptr } %t331, ptr %l179
  br label %bb61
bb59:
  %t332 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 0
  %t334 = extractvalue { i64, ptr } %t332, 1
  %t335 = mul i64 %t333, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t335)
  call void @llvm.memcpy.p0.p0.i64(ptr %t336, ptr %t334, i64 %t335, i1 false)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  %t340 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgTwice(ptr %s13, ptr %v0, { i64, ptr } %t338)
  store %"compiler/diagmsg:Msg" %t340, ptr %l176
  br label %bb60
bb60:
  %t341 = load %"compiler/diagmsg:Msg", ptr %l176
  store %"compiler/diagmsg:Msg" %t341, ptr %l171
  br label %bb63
bb61:
  %t342 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 0
  %t344 = extractvalue { i64, ptr } %t342, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  %t350 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %s13, ptr %v0, { i64, ptr } %t348)
  store %"compiler/diagmsg:Msg" %t350, ptr %l181
  br label %bb62
bb62:
  %t351 = load %"compiler/diagmsg:Msg", ptr %l181
  store %"compiler/diagmsg:Msg" %t351, ptr %l171
  br label %bb63
bb63:
  %t352 = load ptr, ptr %l167, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l168
  %t354 = load %"compiler/diagmsg:Msg", ptr %l171
  %t355 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t352, %"compiler/source:Span" %t353, %"compiler/diagmsg:Msg" %t354)
  store i64 %t355, ptr %l182
  br label %bb64
bb64:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb82
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t356 = load i1, ptr %l6, !tbaa !21
  br i1 %t356, label %bb72, label %bb73
bb72:
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l190, !tbaa !29
  %t359 = load ptr, ptr %l17, !tbaa !29
  %t361 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t359)
  store %"compiler/source:Span" %t361, ptr %l192
  br label %bb74
bb73:
  %t362 = load i64, ptr %l5, !tbaa !24
  %t363 = load i64, ptr %l4, !tbaa !24
  %t366 = icmp slt i64 %t362, %t363
  br i1 %t366, label %bb77, label %bb78
bb74:
  %t368 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePositionalAfterNamed(ptr %v0)
  store %"compiler/diagmsg:Msg" %t368, ptr %l193
  br label %bb75
bb75:
  %t369 = load ptr, ptr %l190, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l192
  %t371 = load %"compiler/diagmsg:Msg", ptr %l193
  %t372 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t369, %"compiler/source:Span" %t370, %"compiler/diagmsg:Msg" %t371)
  store i64 %t372, ptr %l194
  br label %bb76
bb76:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb80
bb77:
  %t373 = load i64, ptr %l5, !tbaa !24
  %t374 = load ptr, ptr %l17, !tbaa !29
  %t377 = load ptr, ptr %lp8
  %t379 = getelementptr { i64, ptr }, ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !27
  %t381 = getelementptr ptr, ptr %t380, i64 %t373
  store ptr %t374, ptr %t381, !tbaa !39
  %t382 = load i64, ptr %l5, !tbaa !24
  %t383 = load i64, ptr %l16, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i64, ptr %t387, i64 %t382
  store i64 %t383, ptr %t388, !tbaa !34
  br label %bb79
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t389 = load i64, ptr %l5, !tbaa !24
  %t391 = add i64 %t389, 1
  store i64 %t391, ptr %l5, !tbaa !24
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_6a354e0ae5aa0db2_42d5d79e5424950e)
  unreachable
bb82:
  br label %bb83
bb83:
  %t393 = load i64, ptr %l15, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l15, !tbaa !24
  br label %bb21
bb84:
  %t397 = load i64, ptr %l5, !tbaa !24
  %t398 = load i64, ptr %l4, !tbaa !24
  %t401 = icmp sgt i64 %t397, %t398
  br i1 %t401, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s20
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l210, !tbaa !29
  %t404 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t404, ptr %l211, !tbaa !27
  %t405 = load i64, ptr %l4, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr ptr, ptr %t408, i64 %t405
  %t410 = load ptr, ptr %t409, !tbaa !39
  %t412 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t410)
  store %"compiler/source:Span" %t412, ptr %l214
  br label %bb87
bb86:
  br label %bb93
bb87:
  %t413 = load i64, ptr %l4, !tbaa !24
  store i64 %t413, ptr %l215, !tbaa !24
  %t414 = load i64, ptr %l4, !tbaa !24
  %t416 = icmp eq i64 %t414, 1
  br i1 %t416, label %bb88, label %bb89
bb88:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l218, !tbaa !27
  br label %bb90
bb89:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l218, !tbaa !27
  br label %bb90
bb90:
  %t418 = load i64, ptr %l5, !tbaa !24
  %t419 = load i64, ptr %l215, !tbaa !24
  %t420 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t422 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s20, ptr %v0, i64 %t419, { i64, ptr } %t420, i64 %t418)
  store %"compiler/diagmsg:Msg" %t422, ptr %l220
  br label %bb91
bb91:
  %t423 = load ptr, ptr %l210, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l214
  %t425 = load %"compiler/diagmsg:Msg", ptr %l220
  %t426 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t423, %"compiler/source:Span" %t424, %"compiler/diagmsg:Msg" %t425)
  store i64 %t426, ptr %l221
  br label %bb92
bb92:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s20)
  br label %bb93
bb93:
  %t427 = load i1, ptr %l7, !tbaa !21
  br i1 %t427, label %bb94, label %bb95
bb94:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/check:Checker", ptr %t429, i32 0, i32 170
  store i1 true, ptr %t431, !tbaa !21
  %t432 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t432, ptr %rv
  br label %ret
bb95:
  br label %bb96
bb96:
  store i64 -1, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  %t434 = load i64, ptr %l4, !tbaa !24
  store i64 %t434, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t436 = load i64, ptr %l31, !tbaa !24
  %t437 = load i64, ptr %l30, !tbaa !24
  %t440 = icmp sgt i64 %t436, %t437
  br i1 %t440, label %bb97, label %bb98
bb97:
  %t442 = load i64, ptr %l32, !tbaa !24
  %t444 = icmp sgt i64 %t442, 0
  br i1 %t444, label %bb99, label %bb100
bb98:
  store i64 0, ptr %l229, !tbaa !24
  br label %bb102
bb99:
  %t446 = load i64, ptr %l31, !tbaa !24
  %t447 = load i64, ptr %l30, !tbaa !24
  %t450 = sub i64 %t446, %t447
  %t451 = load i64, ptr %l32, !tbaa !24
  %t454 = add i64 %t450, %t451
  %t456 = sub i64 %t454, 1
  %t457 = load i64, ptr %l32, !tbaa !24
  %t460 = sdiv i64 %t456, %t457
  store i64 %t460, ptr %l232, !tbaa !24
  br label %bb101
bb100:
  store i64 0, ptr %l232, !tbaa !24
  br label %bb101
bb101:
  %t462 = load i64, ptr %l232, !tbaa !24
  store i64 %t462, ptr %l229, !tbaa !24
  br label %bb102
bb102:
  %t463 = load i64, ptr %l229, !tbaa !24
  store i64 %t463, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb103
bb103:
  %t464 = load i64, ptr %l34, !tbaa !24
  %t465 = load i64, ptr %l33, !tbaa !24
  %t468 = icmp slt i64 %t464, %t465
  %t470 = xor i1 %t468, true
  br i1 %t470, label %bb104, label %bb105
bb104:
  br label %bb111
bb105:
  br label %bb106
bb106:
  %t472 = load i64, ptr %l30, !tbaa !24
  %t473 = load i64, ptr %l34, !tbaa !24
  %t474 = load i64, ptr %l32, !tbaa !24
  %t477 = mul i64 %t473, %t474
  %t480 = add i64 %t472, %t477
  store i64 %t480, ptr %l35, !tbaa !24
  %t482 = load i64, ptr %l35, !tbaa !24
  %t483 = load ptr, ptr %lp8
  %t485 = getelementptr { i64, ptr }, ptr %t483, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr ptr, ptr %t486, i64 %t482
  %t488 = load ptr, ptr %t487, !tbaa !39
  %t490 = icmp eq ptr %t488, null
  %t492 = xor i1 %t490, true
  br i1 %t492, label %bb107, label %bb108
bb107:
  %t494 = load i64, ptr %l35, !tbaa !24
  store i64 %t494, ptr %l29, !tbaa !24
  br label %bb109
bb108:
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t496 = load i64, ptr %l34, !tbaa !24
  %t498 = add i64 %t496, 1
  store i64 %t498, ptr %l34, !tbaa !24
  br label %bb103
bb111:
  %t500 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t500, ptr %l257
  br label %bb112
bb112:
  %t501 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t501, ptr %lp36
  %t502 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l257
  %t503 = load ptr, ptr %lp36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t502, ptr %t503
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/check:Checker", ptr %t504, i32 0, i32 171
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t506)
  br label %bb113
bb113:
  store i64 0, ptr %l37, !tbaa !24
  %t508 = load i64, ptr %l29, !tbaa !24
  %t510 = add i64 %t508, 1
  store i64 %t510, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t512 = load i64, ptr %l38, !tbaa !24
  %t513 = load i64, ptr %l37, !tbaa !24
  %t516 = icmp sgt i64 %t512, %t513
  br i1 %t516, label %bb114, label %bb115
bb114:
  %t518 = load i64, ptr %l39, !tbaa !24
  %t520 = icmp sgt i64 %t518, 0
  br i1 %t520, label %bb116, label %bb117
bb115:
  store i64 0, ptr %l265, !tbaa !24
  br label %bb119
bb116:
  %t522 = load i64, ptr %l38, !tbaa !24
  %t523 = load i64, ptr %l37, !tbaa !24
  %t526 = sub i64 %t522, %t523
  %t527 = load i64, ptr %l39, !tbaa !24
  %t530 = add i64 %t526, %t527
  %t532 = sub i64 %t530, 1
  %t533 = load i64, ptr %l39, !tbaa !24
  %t536 = sdiv i64 %t532, %t533
  store i64 %t536, ptr %l268, !tbaa !24
  br label %bb118
bb117:
  store i64 0, ptr %l268, !tbaa !24
  br label %bb118
bb118:
  %t538 = load i64, ptr %l268, !tbaa !24
  store i64 %t538, ptr %l265, !tbaa !24
  br label %bb119
bb119:
  %t539 = load i64, ptr %l265, !tbaa !24
  store i64 %t539, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb120
bb120:
  %t540 = load i64, ptr %l41, !tbaa !24
  %t541 = load i64, ptr %l40, !tbaa !24
  %t544 = icmp slt i64 %t540, %t541
  %t546 = xor i1 %t544, true
  br i1 %t546, label %bb121, label %bb122
bb121:
  br label %bb132
bb122:
  br label %bb123
bb123:
  %t548 = load i64, ptr %l37, !tbaa !24
  %t549 = load i64, ptr %l41, !tbaa !24
  %t550 = load i64, ptr %l39, !tbaa !24
  %t553 = mul i64 %t549, %t550
  %t556 = add i64 %t548, %t553
  store i64 %t556, ptr %l42, !tbaa !24
  %t558 = load i64, ptr %l42, !tbaa !24
  %t559 = load ptr, ptr %lp8
  %t561 = getelementptr { i64, ptr }, ptr %t559, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = getelementptr ptr, ptr %t562, i64 %t558
  %t564 = load ptr, ptr %t563, !tbaa !39
  store ptr %t564, ptr %l43, !tbaa !29
  %t566 = load ptr, ptr %l43, !tbaa !29
  %t568 = icmp eq ptr %t566, null
  br i1 %t568, label %bb124, label %bb125
bb124:
  %t570 = load ptr, ptr %lp36
  store ptr %t570, ptr %l290, !tbaa !29
  %t571 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t571, ptr %l291, !tbaa !27
  %t572 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr ptr, ptr %t573, i64 0
  %t575 = load ptr, ptr %t574, !tbaa !39
  %t577 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t575)
  store %"compiler/source:Span" %t577, ptr %l293
  br label %bb126
bb125:
  %t578 = load ptr, ptr %lp36
  %t579 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t578, ptr %t579)
  br label %bb128
bb126:
  store { i64, [4 x i64] } zeroinitializer, ptr %t582
  %t583 = getelementptr { i64, [4 x i64] }, ptr %t582, i32 0, i32 0
  store i64 23, ptr %t583
  %t584 = load %"compiler/source:Span", ptr %l293
  %t585 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t584, 0
  %t586 = getelementptr { i64, [4 x i64] }, ptr %t582, i32 0, i32 1
  store { %"compiler/source:Span" } %t585, ptr %t586
  %t587 = load { i64, [4 x i64] }, ptr %t582
  %t589 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t587, ptr %t589
  %t590 = load ptr, ptr %l290, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t590, ptr %t589)
  br label %bb127
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t594 = getelementptr %"compiler/check:Checker", ptr %t592, i32 0, i32 171
  %t595 = load i64, ptr %l42, !tbaa !24
  %t597 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t598 = load ptr, ptr %t597, !tbaa !27
  %t599 = getelementptr i64, ptr %t598, i64 %t595
  %t600 = load i64, ptr %t599, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t594, i64 %t600)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t603 = load i64, ptr %l41, !tbaa !24
  %t605 = add i64 %t603, 1
  store i64 %t605, ptr %l41, !tbaa !24
  br label %bb120
bb132:
  %t607 = load ptr, ptr %lp36
  %t609 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t607)
  store { i64, ptr } %t609, ptr %l305
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s0)
  %t610 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t610, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca %"compiler/source:Span"
  %l16 = alloca { i64, ptr }
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t22, ptr %l13
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l16
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = load %"compiler/source:Span", ptr %l13
  %t32 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t30, i64 %t29)
  store %"compiler/source:Span" %t32, ptr %l18
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t33 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t33, ptr %rv
  br label %ret
bb8:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 28}
  %t41 = icmp eq i64 %t39, 13
  store i1 %t41, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketOf(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store %"compiler/source:Span" %t53, ptr %l27
  br label %bb14
bb14:
  %t54 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t54, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t59 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  store %"compiler/source:Span" %t59, ptr %l30
  br label %bb19
bb19:
  %t60 = load %"compiler/source:Span", ptr %l30
  store %"compiler/source:Span" %t60, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e993077ed681d47d_7cf2fdb3e0a34b99)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l20 = alloca i32
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i32
  %l39 = alloca i1
  %l41 = alloca i1
  %l46 = alloca i1
  %l51 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca i1
  %l67 = alloca i32
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l113 = alloca { i64, ptr }
  %l116 = alloca i1
  %l117 = alloca i1
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca i1
  %l135 = alloca i32
  %l137 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i32
  %l152 = alloca i32
  %l153 = alloca i1
  %l156 = alloca ptr
  %l160 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l170 = alloca { i64, ptr }
  %l171 = alloca %"compiler/diagmsg:Msg"
  %l172 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load i32, ptr %l20, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l23, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l28
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l23, !tbaa !29
  %t27 = load i32, ptr %l28, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l29
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l34, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 0
  %t41 = load i32, ptr %t40, !tbaa !33
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t36, i32 %t41)
  store i32 %t44, ptr %l36
  br label %bb7
bb7:
  %t45 = load i32, ptr %l36, !tbaa !23
  store i32 %t45, ptr %l4, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l4, !tbaa !23
  %t50 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l39
  br label %bb8
bb8:
  %t51 = load i1, ptr %l39, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb12
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l4, !tbaa !23
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l46
  br label %bb11
bb11:
  %t64 = load i1, ptr %l46, !tbaa !21
  %t65 = xor i1 %t64, true
  store i1 %t65, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t67 = load i1, ptr %l41, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l51
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l51, !tbaa !29
  store ptr %t76, ptr %l5, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t89 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %t80, i32 %t81, i32 %t85)
  store i64 %t89, ptr %l57
  br label %bb17
bb17:
  %t90 = load i64, ptr %l57, !tbaa !24
  store i64 %t90, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp slt i64 %t91, 0
  br i1 %t93, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  store i1 %t99, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t101 = load i1, ptr %l60, !tbaa !21
  br i1 %t101, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t105, i64 %t106)
  store i32 %t109, ptr %l67
  br label %bb24
bb24:
  %t110 = load i32, ptr %l67, !tbaa !23
  store i32 %t110, ptr %l7, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  store ptr %t116, ptr %l70, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l7, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l75
  br label %bb25
bb25:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = load i32, ptr %l75, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l76
  br label %bb26
bb26:
  %t130 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t130, ptr %l8, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp eq i64 %t133, %t136
  store i1 %t139, ptr %l9, !tbaa !21
  store i64 1, ptr %l10, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb27, label %bb28
bb27:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb32
bb29:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l12, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l90, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb31
bb31:
  %t171 = load i64, ptr %l90, !tbaa !24
  store i64 %t171, ptr %l87, !tbaa !24
  br label %bb32
bb32:
  %t172 = load i64, ptr %l87, !tbaa !24
  store i64 %t172, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  %t173 = load i64, ptr %l14, !tbaa !24
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb34, label %bb35
bb34:
  br label %bb49
bb35:
  br label %bb36
bb36:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t182 = load i64, ptr %l14, !tbaa !24
  %t183 = load i64, ptr %l12, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l15, !tbaa !24
  %t191 = load i1, ptr %l9, !tbaa !21
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb37, label %bb38
bb37:
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t201, ptr %l113, !tbaa !27
  %t202 = load i64, ptr %l15, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t200, i32 %t207)
  store i1 %t210, ptr %l116
  br label %bb40
bb40:
  %t211 = load i1, ptr %l116, !tbaa !21
  br i1 %t211, label %bb41, label %bb42
bb41:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  %t218 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t218, ptr %l121, !tbaa !27
  %t219 = load i64, ptr %l15, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr i32, ptr %t222, i64 %t219
  %t224 = load i32, ptr %t223, !tbaa !33
  %t225 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t225, ptr %l124, !tbaa !27
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i32, ptr %t229, i64 %t226
  %t231 = load i32, ptr %t230, !tbaa !33
  %t235 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t217, i32 %t224, i32 %t231)
  store i1 %t235, ptr %l127
  br label %bb43
bb42:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb44
bb43:
  %t236 = load i1, ptr %l127, !tbaa !21
  %t237 = xor i1 %t236, true
  store i1 %t237, ptr %l117, !tbaa !21
  br label %bb44
bb44:
  %t239 = load i1, ptr %l117, !tbaa !21
  br i1 %t239, label %bb45, label %bb46
bb45:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t240 = load i64, ptr %l14, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l14, !tbaa !24
  br label %bb33
bb49:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %l7, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t249, i32 %t250)
  store i32 %t253, ptr %l135
  br label %bb50
bb50:
  %t254 = load i32, ptr %l135, !tbaa !23
  store i32 %t254, ptr %l16, !tbaa !23
  %t255 = load i1, ptr %l9, !tbaa !21
  br i1 %t255, label %bb51, label %bb52
bb51:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/generic:Program", ptr %t260, i32 0, i32 2
  %t263 = load i32, ptr %l16, !tbaa !23
  %t266 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t262, i32 %t263)
  store i1 %t266, ptr %l142
  br label %bb53
bb52:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb54
bb53:
  %t267 = load i1, ptr %l142, !tbaa !21
  store i1 %t267, ptr %l137, !tbaa !21
  br label %bb54
bb54:
  %t268 = load i1, ptr %l137, !tbaa !21
  br i1 %t268, label %bb55, label %bb56
bb55:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t272, i32 0, i32 2
  store ptr %t274, ptr %l146, !tbaa !29
  %t275 = load i32, ptr %l16, !tbaa !23
  store i32 %t275, ptr %l147, !tbaa !23
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/check:Checker", ptr %t276, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %l2, !tbaa !23
  %t285 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t281, i32 %t282)
  store i32 %t285, ptr %l152
  br label %bb57
bb56:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb59
bb57:
  %t286 = load ptr, ptr %l146, !tbaa !29
  %t287 = load i32, ptr %l147, !tbaa !23
  %t288 = load i32, ptr %l152, !tbaa !23
  %t289 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t286, i32 %t287, i32 %t288)
  store i1 %t289, ptr %l153
  br label %bb58
bb58:
  %t290 = load i1, ptr %l153, !tbaa !21
  %t291 = xor i1 %t290, true
  store i1 %t291, ptr %l143, !tbaa !21
  br label %bb59
bb59:
  %t293 = load i1, ptr %l143, !tbaa !21
  br i1 %t293, label %bb60, label %bb61
bb60:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t294 = load i1, ptr %l9, !tbaa !21
  br i1 %t294, label %bb63, label %bb64
bb63:
  br label %ret
bb64:
  br label %bb65
bb65:
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l156, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t301 = load i64, ptr %l1, !tbaa !24
  %t304 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t300, i64 %t301)
  store i64 %t304, ptr %l160
  br label %bb66
bb66:
  %t305 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t306 = load ptr, ptr %l156, !tbaa !29
  %t307 = load i64, ptr %l160, !tbaa !24
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t306, i64 -1, i64 %t307, i32 %t305, i32 0)
  store ptr %t309, ptr %l162
  br label %bb67
bb67:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l163, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load ptr, ptr %l5, !tbaa !29
  %t315 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t311, ptr %t312)
  store %"compiler/source:Span" %t315, ptr %l166
  br label %bb68
bb68:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l5, !tbaa !29
  %t319 = getelementptr %"compiler/ast:Func", ptr %t317, i32 0, i32 2
  %t320 = load i32, ptr %t319, !tbaa !23
  %t323 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t316, i32 %t320)
  store { i64, ptr } %t323, ptr %l170
  br label %bb69
bb69:
  %t324 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t325 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %v0, { i64, ptr } %t324)
  store %"compiler/diagmsg:Msg" %t325, ptr %l171
  br label %bb70
bb70:
  %t326 = load ptr, ptr %l163, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l166
  %t328 = load %"compiler/diagmsg:Msg", ptr %l171
  %t329 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t326, %"compiler/source:Span" %t327, %"compiler/diagmsg:Msg" %t328)
  store i64 %t329, ptr %l172
  br label %bb71
bb71:
  %t330 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t330)
  br label %bb72
bb72:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca %"compiler/typed:Local"
  %l26 = alloca i1
  %l30 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l42 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 8}
  %t21 = icmp eq i64 %t19, 0
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l11, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l8, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 1
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l2, !tbaa !23
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb25
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t40)
  store ptr %t42, ptr %l20
  br label %bb11
bb11:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t46 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t44, i32 %t43)
  store %"compiler/typed:Local" %t46, ptr %l22
  br label %bb12
bb12:
  %t47 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 4
  %t48 = load i32, ptr %t47, !range !{i32 0, i32 7}
  %t50 = trunc i64 1 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l30
  br label %bb15
bb15:
  %t63 = load i1, ptr %l30, !tbaa !21
  store i1 %t63, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l26, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t71, i32 %t72)
  store i1 %t75, ptr %l36
  br label %bb20
bb20:
  %t76 = load i1, ptr %l36, !tbaa !21
  br i1 %t76, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb22:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l2, !tbaa !23
  %t86 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l42
  br label %bb23
bb23:
  %t87 = load i1, ptr %l42, !tbaa !21
  store i1 %t87, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t88 = load i1, ptr %l37, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4e588e9eb703ca58_549acb49cdd076c4)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatElem(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:seqOf"
  %l13 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l30 = alloca ptr
  %l35 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l42 = alloca %"compiler/check:seqOf"
  %l45 = alloca %"compiler/check:seqOf"
  %l46 = alloca i32
  %l48 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l1, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l13
  br label %bb4
bb4:
  %t19 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t21 = trunc i64 19 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l20
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t34 = load i32, ptr %l20, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t35, i32 %a2)
  store i32 %t39, ptr %l23
  br label %bb9
bb9:
  %t40 = load i32, ptr %l23, !tbaa !23
  store i32 %t40, ptr %l3, !tbaa !23
  %t41 = load i32, ptr %l3, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = icmp ne i32 %t41, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l30, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l35
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb15
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l30, !tbaa !29
  %t74 = load i32, ptr %l35, !tbaa !23
  %t75 = load i32, ptr %l40, !tbaa !23
  %t76 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i1 %t76, ptr %l41
  br label %bb14
bb14:
  %t77 = load i1, ptr %l41, !tbaa !21
  store i1 %t77, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t78 = load i1, ptr %l27, !tbaa !21
  br i1 %t78, label %bb16, label %bb17
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call { i32, %"compiler/check:seqOf" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqType(ptr %v0, ptr %t79, i32 %t80)
  %t84 = extractvalue { i32, %"compiler/check:seqOf" } %t83, 1
  %t85 = extractvalue { i32, %"compiler/check:seqOf" } %t83, 0
  store i32 %t85, ptr %l46
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb19, label %ok.87, !prof !99
ok.87:
  store %"compiler/check:seqOf" %t84, ptr %l45
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t88 = load %"compiler/check:seqOf", ptr %l45
  store %"compiler/check:seqOf" %t88, ptr %l42
  br label %bb21
bb19:
  %t89 = load i32, ptr %l46, !tbaa !23
  %t90 = ashr i32 %t89, 16
  %t92 = icmp eq i32 %t90, 1
  store i1 %t92, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t93 = load i32, ptr %l1, !tbaa !23
  store i32 %t93, ptr %rv
  br label %ret
bb21:
  %t95 = load %"compiler/check:seqOf", ptr %l42
  store %"compiler/check:seqOf" %t95, ptr %l4
  %t96 = getelementptr %"compiler/check:seqOf", ptr %l4, i32 0, i32 0
  %t97 = load i32, ptr %t96, !tbaa !23
  store i32 %t97, ptr %rv
  br label %ret
bb22:
  %t99 = load i32, ptr %l1, !tbaa !23
  store i32 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprogramOrigin(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/generic:Origin"
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [3 x i64] }
  %l13 = alloca i64
  %l15 = alloca i32
  %l18 = alloca %"compiler/generic:Origin"
  %l22 = alloca %"compiler/generic:Origin"
  %l26 = alloca %"compiler/generic:Origin"
  %l31 = alloca i64
  %l34 = alloca i64
  %l65 = alloca i1
  %l73 = alloca %"compiler/generic:Origin"
  %l80 = alloca %"compiler/generic:Origin"
  %rv = alloca { i64, [3 x i64] }
  %t32 = alloca { i64, [3 x i64] }, align 8
  %t99 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorInstance(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i32, ptr %l15, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/generic:Origin" %t20, ptr %l22
  br label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t24, i32 %t25)
  store %"compiler/generic:Origin" %t28, ptr %l26
  br label %bb6
bb5:
  %t29 = load %"compiler/generic:Origin", ptr %l22
  store %"compiler/generic:Origin" %t29, ptr %l18
  br label %bb7
bb6:
  %t30 = load %"compiler/generic:Origin", ptr %l26
  store %"compiler/generic:Origin" %t30, ptr %l18
  br label %bb7
bb7:
  %t31 = load %"compiler/generic:Origin", ptr %l18
  store %"compiler/generic:Origin" %t31, ptr %l3
  store { i64, [3 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [3 x i64] }, ptr %t32
  store { i64, [3 x i64] } %t34, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i64 64, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb13
bb10:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l34, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t62 = load i64, ptr %l34, !tbaa !24
  store i64 %t62, ptr %l31, !tbaa !24
  br label %bb13
bb13:
  %t63 = load i64, ptr %l31, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb15, label %bb16
bb15:
  br label %bb34
bb16:
  br label %bb17
bb17:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l10, !tbaa !24
  %t82 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = icmp slt i64 %t83, 0
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb34
bb19:
  br label %bb20
bb20:
  %t87 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 1
  %t90 = getelementptr %"compiler/source:Span", ptr %t89, i32 0, i32 0
  %t91 = load i32, ptr %t90, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t94 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 1
  %t95 = getelementptr %"compiler/source:Span", ptr %t94, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t98 = sext i32 %t96 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 0
  store i64 3, ptr %t100
  %t102 = insertvalue { i64, i64, i64 } undef, i64 %t88, 0
  %t104 = insertvalue { i64, i64, i64 } %t102, i64 %t93, 1
  %t106 = insertvalue { i64, i64, i64 } %t104, i64 %t98, 2
  %t107 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 1
  store { i64, i64, i64 } %t106, ptr %t107
  %t108 = load { i64, [3 x i64] }, ptr %t99
  store { i64, [3 x i64] } %t108, ptr %l11
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/load:Loader", ptr %t116, i32 0, i32 4
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load { i64, [3 x i64] }, ptr %l11
  %t123 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsLibrary(ptr %v0, ptr %t119, { i64, [3 x i64] } %t120)
  store i1 %t123, ptr %l65
  br label %bb21
bb21:
  %t124 = load i1, ptr %l65, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb22, label %bb23
bb22:
  %t127 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t127, ptr %l4
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t129 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 2
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = icmp sge i64 %t130, 0
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 2
  %t139 = load i64, ptr %t138, !tbaa !24
  %t142 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t137, i64 %t139)
  store %"compiler/generic:Origin" %t142, ptr %l73
  br label %bb27
bb26:
  %t143 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 3
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t148 = icmp ne i32 %t144, %t145
  br i1 %t148, label %bb28, label %bb29
bb27:
  %t150 = load %"compiler/generic:Origin", ptr %l73
  store %"compiler/generic:Origin" %t150, ptr %l3
  br label %bb32
bb28:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 3
  %t156 = load i32, ptr %t155, !tbaa !23
  %t159 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t154, i32 %t156)
  store %"compiler/generic:Origin" %t159, ptr %l80
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t160 = load %"compiler/generic:Origin", ptr %l80
  store %"compiler/generic:Origin" %t160, ptr %l3
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t161 = load i64, ptr %l9, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l9, !tbaa !24
  br label %bb14
bb34:
  %t165 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t165, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenAmount(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l26 = alloca i32
  %l34 = alloca i64
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i64
  %l59 = alloca i1
  %l64 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca { i64, ptr }
  %l77 = alloca %"compiler/diagmsg:Msg"
  %l78 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t3 = trunc i64 105 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t8 = trunc i64 106 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l10, !tbaa !21
  store i1 %t11, ptr %l4, !tbaa !21
  %t12 = load i1, ptr %l4, !tbaa !21
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t18 = trunc i64 71 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  store i1 %t21, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load i32, ptr %l1, !range !{i32 0, i32 113}
  %t26 = trunc i64 72 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenInt(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  store i32 %t37, ptr %l26
  br label %bb13
bb13:
  %t38 = load i32, ptr %l26, !tbaa !23
  store i32 %t38, ptr %l5, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t41 = icmp slt i32 %t39, 0
  br i1 %t41, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l5, !tbaa !23
  %t53 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t49, i32 %t50)
  store i64 %t53, ptr %l34
  br label %bb17
bb17:
  %t54 = load i64, ptr %l34, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  %t55 = load i1, ptr %l4, !tbaa !21
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp ne i64 %t59, 0
  br i1 %t61, label %bb20, label %bb21
bb19:
  br label %bb28
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l40, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t65)
  store %"compiler/source:Span" %t67, ptr %l42
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l43, !tbaa !29
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t69)
  store %"compiler/source:Span" %t71, ptr %l45
  br label %bb24
bb24:
  %t72 = load ptr, ptr %l43, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l45
  %t74 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t72, %"compiler/source:Span" %t73)
  store { i64, ptr } %t74, ptr %l46
  br label %bb25
bb25:
  %t75 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t76 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDivisorProven(ptr %v0, ptr %v0, { i64, ptr } %t75)
  store %"compiler/diagmsg:Msg" %t76, ptr %l47
  br label %bb26
bb26:
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l42
  %t79 = load %"compiler/diagmsg:Msg", ptr %l47
  %t80 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t77, %"compiler/source:Span" %t78, %"compiler/diagmsg:Msg" %t79)
  store i64 %t80, ptr %l48
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  store ptr %t87, ptr %l52, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l2, !tbaa !23
  %t92 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l55
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l52, !tbaa !29
  %t94 = load i32, ptr %l55, !tbaa !23
  %t95 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t93, i32 %t94)
  store i64 %t95, ptr %l56
  br label %bb30
bb30:
  %t96 = load i64, ptr %l56, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = icmp sge i64 %t97, 0
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  store i1 %t105, ptr %l59, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb33
bb33:
  %t107 = load i1, ptr %l59, !tbaa !21
  br i1 %t107, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l64, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t110)
  store %"compiler/source:Span" %t112, ptr %l66
  br label %bb37
bb37:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l2, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t113, i32 %t114)
  store { i64, ptr } %t117, ptr %l69
  br label %bb38
bb38:
  %t118 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l70, !tbaa !27
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l71, !tbaa !29
  %t126 = load ptr, ptr %l3, !tbaa !29
  %t128 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t126)
  store %"compiler/source:Span" %t128, ptr %l73
  br label %bb39
bb39:
  %t129 = load ptr, ptr %l71, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l73
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t129, %"compiler/source:Span" %t130)
  store { i64, ptr } %t131, ptr %l74
  br label %bb40
bb40:
  %t132 = load i64, ptr %l6, !tbaa !24
  %t133 = load i64, ptr %l7, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t138 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShiftProven(ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t134, { i64, ptr } %t135, i64 %t132, i64 %t133)
  store %"compiler/diagmsg:Msg" %t138, ptr %l77
  br label %bb41
bb41:
  %t139 = load ptr, ptr %l64, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l66
  %t141 = load %"compiler/diagmsg:Msg", ptr %l77
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t139, %"compiler/source:Span" %t140, %"compiler/diagmsg:Msg" %t141)
  store i64 %t142, ptr %l78
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, i32 }
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/diagmsg:Msg"
  %l24 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/diagmsg:Msg"
  %l36 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca %"compiler/diagmsg:Msg"
  %l54 = alloca i64
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l66 = alloca %"compiler/names:Ref"
  %l72 = alloca i1
  %l75 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca %"compiler/diagmsg:Msg"
  %l90 = alloca i64
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l103 = alloca i32
  %l111 = alloca i1
  %l113 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca %"compiler/diagmsg:Msg"
  %l123 = alloca i64
  %l129 = alloca { i64, i32 }
  %l138 = alloca i1
  %l140 = alloca ptr
  %l145 = alloca i32
  %l146 = alloca i1
  %l148 = alloca i32
  %l153 = alloca i64
  %l155 = alloca i32
  %l158 = alloca ptr
  %l162 = alloca i1
  %l172 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l186 = alloca i32
  %l195 = alloca ptr
  %l198 = alloca %"compiler/source:Span"
  %l200 = alloca i1
  %l201 = alloca %"compiler/diagmsg:Msg"
  %l204 = alloca { i64, ptr }
  %l206 = alloca %"compiler/diagmsg:Msg"
  %l209 = alloca { i64, ptr }
  %l211 = alloca %"compiler/diagmsg:Msg"
  %l212 = alloca i64
  %l217 = alloca i32
  %l220 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l226 = alloca { i64, ptr }
  %l228 = alloca %"compiler/diagmsg:Msg"
  %l229 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %t497 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l18, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 32
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l21, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l22
  %t11 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0)
  store %"compiler/diagmsg:Msg" %t11, ptr %l23
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l21, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l22
  %t14 = load %"compiler/diagmsg:Msg", ptr %l23
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t12, %"compiler/source:Span" %t13, %"compiler/diagmsg:Msg" %t14)
  store i64 %t15, ptr %l24
  br label %bb5
bb5:
  br label %ret
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l26
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l26, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 34
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l30, !tbaa !29
  %t27 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  %t32 = add i32 %t30, 5
  %t35 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t28, i32 %t32)
  store %"compiler/source:Span" %t35, ptr %l34
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t36 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0)
  store %"compiler/diagmsg:Msg" %t36, ptr %l35
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l30, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l34
  %t39 = load %"compiler/diagmsg:Msg", ptr %l35
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t37, %"compiler/source:Span" %t38, %"compiler/diagmsg:Msg" %t39)
  store i64 %t40, ptr %l36
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t41)
  store ptr %t43, ptr %l38
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l38, !tbaa !29
  %t46 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 35
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l42, !tbaa !29
  %t52 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = add i32 %t55, 5
  %t60 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t53, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l46
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l47, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t62)
  store ptr %t64, ptr %l49
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l49, !tbaa !29
  %t67 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 36
  %t68 = load i1, ptr %t67, !tbaa !21
  %t69 = load ptr, ptr %l47, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s3, ptr %t69, i1 %t68)
  store { i64, ptr } %t71, ptr %l52
  br label %bb19
bb19:
  %t72 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t73 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %s3, ptr %v0, { i64, ptr } %t72)
  store %"compiler/diagmsg:Msg" %t73, ptr %l53
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l42, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l46
  %t76 = load %"compiler/diagmsg:Msg", ptr %l53
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t74, %"compiler/source:Span" %t75, %"compiler/diagmsg:Msg" %t76)
  store i64 %t77, ptr %l54
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb22:
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l59, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t89)
  store ptr %t91, ptr %l61
  br label %bb26
bb26:
  %t92 = load ptr, ptr %l61, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Path", ptr %t96, i32 0, i32 0
  %t99 = getelementptr %"compiler/source:Span", ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99, !tbaa !23
  %t101 = load ptr, ptr %l59, !tbaa !29
  %t104 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t101, i64 %t95, i32 %t100)
  store %"compiler/names:Ref" %t104, ptr %l66
  br label %bb27
bb27:
  %t105 = getelementptr %"compiler/names:Ref", ptr %l66, i32 0, i32 0
  %t106 = load i32, ptr %t105, !range !{i32 0, i32 9}
  store i32 %t106, ptr %l4
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Path", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp eq i64 %t113, 1
  br i1 %t115, label %bb28, label %bb29
bb28:
  %t117 = load i32, ptr %l4, !range !{i32 0, i32 9}
  %t119 = trunc i64 1 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb33
bb30:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb32
bb31:
  %t122 = load i32, ptr %l4, !range !{i32 0, i32 9}
  %t124 = trunc i64 2 to i32
  %t125 = icmp eq i32 %t122, %t124
  store i1 %t125, ptr %l75, !tbaa !21
  br label %bb32
bb32:
  %t127 = load i1, ptr %l75, !tbaa !21
  store i1 %t127, ptr %l72, !tbaa !21
  br label %bb33
bb33:
  %t128 = load i1, ptr %l72, !tbaa !21
  br i1 %t128, label %bb34, label %bb35
bb34:
  %t129 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t133 = icmp eq i64 %t131, %t132
  %t134 = extractvalue { i64, ptr } %t129, 1
  %t135 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t136 = icmp eq ptr %t134, %t135
  %t137 = and i1 %t133, %t136
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb36, label %bb37
bb35:
  br label %bb58
bb36:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l81, !tbaa !29
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Path", ptr %t142, i32 0, i32 0
  %t145 = load %"compiler/source:Span", ptr %t144
  store %"compiler/source:Span" %t145, ptr %l83
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr %"compiler/ast:Path", ptr %t147, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l86, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i32, ptr %t152, i64 0
  %t154 = load i32, ptr %t153, !tbaa !33
  %t157 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t146, i32 %t154)
  store { i64, ptr } %t157, ptr %l88
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t158 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t159 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %v0, ptr %v0, { i64, ptr } %t158)
  store %"compiler/diagmsg:Msg" %t159, ptr %l89
  br label %bb39
bb39:
  %t160 = load ptr, ptr %l81, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l83
  %t162 = load %"compiler/diagmsg:Msg", ptr %l89
  %t163 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t160, %"compiler/source:Span" %t161, %"compiler/diagmsg:Msg" %t162)
  store i64 %t163, ptr %l90
  br label %bb40
bb40:
  br label %ret
bb41:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t167 = getelementptr %"compiler/ast:Path", ptr %t165, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Path", ptr %t169, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l95, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr i32, ptr %t174, i64 0
  %t176 = load i32, ptr %t175, !tbaa !33
  %t177 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %v0, ptr %t164, %"compiler/source:Span" %t168, i32 %t176, i32 %t177, i1 false)
  store ptr %t182, ptr %l98
  br label %bb42
bb42:
  %t183 = load ptr, ptr %l98, !tbaa !29
  store ptr %t183, ptr %l5, !tbaa !29
  %t184 = load ptr, ptr %l5, !tbaa !29
  %t186 = icmp eq ptr %t184, null
  br i1 %t186, label %bb43, label %bb44
bb43:
  br label %ret
bb44:
  br label %bb45
bb45:
  %t188 = load ptr, ptr %l5, !tbaa !29
  %t191 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t188)
  store i32 %t191, ptr %l103
  br label %bb46
bb46:
  %t192 = load i32, ptr %l103, !tbaa !23
  store i32 %t192, ptr %l6, !tbaa !23
  %t193 = load i32, ptr %l6, !tbaa !23
  %t194 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t197 = icmp eq i32 %t193, %t194
  br i1 %t197, label %bb47, label %bb48
bb47:
  br label %ret
bb48:
  br label %bb49
bb49:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l6, !tbaa !23
  %t208 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t204, i32 %t205)
  store i1 %t208, ptr %l111
  br label %bb50
bb50:
  %t209 = load i1, ptr %l111, !tbaa !21
  %t210 = xor i1 %t209, true
  br i1 %t210, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s9
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l113, !tbaa !29
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t215 = getelementptr %"compiler/ast:Path", ptr %t213, i32 0, i32 0
  %t216 = load %"compiler/source:Span", ptr %t215
  store %"compiler/source:Span" %t216, ptr %l115
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Path", ptr %t218, i32 0, i32 1
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l118, !tbaa !27
  %t222 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i32, ptr %t223, i64 0
  %t225 = load i32, ptr %t224, !tbaa !33
  %t228 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t217, i32 %t225)
  store { i64, ptr } %t228, ptr %l120
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t229 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t237 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaiseNotCaught(ptr %s9, ptr %v0, { i64, ptr } %t235)
  store %"compiler/diagmsg:Msg" %t237, ptr %l122
  br label %bb54
bb54:
  %t238 = load ptr, ptr %l113, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l115
  %t240 = load %"compiler/diagmsg:Msg", ptr %l122
  %t241 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t238, %"compiler/source:Span" %t239, %"compiler/diagmsg:Msg" %t240)
  store i64 %t241, ptr %l123
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %ret
bb56:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load %"compiler/source:Span", ptr %l1
  %t244 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereraise(ptr %v0, ptr %v0, ptr %t242, %"compiler/source:Span" %t243, ptr %t244)
  br label %bb57
bb57:
  br label %ret
bb58:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t252 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t248, ptr %t249)
  store { i64, i32 } %t252, ptr %l129
  br label %bb59
bb59:
  %t253 = load { i64, i32 }, ptr %l129
  store { i64, i32 } %t253, ptr %l7
  %t254 = getelementptr { i64, i32 }, ptr %l7, i32 0, i32 0
  %t255 = load i64, ptr %t254, !tbaa !24
  store i64 %t255, ptr %l8, !tbaa !24
  %t257 = getelementptr { i64, i32 }, ptr %l7, i32 0, i32 1
  %t258 = load i32, ptr %t257, !tbaa !23
  store i32 %t258, ptr %l9, !tbaa !23
  %t260 = load i64, ptr %l8, !tbaa !24
  %t262 = icmp slt i64 %t260, 0
  br i1 %t262, label %bb60, label %bb61
bb60:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraiseUnknown(ptr %v0, ptr %v1, ptr %t264, ptr %t265)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %ret
bb63:
  %t268 = load i64, ptr %l8, !tbaa !24
  %t270 = icmp slt i64 %t268, 64
  br i1 %t270, label %bb64, label %bb65
bb64:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !29
  store ptr %t275, ptr %l140, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/check:Checker", ptr %t276, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %l9, !tbaa !23
  %t285 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t281, i32 %t282)
  store i32 %t285, ptr %l145
  br label %bb66
bb65:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb68
bb66:
  %t286 = load ptr, ptr %l140, !tbaa !29
  %t287 = load i32, ptr %l145, !tbaa !23
  %t288 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t286, i32 %t287)
  store i1 %t288, ptr %l146
  br label %bb67
bb67:
  %t289 = load i1, ptr %l146, !tbaa !21
  %t290 = xor i1 %t289, true
  store i1 %t290, ptr %l138, !tbaa !21
  br label %bb68
bb68:
  %t292 = load i1, ptr %l138, !tbaa !21
  br i1 %t292, label %bb69, label %bb70
bb69:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %l9, !tbaa !23
  %t300 = load i64, ptr %l8, !tbaa !24
  store i64 %t300, ptr %l153, !tbaa !24
  %t301 = load i64, ptr %l153, !tbaa !24
  %t302 = load i64, ptr %l153, !tbaa !24
  %t303 = shl i64 1, %t302
  %t307 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t298, i32 %t299, i64 %t303)
  store i32 %t307, ptr %l155
  br label %bb71
bb70:
  %t308 = load i32, ptr %l9, !tbaa !23
  store i32 %t308, ptr %l148, !tbaa !23
  br label %bb72
bb71:
  %t310 = load i32, ptr %l155, !tbaa !23
  store i32 %t310, ptr %l148, !tbaa !23
  br label %bb72
bb72:
  %t311 = load i32, ptr %l148, !tbaa !23
  store i32 %t311, ptr %l10, !tbaa !23
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t312)
  store ptr %t314, ptr %l158
  br label %bb73
bb73:
  %t315 = load ptr, ptr %l158, !tbaa !29
  store ptr %t315, ptr %l11, !tbaa !29
  %t316 = load ptr, ptr %l11, !tbaa !29
  %t318 = getelementptr %"compiler/check:frame", ptr %t316, i32 0, i32 26
  %t319 = load i1, ptr %t318, !tbaa !21
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb74, label %bb75
bb74:
  %t323 = load ptr, ptr %l11, !tbaa !29
  %t325 = getelementptr %"compiler/check:frame", ptr %t323, i32 0, i32 12
  %t326 = load i1, ptr %t325, !tbaa !21
  %t328 = xor i1 %t326, true
  store i1 %t328, ptr %l162, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb76
bb76:
  %t330 = load i1, ptr %l162, !tbaa !21
  br i1 %t330, label %bb77, label %bb78
bb77:
  %t331 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t331, ptr %l12, !tbaa !23
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/check:Checker", ptr %t333, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = getelementptr %"compiler/generic:Program", ptr %t336, i32 0, i32 2
  %t339 = load ptr, ptr %l11, !tbaa !29
  %t341 = getelementptr %"compiler/check:frame", ptr %t339, i32 0, i32 6
  %t342 = load i32, ptr %t341, !tbaa !23
  %t345 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t338, i32 %t342)
  store { i64, ptr } %t345, ptr %l172
  br label %bb79
bb78:
  br label %bb111
bb79:
  %t346 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t346, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t347 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t347, 0
  store i64 %t349, ptr %l15, !tbaa !24
  br label %bb80
bb80:
  %t351 = load i64, ptr %l14, !tbaa !24
  %t352 = load i64, ptr %l15, !tbaa !24
  %t355 = icmp slt i64 %t351, %t352
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb81, label %bb82
bb81:
  br label %bb89
bb82:
  br label %bb83
bb83:
  %t359 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t359, ptr %l179, !tbaa !27
  %t360 = load i64, ptr %l14, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t360
  %t365 = load i32, ptr %t364, !tbaa !33
  store i32 %t365, ptr %l16, !tbaa !23
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/check:Checker", ptr %t367, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t372 = getelementptr %"compiler/generic:Program", ptr %t370, i32 0, i32 2
  %t373 = load i32, ptr %l16, !tbaa !23
  %t376 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t372, i32 %t373)
  store i32 %t376, ptr %l186
  br label %bb84
bb84:
  %t377 = load i32, ptr %l9, !tbaa !23
  %t378 = load i32, ptr %l186, !tbaa !23
  %t380 = icmp eq i32 %t378, %t377
  br i1 %t380, label %bb85, label %bb86
bb85:
  %t382 = load i32, ptr %l16, !tbaa !23
  store i32 %t382, ptr %l12, !tbaa !23
  br label %bb87
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t384 = load i64, ptr %l14, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l14, !tbaa !24
  br label %bb80
bb89:
  %t388 = load i32, ptr %l12, !tbaa !23
  %t389 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t392 = icmp eq i32 %t388, %t389
  br i1 %t392, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s16
  %t394 = load ptr, ptr %l0, !tbaa !29
  store ptr %t394, ptr %l195, !tbaa !29
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l2, !tbaa !29
  %t399 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %t395, ptr %t396, i64 1)
  store %"compiler/source:Span" %t399, ptr %l198
  br label %bb92
bb91:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l11, !tbaa !29
  %t403 = getelementptr %"compiler/check:frame", ptr %t401, i32 0, i32 6
  %t404 = load i32, ptr %t403, !tbaa !23
  %t405 = load i32, ptr %l10, !tbaa !23
  %t409 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t400, i32 %t404, i32 %t405)
  store i32 %t409, ptr %l217
  br label %bb102
bb92:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesNoQuestion(ptr %v0, ptr %t410)
  store i1 %t412, ptr %l200
  br label %bb93
bb93:
  %t413 = load i1, ptr %l200, !tbaa !21
  br i1 %t413, label %bb94, label %bb95
bb94:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load i32, ptr %l9, !tbaa !23
  %t418 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t414, i32 %t415)
  store { i64, ptr } %t418, ptr %l204
  br label %bb96
bb95:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load i32, ptr %l9, !tbaa !23
  %t423 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t419, i32 %t420)
  store { i64, ptr } %t423, ptr %l209
  br label %bb98
bb96:
  %t424 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  %t426 = extractvalue { i64, ptr } %t424, 1
  %t427 = mul i64 %t425, 1
  %t428 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t427)
  call void @llvm.memcpy.p0.p0.i64(ptr %t428, ptr %t426, i64 %t427, i1 false)
  %t429 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  %t432 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaiseNeedsQuestion(ptr %s16, ptr %v0, { i64, ptr } %t430)
  store %"compiler/diagmsg:Msg" %t432, ptr %l206
  br label %bb97
bb97:
  %t433 = load %"compiler/diagmsg:Msg", ptr %l206
  store %"compiler/diagmsg:Msg" %t433, ptr %l201
  br label %bb100
bb98:
  %t434 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t434, 0
  %t436 = extractvalue { i64, ptr } %t434, 1
  %t437 = mul i64 %t435, 1
  %t438 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t437)
  call void @llvm.memcpy.p0.p0.i64(ptr %t438, ptr %t436, i64 %t437, i1 false)
  %t439 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  %t442 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %s16, ptr %v0, { i64, ptr } %t440)
  store %"compiler/diagmsg:Msg" %t442, ptr %l211
  br label %bb99
bb99:
  %t443 = load %"compiler/diagmsg:Msg", ptr %l211
  store %"compiler/diagmsg:Msg" %t443, ptr %l201
  br label %bb100
bb100:
  %t444 = load ptr, ptr %l195, !tbaa !29
  %t445 = load %"compiler/source:Span", ptr %l198
  %t446 = load %"compiler/diagmsg:Msg", ptr %l201
  %t447 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t444, %"compiler/source:Span" %t445, %"compiler/diagmsg:Msg" %t446)
  store i64 %t447, ptr %l212
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s16)
  br label %bb110
bb102:
  %t448 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t449 = load i32, ptr %l217, !tbaa !23
  %t451 = icmp ne i32 %t449, %t448
  br i1 %t451, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s18
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l220, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load ptr, ptr %l2, !tbaa !29
  %t458 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %t454, ptr %t455, i64 0)
  store %"compiler/source:Span" %t458, ptr %l223
  br label %bb105
bb104:
  br label %bb109
bb105:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load i32, ptr %l12, !tbaa !23
  %t463 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t459, i32 %t460)
  store { i64, ptr } %t463, ptr %l226
  br label %bb106
bb106:
  %t464 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  %t466 = extractvalue { i64, ptr } %t464, 1
  %t467 = mul i64 %t465, 1
  %t468 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t467)
  call void @llvm.memcpy.p0.p0.i64(ptr %t468, ptr %t466, i64 %t467, i1 false)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  %t472 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %s18, ptr %v0, { i64, ptr } %t470)
  store %"compiler/diagmsg:Msg" %t472, ptr %l228
  br label %bb107
bb107:
  %t473 = load ptr, ptr %l220, !tbaa !29
  %t474 = load %"compiler/source:Span", ptr %l223
  %t475 = load %"compiler/diagmsg:Msg", ptr %l228
  %t476 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t473, %"compiler/source:Span" %t474, %"compiler/diagmsg:Msg" %t475)
  store i64 %t476, ptr %l229
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s18)
  br label %bb109
bb109:
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t478 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t477, i32 %t478)
  br label %bb112
bb112:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load %"compiler/source:Span", ptr %l1
  %t483 = load ptr, ptr %l2, !tbaa !29
  %t484 = load i32, ptr %l9, !tbaa !23
  %t485 = load i64, ptr %l8, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushPayload(ptr %v0, ptr %v1, ptr %v2, ptr %t481, %"compiler/source:Span" %t482, ptr %t483, i32 %t484, i64 %t485, { i64, ptr } %t486)
  br label %bb113
bb113:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load %"compiler/source:Span", ptr %l1
  %t495 = load i32, ptr %l9, !tbaa !23
  %t496 = load i64, ptr %l8, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t497
  %t498 = getelementptr { i64, [3 x i64] }, ptr %t497, i32 0, i32 0
  store i64 7, ptr %t498
  %t500 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t494, 0
  %t502 = insertvalue { %"compiler/source:Span", i32, i64 } %t500, i32 %t495, 1
  %t504 = insertvalue { %"compiler/source:Span", i32, i64 } %t502, i64 %t496, 2
  %t505 = getelementptr { i64, [3 x i64] }, ptr %t497, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t504, ptr %t505
  %t506 = load { i64, [3 x i64] }, ptr %t497
  %t508 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t506, ptr %t508
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t493, ptr %t508)
  br label %bb114
bb114:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/check:reflVal"
  %l13 = alloca %"compiler/check:reflVal"
  %l20 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 165
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l2, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 165
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %s0, ptr %t14, ptr %t15)
  store %"compiler/check:reflVal" %t18, ptr %l13
  br label %bb4
bb4:
  %t19 = load %"compiler/check:reflVal", ptr %l13
  store %"compiler/check:reflVal" %t19, ptr %l3
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 165
  %t23 = load i1, ptr %t22, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i1, ptr %l2, !tbaa !21
  %t29 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 165
  store i1 %t26, ptr %t29, !tbaa !21
  %t32 = xor i1 %t23, true
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t34 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 0
  %t35 = load i1, ptr %t34, !tbaa !21
  %t37 = xor i1 %t35, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t40 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t49 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l59 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Arm", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Arm", ptr %t36, i32 0, i32 4
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9ffee6a4e1a43bc2_8f88457b20f170fe)
  unreachable
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Arm", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t47, ptr %t46)
  store i1 %t49, ptr %l29
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Match", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Match", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb22
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ce05aca7270627a9_4d670951fa414da5)
  unreachable
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Match", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Arm", ptr %t76, i32 0, i32 4
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l48, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Match", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb32
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ce05aca7270627a9_4d670951fa414da5)
  unreachable
bb26:
  br label %bb27
bb27:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Match", ptr %t95, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t98, i32 0, i32 4
  %t102 = load ptr, ptr %t101, !tbaa !29
  store ptr %t102, ptr %l6, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_ce05aca7270627a9_4d670951fa414da5)
  unreachable
bb29:
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t109, ptr %t108)
  store i1 %t111, ptr %l59
  br label %bb31
bb31:
  %t112 = load i1, ptr %l59, !tbaa !21
  store i1 %t112, ptr %l47, !tbaa !21
  br label %bb32
bb32:
  %t113 = load i1, ptr %l47, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l6 = alloca i64
  %l11 = alloca i64
  %l18 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %t1, i32 %t2, { i64, ptr } %t3, i64 %a3)
  store i64 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %t11, i64 %t12, i32 %t13, { i64, ptr } %t14, %"compiler/source:Span" %a4, { i64, ptr } %a5)
  store i1 %t23, ptr %l18
  br label %bb2
bb2:
  %t24 = load i64, ptr %l6, !tbaa !24
  store i64 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleLandings(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca %"compiler/check:landing"
  %l48 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 77
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2eLen_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l13
  br label %bb5
bb5:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 77
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2eLen_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l16
  br label %bb6
bb6:
  %t16 = load i64, ptr %l16, !tbaa !24
  store i64 %t16, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb12
bb9:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l23, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb11
bb11:
  %t43 = load i64, ptr %l23, !tbaa !24
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t44 = load i64, ptr %l20, !tbaa !24
  store i64 %t44, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 77
  %t69 = call %"compiler/check:landing" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2eAt_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %t65, i64 %t61)
  store %"compiler/check:landing" %t69, ptr %l44
  br label %bb17
bb17:
  %t70 = getelementptr %"compiler/check:landing", ptr %l44, i32 0, i32 0
  %t71 = load i64, ptr %t70, !tbaa !24
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t73)
  store i1 %t76, ptr %l48
  br label %bb18
bb18:
  %t77 = load i1, ptr %l48, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t78 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t78, i1 true)
  br label %bb22
bb22:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elandingsOf(ptr %v0, ptr %t81, i64 %t82)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l6, !tbaa !24
  br label %bb13
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l27 = alloca i1
  %l33 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca %"compiler/check:litv"
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"compiler/check:litv"
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca %"compiler/check:litv"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load i1, ptr %l14, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 28}
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 113}
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb41
bb12:
  %t49 = load i32, ptr %l3, !range !{i32 0, i32 113}
  %t51 = trunc i64 105 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb15
bb14:
  %t54 = load i32, ptr %l3, !range !{i32 0, i32 113}
  %t56 = trunc i64 106 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t65 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store %"compiler/check:litv" %t65, ptr %l33
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t66 = getelementptr %"compiler/check:litv", ptr %l33, i32 0, i32 0
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t74 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  store %"compiler/check:litv" %t74, ptr %l39
  br label %bb21
bb20:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  %t75 = getelementptr %"compiler/check:litv", ptr %l39, i32 0, i32 0
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l35, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t85, ptr %l44
  br label %bb24
bb24:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t92 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store %"compiler/check:litv" %t92, ptr %l49
  br label %bb27
bb26:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb27:
  %t93 = getelementptr %"compiler/check:litv", ptr %l49, i32 0, i32 0
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb31
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t100, ptr %l54
  br label %bb30
bb30:
  %t101 = load i1, ptr %l54, !tbaa !21
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l51, !tbaa !21
  store i1 %t102, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t103 = load i1, ptr %l45, !tbaa !21
  br i1 %t103, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb40
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i1 %t108, ptr %l58
  br label %bb35
bb35:
  %t109 = load i1, ptr %l58, !tbaa !21
  br i1 %t109, label %bb36, label %bb37
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t115 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store %"compiler/check:litv" %t115, ptr %l63
  br label %bb38
bb37:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb39
bb38:
  %t116 = getelementptr %"compiler/check:litv", ptr %l63, i32 0, i32 0
  %t117 = load i1, ptr %t116, !tbaa !21
  store i1 %t117, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t119 = load i1, ptr %l59, !tbaa !21
  store i1 %t119, ptr %l55, !tbaa !21
  br label %bb40
bb40:
  %t120 = load i1, ptr %l55, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 false, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_5ec272a16da13ce8_6a23c064ecfaca54)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estaticArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca i1
  %l30 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i1
  %l67 = alloca i1
  %l70 = alloca ptr
  %l75 = alloca i32
  %l77 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i32
  %l91 = alloca ptr
  %l93 = alloca i32
  %l95 = alloca i32
  %l101 = alloca i64
  %l103 = alloca ptr
  %l113 = alloca i64
  %l116 = alloca i64
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l154 = alloca i64
  %l155 = alloca i64
  %l160 = alloca ptr
  %l161 = alloca i1
  %l171 = alloca %"compiler/source:Span"
  %l172 = alloca i32
  %l174 = alloca ptr
  %rv = alloca ptr
  %t176 = alloca { i64, [2 x i64] }, align 8
  %t193 = alloca i64
  %t314 = alloca { i64, [2 x i64] }, align 8
  %t369 = alloca { i64, [2 x i64] }, align 8
  %t377 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l23
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t12 = load i64, ptr %l23, !tbaa !24
  %t14 = and i64 %t12, %t11
  %t16 = icmp ne i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l30, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l35
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l30, !tbaa !29
  %t35 = load i32, ptr %l35, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l36
  br label %bb5
bb5:
  %t37 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  %t42 = xor i1 %t40, true
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  store ptr %t51, ptr %l43, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l48
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l43, !tbaa !29
  %t63 = load i32, ptr %l48, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l49
  br label %bb11
bb11:
  %t65 = load i32, ptr %l49, !tbaa !23
  store i32 %t65, ptr %l3, !tbaa !23
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t67 = load ptr, ptr %l50, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load ptr, ptr %l50, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 7
  store i1 %t73, ptr %l51, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l51, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb14, label %bb15
bb14:
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 0
  %t82 = load %"compiler/source:Span", ptr %t81
  store %"compiler/source:Span" %t82, ptr %l4
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l5, !tbaa !23
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l7, !tbaa !29
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Make", ptr %t98, i32 0, i32 0
  %t101 = load i32, ptr %t100, !range !{i32 0, i32 5}
  %t103 = trunc i64 2 to i32
  %t104 = icmp eq i32 %t101, %t103
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb21
bb18:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  store ptr %t113, ptr %l70, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %l5, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l75
  br label %bb19
bb19:
  %t124 = load i32, ptr %l3, !tbaa !23
  %t125 = load ptr, ptr %l70, !tbaa !29
  %t126 = load i32, ptr %l75, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t125, i32 %t126, i32 %t124)
  store i1 %t128, ptr %l77
  br label %bb20
bb20:
  %t129 = load i1, ptr %l77, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l67, !tbaa !21
  br label %bb21
bb21:
  %t132 = load i1, ptr %l67, !tbaa !21
  br i1 %t132, label %bb22, label %bb23
bb22:
  store ptr null, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l3, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l82
  br label %bb25
bb25:
  %t139 = load i1, ptr %l82, !tbaa !21
  br i1 %t139, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb28
bb27:
  %t140 = load i32, ptr %l3, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  store i1 %t144, ptr %l83, !tbaa !21
  br label %bb28
bb28:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb33
bb30:
  %t147 = load i32, ptr %l3, !tbaa !23
  store i32 %t147, ptr %l88, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  store ptr %t153, ptr %l91, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t154)
  store i32 %t156, ptr %l93
  br label %bb31
bb31:
  %t157 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t158 = load ptr, ptr %l91, !tbaa !29
  %t159 = load i32, ptr %l93, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t158, i32 %t159, i64 %t157)
  store i32 %t161, ptr %l95
  br label %bb32
bb32:
  %t162 = load i32, ptr %l88, !tbaa !23
  %t163 = load i32, ptr %l95, !tbaa !23
  %t164 = icmp eq i32 %t162, %t163
  store i1 %t164, ptr %l87, !tbaa !21
  br label %bb33
bb33:
  %t166 = load i1, ptr %l87, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb34, label %bb35
bb34:
  store ptr null, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l7, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Make", ptr %t170, i32 0, i32 2
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l101, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t178 = insertvalue { i64 } undef, i64 0, 0
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 1
  store { i64 } %t178, ptr %t179
  %t180 = load { i64, [2 x i64] }, ptr %t176
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t180, ptr %t182
  store ptr %t182, ptr %l103, !tbaa !29
  %t183 = load i64, ptr %l101, !tbaa !24
  %t184 = icmp sge i64 %t183, 0
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t186 = load i64, ptr %l101, !tbaa !24
  %t187 = icmp sle i64 %t186, 1152921504606846975
  br i1 %t187, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb39:
  %t189 = load i64, ptr %l101, !tbaa !24
  %t190 = mul i64 %t189, 8
  %t191 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t190)
  %t192 = load ptr, ptr %l103, !tbaa !29
  store i64 0, ptr %t193
  br label %fill.194
fill.194:
  %t197 = load i64, ptr %t193
  %t198 = icmp slt i64 %t197, %t189
  br i1 %t198, label %fillb.195, label %filld.196
fillb.195:
  %t199 = getelementptr ptr, ptr %t191, i64 %t197
  store ptr %t192, ptr %t199
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %t193
  br label %fill.194
filld.196:
  %t201 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t191, 1
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t203, ptr %lp8
  %t205 = load ptr, ptr %lp8
  store { i64, ptr } %t202, ptr %t205, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t206 = load ptr, ptr %l7, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Make", ptr %t206, i32 0, i32 2
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t213 = load i64, ptr %l10, !tbaa !24
  %t214 = load i64, ptr %l9, !tbaa !24
  %t217 = icmp sgt i64 %t213, %t214
  br i1 %t217, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb41:
  %t219 = load i64, ptr %l11, !tbaa !24
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb46
bb43:
  %t223 = load i64, ptr %l10, !tbaa !24
  %t224 = load i64, ptr %l9, !tbaa !24
  %t227 = sub i64 %t223, %t224
  %t228 = load i64, ptr %l11, !tbaa !24
  %t231 = add i64 %t227, %t228
  %t233 = sub i64 %t231, 1
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = sdiv i64 %t233, %t234
  store i64 %t237, ptr %l116, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb45
bb45:
  %t239 = load i64, ptr %l116, !tbaa !24
  store i64 %t239, ptr %l113, !tbaa !24
  br label %bb46
bb46:
  %t240 = load i64, ptr %l113, !tbaa !24
  store i64 %t240, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb47
bb47:
  %t241 = load i64, ptr %l13, !tbaa !24
  %t242 = load i64, ptr %l12, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb48, label %bb49
bb48:
  br label %bb79
bb49:
  br label %bb50
bb50:
  %t249 = load i64, ptr %l9, !tbaa !24
  %t250 = load i64, ptr %l13, !tbaa !24
  %t251 = load i64, ptr %l11, !tbaa !24
  %t254 = mul i64 %t250, %t251
  %t257 = add i64 %t249, %t254
  store i64 %t257, ptr %l14, !tbaa !24
  %t259 = load ptr, ptr %l7, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Make", ptr %t259, i32 0, i32 2
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l135, !tbaa !27
  %t263 = load i64, ptr %l14, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  store ptr %t268, ptr %l15, !tbaa !29
  %t270 = load ptr, ptr %l15, !tbaa !29
  store ptr %t270, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t271 = load ptr, ptr %l138, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb51, label %bb52
bb51:
  %t274 = load ptr, ptr %l138, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 18}
  %t277 = icmp eq i64 %t275, 0
  store i1 %t277, ptr %l139, !tbaa !21
  br label %bb52
bb52:
  %t278 = load i1, ptr %l139, !tbaa !21
  br i1 %t278, label %bb53, label %bb54
bb53:
  %t279 = load ptr, ptr %l15, !tbaa !29
  %t281 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t281, i32 0, i32 1
  %t283 = load i32, ptr %t282
  store i32 %t283, ptr %l16, !tbaa !23
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t285 = load i32, ptr %l16, !tbaa !23
  %t286 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t289 = icmp eq i32 %t285, %t286
  br i1 %t289, label %bb56, label %bb57
bb56:
  store ptr null, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t292 = load ptr, ptr %l15, !tbaa !29
  store ptr %t292, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t293 = load ptr, ptr %l148, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb59, label %bb60
bb59:
  %t296 = load ptr, ptr %l148, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 18}
  %t299 = icmp eq i64 %t297, 0
  store i1 %t299, ptr %l149, !tbaa !21
  br label %bb60
bb60:
  %t300 = load i1, ptr %l149, !tbaa !21
  br i1 %t300, label %bb61, label %bb62
bb61:
  %t301 = load ptr, ptr %l15, !tbaa !29
  %t303 = getelementptr { i64, [5 x i64] }, ptr %t301, i32 0, i32 1
  %t304 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t303, i32 0, i32 2
  %t305 = load i64, ptr %t304
  store i64 %t305, ptr %l17, !tbaa !24
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t307 = load i64, ptr %l14, !tbaa !24
  store i64 %t307, ptr %l154, !tbaa !24
  %t308 = ptrtoint ptr %v2 to i64
  store i64 %t308, ptr %l155, !tbaa !24
  %t309 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2ftyped_3aConst_26_3e_2e_2d1
  br i1 %t309, label %bb64, label %bb65
bb64:
  %t311 = call ptr @__olang_region_make(ptr %v2)
  %t312 = ptrtoint ptr %t311 to i64
  store i64 %t312, ptr %l155, !tbaa !24
  br label %bb65
bb65:
  %t313 = load i64, ptr %l17, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t314
  %t315 = getelementptr { i64, [2 x i64] }, ptr %t314, i32 0, i32 0
  store i64 0, ptr %t315
  %t317 = insertvalue { i64 } undef, i64 %t313, 0
  %t318 = getelementptr { i64, [2 x i64] }, ptr %t314, i32 0, i32 1
  store { i64 } %t317, ptr %t318
  %t319 = load { i64, [2 x i64] }, ptr %t314
  %t321 = load i64, ptr %l155
  %t322 = inttoptr i64 %t321 to ptr
  %t323 = call ptr @__olang_scope_alloc_a(ptr %t322, i64 24, i64 8)
  store { i64, [2 x i64] } %t319, ptr %t323
  %t325 = load ptr, ptr %lp8
  %t326 = load i64, ptr %l154, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %t325, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr ptr, ptr %t328, i64 %t326
  store ptr %t323, ptr %t329, !tbaa !39
  br label %bb77
bb66:
  %t330 = load ptr, ptr %l15, !tbaa !29
  store ptr %t330, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t331 = load ptr, ptr %l160, !tbaa !29
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %bb67, label %bb68
bb67:
  %t334 = load ptr, ptr %l160, !tbaa !29
  %t335 = load i64, ptr %t334, !range !{i64 0, i64 18}
  %t337 = icmp eq i64 %t335, 1
  store i1 %t337, ptr %l161, !tbaa !21
  br label %bb68
bb68:
  %t338 = load i1, ptr %l161, !tbaa !21
  br i1 %t338, label %bb69, label %bb70
bb69:
  %t339 = load ptr, ptr %l15, !tbaa !29
  %t341 = getelementptr { i64, [5 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t341, i32 0, i32 3
  %t343 = load ptr, ptr %t342
  store ptr %t343, ptr %l18, !tbaa !29
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t345 = load i64, ptr %l14, !tbaa !24
  %t346 = load ptr, ptr %l18, !tbaa !29
  %t348 = load ptr, ptr %lp8
  %t350 = getelementptr { i64, ptr }, ptr %t348, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr ptr, ptr %t351, i64 %t345
  store ptr %t346, ptr %t352, !tbaa !39
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store ptr null, ptr %rv
  br label %ret
bb76:
  call void @__olang_check_failed(ptr @olang_loc_81d441761e2a717d_f45e749fdf1e1e81)
  unreachable
bb77:
  br label %bb78
bb78:
  %t354 = load i64, ptr %l13, !tbaa !24
  %t356 = add i64 %t354, 1
  store i64 %t356, ptr %l13, !tbaa !24
  br label %bb47
bb79:
  %t358 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t358, ptr %l171
  %t359 = load i32, ptr %l2, !tbaa !23
  store i32 %t359, ptr %l172, !tbaa !23
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t360)
  store ptr %t362, ptr %l174
  br label %bb80
bb80:
  %t363 = load ptr, ptr %l174, !tbaa !29
  %t365 = getelementptr %"compiler/check:frame", ptr %t363, i32 0, i32 2
  %t366 = load i64, ptr %t365, !tbaa !24
  %t367 = load ptr, ptr %lp8
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t369
  %t370 = getelementptr { i64, [2 x i64] }, ptr %t369, i32 0, i32 0
  store i64 2, ptr %t370
  %t372 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t368, 0
  %t373 = getelementptr { i64, [2 x i64] }, ptr %t369, i32 0, i32 1
  store { { i64, ptr } } %t372, ptr %t373
  %t374 = load { i64, [2 x i64] }, ptr %t369
  %t376 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t374, ptr %t376
  store { i64, [5 x i64] } zeroinitializer, ptr %t377
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t377, i32 0, i32 0
  store i64 1, ptr %t378
  %t379 = load %"compiler/source:Span", ptr %l171
  %t380 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t379, 0
  %t381 = load i32, ptr %l172, !tbaa !23
  %t382 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t380, i32 %t381, 1
  %t384 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t382, i64 %t366, 2
  %t386 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t384, ptr %t376, 3
  %t387 = getelementptr { i64, [5 x i64] }, ptr %t377, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t386, ptr %t387
  %t388 = load { i64, [5 x i64] }, ptr %t377
  %t390 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t388, ptr %t390
  store ptr %t390, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedBitOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, i32 %a5, i32 %a6, { i64, ptr } %a7, { i64, ptr } %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca i32
  %l21 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca %"compiler/diagmsg:Msg"
  %l31 = alloca i64
  %l36 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i64
  %l65 = alloca ptr
  %l69 = alloca i1
  %l73 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i64
  %l83 = alloca { i64, ptr }
  %l86 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca i64
  %l92 = alloca ptr
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l107 = alloca i32
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l117 = alloca i32
  %l118 = alloca ptr
  %l121 = alloca i32
  %l127 = alloca ptr
  %l131 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l136 = alloca %"compiler/source:Span"
  %l139 = alloca { i64, ptr }
  %l141 = alloca %"compiler/diagmsg:Msg"
  %l142 = alloca i64
  %l145 = alloca ptr
  %l149 = alloca i32
  %l151 = alloca i32
  %l153 = alloca ptr
  %l154 = alloca { i64, ptr }
  %l156 = alloca %"compiler/source:Span"
  %l158 = alloca i32
  %l161 = alloca ptr
  %l169 = alloca ptr
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a5, ptr %l5
  store i32 %a6, ptr %l6
  store { i64, ptr } %a7, ptr %l7
  store { i64, ptr } %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = call i32 @compiler_2fcheck_2ebitOp(ptr %v3, { i64, ptr } %t1)
  store i32 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i32, ptr %l16, !range !{i32 0, i32 52}
  store i32 %t4, ptr %l9
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l6, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l21
  br label %bb2
bb2:
  %t15 = load i1, ptr %l21, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l23, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t19, ptr %l24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t20, ptr %l25, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l28
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t26 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  %t28 = extractvalue { i64, ptr } %t26, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t33 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t35 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBitOpNotInteger(ptr %v3, ptr %s1, ptr %v0, { i64, ptr } %t33, { i64, ptr } %t32)
  store %"compiler/diagmsg:Msg" %t35, ptr %l30
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l24
  %t38 = load %"compiler/diagmsg:Msg", ptr %l30
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t36, %"compiler/source:Span" %t37, %"compiler/diagmsg:Msg" %t38)
  store i64 %t39, ptr %l31
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t40, { i64, ptr } %t41)
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t44, %"compiler/source:Span" %t45)
  store ptr %t48, ptr %l36
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l36, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  store ptr %t49, ptr %rv
  br label %ret
bb10:
  %t51 = load i32, ptr %l9, !range !{i32 0, i32 52}
  %t53 = trunc i64 36 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l6, !tbaa !23
  %t65 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t61, i32 %t62)
  store i64 %t65, ptr %l45
  br label %bb13
bb12:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb14
bb13:
  %t66 = load i64, ptr %l45, !tbaa !24
  %t67 = srem i64 %t66, 8
  %t69 = icmp ne i64 %t67, 0
  store i1 %t69, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l48, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t73, ptr %l49
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l5, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t74, i32 %t75)
  store { i64, ptr } %t78, ptr %l52
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t79 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = mul i64 %t80, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t82)
  call void @llvm.memcpy.p0.p0.i64(ptr %t83, ptr %t81, i64 %t82, i1 false)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l53, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l6, !tbaa !23
  %t95 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t91, i32 %t92)
  store i64 %t95, ptr %l58
  br label %bb18
bb18:
  %t96 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t97 = load i64, ptr %l58, !tbaa !24
  %t98 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eByteSwapWidth(ptr %s2, ptr %v0, { i64, ptr } %t96, i64 %t97)
  store %"compiler/diagmsg:Msg" %t98, ptr %l59
  br label %bb19
bb19:
  %t99 = load ptr, ptr %l48, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l49
  %t101 = load %"compiler/diagmsg:Msg", ptr %l59
  %t102 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t99, %"compiler/source:Span" %t100, %"compiler/diagmsg:Msg" %t101)
  store i64 %t102, ptr %l60
  br label %bb20
bb20:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t103, { i64, ptr } %t104)
  br label %bb21
bb21:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t107, %"compiler/source:Span" %t108)
  store ptr %t111, ptr %l65
  br label %bb22
bb22:
  %t112 = load ptr, ptr %l65, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t112, ptr %rv
  br label %ret
bb23:
  %t114 = load i32, ptr %l9, !range !{i32 0, i32 52}
  %t116 = trunc i64 34 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb26
bb25:
  %t119 = load i32, ptr %l9, !range !{i32 0, i32 52}
  %t121 = trunc i64 35 to i32
  %t122 = icmp eq i32 %t119, %t121
  store i1 %t122, ptr %l69, !tbaa !21
  br label %bb26
bb26:
  %t124 = load i1, ptr %l69, !tbaa !21
  store i1 %t124, ptr %l10, !tbaa !21
  %t125 = load i1, ptr %l10, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb27:
  store i64 1, ptr %l73, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb29
bb29:
  %t127 = load i64, ptr %l73, !tbaa !24
  store i64 %t127, ptr %l11, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = icmp ne i64 %t130, %t131
  br i1 %t134, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t137, ptr %l79
  %t138 = load i64, ptr %l11, !tbaa !24
  store i64 %t138, ptr %l80, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = icmp eq i64 %t139, 1
  br i1 %t141, label %bb32, label %bb33
bb31:
  br label %bb39
bb32:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb34
bb34:
  %t143 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = load i64, ptr %l80, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t149 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s3, ptr %v0, i64 %t146, { i64, ptr } %t147, i64 %t145)
  store %"compiler/diagmsg:Msg" %t149, ptr %l86
  br label %bb35
bb35:
  %t150 = load ptr, ptr %l78, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l79
  %t152 = load %"compiler/diagmsg:Msg", ptr %l86
  %t153 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t150, %"compiler/source:Span" %t151, %"compiler/diagmsg:Msg" %t152)
  store i64 %t153, ptr %l87
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t154, { i64, ptr } %t155)
  br label %bb37
bb37:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  %t162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t158, %"compiler/source:Span" %t159)
  store ptr %t162, ptr %l92
  br label %bb38
bb38:
  %t163 = load ptr, ptr %l92, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t163, ptr %rv
  br label %ret
bb39:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v2, ptr %v5, ptr %t165, ptr %a4, %"compiler/source:Span" %t167)
  store ptr %t171, ptr %l97
  br label %bb40
bb40:
  %t172 = load ptr, ptr %l97, !tbaa !29
  store ptr %t172, ptr %l12, !tbaa !29
  %t173 = load i1, ptr %l10, !tbaa !21
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb41, label %bb42
bb41:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l100, !tbaa !29
  %t178 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t178, ptr %l101
  %t179 = load i32, ptr %l9, !range !{i32 0, i32 52}
  %t181 = trunc i64 36 to i32
  %t182 = icmp eq i32 %t179, %t181
  br i1 %t182, label %bb43, label %bb44
bb42:
  br label %bb48
bb43:
  %t184 = load i32, ptr %l5, !tbaa !23
  store i32 %t184, ptr %l104, !tbaa !23
  br label %bb46
bb44:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t186)
  store i32 %t188, ptr %l107
  br label %bb45
bb45:
  %t189 = load i32, ptr %l107, !tbaa !23
  store i32 %t189, ptr %l104, !tbaa !23
  br label %bb46
bb46:
  %t190 = load i32, ptr %l9, !range !{i32 0, i32 52}
  %t191 = load ptr, ptr %l12, !tbaa !29
  %t192 = load ptr, ptr %l100, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l101
  %t194 = load i32, ptr %l104, !tbaa !23
  %t197 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v5, ptr %v0, ptr %v5, ptr %t192, %"compiler/source:Span" %t193, i32 %t194, i32 %t190, ptr %t191, ptr null)
  store ptr %t197, ptr %l110
  br label %bb47
bb47:
  %t198 = load ptr, ptr %l110, !tbaa !29
  store ptr %t198, ptr %rv
  br label %ret
bb48:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l112, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t201, ptr %l113, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr ptr, ptr %t203, i64 0
  %t205 = load ptr, ptr %t204, !tbaa !39
  store ptr %t205, ptr %l115, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t207)
  store i32 %t209, ptr %l117
  br label %bb49
bb49:
  %t210 = load ptr, ptr %l112, !tbaa !29
  %t211 = load ptr, ptr %l115, !tbaa !29
  %t212 = load i32, ptr %l117, !tbaa !23
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v4, ptr %v5, ptr %t210, ptr %t211, i32 %t212)
  store ptr %t213, ptr %l118
  br label %bb50
bb50:
  %t214 = load ptr, ptr %l118, !tbaa !29
  store ptr %t214, ptr %l13, !tbaa !29
  %t215 = load ptr, ptr %l13, !tbaa !29
  %t218 = call i32 @compiler_2fcheck_2etypeOf(ptr %v5, ptr %t215)
  store i32 %t218, ptr %l121
  br label %bb51
bb51:
  %t219 = load i32, ptr %l121, !tbaa !23
  store i32 %t219, ptr %l14, !tbaa !23
  %t220 = load i32, ptr %l14, !tbaa !23
  %t221 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t224 = icmp eq i32 %t220, %t221
  br i1 %t224, label %bb52, label %bb53
bb52:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t226, %"compiler/source:Span" %t227)
  store ptr %t230, ptr %l127
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t231 = load ptr, ptr %l127, !tbaa !29
  store ptr %t231, ptr %rv
  br label %ret
bb55:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l14, !tbaa !23
  %t237 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t233, i32 %t234)
  store i1 %t237, ptr %l131
  br label %bb56
bb56:
  %t238 = load i1, ptr %l131, !tbaa !21
  %t239 = xor i1 %t238, true
  br i1 %t239, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s6
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l133, !tbaa !29
  %t242 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t242, ptr %l134, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 0
  %t246 = load ptr, ptr %t245, !tbaa !39
  %t248 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v4, ptr %t246)
  store %"compiler/source:Span" %t248, ptr %l136
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i32, ptr %l14, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t249, i32 %t250)
  store { i64, ptr } %t253, ptr %l139
  br label %bb60
bb60:
  %t254 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  %t256 = extractvalue { i64, ptr } %t254, 1
  %t257 = mul i64 %t255, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t256, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  %t262 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBitOpCount(ptr %s6, ptr %v0, { i64, ptr } %t260)
  store %"compiler/diagmsg:Msg" %t262, ptr %l141
  br label %bb61
bb61:
  %t263 = load ptr, ptr %l133, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l136
  %t265 = load %"compiler/diagmsg:Msg", ptr %l141
  %t266 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t263, %"compiler/source:Span" %t264, %"compiler/diagmsg:Msg" %t265)
  store i64 %t266, ptr %l142
  br label %bb62
bb62:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l1
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t267, %"compiler/source:Span" %t268)
  store ptr %t271, ptr %l145
  br label %bb63
bb63:
  %t272 = load ptr, ptr %l145, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  store ptr %t272, ptr %rv
  br label %ret
bb64:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l14, !tbaa !23
  %t278 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t274, i32 %t275)
  store i32 %t278, ptr %l149
  br label %bb65
bb65:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t279)
  store i32 %t281, ptr %l151
  br label %bb66
bb66:
  %t282 = load i32, ptr %l149, !tbaa !23
  %t283 = load i32, ptr %l151, !tbaa !23
  %t284 = icmp ne i32 %t282, %t283
  br i1 %t284, label %bb67, label %bb68
bb67:
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l153, !tbaa !29
  %t287 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t287, ptr %l154, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr ptr, ptr %t289, i64 0
  %t291 = load ptr, ptr %t290, !tbaa !39
  %t293 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v4, ptr %t291)
  store %"compiler/source:Span" %t293, ptr %l156
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t294)
  store i32 %t296, ptr %l158
  br label %bb70
bb70:
  %t297 = load ptr, ptr %l13, !tbaa !29
  %t298 = load ptr, ptr %l153, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l156
  %t300 = load i32, ptr %l158, !tbaa !23
  %t303 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v5, ptr %v0, ptr %v5, ptr %t298, %"compiler/source:Span" %t299, i32 %t300, i32 20, ptr %t297, ptr null)
  store ptr %t303, ptr %l161
  br label %bb71
bb71:
  %t304 = load ptr, ptr %l161, !tbaa !29
  store ptr %t304, ptr %l13, !tbaa !29
  br label %bb72
bb72:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l1
  %t307 = load i32, ptr %l5, !tbaa !23
  %t308 = load i32, ptr %l9, !range !{i32 0, i32 52}
  %t309 = load ptr, ptr %l12, !tbaa !29
  %t310 = load ptr, ptr %l13, !tbaa !29
  %t318 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v5, ptr %v5, ptr %v5, ptr %t305, %"compiler/source:Span" %t306, i32 %t307, i32 %t308, ptr %t309, ptr %t310)
  store ptr %t318, ptr %l169
  br label %bb73
bb73:
  %t319 = load ptr, ptr %l169, !tbaa !29
  store ptr %t319, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedGet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, i32 %a5, i32 %a6, { i64, ptr } %a7, { i64, ptr } %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca i64
  %l25 = alloca { i64, ptr }
  %l28 = alloca %"compiler/diagmsg:Msg"
  %l29 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i32
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca i32
  %l53 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l58 = alloca i32
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l87 = alloca ptr
  %l92 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t67 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  store i32 %a6, ptr %l6
  store { i64, ptr } %a7, ptr %l7
  store { i64, ptr } %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i1, ptr %l14, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i64 1, ptr %l15, !tbaa !24
  br label %bb4
bb3:
  store i64 2, ptr %l15, !tbaa !24
  br label %bb4
bb4:
  %t5 = load i64, ptr %l15, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = load i64, ptr %l9, !tbaa !24
  %t12 = icmp ne i64 %t8, %t9
  br i1 %t12, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l20, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t15, ptr %l21
  %t16 = load i64, ptr %l9, !tbaa !24
  store i64 %t16, ptr %l22, !tbaa !24
  %t17 = load i64, ptr %l9, !tbaa !24
  %t19 = icmp eq i64 %t17, 1
  br i1 %t19, label %bb7, label %bb8
bb6:
  br label %bb14
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb9
bb9:
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = load i64, ptr %l22, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t27 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s1, ptr %v0, i64 %t24, { i64, ptr } %t25, i64 %t23)
  store %"compiler/diagmsg:Msg" %t27, ptr %l28
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l21
  %t30 = load %"compiler/diagmsg:Msg", ptr %l28
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t28, %"compiler/source:Span" %t29, %"compiler/diagmsg:Msg" %t30)
  store i64 %t31, ptr %l29
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t32, { i64, ptr } %t33)
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t36, %"compiler/source:Span" %t37)
  store ptr %t40, ptr %l34
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l34, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t41, ptr %rv
  br label %ret
bb14:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v5, ptr %t43)
  store ptr %t45, ptr %l37
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l37, !tbaa !29
  store ptr %t46, ptr %l10, !tbaa !29
  %t47 = load ptr, ptr %l10, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t51)
  store %"compiler/source:Span" %t53, ptr %l41
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t57 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t54)
  store i32 %t57, ptr %l44
  br label %bb19
bb19:
  %t58 = load ptr, ptr %l4, !tbaa !29
  store ptr %t58, ptr %l45, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l46, !tbaa !29
  store i32 8, ptr %l47
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l49
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l46, !tbaa !29
  %t64 = load i32, ptr %l47, !range !{i32 0, i32 9}
  %t65 = load %"compiler/source:Span", ptr %l49
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t63, i32 %t64, %"compiler/source:Span" %t65)
  store i32 %t66, ptr %l50
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 0
  store i64 6, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l41
  %t70 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t69, 0
  %t71 = load i32, ptr %l44, !tbaa !23
  %t72 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t70, i32 %t71, 1
  %t73 = load ptr, ptr %l45, !tbaa !29
  %t74 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t72, ptr %t73, 2
  %t75 = load i32, ptr %l50, !tbaa !23
  %t76 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t74, i32 %t75, 3
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t76, ptr %t77
  %t78 = load { i64, [4 x i64] }, ptr %t67
  %t80 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 40, i64 8)
  store { i64, [4 x i64] } %t78, ptr %t80
  store ptr %t80, ptr %l10, !tbaa !29
  br label %bb22
bb22:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l53, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %t83)
  store i32 %t85, ptr %l55
  br label %bb23
bb23:
  %t86 = mul i64 1, 4
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 1, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l56, !tbaa !27
  %t90 = load i32, ptr %l55, !tbaa !23
  %t91 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i32, ptr %t92, i64 0
  store i32 %t90, ptr %t93, !tbaa !33
  %t95 = load ptr, ptr %l53, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t98 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t95, { i64, ptr } %t96, %"compiler/source:Span" %a2, i1 false)
  store i32 %t98, ptr %l58
  br label %bb24
bb24:
  %t99 = load i32, ptr %l58, !range !{i32 0, i32 4}
  store i32 %t99, ptr %l11
  %t100 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t102, ptr %l60
  br label %bb25
bb25:
  %t103 = load i1, ptr %l60, !tbaa !21
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l61, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t105, ptr %l62
  %t106 = load ptr, ptr %l10, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  br i1 %t108, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  call void @__olang_check_failed(ptr @olang_loc_6002682392a89678_bee70fdc9b2b3a94)
  unreachable
bb29:
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t111 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t111, ptr %l66, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 0
  %t115 = load ptr, ptr %t114, !tbaa !39
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t117, ptr %l69, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 1
  %t121 = load ptr, ptr %t120, !tbaa !39
  %t123 = load i32, ptr %l11, !range !{i32 0, i32 4}
  %t124 = load ptr, ptr %l61, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l62
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v5, ptr %v4, ptr %v4, ptr %v5, ptr %t124, %"compiler/source:Span" %t125, ptr %t110, ptr %t115, ptr %t121, i32 %t123)
  store ptr %t130, ptr %l73
  br label %bb31
bb31:
  %t131 = load ptr, ptr %l73, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t131, ptr %rv
  br label %ret
bb32:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l75, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t134, ptr %l76
  %t135 = load ptr, ptr %l10, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  br i1 %t137, label %bb33, label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_2959120118b86297_7adce6d47ed385a3)
  unreachable
bb34:
  br label %bb35
bb35:
  %t139 = load ptr, ptr %l10, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t141 = load i32, ptr %l11, !range !{i32 0, i32 4}
  %t142 = load ptr, ptr %l75, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l76
  %t147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v5, ptr %v4, ptr %v5, ptr %t142, %"compiler/source:Span" %t143, ptr %t139, { i64, ptr } %t140, i32 %t141)
  store ptr %t147, ptr %l82
  br label %bb36
bb36:
  %t148 = load ptr, ptr %l82, !tbaa !29
  store ptr %t148, ptr %l12, !tbaa !29
  %t149 = load ptr, ptr %l12, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb37, label %bb38
bb37:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l1
  %t157 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t153, %"compiler/source:Span" %t154)
  store ptr %t157, ptr %l87
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t158 = load ptr, ptr %l87, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t158, ptr %rv
  br label %ret
bb40:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l1
  %t162 = load ptr, ptr %l12, !tbaa !29
  %t166 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v5, ptr %v5, ptr %t160, %"compiler/source:Span" %t161, ptr %t162)
  store ptr %t166, ptr %l92
  br label %bb41
bb41:
  %t167 = load ptr, ptr %l92, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t167, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopAssert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i1
  %l36 = alloca ptr
  %l42 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/check:TopAssertAsk"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %t1, i64 %t2, ptr %t3, i32 %t4)
  store i64 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store i64 -1, ptr %l6, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  store ptr %t25, ptr %l20, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t26)
  store i32 %t28, ptr %l22
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t29 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load i32, ptr %l22, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t30, i32 %t31, i64 %t29)
  store i32 %t33, ptr %l24
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l15, !tbaa !29
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i32, ptr %l24, !tbaa !23
  %t38 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v2, ptr %t34, i64 %t35, ptr %t36, i32 %t37)
  store i64 %t38, ptr %l25
  br label %bb6
bb6:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb13
bb9:
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  store i1 %t52, ptr %l32, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l32, !tbaa !21
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 120
  store ptr %t58, ptr %l36, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l1, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l42
  br label %bb17
bb17:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l44, !tbaa !24
  store %"compiler/source:Span" %a2, ptr %l45
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  store %"compiler/source:Span" %t81, ptr %l48
  br label %bb18
bb18:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = load %"compiler/source:Span", ptr %l45
  %t86 = load %"compiler/source:Span", ptr %l48
  %t89 = call %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %s0, i64 %t84, %"compiler/source:Span" %t85, %"compiler/source:Span" %t86, i64 %t82, i64 %t83)
  store %"compiler/check:TopAssertAsk" %t89, ptr %l51
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l36, !tbaa !29
  %t91 = load %"compiler/check:TopAssertAsk", ptr %l51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eP_H67072fc16e996275e069a499f28fddf9(ptr %v0, ptr %t90, %"compiler/check:TopAssertAsk" %t91)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l38 = alloca %"compiler/source:Span"
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i64
  %l62 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l78 = alloca %"compiler/source:Span"
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l83 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l103 = alloca %"compiler/diagmsg:Msg"
  %l104 = alloca i64
  %l107 = alloca ptr
  %l112 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l119 = alloca { i64, ptr }
  %l121 = alloca %"compiler/diagmsg:Msg"
  %l122 = alloca i64
  %l125 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca i32
  %l135 = alloca i32
  %l139 = alloca { i64, ptr }
  %l144 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l150 = alloca { i64, ptr }
  %l152 = alloca %"compiler/diagmsg:Msg"
  %l153 = alloca i64
  %l156 = alloca ptr
  %l162 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t309 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l10
  br label %bb1
bb1:
  %t5 = load i32, ptr %l10, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l3, !tbaa !29
  store ptr %t12, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l18
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i32, ptr %l18, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i1, ptr %l19, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb9:
  %t29 = load i1, ptr %l23, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l28
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  %t38 = load i1, ptr %l28, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l24, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t45 = trunc i64 68 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb17, label %bb18
bb16:
  br label %bb62
bb17:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb19
bb19:
  %t48 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l33, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l36
  br label %bb20
bb20:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l37, !tbaa !27
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l38
  %t57 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t59 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t57)
  store { i64, ptr } %t59, ptr %l40
  br label %bb21
bb21:
  %t60 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t61, ptr %l41
  br label %bb22
bb22:
  %t62 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l36, !tbaa !23
  %t72 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t73 = load %"compiler/source:Span", ptr %l38
  %t75 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %t69, ptr %s2, ptr %t70, i32 %t71, { i64, ptr } %t72, i64 0, %"compiler/source:Span" %t73, { i64, ptr } %t68)
  store i64 %t75, ptr %l43
  br label %bb23
bb23:
  %t76 = load i64, ptr %l43, !tbaa !24
  store i64 %t76, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = icmp sge i64 %t77, 0
  br i1 %t79, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l46, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s3, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l51
  br label %bb26
bb25:
  br label %bb43
bb26:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t95, i32 %t94)
  store { i64, ptr } %t97, ptr %l54
  br label %bb27
bb27:
  %t98 = load ptr, ptr %l46, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 61
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l55, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t102 = load ptr, ptr %l46, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 61
  store { i64, ptr } %t101, ptr %t103, !tbaa !27
  %t104 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e61
  br i1 %t104, label %bb28, label %bb29
bb28:
  %t106 = load { i64, ptr }, ptr %l55
  %t107 = extractvalue { i64, ptr } %t106, 1
  call void @__olang_region_release(ptr %t107)
  store { i64, ptr } zeroinitializer, ptr %l55
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l57, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t109, ptr %l58
  %t110 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t110, ptr %l59
  %t111 = load i64, ptr %l6, !tbaa !24
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load ptr, ptr %l3, !tbaa !29
  store ptr %t112, ptr %l62, !tbaa !29
  %t114 = icmp sge i64 0, 0
  br i1 %t114, label %bb30, label %bb31
bb30:
  %t116 = icmp sle i64 0, 1152921504606846975
  br i1 %t116, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb32:
  %t118 = mul i64 0, 8
  %t119 = insertvalue { i64, ptr } undef, i64 0, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t120, ptr %l65, !tbaa !27
  %t121 = icmp sge i64 0, 0
  br i1 %t121, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb34:
  %t123 = icmp sle i64 0, 1152921504606846975
  br i1 %t123, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb36:
  %t125 = mul i64 0, 8
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t127, ptr %l68, !tbaa !27
  %t128 = icmp sge i64 0, 0
  br i1 %t128, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb38:
  %t130 = icmp sle i64 0, 2305843009213693951
  br i1 %t130, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919)
  unreachable
bb40:
  %t132 = mul i64 0, 4
  %t133 = insertvalue { i64, ptr } undef, i64 0, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t135 = load ptr, ptr %l57, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l58
  %t137 = load %"compiler/source:Span", ptr %l59
  %t138 = load i64, ptr %l60, !tbaa !24
  %t139 = load ptr, ptr %l62, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v2, ptr %v2, ptr %t135, %"compiler/source:Span" %t136, %"compiler/source:Span" %t137, i64 %t138, ptr %t139, { i64, ptr } %t140, { i64, ptr } %t141, { i64, ptr } %t134)
  store ptr %t143, ptr %l72
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  %t144 = load ptr, ptr %l72, !tbaa !29
  store ptr %t144, ptr %rv
  br label %ret
bb43:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l73, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l4, !tbaa !23
  %t150 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l76
  br label %bb44
bb44:
  %t151 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t151, ptr %l77, !tbaa !27
  %t152 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t152, ptr %l78
  %t153 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t155 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t153)
  store { i64, ptr } %t155, ptr %l80
  br label %bb45
bb45:
  %t156 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t157 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t156)
  store { i64, ptr } %t157, ptr %l81
  br label %bb46
bb46:
  %t158 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t165 = load ptr, ptr @__olang_prog_scope
  %t166 = load ptr, ptr %l73, !tbaa !29
  %t167 = load i32, ptr %l76, !tbaa !23
  %t168 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t169 = load %"compiler/source:Span", ptr %l78
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %t165, ptr %s2, ptr %t166, i32 %t167, { i64, ptr } %t168, %"compiler/source:Span" %t169, { i64, ptr } %t164, i64 0, i1 false)
  store i1 %t171, ptr %l83
  br label %bb47
bb47:
  %t172 = load i1, ptr %l83, !tbaa !21
  br i1 %t172, label %bb48, label %bb49
bb48:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t173, %"compiler/source:Span" %t174)
  store ptr %t177, ptr %l86
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s2)
  %t178 = load ptr, ptr %l86, !tbaa !29
  store ptr %t178, ptr %rv
  br label %ret
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l4, !tbaa !23
  %t183 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t179, i32 %t180)
  store i1 %t183, ptr %l89
  br label %bb52
bb52:
  %t184 = load i1, ptr %l89, !tbaa !21
  br i1 %t184, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s5
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l90, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l91
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l4, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t187, i32 %t188)
  store { i64, ptr } %t191, ptr %l94
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t192 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t194 = extractvalue { i64, ptr } %t192, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l95, !tbaa !27
  %t199 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t201 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t199)
  store { i64, ptr } %t201, ptr %l97
  br label %bb56
bb56:
  %t202 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t203 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s5, ptr %s5, { i64, ptr } %t202)
  store { i64, ptr } %t203, ptr %l98
  br label %bb57
bb57:
  %t204 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = mul i64 %t205, 1
  %t208 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t207)
  call void @llvm.memcpy.p0.p0.i64(ptr %t208, ptr %t206, i64 %t207, i1 false)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t211 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t215 = extractvalue { i64, ptr } %t211, 1
  %t216 = extractvalue { i64, ptr } %t211, 0
  %t217 = add i64 %t213, %t216
  %t218 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t212, i64 %t213)
  %t222 = getelementptr i8, ptr %t221, i64 %t213
  call void @olang_textcopy(ptr %t222, ptr %t215, i64 %t216)
  %t223 = getelementptr i8, ptr %t222, i64 %t216
  call void @olang_textcopy(ptr %t223, ptr %t218, i64 %t219)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t221, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } %t225, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  %t233 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t236 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s5, ptr %s5, ptr %s5, ptr %v0, { i64, ptr } %t233, { i64, ptr } %t210, { i64, ptr } %t232)
  store %"compiler/diagmsg:Msg" %t236, ptr %l103
  br label %bb58
bb58:
  %t237 = load ptr, ptr %l90, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l91
  %t239 = load %"compiler/diagmsg:Msg", ptr %l103
  %t240 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t237, %"compiler/source:Span" %t238, %"compiler/diagmsg:Msg" %t239)
  store i64 %t240, ptr %l104
  br label %bb59
bb59:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l1
  %t245 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t241, %"compiler/source:Span" %t242)
  store ptr %t245, ptr %l107
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  %t246 = load ptr, ptr %l107, !tbaa !29
  store ptr %t246, ptr %rv
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb62:
  %t247 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t249 = trunc i64 68 to i32
  %t250 = icmp eq i32 %t247, %t249
  br i1 %t250, label %bb63, label %bb64
bb63:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load i32, ptr %l4, !tbaa !23
  %t256 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t252, i32 %t253)
  store i1 %t256, ptr %l112
  br label %bb65
bb64:
  br label %bb76
bb65:
  %t257 = load i1, ptr %l112, !tbaa !21
  %t258 = xor i1 %t257, true
  br i1 %t258, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l114, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t261, ptr %l115
  %t262 = load i32, ptr %l4, !tbaa !23
  store i32 %t262, ptr %l116, !tbaa !23
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i32, ptr %l4, !tbaa !23
  %t267 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t263, i32 %t264)
  store { i64, ptr } %t267, ptr %l119
  br label %bb68
bb67:
  br label %bb72
bb68:
  %t268 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  %t270 = extractvalue { i64, ptr } %t268, 1
  %t271 = mul i64 %t269, 1
  %t272 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t271)
  call void @llvm.memcpy.p0.p0.i64(ptr %t272, ptr %t270, i64 %t271, i1 false)
  %t273 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  %t276 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s8, ptr %s8, ptr %v0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, { i64, ptr } %t274)
  store %"compiler/diagmsg:Msg" %t276, ptr %l121
  br label %bb69
bb69:
  %t277 = load ptr, ptr %l114, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l115
  %t279 = load i32, ptr %l116, !tbaa !23
  %t280 = load %"compiler/diagmsg:Msg", ptr %l121
  %t281 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s8, ptr %v0, ptr %t277, %"compiler/source:Span" %t278, i32 %t279, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d35, i32 0, i32 1) }, %"compiler/diagmsg:Msg" %t280)
  store i64 %t281, ptr %l122
  br label %bb70
bb70:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l1
  %t286 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t282, %"compiler/source:Span" %t283)
  store ptr %t286, ptr %l125
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s8)
  %t287 = load ptr, ptr %l125, !tbaa !29
  store ptr %t287, ptr %rv
  br label %ret
bb72:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 44
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t290)
  store i64 %t292, ptr %l128
  br label %bb73
bb73:
  %t293 = load i64, ptr %l128, !tbaa !24
  store i64 %t293, ptr %l7, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 44
  %t297 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t296, ptr %t297)
  br label %bb74
bb74:
  %t300 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t300, ptr %l132
  %t301 = load i32, ptr %l4, !tbaa !23
  store i32 %t301, ptr %l133, !tbaa !23
  store i32 0, ptr %l134
  store i32 0, ptr %l135
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 44
  %t305 = load i64, ptr %l7, !tbaa !24
  %t308 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t304, i64 %t305)
  store { i64, ptr } %t308, ptr %l139
  br label %bb75
bb75:
  store { i64, [5 x i64] } zeroinitializer, ptr %t309
  %t310 = getelementptr { i64, [5 x i64] }, ptr %t309, i32 0, i32 0
  store i64 9, ptr %t310
  %t311 = load %"compiler/source:Span", ptr %l132
  %t312 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t311, 0
  %t313 = load i32, ptr %l133, !tbaa !23
  %t314 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t312, i32 %t313, 1
  %t315 = load i32, ptr %l134, !range !{i32 0, i32 52}
  %t316 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t314, i32 %t315, 2
  %t317 = load i32, ptr %l135, !range !{i32 0, i32 4}
  %t318 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t316, i32 %t317, 3
  %t319 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t320 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t318, { i64, ptr } %t319, 4
  %t321 = getelementptr { i64, [5 x i64] }, ptr %t309, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t320, ptr %t321
  %t322 = load { i64, [5 x i64] }, ptr %t309
  %t324 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t322, ptr %t324
  store ptr %t324, ptr %rv
  br label %ret
bb76:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l4, !tbaa !23
  %t330 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t326, i32 %t327)
  store i1 %t330, ptr %l144
  br label %bb77
bb77:
  %t331 = load i1, ptr %l144, !tbaa !21
  %t332 = xor i1 %t331, true
  br i1 %t332, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s9
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l146, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t335, ptr %l147
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l4, !tbaa !23
  %t340 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t336, i32 %t337)
  store { i64, ptr } %t340, ptr %l150
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t341 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 0
  %t343 = extractvalue { i64, ptr } %t341, 1
  %t344 = mul i64 %t342, 1
  %t345 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t344)
  call void @llvm.memcpy.p0.p0.i64(ptr %t345, ptr %t343, i64 %t344, i1 false)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  %t349 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s9, ptr %s9, ptr %v0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, { i64, ptr } %t347)
  store %"compiler/diagmsg:Msg" %t349, ptr %l152
  br label %bb81
bb81:
  %t350 = load ptr, ptr %l146, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l147
  %t352 = load %"compiler/diagmsg:Msg", ptr %l152
  %t353 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t350, %"compiler/source:Span" %t351, %"compiler/diagmsg:Msg" %t352)
  store i64 %t353, ptr %l153
  br label %bb82
bb82:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l1
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t354, %"compiler/source:Span" %t355)
  store ptr %t358, ptr %l156
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s9)
  %t359 = load ptr, ptr %l156, !tbaa !29
  store ptr %t359, ptr %rv
  br label %ret
bb84:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load %"compiler/source:Span", ptr %l1
  %t362 = load i32, ptr %l4, !tbaa !23
  %t363 = load ptr, ptr %l3, !tbaa !29
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t360, %"compiler/source:Span" %t361, i32 %t362, i32 1, ptr %t363, ptr null)
  store ptr %t369, ptr %l162
  br label %bb85
bb85:
  %t370 = load ptr, ptr %l162, !tbaa !29
  store ptr %t370, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolled(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, i64, i64 }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, i64, i64 }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l35 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l41 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca { i64, i64, i64 }
  %l59 = alloca ptr
  %l64 = alloca ptr
  %l75 = alloca i64
  %l78 = alloca i64
  %l98 = alloca i64
  %l102 = alloca { i64, i64, i64 }
  %l107 = alloca ptr
  %l112 = alloca ptr
  %l118 = alloca ptr
  %l120 = alloca i32
  %l125 = alloca i32
  %l126 = alloca i32
  %l127 = alloca ptr
  %l129 = alloca i32
  %l132 = alloca ptr
  %l134 = alloca i32
  %l136 = alloca i32
  %l137 = alloca i32
  %l161 = alloca i64
  %l163 = alloca ptr
  %l166 = alloca i64
  %l167 = alloca i32
  %l173 = alloca ptr
  %l176 = alloca i64
  %l180 = alloca { i64, i64, i64 }
  %l197 = alloca ptr
  %l215 = alloca i64
  %l217 = alloca ptr
  %l220 = alloca i64
  %l221 = alloca i32
  %l227 = alloca ptr
  %s0 = alloca %olang.scope
  %t258 = alloca { i64, [3 x i64] }, align 8
  %t325 = alloca { i64, [3 x i64] }, align 8
  %t356 = alloca { i64, [3 x i64] }, align 8
  %t380 = alloca { i64, [3 x i64] }, align 8
  %t422 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = add i32 %t4, 3
  %t9 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t2, i32 %t6)
  store %"compiler/source:Span" %t9, ptr %l35
  br label %bb1
bb1:
  %t10 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t10, ptr %l4
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:ForIn", ptr %t11, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l38, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t17, ptr %l39
  %t18 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTryList(ptr %v0)
  store %"compiler/diagmsg:Msg" %t18, ptr %l40
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t19 = load ptr, ptr %l38, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l39
  %t21 = load %"compiler/diagmsg:Msg", ptr %l40
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t19, %"compiler/source:Span" %t20, %"compiler/diagmsg:Msg" %t21)
  store i64 %t22, ptr %l41
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l42, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:ForIn", ptr %t24, i32 0, i32 2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t27)
  store %"compiler/source:Span" %t29, ptr %l45
  br label %bb7
bb7:
  %t30 = load %"compiler/check:reflList", ptr %l3
  %t31 = load ptr, ptr %l42, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l45
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/check:reflList" %t30)
  store { i64, ptr } %t34, ptr %l47
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 45
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l50
  br label %bb9
bb9:
  %t41 = load i64, ptr %l50, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t47 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t42, i32 2, %"compiler/source:Span" %t43)
  store { i64, i64, i64 } %t47, ptr %l54
  br label %bb10
bb10:
  %t48 = load { i64, i64, i64 }, ptr %l54
  store { i64, i64, i64 } %t48, ptr %l7
  %t49 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t52 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t58)
  store ptr %t60, ptr %l59
  br label %bb11
bb11:
  %t61 = load ptr, ptr %l59, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 11
  %t64 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t67)
  store ptr %t69, ptr %l64
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l64, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 19
  %t73 = load i64, ptr %l8, !tbaa !24
  %t75 = trunc i64 %t73 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t72, i32 %t75)
  br label %bb14
bb14:
  store i64 0, ptr %l11, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t83 = load i64, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load i64, ptr %l13, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb20
bb17:
  %t93 = load i64, ptr %l12, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l13, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l78, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb19
bb19:
  %t109 = load i64, ptr %l78, !tbaa !24
  store i64 %t109, ptr %l75, !tbaa !24
  br label %bb20
bb20:
  %t110 = load i64, ptr %l75, !tbaa !24
  store i64 %t110, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  %t111 = load i64, ptr %l15, !tbaa !24
  %t112 = load i64, ptr %l14, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb22, label %bb23
bb22:
  br label %bb55
bb23:
  br label %bb24
bb24:
  %t119 = load i64, ptr %l11, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  store i64 %t127, ptr %l16, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 45
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t131)
  store i64 %t133, ptr %l98
  br label %bb25
bb25:
  %t134 = load i64, ptr %l98, !tbaa !24
  store i64 %t134, ptr %l17, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t140 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t135, i32 2, %"compiler/source:Span" %t136)
  store { i64, i64, i64 } %t140, ptr %l102
  br label %bb26
bb26:
  %t141 = load { i64, i64, i64 }, ptr %l102
  store { i64, i64, i64 } %t141, ptr %l18
  %t142 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 0
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l19, !tbaa !24
  %t145 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 1
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l20, !tbaa !24
  %t148 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 2
  %t149 = load i64, ptr %t148, !tbaa !24
  store i64 %t149, ptr %l21, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t151)
  store ptr %t153, ptr %l107
  br label %bb27
bb27:
  %t154 = load ptr, ptr %l107, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 10
  %t157 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t156, i64 %t157)
  br label %bb28
bb28:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t160)
  store ptr %t162, ptr %l112
  br label %bb29
bb29:
  %t163 = load ptr, ptr %l112, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 19
  %t166 = load i64, ptr %l19, !tbaa !24
  %t168 = trunc i64 %t166 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t165, i32 %t168)
  br label %bb30
bb30:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l118, !tbaa !29
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr %"compiler/ast:ForIn", ptr %t173, i32 0, i32 1
  %t176 = load i32, ptr %t175, !tbaa !23
  store i32 %t176, ptr %l120, !tbaa !23
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load %"compiler/check:reflList", ptr %l3
  %t179 = load i64, ptr %l16, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i64, ptr %t182, i64 %t179
  %t184 = load i64, ptr %t183, !tbaa !34
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t177, %"compiler/check:reflList" %t178, i64 %t184)
  store i32 %t188, ptr %l125
  br label %bb31
bb31:
  %t189 = load ptr, ptr %l118, !tbaa !29
  %t190 = load i32, ptr %l120, !tbaa !23
  %t191 = load i32, ptr %l125, !tbaa !23
  %t192 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t189, i32 %t190, i32 %t191)
  store i32 %t192, ptr %l126
  br label %bb32
bb32:
  %t193 = load i32, ptr %l126, !tbaa !23
  store i32 %t193, ptr %l22, !tbaa !23
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l127, !tbaa !29
  %t195 = load ptr, ptr %l2, !tbaa !29
  %t197 = getelementptr %"compiler/ast:ForIn", ptr %t195, i32 0, i32 0
  %t198 = load i32, ptr %t197, !tbaa !23
  store i32 %t198, ptr %l129, !tbaa !23
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  store ptr %t204, ptr %l132, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t205)
  store i32 %t207, ptr %l134
  br label %bb33
bb33:
  %t208 = load i64, ptr %l16, !tbaa !24
  %t209 = load ptr, ptr %l132, !tbaa !29
  %t210 = load i32, ptr %l134, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t209, i32 %t210, i64 %t208)
  store i32 %t212, ptr %l136
  br label %bb34
bb34:
  %t213 = load ptr, ptr %l127, !tbaa !29
  %t214 = load i32, ptr %l129, !tbaa !23
  %t215 = load i32, ptr %l136, !tbaa !23
  %t216 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t213, i32 %t214, i32 %t215)
  store i32 %t216, ptr %l137
  br label %bb35
bb35:
  %t217 = load i32, ptr %l137, !tbaa !23
  store i32 %t217, ptr %l23, !tbaa !23
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/ast:ForIn", ptr %t218, i32 0, i32 4
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb36, label %bb37
bb36:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load ptr, ptr %l2, !tbaa !29
  %t230 = getelementptr %"compiler/ast:ForIn", ptr %t228, i32 0, i32 4
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t227, { i64, ptr } %t231)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l2, !tbaa !29
  %t237 = getelementptr %"compiler/ast:ForIn", ptr %t235, i32 0, i32 0
  %t238 = load i32, ptr %t237, !tbaa !23
  %t239 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t234, i32 %t238, i32 %t239)
  br label %bb40
bb40:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = getelementptr %"compiler/ast:ForIn", ptr %t244, i32 0, i32 1
  %t247 = load i32, ptr %t246, !tbaa !23
  %t248 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t243, i32 %t247, i32 %t248)
  br label %bb41
bb41:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  %t254 = load i64, ptr %l19, !tbaa !24
  %t256 = trunc i64 %t254 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t258
  %t259 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 0
  store i64 5, ptr %t259
  %t261 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t253, 0
  %t263 = insertvalue { %"compiler/source:Span", i32, i32 } %t261, i32 0, 1
  %t265 = insertvalue { %"compiler/source:Span", i32, i32 } %t263, i32 %t256, 2
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t265, ptr %t266
  %t267 = load { i64, [3 x i64] }, ptr %t258
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t267, ptr %t269
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t252, ptr %t269)
  br label %bb42
bb42:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t272)
  store ptr %t274, ptr %l163
  br label %bb43
bb43:
  %t275 = load ptr, ptr %l163, !tbaa !29
  %t277 = getelementptr %"compiler/check:frame", ptr %t275, i32 0, i32 10
  %t279 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t277)
  %t280 = extractvalue { i32, i64 } %t279, 1
  %t281 = extractvalue { i32, i64 } %t279, 0
  store i32 %t281, ptr %l167
  %t282 = icmp ne i32 %t281, 0
  br i1 %t282, label %bb45, label %ok.283, !prof !99
ok.283:
  store i64 %t280, ptr %l166
  br label %bb44
bb44:
  %t284 = load i64, ptr %l166, !tbaa !24
  store i64 %t284, ptr %l161, !tbaa !24
  br label %bb47
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i64, ptr %l19, !tbaa !24
  %t287 = load i64, ptr %l20, !tbaa !24
  %t288 = load i64, ptr %l21, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t295 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t285, i64 %t286, i64 %t287, i64 %t288, i64 %t289)
  store ptr %t295, ptr %l173
  br label %bb48
bb48:
  %t296 = load ptr, ptr %l173, !tbaa !29
  store ptr %t296, ptr %l24, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 45
  %t301 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t299)
  store i64 %t301, ptr %l176
  br label %bb49
bb49:
  %t302 = load i64, ptr %l176, !tbaa !24
  store i64 %t302, ptr %l25, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l1
  %t308 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t303, i32 3, %"compiler/source:Span" %t304)
  store { i64, i64, i64 } %t308, ptr %l180
  br label %bb50
bb50:
  %t309 = load { i64, i64, i64 }, ptr %l180
  store { i64, i64, i64 } %t309, ptr %l26
  %t310 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 0
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l27, !tbaa !24
  %t313 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 1
  %t314 = load i64, ptr %t313, !tbaa !24
  store i64 %t314, ptr %l28, !tbaa !24
  %t316 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 2
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l29, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l1
  %t321 = load i64, ptr %l19, !tbaa !24
  %t323 = trunc i64 %t321 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [3 x i64] }, ptr %t325, i32 0, i32 0
  store i64 5, ptr %t326
  %t328 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t320, 0
  %t330 = insertvalue { %"compiler/source:Span", i32, i32 } %t328, i32 0, 1
  %t332 = insertvalue { %"compiler/source:Span", i32, i32 } %t330, i32 %t323, 2
  %t333 = getelementptr { i64, [3 x i64] }, ptr %t325, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t332, ptr %t333
  %t334 = load { i64, [3 x i64] }, ptr %t325
  %t336 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t334, ptr %t336
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t319, ptr %t336)
  br label %bb51
bb51:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i64, ptr %l27, !tbaa !24
  %t341 = load i64, ptr %l28, !tbaa !24
  %t342 = load i64, ptr %l29, !tbaa !24
  %t343 = load i64, ptr %l25, !tbaa !24
  %t349 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t339, i64 %t340, i64 %t341, i64 %t342, i64 %t343)
  store ptr %t349, ptr %l197
  br label %bb52
bb52:
  %t350 = load ptr, ptr %l197, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l1
  %t353 = load ptr, ptr %l24, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 0
  store i64 4, ptr %t357
  %t359 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t352, 0
  %t361 = insertvalue { %"compiler/source:Span", ptr, ptr } %t359, ptr %t353, 1
  %t363 = insertvalue { %"compiler/source:Span", ptr, ptr } %t361, ptr %t350, 2
  %t364 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t363, ptr %t364
  %t365 = load { i64, [3 x i64] }, ptr %t356
  %t367 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t365, ptr %t367
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t351, ptr %t367)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t370 = load i64, ptr %l15, !tbaa !24
  %t372 = add i64 %t370, 1
  store i64 %t372, ptr %l15, !tbaa !24
  br label %bb21
bb55:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load %"compiler/source:Span", ptr %l1
  %t376 = load i64, ptr %l8, !tbaa !24
  %t378 = trunc i64 %t376 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t380
  %t381 = getelementptr { i64, [3 x i64] }, ptr %t380, i32 0, i32 0
  store i64 5, ptr %t381
  %t383 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t375, 0
  %t385 = insertvalue { %"compiler/source:Span", i32, i32 } %t383, i32 0, 1
  %t387 = insertvalue { %"compiler/source:Span", i32, i32 } %t385, i32 %t378, 2
  %t388 = getelementptr { i64, [3 x i64] }, ptr %t380, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t387, ptr %t388
  %t389 = load { i64, [3 x i64] }, ptr %t380
  %t391 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t389, ptr %t391
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t374, ptr %t391)
  br label %bb56
bb56:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t394)
  store ptr %t396, ptr %l217
  br label %bb57
bb57:
  %t397 = load ptr, ptr %l217, !tbaa !29
  %t399 = getelementptr %"compiler/check:frame", ptr %t397, i32 0, i32 11
  %t401 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t399)
  %t402 = extractvalue { i32, i64 } %t401, 1
  %t403 = extractvalue { i32, i64 } %t401, 0
  store i32 %t403, ptr %l221
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb59, label %ok.405, !prof !99
ok.405:
  store i64 %t402, ptr %l220
  br label %bb58
bb58:
  %t406 = load i64, ptr %l220, !tbaa !24
  store i64 %t406, ptr %l215, !tbaa !24
  br label %bb61
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load i64, ptr %l8, !tbaa !24
  %t409 = load i64, ptr %l9, !tbaa !24
  %t410 = load i64, ptr %l10, !tbaa !24
  %t411 = load i64, ptr %l6, !tbaa !24
  %t417 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t407, i64 %t408, i64 %t409, i64 %t410, i64 %t411)
  store ptr %t417, ptr %l227
  br label %bb62
bb62:
  %t418 = load ptr, ptr %l227, !tbaa !29
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t422
  %t423 = getelementptr { i64, [3 x i64] }, ptr %t422, i32 0, i32 0
  store i64 4, ptr %t423
  %t425 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t420, 0
  %t427 = insertvalue { %"compiler/source:Span", ptr, ptr } %t425, ptr %t418, 1
  %t428 = insertvalue { %"compiler/source:Span", ptr, ptr } %t427, ptr null, 2
  %t429 = getelementptr { i64, [3 x i64] }, ptr %t422, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t428, ptr %t429
  %t430 = load { i64, [3 x i64] }, ptr %t422
  %t432 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t430, ptr %t432
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t419, ptr %t432)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca i1
  %l24 = alloca i1
  %l29 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb3
bb3:
  %t12 = load i1, ptr %l10, !tbaa !21
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t14, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueMoved(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l14
  br label %bb8
bb8:
  %t21 = load i1, ptr %l14, !tbaa !21
  store i1 %t21, ptr %l3, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t26 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v1, ptr %s0, ptr %v2, ptr %t22, ptr %t23, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d37, i32 0, i32 1) }, i1 false)
  store ptr %t26, ptr %l17
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l17, !tbaa !29
  store ptr %t27, ptr %l1, !tbaa !29
  %t28 = load i1, ptr %l3, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l24
  br label %bb12
bb12:
  %t40 = load i1, ptr %l24, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t44, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v2, ptr %v2, ptr %t46, ptr %t47)
  store ptr %t50, ptr %l29
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load ptr, ptr %l29, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l13 = alloca %"compiler/check:litv"
  %l16 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca i32
  %l60 = alloca i32
  %l65 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i64
  %l78 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l108 = alloca i1
  %l111 = alloca i1
  %l114 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l122 = alloca i1
  %l123 = alloca i32
  %l127 = alloca i32
  %l129 = alloca i32
  %l130 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l140 = alloca ptr
  %l146 = alloca i1
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca ptr
  %l172 = alloca i1
  %l173 = alloca i32
  %l178 = alloca i32
  %l182 = alloca i1
  %l183 = alloca i1
  %l186 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca i32
  %l196 = alloca ptr
  %l199 = alloca %"compiler/source:Span"
  %l202 = alloca { i64, ptr }
  %l204 = alloca %"compiler/diagmsg:Msg"
  %l205 = alloca i64
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load %"compiler/check:litv", ptr %l13
  store %"compiler/check:litv" %t7, ptr %l2
  %t8 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb3:
  br label %bb21
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i32 %t21, ptr %l20
  br label %bb6
bb5:
  %t22 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb6:
  %t25 = load i32, ptr %l20, !tbaa !23
  store i32 %t25, ptr %l16, !tbaa !23
  br label %bb19
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t31, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i32 %t33, ptr %l26
  br label %bb9
bb8:
  %t34 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, -2147483648
  br i1 %t37, label %bb10, label %bb11
bb9:
  %t39 = load i32, ptr %l26, !tbaa !23
  store i32 %t39, ptr %l22, !tbaa !23
  br label %bb18
bb10:
  %t40 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp sle i64 %t41, 2147483647
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t51, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i32 %t53, ptr %l36
  br label %bb15
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l38
  br label %bb16
bb15:
  %t57 = load i32, ptr %l36, !tbaa !23
  store i32 %t57, ptr %l32, !tbaa !23
  br label %bb17
bb16:
  %t58 = load i32, ptr %l38, !tbaa !23
  store i32 %t58, ptr %l32, !tbaa !23
  br label %bb17
bb17:
  %t59 = load i32, ptr %l32, !tbaa !23
  store i32 %t59, ptr %l22, !tbaa !23
  br label %bb18
bb18:
  %t60 = load i32, ptr %l22, !tbaa !23
  store i32 %t60, ptr %l16, !tbaa !23
  br label %bb19
bb19:
  %t61 = load i32, ptr %l16, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t62, ptr %t63, i32 %t61)
  store ptr %t69, ptr %l43
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l43, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t71, ptr %t72, i32 %t74)
  store ptr %t78, ptr %l48
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l48, !tbaa !29
  store ptr %t79, ptr %l4, !tbaa !29
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t80)
  store i32 %t83, ptr %l51
  br label %bb23
bb23:
  %t84 = load i32, ptr %l51, !tbaa !23
  store i32 %t84, ptr %l5, !tbaa !23
  %t85 = load i32, ptr %l5, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t89 = icmp eq i32 %t85, %t86
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t91, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l5, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l60
  br label %bb27
bb27:
  %t103 = load i32, ptr %l60, !tbaa !23
  store i32 %t103, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l6, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l65
  br label %bb28
bb28:
  %t114 = load i32, ptr %l65, !range !{i32 0, i32 33}
  store i32 %t114, ptr %l7
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l6, !tbaa !23
  %t124 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l70
  br label %bb29
bb29:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t131, i32 %t132)
  store i64 %t135, ptr %l75
  br label %bb32
bb31:
  br label %bb73
bb32:
  %t136 = load i64, ptr %l75, !tbaa !24
  store i64 %t136, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp slt i64 %t137, 32
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l78, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t142)
  store %"compiler/source:Span" %t144, ptr %l80
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t145 = load ptr, ptr %l4, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s4, ptr %t151, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i32 %t153, ptr %l85
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l80
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load i32, ptr %l85, !tbaa !23
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t154, %"compiler/source:Span" %t155, ptr %t156, i32 %t157)
  store ptr %t158, ptr %l86
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t159 = load ptr, ptr %l86, !tbaa !29
  store ptr %t159, ptr %rv
  br label %ret
bb38:
  %t160 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t162 = trunc i64 31 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb39, label %bb40
bb39:
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = icmp sgt i64 %t165, 64
  store i1 %t167, ptr %l89, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb41
bb41:
  %t169 = load i1, ptr %l89, !tbaa !21
  br i1 %t169, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l92, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t171, ptr %t172)
  store %"compiler/source:Span" %t175, ptr %l95
  br label %bb44
bb43:
  br label %bb50
bb44:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l5, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l98
  br label %bb45
bb45:
  %t181 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %s5, ptr %v0, { i64, ptr } %t187)
  store %"compiler/diagmsg:Msg" %t189, ptr %l100
  br label %bb46
bb46:
  %t190 = load ptr, ptr %l92, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l95
  %t192 = load %"compiler/diagmsg:Msg", ptr %l100
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t190, %"compiler/source:Span" %t191, %"compiler/diagmsg:Msg" %t192)
  store i64 %t193, ptr %l101
  br label %bb47
bb47:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l102, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t195)
  store %"compiler/source:Span" %t197, ptr %l104
  br label %bb48
bb48:
  %t198 = load ptr, ptr %l102, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l104
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t198, %"compiler/source:Span" %t199)
  store ptr %t200, ptr %l105
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t201 = load ptr, ptr %l105, !tbaa !29
  store ptr %t201, ptr %rv
  br label %ret
bb50:
  %t202 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t204 = trunc i64 31 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb51, label %bb52
bb51:
  %t207 = load i64, ptr %l8, !tbaa !24
  %t209 = icmp ne i64 %t207, 32
  store i1 %t209, ptr %l108, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb53
bb53:
  %t211 = load i1, ptr %l108, !tbaa !21
  br i1 %t211, label %bb54, label %bb55
bb54:
  %t212 = load i64, ptr %l8, !tbaa !24
  %t214 = icmp ne i64 %t212, 64
  store i1 %t214, ptr %l111, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb56
bb56:
  %t216 = load i1, ptr %l111, !tbaa !21
  br i1 %t216, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s6
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l114, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l116
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t221 = load ptr, ptr %l4, !tbaa !29
  store ptr %t221, ptr %l117, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l6, !tbaa !23
  %t231 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l122
  br label %bb60
bb60:
  %t232 = load i1, ptr %l122, !tbaa !21
  br i1 %t232, label %bb61, label %bb62
bb61:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t238, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i32 %t240, ptr %l127
  br label %bb63
bb62:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t241)
  store i32 %t243, ptr %l129
  br label %bb64
bb63:
  %t244 = load i32, ptr %l127, !tbaa !23
  store i32 %t244, ptr %l123, !tbaa !23
  br label %bb65
bb64:
  %t245 = load i32, ptr %l129, !tbaa !23
  store i32 %t245, ptr %l123, !tbaa !23
  br label %bb65
bb65:
  %t246 = load ptr, ptr %l114, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l116
  %t248 = load ptr, ptr %l117, !tbaa !29
  %t249 = load i32, ptr %l123, !tbaa !23
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t246, %"compiler/source:Span" %t247, ptr %t248, i32 %t249)
  store ptr %t250, ptr %l130
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t251 = load ptr, ptr %l130, !tbaa !29
  store ptr %t251, ptr %rv
  br label %ret
bb67:
  %t252 = load i32, ptr %l6, !tbaa !23
  %t253 = load i32, ptr %l5, !tbaa !23
  %t256 = icmp ne i32 %t252, %t253
  br i1 %t256, label %bb68, label %bb69
bb68:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l135, !tbaa !29
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t259)
  store %"compiler/source:Span" %t261, ptr %l137
  br label %bb70
bb69:
  %t262 = load ptr, ptr %l4, !tbaa !29
  store ptr %t262, ptr %l134, !tbaa !29
  br label %bb72
bb70:
  %t264 = load ptr, ptr %l4, !tbaa !29
  %t265 = load i32, ptr %l6, !tbaa !23
  %t266 = load ptr, ptr %l135, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l137
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t266, %"compiler/source:Span" %t267, ptr %t264, i32 %t265)
  store ptr %t270, ptr %l140
  br label %bb71
bb71:
  %t271 = load ptr, ptr %l140, !tbaa !29
  store ptr %t271, ptr %l134, !tbaa !29
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t272 = load ptr, ptr %l134, !tbaa !29
  store ptr %t272, ptr %rv
  br label %ret
bb73:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  %t279 = load i32, ptr %l6, !tbaa !23
  %t282 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t278, i32 %t279)
  store i1 %t282, ptr %l146
  br label %bb74
bb74:
  %t283 = load i1, ptr %l146, !tbaa !21
  br i1 %t283, label %bb75, label %bb76
bb75:
  %t284 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t286 = trunc i64 14 to i32
  %t287 = icmp eq i32 %t284, %t286
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb77, label %bb78
bb76:
  br label %bb88
bb77:
  store %olang.scope zeroinitializer, ptr %s8
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l150, !tbaa !29
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t292)
  store %"compiler/source:Span" %t294, ptr %l152
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t295 = load ptr, ptr %l4, !tbaa !29
  store ptr %t295, ptr %l153, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/check:Checker", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = getelementptr %"compiler/generic:Program", ptr %t299, i32 0, i32 2
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t301, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i32 %t303, ptr %l157
  br label %bb80
bb80:
  %t304 = load ptr, ptr %l150, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l152
  %t306 = load ptr, ptr %l153, !tbaa !29
  %t307 = load i32, ptr %l157, !tbaa !23
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t304, %"compiler/source:Span" %t305, ptr %t306, i32 %t307)
  store ptr %t308, ptr %l158
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load ptr, ptr %l158, !tbaa !29
  store ptr %t309, ptr %rv
  br label %ret
bb82:
  %t310 = load i32, ptr %l6, !tbaa !23
  %t311 = load i32, ptr %l5, !tbaa !23
  %t314 = icmp ne i32 %t310, %t311
  br i1 %t314, label %bb83, label %bb84
bb83:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l163, !tbaa !29
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t317)
  store %"compiler/source:Span" %t319, ptr %l165
  br label %bb85
bb84:
  %t320 = load ptr, ptr %l4, !tbaa !29
  store ptr %t320, ptr %l162, !tbaa !29
  br label %bb87
bb85:
  %t322 = load ptr, ptr %l4, !tbaa !29
  %t323 = load i32, ptr %l6, !tbaa !23
  %t324 = load ptr, ptr %l163, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l165
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t324, %"compiler/source:Span" %t325, ptr %t322, i32 %t323)
  store ptr %t328, ptr %l168
  br label %bb86
bb86:
  %t329 = load ptr, ptr %l168, !tbaa !29
  store ptr %t329, ptr %l162, !tbaa !29
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  %t330 = load ptr, ptr %l162, !tbaa !29
  store ptr %t330, ptr %rv
  br label %ret
bb88:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l6, !tbaa !23
  %t335 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t331, i32 %t332)
  store i1 %t335, ptr %l172
  br label %bb89
bb89:
  %t336 = load i1, ptr %l172, !tbaa !21
  br i1 %t336, label %bb90, label %bb91
bb90:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/check:Checker", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t342 = getelementptr %"compiler/generic:Program", ptr %t340, i32 0, i32 2
  %t343 = load i32, ptr %l6, !tbaa !23
  %t346 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t342, i32 %t343)
  store i32 %t346, ptr %l178
  br label %bb92
bb91:
  %t347 = load i32, ptr %l6, !tbaa !23
  store i32 %t347, ptr %l173, !tbaa !23
  br label %bb93
bb92:
  %t349 = load i32, ptr %l178, !tbaa !23
  store i32 %t349, ptr %l173, !tbaa !23
  br label %bb93
bb93:
  %t350 = load i32, ptr %l173, !tbaa !23
  store i32 %t350, ptr %l9, !tbaa !23
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load i32, ptr %l6, !tbaa !23
  %t355 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t351, i32 %t352)
  store i1 %t355, ptr %l182
  br label %bb94
bb94:
  %t356 = load i1, ptr %l182, !tbaa !21
  br i1 %t356, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb99
bb96:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  store ptr %t362, ptr %l186, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 2
  %t369 = load i32, ptr %l9, !tbaa !23
  %t372 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t368, i32 %t369)
  store i32 %t372, ptr %l191
  br label %bb97
bb97:
  %t373 = load ptr, ptr %l186, !tbaa !29
  %t374 = load i32, ptr %l191, !tbaa !23
  %t375 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t373, i32 %t374)
  store i32 %t375, ptr %l192
  br label %bb98
bb98:
  %t376 = load i32, ptr %l192, !range !{i32 0, i32 33}
  %t378 = trunc i64 19 to i32
  %t379 = icmp eq i32 %t376, %t378
  store i1 %t379, ptr %l183, !tbaa !21
  br label %bb99
bb99:
  %t381 = load i1, ptr %l183, !tbaa !21
  br i1 %t381, label %bb100, label %bb101
bb100:
  %t382 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t382, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l196, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t389 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t385, ptr %t386)
  store %"compiler/source:Span" %t389, ptr %l199
  br label %bb103
bb103:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i32, ptr %l5, !tbaa !23
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t390, i32 %t391)
  store { i64, ptr } %t394, ptr %l202
  br label %bb104
bb104:
  %t395 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  %t397 = extractvalue { i64, ptr } %t395, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t403 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVarArgType(ptr %s0, ptr %v0, { i64, ptr } %t401)
  store %"compiler/diagmsg:Msg" %t403, ptr %l204
  br label %bb105
bb105:
  %t404 = load ptr, ptr %l196, !tbaa !29
  %t405 = load %"compiler/source:Span", ptr %l199
  %t406 = load %"compiler/diagmsg:Msg", ptr %l204
  %t407 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t404, %"compiler/source:Span" %t405, %"compiler/diagmsg:Msg" %t406)
  store i64 %t407, ptr %l205
  br label %bb106
bb106:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l206, !tbaa !29
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t411 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t409)
  store %"compiler/source:Span" %t411, ptr %l208
  br label %bb107
bb107:
  %t412 = load ptr, ptr %l206, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l208
  %t414 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t412, %"compiler/source:Span" %t413)
  store ptr %t414, ptr %l209
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  %t415 = load ptr, ptr %l209, !tbaa !29
  store ptr %t415, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l34 = alloca i1
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i32
  %l49 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i64
  %l58 = alloca i64
  %l68 = alloca i32
  %l73 = alloca i32
  %l76 = alloca ptr
  %l81 = alloca i32
  %l90 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l13, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l1, !tbaa !23
  %t14 = icmp eq i32 %t12, 0
  store i1 %t14, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l17, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l23
  br label %bb9
bb9:
  %t22 = load i1, ptr %l23, !tbaa !21
  store i1 %t22, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l20, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb14
bb12:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 81
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l28
  br label %bb13
bb13:
  %t31 = load i1, ptr %l28, !tbaa !21
  store i1 %t31, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t32 = load i1, ptr %l24, !tbaa !21
  br i1 %t32, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb18
bb16:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l34
  br label %bb17
bb17:
  %t43 = load i1, ptr %l34, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t46 = load i1, ptr %l29, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  br label %ret
bb20:
  br label %bb21
bb21:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 81
  %t50 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t49, i32 %t50, i1 true)
  br label %bb22
bb22:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l43
  br label %bb23
bb23:
  %t63 = load i1, ptr %l43, !tbaa !21
  br i1 %t63, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l45, !tbaa !29
  %t68 = load i32, ptr %l1, !tbaa !23
  store i32 %t68, ptr %l46, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = getelementptr %"compiler/types:Table", ptr %t74, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l49, !tbaa !29
  %t77 = load ptr, ptr %l49, !tbaa !29
  %t78 = call ptr @__olang_scope_of(ptr %t77, ptr null)
  %t79 = ptrtoint ptr %t78 to i64
  %t81 = inttoptr i64 %t79 to ptr
  %t82 = load ptr, ptr %l49, !tbaa !29
  %t83 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t81, ptr %s2, ptr %t82, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i32 %t83, ptr %l51
  br label %bb26
bb25:
  br label %bb36
bb26:
  %t84 = load ptr, ptr %l45, !tbaa !29
  %t85 = load i32, ptr %l46, !tbaa !23
  %t86 = load i32, ptr %l51, !tbaa !23
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i64 %t87, ptr %l52
  br label %bb27
bb27:
  %t88 = load i64, ptr %l52, !tbaa !24
  store i64 %t88, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l3, !tbaa !24
  %t91 = icmp slt i64 %t89, 0
  br i1 %t91, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l3, !tbaa !24
  %t95 = load i32, ptr %l1, !tbaa !23
  %t99 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodInstance(ptr %v0, ptr %t93, i64 %t94, i32 %t95)
  store i64 %t99, ptr %l58
  br label %bb31
bb31:
  %t100 = load i64, ptr %l58, !tbaa !24
  store i64 %t100, ptr %l4, !tbaa !24
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = icmp sge i64 %t101, 0
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 80
  %t108 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t107, i64 %t108)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb36:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l1, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l68
  br label %bb37
bb37:
  %t121 = load i32, ptr %l68, !tbaa !23
  store i32 %t121, ptr %l5, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l5, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l73
  br label %bb38
bb38:
  %t132 = load i32, ptr %l73, !range !{i32 0, i32 33}
  store i32 %t132, ptr %l6
  %t133 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t135 = trunc i64 19 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l76, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l5, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l81
  br label %bb42
bb42:
  %t149 = load i64, ptr %l2, !tbaa !24
  %t151 = add i64 %t149, 1
  %t152 = load ptr, ptr %l76, !tbaa !29
  %t153 = load i32, ptr %l81, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t152, i32 %t153, i64 %t151)
  br label %bb43
bb43:
  br label %bb69
bb44:
  %t155 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t157 = trunc i64 22 to i32
  %t158 = icmp eq i32 %t155, %t157
  br i1 %t158, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  %t160 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t162 = trunc i64 23 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb59
bb49:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  store ptr %t170, ptr %l90, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %l5, !tbaa !23
  %t180 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t176, i32 %t177)
  store i32 %t180, ptr %l95
  br label %bb50
bb50:
  %t181 = load ptr, ptr %l90, !tbaa !29
  %t182 = load i32, ptr %l95, !tbaa !23
  %t183 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t181, i32 %t182)
  store { i64, ptr } %t183, ptr %l96
  br label %bb51
bb51:
  %t184 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t184, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t185 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 0
  store i64 %t187, ptr %l9, !tbaa !24
  br label %bb52
bb52:
  %t189 = load i64, ptr %l8, !tbaa !24
  %t190 = load i64, ptr %l9, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb53, label %bb54
bb53:
  br label %bb58
bb54:
  br label %bb55
bb55:
  %t197 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t197, ptr %l103, !tbaa !27
  %t198 = load i64, ptr %l8, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i32, ptr %t201, i64 %t198
  %t203 = load i32, ptr %t202, !tbaa !33
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l2, !tbaa !24
  %t209 = add i64 %t207, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t205, i32 %t203, i64 %t209)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t213 = load i64, ptr %l8, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %l8, !tbaa !24
  br label %bb52
bb58:
  br label %bb69
bb59:
  %t217 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t219 = trunc i64 18 to i32
  %t220 = icmp eq i32 %t217, %t219
  br i1 %t220, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l5, !tbaa !23
  %t224 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopyParts(ptr %v0, ptr %t222, i32 %t223, i64 %t224)
  br label %bb63
bb63:
  br label %bb69
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_4c67a4e0f39ce0e6_aa4d8ec9734e07a2)
  unreachable
bb69:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeColumn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l9
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l12
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 3
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 3
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l24, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l25, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t46)
  store i32 %t48, ptr %l27
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l25, !tbaa !29
  %t50 = load i32, ptr %l27, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l28
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l24, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t54 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t54, ptr %l29
  br label %bb13
bb13:
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %l16, !tbaa !21
  br label %bb26
bb14:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 6
  store i1 %t63, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l31, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t75 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnSlice(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  store i1 %t75, ptr %l38
  br label %bb20
bb20:
  %t76 = load i1, ptr %l38, !tbaa !21
  store i1 %t76, ptr %l16, !tbaa !21
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_b2735ee686977dce_6cfd672f66c8ceea)
  unreachable
bb26:
  %t77 = load i1, ptr %l16, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesImmut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = load i32, ptr %l6, !tbaa !23
  %t11 = icmp ne i32 %t9, %t8
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l28 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_922ae0a799ba69ce_f9cc72ab99b0ec2)
  unreachable
bb16:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb17, label %bb18
bb17:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 12
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb18
bb18:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Seq", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb22, label %bb23
bb22:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Seq", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  br i1 %t61, label %bb24, label %bb25
bb23:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb28
bb24:
  call void @__olang_check_failed(ptr @olang_loc_46a0e749826cef18_3e2809181fcd5dac)
  unreachable
bb25:
  br label %bb26
bb26:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Seq", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l34
  br label %bb27
bb27:
  %t69 = load i1, ptr %l34, !tbaa !21
  store i1 %t69, ptr %l28, !tbaa !21
  br label %bb28
bb28:
  %t70 = load i1, ptr %l28, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_2f12767f94a228d4_8b6b4888798b3f68)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisBind(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a4a9e3d1ce4f287a_3905f5d0b0eda75e)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l122 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca i1
  %l130 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l147 = alloca { i64, ptr }
  %l152 = alloca i1
  %l164 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t12 = load ptr, ptr %l21, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l21, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 17}
  %t18 = icmp eq i64 %t16, 7
  store i1 %t18, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l22, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t21 = load ptr, ptr %l25, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 17}
  %t27 = icmp eq i64 %t25, 8
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t31 = load ptr, ptr %l30, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb17, label %bb18
bb17:
  %t34 = load ptr, ptr %l30, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 9
  store i1 %t37, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t38 = load i1, ptr %l31, !tbaa !21
  br i1 %t38, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 true, ptr %rv
  br label %ret
bb22:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t41 = load ptr, ptr %l35, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb23, label %bb24
bb23:
  %t44 = load ptr, ptr %l35, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 17}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t48 = load i1, ptr %l36, !tbaa !21
  br i1 %t48, label %bb25, label %bb26
bb25:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", ptr }, ptr %t51, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l1, !tbaa !29
  br label %bb27
bb26:
  br label %bb36
bb27:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/typed:If", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb28, label %bb29
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/typed:If", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t67)
  store i1 %t70, ptr %l49
  br label %bb30
bb29:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  %t71 = load i1, ptr %l49, !tbaa !21
  store i1 %t71, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t72 = load i1, ptr %l45, !tbaa !21
  br i1 %t72, label %bb32, label %bb33
bb32:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/typed:If", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t76)
  store i1 %t78, ptr %l53
  br label %bb34
bb33:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb35
bb34:
  %t79 = load i1, ptr %l53, !tbaa !21
  store i1 %t79, ptr %l50, !tbaa !21
  br label %bb35
bb35:
  %t80 = load i1, ptr %l50, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb36:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t82 = load ptr, ptr %l54, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb37, label %bb38
bb37:
  %t85 = load ptr, ptr %l54, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 17}
  %t88 = icmp eq i64 %t86, 11
  store i1 %t88, ptr %l55, !tbaa !21
  br label %bb38
bb38:
  %t89 = load i1, ptr %l55, !tbaa !21
  br i1 %t89, label %bb39, label %bb40
bb39:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l2, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t99 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t96)
  store i1 %t99, ptr %l62
  br label %bb42
bb42:
  %t100 = load i1, ptr %l62, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
bb43:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb44, label %bb45
bb44:
  %t105 = load ptr, ptr %l63, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 17}
  %t108 = icmp eq i64 %t106, 13
  store i1 %t108, ptr %l64, !tbaa !21
  br label %bb45
bb45:
  %t109 = load i1, ptr %l64, !tbaa !21
  br i1 %t109, label %bb46, label %bb47
bb46:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr { i64, [3 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", ptr }, ptr %t112, i32 0, i32 1
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l3, !tbaa !29
  br label %bb48
bb47:
  br label %bb63
bb48:
  %t116 = load ptr, ptr %l3, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Join", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t119)
  store i1 %t122, ptr %l72
  br label %bb49
bb49:
  %t123 = load i1, ptr %l72, !tbaa !21
  %t124 = xor i1 %t123, true
  br i1 %t124, label %bb50, label %bb51
bb50:
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Join", ptr %t127, i32 0, i32 2
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb53
bb53:
  %t136 = load i64, ptr %l5, !tbaa !24
  %t137 = load i64, ptr %l6, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  br label %bb56
bb56:
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t144, ptr %l83, !tbaa !27
  %t145 = load i64, ptr %l5, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr ptr, ptr %t148, i64 %t145
  %t150 = load ptr, ptr %t149, !tbaa !39
  %t154 = getelementptr %"compiler/typed:Clause", ptr %t150, i32 0, i32 3
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t155)
  store i1 %t157, ptr %l88
  br label %bb57
bb57:
  %t158 = load i1, ptr %l88, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb58, label %bb59
bb58:
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t162 = load i64, ptr %l5, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l5, !tbaa !24
  br label %bb53
bb62:
  store i1 true, ptr %rv
  br label %ret
bb63:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t168 = load ptr, ptr %l94, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb64, label %bb65
bb64:
  %t171 = load ptr, ptr %l94, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 17}
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l95, !tbaa !21
  br label %bb65
bb65:
  %t175 = load i1, ptr %l95, !tbaa !21
  br i1 %t175, label %bb66, label %bb67
bb66:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb74
bb68:
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Block", ptr %t190, i32 0, i32 0
  %t193 = load i32, ptr %t192, !tbaa !23
  %t196 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t188, i32 %t193)
  store i1 %t196, ptr %l106
  br label %bb69
bb69:
  %t197 = load i1, ptr %l106, !tbaa !21
  %t198 = xor i1 %t197, true
  br i1 %t198, label %bb70, label %bb71
bb70:
  %t200 = load ptr, ptr %l9, !tbaa !29
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Block", ptr %t201, i32 0, i32 0
  %t204 = load i32, ptr %t203, !tbaa !23
  %t207 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t200, i32 %t204)
  store i1 %t207, ptr %l112
  br label %bb72
bb71:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb73
bb72:
  %t208 = load i1, ptr %l112, !tbaa !21
  %t209 = xor i1 %t208, true
  store i1 %t209, ptr %l108, !tbaa !21
  br label %bb73
bb73:
  %t211 = load i1, ptr %l108, !tbaa !21
  store i1 %t211, ptr %rv
  br label %ret
bb74:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t213 = load ptr, ptr %l114, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb75, label %bb76
bb75:
  %t216 = load ptr, ptr %l114, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 17}
  %t219 = icmp eq i64 %t217, 2
  store i1 %t219, ptr %l115, !tbaa !21
  br label %bb76
bb76:
  %t220 = load i1, ptr %l115, !tbaa !21
  br i1 %t220, label %bb77, label %bb78
bb77:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr { i64, [3 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr }, ptr %t223, i32 0, i32 1
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l10, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t227 = load ptr, ptr %l10, !tbaa !29
  %t230 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t227)
  store i32 %t230, ptr %l122
  br label %bb80
bb80:
  %t231 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t232 = load i32, ptr %l122, !tbaa !23
  %t234 = icmp eq i32 %t232, %t231
  br i1 %t234, label %bb81, label %bb82
bb81:
  store i1 true, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t238 = load ptr, ptr %l126, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb84, label %bb85
bb84:
  %t241 = load ptr, ptr %l126, !tbaa !29
  %t242 = load i64, ptr %t241, !range !{i64 0, i64 17}
  %t244 = icmp eq i64 %t242, 2
  store i1 %t244, ptr %l127, !tbaa !21
  br label %bb85
bb85:
  %t245 = load i1, ptr %l127, !tbaa !21
  br i1 %t245, label %bb86, label %bb87
bb86:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr }, ptr %t248, i32 0, i32 1
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t251 = load ptr, ptr %l132, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb88, label %bb89
bb87:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb90
bb88:
  %t254 = load ptr, ptr %l132, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 18}
  %t257 = icmp eq i64 %t255, 13
  store i1 %t257, ptr %l133, !tbaa !21
  br label %bb89
bb89:
  %t258 = load i1, ptr %l133, !tbaa !21
  store i1 %t258, ptr %l130, !tbaa !21
  br label %bb90
bb90:
  %t259 = load i1, ptr %l130, !tbaa !21
  br i1 %t259, label %bb91, label %bb92
bb91:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr { i64, [3 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", ptr }, ptr %t262, i32 0, i32 1
  %t264 = load ptr, ptr %t263
  %t266 = getelementptr { i64, [5 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t266, i32 0, i32 2
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l11, !tbaa !29
  br label %bb93
bb92:
  br label %bb108
bb93:
  %t270 = load ptr, ptr %l11, !tbaa !29
  %t272 = getelementptr %"compiler/typed:Match", ptr %t270, i32 0, i32 1
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  store { i64, ptr } %t273, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t275 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  store i64 %t277, ptr %l14, !tbaa !24
  br label %bb94
bb94:
  %t279 = load i64, ptr %l13, !tbaa !24
  %t280 = load i64, ptr %l14, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb95, label %bb96
bb95:
  br label %bb103
bb96:
  br label %bb97
bb97:
  %t287 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t287, ptr %l147, !tbaa !27
  %t288 = load i64, ptr %l13, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr ptr, ptr %t291, i64 %t288
  %t293 = load ptr, ptr %t292, !tbaa !39
  %t297 = getelementptr %"compiler/typed:Arm", ptr %t293, i32 0, i32 3
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t298)
  store i1 %t300, ptr %l152
  br label %bb98
bb98:
  %t301 = load i1, ptr %l152, !tbaa !21
  %t302 = xor i1 %t301, true
  br i1 %t302, label %bb99, label %bb100
bb99:
  store i1 false, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t305 = load i64, ptr %l13, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l13, !tbaa !24
  br label %bb94
bb103:
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t311 = getelementptr %"compiler/typed:Match", ptr %t309, i32 0, i32 2
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = icmp eq ptr %t312, null
  br i1 %t314, label %bb104, label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_eb3e4e8f3f96f0ec_5bc3fc9686c42b70)
  unreachable
bb105:
  br label %bb106
bb106:
  %t316 = load ptr, ptr %l11, !tbaa !29
  %t318 = getelementptr %"compiler/typed:Match", ptr %t316, i32 0, i32 2
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Arm", ptr %t319, i32 0, i32 3
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t323)
  store i1 %t325, ptr %l164
  br label %bb107
bb107:
  %t326 = load i1, ptr %l164, !tbaa !21
  store i1 %t326, ptr %rv
  br label %ret
bb108:
  br i1 true, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  store i1 false, ptr %rv
  br label %ret
bb112:
  call void @__olang_check_failed(ptr @olang_loc_bad8a01556e87002_6e42cd1773855696)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2enestedSets(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb24
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 11}
  %t37 = icmp eq i64 %t35, 7
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [8 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2echainSets(ptr %v0, ptr %t45, i32 %a1)
  store i1 %t49, ptr %l29
  br label %bb13
bb13:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f5486e4325103d79_668082c6ca0b25f5)
  unreachable
bb22:
  br label %bb23
bb23:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb4
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epatRow(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v1, ptr %v0, ptr %t5, ptr %a0)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v1, ptr %v1, ptr %t9)
  store { i64, ptr } %t11, ptr %l7
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t3 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v0, i1 false, i64 0, i64 0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, i32 %t1)
  store %"compiler/check:reflVal" %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load %"compiler/check:reflVal", ptr %l1
  store %"compiler/check:reflVal" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l70 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i1
  %l249 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t6 = load ptr, ptr %l35, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l35, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l36, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l36, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb172
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t26 = load ptr, ptr %l44, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l44, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 22}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l45, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l45, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/ast:VarDecl", ptr %t40, i32 0, i32 3
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t43, ptr %t44)
  br label %bb16
bb16:
  br label %bb172
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t48 = load ptr, ptr %l53, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t51 = load ptr, ptr %l53, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 22}
  %t54 = icmp eq i64 %t52, 2
  store i1 %t54, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l54, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb34
bb22:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Multi", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t86, ptr %l70, !tbaa !27
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t95 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t92, ptr %t95)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t98 = load i64, ptr %l6, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l6, !tbaa !24
  br label %bb25
bb31:
  br label %bb32
bb32:
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Multi", ptr %t102, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t106 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t105, ptr %t106)
  br label %bb33
bb33:
  br label %bb172
bb34:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t110 = load ptr, ptr %l80, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l80, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 22}
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l81, !tbaa !21
  br label %bb36
bb36:
  %t117 = load i1, ptr %l81, !tbaa !21
  br i1 %t117, label %bb37, label %bb38
bb37:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l9, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t126, i32 0, i32 3
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l10, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t130 = load ptr, ptr %l9, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  br label %bb40
bb40:
  %t134 = load ptr, ptr %l10, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t134, ptr %t136)
  br label %bb41
bb41:
  br label %bb172
bb42:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t140 = load ptr, ptr %l93, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb43, label %bb44
bb43:
  %t143 = load ptr, ptr %l93, !tbaa !29
  %t144 = load i64, ptr %t143, !range !{i64 0, i64 22}
  %t146 = icmp eq i64 %t144, 4
  store i1 %t146, ptr %l94, !tbaa !21
  br label %bb44
bb44:
  %t147 = load i1, ptr %l94, !tbaa !21
  br i1 %t147, label %bb45, label %bb46
bb45:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t150, i32 0, i32 1
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l11, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t156, i32 0, i32 2
  %t158 = load { i64, ptr }, ptr %t157
  store { i64, ptr } %t158, ptr %l12, !tbaa !27
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t160, ptr %t162)
  br label %bb48
bb48:
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t166 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t165, ptr %t166)
  br label %bb49
bb49:
  br label %bb172
bb50:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t170 = load ptr, ptr %l106, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb51, label %bb52
bb51:
  %t173 = load ptr, ptr %l106, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 22}
  %t176 = icmp eq i64 %t174, 5
  store i1 %t176, ptr %l107, !tbaa !21
  br label %bb52
bb52:
  %t177 = load i1, ptr %l107, !tbaa !21
  br i1 %t177, label %bb53, label %bb54
bb53:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", ptr }, ptr %t180, i32 0, i32 1
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l13, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t184 = load ptr, ptr %l13, !tbaa !29
  %t185 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %t184, ptr %t185)
  br label %bb56
bb56:
  br label %bb172
bb57:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t189 = load ptr, ptr %l114, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb58, label %bb59
bb58:
  %t192 = load ptr, ptr %l114, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 22}
  %t195 = icmp eq i64 %t193, 6
  store i1 %t195, ptr %l115, !tbaa !21
  br label %bb59
bb59:
  %t196 = load i1, ptr %l115, !tbaa !21
  br i1 %t196, label %bb60, label %bb61
bb60:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t199, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l14, !tbaa !27
  br label %bb66
bb61:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t204 = load ptr, ptr %l120, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb62, label %bb63
bb62:
  %t207 = load ptr, ptr %l120, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 22}
  %t210 = icmp eq i64 %t208, 20
  store i1 %t210, ptr %l121, !tbaa !21
  br label %bb63
bb63:
  %t211 = load i1, ptr %l121, !tbaa !21
  br i1 %t211, label %bb64, label %bb65
bb64:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t214, i32 0, i32 1
  %t216 = load { i64, ptr }, ptr %t215
  store { i64, ptr } %t216, ptr %l14, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t218 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t219 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t218, ptr %t219)
  br label %bb67
bb67:
  br label %bb172
bb68:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t223 = load ptr, ptr %l128, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb69, label %bb70
bb69:
  %t226 = load ptr, ptr %l128, !tbaa !29
  %t227 = load i64, ptr %t226, !range !{i64 0, i64 22}
  %t229 = icmp eq i64 %t227, 7
  store i1 %t229, ptr %l129, !tbaa !21
  br label %bb70
bb70:
  %t230 = load i1, ptr %l129, !tbaa !21
  br i1 %t230, label %bb71, label %bb72
bb71:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t233, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l15, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t239, i32 0, i32 2
  %t241 = load { i64, ptr }, ptr %t240
  store { i64, ptr } %t241, ptr %l16, !tbaa !27
  br label %bb77
bb72:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t244 = load ptr, ptr %l136, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb73, label %bb74
bb73:
  %t247 = load ptr, ptr %l136, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 22}
  %t250 = icmp eq i64 %t248, 10
  store i1 %t250, ptr %l137, !tbaa !21
  br label %bb74
bb74:
  %t251 = load i1, ptr %l137, !tbaa !21
  br i1 %t251, label %bb75, label %bb76
bb75:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t254, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255
  store { i64, ptr } %t256, ptr %l16, !tbaa !27
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t260, i32 0, i32 2
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l15, !tbaa !29
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t264 = load ptr, ptr %l15, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t264, ptr %t266)
  br label %bb78
bb78:
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t270 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t269, ptr %t270)
  br label %bb79
bb79:
  br label %bb172
bb80:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t274 = load ptr, ptr %l149, !tbaa !29
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %bb81, label %bb82
bb81:
  %t277 = load ptr, ptr %l149, !tbaa !29
  %t278 = load i64, ptr %t277, !range !{i64 0, i64 22}
  %t280 = icmp eq i64 %t278, 8
  store i1 %t280, ptr %l150, !tbaa !21
  br label %bb82
bb82:
  %t281 = load i1, ptr %l150, !tbaa !21
  br i1 %t281, label %bb83, label %bb84
bb83:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", ptr }, ptr %t284, i32 0, i32 1
  %t286 = load ptr, ptr %t285
  store ptr %t286, ptr %l17, !tbaa !29
  br label %bb85
bb84:
  br label %bb90
bb85:
  %t288 = load ptr, ptr %l17, !tbaa !29
  %t290 = getelementptr %"compiler/ast:For3", ptr %t288, i32 0, i32 0
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t291, ptr %t293)
  br label %bb86
bb86:
  %t296 = load ptr, ptr %l17, !tbaa !29
  %t298 = getelementptr %"compiler/ast:For3", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t300 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t299, ptr %t300)
  br label %bb87
bb87:
  %t303 = load ptr, ptr %l17, !tbaa !29
  %t305 = getelementptr %"compiler/ast:For3", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t306, ptr %t308)
  br label %bb88
bb88:
  %t311 = load ptr, ptr %l17, !tbaa !29
  %t313 = getelementptr %"compiler/ast:For3", ptr %t311, i32 0, i32 3
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  %t315 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t314, ptr %t315)
  br label %bb89
bb89:
  br label %bb172
bb90:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t319 = load ptr, ptr %l169, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb91, label %bb92
bb91:
  %t322 = load ptr, ptr %l169, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 22}
  %t325 = icmp eq i64 %t323, 9
  store i1 %t325, ptr %l170, !tbaa !21
  br label %bb92
bb92:
  %t326 = load i1, ptr %l170, !tbaa !21
  br i1 %t326, label %bb93, label %bb94
bb93:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr }, ptr %t329, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l18, !tbaa !29
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t333 = load ptr, ptr %l18, !tbaa !29
  %t335 = getelementptr %"compiler/ast:ForIn", ptr %t333, i32 0, i32 2
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t336, ptr %t338)
  br label %bb96
bb96:
  %t341 = load ptr, ptr %l18, !tbaa !29
  %t343 = getelementptr %"compiler/ast:ForIn", ptr %t341, i32 0, i32 4
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  %t345 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t344, ptr %t345)
  br label %bb97
bb97:
  %t348 = load ptr, ptr %l18, !tbaa !29
  %t350 = getelementptr %"compiler/ast:ForIn", ptr %t348, i32 0, i32 5
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  %t352 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t351, ptr %t352)
  br label %bb98
bb98:
  br label %bb172
bb99:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t356 = load ptr, ptr %l185, !tbaa !29
  %t357 = icmp ne ptr %t356, null
  br i1 %t357, label %bb100, label %bb101
bb100:
  %t359 = load ptr, ptr %l185, !tbaa !29
  %t360 = load i64, ptr %t359, !range !{i64 0, i64 22}
  %t362 = icmp eq i64 %t360, 11
  store i1 %t362, ptr %l186, !tbaa !21
  br label %bb101
bb101:
  %t363 = load i1, ptr %l186, !tbaa !21
  br i1 %t363, label %bb102, label %bb103
bb102:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t364, i32 0, i32 1
  %t367 = getelementptr { %"compiler/source:Span", ptr }, ptr %t366, i32 0, i32 1
  %t368 = load ptr, ptr %t367
  store ptr %t368, ptr %l19, !tbaa !29
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t370 = load ptr, ptr %l19, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  br label %bb105
bb105:
  br label %bb172
bb106:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t375 = load ptr, ptr %l193, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb107, label %bb108
bb107:
  %t378 = load ptr, ptr %l193, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 22}
  %t381 = icmp eq i64 %t379, 12
  store i1 %t381, ptr %l194, !tbaa !21
  br label %bb108
bb108:
  %t382 = load i1, ptr %l194, !tbaa !21
  br i1 %t382, label %bb109, label %bb110
bb109:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t385, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386
  store { i64, ptr } %t387, ptr %l20, !tbaa !27
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t389 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t390 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t389, ptr %t390)
  br label %bb112
bb112:
  br label %bb172
bb113:
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t394 = load ptr, ptr %l201, !tbaa !29
  %t395 = icmp ne ptr %t394, null
  br i1 %t395, label %bb114, label %bb115
bb114:
  %t397 = load ptr, ptr %l201, !tbaa !29
  %t398 = load i64, ptr %t397, !range !{i64 0, i64 22}
  %t400 = icmp eq i64 %t398, 15
  store i1 %t400, ptr %l202, !tbaa !21
  br label %bb115
bb115:
  %t401 = load i1, ptr %l202, !tbaa !21
  br i1 %t401, label %bb116, label %bb117
bb116:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr { i64, [4 x i64] }, ptr %t402, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", ptr }, ptr %t404, i32 0, i32 1
  %t406 = load ptr, ptr %t405
  store ptr %t406, ptr %l21, !tbaa !29
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t408 = load ptr, ptr %l21, !tbaa !29
  %t410 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t408, ptr %t410)
  br label %bb119
bb119:
  br label %bb172
bb120:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t414 = load ptr, ptr %l210, !tbaa !29
  %t415 = icmp ne ptr %t414, null
  br i1 %t415, label %bb121, label %bb122
bb121:
  %t417 = load ptr, ptr %l210, !tbaa !29
  %t418 = load i64, ptr %t417, !range !{i64 0, i64 22}
  %t420 = icmp eq i64 %t418, 14
  store i1 %t420, ptr %l211, !tbaa !21
  br label %bb122
bb122:
  %t421 = load i1, ptr %l211, !tbaa !21
  br i1 %t421, label %bb123, label %bb124
bb123:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr { i64, [4 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t424, i32 0, i32 1
  %t426 = load ptr, ptr %t425
  store ptr %t426, ptr %l22, !tbaa !29
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t430, i32 0, i32 2
  %t432 = load ptr, ptr %t431
  store ptr %t432, ptr %l23, !tbaa !29
  br label %bb125
bb124:
  br label %bb128
bb125:
  %t434 = load ptr, ptr %l22, !tbaa !29
  %t436 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t434, ptr %t436)
  br label %bb126
bb126:
  %t439 = load ptr, ptr %l23, !tbaa !29
  %t440 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t439, ptr %t440)
  br label %bb127
bb127:
  br label %bb172
bb128:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t444 = load ptr, ptr %l223, !tbaa !29
  %t445 = icmp ne ptr %t444, null
  br i1 %t445, label %bb129, label %bb130
bb129:
  %t447 = load ptr, ptr %l223, !tbaa !29
  %t448 = load i64, ptr %t447, !range !{i64 0, i64 22}
  %t450 = icmp eq i64 %t448, 13
  store i1 %t450, ptr %l224, !tbaa !21
  br label %bb130
bb130:
  %t451 = load i1, ptr %l224, !tbaa !21
  br i1 %t451, label %bb131, label %bb132
bb131:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr { i64, [4 x i64] }, ptr %t452, i32 0, i32 1
  %t455 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t454, i32 0, i32 2
  %t456 = load ptr, ptr %t455
  store ptr %t456, ptr %l24, !tbaa !29
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t458 = load ptr, ptr %l24, !tbaa !29
  %t459 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t458, ptr %t459)
  br label %bb134
bb134:
  br label %bb172
bb135:
  %t462 = load ptr, ptr %l0, !tbaa !29
  store ptr %t462, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t463 = load ptr, ptr %l231, !tbaa !29
  %t464 = icmp ne ptr %t463, null
  br i1 %t464, label %bb136, label %bb137
bb136:
  %t466 = load ptr, ptr %l231, !tbaa !29
  %t467 = load i64, ptr %t466, !range !{i64 0, i64 22}
  %t469 = icmp eq i64 %t467, 17
  store i1 %t469, ptr %l232, !tbaa !21
  br label %bb137
bb137:
  %t470 = load i1, ptr %l232, !tbaa !21
  br i1 %t470, label %bb138, label %bb139
bb138:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr { i64, [4 x i64] }, ptr %t471, i32 0, i32 1
  %t474 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t473, i32 0, i32 1
  %t475 = load { i64, ptr }, ptr %t474
  store { i64, ptr } %t475, ptr %l25, !tbaa !27
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr { i64, [4 x i64] }, ptr %t477, i32 0, i32 1
  %t480 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t479, i32 0, i32 2
  %t481 = load ptr, ptr %t480
  store ptr %t481, ptr %l26, !tbaa !29
  br label %bb140
bb139:
  br label %bb152
bb140:
  %t483 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t487 = icmp sgt i64 %t485, 0
  br i1 %t487, label %bb141, label %bb142
bb141:
  %t489 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t489, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  store i64 %t493, ptr %l29, !tbaa !24
  br label %bb143
bb142:
  br label %bb150
bb143:
  %t495 = load i64, ptr %l28, !tbaa !24
  %t496 = load i64, ptr %l29, !tbaa !24
  %t499 = icmp slt i64 %t495, %t496
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t503 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t503, ptr %l249, !tbaa !27
  %t504 = load i64, ptr %l28, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr ptr, ptr %t507, i64 %t504
  %t509 = load ptr, ptr %t508, !tbaa !39
  %t512 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t509, ptr %t512)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t515 = load i64, ptr %l28, !tbaa !24
  %t517 = add i64 %t515, 1
  store i64 %t517, ptr %l28, !tbaa !24
  br label %bb143
bb149:
  br label %bb150
bb150:
  %t519 = load ptr, ptr %l26, !tbaa !29
  %t521 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t519, ptr %t521)
  br label %bb151
bb151:
  br label %bb172
bb152:
  %t524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t524, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t525 = load ptr, ptr %l259, !tbaa !29
  %t526 = icmp ne ptr %t525, null
  br i1 %t526, label %bb153, label %bb154
bb153:
  %t528 = load ptr, ptr %l259, !tbaa !29
  %t529 = load i64, ptr %t528, !range !{i64 0, i64 22}
  %t531 = icmp eq i64 %t529, 18
  store i1 %t531, ptr %l260, !tbaa !21
  br label %bb154
bb154:
  %t532 = load i1, ptr %l260, !tbaa !21
  br i1 %t532, label %bb155, label %bb156
bb155:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t533, i32 0, i32 1
  %t536 = getelementptr { %"compiler/source:Span", ptr }, ptr %t535, i32 0, i32 1
  %t537 = load ptr, ptr %t536
  store ptr %t537, ptr %l31, !tbaa !29
  br label %bb157
bb156:
  br label %bb160
bb157:
  %t539 = load ptr, ptr %l31, !tbaa !29
  %t541 = getelementptr %"compiler/ast:JoinS", ptr %t539, i32 0, i32 1
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !27
  %t543 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t542, ptr %t543)
  br label %bb158
bb158:
  %t546 = load ptr, ptr %l31, !tbaa !29
  %t548 = getelementptr %"compiler/ast:JoinS", ptr %t546, i32 0, i32 2
  %t549 = load { i64, ptr }, ptr %t548, !tbaa !27
  %t550 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t549, ptr %t550)
  br label %bb159
bb159:
  br label %bb172
bb160:
  %t553 = load ptr, ptr %l0, !tbaa !29
  store ptr %t553, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t554 = load ptr, ptr %l271, !tbaa !29
  %t555 = icmp ne ptr %t554, null
  br i1 %t555, label %bb161, label %bb162
bb161:
  %t557 = load ptr, ptr %l271, !tbaa !29
  %t558 = load i64, ptr %t557, !range !{i64 0, i64 22}
  %t560 = icmp eq i64 %t558, 19
  store i1 %t560, ptr %l272, !tbaa !21
  br label %bb162
bb162:
  %t561 = load i1, ptr %l272, !tbaa !21
  br i1 %t561, label %bb163, label %bb164
bb163:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr { i64, [4 x i64] }, ptr %t562, i32 0, i32 1
  %t565 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t564, i32 0, i32 1
  %t566 = load ptr, ptr %t565
  store ptr %t566, ptr %l32, !tbaa !29
  br label %bb165
bb164:
  br label %bb167
bb165:
  %t568 = load ptr, ptr %l32, !tbaa !29
  %t570 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t568, ptr %t570)
  br label %bb166
bb166:
  br label %bb172
bb167:
  br i1 true, label %bb168, label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb171
bb170:
  br label %bb172
bb171:
  call void @__olang_check_failed(ptr @olang_loc_129627029b1e0c70_26637847123ec4fc)
  unreachable
bb172:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ewordCount(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l74 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = add i64 %t1, %t4
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp sle i64 %t7, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb44
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = add i64 %t19, %t22
  store i64 %t25, ptr %l20, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = load i64, ptr %l21, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb9:
  %t39 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l16, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = getelementptr i8, ptr %t40, i64 %t41
  %t44 = sub i64 %t42, %t41
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t46, { i64, ptr } %t47)
  store i1 %t50, ptr %l27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb11:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp eq i64 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb13:
  br label %bb42
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb24
bb15:
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l31, !tbaa !27
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = sub i64 %t57, 1
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t64)
  store i1 %t66, ptr %l35
  br label %bb16
bb16:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb20
bb18:
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t68, ptr %l37, !tbaa !27
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = sub i64 %t69, 1
  %t73 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i8, ptr %t74, i64 %t71
  %t76 = load i8, ptr %t75, !tbaa !32
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t76)
  store i1 %t78, ptr %l41
  br label %bb19
bb19:
  %t79 = load i1, ptr %l41, !tbaa !21
  store i1 %t79, ptr %l36, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l36, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb23
bb22:
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t81, ptr %l43, !tbaa !27
  %t82 = load i64, ptr %l3, !tbaa !24
  %t84 = sub i64 %t82, 1
  %t86 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t84
  %t89 = load i8, ptr %t88, !tbaa !32
  %t91 = icmp eq i8 %t89, 95
  store i1 %t91, ptr %l42, !tbaa !21
  br label %bb23
bb23:
  %t93 = load i1, ptr %l42, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l30, !tbaa !21
  br label %bb24
bb24:
  %t96 = load i1, ptr %l30, !tbaa !21
  store i1 %t96, ptr %l4, !tbaa !21
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = add i64 %t97, %t100
  store i64 %t103, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t111 = icmp sge i64 %t105, %t108
  br i1 %t111, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb35
bb26:
  %t113 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t113, ptr %l58, !tbaa !27
  %t114 = load i64, ptr %l5, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i8, ptr %t117, i64 %t114
  %t119 = load i8, ptr %t118, !tbaa !32
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t119)
  store i1 %t121, ptr %l61
  br label %bb27
bb27:
  %t122 = load i1, ptr %l61, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb31
bb29:
  %t123 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t129)
  store i1 %t131, ptr %l66
  br label %bb30
bb30:
  %t132 = load i1, ptr %l66, !tbaa !21
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l62, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb34
bb33:
  %t134 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t134, ptr %l68, !tbaa !27
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t135
  %t140 = load i8, ptr %t139, !tbaa !32
  %t142 = icmp eq i8 %t140, 95
  store i1 %t142, ptr %l67, !tbaa !21
  br label %bb34
bb34:
  %t144 = load i1, ptr %l67, !tbaa !21
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l57, !tbaa !21
  br label %bb35
bb35:
  %t147 = load i1, ptr %l57, !tbaa !21
  store i1 %t147, ptr %l6, !tbaa !21
  %t148 = load i1, ptr %l4, !tbaa !21
  br i1 %t148, label %bb36, label %bb37
bb36:
  %t150 = load i1, ptr %l6, !tbaa !21
  store i1 %t150, ptr %l74, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb38
bb38:
  %t152 = load i1, ptr %l74, !tbaa !21
  br i1 %t152, label %bb39, label %bb40
bb39:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l2, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t157 = load i64, ptr %l3, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l3, !tbaa !24
  br label %bb43
bb43:
  br label %bb1
bb44:
  %t161 = load i64, ptr %l2, !tbaa !24
  store i64 %t161, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:EmbedAsk" @compiler_2fcheck_3aEmbedAsk_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:EmbedAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:EmbedAsk" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:EmbedAsk" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:EmbedAsk" %t10, i32 %a2, 2
  store %"compiler/check:EmbedAsk" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:EmbedAsk", ptr %rv
  ret %"compiler/check:EmbedAsk" %rr
}

define dso_local %"compiler/check:idleCall" @compiler_2fcheck_3aidleCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/check:idleCall"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:idleCall" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/check:idleCall" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:idleCall" %t14, %"compiler/source:Span" %a2, 2
  %t18 = insertvalue %"compiler/check:idleCall" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/check:idleCall" %t18, ptr %a4, 4
  store %"compiler/check:idleCall" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:idleCall", ptr %rv
  ret %"compiler/check:idleCall" %rr
}

define dso_local %"compiler/check:inPlaceRead" @compiler_2fcheck_3ainPlaceRead_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %rv = alloca %"compiler/check:inPlaceRead"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:inPlaceRead" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:inPlaceRead" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  %t14 = insertvalue %"compiler/check:inPlaceRead" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:inPlaceRead" %t14, %"compiler/source:Span" %a3, 3
  store %"compiler/check:inPlaceRead" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:inPlaceRead", ptr %rv
  ret %"compiler/check:inPlaceRead" %rr
}

define dso_local %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4, { i64, ptr } %a5, i64 %a6, i1 %a7, i64 %a8) #0 {
entry:
  %rv = alloca %"compiler/check:narrowed"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/check:narrowed" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/check:narrowed" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/check:narrowed" %t22, i32 %a2, 2
  %t26 = insertvalue %"compiler/check:narrowed" %t24, i64 %a3, 3
  %t28 = insertvalue %"compiler/check:narrowed" %t26, i64 %a4, 4
  %t30 = insertvalue %"compiler/check:narrowed" %t28, { i64, ptr } %a5, 5
  %t32 = insertvalue %"compiler/check:narrowed" %t30, i64 %a6, 6
  %t34 = insertvalue %"compiler/check:narrowed" %t32, i1 %a7, 7
  %t36 = insertvalue %"compiler/check:narrowed" %t34, i64 %a8, 8
  store %"compiler/check:narrowed" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:narrowed", ptr %rv
  ret %"compiler/check:narrowed" %rr
}

define dso_local %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:roOrigin"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:roOrigin" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/check:roOrigin" %t6, i1 %a1, 1
  store %"compiler/check:roOrigin" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roOrigin", ptr %rv
  ret %"compiler/check:roOrigin" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" -> " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d2 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d3 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2esole_2ecompiler_2fcheck_3aframe_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
@__olang_empty_array = external constant [16 x i64]
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@olang_2esole_2ecompiler_2fdiag_3acontext_2e1 = weak hidden constant i1 false
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d6 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"' is called through an 'any " }>, align 8
@.d7 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"&' here, so " }>, align 8
@.d8 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" needs it" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d11 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a table slot the instance's type meets no way" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"a type of this kind called" }>, align 8
@.d14 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"a declared number's constructor of this shape (T29d)" }>, align 8
@.d15 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"a constructor of this kind" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"type" }>, align 8
@olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4 = weak hidden constant i1 false
@.d17 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"the checker asked for a frame with none open" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
@.d18 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a generator whose Generator has no constructor" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d19 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/map" }>, align 8
@.d20 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"MapEntry" }>, align 8
@.d21 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"FromIter" }>, align 8
@.d22 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a builder 'FromIter'" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2eArray_3ccompiler_2ftyped_3aConst_26_3e_2e_2d1 = weak hidden constant i1 false
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Get" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d30 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"SliceOf" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitNot" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@olang_2esole_2ecompiler_2fcheck_3aChecker_2e61 = weak hidden constant i1 false
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'-'" }>, align 8
@.d35 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Neg ('-')" }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'~'" }>, align 8
@.d37 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"the parameter" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Copy" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/typed:Local" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGlobalReadsItself(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGlobalsCycle(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_975dab88aa27b035_9179ffefefe8db69 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_687718fa9f832d83_eed198ed3faef857 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eLen_H3aff79531665083e8df6fb2351948096(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eAt__H223e9cc5a62bb13aec2c4037d58f7975(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_3fa0bc2758d24028_39c102aa9b869b2c = external constant [0 x i8]
@olang_loc_386bb7dc57d3fef9_468931e243621ddd = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H53de96b937c1888202b72d022fb4696d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethunkModule(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
@olang_loc_3c4a57751e7c3c44_a964a095ba0d8e8 = external constant [0 x i8]
@olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
@olang_loc_f31fa7029241fd32_aa76ba41726a43b6 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_e17fa1ab378faab9_6d6fcc9fefe16fc5 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
@olang_loc_cd555273ac5ad6b8_af09fb78e7087b4 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopCheck(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForeignBuilt(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_77e9ca8727c07af9_ddc1fd4e636ee49d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etoDeclaredFunc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5759851fa91ce76c_a0f65aa07f0891f0 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaidAlike(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeHasNoConstructor(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleRaised(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_66d3d1d20fd502cf_cd668d3b10c2a493 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstHoldsItself(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstImmutUnique(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeContexts(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewBody(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypes(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edtorBody(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePrimCtorParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_1a21871eed64942d_5f8df5778525f19 = external constant [0 x i8]
@olang_loc_c58696bc0c2f7b46_a4aa6b3b7860c7f2 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_dbcdd42e40c3e4ce_a7e80860aca3d0ca = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5, i32 %a6)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
@olang_loc_6f8999b7f8ddffc_ce9c2022d5a87cc8 = external constant [0 x i8]
@olang_loc_da726112f8a5d119_ce42f73d9d53945 = external constant [0 x i8]
@olang_loc_771f29b9e3f6ab8a_7fc52d4465222796 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ewordAt(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaisedWordOwnName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorWordInUse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetReaches(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorSetHoldsItself(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetEntries(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorWordOfMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesNoQuestion(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryNeedsQuestion(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoValueCase(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_3f3d818644d50cc7_38dbc52e232a8b93 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f2fc693d8c32a9d2_b249c5d053dbb65e = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_1aa49c7f94741e71_4937354175d6cb9d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseFields(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyFieldRow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
@olang_loc_a8287edb9132b4cb_1f129b43d5c83daf = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_fd7c4531a6f9112_8820f62eca2e3ad6 = external constant [0 x i8]
@G_2ecompiler_2fgeneric_2eGenFromReturn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenLambda(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3, i64 %a4)
@olang_loc_8107208a4245ff9c_ccbe9a9f570baf38 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emodOfFile(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eisLit(ptr %v0, ptr %a0)
@olang_loc_317381e6e3d2ca51_b8977c113f1a9cfd = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_8803ccf5e870aa5b_cb8fe22003fe469f = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eWhyCalled = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:nullNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3anullNarrow_2eKilled(ptr %v0, ptr %v1, %"compiler/check:nullNarrow" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:nullNarrow" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(ptr %v0, ptr %v1, %"compiler/check:narrowed" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:narrowed" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/check:errNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3aerrNarrow_2eKilled(ptr %v0, ptr %v1, %"compiler/check:errNarrow" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:errNarrow" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_d04702acd6c67beb_c6baeec7be1e7af7 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_57a7d7e6d1174c7c_73fda2027ad2ad8 = external constant [0 x i8]
@olang_loc_fd3b2969d106d871_acdc32576a39b9ed = external constant [0 x i8]
declare i64 @compiler_2fcheck_2elocalIdOf(ptr %v0, ptr %a0)
@olang_loc_9336e0175c2e9c6a_aabb9d2690ac9706 = external constant [0 x i8]
@olang_loc_12a21cc2c4eb057_a597a544841c60b = external constant [0 x i8]
@olang_loc_286fe13485cd942f_1c0d0a1e63f5e7b3 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epackedPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedLend(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNotMade(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:litBuilder" @compiler_2fcheck_3alitBuilder_2ector(ptr %v0, i64 %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNoFromIter(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efromIterElem(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFromIterShape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralUnique(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
@olang_loc_2a22705e3675cc6a_15625908cbc104fe = external constant [0 x i8]
@olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33 = external constant [0 x i8]
@olang_loc_f1d5d3b2155f2ddc_ad13ea37e14bc210 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePositionalAfterNamed(ptr %v0)
@olang_loc_6a354e0ae5aa0db2_42d5d79e5424950e = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e993077ed681d47d_7cf2fdb3e0a34b99 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4e588e9eb703ca58_549acb49cdd076c4 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/check:seqOf" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorInstance(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsLibrary(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenInt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDivisorProven(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShiftProven(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i1 %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaiseNotCaught(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereraise(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraiseUnknown(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaiseNeedsQuestion(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushPayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i64 %a4, { i64, ptr } %a5)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_9ffee6a4e1a43bc2_8f88457b20f170fe = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ce05aca7270627a9_4d670951fa414da5 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2eLen_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %a0)
declare %"compiler/check:landing" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2eAt_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elandingsOf(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5ec272a16da13ce8_6a23c064ecfaca54 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@olang_loc_3727962a9e2e15db_7cf774666c9d4227 = external constant [0 x i8]
@olang_loc_81d441761e2a717d_f45e749fdf1e1e81 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBitOpNotInteger(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eByteSwapWidth(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBitOpCount(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
@olang_loc_6002682392a89678_bee70fdc9b2b3a94 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5)
@olang_loc_2959120118b86297_7adce6d47ed385a3 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eP_H67072fc16e996275e069a499f28fddf9(ptr %v0, ptr %a0, %"compiler/check:TopAssertAsk" %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
@olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c = external constant [0 x i8]
@olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTryList(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueMoved(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVarArgType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopyParts(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_4c67a4e0f39ce0e6_aa4d8ec9734e07a2 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnSlice(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b2735ee686977dce_6cfd672f66c8ceea = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_922ae0a799ba69ce_f9cc72ab99b0ec2 = external constant [0 x i8]
@olang_loc_46a0e749826cef18_3e2809181fcd5dac = external constant [0 x i8]
@olang_loc_2f12767f94a228d4_8b6b4888798b3f68 = external constant [0 x i8]
@olang_loc_a4a9e3d1ce4f287a_3905f5d0b0eda75e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_eb3e4e8f3f96f0ec_5bc3fc9686c42b70 = external constant [0 x i8]
@olang_loc_bad8a01556e87002_6e42cd1773855696 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2echainSets(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f5486e4325103d79_668082c6ca0b25f5 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_129627029b1e0c70_26637847123ec4fc = external constant [0 x i8]
@olang_loc_a18b02733ea53beb_f9e22fb852fb348f = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
